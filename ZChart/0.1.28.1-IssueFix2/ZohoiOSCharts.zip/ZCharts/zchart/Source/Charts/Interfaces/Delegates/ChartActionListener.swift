//
//  ChartActionListener.swift
//  zchart
//
//  Created by Aravinth T on 03/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

//#if !os(OSX)
//    import UIKit
//#endif
//
//@objc
//public protocol ChartActionListener: class {
//    
//     
//}
