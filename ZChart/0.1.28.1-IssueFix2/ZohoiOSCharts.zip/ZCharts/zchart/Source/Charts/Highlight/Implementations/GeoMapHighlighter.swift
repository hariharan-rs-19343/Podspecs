//
//  GeoMapHighlighter.swift
//  zchart
//
//  Created by Aravinth T on 30/11/21.
//

import Foundation

@objc(GeoMapChartHighlighter)
open class GeoMapHighlighter: ChartHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart,
              let data = chart.data
               else  { return nil }
        
        let pt = CGPoint(x: x, y: y)
               
       if let geoMapLayer = GeoMapLayer.getGeoMapLayerInPoint(chart: chart, loc: pt),
       let entry = geoMapLayer.chartEntry,
       let set =  geoMapLayer.dataset
       {
           let setIndex =  data.indexOfDataSet(set)
           let entryIndex = set.entryIndex(entry: entry)
           return Highlight(x: Double(entryIndex), y: (entry.y), xPx: pt.x, yPx: pt.y, dataSetIndex: setIndex, axisIndex: (set.axisIndex))
        }
          
        return nil
    }
    
    open override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        guard let chart = chart
        else  { return nil }
        
        let dataSet = chart.data!.dataSets[highlight.dataSetIndex]
        return dataSet.entryForIndex(ChartUtils.doubleToIntSafeCast(value:highlight.x))
    }
    
    override open func getHighlight(entry: ChartDataEntry) -> Highlight? {
        guard let chart = chart,
              let geoPlotOption = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions,
              let processor = chart.getProcessor(type: .GeoHeatMap) as? GeoMapPreprocessor
        else  { return nil }
        
        if let key = GeoMapPreprocessor.getKey(entry: entry, plotOptions: geoPlotOption),
           let feature = processor.featureMap[key],
           let properties = feature["properties"] as? [String:AnyObject],
           let latitude = properties["latitude"] as? CGFloat,
           let longitude = properties["longitude"] as? CGFloat,
           let points = processor.getProjectionPoint(x: longitude, y: latitude)
          {
            let pt = GeoMapPreprocessor.getTransformerPoint(point: CGPoint(x: points[0], y: points[1]), transformer: chart.plotTransformer)
            return getHighlight(x: pt.x, y: pt.y)
        }
        
//         if let geoMapLayer = GeoMapLayer.getGeoMapLayerForEntry(chart: chart, entry: entry)
//         {
//             let pt = CGPoint(x: geoMapLayer.path!.boundingBoxOfPath.midX, y: geoMapLayer.path!.boundingBoxOfPath.midY)
//            return getHighlight(x: pt.x, y: pt.y)
//        }
         return nil
    }
  
}
