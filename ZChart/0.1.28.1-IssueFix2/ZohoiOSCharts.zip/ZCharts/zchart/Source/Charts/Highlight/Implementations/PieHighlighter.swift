//
//  PieHighlighter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(PieChartHighlighter)
open class PieHighlighter: PieRadarHighlighter
{
    open override func closestHighlight(index: Int, x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let set = chart?.data?.dataSets[0]
            else { return nil }
        
        guard let entry = set.entryForIndex(index)
            else { return nil }
        
        return Highlight(x: Double(index), y: entry.y, xPx: x, yPx: y, dataSetIndex: 0, axisIndex: set.axisIndex)
    }
    
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = self.chart,
              let piePlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Dial,.Pie]) as? PiePlotOptions,
              let processor = CommonHelperFunctions.getProcessor(chart:chart,types:[.Dial,.Pie]) as? PieRadarPreprocessor
            else { return nil }
        
        let touchDistanceToCenter = processor.distanceToCenter(x: x, y: y)
        
        // check if a slice was touched
        if touchDistanceToCenter > piePlot.radius
        {
            // if no slice was touched, highlight nothing
            return nil
        }
        else
        {
            var angle = PieHelperFunctions.angleForPoint(x: x ,y: y, center: piePlot.centerCircleBox)
            
            if chart.plotTypes.contains(.Pie)
            {
                angle /= CGFloat(chart.chartAnimator.phaseY)
            }
            
            let index = processor.indexForAngle(angle)
            
            // check if the index could be found
            if index < 0 || index >= chart.data?.maxEntryCountSet?.entryCount ?? 0
            {
                return nil
            }
            else
            {
                return closestHighlight(index: index, x: x, y: y)
            }
        }
    }
    
    public override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        
        guard let dataSet = chart?.data?.dataSets[0]
                   else { return nil }
        
        return dataSet.entryForIndex(ChartUtils.doubleToIntSafeCast(value:highlight.x))
    }
}
