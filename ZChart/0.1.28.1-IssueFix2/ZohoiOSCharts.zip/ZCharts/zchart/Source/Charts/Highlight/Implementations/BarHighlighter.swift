//
//  BarHighlighter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(BarChartHighlighter)
open class BarHighlighter: ChartHighlighter
{
    
    var typeAllowed = [ChartType.Bar,ChartType.WaterFall,ChartType.BoxPlot,ChartType.Bullet]
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart
            else { return nil}
        
        if chart._data === nil
        {
            Swift.print("Can't select by touch. No data set.")
            return nil
        }
        
        var high = super.getHighlight(x: x, y: y)
        
        if high == nil
        {
            return nil
        }
        
        if let barData = (self.chart?.data)
        {
            let pos = getValsForTouch(x: x, y: y)
            
            if
                let set = barData.getDataSetByIndex(high!.dataSetIndex),
                let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
                plotOptions.isStacked
            {
                high = getStackedHighlight(high: high!,
                                            set: set,
                                            xValue: Double(pos.x),
                                           yValue: Double(pos.y)) ?? high
            }

        }
        
        guard let h = high,
            let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
             else { return nil }
         
        if !plotOptions.isHighlightFullBarEnabled { return h }
                
        return Highlight(
            x: h.x, y: h.y,
            xPx: h.xPx, yPx: h.yPx,
            dataIndex: h.dataIndex,
            dataSetIndex: h.dataSetIndex,
            stackIndex: -1,
            axisIndex: h.axisIndex)
        
    }
    
    override open func getHighlights(xValue: Double, x: CGFloat, y: CGFloat) -> [Highlight]
    {
        var vals = [Highlight]()
        
        guard let
            data = self.data
            else { return vals }
        
        for i in 0 ..< data.dataSetCount
        {
            guard let dataSet = data.getDataSetByIndex(i),
                  (dataSet.plotType == .Bar || dataSet.plotType == .Bullet || dataSet.plotType == .BoxPlot || dataSet.plotType == .WaterFall)
                else { continue }
            
            // don't include datasets that cannot be highlighted and not visible
            if !dataSet.isHighlightEnabled || !dataSet.isVisible
            {
                continue
            }
            
            // extract all y-values from all DataSets at the given x-value.
            // some datasets (i.e bubble charts) make sense to have multiple values for an x-value. We'll have to find a way to handle that later on. It's more complicated now when x-indices are floating point.
            
            vals.append(contentsOf: buildHighlights(dataSet: dataSet, dataSetIndex: i, xValue: xValue, rounding: .closest))
        }
        
        return vals
    }
    
    internal override func getDistance(x1: CGFloat, y1: CGFloat, x2: CGFloat, y2: CGFloat) -> CGFloat
    {
        return abs(x1 - x2)
    }
    
    /// This method creates the Highlight object that also indicates which value of a stacked BarEntry has been selected.
    /// - parameter high: the Highlight to work with looking for stacked values
    /// - parameter set:
    /// - parameter xIndex:
    /// - parameter yValue:
    /// - returns:
    open func getStackedHighlight(high: Highlight,
                                  set: IChartDataSet,
                                  xValue: Double,
                                  yValue: Double) -> Highlight?
    {
        if let chart = chart, let entriesStackedYValue = (chart.getProcessor(type: .Bar) as? AxisChartPreprocessor)?.entriesStackedYValue {
            
            let xVal = chart.isRotated ? yValue : xValue
            let yVal = chart.isRotated ? xValue : yValue
            
            return super.getStackedHighlight(high: high, xValue: xVal, yValue: yVal, entriesStackedYValue: entriesStackedYValue)
        }
        return nil
    }
    
    /// - returns: The index of the closest value inside the values array / ranges (stacked barchart) to the value given as a parameter.
    /// - parameter entry:
    /// - parameter value:
    /// - returns:
    open func getClosestStackIndex(ranges: [Range]?, value: Double) -> Int
    {
        if ranges == nil
        {
            return 0
        }
        
        var stackIndex = 0
        
        for range in ranges!
        {
            if range.contains(value)
            {
                return stackIndex
            }
            else
            {
                stackIndex += 1
            }
        }
        
        let length = max(ranges!.count - 1, 0)
        
        return (value > ranges![length].to) ? length : 0
    }
}
