//
//  PackedBubbleHighlighter.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 03/06/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

@objc(PackedBubbleChartHighlighter)
open class PackedBubbleHighlighter: ChartHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart
               else  { return nil }
        
        let pt = CGPoint(x: x, y: y)
               
        
        for layer in BubbleLayer.getAllBubbleLayer(chart: chart) where layer.chartEntry?.childEntries.count == 0 && layer.chartEntry?.xString != "root"
        {
            if (layer.path?.contains(pt))!
            {
                let entry = layer.chartEntry
                let set =  layer.bubbleDataSet
                let setIndex = chart.data?.indexOfDataSet(set!)
                
                return Highlight(xString: (layer.chartEntry?.xString)!, y: (entry?.y)!, xPx: pt.x, yPx: pt.y, dataSetIndex: setIndex!, axisIndex:(set?.axisIndex)!)
            }
        }
    
        return nil
    }
    
    open override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        guard let chart = chart
        else  { return nil }
        
        let pt = CGPoint(x: highlight.xPx, y: highlight.yPx)
        
        for layer in BubbleLayer.getAllBubbleLayer(chart: chart) where layer.chartEntry?.childEntries.count == 0 && layer.chartEntry?.xString == highlight.xString
        {
            if (layer.path?.contains(pt))!
            {
                let entry = layer.chartEntry
                return entry
            }
        }
        return nil
    }
    
   
    
    override open func getHighlight(entry: ChartDataEntry) -> Highlight? {
        guard let chart = chart
        else  { return nil }
        
        
         if let bubbleLayer = BubbleLayer.getBubbleLayerForEntry(chart: chart, entry: entry) {
            
                let entry = bubbleLayer.chartEntry
                let set =  bubbleLayer.bubbleDataSet
                let setIndex = chart.data?.indexOfDataSet(set!)
                
            
            return Highlight(xString: (bubbleLayer.chartEntry?.xString)!, y: (entry?.y)!, xPx: bubbleLayer.shapePoint!.x, yPx: bubbleLayer.shapePoint!.y, dataSetIndex: setIndex!, axisIndex:(set?.axisIndex)!)
                 
        }
         return nil
    }
    
    
    
}

