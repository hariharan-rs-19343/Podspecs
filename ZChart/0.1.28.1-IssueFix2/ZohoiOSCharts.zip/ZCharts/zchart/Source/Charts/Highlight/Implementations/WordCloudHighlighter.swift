//
//  WordCloudHighlighter.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 20/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

@objc(WordCloudChartHighlighter)
open class WordCloudHighlighter: ChartHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart
               else  { return nil }
        
        let pt = CGPoint(x: x, y: y)
               
        let textLayer = WordCloudTextLayer.getWordLayerInPoint(chart: chart, loc: pt)
          
        if textLayer != nil {
            let entry = textLayer?.chartEntry
            let set =  textLayer?.chartDataSet
            let setIndex = textLayer?.valueDict["setIndex"] as! Int
            let entryIndex = textLayer?.valueDict["entryIndex"] as! Int
            return Highlight(x: Double(entryIndex), y: (entry?.y)!, xPx: pt.x, yPx: pt.y, dataSetIndex: setIndex, axisIndex: (set?.axisIndex)!)
        }
          
        return nil
    }
    
    open override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        guard let chart = chart
        else  { return nil }
        
        let dataSet = chart.data!.dataSets[highlight.dataSetIndex]
        return dataSet.entryForIndex(ChartUtils.doubleToIntSafeCast(value:highlight.x))
    }
    
    override open func getHighlight(entry: ChartDataEntry) -> Highlight? {
        guard let chart = chart
        else  { return nil }
        
        let textLayer = WordCloudTextLayer.getWordLayerForEntry(chart: chart, entry: entry)
         if textLayer != nil {
            let pt = CGPoint(x: textLayer?.valueDict["x"] as! CGFloat, y: textLayer?.valueDict["y"] as! CGFloat)
            return getHighlight(x: pt.x, y: pt.y)
        }
         return nil
    }
    
    
    
}
