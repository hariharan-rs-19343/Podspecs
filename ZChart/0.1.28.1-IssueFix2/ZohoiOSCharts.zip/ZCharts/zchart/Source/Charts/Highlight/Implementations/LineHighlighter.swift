//
//  LineHighlighter.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/02/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

@objc(LineHighlighter)
open class LineHighlighter: ChartHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line,.LineRange]) as? LinePlotOptions
               else  { return nil }
        
        return highlightEntry(x: x, y: y, isStacked: plotOption.isStacked, chartType: .Line)
    }
    
    func highlightEntry(x: CGFloat, y: CGFloat, isStacked: Bool, chartType: ChartType) -> Highlight? {
        
        guard let chart = chart else {
            return nil
        }
        
        if isStacked
        {
            if let highlight = super.getHighlight(x: x, y: y), let entriesStackedYValue = (chart.getProcessor(type: chartType) as? AxisChartPreprocessor)?.entriesStackedYValue {
                
                let pos = getValsForTouch(x: x, y: y)
                let xVal = chart.isRotated ? pos.y : pos.x
                let yVal = chart.isRotated ? pos.x : pos.y
                
                return super.getStackedHighlight(high: highlight, xValue: xVal, yValue: yVal, entriesStackedYValue: entriesStackedYValue) ?? super.getHighlight(x: x, y: y)
            }
        }
        else{
            return super.getHighlight(x: x, y: y)
        }
        return nil
    }
    
}
