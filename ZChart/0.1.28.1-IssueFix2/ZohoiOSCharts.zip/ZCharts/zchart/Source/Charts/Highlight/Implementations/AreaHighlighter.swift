//
//  AreaHighlighter.swift
//  zchart
//
//  Created by Keerthivass B S on 09/05/24.
//

import Foundation
import CoreGraphics

@objc(AreaHighlighter)
open class AreaHighlighter: LineHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Area]) as? AreaPlotOptions
               else  { return nil }
        
        return highlightEntry( x: x, y: y, isStacked: plotOption.isStacked, chartType: .Area)
    }
    
}
