//
//  CombinedHighlighter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(CombinedChartHighlighter)
open class CombinedHighlighter: ChartHighlighter
{
    /// bar highlighter for supporting stacked highlighting
    fileprivate var barHighlighter: BarHighlighter?
    
    public override init(chart: ChartViewBase)
    {
        super.init(chart: chart)
        
        let combinedChart = chart
                
        // if there is BarData, create a BarHighlighter
        self.barHighlighter = combinedChart.plotTypes.contains(.Bar) ?  BarHighlighter(chart: chart) : nil
    }
    
    open override func getHighlights(xValue: Double, x: CGFloat, y: CGFloat) -> [Highlight]
    {
        var vals = [Highlight]()
        
//        if let dataObjects = [self.chart?.data]
//        {
//            for i in 0..<dataObjects.count
//            {
                let dataObject = (self.chart?.data)!
                
                // in case of BarData, let the BarHighlighter take over
                if barHighlighter != nil
                {
                    if let high = barHighlighter?.getHighlight(x: x, y: y)
                    {
                        high.dataIndex = 0
                        vals.append(high)
                    }
                }
        
                if vals.count == 0
                {
                    for j in 0..<dataObject.dataSetCount
                    {
                        guard let dataSet = dataObject.getDataSetByIndex(j)
                            else { continue }
                        
                        // don't include datasets that cannot be highlighted
                        if !dataSet.isHighlightEnabled || !(dataSet.isVisible)
                        {
                            continue
                        }
                        
                        let highs = buildHighlights(dataSet: dataSet, dataSetIndex: j, xValue: xValue, rounding: .closest)
                        
                        for high in highs
                        {
                            high.dataIndex = 0
                            vals.append(high)
                        }
                    }
                }
//            }
//        }
        
        return vals
    }
    
    public override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        
        let combinedChartView = self.chart!
        
        guard let data = combinedChartView.data else {
            return nil
        }
       
        if highlight.dataSetIndex >= data.dataSetCount
        {
            return nil
        }
        else
        {
            // The value of the highlighted entry could be NaN - if we are not interested in highlighting a specific value.
            let entries = data.getDataSetByIndex(highlight.dataSetIndex).entriesForXValue(highlight.x)
            for e in entries
            {
                if e.y == highlight.y || highlight.y.isNaN
                {
                    return e
                }
            }
           
            return nil
        }
    }
    
      /// - returns: The Highlight object (contains x-index and DataSet index) of the selected value at the given touch point inside the CombinedChart.
    override open func getHighlight(x: CGFloat, y: CGFloat) -> Highlight? {
       guard let chart = chart
        else { return nil }
        
        if chart._data === nil
        {
            Swift.print("Can't select by touch. No data set.")
            return nil
        }
        
        guard let h = super.getHighlight(x: x, y: y)
            else { return nil }
        
        guard let plotOptions = chart.getPlotOptions(type: .Bar) as? BarPlotOptions
            else { return h }
        
        if !(plotOptions.isHighlightFullBarEnabled) { return h }
        
        // For isHighlightFullBarEnabled, remove stackIndex
        return Highlight(
            x: h.x, y: h.y,
            xPx: h.xPx, yPx: h.yPx,
            dataIndex: h.dataIndex,
            dataSetIndex: h.dataSetIndex,
            stackIndex: -1,
            axisIndex: h.axisIndex)
    }

 
}
