//
//  FunnelHighlighter.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 08/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

@objc(FunnelChartHighlighter)
open class FunnelHighlighter: ChartHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart
               else  { return nil }
        
        let pt = CGPoint(x: x, y: y)
               
        let funnelLayer = FunnelLayer.getFunnelLayerInPoint(chart: chart, loc: pt)
          
        if funnelLayer != nil {
            let entry = funnelLayer?.getFunnelChartEntry()
            let set =  chart.data?.dataSets[0]
            let index = (set?.entryIndex(entry: entry!))!
            return Highlight(x: Double(index), y: (entry?.y)!, xPx: pt.x, yPx: pt.y, dataSetIndex: 0, axisIndex: (set?.axisIndex)!)
        }
          
        return nil
    }
    
    open override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        guard let chart = chart
        else  { return nil }
        
        let dataSet = chart.data!.dataSets[0]
        return dataSet.entryForIndex(ChartUtils.doubleToIntSafeCast(value:highlight.x))
    }
    
    /*open override func entryForHighlight(_ highlight: Highlight, customHighlighter: IHighlighter) -> ChartDataEntry? {
        return self.entryForHighlight(highlight)
    }
     open override func getHighlightByEntry(_ e: ChartDataEntry, customHighlighter: IHighlighter) -> Highlight? {
         return getHighlightByEntry(e)
     }*/
    
    override open func getHighlight(entry: ChartDataEntry) -> Highlight? {
        guard let chart = chart
        else  { return nil }
        
        let funnelLayer = FunnelLayer.getFunnelLayerForEntry(chart: chart, entry: entry)
         if funnelLayer != nil {
             let funnelSlicePoint = funnelLayer?.funnelSlicePoint
             let pt = FunnelChartRenderer.getCenterPoint(funnelSlicePoint: funnelSlicePoint!)
            return getHighlight(x: pt.x, y: pt.y)
        }
         return nil
    }
    
    
    
}
