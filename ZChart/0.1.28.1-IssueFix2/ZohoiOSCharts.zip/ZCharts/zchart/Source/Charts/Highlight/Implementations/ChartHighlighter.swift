//
//  ChartHighlighter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

open class ChartHighlighter : NSObject, IHighlighter
{
    /// instance of the data-provider
    open weak var chart: ChartViewBase?
    
    public init(chart: ChartViewBase)
    {
        self.chart = chart
    }
    
    open func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart
        else { return nil }
        
        let xVal = chart.isRotated ? Double(getValsForTouch(x: x, y: y).y) : Double(getValsForTouch(x: x, y: y).x)
        
        guard let high =  chart.isRotated ? getHighlight(xValue: xVal, x: y, y: x) : getHighlight(xValue: xVal, x: x, y: y)
        else { return nil }
        
        if high.y.isNaN
        {
            guard let entry = chart.entryForHighlight(high)
            else { return nil }
            let nextX = CommonHelperFunctions.getNextXEntryinData(entry: entry, includeXNan: false, includeYNan: false, loopingAllowed: false, chart: chart)
            let prevX = CommonHelperFunctions.getPrevXEntryinData(entry: entry, includeXNan: false, includeYNan: false, loopingAllowed: false, chart: chart)
            
            if nextX == nil && prevX == nil
            {
                return nil
            }
            if nextX == nil && prevX != nil
            {
                return getHighlight(entry: prevX!)
            }
            if nextX != nil && prevX == nil
            {
                return getHighlight(entry: nextX!)
            }
            
            if abs(prevX!.x - entry.x) < abs(nextX!.x - entry.x)
            {
                return getHighlight(entry: prevX!)
            }
            else{
                return getHighlight(entry: nextX!)
            }
        }
        return high
    }
    
    open func getHighlight(entry:ChartDataEntry) -> Highlight?
    {
        guard let chart = self.chart,
            let set = chart.data?.getDataSetForEntry(entry),
            let dataSetIndex = chart.data?.indexOfDataSet(set)
            else { return  nil }
        
        let px = chart.pixelForValues(isRotated: chart.isRotated, x: entry.x, y: entry.y, axisIndex: set.axisIndex)
    
        return Highlight(x: entry.x, y: entry.y, xPx: px.x, yPx: px.y, dataSetIndex: dataSetIndex, axisIndex: set.axisIndex)
    }
    
    public func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        
        guard let dataSets = self.chart?.data?.dataSets else {
            return nil
        }
        
        if highlight.dataSetIndex >= dataSets.count
        {
            return nil
        }
        else
        {
            return dataSets[highlight.dataSetIndex].entryForXValue(highlight.x, closestToY: highlight.y)
        }
    }
    
    /// - returns: The corresponding x-pos for a given touch-position in pixels.
    /// - parameter x:
    /// - returns:
    open func getValsForTouch(x: CGFloat, y: CGFloat) -> CGPoint
    {
        guard let chart = self.chart
            else { return CGPoint.zero }
        
        // take any transformer to determine the values
        return chart.getTransformer(axisIndex: 0).valueForTouchPoint(x: x, y: y)
    }
    
    /// - returns: The corresponding ChartHighlight for a given x-value and xy-touch position in pixels.
    /// - parameter xValue:
    /// - parameter x:
    /// - parameter y:
    /// - returns:
    open func getHighlight(xValue xVal: Double, x: CGFloat, y: CGFloat) -> Highlight?
    {
        guard let chart = chart
            else { return nil }
        
        var closestValues = getHighlights(xValue: xVal, x: x, y: y)
        if closestValues.isEmpty
        {
            return nil
        }
        
        closestValues = getClosestHighlights(xValue: xVal, closestHigh: closestValues)
        
        var axisIndexSet:Set<Int> = []
        
        var minValue = CGFloat.greatestFiniteMagnitude
        var minAxisIndex:[Int] = []
        
        for set in (chart.data?.dataSets)! where set.isVisible
        {
            let axisIndex = set.axisIndex
            axisIndexSet.insert(axisIndex)
        }
        
        for axisIndex in axisIndexSet
        {
//            let value = getMinimumDistance(closestValues: closestValues, y: y, axisIndex: axisIndex)
            var value = getXMinimumDistance(closestValues: closestValues, x: x, axisIndex: axisIndex)
            if chart.isRotated {
                value = getMinimumDistance(closestValues: closestValues, y: y, axisIndex: axisIndex)
            }
            if value < minValue
            {
                minAxisIndex.removeAll()
                minAxisIndex.append(axisIndex)
                minValue = value
            }
            else if value == minValue
            {
                minAxisIndex.append(axisIndex)
            }
        }
        
        /*let leftAxisMinDist = getMinimumDistance(closestValues: closestValues, y: y, axisIndex: 0)
        let rightAxisMinDist = getMinimumDistance(closestValues: closestValues, y: y, axisIndex: 1)
        
        let axisIndex = leftAxisMinDist < rightAxisMinDist ? 0 : 1*/
        
        let detail = chart.isRotated ? closestSelectionDetailByPixel(closestValues: closestValues, x: y, y: x, axisIndex: minAxisIndex, minSelectionDistance: chart.maxHighlightDistance) : closestSelectionDetailByPixel(closestValues: closestValues, x: x, y: y, axisIndex: minAxisIndex, minSelectionDistance: chart.maxHighlightDistance)
        
        return detail
    }
    
    /// - returns: A list of Highlight objects representing the entries closest to the given xVal.
    /// The returned list contains two objects per DataSet (closest rounding up, closest rounding down).
    /// - parameter xValue: the transformed x-value of the x-touch position
    /// - parameter x: touch position
    /// - parameter y: touch position
    /// - returns:
    open func getHighlights(xValue: Double, x: CGFloat, y: CGFloat) -> [Highlight]
    {
        var vals = [Highlight]()
        
        guard let
            data = self.data
            else { return vals }
        
        for i in 0 ..< data.dataSetCount
        {
            guard let dataSet = data.getDataSetByIndex(i)
                else { continue }
            
            // don't include datasets that cannot be highlighted and not visible
            if !dataSet.isHighlightEnabled || !dataSet.isVisible
            {
                continue
            }
            
            // extract all y-values from all DataSets at the given x-value.
            // some datasets (i.e bubble charts) make sense to have multiple values for an x-value. We'll have to find a way to handle that later on. It's more complicated now when x-indices are floating point.
            
            vals.append(contentsOf: buildHighlights(dataSet: dataSet, dataSetIndex: i, xValue: xValue, rounding: .closest))
        }
        
        return vals
    }
    
    /// - returns: An array of `Highlight` objects closest to the selected xValue across all DataSet.
    open func getClosestHighlights(xValue: Double, closestHigh:[Highlight]) -> [Highlight]
    {
        var vals = [Highlight]()
        
        var minimumDifference = Double.greatestFiniteMagnitude
        
        guard  (self.data != nil)
            else { return vals }
        
        for high in closestHigh
        {
            let difference = abs(high.x - xValue)
            
            if difference <= minimumDifference
            {
                if difference < minimumDifference
                {
                    vals.removeAll()
                    minimumDifference = difference
                }
                vals.append(high)
            }
        }
        
        return vals
    }
    
    /// - returns: An array of `Highlight` objects corresponding to the selected xValue and dataSetIndex.
    internal func buildHighlights(
        dataSet set: IChartDataSet,
        dataSetIndex: Int,
        xValue: Double,
        rounding: ChartDataSetRounding) -> [Highlight]
    {
        var highlights = [Highlight]()
        
        guard let chart = self.chart
            else { return highlights }
        
        var entries = set.entriesForXValue(xValue)
        if entries.count == 0
        {
            // Try to find closest x-value and take all entries for that x-value
            if let closest = set.entryForXValue(xValue, closestToY: Double.nan, rounding: rounding)
            {
                entries = set.entriesForXValue(closest.x)
            }
        }
        
        for e in entries
        {
            if let px = CommonHelperFunctions.getEntryLocation(chart: chart, entry: e) {
                highlights.append(Highlight(x: e.x, y: e.y, xPx: px.x, yPx: px.y, dataSetIndex: dataSetIndex, axisIndex: set.axisIndex))
            }
        }
        
        return highlights
    }
    
    
    /// This method creates the Highlight object that also indicates which value of a stacked BarEntry has been selected.
    /// - parameter high: the Highlight to work with looking for stacked values
    /// - parameter xIndex:
    /// - parameter yValue:
    /// - parameter entriesStackedYValue:
    /// - returns:
    internal func getStackedHighlight(high: Highlight,
                                  xValue: Double,
                                  yValue: Double, 
                                  entriesStackedYValue: [Int:[Int:Double]]) -> Highlight?
    {
        guard
            let chart = chart,
            let barData = data
            else { return nil }
        
        let highLights = getHighlights(xValue: xValue, x: high.xPx, y:high.yPx )
        
        for highValue in highLights where highValue.x == high.x
        {
            guard let entry = self.entryForHighlight(highValue)
            else { return high}
            
            let  entryIndex = barData.dataSets[highValue.dataSetIndex].entryIndex(entry: entry)
            
            let baseLineValue =  CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barData.dataSets[highValue.dataSetIndex])
            
            if let stackedYValueStart = entriesStackedYValue[highValue.dataSetIndex]?[entryIndex] {
                
                let stackedYValueEnd = entry.y >= baseLineValue ? (stackedYValueStart - abs(entry.y)) : (stackedYValueStart + abs(entry.y))
                
                if stackedYValueStart > stackedYValueEnd
                {
                    if yValue >= stackedYValueEnd && yValue <= stackedYValueStart
                    {
                        return highValue
                    }
                }
                else{
                    if yValue <= stackedYValueEnd && yValue >= stackedYValueStart
                    {
                        return highValue
                    }
                }
            }
        }
        return nil
    }

    // - MARK: - Utilities
    
    /// - returns: The `ChartHighlight` of the closest value on the x-y cartesian axes
    internal func closestSelectionDetailByPixel(
        closestValues: [Highlight],
        x: CGFloat,
        y: CGFloat,
        axisIndex: Int,
        minSelectionDistance: CGFloat) -> Highlight?
    {
        var distance = minSelectionDistance
        var closest: Highlight?
        
        for i in 0 ..< closestValues.count
        {
            let high = closestValues[i]
            
            if high.axisIndex == axisIndex
            {
                let cDistance = getDistance(x1: x, y1: y, x2: high.xPx, y2: high.yPx)
                
                if cDistance < distance || cDistance.isNaN
                {
                    if cDistance.isNaN
                    {
                        if closest == nil
                        {
                            closest = high
                        }
                    }
                    else{
                        closest = high
                        distance = cDistance
                    }
                }
            }
        }
        
        return closest
    }
    
    /// - returns: The `ChartHighlight` of the closest value on the x-y cartesian axes
    internal func closestSelectionDetailByPixel(
        closestValues: [Highlight],
        x: CGFloat,
        y: CGFloat,
        axisIndex: [Int],
        minSelectionDistance: CGFloat) -> Highlight?
    {
        var distance = minSelectionDistance
        var closest: Highlight?
        
        for i in 0 ..< closestValues.count
        {
            let high = closestValues[i]
            
            if axisIndex.contains(high.axisIndex)
            {
                let cDistance = getDistance(x1: x, y1: y, x2: high.xPx, y2: high.yPx)
                
                if cDistance < distance || cDistance.isNaN
                {
                    if cDistance.isNaN
                    {
                        if closest == nil
                        {
                            closest = high
                        }
                    }
                    else{
                        closest = high
                        distance = cDistance
                    }
                }
            }
        }
        
        return closest
    }
    
    /// - returns: The minimum distance from a touch-y-value (in pixels) to the closest y-value (in pixels) that is displayed in the chart.
    internal func getMinimumDistance(
        closestValues: [Highlight],
        y: CGFloat,
        axisIndex: Int) -> CGFloat
    {
        var distance = CGFloat.greatestFiniteMagnitude
        
        for i in 0 ..< closestValues.count
        {
            let high = closestValues[i]
            
            if high.axisIndex == axisIndex
            {
                let tempDistance = abs(getHighlightPos(high: high) - y)
                if tempDistance < distance
                {
                    distance = tempDistance
                }
            }
        }
        
        return distance
    }
    
    internal func getHighlightPos(high: Highlight) -> CGFloat
    {
        return high.yPx
    }
    
    internal func getDistance(x1: CGFloat, y1: CGFloat, x2: CGFloat, y2: CGFloat) -> CGFloat
    {
        return hypot(x1 - x2, y1 - y2)
    }
    
    internal var data: ChartData?
    {
        return chart?.data
    }
    
    /// - returns: The minimum distance from a touch-x-value (in pixels) to the closest x-value (in pixels) that is displayed in the chart.
        internal func getXMinimumDistance(
            closestValues: [Highlight],
            x: CGFloat,
            axisIndex: Int) -> CGFloat
        {
            var distance = CGFloat.greatestFiniteMagnitude
            
            for i in 0 ..< closestValues.count
            {
                let high = closestValues[i]
                
                if high.axisIndex == axisIndex
                {
                    let tempDistance = abs(getXHighlightPos(high: high) - x)
                    if tempDistance < distance
                    {
                        distance = tempDistance
                    }
                }
            }
            
            return distance
        }
        
        internal func getXHighlightPos(high: Highlight) -> CGFloat
        {
            return high.xPx
        }
}
