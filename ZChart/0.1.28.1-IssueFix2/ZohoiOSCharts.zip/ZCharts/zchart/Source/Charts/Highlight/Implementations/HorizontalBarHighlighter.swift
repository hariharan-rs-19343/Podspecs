//
//  HorizontalBarHighlighter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(HorizontalBarChartHighlighter)
open class HorizontalBarHighlighter: BarHighlighter
{
    open override func getHighlight(x: CGFloat, y: CGFloat) -> Highlight?
    {
        if let barData = self.chart?.data
        {
            let pos = getValsForTouch(x: y, y: x)
            
            guard let high = getHighlight(xValue: Double(pos.y), x: y, y: x)
                else { return nil }
            
            if let set = barData.getDataSetByIndex(high.dataSetIndex),
                let plotOptions = chart?.getPlotOptions(type: .Bar) as? BarPlotOptions,
                plotOptions.isStacked
            {
                return getStackedHighlight(high: high,
                                           set: set,
                                           xValue: Double(pos.y),
                                           yValue: Double(pos.x))
            }
            
            return high
        }
        return nil
    }
    
    open override func getHighlight(entry: ChartDataEntry) -> Highlight? {
        guard let chart = self.chart,
            let set = chart.data?.getDataSetForEntry(entry),
            let dataSetIndex = chart.data?.indexOfDataSet(set)
            else { return  nil }
        
        let px = chart.getTransformer(axisIndex: set.axisIndex).pixelForValues(x: entry.y, y: entry.x)
        
        return Highlight(x: entry.x, y: entry.y, xPx: px.x, yPx: px.y, dataSetIndex: dataSetIndex, axisIndex: set.axisIndex)
    }
    
    internal override func buildHighlights(
        dataSet set: IChartDataSet,
        dataSetIndex: Int,
        xValue: Double,
        rounding: ChartDataSetRounding) -> [Highlight]
    {
        var highlights = [Highlight]()
        
        guard let chart = self.chart
            else { return highlights }
        
        var entries = set.entriesForXValue(xValue)
        if entries.count == 0
        {
            // Try to find closest x-value and take all entries for that x-value
            if let closest = set.entryForXValue(xValue, closestToY: Double.nan, rounding: rounding)
            {
                entries = set.entriesForXValue(closest.x)
            }
        }
        
        for e in entries
        {
            let px = chart.getTransformer(axisIndex: set.axisIndex).pixelForValues(x: e.y, y: e.x)
            
            highlights.append(Highlight(x: e.x, y: e.y, xPx: px.x, yPx: px.y, dataSetIndex: dataSetIndex, axisIndex: set.axisIndex))
        }
        
        return highlights
    }
    
    internal override func getDistance(x1: CGFloat, y1: CGFloat, x2: CGFloat, y2: CGFloat) -> CGFloat
    {
        return abs(y1 - y2)
    }
}
