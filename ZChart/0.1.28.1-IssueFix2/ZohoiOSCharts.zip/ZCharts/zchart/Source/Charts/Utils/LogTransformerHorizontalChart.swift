//
//  LogTransformerHorizontalChart.swift
//  zchart
//
//  Created by Keerthivass B S on 22/05/24.
//

import Foundation

open class LogTransformerHorizontalChart: TransformerHorizontalBarChart {
    
    var base: CGFloat
    var isXaxisLogScale: Bool
    var isYaxisLogScale: Bool
    
    public required init(viewPortHandler: ViewPortHandler, base: CGFloat, isXaxisLogScale: Bool, isYaxisLogScale: Bool)
    {
        self.base = base
        self.isXaxisLogScale = isXaxisLogScale
        self.isYaxisLogScale = isYaxisLogScale
        super.init(viewPortHandler: viewPortHandler)
    }
    
    public required init(viewPortHandler: ViewPortHandler) {
        self.base = 10
        self.isXaxisLogScale = false
        self.isYaxisLogScale = false
        super.init(viewPortHandler: viewPortHandler)
    }
    
    /// Transform an array of points with all matrices.
    // VERY IMPORTANT: Keep matrix order "value-touch-offset" when transforming.
    open override func pointValuesToPixel(_ points: inout [CGPoint])
    {
        let trans = valueToPixelMatrix
        for i in 0 ..< points.count
        {
            points[i] = logValueFor(point: points[i])
            points[i] = points[i].applying(trans)
        }
    }
    
    open override func pointValueToPixel(_ point: inout CGPoint)
    {
        point = logValueFor(point: point)
        point = point.applying(valueToPixelMatrix)
    }
    
    open override func pixelForValues(x: Double, y: Double, isOriginal: Bool = true) -> CGPoint
    {
        if isOriginal {
            return logValueFor(point: CGPoint(x: x, y: y)).applying(valueToPixelMatrix)
        }
        else {
            return super.pixelForValues(x: x, y: y)
        }
    }
    
    /// Transform a rectangle with all matrices.
    open override func rectValueToPixel(_ r: inout CGRect)
    {
        let logSizeValue = logValueFor(point: CGPoint(x: r.size.width, y: r.size.height))
        let topValue = ChartUtils.biSymmetricLogTransformation(base: base, x: r.maxX)
        let baseValue = ChartUtils.biSymmetricLogTransformation(base: base, x: r.minX)
        r.origin = logValueFor(point: r.origin)
        r.size.width = logSizeValue.x > 0 ? abs(topValue - baseValue) : -abs(topValue - baseValue)
        r.size.height = logSizeValue.y
        r = r.applying(valueToPixelMatrix)
    }

    /// transforms multiple rects with all matrices
    open override func rectValuesToPixel(_ rects: inout [CGRect])
    {
        let trans = valueToPixelMatrix
        
        for i in 0 ..< rects.count
        {
            let logSizeValue = logValueFor(point: CGPoint(x: rects[i].size.width, y: rects[i].size.height))
            let topValue = ChartUtils.biSymmetricLogTransformation(base: base, x: rects[i].maxX)
            let baseValue = ChartUtils.biSymmetricLogTransformation(base: base, x: rects[i].minX)
            rects[i].origin = logValueFor(point: rects[i].origin)
            rects[i].size.width = logSizeValue.x > 0 ? abs(topValue - baseValue) : -abs(topValue - baseValue)
            rects[i].size.height = logSizeValue.y
            rects[i] = rects[i].applying(trans)
        }
    }
    
    /// Transforms the given array of touch points (pixels) into values on the chart.
    open override func pixelsToValues(_ pixels: inout [CGPoint])
    {
        let trans = pixelToValueMatrix
        
        for i in 0 ..< pixels.count
        {
            pixels[i] = pixels[i].applying(trans)
            pixels[i] = antiLogValueFor(point: pixels[i])
        }
    }
    
    /// Transforms the given touch point (pixels) into a value on the chart.
    open override func pixelToValues(_ pixel: inout CGPoint)
    {
        pixel = pixel.applying(pixelToValueMatrix)
        pixel = antiLogValueFor(point: pixel)
    }
    
    /// - returns: The x and y values in the chart at the given touch point
    /// (encapsulated in a CGPoint). This method transforms pixel coordinates to
    /// coordinates / values in the chart.
    open override func valueForTouchPoint(_ point: CGPoint) -> CGPoint
    {
        return antiLogValueFor(point: point.applying(pixelToValueMatrix))
    }
    
    /// - returns: The x and y values in the chart at the given touch point
    /// (x/y). This method transforms pixel coordinates to
    /// coordinates / values in the chart.
    open override func valueForTouchPoint(x: CGFloat, y: CGFloat) -> CGPoint
    {
        return antiLogValueFor(point: CGPoint(x: x, y: y).applying(pixelToValueMatrix))
    }
    
    open func logValueFor(point: CGPoint) -> CGPoint {
        let x = isYaxisLogScale ? ChartUtils.biSymmetricLogTransformation(base: base, x: point.x) : point.x
        let y = isXaxisLogScale ? ChartUtils.biSymmetricLogTransformation(base: base, x: point.y) : point.y
        return CGPoint(x: x, y: y)
    }
    
    open func antiLogValueFor(point: CGPoint) -> CGPoint {
        let x = isYaxisLogScale ? ChartUtils.biSymmetricAntiLogTransformation(base: base, y: point.x) : point.x
        let y = isXaxisLogScale ? ChartUtils.biSymmetricAntiLogTransformation(base: base, y: point.y) : point.y
        return CGPoint(x: x, y: y)
    }
}
