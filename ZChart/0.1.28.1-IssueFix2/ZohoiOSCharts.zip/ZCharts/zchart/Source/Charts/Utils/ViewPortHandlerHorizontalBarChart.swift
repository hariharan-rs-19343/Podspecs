//
//  ViewPortHandlerHorizontalBarChart.swift
//  zchart
//
//  Created by Aravinth T on 09/01/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class ViewPortHandlerHorizontalBarChart : ViewPortHandler
{
    override open func limitTransAndScale(matrix: inout CGAffineTransform, content: CGRect?)
    {
       /* if !(self.chartViewBase?.xAxis.isInverted)!
        {
            super.limitTransAndScale(matrix: &matrix, content: content)
            return
        }*/
        
        // min scale-x is 1
        _scaleX = min(max(_minScaleX, matrix.a), _maxScaleX)
        
        // min scale-y is 1
        _scaleY = min(max(_minScaleY,  matrix.d), _maxScaleY)
        
        
        var width: CGFloat = 0.0
        var height: CGFloat = 0.0
        
        if content != nil
        {
            width = content!.width
            height = content!.height
        }
        
        let maxTransX = -width * (_scaleX - 1.0)
        _transX = min(max(matrix.tx, maxTransX - _transOffsetX), _transOffsetX)
        
        //let maxTransY = height * (_scaleY - 1.0)
        //_transY = max(min(matrix.ty, maxTransY + _transOffsetY), -_transOffsetY)
        
        let maxTransY = -height * (_scaleY - 1.0)
        _transY = min(max(matrix.ty, maxTransY - _transOffsetY), _transOffsetY)
        
        matrix.tx = _transX
        matrix.a = _scaleX
        matrix.ty = _transY
        matrix.d = _scaleY
        
    }
}
