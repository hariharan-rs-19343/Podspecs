//
//  TimeScale.swift
//  zchart
//
//  Created by Aravinth T on 11/01/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

extension Date {
    var millisecondsSince1970:Double {
        return  (self.timeIntervalSince1970 * 1000.0)
    }
    
    init(milliseconds:Int) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds) / 1000)
    }
}

extension Double{
    
    var millisecondsToYear:Double{
        return ceil(self/3.154e+10)
    }
    
    var millisecondsToQuarter:Double{
        return ceil(self/7.884e+9)
    }
    
    var millisecondsToMonth:Double{
        return ceil(self/2.628e+9)
    }
    
    var millisecondsToWeek:Double{
        return (ceil(self/8.64e+7)/7)
    }
    
    var millisecondsToDay:Double{
        return ceil(self/8.64e+7)
    }
    
    var millisecondsToHour:Double{
        return ceil(self/3.6e+6)
    }
    
    var millisecondsToMinute:Double{
        return ceil(self/60000)
    }
    
    var millisecondsToSecond:Double{
        return ceil(self/1000)
    }
    var millisecondsToNano:Double{
        return ceil(self*1000000)
    }
}

public enum TimeScaleType
{
    case Auto
    case Forced
}

open class TimeScale : ScaleTypeProtocol
{
    weak var axis:AxisBase? = nil
    
    weak var viewPortHandler:ViewPortHandler? = nil
    
    open var timeScaleType = TimeScaleType.Auto
    
    open var currentType:TimeScaleIntervalType = TimeScaleIntervalType.YEAR
    
    public func computeAxisValues(min: Double, max: Double, axis: AxisBase, chart: ChartViewBase) {
        
        self.axis = axis
        
        self.viewPortHandler = chart.viewPortHandler
        
        var yMin = min
        var yMax = max
        
        var dataMinValue:Double
        var dataMaxValue:Double
        
        guard (chart.data != nil)
        else { return }
        if axis.isKind(of: XAxis.self)
        {
            dataMinValue = (chart.data?.xMin)!
            dataMaxValue = (chart.data?.xMax)!
        }
        else{
            let axisIndex = (axis as! YAxis).axisIndex
            guard ( chart.data?._yAxisMinArray[axisIndex] != nil ),
                  ( chart.data?._yAxisMaxArray[axisIndex] != nil )
            else { return }
            dataMinValue = (chart.data?._yAxisMinArray[axisIndex])!
            dataMaxValue = (chart.data?._yAxisMaxArray[axisIndex])!
        }
        
        if yMin < TimeScale.getMinimumValue(value: dataMinValue, currentType: currentType)
        {
            yMin = TimeScale.getMinimumValue(value: dataMinValue, currentType: currentType)
        }
        else{
            yMin = TimeScale.getMinimumValue(value: yMin, currentType: currentType)
        }
        
        if yMax > TimeScale.getMaximumValue(value: dataMaxValue, currentType: currentType)
        {
            yMax = TimeScale.getMaximumValue(value: dataMaxValue, currentType: currentType)
        }
        else{
            yMax = TimeScale.getMaximumValue(value: yMax, currentType: currentType)
        }

        
        let range = abs(yMax - yMin)
        
        if axis.labelCount == 0 ||  range.isInfinite || range == 0 || dataMinValue == dataMaxValue || abs(dataMaxValue - dataMinValue).isInfinite
        {
            axis.entries = [Double]()
            axis.centeredEntries = [Double]()
            if range == 0 || dataMinValue == dataMaxValue
            {
                axis.entries.append(dataMinValue)
            }
            return
        }
           
        if timeScaleType == .Auto
        {
            currentType = TimeScale.getAutoIntervalType(timeDifference: range,yMin:yMin,yMax:yMax)
        }

        let tickList = getTicksList(min: yMin, max: yMax, chart: chart)
        
        axis.entries.removeAll(keepingCapacity: true)
        axis.entries.reserveCapacity(tickList.count)
        
        for val in tickList
        {
            if val == 0
            {
                axis.entries.append(axis.axisMinimum)
                continue
            }
            axis.entries.append(val)
        }
        
        
    }
    
    public static func getMinimumValue(value:Double,currentType:TimeScaleIntervalType) -> Double
    {
        let timeValue = value/1000
        
        let date = Date(timeIntervalSince1970: timeValue)
      
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(abbreviation: "UTC")!
        
        var components:DateComponents
        
        switch  currentType {
            
        case .YEAR:
            components = calendar.dateComponents([.year], from: date)

        case .ABSQUARTER:
            components = calendar.dateComponents([.year,.month], from: date)
            
            if components.month! % 3 == 0
            {
                    components.month = components.month! - 2
            }
            else if components.month! % 3 == 2
            {
                    components.month = components.month! - 1
            }
           
        case .ABSMONTH:
            components = calendar.dateComponents([.year,.month], from: date)
           
        case .ABSWEEK:
            components = calendar.dateComponents([.year,.month, .day, .weekOfYear, .yearForWeekOfYear], from: date)
            
            components = DateComponents(weekOfYear: (components.weekOfYear!), yearForWeekOfYear: components.yearForWeekOfYear)

        case .ABSDAY, .DATE:
            components = calendar.dateComponents([.year,.month, .day], from: date)
            
        case .ABSHOUR:
            components = calendar.dateComponents([.year,.month, .day, .hour], from: date)
            
        case .ABSMINUTE:
            components = calendar.dateComponents([.year,.month, .day, .hour, .minute], from: date)
            
        case .ABSSECOND, .DATETIME:
            components = calendar.dateComponents([.year,.month, .day, .hour, .minute, .second], from: date)
            
        case .ABSNANOSECOND:
            components = calendar.dateComponents([.year,.month, .day, .hour, .minute, .second, .nanosecond], from: date)
      
        default:
            components = calendar.dateComponents([.year,.month, .day, .hour], from: date)
           
        }
        
        guard let dateTime = calendar.date(from: components)
            else { return Double(date.millisecondsSince1970) }
        
        return Double(dateTime.millisecondsSince1970)
    }
    
    public static func getMaximumValue(value:Double,currentType:TimeScaleIntervalType) -> Double
    {
        let timeValue = value/1000
        
        let date = Date(timeIntervalSince1970: timeValue)
        
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(abbreviation: "UTC")!
        
        let minimumValue = TimeScale.getMinimumValue(value: value, currentType: currentType)
        
        if value <= minimumValue
        {
            return minimumValue
        }
        
        var components:DateComponents
        
        switch  currentType {
            
        case .YEAR:
            components = calendar.dateComponents([.year], from: date)
            
            components.year = components.year! + 1
        
        case .ABSQUARTER:
            components = calendar.dateComponents([.year,.month], from: date)
            
            if components.month! % 3 == 0
            {
                components.month = components.month! + 1
            }
            else if components.month! % 3 == 1
            {
                components.month = components.month! + 3
            }
            else if components.month! % 3 == 2
            {
                components.month = components.month! + 2
            }
            
        case .ABSMONTH:
            components = calendar.dateComponents([.year,.month], from: date)
            
            components.month = components.month! + 1
            
        case .ABSWEEK:
            components = calendar.dateComponents([.year,.month, .day, .weekOfYear, .yearForWeekOfYear], from: date)
            
            components = DateComponents(weekOfYear: (components.weekOfYear! + 1), yearForWeekOfYear: components.yearForWeekOfYear)
  
        case .ABSDAY, .DATE:
            components = calendar.dateComponents([.year,.month, .day], from: date)
            
            components.day = components.day! + 1
            
        case .ABSHOUR:
            components = calendar.dateComponents([.year,.month, .day, .hour], from: date)
            
            components.hour = components.hour! + 1
            
        case .ABSMINUTE:
            components = calendar.dateComponents([.year,.month, .day, .hour, .minute], from: date)
            
            components.minute = components.minute! + 1
            
        case .ABSSECOND,.DATETIME:
            components = calendar.dateComponents([.year,.month, .day, .hour, .minute, .second ], from: date)
            
            components.second = components.second! + 1
            
        case .ABSNANOSECOND:
            components = calendar.dateComponents([.year,.month, .day, .hour, .minute, .second, .nanosecond ], from: date)
            
            components.nanosecond = components.nanosecond! + (5000)

        default:
            components = calendar.dateComponents([.year,.month, .day, .hour], from: date)
            
            components.hour = components.hour! + 1
        }
        
        guard let dateTime = calendar.date(from: components)
            else { return Double(date.millisecondsSince1970) }
        
        return Double(dateTime.millisecondsSince1970)
    
    }
    
    static func getAutoIntervalType(timeDifference: Double,yMin:Double,yMax:Double) -> TimeScaleIntervalType
    {
        let absoluteTime = TimeScale.getAbsoluteTime(startDate: yMin, endDate: yMax)
        
        var intervalType:TimeScaleIntervalType = .YEAR
        
        if(absoluteTime.years > 1) && (absoluteTime.month >= 24){
            intervalType = .YEAR
        } else if(absoluteTime.month > 1) && (absoluteTime.day >= 58) {
            intervalType = .ABSMONTH
        }
        else if(absoluteTime.day > 1) && (absoluteTime.hour >= 48){
            intervalType = .DATE
        }
        else if(absoluteTime.hour > 1) && (absoluteTime.minute >= 120) {
            intervalType = .ABSHOUR
        }
        else if(absoluteTime.minute > 1) && (absoluteTime.seconds >= 120){
            intervalType = .ABSMINUTE
            
        } else {
            intervalType = .ABSSECOND
        }
       /* else if (absoluteTime.hour > 1) || (absoluteTime.minute > 1) || (absoluteTime.seconds > 0) {
            intervalType = .DATETIME
        }*/
        
        return intervalType
    }
    

    
    static func getAbsoluteTime(startDate:Double,endDate:Double) ->
        (years: Int, month: Int, day: Int, hour: Int, minute: Int, seconds: Int)
    {
        let startTime = startDate/1000
        let endTime = endDate/1000
        
        let startDate = Date(timeIntervalSince1970: startTime)
        let endDate = Date(timeIntervalSince1970: endTime)
        
        
        let years = endDate.interval(ofComponent: .year, fromDate: startDate)
        let month = endDate.interval(ofComponent: .month, fromDate: startDate)
        let day = endDate.interval(ofComponent: .day, fromDate: startDate)
        var hour = endDate.interval(ofComponent: .hour, fromDate: startDate)
        var minute = endDate.interval(ofComponent: .minute, fromDate: startDate)
        var seconds = endDate.interval(ofComponent: .second, fromDate: startDate)
        
        if day <= 1
        {
            let difference =  ChartUtils.doubleToIntSafeCast(value:endTime - startTime)
            seconds = difference
            minute = (difference / 60)
            hour = (difference / (60*60))
        }
        
        return (years, month, day, hour, minute, seconds)
    }
    
    
    /*func  getTickCount(yMin:Double,yMax:Double) -> Double {
        
        
        let labelCount = (self.axis?.labelCount)!
        
        let startTime = yMin/1000
        let endTime = yMax/1000
        
        let startDate = Date(timeIntervalSince1970: startTime)
        let endDate = Date(timeIntervalSince1970: endTime)
        
        let difference =  ChartUtils.doubleToIntSafeCast(value:endTime - startTime)
        
        let calculatedCount:Int
        
        switch  currentType {
        case .YEAR:
            calculatedCount =  endDate.interval(ofComponent: .year, fromDate: startDate)
            break
        case .ABSQUARTER:
            calculatedCount =  endDate.interval(ofComponent: .quarter, fromDate: startDate)
            break
        case .ABSMONTH:
            calculatedCount =  endDate.interval(ofComponent: .month, fromDate: startDate)
            break
        case .ABSWEEK:
            calculatedCount =  (endDate.interval(ofComponent: .day, fromDate: startDate) / 7)
            break
        case .ABSDAY:
            calculatedCount =  endDate.interval(ofComponent: .day, fromDate: startDate)
            break
        case .ABSHOUR:
            calculatedCount =  (difference / (60*60))
            break
        case .ABSMINUTE:
            calculatedCount =  (difference / 60)
            break
        case .ABSSECOND:
            calculatedCount =  difference
            break
        case .DATETIME:
            calculatedCount =  endDate.interval(ofComponent: .second, fromDate: startDate)
            break
        case .DATE:
            calculatedCount =  endDate.interval(ofComponent: .day, fromDate: startDate)
            break
            
        default:
            calculatedCount = labelCount
            
        }
        
        return Double(min(labelCount, calculatedCount))
        
        
    }*/
    
    
    func getTicksList(min: Double, max: Double,chart:ChartViewBase) -> [Double]
    {
        
        var tickList:[Double] = []
        
        let startTime = min/1000
        let endTime = max/1000
        
        guard (axis != nil)
        else {return tickList }
 
        let scaledValue = (axis?.isKind(of: XAxis.self))! ? Double(chart.viewPortHandler.scaleX) : Double(chart.viewPortHandler.scaleY)
        
        let rangeInView = (self.axis!.axisRange)/(scaledValue)
        
        let labelCount = Double((self.axis?.labelCount)!)
        
        let tickCount:Double
        
        var intervalToAdd = DateComponents()
        
        switch  currentType {
            
        case .YEAR:
            
            let diff  = rangeInView.millisecondsToYear
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.year = interval
            
            break
        case .ABSQUARTER:
            
            let diff  = rangeInView.millisecondsToQuarter
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.month = interval * 3
            
            break
        case .ABSMONTH:

            let diff  = rangeInView.millisecondsToMonth
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.month = interval
            
            break
        case .ABSWEEK:
            
            let diff  = rangeInView.millisecondsToWeek
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.weekOfYear = interval
            
            break
        case .ABSDAY, .DATE:
            
            let diff  = rangeInView.millisecondsToDay
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.day = interval
            
            break
        case .ABSHOUR:
            
            let diff  = rangeInView.millisecondsToHour
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.hour = interval
            
            break
        case .ABSMINUTE:
            let diff  = rangeInView.millisecondsToMinute
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.minute = interval
            
            break
        case .ABSSECOND, .DATETIME:
            let diff  = rangeInView.millisecondsToSecond
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.second = interval
            
            break
            
        case .ABSNANOSECOND:
            let diff  = rangeInView.millisecondsToNano
            
            tickCount = Double.minimum(labelCount, diff)
            
            let interval = tickCount > 0 ?  ChartUtils.doubleToIntSafeCast(value:round(Double(diff)/tickCount)) : 0
            
            intervalToAdd.nanosecond = interval
            
            break
            
        }
        
        let dataMin = TimeScale.getMinimumValue(value: (self.axis!.axisMinimum), currentType: currentType)
        
        var dateToAdd =  Date(timeIntervalSince1970: dataMin/1000)
        
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(abbreviation: "UTC")!

        while true
        {
            let dateToTimeStamp = (dateToAdd.timeIntervalSince1970)
            
            if dateToTimeStamp > endTime
            {
                break
            }
            
            if dateToTimeStamp >= startTime
            {
                tickList.append(dateToTimeStamp*1000)
                
                if tickCount == 0
                {
                    break
                }
            }
            
            // Create date from components
            guard let someDateTime = calendar.date(byAdding: intervalToAdd, to: dateToAdd)
            else { return tickList }//calendar.date(from: dateComponents)
            
            dateToAdd = someDateTime
        }
        
        
        
        /*   var formattedList:[String] = []
         
         var fullTime:[String] = []
         
         let dateFormatter = DateFormatter()
         
         dateFormatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
         
         for i in 0 ..< tickList.count
         {
         let newVal = self.axis?.valueFormatter?.stringForValue!(tickList[i], axis: self.axis, intervalType: currentType)
         formattedList.append(newVal!)
         
         let date = Date(timeIntervalSince1970:(tickList[i]/1000))
         fullTime.append(dateFormatter.string(from: date))
         
         }*/
        
        return tickList
    }
    
    func updateCurrentType(_ min: Double, _ max: Double) {
        
        currentType = TimeScale.getAutoIntervalType(timeDifference: max - min , yMin: min, yMax: max)
    }
    
    
}

@objc public enum TimeScaleIntervalType : Int
{
    case YEAR
    case ABSQUARTER
    case ABSMONTH
    case ABSWEEK
    case ABSDAY
    case ABSHOUR
    case ABSMINUTE
    case ABSSECOND
    case ABSNANOSECOND
    case DATETIME
    case DATE
}

extension Date {
    
    func interval(ofComponent comp: Calendar.Component, fromDate date: Date) -> Int {
        
        var currentCalendar = Calendar.current
        currentCalendar.timeZone = TimeZone(abbreviation: "UTC")!
        
        guard let start = currentCalendar.ordinality(of: comp, in: .era, for: date) else { return 0 }
        guard let end = currentCalendar.ordinality(of: comp, in: .era, for: self) else { return 0 }
        
        return end - start
    }
}
