//
//  Utils.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

open class ChartUtils
{
    fileprivate static var _defaultValueFormatter: IValueFormatter = ChartUtils.generateDefaultValueFormatter()
    
    struct Constants {
        static let minLabelCount = 2
        static let maxLabelCount = 100
    }
    
    internal struct Math
    {
        internal static let FDEG2RAD = CGFloat(Double.pi / 180.0)
        internal static let FRAD2DEG = CGFloat(180.0 / Double.pi)
        internal static let DEG2RAD = Double.pi / 180.0
        internal static let RAD2DEG = 180.0 / Double.pi
    }
    
    internal class func roundToNextSignificant(number: Double) -> Double
    {
        if number.isInfinite || number.isNaN || number == 0
        {
            return number
        }
        
        let d = ceil(log10(number < 0.0 ? -number : number))
        let pw = 1 -  ChartUtils.doubleToIntSafeCast(value:d)
        let magnitude = pow(Double(10.0), Double(pw))
        let shifted = round(number * magnitude)
        return shifted * pow(Double(10.0), -Double(pw))
    }
    
    internal class func decimals(_ number: Double) -> Int
    {
        if number.isNaN || number.isInfinite || number == 0.0
        {
            return 0
        }
        
        let i = roundToNextSignificant(number: Double(number))
        
        if i.isInfinite || i.isNaN
        {
            return 0
        }
        
        return  ChartUtils.doubleToIntSafeCast(value:ceil(-log10(i))) + 2
    }
    
    internal class func nextUp(_ number: Double) -> Double
    {
        if number.isInfinite || number.isNaN
        {
            return number
        }
        else
        {
            return number + Double.ulpOfOne
        }
    }
    
    /// Calculates the position around a center point, depending on the distance from the center, and the angle of the position around the center.
    open class func getPosition(center: CGPoint, dist: CGFloat, angle: CGFloat) -> CGPoint
    {
        return CGPoint(
            x: center.x + dist * cos(angle * Math.FDEG2RAD),
            y: center.y + dist * sin(angle * Math.FDEG2RAD)
        )
    }
    
    /// Rounds number to 3 digit
    open class func roundNumber(number: CGFloat) -> CGFloat
    {
        return round(1000*number)/1000
    }
    
    open class func doubleToIntSafeCast(value:Double) -> Int
    {
        if value.isNaN || value.isInfinite || value > Double(Int.max) || value < Double(Int.min)
        { return -1 }
        return  Int(value)
    }
    
    open class func logFor(base: CGFloat, x: CGFloat) -> CGFloat {
        let y = x.isZero || base.isZero ? 0.0 : log(abs(x)) / log(base)
        return x >= 0 ? y : -y
    }
    
    open class func antiLogFor(base: CGFloat, y: CGFloat) -> CGFloat {
        let val = pow(base, abs(y))
        return y >= 0 ? val : -val
    }
    
    open class func biSymmetricLogTransformation(base: CGFloat, x: CGFloat, c: CGFloat = 1.0) -> CGFloat {
        let absXOverC = abs(x / c)
        let logValue = logFor(base: base,x: c + absXOverC)
        let signX = x >= 0 ? 1.0 : -1.0
        return signX * logValue
    }
    
    open class func biSymmetricAntiLogTransformation(base: CGFloat, y: CGFloat, c: CGFloat = 1.0) -> CGFloat {
        let val = pow(base, abs(y)) - c
        return y >= 0 ? val : -val
    }
    
    open class func squareRoot(value: CGFloat) -> CGFloat {
        let val = sqrt(abs(value))
        return value >= 0 ? val : -val
    }
    
    open class func square(value: CGFloat) -> CGFloat {
        let val = value * value
        return value >= 0 ? val : -val
    }
    
    open class func scaleBoundToFit(bounds: CGSize, size: CGSize) -> CGFloat {
        let maxWidth = bounds.width
        let maxHeight = bounds.height
        let scaleX = maxWidth / size.width
        let scaleY = maxHeight / size.height
        return min(scaleX, scaleY)
    }
    
    open class func widthOfTheCricleFor(y: CGFloat, radius: CGFloat, centerYPoint: CGFloat) -> CGFloat? {
        if y > (radius + centerYPoint) || y < (centerYPoint - radius) {
            return nil
        }
        let distanceSquared = radius * radius - (y - centerYPoint) * (y - centerYPoint)
        return distanceSquared < 0 ? 0.0 : 2.0 * sqrt(distanceSquared)
    }
    
    open class func drawImage(
        context: CGContext,
        image: NSUIImage,
        x: CGFloat,
        y: CGFloat,
        size: CGSize)
    {
        var drawOffset = CGPoint()
        drawOffset.x = x - (size.width / 2)
        drawOffset.y = y - (size.height / 2)
        
        NSUIGraphicsPushContext(context)
        
        if image.size.width != size.width && image.size.height != size.height
        {
            let key = "resized_\(size.width)_\(size.height)"
            
            // Try to take scaled image from cache of this image
            var scaledImage = objc_getAssociatedObject(image, key) as? NSUIImage
            if scaledImage == nil
            {
                // Scale the image
                NSUIGraphicsBeginImageContextWithOptions(size, false, 0.0)
                
                image.draw(in: CGRect(origin: CGPoint(x: 0, y: 0), size: size))
                
                scaledImage = NSUIGraphicsGetImageFromCurrentImageContext()
                NSUIGraphicsEndImageContext()
                
                // Put the scaled image in a cache owned by the original image
                objc_setAssociatedObject(image, key, scaledImage, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            }
            
            scaledImage?.draw(in: CGRect(origin: drawOffset, size: size))
        }
        else
        {
            image.draw(in: CGRect(origin: drawOffset, size: size))
        }
        
        NSUIGraphicsPopContext()
    }
    
    open class func drawText(context: CGContext, text: String, point: CGPoint, align: NSTextAlignment, attributes: [NSAttributedString.Key : AnyObject]?)
    {
        drawText(context: context, text: text, point: point, align: align, attributes: attributes, constrainedWidth: -1)
    }
    
    open class func drawText(context: CGContext, text: String, point: CGPoint, align: NSTextAlignment, attributes: [NSAttributedString.Key : AnyObject]?, constrainedWidth: CGFloat)
    {
        var point = point
        
        var size = text.size(withAttributes: attributes)
        
        if constrainedWidth > -1 {
            size.width = constrainedWidth
        }
        
        if align == .center
        {
            point.x -= size.width / 2.0
        }
        else if align == .right
        {
            point.x -= size.width
        }
        
        let rect = CGRect(origin: point, size: size)
        
        NSUIGraphicsPushContext(context)
        
        (text as NSString).draw(in: rect, withAttributes: attributes)
        
        NSUIGraphicsPopContext()
    }
    
    open class func drawTextLayer(text: String, point: CGPoint, align: NSTextAlignment, attributes: [NSAttributedString.Key : AnyObject]?) -> CATextLayer
    {
        
        return drawTextLayer(text: text, point: point, align: align, attributes: attributes, constrainedToWidth: -1, truncationMode: .none)
        
    }
    
    open class func drawTextLayer(text: String, point: CGPoint, align: NSTextAlignment, attributes: [NSAttributedString.Key : AnyObject]?, constrainedToWidth: CGFloat, truncationMode: CATextLayerTruncationMode) -> CATextLayer
    {
        var point = point
        
        let size = text.size(withAttributes: attributes)
        
        if align == .center
        {
            point.x -= size.width / 2.0
        }
        else if align == .left
        {
            point.x -= size.width
        }
        
        
        let font = attributes![NSAttributedString.Key.font]!
        let color = attributes![NSAttributedString.Key.foregroundColor]!
        
        let frame = CGRect(x: point.x.isNaN ? 0.0 : point.x, y: point.y.isNaN ? 0.0 : point.y, width: size.width, height: size.height)
        
        let layer = CATextLayer()
        layer.string = text
        
        layer.frame = frame
        
        layer.alignmentMode = convertToCATextLayerAlignmentMode("center")
        layer.fontSize = font.pointSize
        layer.font = font
        layer.foregroundColor = color.cgColor
        layer.contentsScale = NSUIMainScreen()!.nsuiScale// UIScreen.main.scale
        layer.truncationMode = truncationMode
        
        if constrainedToWidth > -1 {
            let constrainedToSize = CGSize(width: constrainedToWidth, height: size.height)
            
            if align == .left {
                layer.frame = CGRect(origin: CGPoint(x: (point.x + size.width) - constrainedToWidth, y: point.y), size: constrainedToSize)
            }
            else if align == .center {
                layer.frame = CGRect(origin: CGPoint(x: (point.x + size.width / 2.0) - constrainedToWidth / 2.0, y: point.y), size: constrainedToSize)
            }
            else {
                layer.frame = CGRect(origin: point, size: constrainedToSize)
            }
        }
        
        return layer
    }
    
    open class func drawTextLayer(text: String, rect: CGRect, attributes: [NSAttributedString.Key : AnyObject]?, rotationAngle: Double = 0.0, anchorPoint: CGPoint = CGPoint(x: 0.5, y: 0.5)) -> CATextLayer {
        
        let font = attributes![NSAttributedString.Key.font]!
        let color = attributes![NSAttributedString.Key.foregroundColor]!
        
        let frame = rect
        
        let layer = CATextLayer()
        layer.string = text
        
        if rotationAngle.isZero {
            layer.frame = frame
        }
        else {
            let radians = rotationAngle * Math.FDEG2RAD
            layer.anchorPoint = anchorPoint
            layer.transform = CATransform3DMakeRotation( radians, 0, 0, 1)
            layer.frame = CGRect(origin: frame.origin, size: sizeOfRotatedRectangle(frame.size, radians: radians))
        }
        
        layer.alignmentMode = convertToCATextLayerAlignmentMode("center")
        layer.fontSize = font.pointSize
        layer.font = font
        layer.foregroundColor = color.cgColor
        layer.contentsScale = NSUIMainScreen()!.nsuiScale// UIScreen.main.scale
        
        return layer
    }
    
    internal class func translatedPointFor(angleRadians: CGFloat, point: CGPoint, knownTextSize: CGSize, anchor: CGPoint) -> CGPoint {
        
        let angleDegree = angleRadians * ChartUtils.Math.FRAD2DEG
        
        var translate = point
        
        let rotatedSize = sizeOfRotatedRectangle(knownTextSize, radians: angleRadians)

        translate.x -= rotatedSize.width * (anchor.x - 0.5)
//            translate.y -= rotatedSize.height * (anchor.y )

        if angleDegree > 0 && angleDegree <= 90
        {
            let angle = (90 + angleDegree) * ChartUtils.Math.FDEG2RAD
            
            let x = point.x + (knownTextSize.height/2) * cos(angle)
            
            translate.x += (point.x - x)
    
        }
        else if angleDegree > 90 && angleDegree <= 180
        {
            let angle = (360 - (180 - angleDegree + 90)) * ChartUtils.Math.FDEG2RAD
            
            let x = point.x + (knownTextSize.height/2) * cos(angle)
            
            let y = point.y + (knownTextSize.height) * sin(angle)
            
            translate.x += (point.x - x)
            translate.y += (point.y - y)

        }
        else if angleDegree > 180 && angleDegree <= 270
        {
            
            let x = point.x + (knownTextSize.width) * cos(angleRadians)
            
            let anotherAngle = (360 - (270-angleDegree)) * ChartUtils.Math.FDEG2RAD
            
            let x1 = x + (knownTextSize.height/2) * cos(anotherAngle)
            
            let y = point.y + (knownTextSize.width) * sin(angleRadians)
            
            let y1 = y + (knownTextSize.height) * sin(anotherAngle)
            
            translate.x += (point.x - x1)
            translate.y += (point.y - y1)
            
        }
        else if angleDegree > 270 && angleDegree < 360{
            
            let x = point.x + (knownTextSize.width) * cos(angleRadians)
            
            let anotherAngle = (90 - (90 - (angleDegree - 270))) * ChartUtils.Math.FDEG2RAD
            
            let x1 = x + (knownTextSize.height/2) * cos(anotherAngle)
            
            let y = point.y + (knownTextSize.width) * sin(angleRadians)
            
            translate.x -= (x1 - point.x)
            translate.y += (point.y - y)
        }
        
        return translate
    }
    
    open class func drawText(context: CGContext, text: String, point: CGPoint, attributes: [NSAttributedString.Key : AnyObject]?, anchor: CGPoint, angleRadians: CGFloat)
    {
        var drawOffset = CGPoint()
        
        NSUIGraphicsPushContext(context)
        
        if angleRadians != 0.0
        {
            let size = text.size(withAttributes: attributes)
            
            // Move the text drawing rect in a way that it always rotates around its center
            drawOffset.x = -size.width * 0.5
            drawOffset.y = -size.height * 0.5
            
            var translate = point
            
            // Move the "outer" rect relative to the anchor, assuming its centered
            if anchor.x != 0.5 || anchor.y != 0.5
            {
                let rotatedSize = sizeOfRotatedRectangle(size, radians: angleRadians)
                
                translate.x -= rotatedSize.width * (anchor.x - 0.5)
                translate.y -= rotatedSize.height * (anchor.y - 0.5)
            }
            
            context.saveGState()
            context.translateBy(x: translate.x, y: translate.y)
            context.rotate(by: angleRadians)
            
            (text as NSString).draw(at: drawOffset, withAttributes: attributes)
            
            context.restoreGState()
        }
        else
        {
            if anchor.x != 0.0 || anchor.y != 0.0
            {
                let size = text.size(withAttributes: attributes)
                
                drawOffset.x = -size.width * anchor.x
                drawOffset.y = -size.height * anchor.y
            }
            
            drawOffset.x += point.x
            drawOffset.y += point.y
            
            (text as NSString).draw(at: drawOffset, withAttributes: attributes)
        }
        
        NSUIGraphicsPopContext()
    }
    
    internal class func drawMultilineText(context: CGContext, text: String, knownTextSize: CGSize, point: CGPoint, attributes: [NSAttributedString.Key : AnyObject]?, constrainedToSize: CGSize, anchor: CGPoint, angleRadians: CGFloat)
    {
        var rect = CGRect(origin: CGPoint(), size: knownTextSize)
        
        NSUIGraphicsPushContext(context)
    
        if angleRadians != 0.0
        {
            let translate = translatedPointFor(angleRadians: angleRadians, point: point, knownTextSize: knownTextSize, anchor: anchor)
            
            context.saveGState()
            context.translateBy(x: translate.x, y: translate.y)
            context.rotate(by: angleRadians)
            
            (text as NSString).draw(with: rect, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: attributes, context: nil)
            
            
            context.restoreGState()
        }
        else
        {
            if anchor.x != 0.0 || anchor.y != 0.0
            {
                rect.origin.x = -knownTextSize.width * anchor.x
                rect.origin.y = -knownTextSize.height * anchor.y
            }
            
            rect.origin.x += point.x
            rect.origin.y += point.y
            
            (text as NSString).draw(with: rect, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: attributes, context: nil)
        }
        
        NSUIGraphicsPopContext()
    }
    
    internal class func horizontalDrawText(context: CGContext, text: String, knownTextSize: CGSize, point: CGPoint, attributes: [NSAttributedString.Key : AnyObject]?, constrainedToSize: CGSize, anchor: CGPoint, angleRadians: CGFloat)
    {
        var rect = CGRect(origin: CGPoint(), size: knownTextSize)
        
        var drawOffset = CGPoint()
        
        NSUIGraphicsPushContext(context)
        
        let angleDegree = angleRadians * ChartUtils.Math.FRAD2DEG
    
        if angleDegree != 0 && angleDegree != 360
        {
            let size = knownTextSize//text.size(withAttributes: attributes)
            
            // Move the text drawing rect in a way that it always rotates around its center
            drawOffset.x = -size.width * 0.5
            drawOffset.y = -size.height * 0.5
            
            var translate = point
            
            // Move the "outer" rect relative to the anchor, assuming its centered
            if anchor.x != 0.5 || anchor.y != 0.5
            {
                let rotatedSize = sizeOfRotatedRectangle(size, radians: angleRadians)
                
                translate.x -= rotatedSize.width * (anchor.x - 0.5)
                translate.y -= rotatedSize.height * (anchor.y - 0.5)
            }
            
            context.saveGState()
            context.translateBy(x: translate.x, y: translate.y)
            context.rotate(by: angleRadians)
            
            rect.origin = drawOffset
            
            (text as NSString).draw(with: rect, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: attributes, context: nil)
            
            context.restoreGState()
        }
        else
        {
            if anchor.x != 0.0 || anchor.y != 0.0
            {
                rect.origin.x = -knownTextSize.width * anchor.x
                rect.origin.y = -knownTextSize.height * anchor.y
            }
            
            rect.origin.x += point.x
            rect.origin.y += point.y
            
            (text as NSString).draw(with: rect, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: attributes, context: nil)
        }
        
        NSUIGraphicsPopContext()
    }
    
    internal class func drawMultilineText(context: CGContext, text: String, point: CGPoint, attributes: [NSAttributedString.Key : AnyObject]?, constrainedToSize: CGSize, anchor: CGPoint, angleRadians: CGFloat)
    {
        let rect = text.boundingRect(with: constrainedToSize, options: .usesLineFragmentOrigin, attributes: attributes, context: nil)
        drawMultilineText(context: context, text: text, knownTextSize: rect.size, point: point, attributes: attributes, constrainedToSize: constrainedToSize, anchor: anchor, angleRadians: angleRadians)
    }
    
    /// - returns: An angle between 0.0 < 360.0 (not less than zero, less than 360)
    internal class func normalizedAngleFromAngle(_ angle: CGFloat) -> CGFloat
    {
        var angle = angle
        
        while (angle < 0.0)
        {
            angle += 360.0
        }
        
        return angle.truncatingRemainder(dividingBy: 360.0)
    }
    
    fileprivate class func generateDefaultValueFormatter() -> IValueFormatter
    {
        let formatter = DefaultValueFormatter(decimals: 1)
        return formatter
    }
    
    /// - returns: The default value formatter used for all chart components that needs a default
    open class func defaultValueFormatter() -> IValueFormatter
    {
        return _defaultValueFormatter
    }
    
    internal class func sizeOfRotatedRectangle(_ rectangleSize: CGSize, degrees: CGFloat) -> CGSize
    {
        let radians = degrees * Math.FDEG2RAD
        return sizeOfRotatedRectangle(rectangleWidth: rectangleSize.width, rectangleHeight: rectangleSize.height, radians: radians)
    }
    
    internal class func sizeOfRotatedRectangle(_ rectangleSize: CGSize, radians: CGFloat) -> CGSize
    {
        return sizeOfRotatedRectangle(rectangleWidth: rectangleSize.width, rectangleHeight: rectangleSize.height, radians: radians)
    }
    
    internal class func sizeOfRotatedRectangle(rectangleWidth: CGFloat, rectangleHeight: CGFloat, degrees: CGFloat) -> CGSize
    {
        let radians = degrees * Math.FDEG2RAD
        return sizeOfRotatedRectangle(rectangleWidth: rectangleWidth, rectangleHeight: rectangleHeight, radians: radians)
    }
    
    internal class func sizeOfRotatedRectangle(rectangleWidth: CGFloat, rectangleHeight: CGFloat, radians: CGFloat) -> CGSize
    {
        return CGSize(
            width: abs(rectangleWidth * cos(radians)) + abs(rectangleHeight * sin(radians)),
            height: abs(rectangleWidth * sin(radians)) + abs(rectangleHeight * cos(radians))
        )
    }
    
    /// MARK: - Bridging functions
    
    internal class func bridgedObjCGetNSUIColorArray (swift array: [NSUIColor?]) -> [NSObject]
    {
        var newArray = [NSObject]()
        for val in array
        {
            if val == nil
            {
                newArray.append(NSNull())
            }
            else
            {
                newArray.append(val!)
            }
        }
        return newArray
    }
    
    internal class func bridgedObjCGetNSUIColorArray (objc array: [NSObject]) -> [NSUIColor?]
    {
        var newArray = [NSUIColor?]()
        for object in array
        {
            newArray.append(object as? NSUIColor)
        }
        return newArray
    }
    
    internal class func bridgedObjCGetStringArray (swift array: [String?]) -> [NSObject]
    {
        var newArray = [NSObject]()
        for val in array
        {
            if val == nil
            {
                newArray.append(NSNull())
            }
            else
            {
                newArray.append(val! as NSObject)
            }
        }
        return newArray
    }
    
    internal class func bridgedObjCGetStringArray (objc array: [NSObject]) -> [String?]
    {
        var newArray = [String?]()
        for object in array
        {
            newArray.append(object as? String)
        }
        return newArray
    }
    
    public static func longPressSound()
    {
//        let feedbackGenerator = UIImpactFeedbackGenerator(style: .heavy)
//        feedbackGenerator.impactOccurred()
        #if os(iOS)
        if #available(iOS 10.0, *) {
                    let feedbackGenerator = UIImpactFeedbackGenerator(style: .heavy)
                    feedbackGenerator.impactOccurred()
                } else {
                    // Fallback on earlier versions
                }
        #endif

    }
    
    internal static func constrainedWidthForDataLabel(chart: ChartViewBase, rect: CGRect, align: NSTextAlignment) -> CGFloat {
        
        var constrainedWidth = -1.0
        
        let viewPort = chart._viewPortHandler.contentRect
        
        let xMin = align == .left ? rect.origin.x - rect.size.width : align == .center ? rect.origin.x - rect.size.width / 2.0 : rect.origin.x
        
        let xMax = align == .left ? rect.origin.x : align == .center ? rect.origin.x + rect.size.width / 2.0 : rect.origin.x + rect.size.width
        
        if xMin < viewPort.minX && xMax > viewPort.maxX {
            constrainedWidth = viewPort.width
        }
        else if xMin < viewPort.minX {
            constrainedWidth = rect.origin.x - viewPort.minX
        }
        else if xMax > viewPort.maxX {
            constrainedWidth = viewPort.maxX - rect.origin.x
        }
        
        return constrainedWidth
    }
    
    internal static func getOriginForLabel(chart: ChartViewBase, plotType: ChartType, isAboveBaseLine: Bool = true, rect: CGRect, alignDataLabelWithInViewPort: Bool, alignment: NSTextAlignment = .center, valueOffset: Double = 5.0, isStackedSum: Bool = false) -> CGPoint {
        
        var translatedOrigin = rect.origin
        
        if BarHelperFunctions.typeAllowed.contains(plotType) {
            
            if let barPlotOption = chart.getPlotOptions(type: plotType) as? BarPlotOptions {
                
                let valueTextSize = chart.isRotated ? rect.size.width : rect.size.height
                
                var labelPosition = barPlotOption.labelPosition
 
                if isStackedSum {
                    labelPosition = .bottom
                }
                else if barPlotOption.groupSpacePixel != 0 && !barPlotOption.isStacked || barPlotOption.groupSpacePixel == 0 && !barPlotOption.isStacked && labelPosition == .top {
                    labelPosition = .bottom
                }
                
                switch labelPosition {
                    case .top:
                        if chart.isRotated {
                            translatedOrigin.x += isAboveBaseLine ? -(valueTextSize + valueOffset) : valueOffset
                            translatedOrigin.y -= rect.size.height / 2.0
                        }
                        else {
                            translatedOrigin.x -= rect.size.width / 2.0
                            translatedOrigin.y += isAboveBaseLine ? valueOffset : -(valueTextSize + valueOffset)
                        }
                        break
                    case .bottom:
                        if chart.isRotated {
                            translatedOrigin.x += isAboveBaseLine ? valueOffset : -(valueTextSize + valueOffset)
                            translatedOrigin.y -= rect.size.height / 2.0
                        }
                        else {
                            translatedOrigin.x -= rect.size.width / 2.0
                            translatedOrigin.y += isAboveBaseLine ? -(valueTextSize + valueOffset) : valueOffset
                        }
                        break
                    case .center:
                        translatedOrigin.x -= rect.size.width / 2.0
                        translatedOrigin.y -= ((rect.size.height / 2.0) + valueOffset)
                        break
                }
            }
        }
        else if plotType == .Scatter || plotType == .LineRange || LineHelperFunctions.typeAllowed.contains(plotType) {
            translatedOrigin.x -= rect.size.width / 2.0
            translatedOrigin.y -= rect.size.height + valueOffset
        }
        else if plotType == .BubblePie {
            switch alignment {
                case .center:
                    translatedOrigin.x += rect.size.width / 2.0
                    break
                case .right:
                    translatedOrigin.x -= rect.size.width
                    break
                default: break
            }
            translatedOrigin.y -= rect.size.height / 2.0
        }
        else {
            translatedOrigin.x -= rect.size.width / 2.0
            translatedOrigin.y -= ((rect.size.height / 2.0) + valueOffset)
        }
        
        if alignDataLabelWithInViewPort {
            DataRenderer.alignDataLabel(chart: chart, translatedOrigin: &translatedOrigin, labelSize: rect.size )
        }
        
        return translatedOrigin
    }
    
    internal static func isAboveBaseLine(baseValue: Double, entryOrignalYValue: Double? = nil, value: Double, isAxisInverted: Bool) -> Bool {
        let entryOrignalYValue = entryOrignalYValue ?? value
        return value == baseValue ? entryOrignalYValue >= baseValue && !isAxisInverted || entryOrignalYValue >= baseValue && isAxisInverted : value > baseValue && !isAxisInverted || value < baseValue && isAxisInverted
    }
    
    internal static func valueOffsetFor(dataSet: IChartDataSet, plotOptions: IPlotOptions? = nil) -> Double {
        
        var valueOffset = 5.0
        
        switch dataSet.plotType {
            case .Scatter,.Line,.LineRange,.Area,.Radar:
                valueOffset = 2.0
                if let dataSetOptions = (dataSet.dataSetOptions as? AxisChartDataSetOptions), dataSetOptions.drawShapeEnabled  {
                    valueOffset += dataSetOptions.shapeProperties.size.width / 2.0 + dataSetOptions.shapeProperties.lineWidth / 2.0
                }
                break
            case .Bubble,.BubblePie, .HeatMap:
                valueOffset = 0.0
                break
            case .Bar, .HorizontalBarRange, .Mekko, .WaterFall, .Bullet, .BoxPlot:
                if (plotOptions as? BarPlotOptions)?.labelPosition == .center {
                    valueOffset = 0.0
                }
                break
            default: break
        }
        
        return valueOffset
    }
    
    internal static func getStackedSumLabelSize(barPlotOption: BarPlotOptions,sumValue: Double, entryX: Double) -> CGSize {
        
        let label = barPlotOption.stackSumValueFormatter.getFormattedValue?(stackSum: sumValue, entryX: entryX) ?? String(sumValue)
        return label.size(withAttributes: [NSAttributedString.Key.font: barPlotOption.stackSumValueFont])
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCATextLayerAlignmentMode(_ input: String) -> CATextLayerAlignmentMode {
    return CATextLayerAlignmentMode(rawValue: input)
}

extension ChartUtils{
    
    public static func cgPathToPoints(cgPath: CGPath) -> [CGPoint]{
        
        var points = [CGPoint]()
        
        for elements in cgPath.pathElements(){
            
            switch elements {

            case .moveToPoint(let point1): points.append(point1)
                            
            case .addLineToPoint(let point1): points.append(point1)
                            
            case .addCurveToPoint(let point1, let point2, let point3): points.append(contentsOf: [point1,point2,point3])
                            
            case .addQuadCurveToPoint(let point1, let point2): points.append(contentsOf: [point1,point2])
                            
            case .closeSubpath: break
                            
            }
            
        }
        
        /*for i in 0...1{

            if let xAxis = self.axis as? XAxis
            {
//                if i < 2{
                    points[i].x = xAxis.labelRotationAngle < 180 ? points[i].x - 1 : points[i].x + 1
//                }
//                else{
//                    points[i].x = xAxis.labelRotationAngle < 180 ? points[i].x + 1 : points[i].x - 1
//                }
            }

        }*/
        
        return points
    }
        
    public static func doPolygonsIntersect (polygonA: [CGPoint], polygonB: [CGPoint]){
        let polygons = [polygonA, polygonB];
            
        for polygon in polygons {
                
            var index1 = 0
                
            for points in polygon {
                    
                let index2 = (index1 + 1) % polygon.count
                    
                let p1 = points
                let p2 = polygon[index2]
                    
                let normal = CGPoint(x: p2.y - p1.y, y: p1.x - p2.x)
                    
                index1 += 1
                    
                let minMaxPointsA = getMinMaxPoints(polygon: polygonA,normal: normal)
                    
                let minMaxPointsB = getMinMaxPoints(polygon: polygonB,normal: normal)
                    
                if (minMaxPointsA.y < minMaxPointsB.x || minMaxPointsB.y < minMaxPointsA.x) {
                    print("============================")
                        
                    print("polygons does't intersect!")
                        
                    print("============================")
                    return
                }
            }
        }
            
        print("============================")
            
        print("polygons intersect each other")
            
        print("============================")
    }

    fileprivate class func getMinMaxPoints(polygon: [CGPoint],normal: CGPoint) -> CGPoint{
            
        var minPoint = Double.leastNormalMagnitude
            
        var maxPoint = Double.leastNormalMagnitude

        for polygon in polygon {
            let projected = normal.x * polygon.x + normal.y * polygon.y

            if (minPoint == .leastNormalMagnitude || Double(projected) <= minPoint) {
                minPoint = Double(projected)
            }
            if (maxPoint == .leastNormalMagnitude || Double(projected) >= maxPoint) {
                maxPoint = Double(projected)
            }
        }
            
        return CGPoint(x: minPoint, y: maxPoint)
        
    }
    
    public static func isRectFittedInCircle(radius: CGFloat, size: CGSize) -> Bool {
        
        let diameterOfRect = sqrt(size.width * size.width + size.height * size.height)
        
        if diameterOfRect <= 2 * radius {
            return true
        }
        
        return false
    }
}

extension CGPath {
    func pathElements() -> [PathElement] {
        
        var result = [PathElement]()

        if #available(iOS 11.0, *) {
            self.applyWithBlock { (elementPointer) in
                let element = elementPointer.pointee
                switch element.type {
                case .moveToPoint:
                    let points = Array(UnsafeBufferPointer(start: element.points, count: 1))
                    let el = PathElement.moveToPoint(points[0])
                    result.append(el)
                case .addLineToPoint:
                    let points = Array(UnsafeBufferPointer(start: element.points, count: 1))
                    let el = PathElement.addLineToPoint(points[0])
                    result.append(el)
                case .addQuadCurveToPoint:
                    let points = Array(UnsafeBufferPointer(start: element.points, count: 2))
                    let el = PathElement.addQuadCurveToPoint(points[0], points[1])
                    result.append(el)
                case .addCurveToPoint:
                    let points = Array(UnsafeBufferPointer(start: element.points, count: 3))
                    let el = PathElement.addCurveToPoint(points[0], points[1], points[2])
                    result.append(el)
                case .closeSubpath:
                    result.append(.closeSubpath)
                @unknown default:
                    fatalError()
                }
            }
        } else {
            // Fallback on earlier versions
        }
        
        return result
    }
    
    public enum PathElement {

        case moveToPoint(CGPoint)
        case addLineToPoint(CGPoint)
        case addQuadCurveToPoint(CGPoint, CGPoint)
        case addCurveToPoint(CGPoint, CGPoint, CGPoint)
        case closeSubpath

    }

}
