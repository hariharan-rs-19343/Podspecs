//
//  ShapeFactory.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 23/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

@objc
public protocol ShapeFactoryDataSource
{
    @objc optional func shapePath(point:CGPoint,shapeInstance:ShapeProperties,shapeLayer:CAShapeLayer) -> CGMutablePath
    @objc optional func limitLineShapePath(shapeFrame:CGRect,chartLimitLine:ChartLimitLine) -> CGMutablePath
    @objc optional func shapePath(frame: CGRect, shapeInstance: ShapeProperties, entry: Any?, shapeLayer: CAShapeLayer) -> CGMutablePath
    @objc optional func updateShapeProperties(frame:CGRect, shapeInstance: ShapeProperties, entry: Any?)
}

public enum LineShapes
{
    case square
    case Rect
    case circle
    case triangle
    case cross
    case x
    case line
    case lineVertical
    
    case needleClock
    case needleSharp
    case needleRound
    
    case Default
    case custom
    
    case leftArrow
    case rightArrow
    case topArrow
    case bottomArrow
    
    case thumbNail
    case thumbNailVertical
}

open class ShapeFactory
{
    
    public static func getPath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath
    {
        switch shapeInstance.shapeType
        {
        case .circle:
            return getCirclePath(point:point,shapeInstance:shapeInstance)
        case .square:
            return getSquarePath(point:point,shapeInstance:shapeInstance)
        case .triangle:
            return getTrianglePath(point:point,shapeInstance:shapeInstance)
        case .x:
            return getXPath(point:point,shapeInstance:shapeInstance)
        case .line:
            return getLinePath(point:point,shapeInstance:shapeInstance,isVertical: false)
        case .lineVertical:
            return getLinePath(point:point,shapeInstance:shapeInstance,isVertical: true)
        case .needleClock:
            return getClockPath(point:point,shapeInstance:shapeInstance)
        case .leftArrow,.rightArrow:
            var xPoint = point.x + shapeInstance.padding
            let arrowSize = shapeInstance.size.width - (shapeInstance.padding * 2.0)
            shapeInstance.polarRadius = arrowSize
            if shapeInstance.shapeType == .leftArrow {
                xPoint += arrowSize
                shapeInstance.polarAngle = 180
            }
            else {
                shapeInstance.polarAngle = 0
            }
            
            return getArrowPath(point: CGPoint(x: xPoint, y: point.y + (shapeInstance.size.height / 2.0)), shapeInstance: shapeInstance)
        case .topArrow,.bottomArrow:
            var yPoint = point.y + shapeInstance.padding
            let arrowSize = shapeInstance.size.height - (shapeInstance.padding * 2.0)
            shapeInstance.polarRadius = arrowSize
            if shapeInstance.shapeType == .bottomArrow {
                shapeInstance.polarAngle = 90
            }
            else {
                shapeInstance.polarAngle = 270
                yPoint += arrowSize
            }
            
            return getArrowPath(point: CGPoint(x: point.x  + (shapeInstance.size.width / 2.0), y: yPoint), shapeInstance: shapeInstance)
        case .thumbNail:
            return getThumpNail(point:point,shapeInstance:shapeInstance,isVertical: false)
        case .thumbNailVertical:
            return getThumpNail(point:point,shapeInstance:shapeInstance,isVertical: true)
        case .Rect:
            return CGMutablePath(rect: CGRect(origin: CGPoint(x: point.x - shapeInstance.size.width / 2.0, y: point.y - shapeInstance.size.height / 2.0), size: shapeInstance.size), transform: nil)
        default:
            return CGMutablePath()
        }
    }
    
    public static func getLinePath(point:CGPoint,shapeInstance:ShapeProperties,isVertical:Bool) -> CGPath
    {
        let path = CGMutablePath()
        
        let shapeSize = shapeInstance.size.width
        let shapeHalf = shapeSize / 2.0
        
        var startPoint = CGPoint(x: point.x - shapeHalf, y: point.y)
        var endPoint = CGPoint(x: startPoint.x + shapeSize, y: point.y)
        
        if isVertical
        {
            startPoint = CGPoint(x: point.x , y: point.y - shapeHalf)
            endPoint = CGPoint(x: point.x, y: startPoint.y + shapeSize)
        }
        
        path.move(to: startPoint)
        path.addLine(to: endPoint)
        path.closeSubpath()
        
        return path

        
    }
    
    
    public static func getSquarePath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath
    {
        let path = CGMutablePath()
        
        let shapeSize = shapeInstance.size.width
        let shapeHalf = shapeSize / 2.0
   
            let x = point.x - shapeHalf
            let y = point.y - shapeHalf
            let width = shapeSize
            let height = shapeSize
            
            path.move(to: CGPoint(x: x, y: y))
            path.addLine(to: CGPoint(x: x+width, y: y))
            path.addLine(to: CGPoint(x: x+width, y: y+height))
            path.addLine(to: CGPoint(x: x, y: y+height))
            path.closeSubpath()

        return path
        
    }
    
    public static func getCirclePath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath
    {
        let path = CGMutablePath()
        
        let shapeSize = shapeInstance.size.width
        let shapeHalf = shapeSize / 2.0
        
//        let circlePath = UIBezierPath(arcCenter: CGPoint(x: point.x,y: point.y), radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat(M_PI * 2), clockwise: true)
//
//        path.addPath(circlePath.cgPath)
        
        path.addArc(center: CGPoint(x: point.x,y: point.y), radius: shapeHalf, startAngle: CGFloat(0), endAngle: CGFloat(Double.pi * 2), clockwise: true)
        
        return path
        
    }
    
    public static func getClockPath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath
     {
            let path = CGMutablePath()
           
            let shapeSize = shapeInstance.size.width
            let shapeHalf = shapeSize / 2.0
            
//            let circlePath = UIBezierPath(arcCenter: point, radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat(Double.pi * 2), clockwise: true)
         
            let circlePath = CGMutablePath()
            circlePath.addArc(center: point, radius: shapeHalf, startAngle: CGFloat(0), endAngle: CGFloat(Double.pi * 2), clockwise: true)
        
            path.addPath(circlePath)
            path.addPath(getArrowPath(point: point, shapeInstance: shapeInstance))

            return path
     }
    
    public static func getArrowPath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath {
        
        let path = CGMutablePath()
        
        guard let angle = shapeInstance.polarAngle,
        let distance = shapeInstance.polarRadius
        else { return path }
        
        let linePath = CGMutablePath()
        
        linePath.move(to: point)
    
        let lineEndPoint = ChartUtils.getPosition(center: point, dist: distance, angle: angle)

        linePath.addLine(to: lineEndPoint)
    
        let arrowPath = CGMutablePath()
    
        let rightArrowAngle = (angle + 135) > 360 ? (angle + 135) - 360 : (angle + 135)
    
        let leftArrowAngle = (rightArrowAngle + 90) > 360 ? (rightArrowAngle + 90) - 360 : (rightArrowAngle + 90)
    
        arrowPath.move(to: lineEndPoint)
    
        arrowPath.addLine(to: ChartUtils.getPosition(center: lineEndPoint, dist: distance * 0.2, angle: rightArrowAngle ))
    
        arrowPath.move(to: lineEndPoint)
    
        arrowPath.addLine(to: ChartUtils.getPosition(center: lineEndPoint, dist: distance * 0.2, angle: leftArrowAngle ))
        
        path.addPath(linePath)
        path.addPath(arrowPath)
        
        return path
    }
    
    public static func getTrianglePath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath
    {
        let path = CGMutablePath()
        
        let shapeSize = shapeInstance.size.width
        let shapeHalf = shapeSize / 2.0
        
        let x = point.x - shapeHalf
        let y = point.y - shapeHalf
        let width = shapeSize
        let height = shapeSize
        
        path.move(to: CGPoint(x: x, y: y+height))
        path.addLine(to: CGPoint(x: x+(width/2), y: y))
        path.addLine(to: CGPoint(x: x+width, y: y+height))
        path.addLine(to: CGPoint(x: x, y: y+height))
        path.closeSubpath()
        
        return path
        
    }
    
    public static func getXPath(point:CGPoint,shapeInstance:ShapeProperties) -> CGPath
    {
        let path = CGMutablePath()
        
        let shapeSize = shapeInstance.size.width
        let shapeHalf = shapeSize / 2.0
        
        let x = point.x - shapeHalf
        let y = point.y - shapeHalf
        let width = shapeSize
        let height = shapeSize
        
        path.move(to: CGPoint(x: x, y: y))
        path.addLine(to: CGPoint(x: x+width, y: y+height))
        path.move(to: CGPoint(x: x, y: y+height))
        path.addLine(to: CGPoint(x: x+width, y: y))
        
        return path
        
    }
    
    public static func getThumpNail(point:CGPoint,shapeInstance:ShapeProperties, isVertical: Bool) -> CGPath {
        
        let path = CGMutablePath()
        
        var shapeSize = shapeInstance.size.height
        let shapeHalf = shapeSize / 2.0
        shapeSize -= shapeInstance.size.width
        
        var origin = CGPoint(x: point.x , y: point.y - shapeHalf)
        var endPoint = CGPoint(x: point.x, y: origin.y + shapeSize)
        var circleMidPoint = CGPoint(x: endPoint.x, y: endPoint.y + shapeInstance.size.width / 2.0)
        
        if isVertical
        {
            endPoint = CGPoint(x: point.x + shapeHalf, y: point.y)
            origin = CGPoint(x: endPoint.x - shapeSize, y: point.y)
            circleMidPoint = CGPoint(x: origin.x - shapeInstance.size.width / 2.0, y: origin.y)
        }
        
        path.move(to: origin)
        path.addLine(to: endPoint)
        
        path.addPath(getCirclePath(point: circleMidPoint, shapeInstance: shapeInstance))
        
        path.closeSubpath()
        
        return path
    }
    
    
    
}
