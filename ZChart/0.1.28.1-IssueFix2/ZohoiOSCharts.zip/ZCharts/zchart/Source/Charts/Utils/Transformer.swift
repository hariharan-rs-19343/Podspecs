//
//  Transformer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

/// Transformer class that contains all matrices and is responsible for transforming values into pixels on the screen and backwards.
@objc(ChartTransformer)
open class Transformer: NSObject
{
    /// matrix to map the values to the screen pixels
    internal var _matrixValueToPx = CGAffineTransform.identity

    /// matrix for handling the different offsets of the chart
    internal var _matrixOffset = CGAffineTransform.identity

    internal var _viewPortHandler: ViewPortHandler

    public required init(viewPortHandler: ViewPortHandler)
    {
        _viewPortHandler = viewPortHandler
    }
    
    open func resetMatrices()
    {
        _matrixOffset = CGAffineTransform.identity
        _matrixValueToPx = CGAffineTransform.identity
    }

    /// Prepares the matrix that transforms values to pixels. Calculates the scale factors from the charts size and offsets.
    open func prepareMatrixValuePx(chartXMin: Double, deltaX: CGFloat, deltaY: CGFloat, chartYMin: Double)
    {
        var scaleX = (_viewPortHandler.contentWidth / deltaX)
        var scaleY = (_viewPortHandler.contentHeight / deltaY)
        
        if CGFloat.infinity == scaleX
        {
            scaleX = 0.0
        }
        if CGFloat.infinity == scaleY
        {
            scaleY = 0.0
        }
        
        // setup all matrices
        _matrixValueToPx = CGAffineTransform.identity
        
        if (self._viewPortHandler.chartViewBase?.xAxis.isInverted)! // X axis - inverted
        {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: -scaleX, y: -scaleY)
//            _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: CGFloat(-chartYMin))
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: -(CGFloat(chartXMin) + deltaX), y: CGFloat(-chartYMin))
        }
        else
        {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: scaleX, y: -scaleY)
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: CGFloat(-chartYMin))
        }
    }
    
    /// Prepares the matrix that transforms values to pixels. Calculates the scale factors from the charts size and offsets.
    open func prepareMatrixValuePxforPlot(chartXMin: Double, deltaX: CGFloat, deltaY: CGFloat, chartYMin: Double)
    {
        var scaleX = (_viewPortHandler.contentWidth / deltaX)
        var scaleY = (_viewPortHandler.contentHeight / deltaY)
        
        if CGFloat.infinity == scaleX
        {
            scaleX = 0.0
        }
        if CGFloat.infinity == scaleY
        {
            scaleY = 0.0
        }
        
        // setup all matrices
        _matrixValueToPx = CGAffineTransform.identity
        
        if (self._viewPortHandler.chartViewBase?.xAxis.isInverted)! // X axis - inverted
        {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: -scaleX, y: -scaleY)
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: -(CGFloat(chartXMin) + deltaX), y: CGFloat(-chartYMin))
        }
        else
        {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: scaleX, y: scaleY)
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: CGFloat(-chartYMin))
        }
    }
    
    /// Prepares the matrix that contains all offsets.
    open func prepareMatrixOffset(inverted: Bool)
    {
        if !inverted // Y axis - not inverted
        {
//            _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
            
            if (self._viewPortHandler.chartViewBase?.xAxis.isInverted)! // X axis - inverted
            {
//                _matrixOffset = CGAffineTransform(translationX: (_viewPortHandler.chartWidth - _viewPortHandler.offsetRight), y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
                _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
            }
            else
            {
                _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
            }
        }
        else
        {
//            _matrixOffset = CGAffineTransform(scaleX: 1.0, y: -1.0)
//            _matrixOffset = _matrixOffset.translatedBy(x: _viewPortHandler.offsetLeft, y: -_viewPortHandler.offsetTop)
            
            if (self._viewPortHandler.chartViewBase?.xAxis.isInverted)!
            {
                _matrixOffset = CGAffineTransform(scaleX: 1.0, y: -1.0)
//                _matrixOffset = _matrixOffset.translatedBy(x: (_viewPortHandler.chartWidth - _viewPortHandler.offsetRight), y: -_viewPortHandler.offsetTop)
                _matrixOffset = _matrixOffset.translatedBy(x: (_viewPortHandler.offsetLeft), y: -_viewPortHandler.offsetTop)
            }
            else
            {
                _matrixOffset = CGAffineTransform(scaleX: 1.0, y: -1.0)
                _matrixOffset = _matrixOffset.translatedBy(x: _viewPortHandler.offsetLeft, y: -_viewPortHandler.offsetTop)
            }
            
        }
    }

    
    /// Transform an array of points with all matrices.
    // VERY IMPORTANT: Keep matrix order "value-touch-offset" when transforming.
    open func pointValuesToPixel(_ points: inout [CGPoint])
    {
        let trans = valueToPixelMatrix
        for i in 0 ..< points.count
        {
            points[i] = points[i].applying(trans)
        }
    }
    
    open func pointValueToPixel(_ point: inout CGPoint)
    {
        point = point.applying(valueToPixelMatrix)
    }
    
    open func xPointValueToPixel(_ x: inout CGFloat)
    {
        x = CGPoint(x: x, y: 0).applying(valueToPixelMatrix).x
    }
    
    open func yPointValueToPixel(_ y: inout CGFloat)
    {
        y = CGPoint(x: 0, y: y).applying(valueToPixelMatrix).y
    }
    
    open func pixelForValues(x: Double, y: Double, isOriginal: Bool = true) -> CGPoint
    {
        return CGPoint(x: x, y: y).applying(valueToPixelMatrix)
    }
    
    /// Transform a rectangle with all matrices.
    open func rectValueToPixel(_ r: inout CGRect)
    {
        r = r.applying(valueToPixelMatrix)
    }
    
    /// Transform a rectangle with all matrices with potential animation phases.
    open func rectValueToPixel(_ r: inout CGRect, phaseY: Double)
    {
        // multiply the height of the rect with the phase
        var bottom = r.origin.y + r.size.height
        bottom *= CGFloat(phaseY)
        let top = r.origin.y * CGFloat(phaseY)
        r.size.height = bottom - top
        r.origin.y = top

        r = r.applying(valueToPixelMatrix)
    }
    
    /// Transform a rectangle with all matrices.
    open func rectValueToPixelHorizontal(_ r: inout CGRect)
    {
        r = r.applying(valueToPixelMatrix)
    }
    
    /// Transform a rectangle with all matrices with potential animation phases.
    open func rectValueToPixelHorizontal(_ r: inout CGRect, phaseY: Double)
    {
        // multiply the height of the rect with the phase
        let left = r.origin.x * CGFloat(phaseY)
        let right = (r.origin.x + r.size.width) * CGFloat(phaseY)
        r.size.width = right - left
        r.origin.x = left
        
        r = r.applying(valueToPixelMatrix)
    }

    /// transforms multiple rects with all matrices
    open func rectValuesToPixel(_ rects: inout [CGRect])
    {
        let trans = valueToPixelMatrix
        
        for i in 0 ..< rects.count
        {
            rects[i] = rects[i].applying(trans)
        }
    }
    
    /// Transforms the given array of touch points (pixels) into values on the chart.
    open func pixelsToValues(_ pixels: inout [CGPoint])
    {
        let trans = pixelToValueMatrix
        
        for i in 0 ..< pixels.count
        {
            pixels[i] = pixels[i].applying(trans)
        }
    }
    
    /// Transforms the given touch point (pixels) into a value on the chart.
    open func pixelToValues(_ pixel: inout CGPoint)
    {
        pixel = pixel.applying(pixelToValueMatrix)
    }
    
    /// - returns: The x and y values in the chart at the given touch point
    /// (encapsulated in a CGPoint). This method transforms pixel coordinates to
    /// coordinates / values in the chart.
    open func valueForTouchPoint(_ point: CGPoint) -> CGPoint
    {
        return point.applying(pixelToValueMatrix)
    }
    
    /// - returns: The x and y values in the chart at the given touch point
    /// (x/y). This method transforms pixel coordinates to
    /// coordinates / values in the chart.
    open func valueForTouchPoint(x: CGFloat, y: CGFloat) -> CGPoint
    {
        return CGPoint(x: x, y: y).applying(pixelToValueMatrix)
    }
    
    open var valueToPixelMatrix: CGAffineTransform
    {
        return
            _matrixValueToPx.concatenating(_viewPortHandler.touchMatrix
                ).concatenating(_matrixOffset
        )
    }
    
    open var pixelToValueMatrix: CGAffineTransform
    {
        return valueToPixelMatrix.inverted()
    }
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = type(of: self).init(viewPortHandler: _viewPortHandler)
        copy._matrixOffset = _matrixOffset
        copy._matrixValueToPx = _matrixValueToPx
        return copy
    }
}

///  Enum that specifies the axis a DataSet should be plotted against, either Left or Right.
@objc
public enum AngleDependency: Int
{
    case xAxis
    case yAxis
}

open class PolarTransformer:Transformer
{
    var xScaleRange:CGFloat = 0
    
    var yScaleRange:CGFloat = 0
    
    var startAngle:CGFloat = 0
    
    var centerPoint:CGPoint = CGPoint()
    
    var radius:CGFloat = 0
    
    var direction:SliceDirection = .clockwise
    
    var angleAxisDependency:AngleDependency = .xAxis
    
    public init(xScaleRange: CGFloat, yScaleRange:CGFloat, startAngle:CGFloat, centerPoint:CGPoint, radius:CGFloat, viewPortHandler: ViewPortHandler)
    {
        super.init(viewPortHandler: viewPortHandler)
        self.xScaleRange = xScaleRange
        self.yScaleRange = yScaleRange
        self.startAngle = startAngle
        self.centerPoint = centerPoint
        self.radius = radius
    }
    
    public required init(viewPortHandler: ViewPortHandler) {
        super.init(viewPortHandler: viewPortHandler)
    }
    
    /// Prepares the matrix that transforms values to pixels. Calculates the scale factors from the charts size and offsets.
    open override func prepareMatrixValuePx(chartXMin: Double, deltaX: CGFloat, deltaY: CGFloat, chartYMin: Double)
    {
        var scaleX = (xScaleRange / deltaX)
        var scaleY = (yScaleRange / deltaY)
        
        if CGFloat.infinity == scaleX
        {
            scaleX = 0.0
        }
        if CGFloat.infinity == scaleY
        {
            scaleY = 0.0
        }
        
        // setup all matrices
        _matrixValueToPx = CGAffineTransform.identity
        
        if (self._viewPortHandler.chartViewBase?.xAxis.isInverted)! // X axis - inverted
        {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: -scaleX, y: -scaleY)
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: -(CGFloat(chartXMin) + deltaX), y: CGFloat(-chartYMin))
        }
        else
        {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: scaleX, y: scaleY)
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: CGFloat(-chartYMin))
        }
    }
    
    /// returns width for the given value
    open func rangeForValue(yValue:Double) -> CGFloat
    {
        return pixelForValues(x: 0, y: yValue).y
    }
    
    /// returns angle in chart for the given value
    open func absoluteAngleForValue(value:Double) -> CGFloat
    {
        let range = pixelForValues(x: value, y: value)
        
        if angleAxisDependency == .xAxis
        {
            return getAbsoluteAngleForGivenAngle(angle: range.x)
        }
        else{
            return getAbsoluteAngleForGivenAngle(angle: range.y)
        }
        
    }
    
    internal func getAbsoluteAngleForGivenAngle(angle:CGFloat) -> CGFloat
    {
        var angle = angle
        
        if direction == .clockwise
        {
            angle = angle +  self.startAngle

            if angle >= 360
            {
                angle -= 360
            }
        }
        else{
            angle = self.startAngle - angle
            
            if angle < 0
            {
                angle = 360 + angle
            }
        }
        return angle
    }
    
    open func pixelForPolarValues(x:Double,y:Double, isOriginal: Bool = true) -> CGPoint
    {
        let transformerPoint = pixelForValues(x: x, y: y, isOriginal: isOriginal)
        
        let (xVal,yVal) = (transformerPoint.x,transformerPoint.y)
        
        var angle:CGFloat = 0
        var radius:CGFloat = 0
        
        if angleAxisDependency == .xAxis
        {
            angle = getAbsoluteAngleForGivenAngle(angle: xVal)
            radius = yVal
        }
        else{
            angle = getAbsoluteAngleForGivenAngle(angle: yVal)
            radius = xVal
        }
        
        return ChartUtils.getPosition(center: self.centerPoint, dist: radius, angle: angle)
    }
    
    open func polarValuesForPixel(x:CGFloat,y:CGFloat) -> CGPoint
    {
        let newPoint = CGPoint(x: ChartUtils.roundNumber(number: x), y: ChartUtils.roundNumber(number: y))
        
        let angle = atan2(newPoint.y - centerPoint.y , newPoint.x - centerPoint.x)
        
        var finalAngle = ChartUtils.roundNumber(number: angle * ChartUtils.Math.FRAD2DEG)
        
        finalAngle = (finalAngle >= 0 && finalAngle <= 180) ? finalAngle : 360 + finalAngle
        
        finalAngle = (finalAngle - self.startAngle) < 0 ? 360 + (finalAngle - self.startAngle) : (finalAngle - self.startAngle)
        
        var values = CGPoint()
        
        if angleAxisDependency == .xAxis
        {
            values = CGPoint(x: finalAngle, y: PieHelperFunctions.distance(from: centerPoint, to: newPoint))
            
        }
        else{
            values = CGPoint(x: PieHelperFunctions.distance(from: centerPoint, to: newPoint), y: finalAngle )
        }
        
        values = (values.applying(pixelToValueMatrix))
        
        return CGPoint(x: ChartUtils.roundNumber(number: values.x), y: ChartUtils.roundNumber(number: values.y))
       
    }
    
    override open func valueForTouchPoint(x: CGFloat, y: CGFloat) -> CGPoint {
        return polarValuesForPixel(x: x, y: y)
    }
    
    override open func valueForTouchPoint(_ point: CGPoint) -> CGPoint {
        return polarValuesForPixel(x: point.x, y: point.y)
    }
    
    
    open override func prepareMatrixOffset(inverted: Bool) {
        
    }
}
