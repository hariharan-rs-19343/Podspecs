//
//  ShapeProperties.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 23/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

import Foundation

open class ShapeProperties:NSObject, Codable
{
    
    open var shapeType:LineShapes = LineShapes.Default
    
    weak open var customPathDataSource:ShapeFactoryDataSource? = nil
    
    @available(*, deprecated, message: "use size property instead of shapeSize")
    open var shapeSize = CGFloat(10.0)
    
    open var size: CGSize = CGSize(width: 10.0, height: 10.0)
    
    open var lineWidth = CGFloat(1.0)
    
    open var lineDashPhase = CGFloat(0.0)
    
    open var lineDashLengths: [CGFloat]?
    
    open var lineCapType = CGLineCap.round
    
    open var holeColor:NSUIColor? = NSUIColor.white
    
    open var strokeColor:NSUIColor? = NSUIColor.black
    
    open var polarAngle:CGFloat? = nil
    
    open var polarRadius:CGFloat? = nil
    
    open var padding:CGFloat = 0
    
    open var visible = true
    
    public override init() {
        
    }
    
    public init(type:LineShapes) {
        self.shapeType = type
    }
    
    open func resetProperties()
    {
        shapeType = LineShapes.circle
        
        shapeSize = CGFloat(10.0)
        
        size.width = 10.0
        size.height = 10.0
        
        lineWidth = CGFloat(1.0)
        
        lineDashPhase = CGFloat(0.0)
        
        lineDashLengths = nil
        
        lineCapType = CGLineCap.round
        
        holeColor = NSUIColor.white
        
        strokeColor = NSUIColor.black
        
        polarAngle = nil
        
        polarRadius = nil
        
        padding = 0
        
        visible = true
    }
    
    // MARK: - Codable
    
        enum CodingKeys: CodingKey {
                case fillAlpha
                case fillColor
                case lineDashPhase
                case size
                case strokeAlpha
                case strokeColor
                case strokeWidth
                case style
                case type
           }
    
    enum SizeKeys: CodingKey {
            case height
            case width
            
       }
    
        required convenience  public  init(from decoder: Decoder) throws {
            
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            let type = try container.decode(String.self, forKey: .type)
            
            var shapeType = LineShapes.circle
            if type == "LINE"
            {
                shapeType = .line
            }
            
            self.init(type: shapeType)
            
            let strokeAlpha = try (container.decode(CGFloat.self, forKey: .strokeAlpha))/255
            let fillAlpha = try (container.decode(CGFloat.self, forKey: .fillAlpha))/255
            
            let strokeColorCode = try container.decode(Int.self, forKey: .strokeColor)
            strokeColor = NSUIColor(rgb: strokeColorCode).withAlphaComponent(strokeAlpha)
            
            let holeColorCode = try container.decode(Int.self, forKey: .fillColor)
            holeColor = NSUIColor(rgb: holeColorCode).withAlphaComponent(fillAlpha)
            
            lineDashPhase = try container.decode(CGFloat.self, forKey: .lineDashPhase)
            
          //  shapeSize = try container.decode(CGFloat.self, forKey: .size)
            
            lineWidth = try container.decode(CGFloat.self, forKey: .strokeWidth)
            
            let sizeContainer = try container.nestedContainer(keyedBy: SizeKeys.self, forKey: .size)
            
            var height:CGFloat = 10
            var width:CGFloat = 10
            
            if sizeContainer.contains(.height)
            {
                if let value = try? sizeContainer.decode(CGFloat.self, forKey: .height)
                {
                    height = value
                }
                else{
                    height = CGFloat.nan
                }
            }
            
            if sizeContainer.contains(.width)
            {
                if let value = try? sizeContainer.decode(CGFloat.self, forKey: .width)
                {
                    width = value
                }
                else{
                    width = CGFloat.nan
                }
            }
            
            shapeSize = max(height, width)
            
            size.height = height
            size.width = width
        }
    
        public  func encode(to encoder: Encoder) throws {
  
        }
    
}
