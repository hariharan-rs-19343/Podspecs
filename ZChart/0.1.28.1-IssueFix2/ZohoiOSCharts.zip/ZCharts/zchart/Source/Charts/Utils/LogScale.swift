//
//  LogScale.swift
//  zchart
//
//  Created by Keerthivass B S on 22/05/24.
//

import Foundation

open class LogScale: LinearScale {
    
    open var Base: CGFloat = 10.0
    
    public override func computeAxisValues(min: Double, max: Double, axis: AxisBase, chart: ChartViewBase) {
        
        let interval = getInterval(chart: chart, axis: axis, range: abs(max - min), granularityEnabled: false)
        
        if interval >= 0.5 {
            super.computeAxisValues(min: min, max: max, axis: axis, chart: chart)
            
            for index in 0..<axis.entryCount {
                let antiLogValue = ChartUtils.biSymmetricAntiLogTransformation(base: Base, y: axis.entries[index])
                axis.entries[index] = antiLogValue == 0 ? antiLogValue : antiLogValue > 0 ? antiLogValue + 1 : antiLogValue - 1
            }
        }
        else if interval >= 0.1 {
            
            axis.entries.removeAll()
            
            var tickValues:Set<CGFloat> = []
            let roundedMin = floor(min)
            let roundedMax = ceil(max)
            
            var intermediateFactors = [1,2,3,4,5,6,7,8,9]
            
            if interval > 0.3 {
                intermediateFactors = [1,2,4]
            }
            else if interval > 0.15 {
                intermediateFactors = [1,2,4,6,8]
            }
            
            outerLoop: for i in Int(roundedMin)...Int(roundedMax + 1) {
                for factor in intermediateFactors {
                    var val: CGFloat
                    var checkMax = true
                        
                    if i < 0 {
                        checkMax = false
                    }
                    
                    val = ChartUtils.biSymmetricAntiLogTransformation(base: Base, y: CGFloat(i))
                    val = val == 0 ? val : val > 0 ? val + 1 : val - 1
                    val *= CGFloat(factor)
                        
                    let pos = ChartUtils.biSymmetricLogTransformation(base: Base, x: val)
                        
                    if pos >= roundedMin && pos <= roundedMax {
                        tickValues.insert(pos)
                    }
                        
                    if checkMax && pos >= max {
                        break outerLoop
                    }
                }
            }
            
            var ticks = tickValues.sorted()
                
            var last: CGFloat? = nil
            for current in tickValues {
                if current > min {
                    break
                }
                last = current
            }
                
            if let last = last {
                if let lastIndex = ticks.lastIndex(of: last) {
                    ticks = Array(ticks[lastIndex...])
                }
            }
            
            for index in 0..<ticks.count {
                axis.entries.append(ChartUtils.roundToNextSignificant(number: (ChartUtils.biSymmetricAntiLogTransformation(base: Base, y: ticks[index]))))
            }
        }
        else {
            super.computeAxisValues(min: ChartUtils.biSymmetricAntiLogTransformation(base: Base, y: min), max: ChartUtils.biSymmetricAntiLogTransformation(base: Base, y: max), axis: axis, chart: chart)
        }
    }
}

