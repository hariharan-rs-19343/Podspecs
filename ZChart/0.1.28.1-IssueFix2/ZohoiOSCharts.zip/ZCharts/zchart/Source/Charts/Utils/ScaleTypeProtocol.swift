//
//  ScaleTypeProtocol.swift
//  zchart
//
//  Created by Aravinth T on 11/01/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

@objc
public protocol ScaleTypeProtocol
{
    func computeAxisValues(min: Double, max: Double, axis:AxisBase, chart: ChartViewBase)
    
}


public enum ScaleType
{
    case Linear
    case Time
    case Ordinal
    case Log
    case SQRT
}



