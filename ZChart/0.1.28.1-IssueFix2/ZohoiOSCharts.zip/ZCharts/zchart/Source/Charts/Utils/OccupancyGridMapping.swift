//
//  OccupancyGridMapping.swift
//  zchart
//
//  Created by keerthi-pt4274 on 29/09/23.
//

import Foundation

struct LabelProperties {
    var value: Double
    var rect: CGRect
    
    var axisIndex:Int
    
    var formattedLabel:String? = nil
}

public class OccupancyGridMapping {
    
    fileprivate static var occupancyMatrix = [[Int]]()
    fileprivate static var ViewPortSize = CGSize(width: 0, height: 0)
    fileprivate static var actualWidthInterpolator: ((CGFloat) -> CGFloat)?
    fileprivate static var actualHeightInterpolator: ((CGFloat) -> CGFloat)?
    
    public static func initializeMatrix(viewPortSize: CGSize) {
        
        if viewPortSize.width >= 0 && viewPortSize.height >= 0 {
            occupancyMatrix = Array(repeating: Array(repeating: 0, count: Int(ceil(viewPortSize.width))), count: Int(ceil(viewPortSize.height)))
            
            ViewPortSize.width = viewPortSize.width - 1
            ViewPortSize.height = viewPortSize.height - 1
            
            actualWidthInterpolator = Interpolator.interpolate(a: 0, b: ViewPortSize.width)
            actualHeightInterpolator = Interpolator.interpolate(a: 0, b: ViewPortSize.height)
        }
        
    }
    
    internal static func resetOccupancyMatrix() {
        for rowIndex in 0..<occupancyMatrix.count {
            for colnumIndex in 0..<occupancyMatrix[rowIndex].count {
                occupancyMatrix[rowIndex][colnumIndex] = 0
            }
        }
    }
    
    internal static func isDataLabelFittedInPlot(chart: ChartViewBase, rect:  CGRect) -> Bool {
        
        var labelRectForScale1 = CGRect(origin: rect.origin, size: rect.size)
        
        labelRectForScale1.origin.x += abs(chart.viewPortHandler.transX)
        labelRectForScale1.origin.y += abs(chart.viewPortHandler.transY)
        
        var left = labelRectForScale1.minX
        var right = labelRectForScale1.maxX
        var top = labelRectForScale1.minY
        var bottom = labelRectForScale1.maxY
        
        guard let actualWidthInterpolator = actualWidthInterpolator, let actualHeightInterpolator = actualHeightInterpolator else {
            return false
        }
        
        if chart.viewPortHandler.scaleX > 1 {
            let totalWidth = chart.viewPortHandler.contentRect.width * chart.viewPortHandler.scaleX + chart.viewPortHandler.contentLeft - 1
            left = actualWidthInterpolator(Interpolator.precentage(a: 0, b: totalWidth, value: left))
            right = actualWidthInterpolator(Interpolator.precentage(a: 0, b: totalWidth, value: right))
        }
        
        if chart.viewPortHandler.scaleY > 1 {
            let totalHeight = chart.viewPortHandler.contentRect.height * chart.viewPortHandler.scaleY + chart.viewPortHandler.contentTop + chart.viewPortHandler.contentBottom - 1
            top = actualHeightInterpolator(Interpolator.precentage(a: 0, b: totalHeight, value: top))
            bottom = actualHeightInterpolator(Interpolator.precentage(a: 0, b: totalHeight, value: bottom))
        }
        
        if CheckOccupancy(left: left, right: right, top: top, bottom: bottom) {
            return true
        }
        
        return false
    }
    
    fileprivate static func CheckOccupancy( left: CGFloat, right: CGFloat, top: CGFloat, bottom: CGFloat) -> Bool {
        
        let left = ChartUtils.doubleToIntSafeCast(value: max(left, 0))
        let top = ChartUtils.doubleToIntSafeCast(value: max(top,0))
        let right = ChartUtils.doubleToIntSafeCast(value: min(right, ViewPortSize.width))
        let bottom = ChartUtils.doubleToIntSafeCast(value: min(bottom, ViewPortSize.height))
        
        if(occupancyMatrix[safe:top]?[safe:left]==1 || occupancyMatrix[safe:bottom]?[safe:left]==1 || occupancyMatrix[safe:top]?[safe:right]==1 || occupancyMatrix[safe:bottom]?[safe:right]==1){
            return false;
        }
        
        return fill1(index2Start: left,index1: top,index2: left,index1End: bottom,index2End: right)
    }
    
    fileprivate static func  fill1(index2Start: Int,index1: Int,index2: Int,index1End: Int,index2End: Int) -> Bool {
        
        var isOverlap = false
        var row = index1,column = index2
        
        while row <= index1End {
            column = index2
            while column <= index2End {
                if occupancyMatrix[safe:row]?[safe:column] == 1 {
                    isOverlap = true
                    break
                }
                if occupancyMatrix[safe:row]?[safe:column] != nil {
                    occupancyMatrix[row][column] = 1
                }
                column += 1
            }
            if isOverlap {
                break
            }
            row += 1
        }
        
        if isOverlap {
            var r = row - 1
            while r >= index1 {
                var c = column - 1
                while c >= index2 {
                    if occupancyMatrix[safe:row]?[safe:column] != nil {
                        occupancyMatrix[row][column] = 0
                    }
                    c -= 1
                }
                c = index2End
                r -= 1
            }
        }
        return !isOverlap
    }
}
