//
//  SettingsClass.swift
//  zchart
//
//  Created by Aravinth T on 27/08/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class TextSettings {
    
    public init() {
        
    }
    
    open var text:String!{
        didSet{
           self.notifyPropertyChnage()
        }
    }
    
    open var color:NSUIColor = NSUIColor.black{
        didSet{
            self.notifyPropertyChnage()
        }
    }
    
    open var font:NSUIFont = NSUIFont.systemFont(ofSize: 10){
        didSet{
            self.notifyPropertyChnage()
        }
    }
    
    open var alignment:NSTextAlignment = .center{
        didSet{
            self.notifyPropertyChnage()
        }
    }
    
    open var valueDidChangeClosure: (()->())?
    
    func notifyPropertyChnage(){
        self.valueDidChangeClosure?()
    }
    
}
