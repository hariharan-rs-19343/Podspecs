//
//  ChartGradient.swift
//  zchart
//
//  Created by Aravinth T on 05/10/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

@objc(ChartDrawableGradient)
public protocol DrawableGradient {
    func draw(_ gradient: CGGradient, in context: CGContext)
}
@objc(ChartBaseGradient)
open class BaseGradient: NSObject {
    @objc public var colors: [NSUIColor]
    @objc public let positions: [CGFloat]?
    @objc public let options: CGGradientDrawingOptions
    @objc public var frame:CGRect = CGRect.zero
    @objc public init(
        colors: [NSUIColor],
        positions: [CGFloat]?,
        options: CGGradientDrawingOptions) {
        self.colors = colors
        self.positions = positions
        self.options = options
    }
    
    @objc func getCGGradient() -> CGGradient? {
        
        guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: getCGColors() as CFArray, locations: positions) else {
            Log.error("Unable to create gradient object")
            return nil
        }
        return gradient
    }
    
    func getCGColors() -> [CGColor] {
        var cgColors:[CGColor] = []
        for color in colors {
            cgColors.append(color.cgColor)
        }
        return cgColors
    }
}
@objc(ChartLinearGradient)
open class LinearGradient: BaseGradient, DrawableGradient {
    @objc public var start: CGPoint
    @objc public var end: CGPoint
    @objc public init(
        colors: [NSUIColor],
        positions: [CGFloat]? = nil,
        options: CGGradientDrawingOptions = [],
        start: CGPoint,
        end: CGPoint) {
        self.start = start
        self.end = end
        super.init(colors: colors, positions: positions, options: options)
    }
    
    ///Frame property must be provided to use this method
    fileprivate func getFramePoint(anchorPoint:CGPoint, frame:CGRect) -> CGPoint {
        if frame == CGRect.zero {
            return anchorPoint
        }
        let x = frame.origin.x + (frame.width) * (anchorPoint.x)
        let y = frame.origin.y + (frame.height) * (anchorPoint.y)
        return CGPoint(x: x, y: y)
    }
    
    // MARK: - DrawableGradient
    public func draw(_ gradient: CGGradient, in context: CGContext) {
        context.drawLinearGradient(gradient, start: getFramePoint(anchorPoint: start, frame: frame), end: getFramePoint(anchorPoint: end, frame: frame), options: options)
    }
}

@objc(ChartRadialGradient)
open class RadialGradient: BaseGradient, DrawableGradient {
    
    @objc public var startCenter: CGPoint = CGPoint(x: 1, y: 1)
    @objc public var startRadius: CGFloat = CGFloat(0)
    @objc public var endCenter: CGPoint = CGPoint(x: 1, y: 1)
    @objc public var endRadius: CGFloat = CGFloat(1)
    
    @objc public init(
        colors: [NSUIColor],
        positions: [CGFloat]? = nil,
        options: CGGradientDrawingOptions = [],
        startCenter: CGPoint,
        startRadius: CGFloat,
        endCenter: CGPoint,
        endRadius: CGFloat) {
        self.startCenter = startCenter
        self.startRadius = startRadius
        self.endCenter = endCenter
        self.endRadius = endRadius
        super.init(colors: colors, positions: positions, options: options)
    }
    
    // MARK: - DrawableGradient
    
    public func draw(_ gradient: CGGradient, in context: CGContext) {
        context.drawRadialGradient(
            gradient,
            startCenter: startCenter,
            startRadius: startRadius,
            endCenter: endCenter,
            endRadius: endRadius,
            options: options)
    }
}
