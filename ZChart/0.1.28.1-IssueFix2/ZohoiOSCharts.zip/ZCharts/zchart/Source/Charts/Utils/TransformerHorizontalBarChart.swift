//
//  TransformerHorizontalBarChart.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(ChartTransformerHorizontalBarChart)
open class TransformerHorizontalBarChart: Transformer
{
  /*  /// Prepares the matrix that contains all offsets. //ORIGINAL
    open override func prepareMatrixOffset(inverted: Bool)
    {
        if !inverted
        {
            _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
        }
        else
        {
            _matrixOffset = CGAffineTransform(scaleX: -1.0, y: 1.0)
            _matrixOffset = _matrixOffset.translatedBy(x: -(_viewPortHandler.chartWidth - _viewPortHandler.offsetRight),
                y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
        }
    } */
    
    
    
    
    /// Prepares the matrix that contains all offsets.
    open override func prepareMatrixOffset(inverted: Bool)
    {
        // Y axis- not inverted
        if !inverted
        {
//            _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
            
            // X axis -inverted
            if (_viewPortHandler.chartViewBase?.xAxis.isInverted)!
            {
                _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.offsetTop) //Translate Y to offset top
            }
            else
            {
//                _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
                _matrixOffset = CGAffineTransform(translationX: _viewPortHandler.offsetLeft, y: _viewPortHandler.offsetTop)
            }
            
        }
        else // Y axis - inverted
        {
//            _matrixOffset = CGAffineTransform(scaleX: -1.0, y: 1.0)
//            _matrixOffset = _matrixOffset.translatedBy(x: -(_viewPortHandler.chartWidth - _viewPortHandler.offsetRight),y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
            
            // X axis -inverted
            if (_viewPortHandler.chartViewBase?.xAxis.isInverted)!
            {
                _matrixOffset = CGAffineTransform(scaleX: -1.0, y: 1.0)
                _matrixOffset = _matrixOffset.translatedBy(x:-(_viewPortHandler.chartWidth - _viewPortHandler.offsetRight),                                                       y: _viewPortHandler.offsetTop) //Translate Y to offset top
                
            }
            else
            {
                _matrixOffset = CGAffineTransform(scaleX: -1.0, y: 1.0)
//                  _matrixOffset = _matrixOffset.translatedBy(x: -(_viewPortHandler.chartWidth - _viewPortHandler.offsetRight),y: _viewPortHandler.chartHeight - _viewPortHandler.offsetBottom)
                _matrixOffset = _matrixOffset.translatedBy(x: -(_viewPortHandler.chartWidth - _viewPortHandler.offsetRight),y: _viewPortHandler.offsetTop)
            }
            
        }
    }
    
   /* open override func prepareMatrixValuePx(chartXMin: Double, deltaX: CGFloat, deltaY: CGFloat, chartYMin: Double)
    {
        if !(_viewPortHandler.chartViewBase?.xAxis.isInverted)! //X - axis not inverted
        {
            super.prepareMatrixValuePx(chartXMin: chartXMin, deltaX: deltaX, deltaY: deltaY, chartYMin: chartYMin)
            return
        }
        
        var scaleX = (_viewPortHandler.contentWidth / deltaX)
        var scaleY = (_viewPortHandler.contentHeight / deltaY)
        
        if CGFloat.infinity == scaleX
        {
            scaleX = 0.0
        }
        if CGFloat.infinity == scaleY
        {
            scaleY = 0.0
        }
        
        // setup all matrices
        _matrixValueToPx = CGAffineTransform.identity
        _matrixValueToPx = _matrixValueToPx.scaledBy(x: scaleX, y: scaleY) // scale to positive x value
        _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: CGFloat(-chartYMin))
        
    }*/
    
    open override func prepareMatrixValuePx(chartXMin: Double, deltaX: CGFloat, deltaY: CGFloat, chartYMin: Double)
    {
        var scaleX = (_viewPortHandler.contentWidth / deltaX)
        var scaleY = (_viewPortHandler.contentHeight / deltaY)
        
        if CGFloat.infinity == scaleX
        {
            scaleX = 0.0
        }
        if CGFloat.infinity == scaleY
        {
            scaleY = 0.0
        }
        
        _matrixValueToPx = CGAffineTransform.identity
        
        if !(_viewPortHandler.chartViewBase?.xAxis.isInverted)! {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: scaleX, y: scaleY) // scale to positive x value
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: CGFloat(-chartYMin))
        }else {
            _matrixValueToPx = _matrixValueToPx.scaledBy(x: scaleX, y: -scaleY) // scale to positive x value
            _matrixValueToPx = _matrixValueToPx.translatedBy(x: CGFloat(-chartXMin), y: -(CGFloat(chartYMin) + deltaY))
        }
    }
    
    
}
