//
//  OrdinalScale.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 15/05/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation


open class OrdinalScale : ScaleTypeProtocol
{
    weak var axis:AxisBase? = nil
    
    weak var viewPortHandler:ViewPortHandler? = nil
    
    public func computeAxisValues(min: Double, max: Double, axis: AxisBase, chart: ChartViewBase) {
        
        guard let data = chart.data
            else { return }
        
        self.axis = axis
        
        self.viewPortHandler = chart.viewPortHandler
        
        var min = min
        
        var max = max
        
        if axis.labelCount == 0 ||  abs(max - min).isInfinite || abs(max-min).isNaN
        {
            axis.entries = [Double]()
            axis.centeredEntries = [Double]()
            return
        }
        
        let tempRange =  ChartUtils.doubleToIntSafeCast(value:max - min)
        
        var interval = 1
        
        var tickCount = tempRange
        
        var maxLabelWidthCount: Int
        
        let width = axis.labelRotatedWidth
        
        let height = axis.labelRotatedHeight
        
        
        if (chart.isRotated && axis.isKind(of: XAxis.self) && height == .infinity) || (chart.isRotated && axis.isKind(of: YAxis.self) && width == .infinity) || (!chart.isRotated && axis.isKind(of: YAxis.self) && height == .infinity) || (!chart.isRotated && axis.isKind(of: XAxis.self) && width == .infinity) {
            
            // If more than threshold
            if tickCount > (axis.labelCount) && abs(tickCount - axis.labelCount) > 2
            {
                interval = (tickCount/axis.labelCount)+1
                tickCount = axis.labelCount
            }
            
            if interval == 0 {
                interval = 1
            }
            
        }
        else{
            guard let viewport = viewPortHandler
            else { return }
            
            if (chart.isRotated && axis.isKind(of: XAxis.self)) || (!chart.isRotated && axis.isKind(of: YAxis.self)){
                        
                maxLabelWidthCount =  ChartUtils.doubleToIntSafeCast(value:floor(((viewport.contentHeight)) / height))
            }
            else{
                        
                maxLabelWidthCount =  ChartUtils.doubleToIntSafeCast(value:floor(((viewport.contentWidth)) / width))
            }
            
            if maxLabelWidthCount <= 0
            {
                maxLabelWidthCount = tickCount
            }
        
            var neededIntervalCount = ChartUtils.roundToNextSignificant(number:(Double(tickCount) / Double(maxLabelWidthCount)))
            
            neededIntervalCount = neededIntervalCount <= 1.0 ? 1.0 : neededIntervalCount
        
            interval =  ChartUtils.doubleToIntSafeCast(value: neededIntervalCount)
            
            if  ChartUtils.doubleToIntSafeCast(value: ChartUtils.roundToNextSignificant(number:(Double(tickCount) / Double(interval)))) > axis.labelCount {
                interval =  ChartUtils.doubleToIntSafeCast(value: ChartUtils.roundToNextSignificant(number:(Double(tickCount) / Double(axis.labelCount))))
            }
            
            if interval <= 0 {
                interval = 1
            }
        }
        
        var tickList:[Double] = []
        
        var startValue = floor(min)
        
        while  ChartUtils.doubleToIntSafeCast(value:startValue) % interval != 0
        {
            startValue += 1
        }
        
        var tickValues = startValue
        /*
        if axis.centerAxisLabelsEnabled
        {
            tickValues += 0.5
            max += 0.5
        }
        */
        while tickValues <= max //+ 1
        {
            tickList.append(tickValues)
            
            tickValues += Double(interval)
        }
        
        axis.entries.removeAll(keepingCapacity: true)
        axis.entries.reserveCapacity(tickList.count)
        
        for val in tickList
        {
            if val < 0 { //Negative values are appearing
                continue
            }
            
            // In Case of padding, bottomSpace and topSpace
            if axis.isKind(of: XAxis.self)
            {
                if val < data.xMin || val > data.xMax {
                    continue
                }
            }
            else{
                let axisIndex = (axis as! YAxis).axisIndex
                
                guard (data._yAxisMinArray[axisIndex] != nil),
                      (data._yAxisMaxArray[axisIndex] != nil)
                else { return }
                
                if val < data._yAxisMinArray[axisIndex]! || val > data._yAxisMaxArray[axisIndex]!
                {
                    continue
                }
            }
            
            axis.entries.append(val)
        }
        
        if axis.centerAxisLabelsEnabled
        {
            axis.centeredEntries.removeAll(keepingCapacity: true)
            axis.centeredEntries.reserveCapacity(tickList.count)
            
            for val in tickList
            {
                if val < 0 { //Negative values are appearing
                    continue
                }
                axis.centeredEntries.append(val)
            }
        }
        
    }
    
}



