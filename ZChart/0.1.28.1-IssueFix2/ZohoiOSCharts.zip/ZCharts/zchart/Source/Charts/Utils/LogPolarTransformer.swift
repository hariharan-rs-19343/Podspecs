//
//  LogPolarTransformer.swift
//  Pods
//
//  Created by Keerthivass B S on 12/06/24.
//

open class LogPolarTransformer: PolarTransformer {
    
    var base: CGFloat
    var isXaxisLogScale: Bool
    var isYaxisLogScale: Bool
    
    public init(base: CGFloat, isXaxisLogScale: Bool, isYaxisLogScale: Bool, xScaleRange: CGFloat, yScaleRange:CGFloat, startAngle:CGFloat, centerPoint:CGPoint, radius:CGFloat, viewPortHandler: ViewPortHandler)
    {
        self.base = base
        self.isXaxisLogScale = isXaxisLogScale
        self.isYaxisLogScale = isYaxisLogScale
        super.init(xScaleRange: xScaleRange, yScaleRange: yScaleRange, startAngle: startAngle, centerPoint: centerPoint, radius: radius, viewPortHandler: viewPortHandler)
    }
    
    public required init(viewPortHandler: ViewPortHandler) {
        fatalError("init(viewPortHandler:) has not been implemented")
    }
    
    
    open override func pixelForValues(x: Double, y: Double, isOriginal: Bool = true) -> CGPoint {
        if isOriginal {
            return logValueFor(point: CGPoint(x: x, y: y)).applying(valueToPixelMatrix)
        }
        else {
            return CGPoint(x: x, y: y).applying(valueToPixelMatrix)
        }
    }
    
    open override func polarValuesForPixel(x:CGFloat,y:CGFloat) -> CGPoint
    {
        let newPoint = CGPoint(x: ChartUtils.roundNumber(number: x), y: ChartUtils.roundNumber(number: y))
        
        let angle = atan2(newPoint.y - centerPoint.y , newPoint.x - centerPoint.x)
        
        var finalAngle = ChartUtils.roundNumber(number: angle * ChartUtils.Math.FRAD2DEG)
        
        finalAngle = (finalAngle >= 0 && finalAngle <= 180) ? finalAngle : 360 + finalAngle
        
        finalAngle = (finalAngle - self.startAngle) < 0 ? 360 + (finalAngle - self.startAngle) : (finalAngle - self.startAngle)
        
        var values = CGPoint()
        
        if angleAxisDependency == .xAxis
        {
            values = CGPoint(x: finalAngle, y: PieHelperFunctions.distance(from: centerPoint, to: newPoint))
            
        }
        else{
            values = CGPoint(x: PieHelperFunctions.distance(from: centerPoint, to: newPoint), y: finalAngle )
        }
        
        values = antiLogValueFor(point: (values.applying(pixelToValueMatrix)))
        
        return CGPoint(x: ChartUtils.roundNumber(number: values.x), y: ChartUtils.roundNumber(number: values.y))
       
    }
    
    /// Transform an array of points with all matrices.
    // VERY IMPORTANT: Keep matrix order "value-touch-offset" when transforming.
    open override func pointValuesToPixel(_ points: inout [CGPoint])
    {
        let trans = valueToPixelMatrix
        for i in 0 ..< points.count
        {
            points[i] = logValueFor(point: points[i])
            points[i] = points[i].applying(trans)
        }
    }
    
    open override func pointValueToPixel(_ point: inout CGPoint)
    {
        point = logValueFor(point: point)
        point = point.applying(valueToPixelMatrix)
    }
    
    /// Transform a rectangle with all matrices.
    open override func rectValueToPixel(_ r: inout CGRect)
    {
        let logSizeValue = logValueFor(point: CGPoint(x: r.size.width, y: r.size.height))
        let basevalue = ChartUtils.biSymmetricLogTransformation(base: base, x: r.maxY)
        r.origin = logValueFor(point: r.origin)
        r.size.width = logSizeValue.x
        r.size.height = basevalue - r.origin.y
        r = r.applying(valueToPixelMatrix)
    }

    /// transforms multiple rects with all matrices
    open override func rectValuesToPixel(_ rects: inout [CGRect])
    {
        let trans = valueToPixelMatrix
        
        for i in 0 ..< rects.count
        {
            let logSizeValue = logValueFor(point: CGPoint(x: rects[i].size.width, y: rects[i].size.height))
            let basevalue = ChartUtils.biSymmetricLogTransformation(base: base, x: rects[i].minY)
            rects[i].origin = logValueFor(point: rects[i].origin)
            rects[i].size.width = logSizeValue.x
            rects[i].size.height = basevalue - rects[i].origin.y
            rects[i] = rects[i].applying(trans)
        }
    }
    
    /// Transforms the given array of touch points (pixels) into values on the chart.
    open override func pixelsToValues(_ pixels: inout [CGPoint])
    {
        let trans = pixelToValueMatrix
        
        for i in 0 ..< pixels.count
        {
            pixels[i] = pixels[i].applying(trans)
            pixels[i] = antiLogValueFor(point: pixels[i])
        }
    }
    
    /// Transforms the given touch point (pixels) into a value on the chart.
    open override func pixelToValues(_ pixel: inout CGPoint)
    {
        pixel = pixel.applying(pixelToValueMatrix)
        pixel = antiLogValueFor(point: pixel)
    }
    
    open func logValueFor(point: CGPoint) -> CGPoint{
        let x = isXaxisLogScale ? ChartUtils.biSymmetricLogTransformation(base: base, x: point.x) : point.x
        let y = isYaxisLogScale ? ChartUtils.biSymmetricLogTransformation(base: base, x: point.y) : point.y
        return CGPoint(x: x, y: y)
    }
    
    open func antiLogValueFor(point: CGPoint) -> CGPoint {
        let x = isXaxisLogScale ? ChartUtils.biSymmetricAntiLogTransformation(base: base, y: point.x) : point.x
        let y = isYaxisLogScale ? ChartUtils.biSymmetricAntiLogTransformation(base: base, y: point.y) : point.y
        return CGPoint(x: x, y: y)
    }
}
