//
//  SQRTScale.swift
//  Pods
//
//  Created by Keerthivass B S on 27/06/24.
//

open class SQRTScale: LinearScale {
    
    public override func computeAxisValues(min: Double, max: Double, axis: AxisBase, chart: ChartViewBase) {
        super.computeAxisValues(min: ChartUtils.square(value: min), max: ChartUtils.square(value: max), axis: axis, chart: chart)
    }
    
}
