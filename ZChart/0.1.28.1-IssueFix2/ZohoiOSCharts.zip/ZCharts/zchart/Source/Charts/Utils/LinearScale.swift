//
//  LinearScale.swift
//  zchart
//
//  Created by Aravinth T on 11/01/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class LinearScale : ScaleTypeProtocol
{
    public func computeAxisValues(min: Double, max: Double, axis: AxisBase, chart: ChartViewBase) {
        
        var yMin = min
        var yMax = max
        
        let labelCount = axis.labelCount
        var range = abs(yMax - yMin)
        
        guard (chart.data != nil)
        else { return }
        
        if axis.isKind(of: XAxis.self) && axis.scaleType == .Linear
        {
            if yMin < (chart.data?.xMin)!
            {
                yMin = (chart.data?.xMin)!
            }
            if yMax > (chart.data?.xMax)!
            {
                yMax = (chart.data?.xMax)!
            }
            
            range = abs(yMax - yMin)
            
            if yMin == yMax
            {
                axis.entries = [yMax]
                axis.centeredEntries = [yMax ]
                return
            }
        }
        
        if labelCount == 0 || range <= 0 || range.isInfinite || range.isNaN
        {
            axis.entries = [Double]()
            axis.centeredEntries = [Double]()
            return
        }
        
        let interval = getInterval(chart: chart, axis: axis, range: range, granularityEnabled: axis.granularityEnabled)
        
        var n = axis.centerAxisLabelsEnabled ? 1 : 0
        
        // force label count
        if axis.isForceLabelsEnabled
        {
            // Ensure stops contains at least n elements.
            axis.entries.removeAll(keepingCapacity: true)
            axis.entries.reserveCapacity(labelCount)
            
            var v = interval == 0.0 ? 0.0 : ceil(yMin / interval) * interval
            
            for _ in 0 ..< labelCount
            {
                axis.entries.append(v)
                v += interval
            }
            
            n = labelCount
        }
        else
        {
            // no forced count
            
            var first = interval == 0.0 ? 0.0 : ceil(yMin / interval) * interval
            
            if axis.centerAxisLabelsEnabled
            {
                first -= interval
            }
            
            let last = interval == 0.0 ? 0.0 : ChartUtils.nextUp(floor(yMax / interval) * interval)
            
            if interval != 0.0 || last != first
            {
                for _ in stride(from: first, through: last, by: interval)
                {
                    n += 1
                }
            }
            
            // Ensure stops contains at least n elements.
            axis.entries.removeAll(keepingCapacity: true)
            axis.entries.reserveCapacity(labelCount)
            
            var f = first
            var i = 0
            while i < n
            {
                if f == 0.0
                {
                    // Fix for IEEE negative zero case (Where value == -0.0, and 0.0 == -0.0)
                    f = 0.0
                }
                
                axis.entries.append(Double(f))
                
                f += interval
                i += 1
            }
        }
        
        // set decimals
        if interval < 1
        {
            axis.decimals =  ChartUtils.doubleToIntSafeCast(value:ceil(-log10(interval)))
        }
        else
        {
            axis.decimals = 0
        }
        
        if axis.centerAxisLabelsEnabled
        {
            axis.centeredEntries.reserveCapacity(n)
            axis.centeredEntries.removeAll()
            
            let offset: Double = interval / 2.0
            
            for i in 0 ..< n
            {
                axis.centeredEntries.append(axis.entries[i] + offset)
            }
        }
    }
    
    public func getInterval(chart: ChartViewBase, axis: AxisBase, range: Double, granularityEnabled: Bool = true) -> Double {
        
        // Find out how much spacing (in y value space) between axis values
        let rawInterval = range / Double(axis.labelCount)
        var interval = ChartUtils.roundToNextSignificant(number: Double(rawInterval))
        
        if axis.isForceLabelsEnabled
        {
            interval =  ChartUtils.roundToNextSignificant(number: Double(range) / Double(axis.labelCount - 1))
        }
        
        if (axis.interval != nil) {
            var customInterval = axis.interval!.isNaN ? interval : axis.interval!
            
            if axis.scaleType == .SQRT {
                interval = customInterval < abs(range) ? customInterval : interval
            }
            else {
                while customInterval < abs(range) {
                    let count = Int(floor(range / customInterval))
                    if ((chart.isRotated && axis.isKind(of: XAxis.self) || !chart.isRotated && axis.isKind(of: YAxis.self))  && (CGFloat(count) * axis.labelRotatedHeight) < chart.viewPortHandler.contentHeight) || ((!chart.isRotated && axis.isKind(of: XAxis.self) || chart.isRotated && axis.isKind(of: YAxis.self)) && (CGFloat(count) * axis.labelRotatedWidth) < chart.viewPortHandler.contentWidth) {
                        interval = customInterval
                        break
                    }
                    customInterval += abs(customInterval)
                }
            }
        }
        
        // If granularity is enabled, then do not allow the interval to go below specified granularity.
        // This is used to avoid repeated values when rounding values for display.
        if granularityEnabled
        {
            interval = interval < axis.granularity ? axis.granularity : interval
        }
        
        // Normalize interval
        let intervalMagnitude = ChartUtils.roundToNextSignificant(number: pow(10.0, Double(ChartUtils.doubleToIntSafeCast(value:log10(interval)))))
        let intervalSigDigit =  ChartUtils.doubleToIntSafeCast(value:interval / intervalMagnitude)
        if intervalSigDigit > 5
        {
            // Use one order of magnitude higher, to avoid intervals like 0.9 or 90
            interval = floor(10.0 * Double(intervalMagnitude))
        }
        
        return interval
    }
    
}
