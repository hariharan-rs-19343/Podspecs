//
//  SQRTTransformerHorizontalChart.swift
//  Pods
//
//  Created by Keerthivass B S on 27/06/24.
//

open class SQRTTransformerHorizontalChart: TransformerHorizontalBarChart {
    
    var isXaxisSQRTScale: Bool
    var isYaxisSQRTScale: Bool
    
    public required init(viewPortHandler: ViewPortHandler, isXaxisSQRTScale: Bool, isYaxisSQRTScale: Bool)
    {
        self.isXaxisSQRTScale = isXaxisSQRTScale
        self.isYaxisSQRTScale = isYaxisSQRTScale
        super.init(viewPortHandler: viewPortHandler)
    }
    
    public required init(viewPortHandler: ViewPortHandler) {
        self.isXaxisSQRTScale = false
        self.isYaxisSQRTScale = false
        super.init(viewPortHandler: viewPortHandler)
    }
    
    /// Transform an array of points with all matrices.
    // VERY IMPORTANT: Keep matrix order "value-touch-offset" when transforming.
    open override func pointValuesToPixel(_ points: inout [CGPoint])
    {
        let trans = valueToPixelMatrix
        for i in 0 ..< points.count
        {
            points[i] = squareRoot(point: points[i])
            points[i] = points[i].applying(trans)
        }
    }
    
    open override func pointValueToPixel(_ point: inout CGPoint)
    {
        point = squareRoot(point: point)
        point = point.applying(valueToPixelMatrix)
    }
    
    open override func pixelForValues(x: Double, y: Double, isOriginal: Bool = true) -> CGPoint
    {
        if isOriginal {
            return squareRoot(point: CGPoint(x: x, y: y)).applying(valueToPixelMatrix)
        }
        else {
            return super.pixelForValues(x: x, y: y)
        }
    }
    
    /// Transform a rectangle with all matrices.
    open override func rectValueToPixel(_ r: inout CGRect)
    {
        let sizeValue = squareRoot(point: CGPoint(x: r.size.width, y: r.size.height))
        let topValue = ChartUtils.squareRoot(value: r.maxX)
        let baseValue = ChartUtils.squareRoot(value: r.minX)
        r.origin = squareRoot(point: r.origin)
        r.size.width = sizeValue.x > 0 ? abs(topValue - baseValue) : -abs(topValue - baseValue)
        r.size.height = sizeValue.y
        r = r.applying(valueToPixelMatrix)
    }

    /// transforms multiple rects with all matrices
    open override func rectValuesToPixel(_ rects: inout [CGRect])
    {
        let trans = valueToPixelMatrix
        
        for i in 0 ..< rects.count
        {
            let sizeValue = squareRoot(point: CGPoint(x: rects[i].size.width, y: rects[i].size.height))
            let topValue = ChartUtils.squareRoot(value: rects[i].maxX)
            let baseValue = ChartUtils.squareRoot(value: rects[i].minX)
            rects[i].origin = squareRoot(point: rects[i].origin)
            rects[i].size.width = sizeValue.x > 0 ? abs(topValue - baseValue) : -abs(topValue - baseValue)
            rects[i].size.height = sizeValue.y
            rects[i] = rects[i].applying(trans)
        }
    }
    
    /// Transforms the given array of touch points (pixels) into values on the chart.
    open override func pixelsToValues(_ pixels: inout [CGPoint])
    {
        let trans = pixelToValueMatrix
        
        for i in 0 ..< pixels.count
        {
            pixels[i] = pixels[i].applying(trans)
            pixels[i] = square(point: pixels[i])
        }
    }
    
    /// Transforms the given touch point (pixels) into a value on the chart.
    open override func pixelToValues(_ pixel: inout CGPoint)
    {
        pixel = pixel.applying(pixelToValueMatrix)
        pixel = square(point: pixel)
    }
    
    /// - returns: The x and y values in the chart at the given touch point
    /// (encapsulated in a CGPoint). This method transforms pixel coordinates to
    /// coordinates / values in the chart.
    open override func valueForTouchPoint(_ point: CGPoint) -> CGPoint
    {
        return square(point: point.applying(pixelToValueMatrix))
    }
    
    /// - returns: The x and y values in the chart at the given touch point
    /// (x/y). This method transforms pixel coordinates to
    /// coordinates / values in the chart.
    open override func valueForTouchPoint(x: CGFloat, y: CGFloat) -> CGPoint
    {
        return square(point: CGPoint(x: x, y: y).applying(pixelToValueMatrix))
    }
    
    open func squareRoot(point: CGPoint) -> CGPoint {
        let x = isYaxisSQRTScale ? ChartUtils.squareRoot(value: point.x) : point.x
        let y = isXaxisSQRTScale ? ChartUtils.squareRoot(value: point.y) : point.y
        return CGPoint(x: x, y: y)
    }
    
    open func square(point: CGPoint) -> CGPoint {
        let x = isYaxisSQRTScale ? ChartUtils.square(value: point.x) : point.x
        let y = isXaxisSQRTScale ? ChartUtils.square(value: point.y) : point.y
        return CGPoint(x: x, y: y)
    }
}
