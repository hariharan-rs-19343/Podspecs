//
//  ChartBaseLine.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 03/07/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

/// The Base line is an additional feature for all Line, Bar and ScatterCharts.
/// It allows the displaying of an additional line in the chart that marks a certain baseline value on the specified axis (x- or y-axis).
open class ChartBaseLine: NSObject
{
    /// (the y-value or xIndex)
    open var baseValue = Double(0.0)
    
    fileprivate var _lineWidth = CGFloat(2.0)
    open var lineColor = NSUIColor.black
    open var lineDashPhase = CGFloat(0.0)
    open var lineDashLengths: [CGFloat]?
    

    public override init()
    {
        super.init()
    }
    
    public init(value: Double)
    {
        super.init()
        self.baseValue = value
    }
    
    /// set the line width of the chart (min = 0.2, max = 12); default 2
    open var lineWidth: CGFloat
        {
        get
        {
            return _lineWidth
        }
        set
        {
            if newValue < 0.2
            {
                _lineWidth = 0.2
            }
            else if newValue > 12.0
            {
                _lineWidth = 12.0
            }
            else
            {
                _lineWidth = newValue
            }
        }
    }
}
