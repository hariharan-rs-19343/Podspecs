//
//  ColorAxis.swift
//  zchart
//
//  Created by Aravinth T on 10/04/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class ColorAxis : ComponentBase
{
    var axisminimum:Double = 0
    
    var axismaximum:Double = 0
    
    open var type:ColorAxisType = .linear
    
    open var colors:[NSUIColor] = []
    
    open var minAxisRange:Double? = nil
    
    open var maxAxisRange:Double? = nil
    
    open var stops:[Double] = []
    
    open var category:[String] = []
    
    open var rangeArray:[Range] = []
    
    var tempStops:[Double] = []
    
    var tempColors:[NSUIColor] = []
    
    var tempCategories:[String] = []
    
    var scaleMatrix:CGAffineTransform = CGAffineTransform.identity
    
    open var legend: Legend?
    
    public required init(legend: Legend?)
    {
        super.init()
        enabled = false
        self.legend = legend
    }
    
    open func calcMinMax(data:ChartData) {
        
        guard
            let legend = legend
            else { return }
        
        tempStops.removeAll()
        tempColors.removeAll()
        
        let (dataMin,dataMax,dataCategories) = getDataMinMax(data: data)
        
        if dataMin == Double.greatestFiniteMagnitude || dataMax == -Double.greatestFiniteMagnitude {
            return
        }
        
        axisminimum = dataMin
        axismaximum = dataMax
        
        if minAxisRange != nil { //}&& dataMin > (minAxisRange)! { //TOCHECK dataMin > (minAxisRange)!
            axisminimum = minAxisRange!
        }
        
        if maxAxisRange != nil { //&& dataMax < (maxAxisRange)! { //TOCHECK dataMax < (maxAxisRange)!
            axismaximum = maxAxisRange!
        }
        
        if stops.isEmpty && category.isEmpty && rangeArray.isEmpty {
            
            if dataCategories.count > 0 {
                self.type = .discrete
                prepareDiscreteStops(categories: Array(dataCategories))
            } else {
                self.type = .linear
                prepareLinearStops(stops: [axisminimum, axismaximum])
            }
            
        }
        else {
            switch type {
            case .linear:
                prepareLinearStops(stops: stops)
            case .range:
                prepareRangeStops()
            case .discrete:
                prepareDiscreteStops(categories: category)
            }
        }
        prepareScaleMatrix(minValue: axisminimum, maxValue: axismaximum, minIndex: 0, maxIndex: tempStops.count - 1)
        
        legend.entries = prepareLegendEntries()
        legend.legendRange = (axisminimum, axismaximum)
    }
    
    fileprivate func getDataMinMax(data:ChartData) -> (dataMin:Double, dataMax:Double, categories:Set<String>) {
        
        var categories:Set<String> = Set<String>()
        
        var dataMax = -Double.greatestFiniteMagnitude
        var dataMin = Double.greatestFiniteMagnitude
        
        for dataSet in data.dataSets {
         
            for entryIndex in 0 ..< dataSet.entryCount {
                
                guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
                
                if entry.colorString != nil {
                    categories.insert(entry.colorString!)
                }
                
                if entry.colorValue != nil {
                    let value = entry.colorValue!
                    if value < dataMin
                    {
                        dataMin = value
                    }
                    if value > dataMax
                    {
                        dataMax = value
                    }
                }
            }
        }
        
        if !categories.isEmpty {
            dataMin = 0
            dataMax = Double(categories.count - 1)
        }
        
        return (dataMin,dataMax,categories)
    }
    
   /* open func calculate(dataMin:Double, dataMax:Double)
    {
        tempStops.removeAll()
        tempColors.removeAll()
        
        axisminimum = dataMin
        axismaximum = dataMax
        
        if minAxisRange != nil && dataMin > (minAxisRange)! { //TOCHECK dataMin > (minAxisRange)!
            axisminimum = minAxisRange!
        }
        
        if maxAxisRange != nil && dataMax < (maxAxisRange)! { //TOCHECK dataMax < (maxAxisRange)!
            axismaximum = maxAxisRange!
        }
        
        if stops.isEmpty && category.isEmpty && rangeArray.isEmpty {
     
//            tempStops.append(axisminimum)
//            tempStops.append(axismaximum)
//            copyColorsToTempObj()
     
            if tempCategories.count > 0 {
                prepareDiscreteStops(categories: tempCategories)
            }
            else {
                prepareLinearStops(stops: [axisminimum, axismaximum])
            }
        }
        else {
            switch type {
                case .linear:
                    print("linear")
                    prepareLinearStops(stops: stops)
                case .range:
                    print("range")
                    prepareRangeStops()
                case .discrete:
                    print("discrete")
                    prepareDiscreteStops(categories: category)
            }
        }
        prepareScaleMatrix(minValue: axisminimum, maxValue: axismaximum, minIndex: 0, maxIndex: tempStops.count - 1)
    }*/
    
    /**
     Prepare stops for linear range
     **/
    fileprivate func prepareLinearStops(stops:[Double]) {
        
        
        axisminimum = stops[0]
        axismaximum = stops[stops.count - 1]
        
        if minAxisRange != nil {
            axisminimum = minAxisRange!
            tempStops.append(axisminimum)
        }
        
        for value in stops {
            tempStops.append(value)
        }
        
        if maxAxisRange != nil {
            axismaximum = maxAxisRange!
            tempStops.append(axismaximum)
        }
        
        copyColorsToTempObj()
    }
    
    /**
     Prepare stops for range values
     **/
    fileprivate func prepareRangeStops() {
        
        for index in 0..<rangeArray.count {
            let range = rangeArray[index]
            
           /* tempStops.append(range.from)
            if index == rangeArray.count - 1 {
                tempStops.append(range.to - 1)
            }else {
                tempStops.append(range.to)
            } */
            
            if index == 0 {
               tempStops.append(range.from)
            }else {
               tempStops.append(range.from + 1)
            }
            
            tempStops.append(range.to)
            
            tempColors.append(colors[index%colors.count])
            tempColors.append(colors[index%colors.count])
        }
        
        axisminimum = tempStops[0]
        axismaximum = tempStops[tempStops.count - 1]
        
    }
    
    /**
     Prepare stops for category string
    **/
    fileprivate func prepareDiscreteStops(categories:[String]) {
        
        for index in 0 ..< categories.count {
            tempStops.append(Double(index))
        }
         axisminimum = tempStops[0]
         axismaximum = tempStops[categories.count - 1]
        
         tempCategories = categories
         copyColorsToTempObj()
    }
    
    fileprivate func copyColorsToTempObj() {
        tempColors = colors
    }
    
    fileprivate func prepareScaleMatrix(minValue:Double,maxValue:Double, minIndex:Int, maxIndex:Int) {
        
        let indexWidth = Double(maxIndex - minIndex)
        let valueRange = (maxValue - minValue) == 0 ? 1 : (maxValue - minValue)
        
        let scaleX = indexWidth / valueRange
        
        scaleMatrix = CGAffineTransform.identity
        scaleMatrix = scaleMatrix.scaledBy(x: CGFloat(scaleX), y: 0)
        scaleMatrix = scaleMatrix.translatedBy(x:-CGFloat(minValue), y: 0)
        
    }
    
    fileprivate func prepareLegendEntries() -> [LegendEntry] {
        
        var legendEntries:[LegendEntry] = []
        
        if self.type == .linear
        {
            let legendEntry = LegendEntry()
            legendEntry.type = type
            legendEntry.colors = tempColors
            legendEntry.value = tempStops as AnyObject
            legendEntry.label = "linear"
            legendEntries.append(legendEntry)
        }
        else if self.type == .range
        {
            for index in 0 ..< self.rangeArray.count
            {
                let range = rangeArray[index]
                let legendEntry = LegendEntry()
                legendEntry.type = type
                legendEntry.formColor = colors[index%colors.count]//Temp colors hold more repeated color values for linear scale
                legendEntry.value = range
                legendEntry.label = String(range.from) + "-" + String(range.to)
                legendEntries.append(legendEntry)
            }
        }
        else if self.type == .discrete
        {
            for index in 0 ..< tempCategories.count {
                let category = tempCategories[index]
                let legendEntry = LegendEntry()
                legendEntry.type = type
                legendEntry.formColor = tempColors[index%tempColors.count]
                legendEntry.value = category as AnyObject
                legendEntry.label = category
                legendEntries.append(legendEntry)
            }
        }
        
        return legendEntries
    }
    
    open func getColor(entry:ChartDataEntry) -> NSUIColor? {
        if !isEnabled {
            return nil
        }
        var value:Double!
        
        if type == .discrete {
//            value = Double(category.firstIndex(of: entry.colorString!)!)
            if entry.colorString == nil
            {
                return nil
            }
            value = Double((tempCategories.firstIndex(of: entry.colorString!)) ?? 0)
        }else
        {
            if entry.colorValue == nil || (entry.colorValue?.isNaN)!
            {
                return nil
            }
             value = entry.colorValue!
        }
        
        var point = CGPoint(x: value, y: 0)
        point = point.applying(scaleMatrix)
        
        if (type != .linear){
//            return tempColors[Int(ceil(point.x))]
            return getColorsForDiscrete(entry: entry)
        }
        
        if point.x.isNaN || point.y.isNaN
        {
            return nil
        }
        
        let colorIndex =  ChartUtils.doubleToIntSafeCast(value:floor(point.x))
        
        let startIndex = colorIndex
        
        if startIndex < 0
        {
            return nil
        }
        
        if startIndex == tempStops.count - 1 {
            return tempColors[startIndex%tempColors.count]
        }
        
        let nextIndex = startIndex + 1
        
        let aValue = tempStops[startIndex%tempStops.count]
        let zValue = tempStops[nextIndex%tempStops.count]
        
        var factor = ( value - aValue ) / (zValue - aValue)
        //DOESNT SUPPORT THE STOP POINTS WITH IRREGULAR INTERVALS LIKE 1,10,50
        if factor.isNaN
        {
            factor = 0
        }
        else if factor > 1 {
            factor = 1
        }else if factor < 0 {
            factor = 0
        }

        let function = Interpolator.interpolate(a: tempColors[startIndex%tempColors.count], b: tempColors[nextIndex%tempColors.count])
        
        return function(factor)
    }
    
    fileprivate func getColorsForDiscrete(entry:ChartDataEntry) -> NSUIColor {
        if type == .range {
            for index in 0 ..< rangeArray.count {
                guard let entryColorValue = entry.colorValue
                else{ continue }
                if rangeArray[index].contains(entryColorValue) {
                    return colors[index%colors.count]
                }
            }
        }else {
            guard let eColorString = entry.colorString
            else { return NSUIColor.lightGray.withAlphaComponent(0.5) }
            for index in 0 ..< category.count {
                if category[index] == eColorString {
                    return colors[index]
                }
            }
        }
        return NSUIColor.lightGray.withAlphaComponent(0.5) //NIL Color
    }
    
    open func isEntryAllowed(chartEntry:ChartDataEntry, minimum: Double, maximum:Double) -> Bool {
        var isEntryAllowed:Bool = false
        switch type {
            case .linear:
                isEntryAllowed = checkEntryInLinear(minimum: minimum, maximum: maximum, entry: chartEntry)
            case .range:
                isEntryAllowed = checkEntryInRanges(startIndex:  ChartUtils.doubleToIntSafeCast(value:minimum), endIndex:  ChartUtils.doubleToIntSafeCast(value:maximum), entry: chartEntry)
            case .discrete:
                isEntryAllowed = checkEntryInCategory(startIndex:  ChartUtils.doubleToIntSafeCast(value:minimum), endIndex:  ChartUtils.doubleToIntSafeCast(value:maximum), entry: chartEntry)
        }
        
        return isEntryAllowed
    }
    
    fileprivate func checkEntryInRanges(startIndex:Int, endIndex:Int, entry:ChartDataEntry) -> Bool {
        guard let eColorValue = entry.colorValue
        else { return false }
        for index in stride(from: startIndex, through: endIndex, by: 1) {
            let range  = self.rangeArray[index]
            if (range.contains(eColorValue)) {
                return true
            }
        }
        return false
    }
    
    fileprivate func checkEntryInCategory(startIndex:Int, endIndex:Int, entry:ChartDataEntry) -> Bool {
        guard let eColorString = entry.colorString
        else { return false }
        for index in stride(from: startIndex, through: endIndex, by: 1) {
            let categoryValue  = self.category[index]
            if categoryValue == eColorString {
                return true
            }
        }
        return false
    }
    
    fileprivate func checkEntryInLinear( minimum: Double, maximum:Double, entry:ChartDataEntry) -> Bool {
        guard let eColorValue = entry.colorValue
        else { return false }
        if eColorValue >= minimum && eColorValue <= maximum {
            return true
        }
        return false
    }
    
    // MARK: - NSCopying
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = Swift.type(of: self).init(legend:legend)
        
        copy.type = type
        copy.stops = stops
        copy.colors = colors
        copy.rangeArray = rangeArray
        copy.category = category
      
        return copy
    }
    
    // MARK: - Codable
    
        enum colorAxisCodingKeys: CodingKey {
            case legendType
            case colors
            case stops
            case ranges
            case minValue
            case maxValue
            case categories
       }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            
            let container = try decoder.container(keyedBy: colorAxisCodingKeys.self)
            
            let typeString = container.contains(.legendType) ? try container.decode(String.self, forKey: .legendType) : "LINEAR"
            
            switch typeString {
            case "LINEAR":
                type = .linear
            case "LINEAR_RANGE":
                type = .range
            case "DISCRETE":
                type = .discrete
            case "DISCRETE_CONTINUES":
                type = .discrete
            default:
                type = .linear
            }
            let colorsCode = container.contains(.colors) ? try container.decode([Int].self, forKey: .colors) : []
            
            colors.removeAll()
            
            for code in colorsCode
            {
                colors.append(NSUIColor(rgb:code))
            }
            
            stops = container.contains(.stops) ? try container.decode([Double].self, forKey: .stops) : []
            
            rangeArray = container.contains(.ranges) ? try container.decode([Range].self, forKey: .ranges) : []
            
            category = container.contains(.categories) ? try container.decode([String].self, forKey: .categories) : []
        }
    
        public  override func encode(to encoder: Encoder) throws {
  
        }
    
    
}

public enum ColorAxisType: Int
{
    case linear
    case discrete
    case range
}
