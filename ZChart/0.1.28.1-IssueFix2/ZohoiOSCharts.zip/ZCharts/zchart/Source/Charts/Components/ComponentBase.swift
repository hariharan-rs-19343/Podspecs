//
//  ComponentBase.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics


public struct textOffsets:Codable
{
    /// **default**: 5.0
     public var marginLeft = CGFloat(5)

     public var marginRight = CGFloat(5)
  
     public var marginTop = CGFloat(5)
  
     public var marginBotom = CGFloat(5)
    
    init(marginLeft:CGFloat,marginRight:CGFloat,marginTop:CGFloat,marginBotom:CGFloat) {
        self.marginLeft = marginLeft
        self.marginRight = marginRight
        self.marginTop = marginTop
        self.marginBotom = marginBotom
    }
    
    public mutating func setTextOffets(marginLeft:CGFloat,marginRight:CGFloat,marginTop:CGFloat,marginBotom:CGFloat) {
        self.marginLeft = marginLeft
        self.marginRight = marginRight
        self.marginTop = marginTop
        self.marginBotom = marginBotom
    }
    
    // MARK: - Codable
    
        enum CodingKeys: CodingKey {
            case bottom
            case left
            case right
            case top
       }
    
    public init(from decoder: Decoder) throws {
            
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            marginTop = container.contains(.top) ? try container.decode(CGFloat.self, forKey: .top) : marginTop
            marginBotom = container.contains(.bottom) ? try container.decode(CGFloat.self, forKey: .bottom) : marginBotom
            marginLeft = container.contains(.left) ? try container.decode(CGFloat.self, forKey: .left) : marginLeft
            marginRight = container.contains(.right) ? try container.decode(CGFloat.self, forKey: .right) : marginRight
            
        }
    
        public  func encode(to encoder: Encoder) throws {
  
        }
}

public struct Offsets:Codable
{
    /// **default**: 5.0
    public var leftOffset: CGFloat?

    public var rightOffset: CGFloat?
  
    public var topOffset: CGFloat?
  
    public var bottomOffset: CGFloat?
    
    init(leftOffset:CGFloat,rightOffset:CGFloat,topOffset:CGFloat,bottomOffset:CGFloat) {
        self.leftOffset = leftOffset
        self.rightOffset = rightOffset
        self.rightOffset = rightOffset
        self.bottomOffset = bottomOffset
    }
    
    init (){
        
    }
    
    mutating func reset() {
        leftOffset = nil
        rightOffset = nil
        rightOffset = nil
        bottomOffset = nil
    }
}

/// This class encapsulates everything both Axis, Legend and LimitLines have in common
@objc(ChartComponentBase)
open class ComponentBase: NSObject, Codable
{
    /// flag that indicates if this component is enabled or not
    open var enabled = true
    
    /// The offset this component has on the x-axis
    /// **default**: 5.0
    open var xOffset = CGFloat(5)
    
    /// The offset this component has on the x-axis
    /// **default**: 5.0 (or 0.0 on ChartYAxis)
    open var yOffset = CGFloat(5.0)
    
    public override init()
    {
        super.init()
    }

    open var isEnabled: Bool { return enabled }
    
    // MARK: - Codable
    
        enum CodingKeys: CodingKey {
            case mEnabled
            case mXOffset
            case mYOffset
       }
    
        required public  init(from decoder: Decoder) throws {
            super.init()
            
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            enabled = container.contains(.mEnabled) ? try container.decode(Bool.self, forKey: .mEnabled) : enabled
            xOffset = container.contains(.mXOffset) ? try container.decode(CGFloat.self, forKey: .mXOffset) : xOffset
            yOffset = container.contains(.mYOffset) ? try container.decode(CGFloat.self, forKey: .mYOffset) : yOffset
        }
    
        public  func encode(to encoder: Encoder) throws {
  
        }
}

open class ZCTextModel: NSObject
{
    open var enabled = false
    open var formatter: IValueFormatter = DefaultValueFormatter()
    open var AttributedString:[NSAttributedString.Key : AnyObject] = [NSAttributedString.Key.font: NSUIFont.systemFont(ofSize: 20), NSAttributedString.Key.foregroundColor: NSUIColor.black]
    open var xOffset: CGFloat = 0.0
    open var yOffset: CGFloat = 0.0
    open var truncate: Bool = false
    
    open var labelHorizontalAlignment: HorizontalLabelPosition  = .none
    open var labelVerticalAlignment: VerticalLabelPosition = .none
}

public enum VerticalLabelPosition {
    case none
    case top
    case bottom
    case center
}

public enum HorizontalLabelPosition {
    case none
    case center
    case left
    case right
}

open class ZCLineCongifuration: NSObject
{
    open var enabled = true
    open var lineColor: NSUIColor = NSUIColor.lightGray
    open var lineWidth: CGFloat = 1.0
    open var lineDashPhase: CGFloat = 0.0
    open var lineDashLengths: [NSNumber]?
    
    internal func setLineConfiguration(to layer: CAShapeLayer)
    {
        layer.strokeColor = lineColor.cgColor
        layer.lineWidth = lineWidth
        layer.lineDashPhase = lineDashPhase
        layer.lineDashPattern = lineDashLengths
    }
}
