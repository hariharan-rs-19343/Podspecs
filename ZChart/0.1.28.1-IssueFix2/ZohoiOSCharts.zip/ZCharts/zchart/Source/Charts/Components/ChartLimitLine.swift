//
//  ChartLimitLine.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics


/// The limit line is an additional feature for all Line, Bar and ScatterCharts.
/// It allows the displaying of an additional line in the chart that marks a certain maximum / limit on the specified axis (x- or y-axis).
open class ChartLimitLine: ComponentBase
{
    open var shapeProperties:ShapeProperties? = nil
    
    @objc(ChartLimitLabelPosition)
    public enum LabelPosition: Int
    {
        case leftTop
        case leftBottom
        case rightTop
        case rightBottom
        case centerTop
        case centerBottom
    }
    
    /// limit / maximum (the y-value or xIndex)
    open var limit = Double(0.0)
    
    fileprivate var _lineWidth = CGFloat(2.0)
    open var lineColor = NSUIColor(red: 237.0/255.0, green: 91.0/255.0, blue: 91.0/255.0, alpha: 1.0)
    open var lineDashPhase = CGFloat(0.0)
    open var lineDashLengths: [CGFloat]?
    
    open var valueTextColor = NSUIColor.black
    open var valueFont = NSUIFont.systemFont(ofSize: 13.0)
    
    open var drawLimitValueEnabled = true
    open var limitValueTextColor = NSUIColor.black
    open var limitValueFont = NSUIFont.systemFont(ofSize: 10.0)
    open var limitValueTruncateMode = CATextLayerTruncationMode.end
    
    open var drawLabelEnabled = true
    open var label = ""
    open var valueFormattor: LimitLineValueFormatter?
    open var labelPosition = LabelPosition.rightTop
    open var rotationAngle: Double = 0.0
    
    public override init()
    {
        super.init()
    }
    
    public init(limit: Double)
    {
        super.init()
        self.limit = limit
    }
    
    public init(limit: Double, label: String)
    {
        super.init()
        self.limit = limit
        self.label = label
    }
    
    /// set the line width of the chart (min = 0.2, max = 12); default 2
    open var lineWidth: CGFloat
    {
        get
        {
            return _lineWidth
        }
        set
        {
            if newValue < 0.2
            {
                _lineWidth = 0.2
            }
            else if newValue > 12.0
            {
                _lineWidth = 12.0
            }
            else
            {
                _lineWidth = newValue
            }
        }
    }
    
    // MARK: - Codable
    
        enum chartLimitLineCodingKeys: CodingKey {
            case drawLabelEnabled
            case drawLimitValueEnabled
            case mLabel
            case mLimit
            case mLineColor
            case mLineWidth
            case mTextColor
            case markerProperties
       }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            
            let container = try decoder.container(keyedBy: chartLimitLineCodingKeys.self)
            
            drawLabelEnabled = container.contains(.drawLabelEnabled) ? try container.decode(Bool.self, forKey: .drawLabelEnabled) : drawLabelEnabled
            
            drawLimitValueEnabled = container.contains(.drawLimitValueEnabled) ? try container.decode(Bool.self, forKey: .drawLimitValueEnabled) : drawLimitValueEnabled
            
            label = container.contains(.mLabel) ? try container.decode(String.self, forKey: .mLabel) : label
            
            limit = container.contains(.mLimit) ? try container.decode(Double.self, forKey: .mLimit) : limit
            
            let lineColorCode = container.contains(.mLineColor) ? try container.decode(Int.self, forKey: .mLineColor) : -1
            lineColor = lineColorCode == -1 ? lineColor : NSUIColor(rgb:lineColorCode)
            
            lineWidth = container.contains(.mLineWidth) ? try container.decode(CGFloat.self, forKey: .mLineWidth) : lineWidth
            
            let textColorCode = container.contains(.mTextColor) ? try container.decode(Int.self, forKey: .mTextColor) : -1
            valueTextColor = textColorCode == -1 ? valueTextColor : NSUIColor(rgb:textColorCode)
            limitValueTextColor = textColorCode == -1 ? limitValueTextColor : NSUIColor(rgb:textColorCode)
            shapeProperties = container.contains(.markerProperties) ? try container.decode(ShapeProperties.self, forKey: .markerProperties) : shapeProperties
        }
    
        public  override func encode(to encoder: Encoder) throws {
  
        }
    
    internal func getLimitValue(axis: AxisBase) -> String {
        
        var formattedString: String = String(limit)
        
        if axis.scaleType == .Time
        {
            let interValType =  (axis.scaleTypeProtocol as! TimeScale).currentType
            formattedString = axis.valueFormatter?.stringForValue?(limit, axis: axis, intervalType: interValType) ?? ""
        }
        else{
            formattedString = axis.valueFormatter?.stringForValue(limit, axis: axis) ?? ""
        }
        
        return valueFormattor?.getFormattedValue(value: limit, axis: axis) ?? formattedString
    }
    
    internal func getLimitValueSize(formattedString: String) -> CGSize {
        
        return formattedString.size(withAttributes: [NSAttributedString.Key.font: valueFont])
    }
}
