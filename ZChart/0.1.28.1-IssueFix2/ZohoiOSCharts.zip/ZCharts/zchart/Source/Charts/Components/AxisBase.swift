//
//  AxisBase.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc
public protocol CustomTicksDelegate
{
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text: String, chart: ChartViewBase) -> TickLayer
    
    func getTickSizeforEntry(axis:AxisBase, value: Double, chart: ChartViewBase) -> CGSize
}

/// Base class for all axes
@objc(ChartAxisBase)
open class AxisBase: ComponentBase
{
    public override init()
    {
        super.init()
    }
    
    open var axisTitleOffsets:textOffsets = textOffsets(marginLeft: 5, marginRight: 5, marginTop: 5, marginBotom: 5)
    
    open var axisLabelOffsets:textOffsets = textOffsets(marginLeft: 5, marginRight: 5, marginTop: 5, marginBotom: 5)
    
    //ticklabel modes
    public enum Mode{
        case auto
        case forced
        case wordwrap
    }
    
    public enum LabelAlignment {
        case right
        case left
        case center
    }
    
    
    open var customTickEnabled = false
    
    open weak var tickDelegate:CustomTicksDelegate? = nil
    
    open var tickLabelMode = Mode.auto
    
    /// width of the (rotated) x-axis labels in pixels - this is automatically calculated by the `computeSize()` methods in the renderers
    open var labelRotatedWidth = CGFloat(1.0)
    
    /// height of the (rotated) x-axis labels in pixels - this is automatically calculated by the `computeSize()` methods in the renderers
    open var labelRotatedHeight = CGFloat(1.0)
    
    /// Custom formatter that is used instead of the auto-formatter if set
    fileprivate var _axisValueFormatter: IAxisValueFormatter?
    
    open var labelFont = NSUIFont.systemFont(ofSize: 10.0)
    open var labelTextColor = NSUIColor.gray.withAlphaComponent(0.9)
    open var labelHighlightColor = NSUIColor.black
    open var labelHighlightFont:NSUIFont? = nil
    open var labelAlignment: LabelAlignment = .center
    
    /// This is the angle for drawing the X axis labels (in degrees)
    open var labelRotationAngle = CGFloat(0.0)
    
    
    open var axisTitleEnabled = true
    open var axisTitle = "None"
    open var axisTitleFont = NSUIFont.boldSystemFont(ofSize: 16)
    open var axisTitleColor = NSUIColor.black
    
    
    open var axisLineColor = NSUIColor.gray
    open var axisLineWidth = CGFloat(0.5)
    open var axisLineDashPhase = CGFloat(0.0)
    open var axisLineDashLengths: [CGFloat]!
    
    open var axisTickMarkColor = NSUIColor.gray
    open var axisTickMarkLineWidth = CGFloat(0.5)
    open var axisTickMarkSize = CGFloat(5.0)
    
    open var axisSubTickMarkColor = NSUIColor.gray
    open var axisSubTickMarkLineWidth = CGFloat(0.5)
    open var axisSubTickMarkSize = CGFloat(5.0)
    open var axisSubTickCount = 0
    
    open var gridColor = NSUIColor.gray.withAlphaComponent(0.3)
    open var gridLineWidth = CGFloat(0.5)
    open var gridLineDashPhase = CGFloat(0.0)
    open var gridLineDashLengths: [CGFloat]!
    open var gridLineCap = CGLineCap.butt
    
    open var drawGridLinesEnabled = true
    open var drawAxisLineEnabled = true
    
    /// the maximum width that the axis can take.
    /// use Infinity for disabling the maximum.
    ///
    /// **default**: CGFloat.infinity
    open var maxLabelWidth = CGFloat(CGFloat.infinity)
    
    /// flag to enable/disable baseline for the axis
    fileprivate var _baseLineEnabled = false
    
    open var autoRotateAngle:CGFloat = 60
    
    // To maintain maxLabelHeight
    open var maxLabelHeight:CGFloat = 60
    
    open var categoryOrder:[String]?
    
    open var baseLineEnabled: Bool
    {
        get { return _baseLineEnabled }
        set {
            if newValue == true && baseLine == nil
            {
                baseLine = ChartBaseLine()
            }
            else{
                baseLine = nil
            }
            _baseLineEnabled = newValue
        }
    }
    
    /// flag that indicates of the labels of this axis should be drawn or not
    open var drawLabelsEnabled = true
 
    /// flag that indicates of the last/bottom labels of this axis should be drawn or not
    open var drawBottomYLabelEntryEnabled = true
    
    open var isDrawBottomYLabelEntryEnabled: Bool { return drawBottomYLabelEntryEnabled }
    
    /// flag that indicates of the first/Top labels of this axis should be drawn or not
    open var drawTopYLabelEntryEnabled = true
    
    open var isDrawTopYLabelEntryEnabled: Bool { return drawTopYLabelEntryEnabled }
    
    /// flag that indicates of the labels of this axis should be drawn or not
    open var drawTickMarksEnabled = true
    
    open var drawSubTickMarksEnabled = true
    
    fileprivate var _centerAxisLabelsEnabled = false

    /// Centers the axis labels instead of drawing them at their original position.
    /// This is useful especially for grouped BarChart.
    open var centerAxisLabelsEnabled: Bool
    {
        get { return _centerAxisLabelsEnabled && entryCount > 0 }
        set { _centerAxisLabelsEnabled = newValue }
    }
    
    open var isCenterAxisLabelsEnabled: Bool
    {
        get { return centerAxisLabelsEnabled }
    }

    /// array of limitlines that can be set for the axis
    fileprivate var _limitLines = [ChartLimitLine]()
    
    /// Are the LimitLines drawn behind the data or in front of the data?
    /// 
    /// **default**: false
    open var drawLimitLinesBehindDataEnabled = false

    /// the flag can be used to turn off the antialias for grid lines
    open var gridAntialiasEnabled = true
    
    /// the actual array of entries
    open var entries = [Double]()
    
    /// axis label entries only used for centered labels
    open var centeredEntries = [Double]()
    
    /// the number of entries the legend contains
    open var entryCount: Int { return entries.count }
    
    /// the number of label entries the axis should have
    ///
    /// **default**: 6
    fileprivate var _labelCount =  6
    
    /// the number of decimal digits to use (for the default formatter
    open var decimals: Int = 0
    
    /// When true, axis labels are controlled by the `granularity` property.
    /// When false, axis values could possibly be repeated.
    /// This could happen if two adjacent axis values are rounded to same value.
    /// If using granularity this could be avoided by having fewer axis values visible.
    open var granularityEnabled = false
    
    fileprivate var _granularity = Double(1.0)
    
    /// The minimum interval between axis values.
    /// This can be used to avoid label duplicating when zooming in.
    ///
    /// **default**: 1.0
    open var granularity: Double
    {
        get
        {
            return _granularity
        }
        set
        {
            _granularity = newValue
            
            // set this to `true` if it was disabled, as it makes no sense to set this property with granularity disabled
            granularityEnabled = true
        }
    }
    
    /// The minimum interval between axis values.
    open var isGranularityEnabled: Bool
    {
        get
        {
            return granularityEnabled
        }
    }
    
    /// if true, the set number of y-labels will be forced
    open var forceLabelsEnabled = false
    
    open var interval:Double? = nil
    
    open func getLongestLabelFromEntries() -> String
    {
        var longest = ""
        
        let labelAttrs = [NSAttributedString.Key.font: self.labelFont]
        
        for i in 0 ..< entries.count
        {
            let text = getFormattedLabel(i)
            
            if longest.size(withAttributes: labelAttrs).width < text.size(withAttributes: labelAttrs).width
            {
                longest = text
            }
        }
        
        return longest
    }
    
    /*open func getLongestLabelOfAllData(entryCount:Int) -> String
    {
        var longest = ""
        
        for i in 0 ..< entryCount
        {
            var text = valueFormatter?.stringForValue(Double(i), axis: self) ?? ""
            
            if self.scaleType == .Time
            {
                let interValType = (self.scaleTypeProtocol as! TimeScale).currentType
                text = (self.valueFormatter?.stringForValue!(Double(i), axis: self, intervalType: interValType))!
            }
            
            if longest.characters.count < text.characters.count
            {
                longest = text
            }
        }
        
        return longest
    }*/
    
    /// - returns: The formatted label at the specified index. This will either use the auto-formatter or the custom formatter (if one is set).
    open func getFormattedLabel(_ index: Int) -> String
    {
        
        var tickLabel = ""
        
        if index < 0 || index >= entries.count
        {
            return tickLabel
        }
        
        if scaleType == .Time {
            if let intervalType = (scaleTypeProtocol as? TimeScale)?.currentType {
                tickLabel = valueFormatter?.stringForValue?(entries[index], axis: self, intervalType: intervalType) ?? ""
            }
        }
        else {
            tickLabel = valueFormatter?.stringForValue(entries[index], axis: self) ?? ""
        }
        
        return tickLabel
    }
    
    /// Sets the formatter to be used for formatting the axis labels.
    /// If no formatter is set, the chart will automatically determine a reasonable formatting (concerning decimals) for all the values that are drawn inside the chart.
    /// Use `nil` to use the formatter calculated by the chart.
    open var valueFormatter: IAxisValueFormatter?
    {
        get
        {
            if _axisValueFormatter == nil ||
                (_axisValueFormatter is DefaultAxisValueFormatter &&
                    (_axisValueFormatter as! DefaultAxisValueFormatter).hasAutoDecimals &&
                    (_axisValueFormatter as! DefaultAxisValueFormatter).decimals != decimals)
            {
                _axisValueFormatter = DefaultAxisValueFormatter(decimals: decimals)
            }
            
            return _axisValueFormatter
        }
        set
        {
            _axisValueFormatter = newValue ?? DefaultAxisValueFormatter(decimals: decimals)
        }
    }
    
    open var isDrawGridLinesEnabled: Bool { return drawGridLinesEnabled }
    
    open var isDrawAxisLineEnabled: Bool { return drawAxisLineEnabled }
    
    open var isDrawLabelsEnabled: Bool { return drawLabelsEnabled }
    
    /// Are the LimitLines drawn behind the data or in front of the data?
    /// 
    /// **default**: false
    open var isDrawLimitLinesBehindDataEnabled: Bool { return drawLimitLinesBehindDataEnabled }
    
    /// Extra spacing for `axisMinimum` to be added to automatically calculated `axisMinimum`
    open var spaceMin: Double = 0.0
    
    /// Extra spacing for `axisMaximum` to be added to automatically calculated `axisMaximum`
    open var spaceMax: Double = 0.0
    
    /// Extra spacing for `axisMinimum` to be added to automatically calculated `axisMinimum`
    open var spaceMinPixel: Double = 0.0
    
    /// Extra spacing for `axisMaximum` to be added to automatically calculated `axisMaximum`
    open var spaceMaxPixel: Double = 0.0

    /// Flag indicating that the axis-min value has been customized
    internal var _customAxisMin: Double?
    
    /// Flag indicating that the axis-max value has been customized
    internal var _customAxisMax: Double?
    
    /// Holds forced axis-min value internally
    internal var _forcedAxisMinimum: Double?
    
    /// Holds forced axis-max value internally
    internal var _forcedAxisMaximum: Double?
    
    /// Do not touch this directly, instead, use axisMinimum.
    /// This is automatically calculated to represent the real min value,
    /// and is used when calculating the effective minimum.
    internal var _axisMinimum = Double(0)
    
    /// Do not touch this directly, instead, use axisMaximum.
    /// This is automatically calculated to represent the real max value,
    /// and is used when calculating the effective maximum.
    internal var _axisMaximum = Double(0)
    
    /// the total range of values this axis covers
    open var axisRange = Double(0)
    
    /// the number of label entries the axis should have
    /// max = 25,
    /// min = 2,
    /// default = 6,
    /// be aware that this number is not fixed and can only be approximated
    open var labelCount: Int
    {
        get
        {
            return _labelCount
        }
        set
        {
            _labelCount = newValue
            
            if _labelCount > ChartUtils.Constants.maxLabelCount
            {
                _labelCount = ChartUtils.Constants.maxLabelCount
            }
            if _labelCount < ChartUtils.Constants.minLabelCount
            {
                _labelCount = ChartUtils.Constants.minLabelCount
            }
            
            forceLabelsEnabled = false
        }
    }
    
    open func setLabelCount(_ count: Int, force: Bool)
    {
        self.labelCount = count
        forceLabelsEnabled = force
    }
    
    /// - returns: `true` if focing the y-label count is enabled. Default: false
    open var isForceLabelsEnabled: Bool { return forceLabelsEnabled }
    
    /// Adds a new ChartLimitLine to this axis.
    open func addLimitLine(_ line: ChartLimitLine)
    {
        _limitLines.append(line)
    }
    
    /// Removes the specified ChartLimitLine from the axis.
    open func removeLimitLine(_ line: ChartLimitLine)
    {
        for i in 0 ..< _limitLines.count
        {
            if _limitLines[i] === line
            {
                _limitLines.remove(at: i)
                return
            }
        }
    }
    
    /// Removes all LimitLines from the axis.
    open func removeAllLimitLines()
    {
        _limitLines.removeAll(keepingCapacity: false)
    }
    
    /// - returns: The LimitLines of this axis.
    open var limitLines : [ChartLimitLine]
    {
        return _limitLines
    }
    
    open var baseLine: ChartBaseLine?
    
    open var visible:Bool = true
    
    open var isVisible: Bool {
        get {
           return visible
        }
    }
    
    // MARK: Custom axis ranges
    
    internal func setAxis(minimum: Double) {
        _axisMinimum = convert(toOriginal: false, value: minimum)
        axisRange = abs(_axisMaximum - _axisMinimum)
    }
    
    internal func setAxis(maximum: Double) {
        _axisMaximum = convert(toOriginal: false, value: maximum)
        axisRange = abs(_axisMaximum - _axisMinimum)
    }
    
    /// By calling this method, any custom minimum value that has been previously set is reseted, and the calculation is done automatically.
    open func resetCustomAxisMin()
    {
        _customAxisMin = nil
    }
    
    open var isAxisMinCustom: Bool { return _customAxisMin != nil }
    
    /// By calling this method, any custom maximum value that has been previously set is reseted, and the calculation is done automatically.
    open func resetCustomAxisMax()
    {
        _customAxisMax = nil
    }
    
    open var isAxisMaxCustom: Bool { return _customAxisMax != nil }
    
    /// This property is deprecated - Use `axisMinimum` instead.
    @available(*, deprecated: 1.0, message: "Use axisMinimum instead.")
    open var axisMinValue: Double
    {
        get { return axisMinimum }
        set { axisMinimum = newValue }
    }
    
    /// This property is deprecated - Use `axisMaximum` instead.
    @available(*, deprecated: 1.0, message: "Use axisMaximum instead.")
    open var axisMaxValue: Double
    {
        get { return axisMaximum }
        set { axisMaximum = newValue }
    }
    
    /// The minimum value for this axis.
    /// If set, this value will not be calculated automatically depending on the provided data.
    /// Use `resetCustomAxisMin()` to undo this.
    open var axisMinimum: Double
    {
        get
        {
            return convert(toOriginal: true, value: _axisMinimum)
        }
        set
        {
            _axisMinimum = convert(toOriginal: false, value: newValue)
            _customAxisMin = _axisMinimum
            axisRange = abs(_axisMaximum - newValue)
        }
    }
    
    /// The maximum value for this axis.
    /// If set, this value will not be calculated automatically depending on the provided data.
    /// Use `resetCustomAxisMax()` to undo this.
    open var axisMaximum: Double
    {
        get
        {
            return convert(toOriginal: true, value: _axisMaximum)
        }
        set
        {
            _axisMaximum = convert(toOriginal: false, value: newValue)
            _customAxisMax = _axisMaximum
            axisRange = abs(newValue - _axisMinimum)
        }
    }
    
    open func getMinMaxWithLimitValues(min:Double, max:Double) -> (min: Double, max:Double)
    {
        var min = min
        var max = max
        for limitLine in self.limitLines where limitLine.isEnabled {
            
            let limitLineValue = convert(toOriginal: false, value: limitLine.limit)
            if limitLineValue > max {
                max = limitLineValue + spaceMax
            }
            
            if limitLineValue < min {
                min = limitLineValue - spaceMin
            }
        }
        
        return (min,max)
    }
    
    func convert(min: Double, max: Double) -> (Double,Double) {
        
        var (min,max) = (min,max)
        
        switch scaleType {
            case .Log:
                if let logScale = scaleTypeProtocol as? LogScale {
                    min = ChartUtils.biSymmetricLogTransformation(base: logScale.Base, x: min)
                    max = ChartUtils.biSymmetricLogTransformation(base: logScale.Base, x: max)
                }
                break
            case .SQRT:
                min = ChartUtils.squareRoot(value: min)
                max = ChartUtils.squareRoot(value: max)
                break
            default: break
        }
        
        return (min,max)
    }
    
    func convert(toOriginal: Bool, value: Double) -> Double {
        
        var val = value
        
        switch scaleType {
            case .Log:
                if let logScale = scaleTypeProtocol as? LogScale {
                    val = toOriginal ? ChartUtils.biSymmetricAntiLogTransformation(base: logScale.Base, y: val) : ChartUtils.biSymmetricLogTransformation(base: logScale.Base, x: val)
                }
                break
            case .SQRT:
                val = toOriginal ? ChartUtils.square(value: val) : ChartUtils.squareRoot(value: val)
                break
            default: break
        }
        
        return val
    }
    
    func minAndMaxForRangeZero(value: Double) -> (Double,Double) {
        
        var max = value
        var min = value
        
        (min,max) = convert(min: min, max: max)
        
        let pow =   ChartUtils.doubleToIntSafeCast(value:ceil(log10(min <= 0 ? 1 : min)))
        max = max + Double(10 ^^ pow)
        min = min - Double(10 ^^ pow)
        
        return (min,max)
    }
    
    /// Calculates the minimum, maximum and range values of the YAxis with the given minimum and maximum values from the chart data.
    /// - parameter dataMin: the y-min value according to chart data
    /// - parameter dataMax: the y-max value according to chart
    open func calculate(min dataMin: Double, max dataMax: Double)
    {
        var (min,max) = convert(min: dataMin, max: dataMax)
        
        // if custom, use value as is, else use data value
        min = _customAxisMin != nil ? _customAxisMin ?? 0.0 : (min - spaceMin)
        max = _customAxisMax != nil ? _customAxisMax ?? 0.0 : (max + spaceMax)
        
        // temporary range (before calculations)
        let range = abs(max - min)
        
        // in case all values are equal
        if range == 0.0
        {
            (min,max) = minAndMaxForRangeZero(value: dataMin)
        }
        
        (min,max) = getMinMaxWithLimitValues(min: min, max: max)
        
        _axisMinimum = min
        _axisMaximum = max
        
        // actual range
        axisRange = abs(max - min)
    }
    
    /// flag that indicates if the axis is inverted or not
    open var inverted = false
    
    open var isInverted: Bool { return inverted }
    
    open var scaleTypeProtocol:ScaleTypeProtocol = LinearScale()
    
    open var scaleType:ScaleType = .Linear {
        didSet {
            self.scaleTypeProtocol = AxisBase.getScaleFromType(scaleType)
        }
    }
    
    internal static func getScaleFromType(_ type: ScaleType) -> ScaleTypeProtocol
    {
        switch type
        {
            case .Linear:
                return LinearScale()
            case .Time:
                return TimeScale()
            case .Ordinal:
                return OrdinalScale()
            case .Log:
                return LogScale()
            case .SQRT:
                return SQRTScale()
        }
    }
    
    open func setTimeScaleType(type:TimeScaleType,forcedType:TimeScaleIntervalType?)
    {
        ((self.scaleTypeProtocol) as! TimeScale).timeScaleType = type
        if type == .Forced
        {
            ((self.scaleTypeProtocol) as! TimeScale).currentType = forcedType!
        }
        
    }
    
    // MARK: - limitLine offset
    
    internal func limitLineLabeloffset(limitLineType: LimitLineType) -> Double {
        
        var offset = 0.0
        
        for limitLine in limitLines {
            
            guard limitLine.enabled && limitLine.drawLimitValueEnabled else {
                continue
            }
            
            let limitLabel = limitLine.getLimitValue(axis: self)
            let limitLabelSize = limitLine.getLimitValueSize(formattedString: limitLabel)
            
            if limitLineType == .vertical {
                offset = max(offset, limitLabelSize.height)
            }
            else {
                offset = max(offset, limitLabelSize.width)
            }
        }
        
        return offset
    }
    
    // MARK: - Codable
    
    enum axisBaseCodingKeys: CodingKey {
            case mAxisMinimum
            case mAxisMaximum
            case visible
            case isDrawTickMark
            case tickMarkSize
            case mInverted
            case mGridColor
            case mGridLineWidth
            case mAxisLineColor
            case mAxisLineWidth
            case mLabelCount
            case mDrawGridLines
            case mDrawAxisLine
            case mDrawLabels
            case mTextColor
            case mLimitLines
            case scaleType
            case axisTitle
            case drawAxisTitle
            case customCategoryOrder
            case maxTickWidth
            case mTextSize
            case labelOffset
            case axisOffset
            case labelCountType
            case maxTickHeight
            case tickType
            case mSpaceMin
            case mSpaceMax
       }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            
            let isQAAutomation = decoder.userInfo[ChartViewBase.qaUserInfoKey]
            
            if (isQAAutomation != nil)
            {
                let container = try decoder.container(keyedBy: axisBaseCodingKeys.self)
                
                if container.contains(.mAxisMaximum)
                {
                    axisMaximum = try container.decode(Double.self, forKey: .mAxisMaximum)
                }
                if container.contains(.mAxisMinimum)
                {
                    axisMinimum = try container.decode(Double.self, forKey: .mAxisMinimum)
                }
                
                
                visible = container.contains(.visible) ? try container.decode(Bool.self, forKey: .visible) : visible
                drawTickMarksEnabled = container.contains(.isDrawTickMark) ? try container.decode(Bool.self, forKey: .isDrawTickMark) : drawTickMarksEnabled
                axisTickMarkSize = container.contains(.tickMarkSize) ? try container.decode(CGFloat.self, forKey: .tickMarkSize) : axisTickMarkSize
                inverted = container.contains(.mInverted) ? try container.decode(Bool.self, forKey: .mInverted) : inverted
                
                let gridColorCode = container.contains(.mGridColor) ? try container.decode(Int.self, forKey: .mGridColor) : -1
                gridColor = gridColorCode == -1 ? gridColor : NSUIColor(rgb:gridColorCode)
                
                gridLineWidth = container.contains(.mGridLineWidth) ? try container.decode(CGFloat.self, forKey: .mGridLineWidth) : gridLineWidth
                
                let axisLineColorCode = container.contains(.mAxisLineColor) ? try container.decode(Int.self, forKey: .mAxisLineColor) : -1
                axisLineColor = axisLineColorCode == -1 ? axisLineColor : NSUIColor(rgb:axisLineColorCode)
                
                let labelColorCode = container.contains(.mTextColor) ? try container.decode(Int.self, forKey: .mTextColor) : -1
                labelTextColor = labelColorCode == -1 ? labelTextColor : NSUIColor(rgb:labelColorCode)
                axisTitleColor = labelColorCode == -1 ? axisTitleColor : NSUIColor(rgb:labelColorCode)
                
                axisLineWidth = container.contains(.mAxisLineWidth) ? try container.decode(CGFloat.self, forKey: .mAxisLineWidth) : axisLineWidth
                labelCount = container.contains(.mLabelCount) ? try container.decode(Int.self, forKey: .mLabelCount) : labelCount
                drawGridLinesEnabled = container.contains(.mDrawGridLines) ? try container.decode(Bool.self, forKey: .mDrawGridLines) : drawGridLinesEnabled
                drawAxisLineEnabled = container.contains(.mDrawAxisLine) ? try container.decode(Bool.self, forKey: .mDrawAxisLine) : drawTickMarksEnabled
                drawLabelsEnabled = container.contains(.mDrawLabels) ? try container.decode(Bool.self, forKey: .mDrawLabels) : drawLabelsEnabled
                _limitLines = container.contains(.mLimitLines) ? try container.decode([ChartLimitLine].self, forKey: .mLimitLines) : limitLines
                let scaleTypeString = container.contains(.scaleType) ? try container.decode(String.self, forKey: .scaleType) : "ORDINAL"
                switch scaleTypeString {
                    case "ORDINAL":
                        scaleType = .Ordinal
                        break
                        
                    case "LINEAR","POLAR_LINEAR":
                        scaleType = .Linear
                        break
                        
                    case "DATETIME":
                        self.scaleType = .Time
                        break
                        
                    default:
                        scaleType = .Ordinal
                        break
                }
                self.scaleTypeProtocol = AxisBase.getScaleFromType(scaleType)
                
                axisTitle = container.contains(.axisTitle) ? try container.decode(String.self, forKey: .axisTitle) : axisTitle
                axisTitleEnabled = container.contains(.drawAxisTitle) ? try container.decode(Bool.self, forKey: .drawAxisTitle) : axisTitleEnabled
                categoryOrder = container.contains(.customCategoryOrder) ? try container.decode([String].self, forKey: .customCategoryOrder) : categoryOrder
                if categoryOrder != nil
                {
                    granularityEnabled = true
                    granularity = 1
                }
                
                maxLabelWidth = container.contains(.maxTickWidth) ? try container.decode(CGFloat.self, forKey: .maxTickWidth) : maxLabelWidth
                
                maxLabelHeight = container.contains(.maxTickHeight) ? try container.decode(CGFloat.self, forKey: .maxTickHeight) : maxLabelHeight
                
    //            labelFont = container.contains(.mTextSize) ? labelFont.withSize(try container.decode(CGFloat.self, forKey: .mTextSize)) : labelFont
                
                var tempOffset = container.contains(.labelOffset) ? try container.decode(textOffsets.self, forKey: .labelOffset) : axisLabelOffsets
                axisLabelOffsets.marginTop = tempOffset.marginTop
                axisLabelOffsets.marginBotom = tempOffset.marginBotom
                axisLabelOffsets.marginLeft = tempOffset.marginLeft
                axisLabelOffsets.marginRight = tempOffset.marginRight
                
                tempOffset =  container.contains(.axisOffset) ? try container.decode(textOffsets.self, forKey: .axisOffset) : axisTitleOffsets
                axisTitleOffsets.marginTop = tempOffset.marginTop
                axisTitleOffsets.marginBotom = tempOffset.marginBotom
                axisTitleOffsets.marginLeft = tempOffset.marginLeft
                axisTitleOffsets.marginRight = tempOffset.marginRight
                
                let labelMode = container.contains(.labelCountType) ? try container.decode(String.self, forKey: .labelCountType) : "AUTO"
                
                switch labelMode {
                    case "AUTO":
                        tickLabelMode = .auto
                        
                    case "FORCED":
                        tickLabelMode = .forced
                        
                    case "WORD_WRAP":
                        tickLabelMode = .wordwrap
                       
                    default:
                        tickLabelMode = .auto
                }
                
                customTickEnabled = try container.decode(String.self, forKey: .tickType) == "CUSTOM" ? true : false
                
                spaceMinPixel = try container.decode(Double.self, forKey: .mSpaceMin)
                
                spaceMaxPixel = try container.decode(Double.self, forKey: .mSpaceMax)
                
            }
            else
            {
                
                let container = try decoder.container(keyedBy: axisBaseCodingKeys.self)
                
                if container.contains(.mAxisMaximum)
                {
                    _axisMaximum = try container.decode(Double.self, forKey: .mAxisMaximum)
                }
                if container.contains(.mAxisMinimum)
                {
                    _axisMinimum = try container.decode(Double.self, forKey: .mAxisMinimum)
                }
                
                
                visible = container.contains(.visible) ? try container.decode(Bool.self, forKey: .visible) : visible
                drawTickMarksEnabled = container.contains(.isDrawTickMark) ? try container.decode(Bool.self, forKey: .isDrawTickMark) : drawTickMarksEnabled
                axisTickMarkSize = container.contains(.tickMarkSize) ? try container.decode(CGFloat.self, forKey: .tickMarkSize) : axisTickMarkSize
                inverted = container.contains(.mInverted) ? try container.decode(Bool.self, forKey: .mInverted) : inverted
                
                let gridColorCode = container.contains(.mGridColor) ? try container.decode(Int.self, forKey: .mGridColor) : -1
                gridColor = gridColorCode == -1 ? gridColor : NSUIColor(rgb:gridColorCode)
                
                gridLineWidth = container.contains(.mGridLineWidth) ? try container.decode(CGFloat.self, forKey: .mGridLineWidth) : gridLineWidth
                
                let axisLineColorCode = container.contains(.mAxisLineColor) ? try container.decode(Int.self, forKey: .mAxisLineColor) : -1
                axisLineColor = axisLineColorCode == -1 ? axisLineColor : NSUIColor(rgb:axisLineColorCode)
                
                let labelColorCode = container.contains(.mTextColor) ? try container.decode(Int.self, forKey: .mTextColor) : -1
                labelTextColor = labelColorCode == -1 ? labelTextColor : NSUIColor(rgb:labelColorCode)
                axisTitleColor = labelColorCode == -1 ? axisTitleColor : NSUIColor(rgb:labelColorCode)
                
                axisLineWidth = container.contains(.mAxisLineWidth) ? try container.decode(CGFloat.self, forKey: .mAxisLineWidth) : axisLineWidth
                labelCount = container.contains(.mLabelCount) ? try container.decode(Int.self, forKey: .mLabelCount) : labelCount
                drawGridLinesEnabled = container.contains(.mDrawGridLines) ? try container.decode(Bool.self, forKey: .mDrawGridLines) : drawGridLinesEnabled
                drawAxisLineEnabled = container.contains(.mDrawAxisLine) ? try container.decode(Bool.self, forKey: .mDrawAxisLine) : drawTickMarksEnabled
                drawLabelsEnabled = container.contains(.mDrawLabels) ? try container.decode(Bool.self, forKey: .mDrawLabels) : drawLabelsEnabled
                _limitLines = container.contains(.mLimitLines) ? try container.decode([ChartLimitLine].self, forKey: .mLimitLines) : limitLines
                let scaleTypeString = container.contains(.scaleType) ? try container.decode(String.self, forKey: .scaleType) : "ORDINAL"
                switch scaleTypeString {
                    case "ORDINAL":
                        scaleType = .Ordinal
                        break
                        
                    case "LINEAR","POLAR_LINEAR":
                        scaleType = .Linear
                        break
                        
                    case "DATETIME":
                        self.scaleType = .Time
                        break
                        
                    default:
                        scaleType = .Ordinal
                        break
                }
                self.scaleTypeProtocol = AxisBase.getScaleFromType(scaleType)
                
                axisTitle = container.contains(.axisTitle) ? try container.decode(String.self, forKey: .axisTitle) : axisTitle
                axisTitleEnabled = container.contains(.drawAxisTitle) ? try container.decode(Bool.self, forKey: .drawAxisTitle) : axisTitleEnabled
                categoryOrder = container.contains(.customCategoryOrder) ? try container.decode([String].self, forKey: .customCategoryOrder) : categoryOrder
                if categoryOrder != nil
                {
                    granularityEnabled = true
                    granularity = 1
                }
                
                maxLabelWidth = container.contains(.maxTickWidth) && !(try! container.decodeNil(forKey: .maxTickWidth)) ? try container.decode(CGFloat.self, forKey: .maxTickWidth) : maxLabelWidth
                
                maxLabelHeight = container.contains(.maxTickHeight) && !(try! container.decodeNil(forKey: .maxTickHeight)) ? try container.decode(CGFloat.self, forKey: .maxTickHeight) : maxLabelHeight
                
        //            labelFont = container.contains(.mTextSize) ? labelFont.withSize(try container.decode(CGFloat.self, forKey: .mTextSize)) : labelFont
                
                var tempOffset = container.contains(.labelOffset) ? try container.decode(textOffsets.self, forKey: .labelOffset) : axisLabelOffsets
                axisLabelOffsets.marginTop = tempOffset.marginTop
                axisLabelOffsets.marginBotom = tempOffset.marginBotom
                axisLabelOffsets.marginLeft = tempOffset.marginLeft
                axisLabelOffsets.marginRight = tempOffset.marginRight
                
                tempOffset =  container.contains(.axisOffset) ? try container.decode(textOffsets.self, forKey: .axisOffset) : axisTitleOffsets
                axisTitleOffsets.marginTop = tempOffset.marginTop
                axisTitleOffsets.marginBotom = tempOffset.marginBotom
                axisTitleOffsets.marginLeft = tempOffset.marginLeft
                axisTitleOffsets.marginRight = tempOffset.marginRight
                
                let labelMode = container.contains(.labelCountType) ? try container.decode(String.self, forKey: .labelCountType) : "AUTO"
                
                switch labelMode {
                    case "AUTO":
                        tickLabelMode = .auto
                        
                    case "FORCED":
                        tickLabelMode = .forced
                        
                    case "WORD_WRAP":
                        tickLabelMode = .wordwrap
                       
                    default:
                        tickLabelMode = .auto
                }
                
                customTickEnabled = try container.decode(String.self, forKey: .tickType) == "CUSTOM" ? true : false
                
                spaceMinPixel = try container.decode(Double.self, forKey: .mSpaceMin)
                
                spaceMaxPixel = try container.decode(Double.self, forKey: .mSpaceMax)
                
            }
            
            
        }
        public  override func encode(to encoder: Encoder) throws {
  
        }

    open var longestLabel:String = ""
  
    var longestSize:CGSize = CGSize.zero
   
    var storedFontSize:[String:CGSize] = [:]
   
    func resetLongestLabelProps() {
        longestLabel = ""
        longestSize = CGSize.zero
        storedFontSize.removeAll()
    }
    
   func updateLongest(text:String,labelAttrs: [NSAttributedString.Key : Any] )  {
       let textSize = getStoredSize(text: text, labelAttrs: labelAttrs)
       if (longestSize.width < textSize.width) {
           longestLabel = text
           longestSize = textSize
       }
   }
  
    func getStoredSize(text:String, labelAttrs: [NSAttributedString.Key : Any]) -> CGSize {
      
      var size:CGSize = CGSize.zero
      
      if (storedFontSize[text] == nil){
          size = text.size(withAttributes: labelAttrs)
          storedFontSize[text] = size
      }
      
      size = storedFontSize[text]!
      
      return size
  }
   
   open func getFormattedValue(value:Double) -> String {
       var text = ""
       if scaleType == .Time
       {
           let interValType = (scaleTypeProtocol as! TimeScale).currentType
           text = (valueFormatter?.stringForValue?(value, axis: self, intervalType: interValType)) ?? String(value)
       }else{
           text = valueFormatter?.stringForValue(value, axis: self) ?? ""
       }
       return text
   }
}

extension AxisBase {
    
    func getParaStyle() -> NSMutableParagraphStyle {
        #if os(OSX)
        let paraStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        #else
        let paraStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        #endif
        paraStyle.alignment = .center
        return paraStyle
    }
    
    internal func getlabelAttribus() -> [NSAttributedString.Key:NSObject] {
        
        let paraStyle = getParaStyle()
        
        if !(tickLabelMode == .wordwrap){
            paraStyle.lineBreakMode = .byTruncatingTail
        }
        
        return [NSAttributedString.Key.font: labelFont, NSAttributedString.Key.foregroundColor: labelTextColor,NSAttributedString.Key.paragraphStyle: paraStyle]
    }
    
    internal func computeMaxTickSize(maxSize: inout CGSize, isVerticalAxis: Bool) {
        
        let labelSize = longestLabel.size(withAttributes: [NSAttributedString.Key.font: labelHighlightFont ?? labelFont])
        
        if  isVerticalAxis {
            
            let rotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: labelRotationAngle)

            if labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360
            {
                if rotatedSize.width > maxLabelWidth{
                    
                    var restictedTextWidth = abs( maxLabelWidth / cos(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                    
                    let height = restictedTextWidth *
                    sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD)

                    if height > maxLabelHeight{
                        restictedTextWidth = sqrt(maxLabelWidth * maxLabelWidth + maxLabelHeight * maxLabelHeight)
                    }
                    
                    maxSize.width = restictedTextWidth
                }
                else if rotatedSize.height > maxLabelHeight{
                    
                    var restictedTextWidth = abs( maxLabelHeight / sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                    
                    let width = restictedTextWidth * cos(labelRotationAngle * ChartUtils.Math.FDEG2RAD)

                    if width > maxLabelWidth{
                        
                        restictedTextWidth = sqrt(maxLabelWidth * maxLabelWidth + maxLabelHeight * maxLabelHeight)
                    }
                    
                    maxSize.width = restictedTextWidth
                }
            }
            else{
                maxSize.width = labelRotatedWidth
            }
        }
        else {
            
            if labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360
            {
                let rotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: labelRotationAngle)
                
                let height = (rotatedSize.height < maxLabelHeight) ? rotatedSize.height : maxLabelHeight
                
                maxSize.width = abs( height / sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
            }
            else {
                maxSize.width = labelRotatedWidth
            }
        }
    }
}

open class TickModel: NSObject {
    public var label:String = ""
    
    public var value:Double = 0
    
    public var point:CGPoint = CGPoint.zero
    
    public var opacity: CGFloat = 1.0
    
    internal static func createTickPosition(axis: AxisBase, axisEntryIndex: Int, axisTickPosition: CGPoint) -> TickModel {
        
        let tickPosition = TickModel()
        
        tickPosition.label = axis.getFormattedLabel(axisEntryIndex)
        
        tickPosition.value = axis.entries[axisEntryIndex]
        
        tickPosition.point = axisTickPosition
        
        return tickPosition
    }
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = TickModel()
        
        copy.label = label
        
        copy.value = value
        
        copy.point = point
        
        copy.opacity = opacity
        
        return copy
    }
}

open class TickLabel: TickModel
{
    public var constrainedSize:CGSize = CGSize.zero
    
    public var angleInRadians:CGFloat = 0
    
    public var attributes: [NSAttributedString.Key: NSObject] = [:]
    
    public var anchorPoint:CGPoint = CGPoint.zero
    
    public var boundPath = CGMutablePath() //UIBezierPath()
    
#if os(iOS) || os(tvOS)
    public var stringDrawingOption:NSStringDrawingOptions = .usesLineFragmentOrigin
#else
    public var stringDrawingOption:NSString.DrawingOptions = .usesLineFragmentOrigin
#endif
    
    open  func getRectOfMultilineText(text: String, knownTextSize: CGSize, point: CGPoint, attributes: [NSAttributedString.Key : AnyObject]?, constrainedToSize: CGSize, anchor: CGPoint, angleRadians: CGFloat) -> (CGRect,CGPoint)
    {
        var rect = CGRect(origin: CGPoint(), size: knownTextSize)
        
        var translate = point
        
        if angleRadians != 0.0
        {
            
            let angleDegree = angleRadians * ChartUtils.Math.FRAD2DEG
            
            let rotatedSize = ChartUtils.sizeOfRotatedRectangle(knownTextSize, radians: angleRadians)
            
            translate.x -= rotatedSize.width * (anchor.x - 0.5)
            
            if angleDegree > 0 && angleDegree <= 90
            {
                let angle = (90 + angleDegree) * ChartUtils.Math.FDEG2RAD
                
                let x = point.x + (knownTextSize.height/2) * cos(angle)
                
                translate.x += (point.x - x)
                
            }
            else if angleDegree > 90 && angleDegree <= 180
            {
                let angle = (360 - (180 - angleDegree + 90)) * ChartUtils.Math.FDEG2RAD
                
                let x = point.x + (knownTextSize.height/2) * cos(angle)
                
                let y = point.y + (knownTextSize.height) * sin(angle)
                
                translate.x += (point.x - x)
                translate.y += (point.y - y)
                
            }
            else if angleDegree > 180 && angleDegree <= 270
            {
                
                let x = point.x + (knownTextSize.width) * cos(angleRadians)
                
                let anotherAngle = (360 - (270-angleDegree)) * ChartUtils.Math.FDEG2RAD
                
                let x1 = x + (knownTextSize.height/2) * cos(anotherAngle)
                
                let y = point.y + (knownTextSize.width) * sin(angleRadians)
                
                let y1 = y + (knownTextSize.height) * sin(anotherAngle)
                
                translate.x += (point.x - x1)
                translate.y += (point.y - y1)
                
            }
            else if angleDegree > 270 && angleDegree < 360{
                
                let x = point.x + (knownTextSize.width) * cos(angleRadians)
                
                let anotherAngle = (90 - (90 - (angleDegree - 270))) * ChartUtils.Math.FDEG2RAD
                
                let x1 = x + (knownTextSize.height/2) * cos(anotherAngle)
                
                let y = point.y + (knownTextSize.width) * sin(angleRadians)
                
                translate.x -= (x1 - point.x)
                translate.y += (point.y - y)
            }
        }
        else
        {
            if anchor.x != 0.0 || anchor.y != 0.0
            {
                rect.origin.x = -knownTextSize.width * anchor.x
                rect.origin.y = -knownTextSize.height * anchor.y
            }
            
            rect.origin.x += point.x
            rect.origin.y += point.y
        }
  
        return (rect,translate)
    }
    
    open func getRectOfMultilineText(text: String, point: CGPoint, attributes: [NSAttributedString.Key : AnyObject]?, constrainedToSize: CGSize, anchor: CGPoint, angleRadians: CGFloat) -> (CGRect,CGPoint)
    {
        let rect = text.boundingRect(with: constrainedToSize, options: stringDrawingOption, attributes: attributes, context: nil)
        return getRectOfMultilineText(text: text, knownTextSize: rect.size, point: point, attributes: attributes, constrainedToSize: constrainedToSize, anchor: anchor, angleRadians: angleRadians)
    }
    
    open func updateTickBounds()
    {
        var (textRect,textPoint) = getRectOfMultilineText(text: label, point: point, attributes: attributes, constrainedToSize: constrainedSize, anchor: anchorPoint, angleRadians: angleInRadians)
        
        if angleInRadians != 0
        {
            textRect.origin = textPoint
        }
        let center = CGPoint(x:textPoint.x, y:textPoint.y)
                
           /* let bexPath = UIBezierPath(rect: textRect)
            
            let center = CGPoint(x:textPoint.x, y:textPoint.y)
            
            let toOrigin =  CGAffineTransform(translationX: -center.x, y: -center.y)
            bexPath.apply(toOrigin)
            
            
            let rotation = CGAffineTransform(rotationAngle: angleInRadians )
            bexPath.apply(rotation)
            
            
            let fromOrigin = CGAffineTransform(translationX: center.x, y: center.y)
            bexPath.apply(fromOrigin)*/
        
            var transform = CGAffineTransform(translationX: -center.x, y: -center.y)
        
            transform = transform.concatenating(CGAffineTransform(rotationAngle: angleInRadians))
        
            transform = transform.concatenating(CGAffineTransform(translationX: center.x, y: center.y))
        
            let bexPath = CGMutablePath()
            bexPath.addRect(textRect, transform: transform)
        
        boundPath = bexPath
        
    }
    
    /*func createTickLayer() -> CAShapeLayer
    {
        
        var (textRect,textPoint) = getRectOfMultilineText(text: label, point: point, attributes: attributes, constrainedToSize: constrainedSize, anchor: anchorPoint, angleRadians: angleInRadians)
     
        if angleInRadians != 0
        {
            textRect.origin = textPoint
        }
        
        let bexPath = UIBezierPath(rect: textRect)
        
        let center = CGPoint(x:textPoint.x, y:textPoint.y)
        
        let toOrigin =  CGAffineTransform(translationX: -center.x, y: -center.y)
        bexPath.apply(toOrigin)
        
        
        let rotation = CGAffineTransform(rotationAngle: angleInRadians)
        bexPath.apply(rotation)
        
        
        let fromOrigin = CGAffineTransform(translationX: center.x, y: center.y)
        bexPath.apply(fromOrigin)
        

        let textLay = CAShapeLayer()
        textLay.path = bexPath.cgPath
        textLay.strokeColor = NSUIColor.blue.cgColor
        textLay.lineWidth = 1
        textLay.fillColor = NSUIColor.clear.cgColor
        return textLay

    }*/
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = TickLabel()
        
        copy.label = label
        
        copy.value = value
        
        copy.point = point
        
        copy.constrainedSize = constrainedSize
        
        copy.angleInRadians = angleInRadians
        
        copy.anchorPoint = anchorPoint
        
        copy.attributes = attributes
        
        copy.stringDrawingOption = stringDrawingOption
        
        copy.opacity = opacity
        
            return copy
    }
    
}

extension TickLabel {
    
    internal static func createTickModel(axis: AxisBase, axisEntryIndex: Int, axisTickPosition: CGPoint = .zero, constrainedToSize: CGSize, anchorPoint: CGPoint = CGPoint(x: 0.5, y: 0.5)) -> TickLabel {
        
        let labelAttributes = axis.getlabelAttribus()
        
        let text = axis.getFormattedLabel(axisEntryIndex)
        
        #if os(iOS) || os(tvOS)
        var options: NSStringDrawingOptions = [.usesLineFragmentOrigin]
        #else
        var options: NSString.DrawingOptions = [.usesLineFragmentOrigin]
        #endif
        
        if axis.tickLabelMode == .wordwrap{
            options = [.usesLineFragmentOrigin,.truncatesLastVisibleLine]
        }
        
        let tickLabel = TickLabel()
        
        tickLabel.label = text
        
        tickLabel.value = axis.entries[axisEntryIndex]
        
        tickLabel.point = axisTickPosition
        
        tickLabel.constrainedSize = constrainedToSize
        
        tickLabel.angleInRadians = axis.labelRotationAngle * ChartUtils.Math.FDEG2RAD
        
        tickLabel.anchorPoint = anchorPoint
        
        tickLabel.attributes = labelAttributes
        
        tickLabel.stringDrawingOption = options
        
        return tickLabel
        
    }
}


open class TickLayer:CALayer
{
    open var tickValue:Double = 0
    
    open var tickPosition:CGPoint = CGPoint.zero
    
    open var tickSize:CGSize = CGSize.zero
    
    open var tickAnchor:CGPoint = CGPoint.zero
    
}

internal enum LimitLineType {
    case vertical
    case horizontal
}
