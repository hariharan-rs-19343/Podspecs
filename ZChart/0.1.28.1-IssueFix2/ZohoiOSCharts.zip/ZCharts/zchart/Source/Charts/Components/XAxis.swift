//
//  XAxis.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(ChartXAxis)
open class XAxis: AxisBase
{
    @objc(XAxisLabelPosition)
    public enum LabelPosition: Int
    {
        case top
        case bottom
        case bothSided
        case topInside
        case bottomInside
    }
    
    /// width of the x-axis labels in pixels - this is automatically calculated by the `computeSize()` methods in the renderers
    open var labelWidth = CGFloat(1.0)
    
    /// height of the x-axis labels in pixels - this is automatically calculated by the `computeSize()` methods in the renderers
    open var labelHeight = CGFloat(1.0)
    

    /// if set to true, the chart will avoid that the first and last label entry in the chart "clip" off the edge of the chart
    open var avoidFirstLastClippingEnabled = false
    
    /// the position of the x-labels relative to the chart
    open var labelPosition = LabelPosition.bottom
    
    /// if set to true, word wrapping the labels will be enabled.
    /// word wrapping is done using `(value width * labelRotatedWidth)`
    ///
    /// - note: currently supports all charts except pie/radar/horizontal-bar*
//    open var wordWrapEnabled = false
    
    /// - returns: `true` if word wrapping the labels is enabled
//    open var isWordWrapEnabled: Bool { return wordWrapEnabled }
    
    // To maintain auto rotation angle
//    open var autoRotateEnabled = true
    
    /// the width for wrapping the labels, as percentage out of one value width.
    /// used only when isWordWrapEnabled = true.
    /// 
    /// **default**: 1.0
    open var wordWrapWidthPercent: CGFloat = 1.0
    
    open var maxRangeToShow: Double = -Double.greatestFiniteMagnitude
    open var minRangeToShow: Double = Double.greatestFiniteMagnitude
    
    public override init()
    {
        super.init()
        
        self.yOffset = 4.0
        
        self.labelCount = 15
        
#if os(iOS) || os(tvOS)
        let currentDeviceName = UIDevice.current.name
        if let _ = currentDeviceName.range(of: "IPAD", options: .caseInsensitive) {
            self.labelCount = 25
        }
#endif

    }
    
    open var isAvoidFirstLastClippingEnabled: Bool
    {
        return avoidFirstLastClippingEnabled
    }
    
    // MARK: - Codable
    
        enum xAxisCodingKeys: CodingKey {
           
            case rotationAngle
            case mAvoidFirstLastClipping
            case mPosition

           }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            
            let container = try decoder.container(keyedBy: xAxisCodingKeys.self)
            
            labelRotationAngle = container.contains(.rotationAngle) ? try container.decode(CGFloat.self, forKey: .rotationAngle) : labelRotationAngle
            
            avoidFirstLastClippingEnabled = container.contains(.mAvoidFirstLastClipping) ? try container.decode(Bool.self, forKey: .mAvoidFirstLastClipping) : avoidFirstLastClippingEnabled
            
            let labelPositionValue = container.contains(.mPosition) ? try container.decode(String.self, forKey: .mPosition) : "BOTTOM"
            
            switch labelPositionValue {
                case "BOTTOM":
                    labelPosition = .bottom
                    
                case "BOTTOM_INSIDE":
                    labelPosition = .bottom
                    
                case "TOP":
                    labelPosition = .top
                    
                case "TOP_INSIDE":
                    labelPosition = .topInside
                    
                default:
                    labelPosition = .bothSided
            }
            

        }
    
    public  override func encode(to encoder: Encoder) throws {

        }
}

extension XAxis {
    
    internal func computeMaxTickSize(maxSize: inout CGSize, isRotated: Bool) {
        if tickLabelMode == .wordwrap
        {
            maxSize = longestSize
            return
        }
        
        if isRotated {
            
            super.computeMaxTickSize(maxSize: &maxSize, isVerticalAxis: true)

            if !(labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360)
            {
                let widthOffSet = axisTitleEnabled ? (axisTitle).size(withAttributes: [NSAttributedString.Key.font:axisTitleFont]).height : 0
                maxSize.width -= widthOffSet
            }
        }
        else {
            super.computeMaxTickSize(maxSize: &maxSize, isVerticalAxis: false)
        }
    }
    
    internal func getAnchorForAxisTickLabel(isRotated: Bool, labelPosition: LabelPosition? = nil) -> CGPoint {
        
        let labelPosition = labelPosition ?? self.labelPosition
        
        var point: CGPoint = CGPoint(x: 0.0, y: 0.0)
        
        switch labelPosition {
            case .top:
                point = isRotated ? CGPoint(x: 0.5, y: 0.5) : CGPoint(x: 0.5, y: 0.0)
            case .topInside:
                point = isRotated ? CGPoint(x: 1.0, y: 0.5) : CGPoint(x: 0.5, y: 1.0)
            case .bottom:
                point = isRotated ? CGPoint(x: 0.5, y: 0.5) : CGPoint(x: 0.5, y: 0.0)
            case .bottomInside:
                point = isRotated ? CGPoint(x: 0.0, y: 0.5) : CGPoint(x: 0.5, y: 0.0)
            default: break
        }
        
        return point
    }
    
    internal func getFixedPositionForAxisTickLabel(isRotated: Bool, viewPortHandler: ViewPortHandler) -> CGFloat {
        
        let labelPosition = labelPosition
        
        var fixedPosition: CGFloat = 0.0
        
        switch labelPosition {
            case .top,.topInside:
                fixedPosition = isRotated ? viewPortHandler.contentRight : viewPortHandler.contentTop
            case .bottom,.bottomInside:
                fixedPosition = isRotated ? viewPortHandler.contentLeft : viewPortHandler.contentBottom
            default:
                break
        }
        
        return fixedPosition
    }
    
    internal func fixedPosition( isRotated: Bool, viewPortHandler: ViewPortHandler, tickLabelSize: CGSize) -> CGFloat {
        
        let fixedPosition: CGFloat = getFixedPositionForAxisTickLabel(isRotated: isRotated, viewPortHandler: viewPortHandler)
        
        let labelPosition = labelPosition
        
        let heightOffSet = axisTitleEnabled ? (axisTitle).size(withAttributes: [NSAttributedString.Key.font:axisTitleFont]).height : 0
        
        if isRotated {
            
            let widthOffSet = labelRotatedWidth - heightOffSet
            
            var alignmentPosition = 0.0
            let labelHeight = labelRotationAngle != 0 && labelRotationAngle != 360 ? longestSize.height / 2.0 : 0.0
            
            switch labelAlignment {
                case .left:
                alignmentPosition = labelPosition == .bottom ? widthOffSet - tickLabelSize.width / 2.0 + labelHeight : tickLabelSize.width / 2.0
                    break
                case .right:
                alignmentPosition = labelPosition == .bottom ? tickLabelSize.width / 2.0 : widthOffSet - tickLabelSize.width / 2.0 + labelHeight
                    break
                case .center:
                alignmentPosition = widthOffSet / 2.0
                    break
            }
            
            if labelPosition == .top
            {
                return fixedPosition + axisLabelOffsets.marginLeft + alignmentPosition
            }
            else if labelPosition == .topInside
            {
                return fixedPosition - axisLabelOffsets.marginRight
            }
            else if labelPosition == .bottom
            {
                return fixedPosition - axisLabelOffsets.marginRight - alignmentPosition
            }
            else if labelPosition == .bottomInside
            {
                return fixedPosition + axisLabelOffsets.marginLeft
            }
        }
        else {
            
            if labelPosition == .top
            {
                var heightToAdd = (labelRotationAngle == 0) ? labelFont.lineHeight : min( (labelRotatedHeight - heightOffSet),maxLabelHeight)
                
                if tickLabelMode == .wordwrap{
                    heightToAdd = labelRotatedHeight - heightOffSet
                }
                
                return fixedPosition - axisLabelOffsets.marginBotom - heightToAdd
            }
            else if labelPosition == .topInside
            {
                return fixedPosition + axisLabelOffsets.marginTop + (labelRotatedHeight - heightOffSet)
            }
            else if labelPosition == .bottom
            {
                return fixedPosition + axisLabelOffsets.marginTop
            }
            else if labelPosition == .bottomInside
            {
                return fixedPosition - axisLabelOffsets.marginBotom - (labelRotatedHeight - heightOffSet)
            }
        }
        
        return fixedPosition
        
    }
        
    internal func calculateOffsetForFixed(position: CGPoint, axisTickPosition: inout CGPoint, tickLabelSize: CGSize, isRotated: Bool, viewPortHandler: ViewPortHandler) {
        
        if isRotated {
            
            axisTickPosition.y = position.y
            
            axisTickPosition.x = fixedPosition(isRotated: isRotated, viewPortHandler: viewPortHandler, tickLabelSize: tickLabelSize)
        }
        else {
            
            axisTickPosition.x = position.x
            
            axisTickPosition.y = fixedPosition(isRotated: isRotated, viewPortHandler: viewPortHandler, tickLabelSize: tickLabelSize)
        }
    }
}
