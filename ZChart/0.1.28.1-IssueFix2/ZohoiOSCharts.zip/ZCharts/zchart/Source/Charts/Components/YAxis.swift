//
//  YAxis.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


/// Class representing the y-axis labels settings and its entries.
/// Be aware that not all features the YLabels class provides are suitable for the RadarChart.
/// Customizations that affect the value range of the axis need to be applied before setting data for the chart.
@objc(ChartYAxis)
open class YAxis: AxisBase
{
    @objc(YAxisLabelPosition)
    public enum LabelPosition: Int
    {
        case outsideChart
        case insideChart
    }
    
    ///  Enum that specifies the axis a DataSet should be plotted against, either Left or Right.
    @objc
    public enum AxisDependency: Int
    {
        case left
        case right
    }
    
//    open var longestLabel = " "
    
    open var resizeEnabled:Bool = false
    
//    /// flag that indicates if the axis is inverted or not
//    open var inverted = false ///Moved to AxisBase to support inversion for X axis
    
    /// flag that indicates if the zero-line should be drawn regardless of other grid lines
    open var drawZeroLineEnabled = false
    
    /// Color of the zero line
    open var zeroLineColor: NSUIColor? = NSUIColor.gray
    
    /// Width of the zero line
    open var zeroLineWidth: CGFloat = 1.0
    
    /// This is how much (in pixels) into the dash pattern are we starting from.
    open var zeroLineDashPhase = CGFloat(0.0)
    
    /// This is the actual dash pattern.
    /// I.e. [2, 3] will paint [--   --   ]
    /// [1, 3, 4, 2] will paint [-   ----  -   ----  ]
    open var zeroLineDashLengths: [CGFloat]?

    /// axis space from the largest value to the top in percent of the total axis range
    open var spaceTop = CGFloat(0.1)

    /// axis space from the smallest value to the bottom in percent of the total axis range
    open var spaceBottom = CGFloat(0.1)
    
    /// the position of the y-labels relative to the chart
    open var labelPosition = LabelPosition.outsideChart
    
    /// the side this axis object represents
    fileprivate var _axisDependency = AxisDependency.left
    
    /// the minimum width that the axis should take
    ///
    /// **default**: 0.0
    open var minWidth = CGFloat(0)
    
    
    /// forced to use the maximum label width as axis fixed label width
    /// instead of calculating the width dynamically
    open var forceMaxLabelWidth:Bool = false
    
    /// (proper) offset need to be re-calculated when multiple left or right enabled
    open var offsetCalculated:CGFloat = 0.0
    
    var _axisIndex:Int = 0
    
    open var titleFrame:CGRect = CGRect.zero
    
    public override init()
    {
        super.init()
        
        self.yOffset = 0.0
    }
    
    public init(position: AxisDependency)
    {
        super.init()
        
        _axisDependency = position
        
        self.yOffset = 0.0
    }
    
    open var axisDependency: AxisDependency
    {
        set {
         _axisDependency = newValue
        }
        get {
         return _axisDependency
        }
    }
    
    open var axisIndex:Int
    {
        set {
            _axisIndex = newValue
        }
        get {
            return _axisIndex
        }
    }
    
    open func requiredSize() -> CGSize
    {
        
        longestLabel = self.scaleType == .Ordinal ? longestLabel : getLongestLabelFromEntries()
        
        let labelAttrs = [NSAttributedString.Key.font: labelHighlightFont ?? labelFont]
        
        var labelSize = longestLabel.size(withAttributes: labelAttrs)
        
        var maxLabelWidth = self.maxLabelWidth
        
        var isHeightInfinity = false
        
        if maxLabelHeight == .infinity{
            maxLabelHeight = 0
            isHeightInfinity = true
        }
        
        var labelRotatedSize = CGSize()
        
        switch tickLabelMode{
            
        case .auto:
            //label width is less then requried maxlabel width (horizontal case)
            
            labelRotationAngle = 0
            
            labelRotatedSize = labelSize
            /*
            //rotation case
            if labelSize.width > maxLabelWidth
            {
                labelRotationAngle = autoRotateAngle
                
                labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: labelRotationAngle)
                    
                if labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360
                {
                        if labelRotatedSize.width > maxLabelWidth{
                            var restictedTextWidth = abs( maxLabelWidth / cos(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                            let height = restictedTextWidth * sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD)
                        
                            if height > maxLabelHeight{
                                restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (maxLabelHeight * maxLabelHeight))
                            }
                        
                            labelRotatedSize.width = restictedTextWidth
                        }
//                    let computedheight = labelRotatedSize.width * sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD)
                    
                                else if labelRotatedSize.height > maxLabelHeight{
                        
                        var restictedTextWidth = abs( maxLabelHeight / sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                        
                        let width = restictedTextWidth * cos(labelRotationAngle * ChartUtils.Math.FDEG2RAD)

                        if width > maxLabelWidth{
                            
                            restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (maxLabelHeight * maxLabelHeight))
                        }
                        
                        labelRotatedSize.width = restictedTextWidth
                    }
                    
                    let longestTick = computeLongestTickLabel(MaxLabelSize: CGSize(width: labelRotatedSize.width, height: 0),angle: labelRotationAngle)
                
                    labelRotatedSize = longestTick.boundPath.boundingBox.size//.bounds.size
                    
                }
                else{
                    //width restiction
                    labelRotatedSize.width = maxLabelWidth
                }
            }
            else{
                //width restiction
                if maxLabelWidth != .infinity{
                    labelRotatedSize.width = maxLabelWidth
                }
            }
            */
            
            if labelSize.width > maxLabelWidth && maxLabelWidth > 0 {
                labelRotatedSize.width = maxLabelWidth
            }
            
            break
            
        case .forced:
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: labelRotationAngle)
                
            if labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360
            {
                    if labelRotatedSize.width > maxLabelWidth{
                        var restictedTextWidth = abs( maxLabelWidth / cos(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                        let height = restictedTextWidth * sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD)
                    
                        if height > maxLabelHeight{
                            restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (maxLabelHeight * maxLabelHeight))
                        }
                    
                        labelRotatedSize.width = restictedTextWidth
                    }
                
//                let computedheight = labelRotatedSize.width * sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD)
                
                else if labelRotatedSize.height > maxLabelHeight{
                    
                    var restictedTextWidth = abs( maxLabelHeight / sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                    
                    let width = restictedTextWidth * cos(labelRotationAngle * ChartUtils.Math.FDEG2RAD)

                    if width > maxLabelWidth{
                        
                        restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (maxLabelHeight * maxLabelHeight))
                    }
                    
                    labelRotatedSize.width = restictedTextWidth
                }
                
                let longestTick = computeLongestTickLabel(MaxLabelSize: CGSize(width: labelRotatedSize.width, height: 0),angle: labelRotationAngle)
            
                labelRotatedSize = longestTick.boundPath.boundingBox.size//.bounds.size
                
                if maxLabelWidth == .infinity && isHeightInfinity{
                    labelRotatedSize.height = .infinity
                    maxLabelHeight = .infinity
                }
                
            }
            else{

                //width restiction

                if labelSize.width > maxLabelWidth{
                    labelRotatedSize.width = maxLabelWidth
                }

            }
            break
            
        case .wordwrap:
            
            var labelMaxSize = CGSize()
            
            if maxLabelWidth <= 0 || maxLabelWidth > labelSize.width{
                maxLabelWidth = labelSize.width
            }
            
            labelMaxSize.width = maxLabelWidth
            
            // calculate rect constrained to max width
            let rect = longestLabel.boundingRect(with: labelMaxSize, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: labelAttrs, context: nil)
            
            // To maintain space between axis line and bottom
            labelSize = rect.size
            
            labelMaxSize = rect.size
            
            if labelMaxSize.height > maxLabelHeight
            {
                labelMaxSize.height = maxLabelHeight
                
                labelSize.height = labelMaxSize.height
            }
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelMaxSize, degrees: labelRotationAngle)
            
            break
        }
       
        longestSize = labelSize
        labelRotatedWidth = labelRotatedSize.width
        labelRotatedHeight =  labelRotatedSize.height
        
        var size = CGSize.zero
        
        let offSetToAdd = (axisLabelOffsets.marginLeft + axisLabelOffsets.marginRight)   //xOffset * 2.0
        
        let maxWidthWithOffset = self.maxLabelWidth + offSetToAdd
        
        if self.drawLabelsEnabled {
            
            size = labelRotatedSize//longestLabel.size(withAttributes: [NSAttributedString.Key.font: labelFont])
            
            size.width += offSetToAdd
            
            size.height += (axisLabelOffsets.marginTop + axisLabelOffsets.marginBotom)  //yOffset * 2.0
            
            size.width = max(minWidth, size.width/*min(size.width,maxWidthWithOffset)*/)
            
            if self.forceMaxLabelWidth && self.maxLabelWidth != CGFloat.infinity {
                size.width = max(minWidth ,maxWidthWithOffset)
            }
            
        }
        
        if self.limitLines.count > 0 {
            size.width = min(max(size.width, limitLineLabeloffset(limitLineType: .horizontal) + offSetToAdd), maxWidthWithOffset)
        }
        
        if self.axisTitleEnabled {
            
            let axisTitleSize =  (self.axisTitle).size(withAttributes: [NSAttributedString.Key.font:self.axisTitleFont])
            
            size.height += axisTitleSize.height
            size.width += axisTitleSize.height//Need to provide height of axis Title after rotated in 90 deg
            size.width += (axisTitleOffsets.marginLeft + axisTitleOffsets.marginRight)
            size.height += (axisTitleOffsets.marginTop + axisTitleOffsets.marginBotom)
            
        }
        
        return size
    }
    
    open func getRequiredHeightSpace(constrainedWidth:CGFloat, onePointWidth: CGFloat = 0.0, scaleX: CGFloat) -> CGFloat
    {
        
        longestLabel = self.scaleType == .Ordinal ? longestLabel : getLongestLabelFromEntries()
        
        let labelAttrs = [NSAttributedString.Key.font: labelHighlightFont ?? labelFont]
        
        var labelSize = longestLabel.size(withAttributes: labelAttrs)
        
        var labelRotatedSize = CGSize()
        
        if maxLabelHeight <= 0{
            maxLabelHeight = labelSize.height
        }
        
        let isOrdinalScale = scaleType == .Ordinal
        
        switch tickLabelMode{
            
        case .auto:
            //label width is less then requried maxlabel width (horizontal case)
            
            labelRotationAngle = 0
            
            labelRotatedSize = labelSize
            
            let width = labelSize.width.isZero || labelSize.width.isNaN ? 1.0 : labelSize.width
            let scaleX = scaleX.isZero ? 1.0 : scaleX
            
            //rotation case
            if isOrdinalScale && (labelRotatedSize.width > onePointWidth || ceil(axisRange / scaleX) > floor(constrainedWidth / width)) || !isOrdinalScale && entries.count > ChartUtils.doubleToIntSafeCast(value: floor(constrainedWidth / width))
            {
                
                let rotatedLabelSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: autoRotateAngle)
                
                if round(abs(labelSize.width * cos(autoRotateAngle * ChartUtils.Math.FDEG2RAD))) <= round(labelSize.width) {
                    
                    labelRotationAngle = autoRotateAngle
                    
                    labelRotatedSize = rotatedLabelSize
                    
                    if labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360
                    {
                        
                        //height restiction
                        if labelRotatedSize.height > maxLabelHeight {
                            let longestTick = computeLongestTickLabel(MaxLabelSize: CGSize(width: abs( maxLabelHeight / sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD) ), height: 0),angle: labelRotationAngle)
                            
                            labelRotatedSize = longestTick.boundPath.boundingBox.size//.bounds.size
                        }
                        
                    }
                    else{
                        //width restiction
                        if maxLabelWidth >= 0 {
                            labelRotatedSize.width = maxLabelWidth
                        }
                    }
                }
            }
            
            break
            
        case .forced:
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: labelRotationAngle)
            
            //height restiction
            
            let height = (labelRotatedSize.height < maxLabelHeight) ? labelRotatedSize.height : maxLabelHeight
            
            if maxLabelWidth == .infinity{
                labelRotatedSize.width = maxLabelWidth
                labelRotatedSize.height = height
                break
            }
                
            if labelRotationAngle != 0 && labelRotationAngle != 180 && labelRotationAngle != 360
            {
                if labelRotatedSize.height > maxLabelHeight {
                    
                    let longestTick = computeLongestTickLabel(MaxLabelSize: CGSize(width: abs( maxLabelHeight / sin(labelRotationAngle * ChartUtils.Math.FDEG2RAD) ), height: 0),angle: labelRotationAngle)
                    
                    labelRotatedSize = longestTick.boundPath.boundingBox.size//.bounds.size
                }
            }
            else{

                //width restiction
                if labelSize.width > maxLabelWidth && maxLabelWidth != 0 {
                    labelRotatedSize.width = maxLabelWidth
                }

            }
            
            break
            
        case .wordwrap:
            
            var labelMaxSize = CGSize()
            
            if maxLabelWidth <= 0 || maxLabelWidth > labelSize.width{
                maxLabelWidth = labelSize.width
            }
            
            labelMaxSize.width = maxLabelWidth
            
            // calculate rect constrained to max width
            let rect = longestLabel.boundingRect(with: labelMaxSize, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: labelAttrs, context: nil)
            
            // To maintain space between axis line and bottom
            labelSize = rect.size
            
            labelMaxSize = rect.size
            
            if labelMaxSize.height > maxLabelHeight
            {
                labelMaxSize.height = maxLabelHeight
                
                labelSize.height = labelMaxSize.height
            }
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelMaxSize, degrees: labelRotationAngle)
            
            break
        }
        
        longestSize = labelSize
        
        labelRotatedWidth = labelRotatedSize.width
        labelRotatedHeight = labelRotatedSize.height
        
        /*
        var size = CGSize.zero
        
        let maxWidthRequired = CGFloat(entries.count) * size.width
        
        if constrainedWidth < maxWidthRequired
        {
            self.labelRotationAngle = autoRotateAngle
            var labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(size, degrees: autoRotateAngle)
            
            if labelRotatedSize.height > self.maxLabelHeight
            {
                labelRotatedSize = CGSize(width: CGFloat.greatestFiniteMagnitude, height: self.maxLabelHeight)
            }
            
            return requiredSize().height - size.height + labelRotatedSize.height
        }*/
        
        var size = CGSize.zero
        
        if self.drawLabelsEnabled {
            
//            let offSetToAdd = (axisLabelOffsets.marginTop + axisLabelOffsets.marginBotom)   //xOffset * 2.0
            
            let maxWidthWithOffset = self.maxLabelWidth //+ offSetToAdd
            
            size = labelRotatedSize//longestLabel.size(withAttributes: [NSAttributedString.Key.font: labelFont])
            
            size.height += (axisLabelOffsets.marginTop + axisLabelOffsets.marginBotom)  //yOffset * 2.0
            
            size.width = max(minWidth, size.width/*min(size.width,maxWidthWithOffset)*/)
            
            if self.forceMaxLabelWidth && self.maxLabelWidth != CGFloat.infinity {
                size.width = max(minWidth ,maxWidthWithOffset)
            }
            
        }
        
        if self.limitLines.count > 0 {
            size.height = min(size.height, limitLineLabeloffset(limitLineType: .vertical) + (axisLabelOffsets.marginTop + axisLabelOffsets.marginBotom))
        }
        
        if self.axisTitleEnabled {
            
            let axisTitleSize =  (self.axisTitle).size(withAttributes: [NSAttributedString.Key.font:self.axisTitleFont])
            
            size.height += axisTitleSize.height
            size.width += axisTitleSize.height//Need to provide height of axis Title after rotated in 90 deg
            size.width += (axisTitleOffsets.marginLeft + axisTitleOffsets.marginRight)
            size.height += (axisTitleOffsets.marginTop + axisTitleOffsets.marginBotom)
            
        }
    
        return size.height
    }
    
    /// - returns: `true` if this axis needs horizontal offset, `false` ifno offset is needed.
    var needsOffset: Bool
    {
        if isEnabled && isVisible && (isDrawLabelsEnabled || axisTitleEnabled) && labelPosition == .outsideChart
        {
            return true
        }
        else
        {
            return false
        }
    }
    
//    open var isInverted: Bool { return inverted } Moved to AxisBase to support inversion for X axis
    
  /*  open override func calculate(min dataMin: Double, max dataMax: Double)
    {
        // if custom, use value as is, else use data value
        var min = _customAxisMin ? _axisMinimum  : dataMin - spaceMin
        var max = _customAxisMax ? _axisMaximum  : dataMax + spaceMax
        
        // Invalid data cases
        // If all null
        // Bar won't come in this case since min and max will be changed to 0.
        if min == Double.greatestFiniteMagnitude && max == -(Double.greatestFiniteMagnitude)
        {
            min = -1
            max = 1
        }
        else if min == Double.greatestFiniteMagnitude
        {
            min = max - 1
        }
        else if max == -(Double.greatestFiniteMagnitude)
        {
            max = min + 1
        }
        
        
        // temporary range (before calculations)
        var range = abs(max - min)
        
        
        // in case all values are equal
        if range == 0.0
        {
            //Need to check for transformer issue with old method
            
            if  min == 0
            {
                min = _customAxisMin ? min : -1
                max = _customAxisMax ? max : 1
            }
            else{
                if min > 0 {
                    max = _customAxisMax ? max : 2 * min
                    min = _customAxisMin ? min : 0
                }else {
                    max = _customAxisMax ? max : 0
                    min = _customAxisMin ? min : 2 * min
                }
            }
            
            range = abs(max - min)
        }
        
        (min,max) = getMinMaxWithLimitValues(min: min, max: max)
        
        range = abs(max - min)
        
        let pixelPaddingEnabled = spaceMinPixel != 0 && spaceMaxPixel != 0 && dataMin != dataMax
        
        // bottom-space only effects non-custom min
        if !_customAxisMin && !pixelPaddingEnabled
        {
            let bottomSpace = range * Double(spaceBottom)
            min = (min - bottomSpace)
        }
        
        // top-space only effects non-custom max
        if !_customAxisMax && !pixelPaddingEnabled
        {
            let topSpace = range * Double(spaceTop)
            max = (max + topSpace)
        }
        
        _axisMinimum = min
        _axisMaximum = max
        
        
        
        // calc actual range
        axisRange = abs(_axisMaximum - _axisMinimum)
    }*/
    
    open override func calculate(min dataMin: Double, max dataMax: Double)
    {
        var (min,max) = convert(min: dataMin, max: dataMax)
        
        // if custom, use value as is, else use data value
        min = min - spaceMin
        max = max + spaceMax
        
        // Invalid data cases
        // If all null
        // Bar won't come in this case since min and max will be changed to 0.
        if min == Double.greatestFiniteMagnitude && max == -(Double.greatestFiniteMagnitude)
        {
            min = -1
            max = 1
        }
        else if min == Double.greatestFiniteMagnitude
        {
            min = max - 1
        }
        else if max == -(Double.greatestFiniteMagnitude)
        {
            max = min + 1
        }
        
        
        // temporary range (before calculations)
        var range = abs(max - min)
        
        
        // in case all values are equal
        if range == 0.0
        {
            //Need to check for transformer issue with old method
            
            (min,max) = minAndMaxForRangeZero(value: dataMin)
            
            range = abs(max - min)
        }
        
        (min,max) = getMinMaxWithLimitValues(min: min, max: max)
        
        range = abs(max - min)
        
        let pixelPaddingEnabled = spaceMinPixel != 0 && spaceMaxPixel != 0 && dataMin != dataMax
        
        // bottom-space only effects non-custom min
        if  !pixelPaddingEnabled
        {
            let bottomSpace = range * Double(spaceBottom)
            min = (min - bottomSpace)
            
            let topSpace = range * Double(spaceTop)
            max = (max + topSpace)
        }
        
        if _customAxisMin != nil {
            _axisMinimum = _customAxisMin ?? 0.0
        }
        else {
            _axisMinimum = min
        }
        
        if _customAxisMax != nil {
            _axisMaximum = _customAxisMax ?? 0.0
        }
        else {
            _axisMaximum = max
        }

        // calc actual range
        axisRange = abs(_axisMaximum - _axisMinimum)
    }
    
    // MARK: - Codable
    
        enum yAxisCodingKeys: CodingKey {
           
            case axisIndex
            case mDrawBottomYLabelEntry
            case mDrawTopYLabelEntry
            case mSpacePercentTop
            case mSpacePercentBottom
            case mLabelPosition
            case mAxisDependency
           }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            
            let container = try decoder.container(keyedBy: yAxisCodingKeys.self)
            
            axisIndex = container.contains(.axisIndex) ? try container.decode(Int.self, forKey: .axisIndex) : axisIndex
            
            drawBottomYLabelEntryEnabled = container.contains(.mDrawBottomYLabelEntry) ? try container.decode(Bool.self, forKey: .mDrawBottomYLabelEntry) : drawBottomYLabelEntryEnabled
            
            drawTopYLabelEntryEnabled = container.contains(.mDrawTopYLabelEntry) ? try container.decode(Bool.self, forKey: .mDrawTopYLabelEntry) : drawTopYLabelEntryEnabled
            
            spaceTop = container.contains(.mSpacePercentTop) ? (try container.decode(CGFloat.self, forKey: .mSpacePercentTop))/100 : spaceTop
            
            spaceBottom = container.contains(.mSpacePercentBottom) ? (try container.decode(CGFloat.self, forKey: .mSpacePercentBottom))/100 : spaceBottom
            
            let labelPositionValue = container.contains(.mLabelPosition) ? try container.decode(String.self, forKey: .mLabelPosition) : "OUTSIDE_CHART"
            
            switch labelPositionValue {
                case "OUTSIDE_CHART":
                    labelPosition = .outsideChart
                default:
                    labelPosition = .outsideChart
            }
            
            let axisDependent = container.contains(.mAxisDependency) ? try container.decode(String.self, forKey: .mAxisDependency) : "LEFT"
            
            switch axisDependent {
                case "LEFT":
                    axisDependency = .left
                case "RIGHT":
                    axisDependency = .right
                default:
                    axisDependency = .left
            }
            
        }
    
    public  override func encode(to encoder: Encoder) throws {

        }

}

precedencegroup PowerPrecedence { higherThan: MultiplicationPrecedence }
infix operator ^^ : PowerPrecedence
func ^^ (radix: Int, power: Int) -> Double {
    return pow(Double(radix), Double(power))
}

extension YAxis{
    
    func computeLongestTickLabel(MaxLabelSize: CGSize,angle: CGFloat) -> TickLabel{
            
            let labelFont = self.labelHighlightFont ?? self.labelFont
            
            let paraStyle = getParaStyle()
            
            if tickLabelMode != .wordwrap{
                paraStyle.lineBreakMode = .byTruncatingTail
            }
            
            let labelAttrs = [NSAttributedString.Key.font: labelFont,
                              NSAttributedString.Key.paragraphStyle: paraStyle]
            
            let labelRotationAngleRadians = angle * ChartUtils.Math.FDEG2RAD
        
            let longestTickLabel = TickLabel()
            
            longestTickLabel.label = longestLabel
            
            longestTickLabel.constrainedSize = MaxLabelSize
            
            longestTickLabel.angleInRadians = labelRotationAngleRadians
            
            longestTickLabel.attributes = labelAttrs
        
            longestTickLabel.updateTickBounds()
        
            return longestTickLabel
            
        }
    
    internal func computeMaxTickSize(maxSize: inout CGSize, isRotated: Bool) {
        
        if tickLabelMode == .wordwrap
        {
            maxSize = longestSize
            return
        }
        
        if isRotated {
            super.computeMaxTickSize(maxSize: &maxSize, isVerticalAxis: false)
        }
        else {
            super.computeMaxTickSize(maxSize: &maxSize, isVerticalAxis: true)
        }
    }
    
    internal func getFixedPositionForAxisTickLabel(isRotated: Bool, viewPortHandler: ViewPortHandler) -> CGFloat {
        return isRotated ? (axisDependency == .left ? viewPortHandler.contentTop : viewPortHandler.contentBottom) + offsetCalculated : (axisDependency == .left ? viewPortHandler.offsetLeft : viewPortHandler.contentRight) + offsetCalculated
    }
    
    internal func calculateOffsetForFixed(position: CGPoint, tickLabelSize: CGSize, axisTickPosition: inout CGPoint, isRotated: Bool, viewPortHandler: ViewPortHandler) {
        
        let fixedPosition: CGFloat = getFixedPositionForAxisTickLabel(isRotated: isRotated, viewPortHandler: viewPortHandler)
        
        if isRotated {
            
            axisTickPosition.x = position.x
            
            if axisDependency == .left
            {
                
                var heightToAdd = labelRotationAngle == 0 ? labelFont.lineHeight : min(labelRotatedHeight,maxLabelHeight)
                
                if tickLabelMode == .wordwrap{
                    heightToAdd = labelRotatedHeight
                }
                
                axisTickPosition.y = fixedPosition - heightToAdd - axisLabelOffsets.marginBotom
            }
            else
            {
                axisTickPosition.y = fixedPosition + axisLabelOffsets.marginTop
            }
        }
        else {
            
            axisTickPosition.y = position.y + yOffset
            
            var alignmentPosition = 0.0
            let labelHeight = labelRotationAngle != 0 && labelRotationAngle != 360 ? longestSize.height / 2.0 : 0.0
            
            switch labelAlignment {
                case .left:
                alignmentPosition = axisDependency == .left ? labelRotatedWidth - tickLabelSize.width / 2.0 + labelHeight : tickLabelSize.width / 2.0
                    break
                case .right:
                alignmentPosition = axisDependency == .left ? tickLabelSize.width / 2.0 : labelRotatedWidth - tickLabelSize.width / 2.0 + labelHeight
                    break
                case .center:
                    alignmentPosition = (labelRotatedWidth / 2.0)
                    break
            }
            
            if axisDependency == .left
            {
                axisTickPosition.x = fixedPosition - alignmentPosition - axisLabelOffsets.marginRight
            }
            else{
                axisTickPosition.x = fixedPosition + alignmentPosition + axisLabelOffsets.marginLeft
            }
        }
        
    }
}
