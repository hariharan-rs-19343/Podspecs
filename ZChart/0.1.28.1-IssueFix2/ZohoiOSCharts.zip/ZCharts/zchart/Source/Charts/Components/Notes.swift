//
//  Notes.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 17/05/22.
//

@objc
public protocol NoteDelegate
{
//    @objc optional func updateNoteShapeProperties(shapeInstance: ShapeProperties, entry: NoteEntry)
    @objc optional func updateNoteLayer(noteLayer:NoteLayer, noteShape: ShapeProperties)
    
}

open class NoteLayer:CALayer
{
    open var noteEntry:NoteEntry? = nil
    
    init(noteEntry:NoteEntry)
    {
        super.init()
        self.noteEntry = noteEntry
    }
    
    required public init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public static func getAllNoteLayer(chart: ChartViewBase) -> [NoteLayer] {
        
        var noteLayers = [NoteLayer]()
        
        guard let layers = chart.plotView?.nsuiLayer?.sublayers else {
            return noteLayers
        }
        
        for layer in layers where layer.isKind(of: NoteLayer.self) {
            
            guard let noteLayer = layer as? NoteLayer else {
                continue
            }
            
            noteLayers.append(noteLayer)
        }
        
        return noteLayers
    }
    
    public static func noteLayerForNoteEntry(chart: ChartViewBase, noteEntry: NoteEntry) -> NoteLayer? {
        
        for layer in getAllNoteLayer(chart: chart) {
            
            if layer.noteEntry === noteEntry
            {
                return layer
            }
        }
        
        return nil
    }
    
    public static func noteLayerForEntry(chart: ChartViewBase,entry: ChartDataEntry) -> NoteLayer? {
        
        guard let notes = chart.notes else {
            return nil
        }
        
        for noteEntry in notes.noteEntries {
            
            guard let noteDataEntry = noteEntry.noteEntryData else {
                continue
            }
            
            if noteDataEntry == entry {
                return noteLayerForNoteEntry(chart: chart, noteEntry: noteEntry)
            }
        }
        
        return nil
    }
    
    func opacity(opacityValue: Float) {
        self.opacity = opacityValue
    }
    
}



open class NoteEntry:NSObject, Codable
{
    open var point:(x:Any,y:Any)? = nil
    
    open var axisIndex:Int = 0
    
    open var noteEntryDataSetIndex:Int = -1
    
    open var noteEntryData:ChartDataEntry? = nil
    
    open var text:String = ""
    open var textFont = NSUIFont.systemFont(ofSize: 10.0)
    open var textColor = NSUIColor.black
    
    open var opacityChanged = 1.0
    open var notesFilterEnabled = false
    
    public override init() {
        
    }
    
    // MARK: - Codable
    
    enum NoteEntryCodingKeys: CodingKey {
        
        case x
        case y
        case axisIndex
        case notes
        
    }
    
    required public init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: NoteEntryCodingKeys.self)
        
        var xVal: (Any)? = nil
        
        var yVal: (Any)? = nil
        
        if let x = (try? container.decode(String.self, forKey: .x)){
            xVal = x
        }
        else if let x = (try? container.decode(Double.self, forKey: .x)){
            xVal = x
        }
        
        if let y = (try? container.decode(String.self, forKey: .y)){
            yVal = y
        }
        else if let y = (try? container.decode(Double.self, forKey: .y)){
            yVal = y
        }
        
        if let x = xVal, let y = yVal {
            point = (x: x, y: y)
        }
        
        axisIndex = try container.decode(Int.self, forKey: .axisIndex)
        
        text = try container.decode(String.self, forKey: .notes)
        
    }
    
    public func encode(to encoder: Encoder) throws {

    }
    
}

open class Notes: ComponentBase
{
    open var noteEntries: [NoteEntry] = []
    
    open var notesShape = ShapeProperties()
    
    open var cusotmNoteEnabled:Bool = false
    
    open var drawNotesEnabled = true
    
    open weak var customNoteDelegate:NoteDelegate? = nil
     
    public init(entries:[NoteEntry])
    {
        super.init()
        noteEntries = entries
    }
    
    // MARK: - Codable
    
    enum NotesCodingKeys: CodingKey {
        
        case noteEntries
        case noteShapeProperties
        
    }
    
    required public convenience init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: NotesCodingKeys.self)
        
        let noteEntries = try container.decode([NoteEntry].self, forKey: .noteEntries)
        
        self.init(entries: noteEntries)
        
        if let shapes = try? container.decode(ShapeProperties.self, forKey: .noteShapeProperties) {
            
            if shapes.size.width > 25.0 {
                shapes.size = CGSize(width: 25.0, height: 25.0)
            }
            
            cusotmNoteEnabled = shapes.shapeType == .custom ? true : false
        
            notesShape = shapes
            
        }
    }
    
    public override func encode(to encoder: Encoder) throws {

    }
}
