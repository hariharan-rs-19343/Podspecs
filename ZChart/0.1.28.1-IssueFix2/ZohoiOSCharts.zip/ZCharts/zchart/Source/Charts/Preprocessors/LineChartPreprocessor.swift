//
//  LineChartPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 15/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class LineChartPreprocessor:AxisChartPreprocessor
{
    
    // MARK: - Data Updation Calculation
    
    open override func notifyDataSetChanged(redrawRequired: Bool)
    {
        self.calcPosNegSum()
        
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
        
        checkIfBaseLineValueWithinRange()
        
        axisCorrection()
        
        chart?.updatePadding()
    }
    
    override func calcMinMax() {
        
        guard let chart = chart,
          let _data = chart.data
         else { return }
                                    
        // calculate / set x-axis range
        if let timeScale = chart._xAxis.scaleTypeProtocol as? TimeScale
        {
            if timeScale.timeScaleType == .Auto {
                timeScale.updateCurrentType(_data.xMin, _data.xMax)
            }
            var xMin = TimeScale.getMinimumValue(value: (_data.xMin), currentType: timeScale.currentType )
            var xMax = TimeScale.getMaximumValue(value: (_data.xMax), currentType: timeScale.currentType )
            if _data.xMin == _data.xMax
            {
                xMin = _data.xMax
                xMax = _data.xMax
            }
            chart._xAxis.calculate(min: xMin , max: xMax )
        }
        else{
            chart._xAxis.calculate(min: _data.xMin , max: _data.xMax)
        }
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            var yMin = getDataMin(data: _data, yAxis: yAxis)
            var yMax = getDataMax(data: _data, yAxis: yAxis)
            if yAxis.scaleType == .Time || yAxis.scaleType == .Linear {
                
                if let timeScale = yAxis.scaleTypeProtocol as? TimeScale {
                    
                    if timeScale.timeScaleType == .Auto {
                        timeScale.updateCurrentType(yMin, yMax)
                    }
                    yMin = TimeScale.getMinimumValue(value: yMin, currentType: timeScale.currentType )
                    yMax = TimeScale.getMaximumValue(value: yMax, currentType: timeScale.currentType )
                }
                
                if !isAllowedForAxisCorrection(axisIndex:yAxis.axisIndex) {
                    let (minVal,maxVal) = CommonHelperFunctions.getYMinMaxValue(axis: yAxis, chart: chart)
                    
                    if minVal == maxVal {
                        yMin = maxVal
                        yMax = maxVal
                    }
                }
            }
            yAxis.calculate(min: yMin  , max: yMax )
        }
    }
    
    func getDataMin(data:ChartData, yAxis:YAxis) -> Double
    {
        var axisMinimum = data.getYMin(axisIndex: yAxis.axisIndex)
        let axisMaximum = data.getYMax(axisIndex: yAxis.axisIndex)
        if (isAllowedForAxisCorrection(axisIndex: yAxis.axisIndex) && axisMinimum >= Double(0)) && (axisMaximum - axisMinimum) != 0 {
            axisMinimum = 0.0
        }
        return axisMinimum
    }
    
    func getDataMax(data:ChartData, yAxis:YAxis) -> Double
    {
        let axisMinimum = data.getYMin(axisIndex: yAxis.axisIndex)
        var axisMaximum = data.getYMax(axisIndex: yAxis.axisIndex)
        if (isAllowedForAxisCorrection(axisIndex: yAxis.axisIndex) && axisMaximum <= Double(0)) && (axisMaximum - axisMinimum) != 0 {
            axisMaximum = 0.0
        }
        return axisMaximum
    }
    
    fileprivate func isAllowedForAxisCorrection(axisIndex:Int) -> Bool
    {
        guard let chart = chart ,
            let lineData = chart.data,
            let sets = (lineData.dataSets as? [ChartDataSet])
            else { return false}
        
        var isAllowed = false
        
        for set in sets where (set.plotType == .Area) && (set.dataSetOptions as! LineDataSetOptions).drawFilledEnabled && set.axisIndex == axisIndex {
            isAllowed = true
            break
        }
                        
        return isAllowed
    }
    
    internal func axisCorrection() {
        
        guard let chart = chart ,
            let lineData = chart.data,
            let sets = (lineData.dataSets as? [ChartDataSet])
            else { return }
        
        var uniqIndex:Set<Int> = Set<Int>()
        
        for set in sets where (set.plotType == .Line || set.plotType == .Area) && (set.dataSetOptions as! LineDataSetOptions).drawFilledEnabled {
            uniqIndex.insert(set.axisIndex)
        }
        
        for axisIndex in uniqIndex {
            
            guard let axis = chart.getYAxis(atIndex: axisIndex),
            let maxValue = (lineData._yAxisMaxArray[axisIndex]),
            let minValue = (lineData._yAxisMinArray[axisIndex])
            else { continue }
             
            if !axis.enabled {
                continue
            }
            
            if minValue == Double.greatestFiniteMagnitude || maxValue == -Double.greatestFiniteMagnitude {
                continue
            }

            
            /// Case 1: Min > 0  Max > 0
            /// Case 2: Min = 0  Max = 0
            /// Case 3: Min < 0  Max < 0
            /// Case 4: Min = 0  Max > 0
            /// Case 5: Min < 0  Max = 0
            /// Case 6: Min < 0  Max > 0
            
            if minValue >= 0 && !axis.isAxisMinCustom
            {
                axis.setAxis(minimum: 0.0)
            }
            
            if maxValue <= 0 && !axis.isAxisMaxCustom
            {
                 if (lineData.getYMax(axisIndex: axis.axisIndex)) == 0 && (lineData.getYMin(axisIndex: axis.axisIndex)) == 0
                {
                     axis.setAxis(maximum: 1.0)
                }
                else{
                    axis.setAxis(maximum: 0.0)
                }
            }
        }
        
    }
    
    // MARK: - Supporting Methods
    
    public override func toolTipHighlight(newEntry:ChartDataEntry)
    {
        guard let chart = chart
        else { return }
        LineHelperFunctions.performHighlight(newEntry: newEntry, chart: chart)
    }
    
    // MARK: - Gesture Handled
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint) -> (entry: ChartDataEntry?, layer: ChartEntryLayer?) {
        
        guard let chart = chart
            else { return (nil,nil) }
        
        /*var handler:EventHandler?
        
        if recognizer.isKind(of: TapEventListener.self)
        {
            handler = (recognizer as? TapEventListener)?.handler
        }
        else if recognizer.isKind(of: PanEventListener.self)
        {
            handler = (recognizer as? PanEventListener)?.handler
        }
        else if recognizer.isKind(of: LongPressEventListener.self)
        {
            handler = (recognizer as? LongPressEventListener)?.handler
        }*/
    
        return LineHelperFunctions.tapHighlight(location: location, recognizer, chart: chart)
    }
    
    //MARK: - FROM LINE CHART DATA
       
        open var xUniqueValues = Set<Double>()
        
        open func calcPosNegSum()
        {
            entriesStackedYValue.removeAll()
            
            xUniqueValues.removeAll()
           
            guard let data = chart?.data,
                  let chart = chart,
                  let linePlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line, .LineRange]) as? LinePlotOptions
                  else { return }
            
            if !linePlotOptions.isStacked{
                return
            }
            
            let lineDataSets:[IChartDataSet] = data.dataSets.filter({
                $0.plotType == .Line
            })
            
            updateEntriesStackValue(dataset: lineDataSets, plotOptions: linePlotOptions)
            
        }
    
    func updateEntriesStackValue(dataset: [IChartDataSet], plotOptions: LinePlotOptions) {
        
        guard let data = chart?.data,
              let chart = chart
              else { return }
        
        var xDatasetUniqueValues = [Set<Double>]()
        
       for set in dataset
        {
            var setXValues = Set<Double>()
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else { continue }
                if (entry.x.isNaN)
                {
                    continue
                }
                xUniqueValues.insert((entry.x))
                setXValues.insert((entry.x))
            }
            xDatasetUniqueValues.append(setXValues)
        }
        
        if let xStringOrder = data.xStringOrder {
            
            for set in dataset
             {
                var setXValues = Set<Double>()
                for xindex in 0..<xStringOrder.count
                {
                    xUniqueValues.insert(Double((xindex)))
                    setXValues.insert(Double((xindex)))
                }
                xDatasetUniqueValues.append(setXValues)
             }
        }
        
        
       for lineSetIndex in  0..<dataset.count
        {
            let currentSet = dataset[lineSetIndex]
//                let setIndex = data.indexOfDataSet(currentSet)
           
           guard let xUniqueVals = xDatasetUniqueValues[safe:lineSetIndex] else {
               continue
           }
           
           let xValuesToAdd = xUniqueValues.subtracting(xUniqueVals)
            
            for setValue in xValuesToAdd
            {
                let tempEntry = ChartDataEntry(x: setValue, y: Double.nan, data: ["isDummy":true] as AnyObject)
                tempEntry.xString = data.xString?[safe:ChartUtils.doubleToIntSafeCast(value: setValue)] ?? nil
                _ = currentSet.addEntryOrdered(tempEntry)
            }
        }
        
        
        var posY:[Double:Double] = [:]
        
        var negY:[Double:Double] = [:]
        
        var posSum:[Double:[Int:Double]] = [:]
        var negSum:[Double:[Int:Double]] = [:]
        
        var maxY = -(Double.greatestFiniteMagnitude)
        var minY = -(Double.greatestFiniteMagnitude)
        
        var prevVisibleIndex = 0
        
       for lineSetIndex in 0..<dataset.count
        {
           let set = dataset[lineSetIndex]
           let setIndex = data.indexOfDataSet(set)
            if !set.isVisible
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else { continue }
                
                if  entry.x.isNaN
                {
                    continue
                }
                else if entry.y.isNaN
                {
                    if entriesStackedYValue[setIndex] == nil {
                        entriesStackedYValue[setIndex] = [:]
                    }
                    
                    var val = 0.0
                    
                    let prevDatasetIndex = data.indexOfDataSet(dataset[prevVisibleIndex])
                    
                    if let posVal = posSum[entry.x]?[prevDatasetIndex] {
                        val = posVal
                    }
                    else if let negVal = negSum[entry.x]?[prevDatasetIndex] {
                        val = -negVal
                    }
                    
                    entriesStackedYValue[setIndex]![entryIndex] = val
                    
                    if posSum[entry.x] == nil {
                        posSum[entry.x] = [setIndex:val]
                    }
                    else {
                        posSum[entry.x]?[setIndex] = val
                    }
                    
                    continue
                }
                
                if entry.y >= 0
                {
                    if posSum[entry.x] == nil
                    {
                        
                        posSum[entry.x] = [setIndex:entry.y]
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entry.y
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entry.y]
                        }
                        
                        
                        posY[entry.x] = entry.y
                    }
                    else{
                        
                        let  lastPositiveDataSetIndexSoFar = posSum[entry.x]?.keys.max()
                        
                        // CASE :- Same X For differnt entry
                        if lastPositiveDataSetIndexSoFar == setIndex
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = posSum[entry.x]?[setIndex] ?? entry.y
                        }
                        else{
                            let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + entry.y
                            
                            posSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            posY[entry.x] = yValue
                            
                        }
                        
                    }
                    
                }
                else{
                    
                    if negSum[entry.x] == nil
                    {
                        
                        negSum[entry.x] = [setIndex:abs(entry.y)]
                        
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entry.y
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entry.y]
                        }
                        
                        negY[entry.x] = abs(entry.y)
                        
                    }
                    else{
                        
                        let  lastNegativeDataSetIndexSoFar = negSum[entry.x]?.keys.max()
                        
                        
                        // CASE :- Same X For differnt entry
                        if lastNegativeDataSetIndexSoFar == setIndex
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = -(negSum[entry.x]?[setIndex] ?? abs(entry.y))
                        }
                        else{
                            let yValue = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]! + abs(entry.y)
                            
                            negSum[entry.x]![setIndex] = yValue
                            
                            negY[entry.x] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                            }
                        }
                    }
                }
                
                // Min & Max
                if posY[entry.x] != nil && posY[entry.x]! > maxY
                {
                    maxY = posY[entry.x]!
                }

                if negY[entry.x] != nil && negY[entry.x]! > minY
                {
                    minY = negY[entry.x]!
                }
            }
            prevVisibleIndex = lineSetIndex
        }
        
        // Need to revise first two lines
       /* data._yMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        data._yMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        
       //Need to check on below code based on actual available axis indices
       //otherwise Data yMin/yMax values will be written on all axis Index arrays
       for axisIndex in 0 ..< data._yAxisMinArray.count {
           data._yAxisMinArray[axisIndex] = data._yMin
        }
        
       for axisIndex in 0 ..< data._yAxisMaxArray.count {
           data._yAxisMaxArray[axisIndex] = data._yMax
        }*/
        
         minY = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
         maxY = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        
        var (yMinForNonStackedDataset,yMaxForNonStackedDataset) = calcYMinMaxForNonStackedDatasets(axisIndex: dataset[safe:0]?.axisIndex ?? 0)
        
         if (minY < yMinForNonStackedDataset){
             data._yAxisMinArray[dataset[0].axisIndex] = minY
         }
        
         if (maxY > yMaxForNonStackedDataset){
             data._yAxisMaxArray[dataset[0].axisIndex] = maxY
         }
        
         (yMinForNonStackedDataset,yMaxForNonStackedDataset) = calcYMinMaxForNonStackedDatasets()
        
         if (minY < yMinForNonStackedDataset) {
             data._yMin = minY
         }
        
         if (maxY > yMaxForNonStackedDataset) {
             data._yMax = maxY
         }
        
       /*for dict in _leftAxisMinArray
        {
            _leftAxisMinArray[dict.key] = -minY
        }
        for dict in _leftAxisMaxArray
        {
            _leftAxisMaxArray[dict.key] = maxY
        }
        
        for dict in _rightAxisMinArray
        {
            _rightAxisMinArray[dict.key] = -minY
        }
        for dict in _rightAxisMaxArray
        {
            _rightAxisMaxArray[dict.key] = maxY
        }
        
        self._leftAxisMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        self._leftAxisMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        self._rightAxisMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        self._rightAxisMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        */
    }

    // MARK: - Protocol Implementation
      
      public override func filterEntrySelected(entry: [ChartDataEntry]?) {
           
            guard let chart = chart,
                (entry != nil)
                else { return }
        
            chart.interactionAnimationInProgress = true
            ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 1)
        }
    
      public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
          
        guard let chart = chart
          else { return }
    
          ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
          
      }
      
      public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
          Log.info("Container::LegendDisabled ")
        
        guard let chart = chart
            else { return }
          
          ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
         
          /*
        if ((chart.data?.dataSetCount)! - chart.removedCount) > 1
          {
                chart.interactionAnimationInProgress = true
                chart.removedCount += 1
              
                let set = (chart.data?.dataSets[indexPath.item])!
              
                CommonHelperFunctions.hideDataSet(selectedDataset: [set], chart: chart)
              
              //            self.resizeAxisIfNeeded()
          }
           */
      }
}
