//
//  MekkoPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 22/08/22.
//


import Foundation

open class MekkoPreprocessor:BarPreprocessor
{
    // MARK: - Data Updation Calculation
    
    // XString -> (StartFromSize,ActualSize)
    var categoryToSize:[String:(CGFloat,CGFloat)] = [:]
    
    override open func notifyDataSetChanged(redrawRequired: Bool) {
        
        updateArrayOfDataSets()
        
        calcPosNegSum()
        
        callSuperNotifyDataSetChanged(redrawRequired: redrawRequired)
        
        axisCorrections()
            
    }
    
    override func calculateOffsets() {
        callSuperCalculateOffsets()
    }
    
    internal override func calcMinMax()
    {
        guard let chart = chart,
              let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Mekko]) as? BarPlotOptions,
              let _data = chart.data
            else { return }
        
        
        
        // calculate / set x-axis range
        if let timeScale = chart._xAxis.scaleTypeProtocol as? TimeScale
        {
            if timeScale.timeScaleType == .Auto {
                timeScale.updateCurrentType(_data.xMin, _data.xMax)
            }
            var xMin = TimeScale.getMinimumValue(value: (_data.xMin), currentType: timeScale.currentType )
            var xMax = TimeScale.getMaximumValue(value: (_data.xMax), currentType: timeScale.currentType )
            
            if _data.xMin == _data.xMax
            {
                xMin = _data.xMax
                xMax = _data.xMax
            }
            chart._xAxis.calculate(min: xMin , max: xMax )
        }
        else{
            categoryToSize.removeAll()
            for dataSet in _data.dataSets
            {
                for i in 0..<dataSet.entryCount
                {
                    guard let e = dataSet.entryForIndex(i),
                          let eString = e.xString,
                          let eSize = e.size
                    else { continue }
                    
                    categoryToSize[eString] = (0,eSize)
                }
                
            }
            var sizeSum = CGFloat(0)
            
            guard let dataXString = _data.xString
            else { return }
            
            for xLabel in dataXString
            {
                guard let (start,size) = categoryToSize[xLabel]
                else { continue}
                
                categoryToSize[xLabel] = (sizeSum,size)
                sizeSum += size
            }
//            for categorykey in categoryToSize.keys
//            {
//                sizeSum += categoryToSize[categorykey]!
//            }
            chart._xAxis.calculate(min: 0, max: sizeSum)
        }
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            yAxis.spaceTop = 0
            yAxis.spaceBottom = 0
            yAxis.calculate(
                min: (barPlotOptions.stackedPercentEnabled) ? 0 : getDataMin(data: _data, yAxis: yAxis),
                max: (barPlotOptions.stackedPercentEnabled) ? 100 : getDataMax(data: _data, yAxis: yAxis) )
        }
    }
       
       /////====================== ****************************** ====================== /////
       
    // MARK: - Supporting Methods
    
//    public override func toolTipHighlight(newEntry:ChartDataEntry)
//    {
//        BubbleHelperFunctions.performHighlight(newEntry: newEntry, chart: chart!)
//    }
//
//    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
//    {
//        var entry:ChartDataEntry? = nil
//
//        let high = chart!.getHighlightByTouchPoint(location)
//
//        var bubbleLayer:BubbleLayer? = nil
//
//        if high != nil
//        {
//            entry = chart!.entryForHighlight(high!)
//            bubbleLayer = BubbleLayer.getBubbleLayerForEntry(chart: chart!, entry: entry!)
//        }
//
//        return (entry,bubbleLayer)
//
//    }
//
//    // MARK: - Protocol Implementation
//
//    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
//        guard let chart = chart,
//            (entry != nil)
//            else { return }
//
//        ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 0.5)
//    }
//
//    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
//
//        ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart!, indexPath: indexPath, entry: entry)
//
//    }
//
//    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
//
//        ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart!, indexPath: indexPath, entry: entry)
//
//    }
}
