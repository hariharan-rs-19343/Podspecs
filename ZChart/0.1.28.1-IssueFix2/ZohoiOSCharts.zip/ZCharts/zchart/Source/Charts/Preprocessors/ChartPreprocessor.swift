//
//  ChartPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 15/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class ChartPreprocessor:NSObject
{
    
    open weak var chart: ChartViewBase?
    
    /// - returns: The current y-max value across all DataSets
    open var chartYMax: Double
    {
        return chart?._data?.yMax ?? 0.0
    }
   
    /// - returns: The current y-min value across all DataSets
    open var chartYMin: Double
    {
        return chart?._data?.yMin ?? 0.0
    }
    
    // Set Index -> EntryIndex -> YValue
    open var entriesStackedYValue:[Int:[Int:Double]] = [:]
    
    init(chart: ChartViewBase?) {
        self.chart = chart
    }
    
    internal func initialize()
    {
       return
    }
    
    open func notifyDataSetChanged(redrawRequired:Bool)
    {
        fatalError("No Calling")
    }
    
    internal func calcMinMax()
    {
       fatalError("No Calling")
    }
    
    /// Calculates the offsets of the chart to the border depending on the position of an eventual legend or depending on the length of the y-axis and x-axis labels and their position
    internal func calculateOffsets()
    {
        fatalError("calculateOffsets() cannot be called")
    }
    
    internal func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
            else { return (nil,nil) }
        
        var entry:ChartDataEntry? = nil
       
        let high = chart.getHighlightByTouchPoint(location)
       
        let entryLayer:ChartEntryLayer? = nil
       
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
       
        return (entry,entryLayer)
           
    }
    
    /// - returns: The actual position in pixels of the MarkerView for the given Entry in the given DataSet.
    open func getMarkerPosition(highlight: Highlight) -> CGPoint
    {
        return CGPoint(x: highlight.drawX, y: highlight.drawY)
    }
    
    @objc  func decelerationLoop()
    {
          guard let chart = chart
               else { return }
        
          let isPackedBubble = (chart.plotTypes.contains(.PackedBubble)) ||  (chart.plotTypes.contains(.WordCloud)) ||  (chart.plotTypes.contains(.GeoHeatMap)) || (chart.plotTypes.contains(.Sanky))
       
          let plotOption = chart.getPlotOptions() as? AxisChartPlotOptions
        
          let currentTime = CACurrentMediaTime()
          
          chart._decelerationVelocity.x *= chart.dragDecelerationFrictionCoef
          chart._decelerationVelocity.y *= chart.dragDecelerationFrictionCoef
          
          let timeInterval = CGFloat(currentTime - chart._decelerationLastTime)
          
          let distance = CGPoint(
              x:  chart._decelerationVelocity.x * timeInterval,
              y: chart._decelerationVelocity.y * timeInterval
          )
          
          let panStatus = isPackedBubble ? CommonHelperFunctions.performPanChangeforPlot(translation: distance, chart: chart) : CommonHelperFunctions.performPanChange(translation: distance, chart: chart)
        
          if !(panStatus)
          {
              // We reached the edge, stop
              chart._decelerationVelocity.x = 0.0
              chart._decelerationVelocity.y = 0.0
          }
          
          chart._decelerationLastTime = currentTime
          
          if abs(chart._decelerationVelocity.x) < 1 && abs(chart._decelerationVelocity.y) < 1
          {
               chart.stopDeceleration()
              
              chart.updateAxisMinAndMax()
              
//              if plotOption != nil && !isPackedBubble && plotOption!.resizeAxisOnScrollEnabled
//              {
//                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
//              }
              
              // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
               calculateOffsets()
               chart.setNeedsDisplay()
          }
    }
    
    // MARK: - Datalabel helperFunctions
    
    
    internal func computedYDomainValueForDatalabelRendering(chart: ChartViewBase, plotoption: IPlotOptions?, dataset: IChartDataSet, entry: ChartDataEntry, datasetIndex: Int, entryIndex: Int) -> Double {
        
        var entryY = entry.y
        var stackedY = entry.y
        
        if let stackedYvalue = entriesStackedYValue[datasetIndex]?[entryIndex], (plotoption as? PlotOptionsBase)?.isStacked ?? false || dataset.plotType == .WaterFall {
            stackedY = stackedYvalue
        }
        
        if (plotoption as? BarPlotOptions)?.stackedPercentEnabled ?? false
        {
            if let processor = (chart.getProcessor(type: dataset.plotType) as? BarPreprocessor) {
            
                entryY = processor.positiveSum[entry.x] != nil ? (entryY/processor.positiveSum[entry.x]!)*100 :  entryY
            }
        }
        
        if let barPlotOption = plotoption as? BarPlotOptions {
            switch barPlotOption.labelPosition {
                case .top:
                    return stackedY
                case .bottom:
                    return stackedY - entryY
                case .center:
                if barPlotOption.stackedPercentEnabled {
                    let prevY = getPrevStackedYvalue(chart: chart, dataset: dataset, datasetIndex: datasetIndex, entryIndex: entryIndex)
                    return prevY + ((stackedY - prevY) / 2.0)
                }
                else {
                    let prevY = stackedY - entryY
                    return prevY + (entryY / 2.0)
                }
            }
        }
        
        return stackedY
        
    }
    
    internal func getStackBound(chart: ChartViewBase, plotoption: IPlotOptions?, dataset: IChartDataSet, entry: ChartDataEntry, datasetIndex: Int, entryIndex: Int) -> (Double,Double) {
            
            var entryY = entry.y
    
            var stackedY = entry.y
        
            if let stackedYvalue = entriesStackedYValue[datasetIndex]?[entryIndex], (plotoption as? AxisChartPlotOptions)?.isStacked ?? false || dataset.plotType == .WaterFall {
                stackedY = stackedYvalue
            }
    
            if (plotoption as? BarPlotOptions)?.stackedPercentEnabled ?? false
            {
                if let processor = (chart.getProcessor(type: dataset.plotType) as? BarPreprocessor) {
                
                    entryY = processor.positiveSum[entry.x] != nil ? (entryY/processor.positiveSum[entry.x]!)*100 : entryY
                }
            }
            
            let minPoint = chart.pixelForValues(point: CGPoint(x: entry.x, y: stackedY), axisIndex: dataset.axisIndex)
            let maxPoint = chart.pixelForValues(point: CGPoint(x: entry.x, y: (stackedY-entryY)), axisIndex: dataset.axisIndex)
            
            let min = chart.isRotated ? minPoint.x : minPoint.y
            let max = chart.isRotated ? maxPoint.x : maxPoint.y
            
            return min < max ? (min,max) : (max,min)
            
        }

    internal func getPrevStackedYvalue(chart: ChartViewBase, dataset: IChartDataSet, datasetIndex: Int, entryIndex: Int) -> Double {
        
        var prevY = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataset)
        
        if let currentYValue = entriesStackedYValue[datasetIndex]?[entryIndex] {
            var index = datasetIndex - 1
            let isPositiveCurrentYValue = currentYValue > 0
            while index > -1 {
                if var yValue = entriesStackedYValue[index]?[entryIndex] {
                    yValue = yValue.isNaN ? 0 : yValue
                    if isPositiveCurrentYValue && prevY < yValue && currentYValue > yValue || prevY > yValue && currentYValue < yValue {
                        prevY = yValue
                        break
                    }
                }
                index -= 1
            }
        }
        return prevY
    }
    
    fileprivate static var stackedPlotType: [ChartType] = [ChartType.Bar,ChartType.WaterFall,ChartType.Line,ChartType.Area]
    
    internal static var notAllowedTypes: [ChartType] = [.Dial,.Pie,.Sanky,.PackedBubble,.GeoHeatMap,.HeatMap,.Funnel,.WordCloud,.BubblePie]
    
    internal static func prepareDataLabelRects(chart: ChartViewBase) {
        
        guard let chartData = chart.data
        else {
            return
        }
        
        if !(chartData.dataLabelRenderingMode == .showAll) {
            OccupancyGridMapping.resetOccupancyMatrix()
        }
        
        chart.labelRectIndexMap.removeAll()
        chart.longestDatalabelSize = CGSize()
        
        if chartData.dataSets.contains(where: {$0.plotType == .BubblePie}) {
            (chart.getProcessor(type: .BubblePie) as? BubblePiePreprocessor)?.prepareDatalabelRects()
        }
        
        let isStacked = CommonHelperFunctions.isStacked(chart: chart)
        
        var positiveSum: [Double:Double]?
        var negativeSum: [Double:Double]?
        
        if isStacked || chartData.dataSets.contains(where: {$0.plotType == .WaterFall}) {
            
            let preProcessor = CommonHelperFunctions.getProcessor(chart: chart, types: stackedPlotType) as? BarPreprocessor
            positiveSum = preProcessor?.positiveSum
            negativeSum = preProcessor?.negativeSum
        }
        
        for dataSetIndex in 0..<chartData.dataSets.count {
            let dataSet = chartData.dataSets[dataSetIndex]
            
            guard dataSet.isVisible, !notAllowedTypes.contains(dataSet.plotType) else {
                continue
            }
            
            let labelSizeForDataset = chart.labelSizeIndexMap[dataSetIndex]
            
            if chart.labelRectIndexMap[dataSetIndex] == nil {
                chart.labelRectIndexMap[dataSetIndex] = [:]
            }
            else {
                chart.labelRectIndexMap[dataSetIndex]?.removeAll()
            }
            
            let plotOption = chart.getPlotOptions(type: dataSet.plotType)
            let processor = chart.getProcessor(type: dataSet.plotType)
            let isAxisInverted = chart.getYAxis(atIndex: dataSet.axisIndex)?.isInverted ?? false
            var baseValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
            let isY0Plot = dataSet.plotType == .BoxPlot
            let isWaterfallPlot = dataSet.plotType == .WaterFall
            let isBoxPlot = dataSet.plotType == .BoxPlot
            let isBarFamily = BarHelperFunctions.typeAllowed.contains(dataSet.plotType)
            
            let valueOffset = ChartUtils.valueOffsetFor(dataSet: dataSet, plotOptions: plotOption)
            
            if !dataSet.drawValuesEnabled && !((plotOption as? BarPlotOptions)?.stackedPercentEnabled ?? false) && !((plotOption as? BoxPlotPlotOptions)?.medianEnabled ?? false) && !((plotOption as? BoxPlotPlotOptions)?.whiskersEnabled ?? false) {
                continue
            }
            
            for entryIndex in 0..<dataSet.entryCount {
                
                guard let entry = dataSet.entryForIndex(entryIndex), !entry.x.isNaN, !entry.y.isNaN, !entry.y0.isNaN, !entry.filterEnabled else {
                    continue
                }
                
                if chart.labelRectIndexMap[dataSetIndex]?[entryIndex] == nil {
                    chart.labelRectIndexMap[dataSetIndex]?[entryIndex] = [:]
                }
                else {
                    chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?.removeAll()
                }
                
                if ((plotOption as? BarPlotOptions)?.stackedPercentEnabled ?? false) && entry.y < 0 {
                    continue
                }
                
                let isAlignFirstAndLastDataLabel = true//((plotOption as? BarPlotOptions)?.groupSpace != 0 ?  round(entry.x) == chartData.xMin || round(entry.x) == chartData.xMax : entry.x == chartData.xMin || entry.x == chartData.xMax) || BarHelperFunctions.typeAllowed.contains(dataSet.plotType) && chart.isRotated
                
                var entryX = entry.x
                let entryY = processor?.computedYDomainValueForDatalabelRendering(chart: chart, plotoption: plotOption, dataset: dataSet, entry: entry, datasetIndex: dataSetIndex, entryIndex: entryIndex) ?? entry.y
                baseValue = isY0Plot ? min(entry.y0, entry.y) : baseValue
                
                if dataSet.plotType == .Mekko
                {
                    guard let processor = processor as? MekkoPreprocessor
                    else { continue}
                    
                    if
                       let xString = entry.xString,
                       let sizeValueStart = processor.categoryToSize[xString]?.0 {
                        
                        if (entry.size ?? 0.0).isZero {
                            entryX = .nan
                        }
                        else {
                            entryX = sizeValueStart + (entry.size ?? 0.0)/2
                        }
                    }
                }
                
                if let textSizeDict = labelSizeForDataset?[entryIndex], dataSet.drawValuesEnabled {
                    
                    if var textSize = textSizeDict["y"] {
                        
                        var prevBasevalue = baseValue
                        
                        if isWaterfallPlot  {
                            
                            if let processor = processor as? WaterFallPreprocessor {
                                prevBasevalue = processor.getBaseValue(basevalue: baseValue, dataset: dataSet, datasetIndex: dataSetIndex, entryIndex: entryIndex)
                            }
                            
                            if WaterFallHelperFunction.isCascade(entry: entry) {
                                if let formatter = dataSet.valueFormatter, let viewPortHandler = chart.viewPortHandler {
                                    let dataLabel = formatter.stringForValue(
                                        entry.y,
                                        entry: entry,
                                        dataSetIndex: dataSetIndex,
                                        viewPortHandler: viewPortHandler)
                                    
                                    textSize = dataLabel.size(withAttributes: [NSAttributedString.Key.font: dataSet.valueFont])
                                }
                            }
                        }
                        
                        var isAboveBaseLine = true
                        
                        if isBarFamily {
                            
                            if isWaterfallPlot {
                                isAboveBaseLine = ChartUtils.isAboveBaseLine(baseValue: prevBasevalue, entryOrignalYValue: prevBasevalue + entry.y, value: prevBasevalue + entry.y, isAxisInverted: isAxisInverted)
                            }
                            else if isBoxPlot {
                                let baseVal = min(entry.y0, entry.y)
                                isAboveBaseLine = entry.y == baseVal ? isAxisInverted : entry.y > baseVal && !isAxisInverted || entry.y < baseVal && isAxisInverted
                            }
                            else {
                                isAboveBaseLine = ChartUtils.isAboveBaseLine(baseValue: baseValue, entryOrignalYValue: entry.y, value: entryY, isAxisInverted: isAxisInverted)
                            }
                            
                            if (plotOption as? BarPlotOptions)?.stackedPercentEnabled ?? false {
                                
                                var entryY = entry.y
                                
                                if let processor = processor as? BarPreprocessor {
                                    entryY = processor.positiveSum[entry.x] != nil ? (entryY/processor.positiveSum[entry.x]!)*100 :  entryY
                                }
                                
                                if let formatter = dataSet.valueFormatter, let viewPortHandler = chart.viewPortHandler {
                                    let dataLabel = formatter.stringForValue(
                                        entryY,
                                        entry: entry,
                                        dataSetIndex: dataSetIndex,
                                        viewPortHandler: viewPortHandler)
                                    
                                    textSize = dataLabel.size(withAttributes: [NSAttributedString.Key.font: dataSet.valueFont])
                                }
                            }
                        }
                        
                        var rect = CGRect(origin: CGPoint(x: entryX, y: entryY), size: textSize)
                        
                        translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: isAboveBaseLine, isAlign: isAlignFirstAndLastDataLabel, valueOffset: valueOffset)
                        
                        if (isBarFamily && isStacked)
                        {
                            let stackBound = processor?.getStackBound(chart: chart, plotoption: plotOption, dataset: dataSet, entry: entry, datasetIndex: dataSetIndex, entryIndex: entryIndex) ?? (entry.y,baseValue)
                            
                            if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, originalPoint: CGPoint(x: entryX, y: entryY), labelRect: rect, isAboveBaseLine:isAboveBaseLine,isStacked: true,stackBound: stackBound) {
                                chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?["y"] = rect
                            }
                        }
                        else{
                            if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, originalPoint: CGPoint(x: entryX, y: entryY), labelRect: rect, isAboveBaseLine:isAboveBaseLine) {
                                chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?["y"] = rect
                            }
                        }
                    }
                    
                    if let textSize = textSizeDict["y0"] {
                        
                        var rect = CGRect(origin: CGPoint(x: entryX, y: entry.y0), size: textSize)
                        
                        let isAboveBaseLine = isBarFamily ? entry.y0 == baseValue ? isAxisInverted : entry.y0 > baseValue && !isAxisInverted || entry.y0 < baseValue && isAxisInverted : true
                        
                        translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: isAboveBaseLine, isAlign: isAlignFirstAndLastDataLabel, valueOffset: valueOffset)
                        
                        if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, originalPoint: CGPoint(x: entryX, y: entry.y0), labelRect: rect, isAboveBaseLine: isAboveBaseLine) {
                            chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?["y0"] = rect
                        }
                    }
                }
                
                if let boxPlotPlotOption = plotOption as? BoxPlotPlotOptions, let valArr = entry.plotData as? [Double] {
                    
                    let minWhiskers = valArr[safe:boxPlotPlotOption.minWhiskersIndex]
                    
                    let maxWhiskers = valArr[safe: boxPlotPlotOption.maxWhiskersIndex]
                    
                    let medianVal = valArr[safe: boxPlotPlotOption.medianIndex]
                    
                    if boxPlotPlotOption.medianEnabled && boxPlotPlotOption.drawMedianValueEnabled &&
                        medianVal != nil &&
                        !medianVal!.isNaN {
                        
                        let medianValueText = boxPlotPlotOption.medianValueFormatter.getFormattedValue?(medianValue: medianVal!) ?? String(medianVal!)
                        
                        let medianPoint = CGPoint(x: entryX, y: medianVal!)
                        let textSize = medianValueText.size(withAttributes: [NSAttributedString.Key.font: boxPlotPlotOption.medianValueFont])
                        
                        var rect = CGRect(origin: medianPoint, size: textSize)
                        
                        translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: true, isAlign: isAlignFirstAndLastDataLabel)
                        
                        if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, labelRect: rect, isAboveBaseLine: true) {
                            chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?["median"] = rect
                        }
                    }
                    
                    if boxPlotPlotOption.whiskersEnabled && boxPlotPlotOption.drawWhiskersValueEnabled {
                        
                        if boxPlotPlotOption.whiskersOn == .overLay && !(minWhiskers != nil) || !(maxWhiskers != nil) {
                            continue
                        }
                        
                        if minWhiskers != nil && !minWhiskers!.isNaN {
                            
                            let minWhiskerValueText = boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: minWhiskers!) ?? String(minWhiskers!)
                            
                            let minWhiskersPoint = CGPoint(x: entryX, y: minWhiskers!)
                            
                            var rect = CGRect(origin: minWhiskersPoint, size: minWhiskerValueText.size(withAttributes: [NSAttributedString.Key.font: boxPlotPlotOption.whiskersValueFont]))
                            let isAboveBaseLine = ChartUtils.isAboveBaseLine(baseValue: baseValue, value: minWhiskersPoint.y, isAxisInverted: isAxisInverted)
                            
                            translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: isAboveBaseLine, isAlign: isAlignFirstAndLastDataLabel)
                            
                            if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, labelRect: rect, isAboveBaseLine: isAboveBaseLine) {
                                chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?["minWhiskers"] = rect
                            }
                            
                        }
                        
                        if maxWhiskers != nil && !maxWhiskers!.isNaN {
                            
                            let maxWhiskerValueText = boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: maxWhiskers!) ?? String(maxWhiskers!)
                            
                            let maxWhiskersPoint = CGPoint(x: entryX, y: maxWhiskers!)
                            
                            var rect = CGRect(origin: maxWhiskersPoint, size: maxWhiskerValueText.size(withAttributes: [NSAttributedString.Key.font: boxPlotPlotOption.whiskersValueFont]))
                            let isAboveBaseLine = ChartUtils.isAboveBaseLine(baseValue: baseValue, value: maxWhiskersPoint.y, isAxisInverted: isAxisInverted)
                            
                            translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: isAboveBaseLine, isAlign: isAlignFirstAndLastDataLabel)
                            
                            if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, labelRect: rect, isAboveBaseLine: isAboveBaseLine) {
                                chart.labelRectIndexMap[dataSetIndex]?[entryIndex]?["maxWhiskers"] = rect
                            }
                        }
                    }
                }
            }
        }
        
        if isStacked {
            
            var dataSet = chart.data?.getDataSetForPlotType(plotType: .Bar).first
            if dataSet == nil {
                dataSet = chart.data?.getDataSetForPlotType(plotType: .WaterFall).first
            }
            
            if let dataSet = dataSet as? ChartDataSet {
                prepareDataLabelRectsForStackedsum(chart: chart, positiveSum: positiveSum, negativeSum: negativeSum,dataSet: dataSet)
            }
        }
    }
    
    fileprivate static func prepareDataLabelRectsForStackedsum(chart: ChartViewBase, positiveSum: [Double:Double]?, negativeSum: [Double:Double]?, dataSet: ChartDataSet) {
        
        guard let barPlotOption = chart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions,
              barPlotOption.stackedSumEnabled else {
            return
        }
        chart.labelRectIndexForStackedSum.removeAll()
        
        let isAxisInverted = chart.getYAxis(atIndex: dataSet.axisIndex)?.isInverted ?? false
        var baseValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
        let isWaterFall = dataSet.plotType == .WaterFall
        var prevX = 0.0
        
        if let positiveSum, let negativeSum {
            
            var xValues: Set<Double> = Set(positiveSum.keys)
            
            xValues = xValues.union(negativeSum.keys)
            
            for xValue in xValues.sorted() {
                
                if chart.labelRectIndexForStackedSum[xValue] == nil {
                    chart.labelRectIndexForStackedSum[xValue] = []
                }
                else {
                    chart.labelRectIndexForStackedSum[xValue]?.removeAll()
                }
                
                if isWaterFall {
                    var prevBaseValue = WaterFallHelperFunction.getMaxYValueForX(chart: chart, xVal: prevX, BaseValue: baseValue)
                    
                    if let preProcessor = CommonHelperFunctions.getProcessor(chart: chart, types: stackedPlotType) as? WaterFallPreprocessor, preProcessor.cascadeIndex.contains(Int(xValue)) {
                        prevBaseValue = 0.0
                    }
                    
                    baseValue = prevBaseValue
                    prevX = xValue
                }
                
                if let positiveSum = positiveSum[xValue] {
                    
                    var value = positiveSum
                    
                    if isWaterFall {
                        value -= baseValue
                    }
                    
                    let textSize = ChartUtils.getStackedSumLabelSize(barPlotOption: barPlotOption, sumValue: value, entryX: xValue)
                    
                    var rect = CGRect(origin: CGPoint(x: xValue, y: positiveSum), size: textSize)
                    let isAboveBaseLine = ChartUtils.isAboveBaseLine(baseValue: baseValue, value: positiveSum, isAxisInverted: isAxisInverted)
                    
                    translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: isAboveBaseLine, isAlign: true, valueOffset: 5.0, isStackedSum: true)
                    
                    if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, labelRect: rect, isAboveBaseLine: isAboveBaseLine) {
                        let label = barPlotOption.stackSumValueFormatter.getFormattedValue?(stackSum: value, entryX: xValue) ?? String(value)
                        var labelProp =  LabelProperties(value: value, rect: rect, axisIndex: dataSet.axisIndex)
                        labelProp.formattedLabel = label
                        chart.labelRectIndexForStackedSum[xValue]?.append(labelProp)
                    }
                }
                
                if var negativeSum = negativeSum[xValue] {
                    
                    var value = negativeSum
                    
                    if isWaterFall {
                        value = -abs(baseValue - negativeSum)
                    }
                    else {
                        value = -negativeSum
                        negativeSum = value
                    }
                    
                    let textSize = ChartUtils.getStackedSumLabelSize(barPlotOption: barPlotOption, sumValue: value, entryX: xValue)
                    
                    var rect = CGRect(origin: CGPoint(x: xValue, y: negativeSum), size: textSize)
                    let isAboveBaseLine = ChartUtils.isAboveBaseLine(baseValue: baseValue, value: negativeSum, isAxisInverted: isAxisInverted)
                    
                    translateLabelOrigin(chart: chart, dataset: dataSet, rect: &rect, isAboveBaseLine: isAboveBaseLine, isAlign: true, valueOffset: 5.0, isStackedSum: true)
                    
                    if let rect = isLabelrectAdjustedAndFittedInPlotView(chart: chart, dataset: dataSet, labelRect: rect, isAboveBaseLine: isAboveBaseLine) {
                        let label = barPlotOption.stackSumValueFormatter.getFormattedValue?(stackSum: value, entryX: xValue) ?? String(value)
                        var labelProp = LabelProperties(value: value, rect: rect, axisIndex: dataSet.axisIndex)
                        labelProp.formattedLabel = label
                        chart.labelRectIndexForStackedSum[xValue]?.append(labelProp)
                    }
                }
            }
        }
    }
    
    fileprivate static func translateLabelOrigin(chart: ChartViewBase, dataset: IChartDataSet,rect: inout CGRect, isAboveBaseLine: Bool, isAlign: Bool, valueOffset: Double = 5.0, isStackedSum: Bool = false) {
        
        rect.origin = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: rect.origin.x, y: rect.origin.y, dataset: dataset as! ChartDataSet, chart: chart)
        
        rect.origin = ChartUtils.getOriginForLabel(chart: chart, plotType: dataset.plotType, isAboveBaseLine: isAboveBaseLine, rect: rect, alignDataLabelWithInViewPort: isAlign, valueOffset: valueOffset, isStackedSum: isStackedSum)
    }
    
    internal static func isLabelrectAdjustedAndFittedInPlotView(chart: ChartViewBase, dataset: IChartDataSet, originalPoint: CGPoint = CGPoint(), labelRect: CGRect, isAboveBaseLine:Bool, isStacked:Bool = false, stackBound:(Double,Double)? = nil) -> CGRect?{
        
        if chart.data?.dataLabelRenderingMode == .showAll || getFittedRect(count: 1, labelRect: labelRect, threshold: 0, chart: chart,stackBound: stackBound, axisIndex: dataset.axisIndex) != nil
        {
            let valueForRectOrigin = chart.valueForTouchPoint(point: labelRect.origin, axisIndex: dataset.axisIndex, isRotated: chart.isRotated)
            return CGRect(origin: valueForRectOrigin, size: labelRect.size)
        }
        else if chart.data?.dataLabelRenderingMode == .adjust {
            
            switch dataset.plotType {
            case .Bar,.BoxPlot,.WaterFall,.Bullet,.Mekko,.HorizontalBarRange:
                var count = (chart.getPlotOptions(type: dataset.plotType) as? BarPlotOptions)?.adjustmentLevel ?? 2
                
                let textSizeValue = chart.isRotated ? (labelRect.width+5) : (labelRect.height+5)
                var threshold = isAboveBaseLine ? -(textSizeValue) : textSizeValue
                let labelRect = labelRect
                
                if isStacked && stackBound != nil
                {
                    count = 100
                    threshold = -(textSizeValue)
                    
                    //Upwards
                    if let newRect = getFittedRect(count: count, labelRect: labelRect, threshold: threshold, chart: chart,stackBound: stackBound, axisIndex: dataset.axisIndex)
                    {
                        return newRect
                    }
                    //Downwards
                    else{
                        threshold = textSizeValue
                        if let newRect = getFittedRect(count: count, labelRect: labelRect, threshold: threshold, chart: chart,stackBound: stackBound, axisIndex: dataset.axisIndex)
                        {
                            return newRect
                        }
                    }
                }
                else{
                    if let newRect = getFittedRect(count: count, labelRect: labelRect, threshold: threshold, chart: chart, axisIndex: dataset.axisIndex)
                    {
                        return newRect
                    }
                }
                break
            case .Scatter, .Radar, .Line, .Area, .LineRange:
                
                let originalPoint = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: originalPoint.x, y: originalPoint.y, dataset: dataset as! ChartDataSet, chart: chart)
                
                let valueOffset = ChartUtils.valueOffsetFor(dataSet: dataset)
                
                var labelOrigin = CGPoint(x: labelRect.origin.x, y: originalPoint.y + valueOffset)
                
                DataRenderer.alignDataLabel(chart: chart, translatedOrigin: &labelOrigin, labelSize: labelRect.size )
                
                if let newRect = getFittedRect(count: 1, labelRect: CGRect(origin: labelOrigin, size: labelRect.size), threshold: 0.0, chart: chart, axisIndex: dataset.axisIndex)
                {
                    return newRect
                }
                
                labelOrigin = CGPoint(x: originalPoint.x - labelRect.size.width - valueOffset, y: originalPoint.y - labelRect.size.height / 2.0)
                
                DataRenderer.alignDataLabel(chart: chart, translatedOrigin: &labelOrigin, labelSize: labelRect.size )
                
                if let newRect = getFittedRect(count: 1, labelRect: CGRect(origin: labelOrigin, size: labelRect.size), threshold: 0.0, chart: chart, axisIndex: dataset.axisIndex)
                {
                    return newRect
                }
                
                labelOrigin = CGPoint(x: labelRect.origin.x + valueOffset, y: originalPoint.y - labelRect.size.height / 2.0)
                
                DataRenderer.alignDataLabel(chart: chart, translatedOrigin: &labelOrigin, labelSize: labelRect.size )
                
                if let newRect = getFittedRect(count: 1, labelRect: CGRect(origin: labelOrigin, size: labelRect.size), threshold: 0.0, chart: chart, axisIndex: dataset.axisIndex)
                {
                    return newRect
                }
                break
            default:break
            }
        }
        
        return nil
    }
    
    internal static func getFittedRect(count:Int,labelRect:CGRect,threshold:CGFloat,chart:ChartViewBase,stackBound:(Double,Double)? = nil, axisIndex: Int) -> CGRect?
    {
        
        if chart.data?.dataLabelRenderingMode == .adjust {
            var labelRect = labelRect
            var count = count
            while (count > 0)
            {
                let newRect =  chart.isRotated ? CGRect(x: labelRect.minX+threshold, y: labelRect.minY, width: labelRect.width, height: labelRect.height) : CGRect(x: labelRect.minX, y: labelRect.minY+threshold, width: labelRect.width, height: labelRect.height)
                
                if let bound = stackBound
                {
                    if chart.isRotated
                    {
                        if !(newRect.minX >= bound.0 && newRect.maxX <= bound.1)
                        {
                            return nil
                        }
                    }
                    else{
                        if !(newRect.minY >= bound.0 && newRect.maxY <= bound.1)
                        {
                            return nil
                        }
                    }
                }
                
                if chart.isRotated
                {
                    if !chart.viewPortHandler.isInBoundsLeft(newRect.minX) || !chart.viewPortHandler.isInBoundsRight(newRect.maxX)
                    {
                        return nil
                    }
                }
                else{
                    if !chart.viewPortHandler.isInBoundsTop(newRect.minY) || !chart.viewPortHandler.isInBoundsBottom(newRect.maxY)
                    {
                        return nil
                    }
                }
                
                if isLabelrectIsfittedInPlotView(chart: chart, labelRect: newRect)
                {
                    let valueForRectOrigin = chart.valueForTouchPoint(point: newRect.origin, axisIndex: axisIndex, isRotated: chart.isRotated)
                    return CGRect(origin: valueForRectOrigin, size: newRect.size)
                }
                else{
                    labelRect = newRect
                }
                
                count -= 1
            }
        }
        else {
            if isLabelrectIsfittedInPlotView(chart: chart, labelRect: labelRect)
            {
                let valueForRectOrigin = chart.valueForTouchPoint(point: labelRect.origin, axisIndex: axisIndex, isRotated: chart.isRotated)
                return CGRect(origin: valueForRectOrigin, size: labelRect.size)
            }
        }
        
        return nil
    }
    
    internal static func isLabelrectIsfittedInPlotView(chart: ChartViewBase, labelRect: CGRect) -> Bool{
        
        guard let chartData = chart.data else {
            return false
        }
        
        if chartData.dataLabelRenderingMode == .showAll || OccupancyGridMapping.isDataLabelFittedInPlot(chart: chart, rect:  labelRect) {
            updateMaximumLabelSize(chart: chart, labelSize: labelRect.size)
            return true
        }
        
        return false
    }
    
    fileprivate static func updateMaximumLabelSize(chart: ChartViewBase, labelSize: CGSize) {
        chart.longestDatalabelSize.width = max(labelSize.width, chart.longestDatalabelSize.width)
        chart.longestDatalabelSize.height = max(labelSize.height, chart.longestDatalabelSize.height)
    }
    
    
    // MARK: - Protocol Implementations
         
    public func filterEntrySelected(entry: [ChartDataEntry]?) {
       fatalError("No Calling")
    }
    
     /// Tooltip tapped
     public func tooltipSelected(entry: ChartDataEntry?) {
         
      fatalError("No Calling")
         
     }
     
     /// Legend tapped
     public func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
         
        fatalError("No Calling")
     }
         
         
     /// Legend tapped
     public func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
         
         fatalError("No Calling")
     }
   /// Legend range adjusted
   open func legendRangeSelected(minimum: Double, maximum: Double) {
        guard let chart = chart
            else { return }
    
        chart.legend.legendRange = (minimum,maximum)
   }
    
    
    // MARK: - Animation Delegate
       
    open  func animatorUpdated(_ chartAnimator: Animator)
    {
        chart?.setNeedsDisplay()
        return
    }
       
    open  func animatorStopped(_ chartAnimator: Animator)
    {
          return
    }
    
    
}
