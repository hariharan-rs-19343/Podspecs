//
//  RadarPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 28/06/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class RadarPreprocessor:PiePreprocessor
{
    override func initialize() {
        
        let types = [ChartType.Radar]
        
        guard let chart = chart,
            let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: types) as? DialPlotOptions
            else { return }
        
        plotOption.selectionShift = 0
        chart.xAxis.drawTickMarksEnabled = false
//        chart.xAxis.yOffset = 0
        chart.xAxis.labelCount = 25
    }
    
    internal func axisCorrection()
    {
        guard  let chart = chart,
            let data = chart.data
            else {
                return
        }
        
        if data.xMin == data.xMax
        {
            if !chart.xAxis.isAxisMinCustom {
                chart.xAxis.setAxis(minimum: 0.0)
            }
            
            if chart.xAxis.isAxisMaxCustom {
                chart.xAxis.setAxis(maximum: 1.0)
            }
        }
        
        for axis in chart.getYAxisArray()
        {
            axis.spaceBottom = 0
        }
    }

    
    // MARK: - Data Updation Calculation
    
    open override func notifyDataSetChanged(redrawRequired:Bool)
    {
        guard  let chart = chart,
                let data = chart.data,
                let radarPlot = chart.getPlotOptions(type: .Radar) as? DialPlotOptions
                  else {
                      return
              }
        
        if radarPlot.isStacked
        {
          entriesStackedYValue = CommonHelperFunctions.calcPosNegSum(chart: chart, plotAllowed: [.Radar])
        }
        
        chart.updateAxisObjects()
        
        calcMinMax()
        
        axisCorrection()
        
        calculateOffsets()
        
        for yAxis in chart.yAxisArray where yAxis.spaceMinPixel != 0 && yAxis.spaceMaxPixel != 0 {
            chart.updateYPadding(axis: yAxis)
        }
        
        for yAxisRenderer in chart.yAxisRenderers where yAxisRenderer.axis != nil && yAxisRenderer.axis!.enabled {
             yAxisRenderer.computeAxis(min: (yAxisRenderer.axis?._axisMinimum)!, max: (yAxisRenderer.axis?._axisMaximum)!, inverted: (yAxisRenderer.axis?.inverted)!)
         }
        
        chart._xAxisRenderer?.computeAxis(min: chart._xAxis._axisMinimum, max: chart._xAxis._axisMaximum, inverted: chart._xAxis.isInverted)
         
        if let legend = chart._legend,
            !legend.isLegendCustom
        {
            chart._legendRenderer?.computeLegend(data: data)
        }
         
        if redrawRequired
        {
            chart.setNeedsDisplay()
        }
    }
    
    open override func calcMinMax() {
        
        guard  let chart = chart,
              let data = chart.data
            else {
                    return
                }
        
        chart.xAxis.calculate(min: data.xMin, max: data.xMax)
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            
            yAxis.spaceBottom = 0.0
            
            let dataMin = data.getYMin(axisIndex: yAxis.axisIndex)
            
            let dataMax = data.getYMax(axisIndex: yAxis.axisIndex)
            
//            let storedMinMax = (yAxis.axisMinimum,yAxis.axisMaximum)
            
            yAxis.calculate(min: dataMin , max: dataMax)
            /*
            if let _customAxisMin = yAxis._customAxisMin
            {
                yAxis.axisMinimum = _customAxisMin
            }
            
            if let _customAxisMax = yAxis._customAxisMax
            {
                yAxis.axisMaximum = _customAxisMax
            }
            */
        }
    }
    
    /// Calculates the offsets of the chart to the border depending on the position of an eventual legend or depending on the length of the y-axis and x-axis labels and their position
    internal override func calculateOffsets()
    {
        guard  let chart = chart
            else {
                    return
                }
        
        super.calculateOffsets()
        
        updateCenterAndRadius()
        
        chart.prepareOffsetMatrix()
        chart.prepareValuePxMatrix()
    }
    
    func updateCenterAndRadius()
    {
        guard let radarPlot = chart?.getPlotOptions(type: .Radar) as? DialPlotOptions,
                let chart = chart
            else { return }
        
        for yAxis in chart.getYAxisArray()
        {
            guard let transformers = chart.getTransformer(axisIndex: yAxis.axisIndex) as? PolarTransformer
                else { continue }
            transformers.centerPoint = radarPlot.centerCircleBox
            transformers.radius = radarPlot.radius
            transformers.xScaleRange = radarPlot.maxAngle
            transformers.yScaleRange = radarPlot.radius
            transformers.startAngle = radarPlot.startAngle
            transformers.direction = radarPlot.direction
        }
        
    }
    
    // MARK: - Protocol Implementations
    
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
         
          guard let chart = chart,
              (entry != nil)
              else { return }
      
          chart.interactionAnimationInProgress = true
          ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 1)
      }
    
    override public func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard let chart = chart
        else { return  }
        
        ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
        
    }
    
    override public func legendDisabled(indexPath: IndexPath, entry: LegendEntry)
    {
        guard let chart = chart
        else { return  }
          
        ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)

    }
    
    internal override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
            else { return (nil,nil) }
        
        var entry:ChartDataEntry? = nil
       
        let high = chart.getHighlightByTouchPoint(location)
       
        let entryLayer:ChartEntryLayer? = nil
       
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
       
        return (entry,entryLayer)
           
    }
    
    
}

