//
//  BubblePiePreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 05/10/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import Foundation

open class BubblePiePreprocessor:AxisChartPreprocessor
{
    open var _buffer:[Double:[Double:[[Any]]]] = [:]
    
    // MARK: - Data Updation Calculation
    
    override open func notifyDataSetChanged(redrawRequired: Bool) {
        
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
            
        checkIfBaseLineValueWithinRange()
        
        updateBuffer()
        
    }
    
    internal func updateBuffer()
    {
        guard let data = chart?.data,
              let plotOption = chart?.getPlotOptions(type: .BubblePie) as? BubblePiePlotOptions
        else { return }
        
        var valueSum:[Double:[Double:[(ChartDataEntry,Int)]]] = [:]
        
        for setIndex in 0..<data.dataSets.count
        {
            let set = data.dataSets[setIndex]
            if !(set.isVisible && set.plotType == .BubblePie)
            {
                continue
            }
            for i in 0..<set.entryCount
            {
                guard let e = set.entryForIndex(i),
                      !(e.x.isNaN) || !(e.y.isNaN)
                else { continue }
                
                // Need to handle
                if valueSum[e.x] != nil && valueSum[e.x]![e.y] != nil
                {
                    continue
                }
                
                var entriesAtXandYValue:[(ChartDataEntry,Int)] = []
                
                for tempSetIndex in 0..<data.dataSets.count
                {
                    let tempSet = data.dataSets[tempSetIndex]
                    if !(tempSet.isVisible && tempSet.plotType == .BubblePie)
                    {
                        continue
                    }
                    for tempE in tempSet.entriesForXYValue(e.x, e.y)
                    {
                        entriesAtXandYValue.append((tempE,tempSetIndex))
                    }
                }
                
                if valueSum[e.x] != nil
                {
                    valueSum[e.x]![e.y] = entriesAtXandYValue   // [(e,setIndex)]
                    
                }
                else{
                    var tempDict:[Double:[(ChartDataEntry,Int)]] = [:]
                    
                    tempDict[e.y] = entriesAtXandYValue
                    valueSum[e.x] = tempDict
                }
            }
        }
        
        _buffer.removeAll()
        
        for (xVal,dict) in valueSum
        {
            for (yVal,entryArray) in dict
            {
                var values:[Double] = []
                var tempValues:[Int:[Double]] = [:]
                for e in entryArray
                {
                    guard var pieValue = e.0.plotData as? Double
                    else { continue }
                    
                    if pieValue.isNaN || (e.0.y.isNaN)
                    {
                        pieValue = 0
                    }
                    
                    if tempValues[e.1] == nil
                    {
                        tempValues[e.1] = [pieValue]
                    }
                    else{
                        var dummyPieValues:[Double] = []
                        for c in tempValues[e.1]!
                        {
                            dummyPieValues.append(0)
                        }
                        tempValues[e.1] = dummyPieValues
                        tempValues[e.1]!.append(pieValue)
                    }
                }
                for dictKey in tempValues.keys.sorted()
                {
                    values.append(contentsOf: tempValues[dictKey]!)
                }
                let tempPieBuilder = PieBuilder(values: values, maxAngle: plotOption.piePlotoptions.maxAngle)
                tempPieBuilder.calcAngles()
                
                var tempArray:[Any] = []
                tempArray.append(entryArray)
                tempArray.append(tempPieBuilder)
                
                if _buffer[xVal] != nil
                {
                    if _buffer[xVal]![yVal] != nil
                    {
                        _buffer[xVal]![yVal]!.append(tempArray)
                    }
                    else{
                        _buffer[xVal]![yVal] = [tempArray]
                    }
                }
                else{
                    var tempDict:[Double:[[Any]]] = [:]
                    
                    tempDict[yVal] = [tempArray]
                    
                    _buffer[xVal] = tempDict
                }
            }
        }
    }
    
    internal func prepareDatalabelRects() {
        
        guard
            let chart = chart,
            let viewPortHandler = chart.viewPortHandler,
            let bubbleData = (chart.data),
            let plotOptions = chart.getPlotOptions(type: .BubblePie) as? BubblePiePlotOptions,
            let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.BubblePie]) as? BubbleChartRenderer
            else { return }
        
        let axisIndex = chart.data?.dataSets.first?.axisIndex ?? 0
        
        let bubbleSizeScale = renderer.getBubbleSizeScale(bubbleData: bubbleData, plotOptions: plotOptions)
        
        let viewMinWidth = min(viewPortHandler.contentWidth, viewPortHandler.contentHeight)
        
        var _pointBuffer: CGPoint
        
        for (xVal,dict) in _buffer.sorted(by: {$0.0 < $1.0})
        {
            _pointBuffer = CGPoint()
            
            for (yVal,pieConfigArray) in dict
            {
                _pointBuffer.x = CGFloat(xVal)
                _pointBuffer.y = CGFloat(yVal)
                _pointBuffer = chart.pixelForValues(isRotated: chart.isRotated, x: _pointBuffer.x, y: _pointBuffer.y, axisIndex: axisIndex)
                
                for pieConfig in pieConfigArray
                {
                    guard let entryArray = (pieConfig[0] as? [(ChartDataEntry,Int)]),
                          let pieBuilder = (pieConfig[1] as? PieBuilder)
                    else { continue }
                    
                    let sliceSpace = pieBuilder.values.count <= 1 ? 0.0 : PieChartRenderer.getSliceSpace(minValue: pieBuilder.values.min() ?? pieBuilder.values[0], minViewWidth: viewMinWidth, valueSum: pieBuilder.getYValueSum(), piePlotOption: plotOptions.piePlotoptions)
                    
                    var notNanSize = entryArray[0].0.size ?? 0.0
                    
                    if notNanSize.isNaN
                    {
                        for e in entryArray
                        {
                            if !((e.0.size ?? 0.0).isNaN)
                            {
                                notNanSize = e.0.size ?? 0.0
                                break
                            }
                        }
                    }
                    
                    let shapeSize = renderer.getBubbleSize(sizeValue: notNanSize , scale: bubbleSizeScale, plotOptions: plotOptions, bubbleData: bubbleData)

                    let shapeHalf = shapeSize / 2.0
                    
                    plotOptions.piePlotoptions.drawAngles = pieBuilder.drawAngles
                    plotOptions.piePlotoptions.radius = shapeHalf
                    
                    if  entryArray[0].0.filterEnabled
                    {
                        continue
                    }
                    
                    let pieBuffer = PieChartRenderer.prepareBuffer(entries: entryArray, piePlot: plotOptions.piePlotoptions, sliceCenter: _pointBuffer, sliceSpace: sliceSpace, animator: nil, isPiePlot: false)
                    
                    for bubblepieDict in pieBuffer {
                        
                        if let setIndex = bubblepieDict["setIndex"] as? Int, bubbleData.dataSets[setIndex].drawValuesEnabled {
                            
                            guard let center = bubblepieDict["center"] as? CGPoint,
                                  let radius = bubblepieDict["radius"] as? CGFloat,
                                  let startAngOuter = bubblepieDict["startAngleOuter"] as? CGFloat,
                                  let sweepAngOuter = bubblepieDict["sweepAngleOuter"] as? CGFloat,
                                  let entry = bubblepieDict["entry"] as? ChartDataEntry
                            else { continue }
                            
                            let entryIndex = bubbleData.dataSets[setIndex].entryIndex(entry: entry)
                            
                            let labelSizeForDataset = chart.labelSizeIndexMap[setIndex]
                            
                            if sweepAngOuter == 0 && !((entry.plotData as? Double)?.isZero ?? true) && !((entry.plotData as? Double)?.isNaN ?? true) {
                                continue
                            }
                            
                            if let labelSize = labelSizeForDataset?[entryIndex]?["y"] {
                                
                                if chart.labelRectIndexMap[setIndex] == nil {
                                    chart.labelRectIndexMap[setIndex] = [:]
                                }
                                
                                if chart.labelRectIndexMap[setIndex]?[entryIndex] == nil {
                                    chart.labelRectIndexMap[setIndex]?[entryIndex] = [:]
                                }
                                
                                var labelRect = getLabelRect(center: center, radius: radius, startAngle: startAngOuter, sweepAngleOuter: sweepAngOuter, labelSize: labelSize)
                                
                                if ChartPreprocessor.isLabelrectIsfittedInPlotView(chart: chart, labelRect: labelRect) {
                                    
                                    labelRect.origin = chart.valueForTouchPoint(point: labelRect.origin, axisIndex: bubbleData.dataSets[setIndex].axisIndex)
                                    chart.labelRectIndexMap[setIndex]?[entryIndex]?["y"] = labelRect
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    internal func getLabelRect(center: CGPoint, radius: CGFloat, startAngle: CGFloat, sweepAngleOuter: CGFloat, labelSize: CGSize) -> CGRect {
        
        guard let chart = chart else {
            return CGRect()
        }
        
        let midAngle = PieHelperFunctions.midAngle(startAngle: startAngle, delta: sweepAngleOuter)
        
        let point = PieHelperFunctions.getPosition(center: center, dist: radius + 5.0, angle: midAngle)
        
        let alignment = midAngle > 90 && midAngle < 270 ? NSTextAlignment.right : NSTextAlignment.left
        
        let labelOrigin = ChartUtils.getOriginForLabel(chart: chart, plotType: .BubblePie, rect: CGRect(origin: point, size: labelSize), alignDataLabelWithInViewPort: true, alignment: alignment)
        
        return CGRect(origin: labelOrigin, size: labelSize)
        
    }
       
       /////====================== ****************************** ====================== /////
       
    // MARK: - Supporting Methods
    
    public override func toolTipHighlight(newEntry:ChartDataEntry)
    {
        guard let chart = chart
        else { return }
        BubbleHelperFunctions.performHighlight(newEntry: newEntry, chart: chart)
    }
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
        else { return (nil,nil)}
        
        var entry:ChartDataEntry? = nil
        
        let high = chart.getHighlightByTouchPoint(location)
        
        var bubblePieLayer:PieLayer? = nil
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
            if entry != nil
            {
                bubblePieLayer = PieLayer.getPieLayerForEntry(chart: chart, entry: entry!)
            }
        }
        
        return (entry,bubblePieLayer)
        
    }
    
    // MARK: - Protocol Implementation
       
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
        guard let chart = chart,
            (entry != nil)
            else { return }
        
        ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 0.5)
    }
    
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
       
        guard let chart = chart
        else { return }
        ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
       
    }
   
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        guard let chart = chart
        else { return }
        ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
       
    }
}

