//
//  HorizontalBoxPlotPreprocessor.swift
//  zchart
//
//  Created by keerthi-pt4274 on 10/08/22.
//
/*
import Foundation

class HorizontalBoxPlotPreprocessor: HorizontalBarPreprocessor {
    
    override open func updateEntriesStackValue() {
        
        super.updateEntriesStackValue()
        
        updateMinMaxBasedOnWhiskers()
    }
}
*/
