//
//  HeatMapPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/02/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation


open class HeatMapPreprocessor:AxisChartPreprocessor
{
    
    // MARK: - Data Updation Calculation
    
    open override func notifyDataSetChanged(redrawRequired: Bool) {
        
        guard let chart = chart,
            let data = chart.data else {
            return
        }
        
        for yAxis in chart.yAxisArray {
            yAxis.spaceTop = 0
            yAxis.spaceBottom = 0
        }
        
        super.notifyDataSetChanged(redrawRequired: true)
        
        let singleWidth = CommonHelperFunctions.getOnePointWidth(chart: chart)
        
        let singleHeight = CommonHelperFunctions.getOnePointHeight(chart: chart, axis: chart.yAxisArray[0])
        
        if singleWidth < data.paddingInPixels || singleHeight < data.paddingInPixels || data.paddingInPixels == 0
        {
            return
        }
        data.rectWidth = Double(1 - ((1/singleWidth)*data.paddingInPixels))
        data.rectHeight = Double(1 - ((1/singleHeight)*data.paddingInPixels))

    }
    internal override func calcMinMax()
    {
        guard let chart = chart,
            let data = chart._data
            else { return }
        
        chart._xAxis.calculate(
                min: data.xMin - 0.5,
                max: data.xMax + 0.5)
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            yAxis.calculate(
                min: data.getYMin(axisIndex: yAxis.axisIndex) - 0.5,
                max: data.getYMax(axisIndex: yAxis.axisIndex) + 0.5 )
        }
    }
    
    // MARK: - Supporting Methods
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint) -> (entry: ChartDataEntry?, layer: ChartEntryLayer?) {
        
        guard let chart = chart
            else { return (nil,nil) }
        
        var entry:ChartDataEntry? = nil
        
        var entryLayer:MapLayer? = nil
        
        entryLayer = MapLayer.getMapLayerInPoint(chart: chart, loc: location)
        
        if entryLayer != nil
        {
            entry = entryLayer?.chartEntry
        }
        
        return (entry,entryLayer)
    }
    
    // MARK: - Protocol Implementations
    
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
    }
    
    /// Legend range adjusted
    open override func legendRangeSelected(minimum: Double, maximum: Double) {
        
        guard let chart = chart
        else { return  }
        
        super.legendRangeSelected(minimum: minimum, maximum: maximum)
        
        chart.lastSelected = nil
        
        HeatMapHelperFunctions.highLightMapEntry(chart: chart, entry: nil)
        
    }
}
