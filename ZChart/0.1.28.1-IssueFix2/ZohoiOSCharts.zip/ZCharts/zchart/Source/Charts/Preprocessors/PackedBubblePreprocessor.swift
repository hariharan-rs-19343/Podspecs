//
//  PackedBubblePreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/05/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation
import JavaScriptCore

open class PackedBubblePreprocessor:ChartPreprocessor
{

    var jsContext: JSContext!
    
    var dataValues:[Any] = []
    
    // MARK: - Initialize
    
    override func initialize() {
        super.initialize()
        
        chart?.xAxis.enabled  = false
        
        initializeJS()
        
        JSGarbageCollect(self.jsContext.jsGlobalContextRef)
    }
    
    func initializeJS() {
        
        self.jsContext = JSContext()
        
        // Add an exception handler.
        self.jsContext.exceptionHandler = { context, exception in
            if let exc = exception {
                print("JS Exception:", exc.toString() ?? "null")
            }
        }
    
        let bundle = Bundle(for: ChartViewBase.self)
    
        if let jsSourcePath = bundle.path(forResource: "d3-hierarchy.v1.min", ofType: "js") {
           do {
                   // Load its contents to a String variable.
                   let jsSourceContents = try String(contentsOfFile: jsSourcePath)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
               print(error.localizedDescription)
            }
        }
    
        if let jsSourcePath1 = bundle.path(forResource: "PackedBubble", ofType: "js") {
            do {
                   // Load its contents to a String variable.
                   let jsSourceContents1 = try String(contentsOfFile: jsSourcePath1)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents1)
               }
               catch {
                   print(error.localizedDescription)
               }
        }
    }
    
    // MARK: - Data Updation Calculation
    
    override open func notifyDataSetChanged(redrawRequired: Bool) {
    
        guard let chart = chart,
            let data = chart.data
        else { return }
        
        if chart._legend !== nil
        {
            chart._legendRenderer.computeLegend(data: data)
        }
        
        calculateOffsets()
        
        chart.prepareValuePxMatrixForPlot()
        
        doBubblePackLayout()
        
        if redrawRequired
        {
            chart.setNeedsDisplay()
        }

    }
    
    func doBubblePackLayout()
    {
           guard let chart = chart
                else { return }
        
           let data = getDataInFormat()
               
            let cgSizeArray:[Any] = [chart.viewPortHandler.contentRect.size.width, chart.viewPortHandler.contentRect.size.height]
           
           do
           {
               if let functionMaxMinAverage = self.jsContext.objectForKeyedSubscript("doPackLayout")
               {
                  if let results = functionMaxMinAverage.call(withArguments: [data,cgSizeArray])
                  {
                       if let resultArray = results.toArray()
                       {
                           dataValues = resultArray
                           removeRootForFlatMode()
                       }
                                                         
                   }
               }

           } catch _
           {
               print ("JSON Failure")
           }
    }
    
    func removeRootForFlatMode() {
        guard let chart = chart,
             let plotOptions = chart.getPlotOptions(type: .PackedBubble) as? BubblePlotOptions,
             plotOptions.mode == .Flat
             else { return }
            
            var index = -1
            var rootIndex = -1
            for arrayVal in dataValues {
                index = index + 1
                guard let object = arrayVal as? NSDictionary,
                      let name = object["name"] as? String
                else { continue }
                
                let isRoot = name == "root"
                if (isRoot) {
                    rootIndex = index
                    break
                }
            }
        
        if (rootIndex != -1) {
            dataValues.remove(at: rootIndex)
        }
    }
    
    fileprivate func getDataInFormat() -> [String:Any]
    {
        var data:[String:Any] = [:]
        
        guard let chart = chart,
            let dataSets = chart.data?.dataSets as? [ChartDataSet],
            let plotOptions = chart.getPlotOptions(type: .PackedBubble) as? BubblePlotOptions
            else { return data }
        
        var dummyString:[[String:Any]] = []
        
        for setIndex in 0..<(dataSets.count)
        {
            let set = dataSets[setIndex]
            
            if !(set.isVisible)
            {
                continue
            }
            
            for entryIndex in 0..<set.values.count
            {
                var pathIndex:[Int] = [entryIndex]
                
                let entry = set.values[entryIndex]
                
                if entry.filterEnabled
                {
                    continue
                }
                
                if plotOptions.mode == .Flat
                {
                    traverseFlatTree(entry: entry, setIndex: setIndex, stringArray: &dummyString, pathIndex: &pathIndex)
                }
                else{
                    dummyString.append(traverseTree(entry: entry, setIndex: setIndex, pathIndex: &pathIndex))
                }
            }
        }
        
        data["name"] = "root"
        data["children"] = dummyString
        data["setIndex"] = 0
        data["pathIndex"] = [0]
        
        return data
    }
    
    func traverseTree(entry:ChartDataEntry, setIndex:Int, pathIndex: inout [Int]) -> [String:Any]
    {
        if entry.childEntries.count == 0
        {
            var tempDict:[String:Any] = [:]
            tempDict["name"] = entry.xString ?? "null"
            tempDict["value"] = entry.y
            tempDict["setIndex"] = setIndex
            tempDict["pathIndex"] = pathIndex
            return tempDict
        }
        
        var childString:[[String:Any]] = []
        for childEntryIndex in 0..<entry.childEntries.count
        {
            let childEntry = entry.childEntries[childEntryIndex]
            
            if childEntry.filterEnabled
            {
                continue
            }
            var pathCopy = pathIndex
            pathCopy.append(childEntryIndex)
            
            childString.append(traverseTree(entry: childEntry, setIndex: setIndex, pathIndex: &pathCopy))
        }
        var entryString:[String:Any] = [:]
        entryString["name"] = entry.xString == nil ? "" : entry.xString!
        entryString["children"] = childString
        entryString["setIndex"] = setIndex
        entryString["pathIndex"] = pathIndex
        
        return entryString
    }
    
    func traverseFlatTree(entry:ChartDataEntry, setIndex:Int, stringArray:inout [[String:Any]],pathIndex:inout [Int])
    {
        if entry.filterEnabled
        {
            return
        }
        
        if entry.childEntries.count == 0
        {
            var tempDict:[String:Any] = [:]
            tempDict["name"] = entry.xString ?? "null"
            tempDict["value"] = entry.y
            tempDict["setIndex"] = setIndex
            tempDict["pathIndex"] = pathIndex
            stringArray.append(tempDict)
            return
        }
        
        for childEntryIndex in 0..<entry.childEntries.count
        {
            var pathCopy = pathIndex
            pathCopy.append(childEntryIndex)
            let childEntry = entry.childEntries[childEntryIndex]
            
            traverseFlatTree(entry: childEntry, setIndex: setIndex, stringArray: &stringArray, pathIndex: &pathCopy)
        }

    }
    
    override func calculateOffsets() {
        
        guard  let chart = chart,
            let plotOptions = chart.getPlotOptions(type: .PackedBubble) as? BubblePlotOptions
        else {
                return
        }
        
        let outerPadding:CGFloat = 0 //plotOptions.outerPadding
        
        chart._viewPortHandler.restrainViewPort(
            offsetLeft: outerPadding,
            offsetTop: outerPadding,
            offsetRight: outerPadding,
            offsetBottom: outerPadding)
        
    }
       
       /////====================== ****************************** ====================== /////
       
    // MARK: - Supporting Methods
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        var entry:ChartDataEntry? = nil
        
        let high = chart?.getHighlightByTouchPoint(location)
        
        var bubbleLayer:BubbleLayer? = nil
        
        if high != nil
        {
            entry = chart?.entryForHighlight(high!)
            if entry != nil && chart != nil
            {
                bubbleLayer = BubbleLayer.getBubbleLayerForEntry(chart: chart!, entry: entry!)
            }
        }
        
        return (entry,bubbleLayer)
        
    }
    
    // MARK: - Protocol Implementation
       
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
        guard let chart = chart,
            (entry != nil)
            else { return }
        
        ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 0.5)
    }
    
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
    }
    
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
       
         guard let chart = chart,
                   let set = (chart.data?.dataSets[indexPath.item]) as? ChartDataSet
                   else { return }
               
         chart.interactionAnimationInProgress = true
         BubbleHelperFunctions.includeDataset(dataSets: [set], chart: chart, duration: 1)
       
    }
   
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
       
        guard let chart = chart,
            let set = (chart.data?.dataSets[indexPath.item]) as? ChartDataSet
            else { return }
        
        chart.interactionAnimationInProgress = true
        BubbleHelperFunctions.hideDataset(dataSets: [set], chart: chart, duration: 1)
       
       
    }
}
