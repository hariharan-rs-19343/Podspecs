//
//  BubblePreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/02/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class BubblePreprocessor:AxisChartPreprocessor
{
    // MARK: - Data Updation Calculation
    
    override open func notifyDataSetChanged(redrawRequired: Bool) {
        
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
            
        checkIfBaseLineValueWithinRange()
    }
       
       /////====================== ****************************** ====================== /////
       
    // MARK: - Supporting Methods
    
    public override func toolTipHighlight(newEntry:ChartDataEntry)
    {
        BubbleHelperFunctions.performHighlight(newEntry: newEntry, chart: chart!)
    }
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
        else { return (nil,nil)}
        
        var entry:ChartDataEntry? = nil
        
        let high = chart.getHighlightByTouchPoint(location)
        
        var bubbleLayer:BubbleLayer? = nil
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
            if entry != nil
            {
            bubbleLayer = BubbleLayer.getBubbleLayerForEntry(chart: chart, entry: entry!)
            }
        }
        
        return (entry,bubbleLayer)
        
    }
    
    // MARK: - Protocol Implementation
       
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
        guard let chart = chart,
            (entry != nil)
            else { return }
        
        ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 0.5)
    }
    
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
       
        guard let chart = chart
        else { return }
        
        ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
       
    }
   
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
       
        guard let chart = chart
        else { return }
        ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
       
    }
}
