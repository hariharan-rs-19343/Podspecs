//
//  ScatterPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 20/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class ScatterPreprocessor:AxisChartPreprocessor
{
    // MARK: - Data Updation Calculation
    
    open override func notifyDataSetChanged(redrawRequired: Bool)
    {
        guard  let chart = chart,
            let plotOptions = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
            else {
                return
        }
        
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
        
        if !chart.customScaleEnabled
        {
            calculateOnDataSetChanged()
        }
        
        checkIfBaseLineValueWithinRange()
        
        if plotOptions.minimumShapeSizeInPixel != 0 && plotOptions.maximumShapeSizeInPixel != 0 && (plotOptions.maxWidthZoomRestrictionPixel != CGFloat.greatestFiniteMagnitude)
        {
            prepareShapeSize()
        }
    }
    
    fileprivate func prepareShapeSize()
    {
        guard  let chart = chart ,
            let scatterData = chart.data,
            let plotOptions = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions,
            let viewPortHandler = chart.viewPortHandler
            else {
                return
        }

        let maxSize = plotOptions.maximumShapeSizeInPixel
        
        let minSize = plotOptions.minimumShapeSizeInPixel
        
        //Backup of scaleValues
        let lastScaleX = viewPortHandler._touchMatrix.a
        
        // To reset scaleX Value
        viewPortHandler._touchMatrix.a = 1
        
        chart.prepareValuePxMatrix()
        
        chart.updatePadding()
        
        var currentOnePointWidth = CommonHelperFunctions.stepSize(chart: chart, axisIndex: 0)
        
        if chart.xAxis.scaleType != .Ordinal
        {
            currentOnePointWidth =  CommonHelperFunctions.getMaxWidthBetweenEntriesAcrossAllVisibleData(barLine: chart)
        }
        
        // Reset Scale Value
        viewPortHandler._touchMatrix.a = lastScaleX
        
        chart.prepareValuePxMatrix()
        
        chart.updatePadding()
        
        let scatterSize = ((currentOnePointWidth >= minSize) && (currentOnePointWidth <= maxSize))
            ?   currentOnePointWidth
            : ((currentOnePointWidth > maxSize) ? maxSize : minSize)
        
        for set in (scatterData.dataSets) where set.plotType == .Scatter
        {
            guard let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
            else { continue }
            let shapeProperties = dataOption.shapeProperties
            shapeProperties.size = CGSize(width: scatterSize, height: scatterSize)
        }
        
    }
    
    func calculateOnDataSetChanged()
    {
        guard  let chart = chart
            else {
                return
        }
        
        let scaleValue:CGFloat = 1
        
        chart.setScaleMinima(scaleValue, scaleY: 1)
        
        /* //Backup of scaleValues
         let lastScaleX = viewPortHandler._touchMatrix.a
         
         // To reset scaleX Value
         viewPortHandler._touchMatrix.a = 1
         
         let currentWidth = getCurrentWidthAfterPadding(padding: CGFloat(((scatterData.xMax) - (scatterData.xMin))/Double((scatterData.maxEntryCountSet?.entryCount)!)))
         
         // Padding
         if currentWidth > scatterData.interSpace
         {
         var padding:CGFloat = 0
         
         var currentWidth:CGFloat = 0
         
         // trail and error checking for padding value to get bar width close to maxwidth
         repeat
         {
         padding += 1
         
         currentWidth = getCurrentWidthAfterPadding(padding: padding)
         }
         while(currentWidth > scatterData.interSpace)
         
         
         padding = getPaddingValueBinarySearch(padding: padding-1,expectedWidth: scatterData.interSpace)
         
         currentWidth = getCurrentWidthAfterPadding(padding: padding)
         
         }
         else if currentWidth == 0
         {
         _ = getCurrentWidthAfterPadding(padding: 0.5)
         }
         else{
         // Current view width
         var viewSize:CGFloat
         
         viewSize = viewPortHandler.contentRect.width
         
         let neededLabelCount = viewSize/scatterData.interSpace
         
         scaleValue = CGFloat((chart.data?.maxEntryCountSet?.entryCount)!) / neededLabelCount
         
         if lastScaleX > scaleValue && chart.scaleXEnabled
         {
         viewPortHandler._touchMatrix.a = lastScaleX
         }
         }*/
        
    }
    
    // MARK: - Supporting Methods
    
    public override func toolTipHighlight(newEntry:ChartDataEntry)
    {
        guard let chart = chart
                   else { return  }
        
        ScatterHelperFunctions.performHighlight(newEntry: newEntry, chart: chart)
    }
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
            else { return (nil,nil) }
        
        var entry:ChartDataEntry? = nil
        
        let high = chart.getHighlightByTouchPoint(location)
        
        var entryLayer:ChartEntryLayer? = nil
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
        
        entryLayer = ScatterLayer.getScatterEntryLayer(chart: chart, loc: location)
        
        return (entry,entryLayer)
        
    }
    
    // MARK: - Protocol Implementation
    
        public override func filterEntrySelected(entry: [ChartDataEntry]?) {
            guard let chart = chart,
                (entry != nil)
                else { return }
            
            ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 1)
        }
       
       public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
           
        guard let chart = chart
        else { return  }
        
       ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
           
       }
       
       public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
           
        guard let chart = chart
        else { return  }
          
        ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
           
       }
    
}

