//
//  HorizontalBarPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 10/02/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class HorizontalBarPreprocessor:BarPreprocessor
{
    fileprivate let typeAllowed = [ ChartType.Bar, ChartType.Bullet, ChartType.HorizontalBarRange]
    
    // MARK: - Offset and Scale Calculation
    
    internal override func calculateOffsets()
    {
        guard let chart = chart,
            let _viewPortHandler = chart._viewPortHandler,
            let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
            let _xAxis = chart._xAxis
            else { return }
        
        computeAxisLabelOffsets()
        
        var offsetLeft: CGFloat = 0.0,
        offsetRight: CGFloat = 0.0,
        offsetTop: CGFloat = 0.0,
        offsetBottom: CGFloat = 0.0
        
        calculateLegendOffsets(offsetLeft: &offsetLeft,
                               offsetTop: &offsetTop,
                               offsetRight: &offsetRight,
                               offsetBottom: &offsetBottom)
        
        let xlabelwidth = _xAxis.labelRotatedWidth
        
        if _xAxis.isEnabled
        {
            var xlabelwidth = xlabelwidth + _xAxis.axisLabelOffsets.marginLeft + _xAxis.axisLabelOffsets.marginRight
            
            if _xAxis.axisTitleEnabled
            {
                xlabelwidth += _xAxis.axisTitleOffsets.marginLeft + _xAxis.axisTitleOffsets.marginRight
            }
            
            // offsets for x-labels
            if _xAxis.labelPosition == .bottom
            {
                offsetLeft += xlabelwidth
            }
            else if _xAxis.labelPosition == .top
            {
                offsetRight += xlabelwidth
            }
            else if _xAxis.labelPosition == .bothSided
            {
                offsetLeft += xlabelwidth
                offsetRight += xlabelwidth
            }
        }
        
        offsetLeft += chart.extraLeftOffset
        offsetRight += chart.extraRightOffset
        
        _viewPortHandler.restrainViewPort(
            offsetLeft: max(plotOption.minOffset, offsetLeft),
            offsetTop: max(plotOption.minOffset, offsetTop),
            offsetRight: max(plotOption.minOffset, offsetRight),
            offsetBottom: max(plotOption.minOffset, offsetBottom))
        
        
        // offsets for y-labels\
        for axis in chart.yAxisArray where axis.needsOffset && axis.axisDependency == .left {
            axis.offsetCalculated = -offsetTop
            offsetTop += axis.getRequiredHeightSpace(constrainedWidth: _viewPortHandler.contentWidth, onePointWidth: CommonHelperFunctions.getOnePointWidth(chart: chart), scaleX: chart._viewPortHandler.scaleX)
        }
        
        for axis in chart.yAxisArray where axis.needsOffset && axis.axisDependency == .right {
            axis.offsetCalculated = offsetBottom
            offsetBottom += axis.getRequiredHeightSpace(constrainedWidth: _viewPortHandler.contentWidth, onePointWidth: CommonHelperFunctions.getOnePointWidth(chart: chart), scaleX: chart._viewPortHandler.scaleX)
        }
        
        
        
        offsetTop += chart.extraTopOffset
        offsetBottom += chart.extraBottomOffset
        
        
        _viewPortHandler.restrainViewPort(
            offsetLeft: max(plotOption.minOffset, offsetLeft),
            offsetTop: max(plotOption.minOffset, offsetTop),
            offsetRight: max(plotOption.minOffset, offsetRight),
            offsetBottom: max(plotOption.minOffset, offsetBottom))
        
       
        let barData = chart.data
        let barSet = barData?.dataSets[0]
        
        if (barSet?.plotType == .Bullet) && plotOption.adjustViewToLevelWidth && plotOption.levelMarkerWidthPixel != 0
        {
            let levelpixel = plotOption.levelMarkerWidthPixel + plotOption.barSpacePixel
            
            let topOffset = (chart.frame.height/2) - CGFloat(levelpixel/2) < 0 ? 0 : (chart.frame.height/2) - CGFloat(levelpixel/2)
            
            let bottomOffset = chart.frame.height - ((chart.frame.height/2) + CGFloat((levelpixel/2))) < 0 ? 0 : chart.frame.height - ((chart.frame.height/2) + CGFloat((levelpixel/2)))
            
            _viewPortHandler.restrainViewPort(
                offsetLeft: max(plotOption.minOffset, offsetLeft),
                offsetTop: topOffset,
                offsetRight: max(plotOption.minOffset, offsetRight),
                offsetBottom: bottomOffset)
        }
        
        
        chart.prepareOffsetMatrix()
        chart.prepareValuePxMatrix()
    }
    
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Supporting Methods
      
      open override func getMarkerPosition(highlight: Highlight) -> CGPoint
      {
          return CGPoint(x: highlight.drawY, y: highlight.drawX)
      }
    
}
