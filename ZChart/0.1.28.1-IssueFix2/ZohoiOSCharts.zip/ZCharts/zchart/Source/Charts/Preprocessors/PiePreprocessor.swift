//
//  PiePreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 10/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation


open class PieBuilder:NSObject
{
    var values:[Double] = []
    var maxAngle:CGFloat = 360
    open var pieStartAngle:CGFloat = 270
    open var drawAngles:[CGFloat] = []
    open var absoluteAngles:[CGFloat] = []
    
    
    public override init() {
        
    }
    
    public  init(values:[Double], maxAngle:CGFloat) {
        self.values = values
        self.maxAngle = maxAngle
    }
    
    open func calcAngles()
    {
        drawAngles = [CGFloat]()
        absoluteAngles = [CGFloat]()
        
        let entryCount = values.count
        
        drawAngles.reserveCapacity(entryCount)
        absoluteAngles.reserveCapacity(entryCount)
        
        let yValueSum = getYValueSum()
        
        var cnt = 0
        
        for value in values
        {
            var y = value
            
            if y.isNaN {
                y = 0
            }
            
            let angle = CGFloat(abs(y)) / CGFloat(yValueSum) * maxAngle
            
            drawAngles.append(angle)
            
            if cnt == 0
            {
                absoluteAngles.append(drawAngles[cnt])
            }
            else
            {
                absoluteAngles.append(absoluteAngles[cnt - 1] + drawAngles[cnt])
            }
            
            cnt += 1
        }
    }
    
    open func getYValueSum() -> Double
    {
        var yValueSum: Double = 0.0
        
        for value in values
        {
            var y = value
            
            if y.isNaN {
                y = 0
            }
            
            yValueSum += abs(y)
        }
        
        return yValueSum
    }
}
open class PiePreprocessor:PieRadarPreprocessor
{

    override func initialize() {
        
        let types = [ChartType.Pie,ChartType.Dial]
        
        guard let chart = chart,
            let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: types) as? PiePlotOptions
            else { return }
        
        plotOption.pieComponents.pieChart = chart
        chart.xAxis.enabled = false
    }
    // MARK: - Data Updation Calculation
    
    open override func notifyDataSetChanged(redrawRequired:Bool)
    {
        guard  let chart = chart,
               let data = chart.data,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else {
                return
        }
        
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
              
        if piePlot.arrowShow {
            //pieType.startUp()
            PieHelperFunctions.rotateAndPositionMid(chart: chart)
        }
    }
    
    open override func calcMinMax() {
        calcAngles()
    }
    
    /// calculates the needed angles for the chart slices
    fileprivate func calcAngles()
    {
        guard  let chart = chart,
            let data = chart.data,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else {
                return
        }
        
        var values:[Double] = []
        
        for i in 0 ..< data.dataSetCount
        {
            let set = data.dataSets[i]
            let entryCount = set.entryCount
            
            for j in 0 ..< entryCount
            {
                guard let e = set.entryForIndex(j) else { continue }
                
                values.append(e.y)
                
            }
        }
        let pieBuilder = PieBuilder(values: values, maxAngle: piePlot.maxAngle)
        
        pieBuilder.calcAngles()
        
        piePlot.drawAngles = pieBuilder.drawAngles
        piePlot.absoluteAngles = pieBuilder.absoluteAngles
        
    }
    
    /// No Need
//    /// calculates the needed angle for a given value
//   fileprivate func calcAngle(_ value: Double) -> CGFloat
//   {
//       return calcAngle(value: value, yValueSum: self.yValueSum)
//   }
    
    /// calculates the needed angle for a given value
   internal func calcAngle(value: Double, yValueSum: Double) -> CGFloat
   {
        guard  let chart = chart,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else {
                return 0
        }
        return CGFloat(value) / CGFloat(yValueSum) * piePlot.maxAngle
   }
    
    
    /// Calculates the offsets of the chart to the border depending on the position of an eventual legend or depending on the length of the y-axis and x-axis labels and their position
    internal override func calculateOffsets()
    {
        super.calculateOffsets()
        
        updateCenterCircleBox()
    }
    
    internal func updateCenterCircleBox() {
        
        guard  let chart = chart,
            let piePlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Pie, .Dial, .Radar]) as? PiePlotOptions
            else {
                return
        }
        
        piePlot.internalRadius = 0.0
        
        let diameter = PieHelperFunctions.getDiameter(chart: chart)
        
        let radius = diameter / 2.0
        
        let c = chart.centerOffsets
        
        let shift = piePlot.selectionShift
        
        // create the circle box that will contain the pie-chart (the bounds of the pie-chart)
        piePlot._circleBox.origin.x = (c.x - radius) + shift
        piePlot._circleBox.origin.y = (c.y - radius) + shift
        piePlot._circleBox.size.width = diameter - shift * 2.0
        piePlot._circleBox.size.height = diameter - shift * 2.0
    }
    
    internal override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
            else { return (nil,nil) }
        
       /* let location = recognizer.location(in: chart)
        
        var handler:EventHandler?
        
        if recognizer.isKind(of: TapEventListener.self)
        {
            handler = (recognizer as? TapEventListener)?.handler
        }
        else if recognizer.isKind(of: PanEventListener.self)
        {
            handler = (recognizer as? PanEventListener)?.handler
        }
        else if recognizer.isKind(of: LongPressEventListener.self)
        {
            handler = (recognizer as? LongPressEventListener)?.handler
        }*/
       
        return PieHelperFunctions.tapHighlight(chart: chart, location: location)
           
    }
    
    // MARK: - Protocol Implementations
    
    /*** Legend View Delegate **/
    
    /// Legend range adjusted
    open override func legendRangeSelected(minimum: Double, maximum: Double) {
        
        guard  let chart = chart
            else {
                return
        }
        
        super.legendRangeSelected(minimum: minimum, maximum: maximum)
        
        if !chart.colorAxis.isEnabled {
            return
        }
        
        for pieLayer in PieLayer.getAllPieLayer(chart: chart) {
            
            guard let chartEntry = pieLayer.chartEntry
            else { continue }
            
            if chart.colorAxis.isEntryAllowed(chartEntry: chartEntry, minimum: floor(minimum), maximum: floor(maximum)) {
                pieLayer.fillColor = chart.colorAxis.getColor(entry: chartEntry)?.cgColor
            }else {
                pieLayer.fillColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
            }
        }
    }
    
    public func legendSelected(indexPath: IndexPath) {
        
        guard  let pieChart = chart,
            let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions,
               let chartEntry = pieChart.data?.dataSets[0].entryForIndex(indexPath.item)
            else {
                return
        }
        
        let midAngle = PieHelperFunctions.getMidAngle(chart: pieChart, entry: chartEntry)
        
        let pt = PieHelperFunctions.getPosition(center: piePlot.centerCircleBox, dist: piePlot.radius/2, angle: midAngle)
        
        let high = pieChart.getHighlightByTouchPoint(pt)
        
        if high != nil {
            PieHelperFunctions.taprotate(chart: pieChart, high: high!,location: pt,rotation: false,addangle:0, duration: 1.5)
        }
        
    }
    
    public func legendLongPressed(indexPath: IndexPath)
    {
        guard  let pieChart = chart,
            let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else {
                return
        }
        
        let entries = pieChart.legend.entries
        let entry = entries[indexPath.item]
        
        if entry.enabled
        {
            guard let chartEntry = pieChart.data?.dataSets[0].entryForIndex(indexPath.item)
            else { return }
            
            let midAngle = PieHelperFunctions.getMidAngle(chart: pieChart, entry: chartEntry)
            
            let pt = PieHelperFunctions.getPosition(center: piePlot.centerCircleBox, dist: piePlot.radius/2, angle: midAngle)
            
            let high = pieChart.getHighlightByTouchPoint(pt)
            
            //        if high != nil {
            //            pieChart.pieType.taprotate(high: high!,location: pt,rotation: false,addangle:0)
            //        }
            
            legendTooltipCommonFunction(high: high, location: pt)
        }
    }
    
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard  let pieChart = chart
            else {
                return
        }
        
        if pieChart.colorAxis.isEnabled {
            let legendEntry = pieChart.legend.entries[indexPath.item]
            guard let category = legendEntry.value as? String
            else { return }
            for pieLayer in PieLayer.getAllPieLayer(chart: pieChart) {
                guard let chartEntry = pieLayer.chartEntry
                else { continue }
                if chartEntry.colorString == category {
                    pieLayer.fillColor = pieChart.colorAxis.getColor(entry: chartEntry)?.cgColor
                }
            }
        }else {
            let dataSet = pieChart.data?.dataSets[0]
            
            guard let chartEntry = dataSet?.entryForIndex(indexPath.item)
            else { return }
            
            PieHelperFunctions.chartEntryEnabled(chart: pieChart, entry: [chartEntry], duration: 0.4)
        }
    }
    
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard  let pieChart = chart
            else {
                return
        }
        
        if pieChart.colorAxis.isEnabled {
            let legendEntry = pieChart.legend.entries[indexPath.item]
            guard let category = legendEntry.value as? String
            else { return }
            for pieLayer in PieLayer.getAllPieLayer(chart: pieChart) {
                guard let chartEntry = pieLayer.chartEntry
                else { continue }
                if chartEntry.colorString == category {
                    pieLayer.fillColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
                }
            }
        }
        else {
            let dataSet = pieChart.data?.dataSets[0]
            
            guard let chartEntry = dataSet?.entryForIndex(indexPath.item)
            else { return }
            
            PieHelperFunctions.removeEntry(chart: pieChart, entry: chartEntry)
        }
        
    }
    
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
        guard  let pieChart = chart
            else {
                return
        }
        
        if entry != nil
        {
            PieHelperFunctions.chartEntryEnabled(chart: pieChart, entry: entry!, duration: 0.4)
        }
    }
    
    /// Tooltip tapped
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
        guard  let pieChart = chart,
        let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions,
               let count = (pieChart.data?.dataSets[0].entryCount)
            else {
                return
        }
        
        var nextIndex = -1
        
        if entry == nil
        {
            nextIndex = 0
        }
        else
        {
            guard let curIndex = pieChart.data?.dataSets[0].entryIndex(entry: entry!)
            else { return }
            
            nextIndex = (curIndex + 1) % count
            
        }
        
        guard var nextEntry = pieChart.data?.dataSets[0].entryForIndex(nextIndex)
        else { return }
        
        while nextEntry.y == 0 || (nextEntry.y.isNaN)
        {
            nextIndex = (nextIndex + 1) % count
            
            nextEntry = pieChart.data?.dataSets[0].entryForIndex(nextIndex) ?? nextEntry
        }
        
        let midAngle = PieHelperFunctions.getMidAngle(chart: pieChart, entry: nextEntry)
        
        var radius = piePlot.radius/2
        if piePlot.drawHoleEnabled
        {
            radius =    piePlot.radius *  (1 - ((1 - piePlot.holeRadiusPercent)/2) )
        }
        
        let pt = PieHelperFunctions.getPosition(center: piePlot.centerCircleBox, dist: radius, angle: midAngle)
        
        let high = pieChart.getHighlightByTouchPoint(pt)
        
        
        //        if high != nil {
        //            pieChart.pieType.taprotate(high: high!,location: pt,rotation: false,addangle:0)
        //        }
        
        legendTooltipCommonFunction(high: high, location: pt)
        
    }
    
    
    // MARK: - Supporting Methods
    open override func distanceToCenter(x: CGFloat, y: CGFloat) -> CGFloat {
       
        guard  let pieChart = chart,
               let piePlot = CommonHelperFunctions.getPlotOption(chart: pieChart, types: [.Dial,.Pie]) as? PiePlotOptions
            else {
                return 0
        }
        
        let c = piePlot.centerCircleBox
        
        var dist = CGFloat(0.0)
        
        var xDist = CGFloat(0.0)
        var yDist = CGFloat(0.0)
        
        if x > c.x
        {
            xDist = x - c.x
        }
        else
        {
            xDist = c.x - x
        }
        
        if y > c.y
        {
            yDist = y - c.y
        }
        else
        {
            yDist = c.y - y
        }
        
        // pythagoras
        dist = sqrt(pow(xDist, 2.0) + pow(yDist, 2.0))
        
        return dist
    }
    
    func legendTooltipCommonFunction(high: Highlight?, location: CGPoint)
    {
        guard  let pieChart = chart
            else {
                return
        }
        let (entry,layer) = PieHelperFunctions.tapHighlight(chart: pieChart, location: location)
        
        pieChart.tapEventListener?.handler?.execute(pieChart, entry: entry, entryLayer: layer, pieChart.tapEventListener, location)
        
        
//        if pieChart.chartActionListener != nil
//        {
//            pieChart.chartActionListener?.tapEventCalled?(chartView: pieChart, selectedEntry: entry, selectedLayer: layer)
//        }
    }
    
    open override func getMarkerPosition(highlight: Highlight) -> CGPoint
    {
        guard  let pieChart = chart,
        let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else {
                return CGPoint()
        }
        
        let center = piePlot.centerCircleBox
        var r = piePlot.radius
        
        var off = r / 10.0 * 3.6
        
        if piePlot.isDrawHoleEnabled
        {
            off = (r - (r * piePlot.holeRadiusPercent)) / 2.0
        }
        
        r -= off // offset to keep things inside the chart
        
        let rotationAngle = piePlot.rotationAngle
        
        let entryIndex =  ChartUtils.doubleToIntSafeCast(value:highlight.x)
        
        // offset needed to center the drawn text in the slice
        let offset = piePlot.drawAngles[entryIndex] / 2.0
        
        // calculate the text position
        let x: CGFloat = (r * cos(((rotationAngle + piePlot.absoluteAngles[entryIndex] - offset) * CGFloat(pieChart._animator.phaseY)) * ChartUtils.Math.FDEG2RAD) + center.x)
        let y: CGFloat = (r * sin(((rotationAngle + piePlot.absoluteAngles[entryIndex] - offset) * CGFloat(pieChart._animator.phaseY)) * ChartUtils.Math.FDEG2RAD) + center.y)
        
        return CGPoint(x: x, y: y)
    }
    
    open override func indexForAngle(_ angle: CGFloat) -> Int
    {
        guard  let pieChart = chart,
               let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
                   else {
                       return -1
               }
        
        // take the current angle of the chart into consideration
        //        let a = ChartUtils.normalizedAngleFromAngle(angle - self.rotationAngle)
        var a = ChartUtils.normalizedAngleFromAngle(angle - piePlot.rotationAngle)
        
        if piePlot.sliceDirection == .counterClockwise {
            a = 360 - a
        }
        
        for i in 0 ..< piePlot.absoluteAngles.count
        {
            if piePlot.absoluteAngles[i] > a
            {
                return i
            }
        }
        
        return -1 // return -1 if no index found
    }
    
    // MARK: - Animation Delegate
       
   open override func animatorUpdated(_ chartAnimator: Animator)
   {
       guard let pieChart = chart,
            pieChart.data != nil
        else {
           return
       }
       
       calcMinMax()
       pieChart.setNeedsDisplay()
       chart?.interactionAnimationInProgress = true
   }
   
   open override func animatorStopped(_ chartAnimator: Animator)
   {
       guard let pieChart = chart,
            pieChart.data != nil
        else {
           return
       }
       
       chart?.interactionAnimationInProgress = false
   }
    
    
}
