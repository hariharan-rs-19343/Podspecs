//
//  DialPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 14/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class DialPreprocessor:PiePreprocessor
{
    internal func axisCorrection()
    {
        guard  let chart = chart,
            let data = chart.data
            else {
                return
        }
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
          
            yAxis.spaceTop = 0
            yAxis.spaceBottom = 0
                 
            let dataMin = data.getYMin(axisIndex: yAxis.axisIndex)
                 
            let dataMax = data.getYMax(axisIndex: yAxis.axisIndex)
             
            if yAxis._customAxisMin == nil
            {
                if dataMin >= 0
                {
                    yAxis.setAxis(minimum: 0.0)
                }
            }
           
            if yAxis._customAxisMax == nil
            {
                if dataMax <= 0
                {
                    yAxis.setAxis(maximum: 0)
                }
            }
        }
             
    }

    
    // MARK: - Data Updation Calculation
    
    open override func notifyDataSetChanged(redrawRequired:Bool)
    {
        guard  let chart = chart,
                  let data = chart.data
                  else {
                      return
              }
        
        chart.updateAxisObjects()
        
//        axisCorrection()
        
        calcMinMax()
         
        for yAxisRenderer in chart.yAxisRenderers where yAxisRenderer.axis != nil && yAxisRenderer.axis!.enabled {
             yAxisRenderer.computeAxis(min: (yAxisRenderer.axis?._axisMinimum)!, max: (yAxisRenderer.axis?._axisMaximum)!, inverted: (yAxisRenderer.axis?.inverted)!)
         }
        
        chart._xAxisRenderer?.computeAxis(min: chart._xAxis._axisMinimum, max: chart._xAxis._axisMaximum, inverted: chart._xAxis.isInverted)
         
        if let legend = chart._legend,
            !legend.isLegendCustom
        {
            chart._legendRenderer?.computeLegend(data: data)
        }
         
        notifyPlotOptionUpdated()
        
        calculateOffsets()
        
        calcAngles()
         
        if redrawRequired
        {
            chart.setNeedsDisplay()
        }
    }
    
    open override func calcMinMax() {
        
        guard  let chart = chart,
              let data = chart.data
            else {
                    return
                }
        
        chart.xAxis.calculate(min: data.xMin, max: data.xMax)
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            
            yAxis.spaceTop = 0
            yAxis.spaceBottom = 0
            
            let dataMin = data.getYMin(axisIndex: yAxis.axisIndex)
            
            let dataMax = data.getYMax(axisIndex: yAxis.axisIndex)
            
//            let storedMinMax = (yAxis.axisMinimum,yAxis.axisMaximum)
            
            yAxis.calculate(min: dataMin , max: dataMax)
            /*
            if let _customAxisMin = yAxis._customAxisMin
            {
                yAxis.axisMinimum = _customAxisMin
            }
            
            if let _customAxisMax = yAxis._customAxisMax
            {
                yAxis.axisMaximum = _customAxisMax
            }
            */
        }
        
        axisCorrection()
    }
    
    /// Calculates the offsets of the chart to the border depending on the position of an eventual legend or depending on the length of the y-axis and x-axis labels and their position
    internal override func calculateOffsets()
    {
        guard  let chart = chart
            else {
                    return
                }
        
        super.calculateOffsets()
        
        updateCenterAndRadius()
        
        if let offsets = offsetsForViewPort() {
            
            chart._viewPortHandler.restrainViewPort(offsetLeft: chart._viewPortHandler.offsetLeft + offsets.0, offsetTop: chart._viewPortHandler.offsetTop + offsets.1, offsetRight: chart._viewPortHandler.offsetRight + offsets.2, offsetBottom: chart._viewPortHandler.offsetBottom + offsets.3)
            
            updateCenterCircleBox()
            
            updateCenterAndRadius()
        }
        
        chart.prepareOffsetMatrix()
        chart.prepareValuePxMatrix()
    }
    
    fileprivate func calcAngles()
    {
        guard let chart = chart,
            let data = chart.data,
            let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions
            else { return }
        
        dialOption.drawAngles = [CGFloat]()
        dialOption.absoluteAngles = [CGFloat]()
        
        let entryCount = data.entryCount
        
        dialOption.drawAngles.reserveCapacity(entryCount)
        dialOption.absoluteAngles.reserveCapacity(entryCount)
        
        let dataSets = data.dataSets
        
        var cnt = 0
        
        for i in 0 ..< data.dataSetCount
        {
            let set = dataSets[i]
            let entryCount = set.entryCount
            
            guard let transformer = chart.getTransformer(axisIndex: set.axisIndex) as? PolarTransformer
                else { return }
            
            for j in 0 ..< entryCount
            {
                guard let e = set.entryForIndex(j),
                let yAxis = chart.getYAxis(atIndex: set.axisIndex)
                    else { continue }
                
                var y = e.y.isNaN ? 0 : e.y
                
                if y > yAxis.axisMaximum
                {
                    y = yAxis.axisMaximum
                }
                
                if y < yAxis.axisMinimum
                {
                    y = yAxis.axisMinimum
                }
                
                let fromVal = y < 0 ? min(0,yAxis.axisMaximum) : max(0,yAxis.axisMinimum)
                
                let rect = CGRect(x: 0, y: 0, width: abs(fromVal - y), height: abs(fromVal - y))
                
                var angle = rect.applying(transformer.valueToPixelMatrix).height
                
                angle = angle > dialOption.maxAngle ? dialOption.maxAngle : angle
                
                if y < 0
                {
                    angle = -angle
                }
                
                dialOption.drawAngles.append(angle)
                
                if cnt == 0
                {
                    dialOption.absoluteAngles.append(dialOption.drawAngles[cnt])
                }
                else
                {
                    dialOption.absoluteAngles.append(dialOption.absoluteAngles[cnt - 1] + dialOption.drawAngles[cnt])
                }
                
                cnt += 1
            }
        }
    }
    
//    override public func calcAngle(value: Double, yValueSum: Double) -> CGFloat {
//           guard let dialOption = getPlotOptions(type: .Dial) as? DialPlotOptions
//               else { return 0 }
//           return CGFloat(value) / CGFloat(yValueSum) * dialOption.maxAngle
//       }
    
    internal func notifyPlotOptionUpdated()
    {
        guard  let chart = chart
        else {
                return
            }
        
        for yAxis in chart.getYAxisArray()
        {
            guard let transformers = chart.getTransformer(axisIndex: yAxis.axisIndex) as? PolarTransformer,
                let dialOptions = chart.getPlotOptions(type: .Dial) as? DialPlotOptions
                else { continue }
            
            transformers.xScaleRange = dialOptions.maxAngle
            transformers.yScaleRange = dialOptions.maxAngle
            transformers.startAngle = dialOptions.startAngle
            transformers.direction = dialOptions.direction
            transformers.angleAxisDependency = .yAxis
        }
        
    }
    
    func updateCenterAndRadius()
    {
        guard let dialPlot = chart?.getPlotOptions(type: .Dial) as? DialPlotOptions
            else { return }
        
        for yAxis in chart!.getYAxisArray()
        {
            guard let transformers = chart?.getTransformer(axisIndex: yAxis.axisIndex) as? PolarTransformer
                else { continue }
            dialPlot.radius = PieHelperFunctions.updateRadius(chart: chart!, dialPlot: dialPlot)
            transformers.centerPoint = dialPlot.centerCircleBox
            transformers.radius = dialPlot.radius
        }
        
    }
    
    func offsetsForViewPort() -> (CGFloat,CGFloat,CGFloat,CGFloat)? {
        
        var (leftOffset, topOffset, rightOffset, bottomOffset): (CGFloat, CGFloat, CGFloat, CGFloat) = (0.0, 0.0, 0.0, 0.0)
        
        guard let chart = chart,
              let dialPlot = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              let dataset = chart.data?.getDataSetFor(plotTypes: [.Dial], axisIndex: 0, isVisibleDatasets: true).first as? ChartDataSet,
              let yAxis = chart.getYAxis(atIndex: dataset.axisIndex) else {
            return nil
        }
        
        var correctionNeeded: Bool = false
            
        let startAngle:CGFloat = dialPlot.startAngle
        let maxAngle:CGFloat = dialPlot.maxAngle
        let direction: SliceDirection = dialPlot.direction
        let radius: CGFloat = dialPlot.radius
        
        if maxAngle > 180 {
            return nil
        }
        
        var endAngle = startAngle + maxAngle
        
        let isClockwise = direction == .clockwise
        
        if !isClockwise {
            endAngle = startAngle - maxAngle
        }
        
        if endAngle >= 360 {
            endAngle = endAngle - 360
        }
        
        if endAngle < 0 {
            endAngle = 360 + endAngle
        }
        
        let width = chart.viewPortHandler.contentWidth
        let height = chart.viewPortHandler.contentHeight
        
        var maxSize = CGSize.zero
        
        if dialPlot.minMaxLabelConfig.enabled {
            let minValueSize = (dialPlot.minMaxLabelConfig.formatter.getFormattedTextforValue?(value: yAxis.axisMinimum, type: .minValue, data: nil) ?? String(yAxis.axisMinimum)).size(withAttributes: dialPlot.minMaxLabelConfig.AttributedString)
            
            let maxValueSize = (dialPlot.minMaxLabelConfig.formatter.getFormattedTextforValue?(value: yAxis.axisMaximum, type: .maxValue, data: nil) ?? String(yAxis.axisMaximum)).size(withAttributes: dialPlot.minMaxLabelConfig.AttributedString)
            
            maxSize.width = max(minValueSize.width / 2.0,maxValueSize.width / 2.0) + dialPlot.minMaxLabelConfig.xOffset
            maxSize.height = max(minValueSize.height,maxValueSize.height) + dialPlot.minMaxLabelConfig.yOffset
        }
        
        if dataset.isDrawValuesEnabled {
            
            for entryIndex in 0 ..< dataset.entryCount {
                
                guard let entry = dataset.entryForIndex(entryIndex) else { continue }
                
                let value = entry.y.isNaN ? 0 : entry.y
                
                let text = dataset.valueFormatter?.stringForValue(
                    value,
                    entry: entry,
                    dataSetIndex: 0,
                    viewPortHandler: chart.viewPortHandler) ?? String(value)
                
                let textSize = text.size(withAttributes: [NSAttributedString.Key.font: dataset.valueFont])
                
                maxSize.width = max(textSize.width / 2.0 + dialPlot.centerLabelPadding, maxSize.width)
                maxSize.height = max(textSize.height + dialPlot.centerLabelPadding, maxSize.height)
            }
        }
        
        if dialPlot.needleEnabled {
            maxSize.width += dialPlot.needleShapeProperties.size.width / 2.0
            maxSize.height += dialPlot.needleShapeProperties.size.width / 2.0
        }
        
        if maxSize != .zero {
            
            if (startAngle >= 270 && endAngle <= 90 && isClockwise) || (startAngle <= 90 && endAngle >= 270 && !isClockwise) {
                if radius + maxSize.width >= width {
                    correctionNeeded = true
                    rightOffset = maxSize.width
                }
            }
            else if (startAngle >= 90 && endAngle >= startAngle && endAngle <= 270 && isClockwise) || (startAngle <= 270 && endAngle >= 90 && startAngle >= endAngle && !isClockwise) {
                if radius + maxSize.width >= width {
                    correctionNeeded = true
                    leftOffset = maxSize.width
                }
            }
            else if (startAngle == 0 && endAngle == 180 && !isClockwise) || (startAngle >= 0 && endAngle >= 180 && !isClockwise)
                        || (startAngle == 180 && endAngle == 0 && isClockwise) {
                if radius + maxSize.height >= height {
                    correctionNeeded = true
                    bottomOffset = maxSize.height
                }
            }
            else  if (startAngle == 180 && endAngle == 0 && !isClockwise) || (startAngle >= 0 && startAngle <= endAngle && endAngle <= 180 && isClockwise) {
                if radius + maxSize.height >= height {
                    correctionNeeded = true
                    topOffset = maxSize.height
                }
            }
        }
        
        if chart.extraTopOffset > 0 || chart.extraRightOffset > 0 || chart.extraBottomOffset > 0 || chart.extraLeftOffset > 0 {
            correctionNeeded = true
        }
        
        return correctionNeeded ? (leftOffset + chart.extraLeftOffset, topOffset + chart.extraTopOffset, rightOffset + chart.extraRightOffset, bottomOffset + chart.extraBottomOffset) : nil
    }
    
    internal override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        guard let chart = chart
            else { return (nil,nil) }
        
        var entry:ChartDataEntry? = nil
       
        let high = chart.getHighlightByTouchPoint(location)
       
        let entryLayer:ChartEntryLayer? = DialPreprocessor.getDialDataLayerInPoint(chart: chart, loc: location)
       
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
       
        return (entry,entryLayer)
           
    }
    
    public static func getDialDataLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> PieLayer?{
        for layer in PieLayer.getAllPieLayer(chart: chart)
        {
            if !layer.isKind(of: DialLevelLayer.self) && layer.path != nil && (layer.path?.contains(loc))!
            {
                return (layer)
            }
            
        }
        return nil
    }
    
    open override func indexForAngle(_ angle: CGFloat) -> Int
    {
        guard  let pieChart = chart,
               let piePlot = CommonHelperFunctions.getPlotOption(chart: pieChart, types: [.Dial]) as? PiePlotOptions,
               let dataSet = pieChart.data?.dataSets[0],
               let transformer = pieChart.getTransformer(axisIndex: dataSet.axisIndex) as? PolarTransformer
                   else {
                       return -1
               }
        
        // take the current angle of the chart into consideration
        //        let a = ChartUtils.normalizedAngleFromAngle(angle - self.rotationAngle)
        
        let fromAngle = transformer.absoluteAngleForValue(value: 0.0)
        
        var a = ChartUtils.normalizedAngleFromAngle(angle - fromAngle)
        
        if piePlot.sliceDirection == .counterClockwise {
            a = 360 - a
        }
        
        for i in 0 ..< piePlot.absoluteAngles.count
        {
            if piePlot.absoluteAngles[i] > a
            {
                return i
            }
        }
        
        return -1 // return -1 if no index found
    }
    
}
