//
//  BarPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 13/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class BarPreprocessor:AxisChartPreprocessor
{
    
    // MARK: - Bar Specific Properties
    
    fileprivate let typeAllowed = [ChartType.Bar,ChartType.Mekko, ChartType.Bullet, ChartType.WaterFall, ChartType.BoxPlot, ChartType.HorizontalBarRange]
    
    fileprivate var allowed:Bool = true
    
    fileprivate var minPadding:Double = 0.0
    
    fileprivate var maxPadding:Double = 0
    
    fileprivate var currentDatasetCount = 0
    
    fileprivate var toggle:Bool = true
    
    fileprivate var tempBarCount = 0
    
    fileprivate var oldScale:CGFloat = 0
    
    fileprivate var oldWidth:CGFloat = 0
    
    // used to calculate groupWidth
    fileprivate var currentGroupCount = 0
    
    /// flag that indicates if colors array has already been updated or not
    fileprivate var _colorsUpdated = false
    
    //    open var xUniqueValues = Set<Double>()
    
    open var positiveSum:[Double:Double] = [:]
    
    open var negativeSum:[Double:Double] = [:]
    
    
    override func initialize() {
        guard  let chart = chart,
        let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
            else {   return }
        
        if chart.isCombined
        {
            barPlotOptions.highlightFullBarEnabled = true
        }
    }
    
    // MARK: - Data updation calculation
    
    /*open func axisCorrections()
    {
        guard  let chart = chart,
        let data = chart.data else {
            return
        }
        
        for axis in chart.yAxisArray where axis.isEnabled {
            
            if (data.getYMin()) >= Double(0)
            {
                if chart.interactionAnimationInProgress && axis.resizeEnabled {
                    
                }else{
                    axis.axisMinimum = 0.0
                }
            }
            else
            {
                if chart.interactionAnimationInProgress && axis.resizeEnabled {
                    axis._customAxisMin = true
                }else{
                    axis.resetCustomAxisMin()
                }
            }
            
            
            if (data.getYMax()) <= Double(0)
            {
                if chart.interactionAnimationInProgress && axis.resizeEnabled {
                }else {
                    if data.getYMax() == 0 && data.getYMin() == 0
                    {
                        axis.axisMaximum = 1.0
                    }
                    else{
                        axis.axisMaximum = 0.0
                    }
                }
            }
            else
            {
                if chart.interactionAnimationInProgress && axis.resizeEnabled {
                    axis._customAxisMax = true
                }else{
                    axis.resetCustomAxisMax()
                }
            }
        }
    }*/
    
    open func axisCorrections()
    {
        guard  let chart = chart,
        let data = chart.data else {
            return
        }
      
      let barDataSets:[IChartDataSet] = getVisibleBarDataSets(data: data)
            
            if barDataSets.count == 0 {
                return
            }
        
        for axis in chart.yAxisArray where axis.isEnabled {
            
            if (data.getYMin(axisIndex: axis.axisIndex)) >= Double(0) && !axis.isAxisMinCustom
            {
              axis.setAxis(minimum: 0.0)
            }
            
            
            if (data.getYMax(axisIndex: axis.axisIndex)) <= Double(0)
            {
              if data.getYMax(axisIndex: axis.axisIndex) == 0 && data.getYMin(axisIndex: axis.axisIndex) == 0 && !axis.isAxisMaxCustom
              {
                  axis.setAxis(maximum: 1.0)
              }
              else if !axis.isAxisMinCustom
              {
                  axis.setAxis(maximum: 0.0)
              }
            }
            
            if !chart.isRotated {
                let datasets = data.getDataSetFor(plotTypes: typeAllowed, axisIndex: axis.axisIndex)
                
                if let dataset = datasets.first as? ChartBaseDataSet, let plotOption = (chart.getPlotOptions(type: dataset.plotType) as? BarPlotOptions) {
                    
                    var pointSize = dataset.isDrawValuesEnabled && (plotOption.groupSpacePixel != 0 && !plotOption.isStacked || plotOption.groupSpacePixel == 0 && !plotOption.isStacked) ? CommonHelperFunctions.getLargestPointSize(datasets: datasets) : 0.0
                    
                    if plotOption.stackedSumEnabled {
                        pointSize = max(pointSize, plotOption.stackSumValueFont.pointSize)
                    }
                    
                    if pointSize != 0 {
                        let padVal = chart.computeYPaddingValue(axis: axis, range: axis.axisRange, neededWidth: pointSize + ChartUtils.valueOffsetFor(dataSet: dataset, plotOptions: plotOption))
                        
                        if data.getYMax(axisIndex: axis.axisIndex) >= axis.axisMaximum || data.getYMax(axisIndex: axis.axisIndex) + padVal > axis.axisMaximum {
                            axis.setAxis(maximum: axis.axisMaximum + padVal)
                        }
                        
                        if data.getYMin(axisIndex: axis.axisIndex) < 0 && (data.getYMin(axisIndex: axis.axisIndex) <= axis.axisMinimum || data.getYMin(axisIndex: axis.axisIndex) - padVal < axis.axisMinimum) {
                            axis.setAxis(minimum: axis.axisMinimum - padVal)
                        }
                    }
                }
            }
        }
    }
    
    func getDataMin(data:ChartData, yAxis:YAxis) -> Double
    {
        var axisMinimum = data.getYMin(axisIndex: yAxis.axisIndex)
        if (axisMinimum >= Double(0)) {
            axisMinimum = 0.0
        }
        return axisMinimum
    }
    
    func getDataMax(data:ChartData, yAxis:YAxis) -> Double
    {
        var axisMaximum = data.getYMax(axisIndex: yAxis.axisIndex)
        if (axisMaximum <= Double(0)) {
            axisMaximum = 0.0
        }
        return axisMaximum
    }
    
    open override func notifyDataSetChanged(redrawRequired: Bool)
    {
        guard  let chart = chart,
                let viewPortHandler = chart._viewPortHandler,
                let data = chart.data
        else {
            return
        }
        
        updateArrayOfDataSets()
        
        // Initialize Code
        chart._xAxis.spaceMin = 0.5
        chart._xAxis.spaceMax = 0.5
        
        //Data calculation
        self.calcPosNegSum()
        
        let valueForTouch = chart.valueForTouchPoint(point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop), axisIndex: 0)
        
        var oldContentLeftX = chart.isRotated ?  valueForTouch.y : valueForTouch.x
        
        oldContentLeftX = oldContentLeftX == 0 ? CGFloat(chart.xAxis.isInverted ? data._xMax * 2 : -1 ) : oldContentLeftX
        
        // Space Min Max Pixels not supported in Bar.. Need to Check...
//        resetSpaceMinMaxPixels()
    
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
        
        // YAxis min max adjusted based on chart needs
//        axisCorrections()
        
        if !chart.customScaleEnabled
        {
            calculateOnDataSetChanged()
        }
        else
        {
            calculateGroupSpaceForCustomScale()
        }
        
        checkIfBaseLineValueWithinRange()
        
        calcMinMax()
        
        // YAxis min max adjusted based on chart needs
        axisCorrections()
        
        chart.prepareValuePxMatrix()
        
        chart.calculateOffsets()
        
        if redrawRequired
        {
            chart.moveViewToX(Double(oldContentLeftX))
        }
        else{
            chart.moveViewToXWithoutRedraw(xValue: Double(oldContentLeftX))
        }

    }
    
    internal func callSuperNotifyDataSetChanged(redrawRequired:Bool)
    {
        super.notifyDataSetChanged(redrawRequired: redrawRequired)
    }
    
    internal override func calcMinMax()
    {
        guard  let chart = chart,
            let data = chart.data,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
        else{
            return
        }
       
        if barPlotOptions.fitBars
        {
            chart._xAxis.calculate(
                min: data.xMin - 0.5,
                max: data.xMax + 0.5)
        }
        else
        {
            chart._xAxis.calculate(min: data.xMin, max: data.xMax)
        }
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
//            yAxis.calculate(
//                min: (barPlotOptions.stackedPercentEnabled) ? 0 : data.getYMin(axisIndex: yAxis.axisIndex),
//                max: (barPlotOptions.stackedPercentEnabled) ? 100 : data.getYMax(axisIndex: yAxis.axisIndex) )
            yAxis.calculate(
                min: (barPlotOptions.stackedPercentEnabled) ? 0 : getDataMin(data: data, yAxis: yAxis),
                max: (barPlotOptions.stackedPercentEnabled) ? 100 : getDataMax(data: data, yAxis: yAxis) )
        }
    }
    
    internal func callSuperCalculateOffsets()
    {
        super.calculateOffsets()
    }
    
    internal override func calculateOffsets()
    {
        
        guard  let chart = chart,
            let barData = chart.data,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
            let viewPortHandler = chart._viewPortHandler
            else {
            return
        }
        
        let barDataSets:[IChartDataSet] = barData.dataSets.filter({
            $0.plotType == .Bar || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot
        })
        
        if barDataSets.count <= 0
        {
            return
        }
        
        computeAxisLabelOffsets()
        
        if !chart._customViewPortEnabled
        {
            updateViewPortOffsets()
            
            let barSet = barDataSets[0]
            
            if barSet.plotType == .Bullet && barPlotOptions.adjustViewToLevelWidth && barPlotOptions.levelMarkerWidthPixel != 0
            {
                let levelpixel = barPlotOptions.levelMarkerWidthPixel + barPlotOptions.barSpacePixel
                
                if chart.isRotated {
                    let topOffset = (chart.frame.height/2) - CGFloat(levelpixel/2) < 0 ? 0 : (chart.frame.height/2) - CGFloat(levelpixel/2)
                    
                    let bottomOffset = chart.frame.height - ((chart.frame.height/2) + CGFloat((levelpixel/2))) < 0 ? 0 : chart.frame.height - ((chart.frame.height/2) + CGFloat((levelpixel/2)))
                    
                    
                    viewPortHandler._contentRect.origin.y = topOffset
                    viewPortHandler._contentRect.size.height = viewPortHandler._chartHeight - bottomOffset - topOffset
                }
                else {
                    let offsetLeft = (chart.frame.width/2) - CGFloat(levelpixel/2) < 0 ? 0 : (chart.frame.width/2) - CGFloat(levelpixel/2)
                    
                    let offsetRight = chart.frame.width - ((chart.frame.width/2) + CGFloat((levelpixel/2))) < 0 ? 0 : chart.frame.width - ((chart.frame.width/2) + CGFloat((levelpixel/2)))
                    
                    chart._viewPortHandler._contentRect.origin.x = offsetLeft
                    chart._viewPortHandler._contentRect.size.width = chart.viewPortHandler.chartWidth - offsetLeft - offsetRight
                }
            }
            
        }
        
        chart.prepareOffsetMatrix()
        chart.prepareValuePxMatrix()
    }
    
    override open func getMarkerPosition(highlight: Highlight) -> CGPoint {
        
        if let chart = chart,chart.isRotated {
            return CGPoint(x: highlight.drawY, y: highlight.drawX)
        }
        
        return super.getMarkerPosition(highlight: highlight)
    }
    
    func resetSpaceMinMaxPixels()
    {
        guard  let chart = chart
            else {
            return
        }
        
        chart.xAxis.spaceMinPixel = 0
        chart.xAxis.spaceMaxPixel = 0
        
        chart.xAxis.spaceMin = 0
        chart.xAxis.spaceMax = 0
        
        for axis in chart.yAxisArray where axis.isEnabled
        {
            axis.spaceMinPixel = 0
            axis.spaceMaxPixel = 0
        }
    }
    
    fileprivate func calculateGroupSpaceForCustomScale() {
        guard  let chart = chart,
                   let barData = chart.data,
                   let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
                   else {
                   return
               }
        
        if barPlotOptions.isStacked {
            return
        }
        
        let barDataSets:[IChartDataSet] = barData.dataSets.filter({
            ($0.plotType == .Bar || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot || $0.plotType == .HorizontalBarRange) && ($0.isVisible)
        })
        
        guard
            barDataSets.count > 1
            else {
                return
            }
        
        let visibleCount = barDataSets.count
                        
        let intervalValue:Double = 1.0
        
        let sliceWidth = intervalValue / Double(visibleCount)
        
        barPlotOptions.groupSpace = sliceWidth * (0.1)
        
        let newWidth = (intervalValue - barPlotOptions.groupSpace) / Double(visibleCount)
        
        barPlotOptions.barWidth =  newWidth * (0.9)
        
        barPlotOptions.barSpace =  newWidth * (0.1)
        
        self.groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace, xInverted: chart.xAxis.isInverted)
        
    }

    
    // MARK: -
    
    open func calcPosNegSum()
    {
        guard  let chart = chart,
                let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
            else {
                return
            }
       
        if barPlotOptions.stackedPercentEnabled
        {
            updatePosNegSum()
        }
        updateEntriesStackValue()
    }
    
    open func updatePosNegSum()
    {
        positiveSum.removeAll()
        
        negativeSum.removeAll()
        
        guard  let chart = chart,
            let data = chart.data
        else {
            return
        }
        
        let barDataSets:[IChartDataSet] = data.dataSets.filter({
            $0.plotType == .Bar || $0.plotType == .Mekko || $0.plotType == .Bullet
        })
        
        for setIndex in 0..<barDataSets.count
        {
            let set = barDataSets[setIndex]
            
            if !set.isVisible
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else { continue }
                
                if  entry.x.isNaN || entry.y.isNaN || (set.plotType == .Mekko && (entry.size ?? 0.0).isZero)
                {
                    continue
                }
                
                if entry.y >= 0
                {
                    if positiveSum[entry.x] == nil
                    {
                        positiveSum[entry.x] = entry.y
                    }
                    else{
                        let yValue = (positiveSum[entry.x] ?? 0)  + entry.y
                     
                        positiveSum[entry.x] = yValue
                   }
                    
                }
                else{
                    
                    if negativeSum[entry.x] == nil
                    {
                        negativeSum[entry.x] = abs(entry.y)
                    }
                    else{
                        let yValue = (negativeSum[entry.x] ?? 0) + abs(entry.y)
                        
                        negativeSum[entry.x] = yValue
                    }
                }
              
            }
        }
    }
    
    open func updateEntriesStackValue()
    {
        entriesStackedYValue.removeAll()
        
        guard let chart = chart,
              let data = chart.data,
              let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
            else {
                return
            }
        
        if (getVisibleBarDataSets(data: data).count == 0) {
            return
        }
        
        var posY:[Double:Double] = [:]
        
        var negY:[Double:Double] = [:]
        
        var posSum:[Double:[Int:Double]] = [:]
        var negSum:[Double:[Int:Double]] = [:]
        
        var maxY = -(Double.greatestFiniteMagnitude)
        var minY = -(Double.greatestFiniteMagnitude)
        
         let barDataSets:[IChartDataSet] = data.dataSets.filter({
             $0.plotType == .Bar || $0.plotType == .Mekko || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot || $0.plotType == .HorizontalBarRange
               })
        var barDatasetIndex = 0
        
        for barSetIndex in 0..<data.dataSets.count
        {
            let set =   data.dataSets[barSetIndex]
            
            if !(set.plotType == .Bar || set.plotType == .Mekko || set.plotType == .Bullet || set.plotType == .WaterFall || set.plotType == .BoxPlot || set.plotType == .HorizontalBarRange)
            {
                continue
            }
            
            let stackgroup = data.getStackGroupArrayFor(setIndex: barDatasetIndex)
            let lastDatasetIndexSoFor = CommonHelperFunctions.getLastDatasetIndexSoFor(stackedGroup: stackgroup, setIndex: barDatasetIndex)
            barDatasetIndex += 1
            
//            let baseLineValue = set.axisIndex //COMMENTED SINCE UNUSED
            let setIndex = barSetIndex
            
            if !set.isVisible
            {
                continue
            }
            
            // sum of y value for cascade
            var currentSum = 0.0
            
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else { continue }
                
                var entryYValue = entry.y
                
                if barPlotOptions.stackedPercentEnabled
                {
                    
                    
                    entryYValue = positiveSum[entry.x] != nil ? (entry.y/positiveSum[entry.x]!)*100 : Double.nan
                    
                    if entry.y < 0
                    {
                        entryYValue = Double.nan
                    }
                }
                
                if  entry.x.isNaN || (set.plotType == .Mekko && (entry.size ?? 0.0).isZero)
                {
                    /// Newly added from line calposnegsum
                    if entriesStackedYValue[setIndex] != nil
                    {
                        entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                    }
                    else{
                        entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                    }
                    ///*************************///
                    
                    continue
                }
                else if entryYValue.isNaN
                {
                    var posValue:Double = 0
                    var negValue:Double = 0
                    
                    if set.yMax > 0
                    {
                        if posY[entry.x] != nil
                        {
                            posValue = posY[entry.x]!
                        }
                    }
                    else{
                        if negY[entry.x] != nil
                        {
                            negValue = -negY[entry.x]!
                        }
                    }
                    
                    if entriesStackedYValue[setIndex] == nil {
                        entriesStackedYValue[setIndex] = [:]
                    }
                    
                    if set.yMax > 0
                    {
                        entriesStackedYValue[setIndex]![entryIndex] = posValue
                    }
                    else{
                        entriesStackedYValue[setIndex]![entryIndex] = negValue
                    }
                    
                    if (set.plotType == .WaterFall) {
                        if entry.plotData != nil && (entry.plotData as? Int) != nil && (entry.plotData as! Int) == 1 {
                            if currentSum >= 0.0 {
                                posY[entry.x] = currentSum
                            }
                            else{
                                negY[entry.x] = abs(currentSum)
                            }
                        }
                    }
                    
                    continue
                }
                
                if (set.plotType == .WaterFall) && (entryYValue == 0 || (entry.origY != nil && entry.origY == 0) ) {
                    
                    if WaterFallHelperFunction.isCascade(entry: entry) {
                        
                        if entry.origY == 0 {
                            entryYValue = 0
                            entry.y = 0
                        }
                    
                        if currentSum >= 0.0{
                        
                            if posSum[entry.x] == nil {
                            
                                posSum[entry.x] = [setIndex:currentSum]
                                
                                if entriesStackedYValue[setIndex] != nil
                                {
                                    entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                                }
                                else{
                                    entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                                }
                            
                                posY[entry.x] = currentSum
                            }
                            else{
                                guard let  lastPositiveDataSetIndexSoFar = posSum[entry.x]?.keys.max(),
                                      let yValueXPositive = posSum[entry.x]![lastPositiveDataSetIndexSoFar]
                                else { continue }
                            
                                let yValue = yValueXPositive + currentSum
                                
                                if entriesStackedYValue[setIndex] != nil
                                {
                                    entriesStackedYValue[setIndex]![entryIndex] = yValue
                                }
                                else{
                                    entriesStackedYValue[setIndex] = [entryIndex:yValue]
                                }
                            
                                posSum[entry.x]![setIndex] = yValue
                            
                                posY[entry.x] = yValue
                            }
                        }
                        else{
                            
                            if negSum[entry.x] == nil {
                            
                                negSum[entry.x] = [setIndex:abs(currentSum)]
                                
                                if entriesStackedYValue[setIndex] != nil
                                {
                                    entriesStackedYValue[setIndex]![entryIndex] = currentSum
                                }
                                else{
                                    entriesStackedYValue[setIndex] = [entryIndex:currentSum]
                                }
                            
                                negY[entry.x] = abs(currentSum)
                            }
                            else{
                                guard let  lastNegativeDataSetIndexSoFar = negSum[entry.x]?.keys.max(),
                                      let yValueXNegative = negSum[entry.x]![lastNegativeDataSetIndexSoFar]
                                    else { continue }
                            
                                let yValue = yValueXNegative + abs(currentSum)
                                
                                if entriesStackedYValue[setIndex] != nil
                                {
                                    entriesStackedYValue[setIndex]![entryIndex] = -yValue
                                }
                                else{
                                    entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                                }
                            
                                negSum[entry.x]![setIndex] = yValue
                            
                                negY[entry.x] = yValue
                            }
                        }
                    
                        continue
                    }
                }
                
                if entryYValue >= 0
                {
                    if posSum[entry.x] == nil
                    {
                        
                        posSum[entry.x] = [setIndex:entryYValue]
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                        }
                        
                        
                        posY[entry.x] = entryYValue
                    }
                    else{
                        
                        guard let yValueXPositive = getstackedValueBefore(index: lastDatasetIndexSoFor, stackGroup: stackgroup, stackedSumForX: posSum[entry.x], barDatasets: barDataSets)
                        else { continue }
                        
                        let yValue = yValueXPositive + entryYValue
                        
                        posSum[entry.x]![setIndex] = yValue
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = yValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:yValue]
                        }
                        
                        posY[entry.x] = yValue
                        
                        // CASE :- Same X For differnt entry
                        // Since Bar has only unique X. This case won't come.
                        /*if false    //lastPositiveDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if posSum[entry.x]?.keys.count == 1
                            {
                                if posSum[entry.x]![setIndex]! < entryYValue
                                {
                                    posSum[entry.x]![setIndex] = entryYValue
                                    posY[entry.x] = entryYValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                                
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (posSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    //Ignoring the current data set index
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                    
                                }
                                
                                let yValue = posSum[entry.x]![prevDataSetIndex]! + entryYValue
                                
                                if yValue > posSum[entry.x]![setIndex]!
                                {
                                    posSum[entry.x]![setIndex] = yValue
                                    posY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                                
                                
                            }
                        }
                        else{
                            let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + entryYValue
                            
                            posSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            posY[entry.x] = yValue
                            
                        }*/
                        
                    }
                    
                }
                else{
                    
                    if negSum[entry.x] == nil
                    {
                        
                        negSum[entry.x] = [setIndex:abs(entryYValue)]
                        
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                        }
                        
                        negY[entry.x] = abs(entryYValue)
                        
                    }
                    else{
                        
                        guard let yValueXNegative = getstackedValueBefore(index: lastDatasetIndexSoFor, stackGroup: stackgroup, stackedSumForX: negSum[entry.x], barDatasets: barDataSets)
                            else { continue }
                        
                        let yValue = yValueXNegative + abs(entryYValue)
                        
                        negSum[entry.x]![setIndex] = yValue
                        
                        negY[entry.x] = yValue
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = -yValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                        }
                        
                        // CASE :- Same X For differnt entry
                        // Since Bar has only unique X. This case won't come.
                        /*if lastNegativeDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if negSum[entry.x]?.keys.count == 1
                            {
                                if negSum[entry.x]![setIndex]! < abs(entryYValue)
                                {
                                    negSum[entry.x]![setIndex] = abs(entryYValue)
                                    negY[entry.x] = abs(entryYValue)
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (negSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                }
                                
                                let yValue = negSum[entry.x]![prevDataSetIndex]! + abs(entryYValue)
                                
                                if yValue > negSum[entry.x]![setIndex]!
                                {
                                    negSum[entry.x]![setIndex] = yValue
                                    negY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                        }
                        else{
                            let yValue = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]! + abs(entryYValue)
                            
                            negSum[entry.x]![setIndex] = yValue
                            
                            negY[entry.x] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                            }
                            
                            
                            
                        }*/
                    }
                }
                
                if !entry.x.isNaN && !entry.y.isNaN {
                    currentSum += entryYValue
                }
                
                // Min & Max
                if posY[entry.x] != nil && posY[entry.x]! > maxY
                {
                    maxY = posY[entry.x]!
                }
                
                if negY[entry.x] != nil && negY[entry.x]! > minY
                {
                    minY = negY[entry.x]!
                }
            }
            
        }
        
        if !barPlotOptions.stackedPercentEnabled
        {
            positiveSum = posY
            negativeSum = negY
        }
        
        if !((barDataSets[0].plotType == .Bullet || barDataSets[0].plotType == .WaterFall))  && barPlotOptions.isStacked//&&  barPlotOptions.groupSpacePixel == 0  && barPlotOptions.groupSpace == 0  /// Not Multibar Check   // !((dataSetCount > 1) && isStacked)
        {
            // Need to revise first two lines
            /*data._yMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
            data._yMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
            
            data._yAxisMinArray[barDataSets[0].axisIndex] = data._yMin
            data._yAxisMaxArray[barDataSets[0].axisIndex] = data._yMax*/
            
             minY = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
             maxY = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
            
            guard let yMinForDataset = data._yAxisMinArray[barDataSets[0].axisIndex],
                  let yMaxForDataset = data._yAxisMaxArray[barDataSets[0].axisIndex]
            else { return }
                    
            
             if (minY < yMinForDataset){
                 data._yAxisMinArray[barDataSets[0].axisIndex] = minY
             }
            
             if (maxY > yMaxForDataset){
                 data._yAxisMaxArray[barDataSets[0].axisIndex] = maxY
             }
            
             if (minY < data._yMin) {
                 data._yMin = minY
             }
            
             if (maxY > data._yMax) {
                 data._yMax = maxY
             }

            /*for axisIndex in 0 ..< _yAxisMinArray.count {
                _yAxisMinArray[axisIndex] = self._yMin
            }
            
            for axisIndex in 0 ..< _yAxisMaxArray.count {
                _yAxisMaxArray[axisIndex] = self._yMax
            }*/
        }
    }
    
    internal func getstackedValueBefore(index: Int, stackGroup: [Int], stackedSumForX: [Int:Double]?, barDatasets: [IChartDataSet]) -> Double? {
        
        guard let stackedSumForX = stackedSumForX, let data = chart?.data else {
            return nil
        }
        
        for stackGroupIndex in (0...index).reversed() {
            if let darDatasetIndex = stackGroup[safe:stackGroupIndex],  let dataset = barDatasets[safe:darDatasetIndex] {
                
                let datasetIndex = data.indexOfDataSet(dataset)
                if let yValue = stackedSumForX[datasetIndex] {
                    return yValue
                }
            }
        }
        
        return 0.0
    }
    
    // MARK: -
    
    open func calculateOnDataSetChanged()
    {
        guard  let chart = chart,
        let _viewPortHandler = chart._viewPortHandler,
        let data = chart.data,
        let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
        else {
            return
        }
        
        let barDataSets:[IChartDataSet] = getVisibleBarDataSets(data: data)
        
        _viewPortHandler.resetMatrix()
        
        if  barDataSets.count == 0
        {
            return
        }
        
        currentDatasetCount = 0
        
        for i in (barDataSets)
        {
            if i.isVisible
            {
                currentDatasetCount += 1
            }
            
        }

        
        if barDataSets.count == 1
        {
            chart.xAxis.spaceMax = maxPadding
    
            chart.xAxis.spaceMin = minPadding
        }
        else if barPlotOptions.groupSpacePixel != 0 || barPlotOptions.groupSpace != 0 || barPlotOptions.isStacked
        {
            chart.xAxis.spaceMin = 0
            
            chart.xAxis.spaceMax = 0
        }
        
        calcMinMax()
        
        chart.prepareValuePxMatrix()
        
        calculateScaleLevel()
        
    }
    
    func calculateScaleLevel()
    {
        guard  let chart = chart,
            let viewPortHandler = chart._viewPortHandler,
            let data = chart.data else {
                return
        }
        
        let barDataSets:[IChartDataSet] = data.dataSets.filter({
            $0.plotType == .Bar || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot || $0.plotType == .HorizontalBarRange
               })
        
        guard let barPlotOptions = chart.getPlotOptions(type: barDataSets[0].plotType) as? BarPlotOptions
        else { return }
        
        let barDataSet = barDataSets[0]
        
        var scaleLevel:CGFloat = 0
        
        var vertical:Bool = false
        
        var barWidthPixel:CGFloat = 0
        
        guard let xStringArray = chart.data?.xString
            else { return }
        
#if os(iOS) || os(tvOS)
        //To check orientation
        if !UIDevice.current.orientation.isFlat
        {
            if !UIDevice.current.orientation.isLandscape
            {
                vertical = true
            }
        }
        else
        {
            if UIScreen.main.bounds.width < UIScreen.main.bounds.height
            {
                vertical = true
            }
        }
#endif
        // Current view width
        var viewSize:CGFloat
        
        if chart.isRotated
        {
            viewSize = viewPortHandler.contentRect.height
        }
        else{
            viewSize = viewPortHandler.contentRect.width
        }
        
        // If everything is in pixels,
        if barPlotOptions.barWidthPixel != 0 && barPlotOptions.barSpacePixel != 0
        {
            
            if barPlotOptions.groupSpacePixel != 0
            {
                
                let currentDatasetCount = currentGroupCount
                
                let onePointWidth = (((barPlotOptions.barWidthPixel + barPlotOptions.barSpacePixel)*Double(currentDatasetCount))+barPlotOptions.groupSpacePixel)
                
                let neededLabelCount = Double(viewSize)/onePointWidth
                
                scaleLevel = CGFloat(Double(xStringArray.count) / neededLabelCount)
                
                barWidthPixel = CGFloat(barPlotOptions.barWidthPixel)
                
                barPlotOptions.barCount =  ChartUtils.doubleToIntSafeCast(value:neededLabelCount)
                
                if xStringArray.count >=  ChartUtils.doubleToIntSafeCast(value:neededLabelCount)
                {
                    
                    barPlotOptions.barWidth = barPlotOptions.barWidthPixel/onePointWidth
                    
                    barPlotOptions.barSpace = barPlotOptions.barSpacePixel/onePointWidth
                    
                    barPlotOptions.groupSpace = barPlotOptions.groupSpacePixel/onePointWidth
                    
                    groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace,xInverted: chart.xAxis.isInverted)
                }
                
            }
            else{
                
                let neededLabelCount = viewSize/CGFloat(max(barPlotOptions.barWidthPixel,barPlotOptions.levelMarkerWidthPixel) + barPlotOptions.barSpacePixel)
                
                scaleLevel = CGFloat(xStringArray.count) / neededLabelCount
                
                barWidthPixel = CGFloat(barPlotOptions.barWidthPixel)
                
                barPlotOptions.barCount =  ChartUtils.doubleToIntSafeCast(value:ceil(neededLabelCount))
                
                if xStringArray.count >= barPlotOptions.barCount
                {
                    barPlotOptions.barWidth = barPlotOptions.barWidthPixel/(max(barPlotOptions.barWidthPixel,barPlotOptions.levelMarkerWidthPixel) + barPlotOptions.barSpacePixel)
                }
                
            }
            
            if !(maxWidthRestriction(viewSize:viewSize,entryCount:xStringArray.count, barWidthPixel: &barWidthPixel, scaleLevel: &scaleLevel))
            {
                // MinimunScale to maintain minimum bar width
                let minimumScaleValue = (scaleLevel/barWidthPixel)*CGFloat(barPlotOptions.minimumBarPixel)
                
                // if calculated scale goes less than minimum value, set it to minimum scale value
                if scaleLevel <= minimumScaleValue
                {
                    scaleLevel = minimumScaleValue
                    oldScale = scaleLevel
                    barPlotOptions.barCount =  ChartUtils.doubleToIntSafeCast(value:CGFloat(xStringArray.count)/scaleLevel)
                }
                else
                {
                    oldScale = 0
                }
            }
        }
        else{
            
            if vertical
            {
                if toggle{
                    tempBarCount = barPlotOptions.barCount
                }
                oldWidth = viewSize
                barPlotOptions.barCount = tempBarCount
                // To calculate scale level based on labelcount
                scaleLevel = CGFloat(xStringArray.count) / CGFloat(barPlotOptions.barCount)
            }
            else{
                
                // Initially view is in landscape mode
                if oldWidth == 0
                {
                    tempBarCount = barPlotOptions.barCount
                    if chart.isRotated
                    {
                        barPlotOptions.barCount = barPlotOptions.barCount/2
                    }
                    else{
                        barPlotOptions.barCount = barPlotOptions.barCount &* 2
                    }
                    scaleLevel = CGFloat(xStringArray.count) / CGFloat(barPlotOptions.barCount)
                    toggle = false
                }
                else{
                    if chart.isRotated
                    {
                        barPlotOptions.barCount = tempBarCount/2
                    }
                    else{
                        barPlotOptions.barCount = tempBarCount*2
                    }
                    scaleLevel = CGFloat(xStringArray.count) / CGFloat(barPlotOptions.barCount)
                    toggle = false
                    
                }
                
            }
            
            let labelCountFloatValue = CGFloat(xStringArray.count)/scaleLevel
            
            // To calculate single bar width in current viewport width
            barWidthPixel = ((viewSize / labelCountFloatValue)/10)*CGFloat(barPlotOptions.barWidth*10)
            
            // if any restriction provided (Need to revise barwidth pixel)
            if barPlotOptions.barWidthPixel != 0
            {
                // Scale level to maintain given bar Width
                scaleLevel = (scaleLevel/barWidthPixel)*CGFloat(barPlotOptions.barWidthPixel)
                
                barWidthPixel = CGFloat(barPlotOptions.barWidthPixel)
                
                oldScale = scaleLevel
                
                barPlotOptions.barCount =  ChartUtils.doubleToIntSafeCast(value:CGFloat(xStringArray.count)/scaleLevel)
            }
            else if barPlotOptions.barSpacePixel != 0
            {
                let newRatio = CGFloat(barPlotOptions.barSpacePixel)/((viewSize / CGFloat(labelCountFloatValue)))
                
                barPlotOptions.barWidth = Double(1-newRatio)
                
                barWidthPixel = ((viewSize / CGFloat(labelCountFloatValue))/10)*CGFloat(barPlotOptions.barWidth*10)
                
            }
            
            // To restrict maximimum width
            if !(maxWidthRestriction(viewSize:viewSize,entryCount:xStringArray.count,barWidthPixel:&barWidthPixel,scaleLevel:&scaleLevel))
            {
                // MinimunScale to maintain minimum bar width
                let minimumScaleValue = (scaleLevel/barWidthPixel)*CGFloat(barPlotOptions.minimumBarPixel)
                
                // if calculated scale goes less than minimum value, set it to minimum scale value
                if scaleLevel < minimumScaleValue
                {
                    scaleLevel = minimumScaleValue
                    
                    barWidthPixel = ((viewSize / (CGFloat(xStringArray.count)/scaleLevel))/10)*CGFloat(barPlotOptions.barWidth*10)
                    
                    oldScale = scaleLevel
                    
                    barPlotOptions.barCount =  ChartUtils.doubleToIntSafeCast(value:CGFloat(xStringArray.count)/scaleLevel)
                }
                else
                {
                    oldScale = 0
                }
            }
            else{
                oldScale = 0
            }
            
        }
        
        
        /// To Calculate width ratio for levelMarker
        if barDataSet.plotType == .Bullet
        {
            barPlotOptions.levelMarkerWidth = (barPlotOptions.barWidth/Double(barWidthPixel))*barPlotOptions.levelMarkerWidthPixel
        }
        
        setScale(scaleLevel: scaleLevel)
        
        
    }
    /*
    func getCurrentDatasetCount() -> Int{
        
        guard let chart = chart,
              let data = chart.data
        else {
            return 0
        }
        
        var currentBarCount = 0
        
        data._datasetsGroupArray.forEach{ (sets) in
        
            for dataset in sets{
                if dataset.isVisible{
                    currentBarCount += 1
                    break
                }
            }
            
        }
        
        return currentBarCount
    }
    */
    func maxWidthRestriction(viewSize:CGFloat,entryCount:Int,barWidthPixel:inout CGFloat, scaleLevel: inout CGFloat) -> Bool
    {
        guard  let chart = chart,
            let barData = chart.data,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
            else  {
                return false
            }
        
        let barDataSets:[IChartDataSet] = barData.dataSets.filter({
            $0.plotType == .Bar || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot
        })
        
        let maxWidthPixel = CGFloat(barPlotOptions.maximumBarPixel)
        
        if entryCount < barPlotOptions.barCount
        {
            scaleLevel = 1
            barWidthPixel = ((viewSize / CGFloat(entryCount))/10)*CGFloat(barPlotOptions.barWidth*10)
            
            
            
            // if maxwidth, barSpacePixel and barWidthPixel are not set, return
            if maxWidthPixel == 0 && barPlotOptions.barWidthPixel == 0 && barPlotOptions.barSpacePixel == 0
            {
                return false
            }
            
            // if not exceeded maxbarwidth,
            if barWidthPixel < maxWidthPixel || maxWidthPixel == 0
            {
                
                if (barDataSets.count) > 1
                {
                    if barPlotOptions.barSpacePixel != 0 && barPlotOptions.groupSpacePixel != 0
                    {
                        
                        let currentDatasetCount = currentGroupCount
                        
                        barPlotOptions.barSpace  = Double(CGFloat(barPlotOptions.barSpacePixel)/((viewSize / CGFloat(entryCount))))
                        
                        barPlotOptions.groupSpace = Double(CGFloat(barPlotOptions.groupSpacePixel)/((viewSize / CGFloat(entryCount))))
                        
                        barPlotOptions.barWidth = ((1-barPlotOptions.groupSpace-(barPlotOptions.barSpace*Double(currentDatasetCount))))/Double(currentDatasetCount)
                        
                        groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace,xInverted: chart.xAxis.isInverted)
                        
                        barWidthPixel = ((viewSize / CGFloat(entryCount))/10)*CGFloat(barPlotOptions.barWidth*10)
                        
                    }
                    
                }
                else if barPlotOptions.barSpacePixel != 0
                {
                    let newRatio = CGFloat(barPlotOptions.barSpacePixel)/((viewSize / CGFloat(entryCount)))
                    
                    barPlotOptions.barWidth = Double(1-newRatio)
                    
                    barWidthPixel = ((viewSize / CGFloat(entryCount))/10)*CGFloat(barPlotOptions.barWidth*10)
                    
                }
                
                // reCheck for maxWidth, since ratio is changed
                if barWidthPixel < maxWidthPixel || maxWidthPixel == 0 {
                    return true
                }
            }
            
            // Multi bar case Since padding is not working
            if (barDataSets.count) > 1 && barPlotOptions.groupSpacePixel != 0
            {
                if barPlotOptions.barSpacePixel != 0
                {
                    
                    let currentDatasetCount = currentGroupCount
                    
                    let onePoint = Double(viewSize / CGFloat(entryCount))
                    
                    let requiredOnePoint = ((Double(maxWidthPixel)+barPlotOptions.barSpacePixel) * Double(currentDatasetCount)) + barPlotOptions.groupSpacePixel
                    
                    if onePoint >= requiredOnePoint
                    {
                        barPlotOptions.barSpace = barPlotOptions.barSpacePixel/requiredOnePoint
                        
                        barPlotOptions.groupSpace = barPlotOptions.groupSpacePixel/requiredOnePoint
                        
                        barPlotOptions.barWidth = Double(maxWidthPixel)/requiredOnePoint
                        
                        groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace,xInverted: chart.xAxis.isInverted)
                    }
                    else{
                        barPlotOptions.barSpace  = Double(CGFloat(barPlotOptions.barSpacePixel)/((viewSize / CGFloat(entryCount))))
                        
                        barPlotOptions.groupSpace = Double(CGFloat(barPlotOptions.groupSpacePixel)/((viewSize / CGFloat(entryCount))))
                        
                        barPlotOptions.barWidth = ((1-barPlotOptions.groupSpace-(barPlotOptions.barSpace*Double(currentDatasetCount))))/Double(currentDatasetCount)
                        
                        groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace,xInverted: chart.xAxis.isInverted)
                        
                        barWidthPixel = ((viewSize / CGFloat(entryCount))/10)*CGFloat(barPlotOptions.barWidth*10)
                        
                        return true
                        
                    }
                }
                
            }
            else if barPlotOptions.barSpacePixel != 0 // set MaxWidthPixel to barwidthpiexl
            {
                let onePoint = (viewSize / CGFloat(entryCount))
                
                let requiredOnePoint = max(maxWidthPixel,CGFloat(barPlotOptions.levelMarkerWidthPixel)) + CGFloat(barPlotOptions.barSpacePixel)
                
                // No need to update barwidthpixel,Since ratio is set to achieve bar width on padding
                if onePoint >= requiredOnePoint
                {
                    barPlotOptions.barWidth = Double(maxWidthPixel/requiredOnePoint)
                    
                }
                else{
                    let newRatio = CGFloat(barPlotOptions.barSpacePixel)/((viewSize / CGFloat(entryCount)))
                    
                    barPlotOptions.barWidth = Double(1-newRatio)
                    
                    barWidthPixel = ((viewSize / CGFloat(entryCount))/10)*CGFloat(barPlotOptions.barWidth*10)
                    
                    return true
                }
                
                
            }
            
            
            if (barWidthPixel > maxWidthPixel && barPlotOptions.barWidthPixel == 0) || (barPlotOptions.barWidthPixel != 0 && barWidthPixel != maxWidthPixel)
            {
                var padding:Double = 0
                
                var currentWidth:CGFloat = barWidthPixel
                
                // trail and error checking for padding value to get bar width close to maxwidth
                repeat
                {
                    padding += 1
                    
                    currentWidth = getCurrentWidthAfterPadding(padding: padding)
                }
                    while(currentWidth > maxWidthPixel)
                
                
                padding = getPaddingValueBinarySearch(padding: padding-1,expectedWidth:maxWidthPixel)
                
                currentWidth = getCurrentWidthAfterPadding(padding: padding)
                
                barWidthPixel = maxWidthPixel
                
                return true
                
            }
        }
        else if barWidthPixel > maxWidthPixel && maxWidthPixel != 0
        {
            // Scale level to maintain given bar Width
            scaleLevel = (scaleLevel/barWidthPixel)*CGFloat(maxWidthPixel)
            
            barWidthPixel = maxWidthPixel
            
            oldScale = scaleLevel
            
            barPlotOptions.barCount =  ChartUtils.doubleToIntSafeCast(value:CGFloat(entryCount)/scaleLevel)
            
            return true
        }
        
        return false
    }
    
    func setScale(scaleLevel:CGFloat)
    {
        guard  let chart = chart,
            let viewPortHandler = chart._viewPortHandler,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
            let barData = chart.data else {
                return
        }
        
        if viewPortHandler.chartWidth == 0 ||  viewPortHandler.chartHeight == 0 || scaleLevel == CGFloat.infinity || scaleLevel.isNaN
        {
            chart.setScaleMinima(1, scaleY: 1)
            if !chart.scaleXEnabled
            {
                viewPortHandler.setMaximumScaleX(CGFloat(1))
            }
            if !chart.scaleYEnabled
            {
                viewPortHandler.setMaximumScaleY(CGFloat(1))
            }
            return
        }
        
        guard let entryCount = barData.xString?.count
        else { return }
        
        if (entryCount > barPlotOptions.barCount)
        {
            if chart.isRotated
            {
                chart.setScaleMinima(0.0, scaleY: CGFloat(scaleLevel)) //TOUNCOMMENT
                
                //            After filter out, viewport matrix scale property didn't get updated with latest scale value. To maintain the same scale (with zoom disabled option), max scale property assigned with min scale value
                if !chart.scaleYEnabled
                {
                    viewPortHandler.setMaximumScaleY(CGFloat(scaleLevel))
                }
            }
            else{
                chart.setScaleMinima(CGFloat(scaleLevel), scaleY: 0.0) //TOUNCOMMENT
                
                //            After filter out, viewport matrix scale property didn't get updated with latest scale value. To maintain the same scale (with zoom disabled option), max scale property assigned with min scale value
                if !chart.scaleXEnabled
                {
                    viewPortHandler.setMaximumScaleX(CGFloat(scaleLevel))
                }
            }
        }
        else
        {
            chart.setScaleMinima(1.0, scaleY: 1.0)
            
            if chart.isRotated
            {
                if !chart.scaleYEnabled
                {
                    viewPortHandler.setMaximumScaleY(CGFloat(1))
                }
            }
            else
            {
                if !chart.scaleXEnabled
                {
                    viewPortHandler.setMaximumScaleX(CGFloat(1))
                }
            }
        }
    }
    
    // MARK: - supporting Methods
    open func groupBars(fromX: Double, groupSpace: Double, barSpace: Double, xInverted:Bool)
    {
        guard  let chart = chart,
            let barData = chart.data,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
            else  {
                return
        }
        
        let barDataSets:[IChartDataSet] = barData.dataSets.filter({
            $0.plotType == .Bar || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot
               })
        
        let setCount = barDataSets.count
        
        if setCount <= 1
        {
            print("BarData needs to hold at least 2 BarDataSets to allow grouping.", terminator: "\n")
            return
        }
        
        let groupSpaceWidthHalf = groupSpace / 2.0
        let barSpaceHalf = barSpace / 2.0
        let barWidthHalf = barPlotOptions.barWidth / 2.0
        
        var removedCount = 0
        
        for i in barDataSets
        {
            if i.isVisible
            {
                continue
            }
            removedCount += 1
        }
        
        var fromX = fromX - 0.5
        
        let interval = self.groupWidth(groupSpace: groupSpace, barSpace: barSpace)
        
        var dataSetLastIndexMapping:[Int:Int] = [:]
        
        guard let xString = chart.data?.xString
        else { return }
        
        for i in stride(from: 0, to: xString.count, by: 1)
        {
            let currentX = xString[i]
            let start = fromX
            fromX += groupSpaceWidthHalf
            
            var startIndex = 0
            var endIndex = barData._datasetsGroupArray.count - 1//barDataSets.count - 1
            var increment = 1
            
            if (xInverted) {
                startIndex = barData._datasetsGroupArray.count - 1
                endIndex = 0
                increment = -1
            }
            
            var setIndex = 0
            
            for groupIndex in stride(from: startIndex, through: endIndex, by: increment)
            {
                let groupSetIndexArray = barData._datasetsGroupArray[groupIndex]//barDataSets[setIndex]
                
                /*
                if dataSetLastIndexMapping[setIndex] == nil
                {
                    dataSetLastIndexMapping[setIndex] = 0
                }
                
                if !(set.isVisible) || !(set.plotType == .Bar || set.plotType == .HorizontalBar) {
                    continue
                }
                
                if !checkVisibilityOfGroupset(groupSet: groupSet){
                    continue
                }*/
                
                fromX += barSpaceHalf
                fromX += barWidthHalf
                
                for dataSetIndex in groupSetIndexArray {
                    
                    let dataSet = barDataSets[dataSetIndex]
                    
                    if dataSetLastIndexMapping[setIndex] == nil
                    {
                        dataSetLastIndexMapping[setIndex] = 0
                    }
                    
                    let lastIndex = dataSetLastIndexMapping[setIndex]!
                
                    for entryIndex in lastIndex..<dataSet.entryCount
                    {
                        guard let entry = dataSet.entryForIndex(entryIndex)
                        else { break }
                    
                        if !(entry.x.isNaN)
                        {
                            if entry.xString == currentX
                            {
                                entry.x = fromX
                                dataSetLastIndexMapping[setIndex] = entryIndex + 1
                            }
                            break
                        }
                    }
                    
                    setIndex += 1
                    
                }
                
                fromX += barWidthHalf
                fromX += barSpaceHalf
            }
            
            fromX += groupSpaceWidthHalf
            let end = fromX
            let innerInterval = end - start
            let diff = interval - innerInterval
            
            // correct rounding errors
            if diff > 0 || diff < 0
            {
                fromX += diff
            }
            
        }
        
        chart.data?.notifyDataChanged()
        
        calcPosNegSum()
    }
    
    open func groupWidth(groupSpace: Double, barSpace: Double) -> Double
    {
         guard  let chart = chart,
                let data = chart.data,
                let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
                else  {
                    return 1
                }
        
        let currentDatasetCount = currentGroupCount
        
        return Double(currentDatasetCount) * (barPlotOptions.barWidth + barSpace) + groupSpace
    }
    
    open  override func getCurrentWidthAfterPadding(padding:Double) -> CGFloat
    {
        guard  let chart = chart,
        let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
               let transformer = chart.yAxisRenderer(atIndex: 0).transformer
        else {
                return 0
        }
        
    
        chart.xAxis.spaceMax = Double(padding)
        chart.xAxis.spaceMin = Double(padding)
        
        calcMinMax()
        
        chart.prepareValuePxMatrix()
        
        var rect = CGRect(x: 0, y: 0, width: barPlotOptions.barWidth, height: barPlotOptions.barWidth)
        
        transformer.rectValueToPixel(&rect)// rect = rect.applying(transformer.valueToPixelMatrix)
        
        if chart.isRotated
        {
            return rect.height
        }
        else
        {
            return rect.width
        }
    }
    
    fileprivate func getVisibleBarDataSets(data:ChartData) -> [IChartDataSet]
    {
          let barDataSets:[IChartDataSet] = data.dataSets.filter({
              ($0.plotType == .Bar || $0.plotType == .Mekko || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot || $0.plotType == .HorizontalBarRange) && ($0.isVisible)
                        })
          return barDataSets
   }
    
    func groupingFor(barDataSets: [IChartDataSet], data: ChartData, isStacked: Bool) {
        
        data._datasetsGroupArray.removeAll()
        data._stackGroupArray.removeAll()
        currentGroupCount = 0
        
        var visibleDatasetCount = 0
        
        defer {
            stackGroupingFor(barDataSets: barDataSets, data: data,isStacked: isStacked)
            currentGroupCount = data._datasetsGroupArray.count // consider Group count to find groupWidth
        }
        
        var remainingDatasetIndexArray = Array(repeating: 0, count: barDataSets.count)
        
        guard let datasetsGroupArray = data.datasetsGroupArray else {
            groupRemaining(barDataSets: barDataSets, data: data, isStacked: isStacked, isGrouped: true, remainingDatasetIndexArray: &remainingDatasetIndexArray, groupArray: &data._datasetsGroupArray, visibleDatasetCount: &visibleDatasetCount)
            return
        }
        
        var setGroupArray:[[Int]] = []
        
        for intArray in datasetsGroupArray
        {
            var setArray:[Int] = []
            
            for setIndex in intArray
            {
                if data.isVaild(dataset: barDataSets, datasetIndex: setIndex) {
                    setArray.append(setIndex)
                    remainingDatasetIndexArray[setIndex] = 1
                    visibleDatasetCount += 1
                }
            }
            
            if !setArray.isEmpty {
                setArray.sort(by: { $0 < $1 })
                setGroupArray.append(setArray)
//                currentGroupCount += 1 // consider Group count to find groupWidth
            }
        }
        
        data._datasetsGroupArray = setGroupArray
        
        if visibleDatasetCount == barDataSets.count {
            return
        }
        
        groupRemaining(barDataSets: barDataSets, data: data, isStacked: isStacked, isGrouped: true,remainingDatasetIndexArray: &remainingDatasetIndexArray, groupArray: &data._datasetsGroupArray, visibleDatasetCount: &visibleDatasetCount)
    }
    
    func stackGroupingFor(barDataSets: [IChartDataSet], data: ChartData, isStacked: Bool) {
        var remainingDatasetIndexArray = Array(repeating: 0, count: barDataSets.count)
        var visibleDatasetCount = 0
        
        guard let stackGroupArray = data.stackGroupArray, isStacked else {
            groupRemaining(barDataSets: barDataSets, data: data, isStacked: isStacked, remainingDatasetIndexArray: &remainingDatasetIndexArray, groupArray: &data._stackGroupArray, visibleDatasetCount: &visibleDatasetCount)
            return
        }
        
        var setGroupArray:[[Int]] = []
        
        for intArray in stackGroupArray
        {
            var setArray:[Int] = []
            
            for setIndex in intArray
            {
                if data.isVaild(dataset: barDataSets, datasetIndex: setIndex) {
                    setArray.append(setIndex)
                    remainingDatasetIndexArray[setIndex] = 1
                    visibleDatasetCount += 1
                }
            }
            
            if !setArray.isEmpty {
                setArray.sort(by: { $0 < $1 })
                setGroupArray.append(setArray)
            }
        }
        
        data._stackGroupArray = setGroupArray
        
        if visibleDatasetCount == barDataSets.count {
            return
        }
        
        groupRemaining(barDataSets: barDataSets, data: data, isStacked: isStacked, remainingDatasetIndexArray: &remainingDatasetIndexArray, groupArray: &data._stackGroupArray, visibleDatasetCount: &visibleDatasetCount)
    }
    
    internal func groupRemaining(barDataSets: [IChartDataSet], data: ChartData, isStacked: Bool, isGrouped: Bool = false, remainingDatasetIndexArray: inout[Int], groupArray: inout [[Int]], visibleDatasetCount: inout Int) {
            
        if isStacked {
            
            if !isGrouped {
                for groupSet in data.getdatasetsGroupArray {
                    
                    var groupedDataset = [Int]()
                    
                    for index in groupSet where data.isVaild(dataset: barDataSets, datasetIndex: index) {
                        
                        if remainingDatasetIndexArray[index] == 0 {
                            groupedDataset.append(index)
                            remainingDatasetIndexArray[index] = 1
                            visibleDatasetCount += 1
                        }
                    }
                    if !groupedDataset.isEmpty {
                        groupedDataset.sort(by: { $0 < $1 })
                        groupArray.append(groupedDataset)
                    }
                }
            }
            
            if visibleDatasetCount == barDataSets.count {
                return
            }
            
            var remainingDataset = [Int]()
                
            for index in 0..<remainingDatasetIndexArray.count where data.isVaild(dataset: barDataSets, datasetIndex: index) {
                    
                if remainingDatasetIndexArray[index] == 0 {
                    remainingDataset.append(index)
                }
            }
            if !remainingDataset.isEmpty {
                groupArray.append(remainingDataset)
            }
        }
        else {
                
            var remainingDatasetArray = [[Int]]()
                
            for index in 0..<remainingDatasetIndexArray.count where data.isVaild(dataset: barDataSets, datasetIndex: index) {
                    
                if remainingDatasetIndexArray[index] == 0 {
                    remainingDatasetArray.append([index])
//                    if isGrouped {
//                        currentGroupCount += 1 // consider Group count to find groupWidth
//                    }
                }
            }
              
            if !remainingDatasetArray.isEmpty {
                groupArray.append(contentsOf: remainingDatasetArray)
            }
        }
    }
    
    // MARK: - Gesture Handled
       
   override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint) -> (entry: ChartDataEntry?, layer: ChartEntryLayer?) {
       
       guard let chart = chart,
        let recognizer = recognizer
           else { return (nil,nil) }
       
       if recognizer.isKind(of: TapEventListener.self)
       {
        return BarHelperFunctions.tapHighlight(location: location, recognizer as? TapEventListener, chart: chart)
       }
       else if recognizer.isKind(of: PanEventListener.self)
       {
        return BarHelperFunctions.panPerformed(recognizer as! PanEventListener, chart: chart)
       }
//       else if recognizer.isKind(of: LongPressEventListener.self)
//       {
//        return BarHelperFunctions.longPressPerformed(recognizer as! LongPressEventListener, chart: chart)
//       }
       else if recognizer.isKind(of: PinchEventListener.self)
       {
        return BarHelperFunctions.pinchPerformed(recognizer as! PinchEventListener, chart: chart)
       }
       #if os(iOS)
        if recognizer.isKind(of: LongPressEventListener.self)
        {
         return BarHelperFunctions.longPressPerformed(recognizer as! LongPressEventListener, chart: chart)
        }
       
       if #available(iOS 13.0, *) {
           if recognizer.isKind(of: HoverEventListener.self) {
               return BarHelperFunctions.tapHighlight(location: location, nil, chart: chart)
           }
       }
       #endif
    return (nil,nil)
   }
    
    // MARK: - AnimatorDelegate
    
    open override func animatorUpdated(_ chartAnimator: Animator)
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
           else { return }
        
        super.animatorUpdated(chartAnimator)
        if plotOption.stackedSumEnabled {
            plotOption.isStackedSumEnabled = false
        }
        
//        chart.interactionAnimationInProgress = true
        
    }
    
    open override func animatorStopped(_ chartAnimator: Animator)
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
        else { return }
        
        super.animatorStopped(chartAnimator)
        
        if chart.data == nil{
            return
        }
        if plotOption.stackedSumEnabled {
            plotOption.isStackedSumEnabled = true
        }
        
//        chart.interactionAnimationInProgress = false
    }
    
    // MARK: - Protocol Implementation

   // Drill/Filter View tapped
   public override func filterEntrySelected(entry: [ChartDataEntry]?) {
       
        guard let chart = chart,
            (entry != nil)
            else { return }
    
       chart.interactionAnimationInProgress = true
       ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry!, duration: 1)
       
   }
    
   /// Tooltip tapped
   public override func tooltipSelected(entry: ChartDataEntry?) {
       
        guard let chart = chart,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
              let data = chart.data,
              let delegate = chart.delegateToContainer
        else { return }
    
       var oldEntry = chart.data?.dataSets[0].entryForIndex((data.dataSets[0].entryCount)-1)
       
       if entry != nil
       {
           oldEntry = entry!
       }
       
        if (data.dataSetCount) > 1 || barPlotOptions.isStacked
       {
            if chart.xGroupSelected //|| barPlotOptions.barGroupSelectionEnabled
           {
            BarHelperFunctions.singleBarActionOnTooltipSelectNewLogic(entry: entry, chart: chart)
           }
           else{
               if let set = chart.data?.getDataSetForEntry(oldEntry){
                let nextIndex = ((data.indexOfDataSet(set))+1)%(data.dataSetCount)
                let nextDataSet = chart.data?._dataSets[nextIndex]
                if nextDataSet != nil && !(nextDataSet?.isVisible)! && nextDataSet!.entryCount > 0
                {
                    tooltipSelected(entry: (nextDataSet?.entryForIndex(0))!)
                    return
                }
                guard let curEntry = nextDataSet?.entryForIndex((set.entryIndex(entry: oldEntry!)))
                   else { return }
                chart.updateLastSelectedEntry(entry: curEntry)
                chart.setNeedsDisplay()
                delegate.chartValueSelected?(chart, entry: curEntry)
               }
           }
           
       }
       else
       {
        BarHelperFunctions.singleBarActionOnTooltipSelectNewLogic(entry: entry, chart: chart)
       }
       
   }
       
   /// Includes Dataset in multi bar and stack index in stacked bar.
   public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
       
       Log.info("BarChart LegendEnabled ")
       
       guard let chart = chart,
            let data = chart.data
           else { return }
       
       if data.dataSets[indexPath.item].entryCount == 0
       {
           data.dataSets[indexPath.item].visible = true
           
           data.notifyDataChanged()
           
            chart.notifyDataSetChanged(redrawRequired: true)
           
           chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: nil , dataSets: [data.dataSets[indexPath.item]] as? [ChartDataSet], dataSetAdded: true)
           
           return
       }
       
       /*
        if BarHelperFunctions.isStacked(chart: chart)
       {
           chart.interactionAnimationInProgress = true
           
           BarHelperFunctions.includeStackEntry(barChartView: chart, indexToInclude: indexPath.item)
       }
       else
       {
           chart.interactionAnimationInProgress = true
           
            chart.removedCount -= 1
           
           let chartEntry = chart.data?.dataSets[indexPath.item].entryForIndex(0)
           
           BarHelperFunctions.enableMultiBar(chartEntry: chartEntry!, chart: chart,duration: 0.3,animation: .linear)
       }
       */
       
       ChartInteractionHelperFunction.legendEnabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
   }
   
   /// Excludes Dataset in multi bar, stack index in stacked bar and entry in single bar.
   public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
       
       Log.info("BarChart LegendDisabled ")
       
       guard let chart = chart,
            let data = chart.data,
            let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
           else { return }
    
        chart.xAxis.longestLabel = ""
       
       if indexPath.item < data.dataSets.count &&  data.dataSets[indexPath.item].entryCount == 0
       {
           data.dataSets[indexPath.item].visible = false
           
           data.notifyDataChanged()
           
            chart.notifyDataSetChanged(redrawRequired: true)
           
            chart.delegateToContainer?.chartValueRemoved?(chart, entries: nil, dataSets: data.dataSets[indexPath.item] as? [ChartDataSet], dataSetRemoved: true,showTrackerView: false )
           
           return
       }
       
    if plotOption.isStacked
       {
            /*
           chart.interactionAnimationInProgress = true
           
           let indexToRemove = indexPath.item
           
           BarHelperFunctions.excludeStackEntry(barChartView: chart, indexToRemove: indexToRemove)
             */
        
            ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
       }
       else if (data.dataSetCount) > 1
       {
            if ((data.dataSetCount) - chart.removedCount) > 1
           {
               /*
               chart.interactionAnimationInProgress = true
               
                chart.removedCount += 1
               
               BarHelperFunctions.disableMultiBar(set: (chart.data?.dataSets[indexPath.item])!, chart: chart,duration: 0.3,animation: .linear)
               */
                
                ChartInteractionHelperFunction.legendDisabled(axisChartBase: chart, indexPath: indexPath, entry: entry)
           }
       }
       else{
           
           if data.dataSets[0].entryCount == 0
           {
               chart.delegateToContainer?.chartValueRemoved?(chart, entries: nil, dataSets: [data.dataSets[indexPath.item]] as? [ChartDataSet], dataSetRemoved: true,showTrackerView: false )
               
               return
           }
           
           guard let chartEntry = chart.data?.dataSets[0].entryForIndex(indexPath.item)
           else { return }
           
           let deleteIndex = indexPath.item
           
           let allBarLayer = BarLayer.getAllBarLayer(chart: chart)
           
           if allBarLayer.count == 0
           {
               return
           }
           
           let barLayerStartIndex = (data.dataSets[0].entryIndex(entry: allBarLayer[0].chartEntry!))
           
           let barLayerEndIndex = (data.dataSets[0].entryIndex(entry:(allBarLayer[allBarLayer.count-1].chartEntry)!))
           
           var moved = false
           
           let translateDuration = 0.5
           let filterDuration = 0.5
           
           chart.interactionAnimationInProgress = true
           
           if deleteIndex < barLayerStartIndex || deleteIndex > barLayerEndIndex
           {
               
               let count = barLayerStartIndex - deleteIndex + (allBarLayer.count/2)
               
               let transformer:Transformer
               
               if chart.getYAxis(atIndex: 0)!.isEnabled
               {
                    transformer = chart.getTransformer(axisIndex: 0)
               }
               else{
                    transformer = chart.getTransformer(axisIndex: 1)
               }
               
               let distToMove:CGFloat
               
               if chart.isRotated
               {
                   distToMove = CGFloat(count) * transformer.valueToPixelMatrix.d * CGFloat(chart.xAxis.granularity)
               }
               else{
                   distToMove = CGFloat(count) * transformer.valueToPixelMatrix.a * CGFloat(chart.xAxis.granularity)
               }
               
               if chart.isRotated
               {
                   if chart.xAxis.isInverted //x-axis inverted
                   {
                       CommonHelperFunctions.translateView(distance: distToMove, duration: translateDuration, chart: chart)
                   }
                   else
                   {
                       CommonHelperFunctions.translateView(distance: -distToMove, duration: translateDuration, chart: chart)
                   }
               }
               else{
                   if chart.xAxis.isInverted //x-axis inverted
                   {
                       CommonHelperFunctions.translateView(distance: -distToMove, duration: translateDuration, chart: chart)
                   }
                   else
                   {
                       CommonHelperFunctions.translateView(distance: distToMove, duration: translateDuration, chart: chart)
                   }
               }
               moved = true
           }
           
           
           if moved{
               DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(translateDuration*1000)), execute: {
                    BarHelperFunctions.performFilterAnimation(chartEntry: chartEntry, filterDuration: filterDuration, chart: chart)
               })
           }
           else{
                    BarHelperFunctions.performFilterAnimation(chartEntry: chartEntry, filterDuration: filterDuration, chart: chart)
           }
           
       }
       
   }
}

extension BarPreprocessor {
    
    
    internal func updateArrayOfDataSets() {
        
        guard let chart = chart,
              let data = chart.data,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? AxisChartPlotOptions
        else {
            return
        }
        
        let barDataSets:[IChartDataSet] = data.dataSets.filter({
            $0.plotType == .Bar || $0.plotType == .Bullet || $0.plotType == .WaterFall || $0.plotType == .BoxPlot || $0.plotType == .HorizontalBarRange || $0.plotType == .Mekko
               })
        
        if barDataSets.count <= 0{
            return
        }
        
        groupingFor(barDataSets: barDataSets, data: data, isStacked: plotOption.isStacked)
            
    }
    
    func updateMinMaxBasedOnWhiskers() {
        
        guard let chart = chart,
              let data = chart.data,
              let BoxPlotPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.BoxPlot]) as? BoxPlotPlotOptions
            else {
                return
            }
        
        for dataSet in data.dataSets {
            
            if !dataSet.isVisible || !(dataSet.plotType == .BoxPlot){
                continue
            }

            var maxY = -(Double.greatestFiniteMagnitude)
            var minY = Double.greatestFiniteMagnitude
            
            for entryIndex in 0..<dataSet.entryCount {
                
                guard let entry = dataSet.entryForIndex(entryIndex) else {
                    continue
                }
                
                if entry.x.isNaN {
                    continue
                }
                
                if let valArr = entry.plotData as? [Double] {
                
                    let minVal = valArr[safe: BoxPlotPlotOptions.minWhiskersIndex]
                    
                    let maxVal = valArr[safe: BoxPlotPlotOptions.maxWhiskersIndex]
                    
                    if minVal != nil {
                        
                        if minVal! < minY {
                            minY = minVal!
                        }
                        
                        if minVal! > maxY {
                            maxY = minVal!
                        }
                    }
                    
                    if maxVal != nil {
                        
                        if maxVal! > maxY {
                            maxY = maxVal!
                        }
                        
                        if maxVal! < minY {
                            minY = maxVal!
                        }
                    }
                
                }
            }
            
            minY = (minY == Double.greatestFiniteMagnitude) ?  0 : minY
            maxY = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
            
            guard let yMinForDataset = data._yAxisMinArray[dataSet.axisIndex],
                  let yMaxForDataset = data._yAxisMaxArray[dataSet.axisIndex]
            else { return }
            
            if (minY < yMinForDataset){
                data._yAxisMinArray[dataSet.axisIndex] = minY
            }
           
            if (maxY > yMaxForDataset){
                data._yAxisMaxArray[dataSet.axisIndex] = maxY
            }
           
            if (minY < data._yMin) {
                data._yMin = minY
            }
           
            if (maxY > data._yMax) {
                data._yMax = maxY
            }
        }
    }
}
