//
//  AxisChartPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 13/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class AxisChartPreprocessor:ChartPreprocessor
{
    
    open override var chartYMax: Double
    {
        let maxAxis = chart?.yAxisArray.max { a, b in a._axisMaximum < b._axisMaximum }
        return maxAxis?._axisMaximum ?? 0
    }
    
    open override var chartYMin: Double
    {
        let minAxis = chart?.yAxisArray.min { a, b in a._axisMinimum < b._axisMinimum }
        return minAxis?._axisMinimum ?? 0
    }
    
    // MARK: - Data Updation Calculation
    
    /// Performs auto scaling of the axis by recalculating the minimum and maximum y-values based on the entries currently in view.
    internal func autoScale()
    {
        guard let chart = chart,
            let data = chart._data
            else { return }
        
        data.calcMinMaxY(fromX: chart.lowestVisibleX, toX: chart.highestVisibleX)
        
        chart._xAxis.calculate(min: data.xMin, max: data.xMax)
        
        // calculate axis range (min / max) according to provided data
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            guard let axisIndex = chart.getAxisIndex(axis: yAxis)
            else { continue }
            yAxis.calculate(min: data.getYMin(axisIndex:axisIndex), max: data.getYMax(axisIndex:axisIndex))
        }
        
        calculateOffsets()
    }
    
    open override func notifyDataSetChanged(redrawRequired: Bool)
    {
        guard let chart = chart ,
        let viewPortHandler = chart.viewPortHandler
            else { return }
        
        var isPadding = false
        
        if chart.xAxis.spaceMinPixel != 0 && chart.xAxis.spaceMaxPixel != 0 {
            isPadding = true
        }
        
        var valueForTouch = chart.valueForTouchPoint(point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop), axisIndex: 0)
        
        var oldContentLeftX = chart.isRotated ?  valueForTouch.y : valueForTouch.x
        
        // YAxis Enable/Disable based on their dataset visibility
        chart.updateAxisObjects()
        
        // Calculate Minimum and Maximum for Axis
        calcMinMax()
        
        // Viewport Offset Adjustments
        calculateOffsets()
        
        // Prepare axis values and Legends
        computeRenderers()
        
        // If custom padding is given, adjust SpaceMin and Max
        chart.updatePadding()
        
        if isPadding {
            valueForTouch = chart.valueForTouchPoint(point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop), axisIndex: 0)

            oldContentLeftX = chart.isRotated ?  valueForTouch.y : valueForTouch.x
        }
        
        if redrawRequired
        {
            chart.moveViewToX(Double(oldContentLeftX))
            chart.setNeedsDisplay()
        }
        else{
            chart.moveViewToXWithoutRedraw(xValue: Double(oldContentLeftX))
        }
        
        setMinMaxRangeToShow()
    }
    
    func setMinMaxRangeToShow() {
        
        guard let chart = chart
            else { return }
        
        if chart.xAxis.minRangeToShow != Double.greatestFiniteMagnitude {
            chart.viewPortHandler.setMaximumScaleX(chart.xRange / chart.xAxis.minRangeToShow)
        }
        
        if chart.xAxis.maxRangeToShow != -Double.greatestFiniteMagnitude {
            chart.viewPortHandler.setMinimumScaleX(chart.xRange / chart.xAxis.maxRangeToShow)
        }
    }

    internal override func calcMinMax()
    {
        guard let chart = chart,
              let _data = chart.data
            else { return }
        
        // calculate / set x-axis range
        if let timeScale = chart._xAxis.scaleTypeProtocol as? TimeScale
        {
            if timeScale.timeScaleType == .Auto {
                timeScale.updateCurrentType(_data.xMin, _data.xMax)
            }
            
            var xMin = TimeScale.getMinimumValue(value: (_data.xMin), currentType: timeScale.currentType )
            var xMax = TimeScale.getMaximumValue(value: (_data.xMax), currentType: timeScale.currentType )
            if _data.xMin == _data.xMax
            {
                xMin = _data.xMax
                xMax = _data.xMax
            }
            chart._xAxis.calculate(min: xMin , max: xMax )
        }
        else{
            chart._xAxis.calculate(min: _data.xMin, max: _data.xMax)
        }
        
        // calculate axis range (min / max) according to provided data
       /* var leftIndex = 0
        var rightIndex = 0
        for yAxis in chart.yAxisArray {
            if yAxis.axisDependency == .left {
                yAxis.calculate(min: _data?.getYMin(axis: .left, axisIndex: leftIndex) ?? 0.0 , max: _data?.getYMax(axis: .left, axisIndex: leftIndex) ?? 0.0)
                leftIndex = leftIndex + 1
            }else {
                yAxis.calculate(min: _data?.getYMin(axis: .right, axisIndex: rightIndex) ?? 0.0 , max: _data?.getYMax(axis: .right, axisIndex: rightIndex) ?? 0.0)
                rightIndex = rightIndex + 1
            }
        }*/
        
        for yAxis in chart.yAxisArray where yAxis.isEnabled {
            
            var yMin = _data.getYMin(axisIndex: yAxis.axisIndex)
            var yMax = _data.getYMax(axisIndex: yAxis.axisIndex)
            if yAxis.scaleType == .Time || yAxis.scaleType == .Linear {
                
                if let timeScale = yAxis.scaleTypeProtocol as? TimeScale {
                    
                    if timeScale.timeScaleType == .Auto {
                        timeScale.updateCurrentType(yMin, yMax)
                    }
                    
                    yMin = TimeScale.getMinimumValue(value: yMin, currentType: timeScale.currentType )
                    yMax = TimeScale.getMaximumValue(value: yMax, currentType: timeScale.currentType )
                }
                
                let (minVal,maxVal) = CommonHelperFunctions.getYMinMaxValue(axis: yAxis, chart: chart)
                
                if minVal == maxVal {
                    yMin = maxVal
                    yMax = maxVal
                }
            }
            
            yAxis.calculate(min: yMin , max: yMax)
        }
    }
    
    internal  override func calculateOffsets()
    {
        
        guard let chart = chart
            else { return }
        
        computeAxisLabelOffsets()
        
        if !chart._customViewPortEnabled
        {
            updateViewPortOffsets()
        }
        
        chart.prepareOffsetMatrix()
        chart.prepareValuePxMatrix()
    }
    
    open func computeRenderers()
    {
         guard let chart = chart
            else { return }
        
        for renderer in chart.renderers
        {
                renderer.initBuffers()
        }
        
        
        for yAxisRenderer in chart.yAxisRenderers where yAxisRenderer.axis != nil && yAxisRenderer.axis!.enabled {
            yAxisRenderer.computeAxis(min: (yAxisRenderer.axis?._axisMinimum)!, max: (yAxisRenderer.axis?._axisMaximum)!, inverted: (yAxisRenderer.axis?.inverted)!)
        }
        
         if let data = chart._data
         {
             chart._xAxisRenderer?.computeAxis(
             min: chart._xAxis._axisMinimum,
             max: chart._xAxis._axisMaximum,
             inverted: chart._xAxis.isInverted)
            
             if chart._legend !== nil && chart.computeLegend
             {
                if chart.colorAxis.isEnabled {
                    if chart._legend.legendRange.Minimum == chart._legend.legendRange.Maximum
                    {
                        chart.colorAxis.calcMinMax(data: data)
                    }
                    
                }else {
                    chart._legendRenderer.computeLegend(data: data)
                }
             }
         }
        
         calculateOffsets()
    }
    
    internal func computeAxisLabelOffsets()
    {
        guard let chart = chart
                   else { return }
        
            chart._xAxisRenderer.computeSize()
          
//            for yAxisRenderer in chart.yAxisRenderers where yAxisRenderer.axis!.enabled {
//              yAxisRenderer.updateLongestLabel()
//          }
    }
    
    internal func calculateLegendOffsets(offsetLeft: inout CGFloat, offsetTop: inout CGFloat, offsetRight: inout CGFloat, offsetBottom: inout CGFloat)
    {
        guard let chart = chart,
            let _legend = chart._legend,
            let _viewPortHandler = chart._viewPortHandler
            else { return }
        
            let xAxis = chart.xAxis
        
           // setup offsets for legend
           if _legend.isEnabled && !_legend.drawInside
           {
               switch _legend.orientation
               {
               case .vertical:
                   
                   switch _legend.horizontalAlignment
                   {
                   case .left:
                       offsetLeft += min(_legend.neededWidth, _viewPortHandler.chartWidth * _legend.maxSizePercent) + _legend.xOffset
                       
                   case .right:
                       offsetRight += min(_legend.neededWidth, _viewPortHandler.chartWidth * _legend.maxSizePercent) + _legend.xOffset
                       
                   case .center:
                       
                       switch _legend.verticalAlignment
                       {
                       case .top:
                           offsetTop += min(_legend.neededHeight, _viewPortHandler.chartHeight * _legend.maxSizePercent) + _legend.yOffset
                           
                       case .bottom:
                           offsetBottom += min(_legend.neededHeight, _viewPortHandler.chartHeight * _legend.maxSizePercent) + _legend.yOffset
                           
                       default:
                           break
                       }
                   }
                   
               case .horizontal:
                   
                   switch _legend.verticalAlignment
                   {
                   case .top:
                       offsetTop += min(_legend.neededHeight, _viewPortHandler.chartHeight * _legend.maxSizePercent) + _legend.yOffset
                       if xAxis.isEnabled && xAxis.isDrawLabelsEnabled
                       {
                           offsetTop += xAxis.labelRotatedHeight
                       }
                       
                   case .bottom:
                       offsetBottom += min(_legend.neededHeight, _viewPortHandler.chartHeight * _legend.maxSizePercent) + _legend.yOffset
                       if xAxis.isEnabled && xAxis.isDrawLabelsEnabled
                       {
                           offsetBottom += xAxis.labelRotatedHeight
                       }
                       
                   default:
                       break
                   }
               }
           }
      }
    
    internal func updateViewPortOffsets()
    {
        guard let chart = chart,
            let plotOption = chart.getPlotOptions() as? AxisChartPlotOptions
            else { return }
        
        var offsetLeft = CGFloat(0.0)
        var offsetRight = CGFloat(0.0)
        var offsetTop = CGFloat(0.0)
         var offsetBottom = CGFloat(0.0)
        
        calculateLegendOffsets(offsetLeft: &offsetLeft,
                                     offsetTop: &offsetTop,
                                     offsetRight: &offsetRight,
                                     offsetBottom: &offsetBottom)
        let xAxis = chart.xAxis
        var offset = 0.0
        
        if chart.isRotated {
            let xlabelwidth = xAxis.labelRotatedWidth
            
            if xAxis.isEnabled
            {
                
                let offset = xAxis.axisLabelOffsets.marginLeft + xAxis.axisLabelOffsets.marginRight
                
                var xlabelwidth = xlabelwidth + offset
                
                if xAxis.limitLines.count > 0 {
                    xlabelwidth = min(max(xlabelwidth, xAxis.limitLineLabeloffset(limitLineType: .horizontal)) + offset, xAxis.maxLabelWidth + offset)
                }
                
                if xAxis.axisTitleEnabled
                {
                    xlabelwidth += xAxis.axisTitleOffsets.marginLeft + xAxis.axisTitleOffsets.marginRight
                }
                
                // offsets for x-labels
                if xAxis.labelPosition == .bottom
                {
                    offsetLeft += xlabelwidth
                }
                else if xAxis.labelPosition == .top
                {
                    offsetRight += xlabelwidth
                }
                else if xAxis.labelPosition == .bothSided
                {
                    offsetLeft += xlabelwidth
                    offsetRight += xlabelwidth
                }
            }
            
            // offsets for y-labels\
            for axis in chart.yAxisArray where axis.needsOffset && axis.axisDependency == .left {
                axis.offsetCalculated = -offsetTop
                offsetTop += axis.getRequiredHeightSpace(constrainedWidth: chart._viewPortHandler.contentWidth, onePointWidth: CommonHelperFunctions.getOnePointWidth(chart: chart), scaleX: chart._viewPortHandler.scaleX)
            }
            
            for axis in chart.yAxisArray where axis.needsOffset && axis.axisDependency == .right {
                axis.offsetCalculated = offsetBottom
                offsetBottom += axis.getRequiredHeightSpace(constrainedWidth: chart._viewPortHandler.contentWidth, onePointWidth: CommonHelperFunctions.getOnePointWidth(chart: chart), scaleX: chart._viewPortHandler.scaleX)
            }
            
            offset = offsetLeft / 2
        }
        else {
            // offsets for y-labels
            yaxisOffset(axisDependency: .left, offset: &offsetLeft)
            yaxisOffset(axisDependency: .right, offset: &offsetRight)
            
            if xAxis.isEnabled && (xAxis.isDrawLabelsEnabled || xAxis.axisTitleEnabled)
            {
                
                let offset = xAxis.axisLabelOffsets.marginTop + xAxis.axisLabelOffsets.marginBotom
                var xlabelheight = xAxis.labelRotatedHeight + offset
                
                if xAxis.limitLines.count > 0 {
                    xlabelheight = min(max(xlabelheight, xAxis.limitLineLabeloffset(limitLineType: .vertical) + offset), xAxis.maxLabelHeight + offset)
                }
                
                if xAxis.axisTitleEnabled
                {
                    xlabelheight += xAxis.axisTitleOffsets.marginTop + xAxis.axisTitleOffsets.marginBotom
                }
                
                // offsets for x-labels
                if xAxis.labelPosition == .bottom
                {
                    offsetBottom += xlabelheight
                }
                else if xAxis.labelPosition == .top
                {
                    offsetTop += xlabelheight
                }
                else if xAxis.labelPosition == .bothSided
                {
                    offsetBottom += xlabelheight
                    offsetTop += xlabelheight
                }
            }
            
            offset = offsetBottom / 2
        }
        
        offsetTop += chart.extraTopOffset
        offsetRight += chart.extraRightOffset
        offsetBottom += chart.extraBottomOffset
        offsetLeft += chart.extraLeftOffset
        
        if !(chart.showPlotView)
        {
            let viewPortSizeHalf = chart.isRotated ? chart.viewPortHandler.chartWidth/2 : chart.viewPortHandler.chartHeight/2
            offsetTop =  viewPortSizeHalf - 0.005 - offset
            offsetBottom = viewPortSizeHalf - 0.005 + offset
        }
        
        chart._viewPortHandler.restrainViewPort(
            offsetLeft: max(plotOption.minOffset, offsetLeft),
            offsetTop: max(plotOption.minOffset, offsetTop),
            offsetRight: max(plotOption.minOffset, offsetRight),
            offsetBottom: max(plotOption.minOffset, offsetBottom))
    }
    
    internal func yaxisOffset(axisDependency: YAxis.AxisDependency, offset: inout CGFloat) {
        guard let chart = chart
            else { return }
        let currentOffset = offset
        for axis in chart.yAxisArray where axis.needsOffset && axis.axisDependency == axisDependency {
            axis.offsetCalculated = axisDependency == .left ? -offset : offset
            offset += axis.requiredSize().width
        }
        
        var limitLineOffset = 0.0
        for axis in chart.yAxisArray where axis.enabled && axis.limitLines.map({ $0.drawLimitValueEnabled || ($0.shapeProperties?.visible ?? false) }).contains(true) && axis.axisDependency == axisDependency {
            limitLineOffset = max(limitLineOffset,axis.requiredSize().width)
        }
        
        offset = max(offset, currentOffset + limitLineOffset)
    }
    
    open func checkIfBaseLineValueWithinRange()
    {
        guard let chart = chart
            else { return }
        
        for axis in chart.yAxisArray where axis.isEnabled {
            if axis.baseLineEnabled && axis.baseLine != nil
            {
                if (axis.baseLine?.baseValue)! > axis.axisMaximum
                {
                    axis.setAxis(maximum: (axis.baseLine?.baseValue)!)
                }
                if (axis.baseLine?.baseValue)! < axis.axisMinimum
                {
                    axis.setAxis(minimum: (axis.baseLine?.baseValue)!)
                }
            }
        }
    }
    
    internal func calcYMinMaxForNonStackedDatasets(axisIndex: Int = 0) -> (Double,Double) {
        
        var (min,max) = (Double.greatestFiniteMagnitude,-(Double.greatestFiniteMagnitude))
        
        guard let chart = chart,
              let chartData = chart.data
            else { return (min,max) }
        
        for dataSet in chartData.dataSets where dataSet.axisIndex == axisIndex {
            
            guard let axisChartPlotOption = chart.getPlotOptions(type: dataSet.plotType) as? AxisChartPlotOptions else {
                continue
            }
            
            if !axisChartPlotOption.isStacked {
                
                if min > dataSet.yMin {
                    min = dataSet.yMin
                }
                
                if max < dataSet.yMax {
                    max = dataSet.yMax
                }
            }
        }
        
        return (min,max)
        
    }
    
    // MARK: - Supporting Methods
    
    /// Expected width and padded width are same
    open func getPaddingValueBinarySearch(min:Double,max:Double, expectedWidth:CGFloat, axis: AxisBase) -> Double
    {
        var min = min
        var max = max
        
        var mid:Double = 0
        
        var width:CGFloat = 0
        
        let delta:CGFloat = 0.009
        
        repeat{
            
            mid = (min+max)/2
            
            if axis.isKind(of: XAxis.self)
            {
                width = self.getCurrentWidthAfterPadding(padding: mid ) * CGFloat(mid)
            }
            else{
                if let axis = axis as? YAxis {
                    width = self.getCurrentHeightAfterYPadding(padding: mid, axis: axis) * CGFloat(mid)
                }
            }
            
            if width > expectedWidth
            {
                max = mid
            }
            else if width < expectedWidth
            {
                min = mid
            }
            
            // To avoid loop
            if min == max || (abs(max-min) < Double(delta))
            {
                return mid
            }
            
            if width.isNaN || width <= 0
            {
                return 0
            }
            
        }
            while   !(abs(width-expectedWidth) < delta)
        
        return mid
    }
    
    func getPaddingValueBinarySearch(padding:Double,expectedWidth:CGFloat) -> Double
    {
           var min = padding
           var max = padding+1
           
           var mid:Double = 0
           
           var width:CGFloat = 0
           
           let delta:CGFloat = 0.009
           
           repeat{
               
               mid = (min+max)/2
               width = self.getCurrentWidthAfterPadding(padding: mid )
               
               if width > expectedWidth
               {
                   min = mid
               }
               else if width < expectedWidth
               {
                   max = mid
               }
               
               // To avoid loop
               if min == max
               {
                   return mid
               }
               
               if width.isNaN
               {
                   return 0
               }
               
           }
               while   !(abs(width-expectedWidth) < delta)
           
           return mid
    }
       
    open func getCurrentWidthAfterPadding(padding:Double) -> CGFloat
    {
           guard let chart = chart
               else { return 0 }
        
        let (spaceMin,spaceMax) = CommonHelperFunctions.getPaddingValues(spaceMinPixel: chart.xAxis.spaceMinPixel, spaceMaxPixel: chart.xAxis.spaceMaxPixel, overAllPadding: padding)
           
           chart.xAxis.spaceMax = spaceMax
           chart.xAxis.spaceMin = spaceMin
           
           calcMinMax()
           
           chart.prepareValuePxMatrix()
           
           return  CommonHelperFunctions.getOnePointWidth(chart: chart)
    }
       
    open func getCurrentHeightAfterYPadding(padding: Double, axis:YAxis ) -> CGFloat
    {
           guard let chart = chart
               else { return 0 }
           
           axis.spaceMax = padding
           axis.spaceMin = padding
           
           calcMinMax()
           
           chart.prepareValuePxMatrix()
           
           return  CommonHelperFunctions.getOnePointHeight(chart: chart, axis: axis)
    }
    
    
    public func toolTipHighlight(newEntry:ChartDataEntry)
    {
        fatalError("Highlight cannot be called on BarLineChartViewBase")
    }
    
    // MARK: - Protocol Implementations
    
    override public func tooltipSelected(entry: ChartDataEntry?) {
       
        guard let chart = chart,
        let plotOption = chart.getPlotOptions() as? AxisChartPlotOptions
        else { return }
        
        if entry == nil{
              plotOption.barGroupSelectionEnabled = true
            chart.xGroupSelected = true
          }
          
        guard let newEntry = chart.xAxis.isInverted ? CommonHelperFunctions.getPrevXEntryinData(entry: entry, includeXNan: false, includeYNan: false, loopingAllowed: true, chart: chart) : CommonHelperFunctions.getNextXEntryinData(entry: entry, includeXNan: false, includeYNan: false, loopingAllowed: true, chart: chart),         //CommonHelperFunctions.getNextEntry(entry: entry, includeXNan: false, includeYNan: false, chart: self),
              let location =  CommonHelperFunctions.getEntryLocation(chart: chart, entry: newEntry)
              else { return }
          
        /*  let set = data?.getDataSetForEntry(newEntry)
          
          var animate:Bool = false
          
          if !viewPortHandler.isInBoundsX(location.x)
          {
              animate = true
              //            self.moveViewToAnimated(xValue: newEntry.x, yValue: newEntry.y, axis: (set?.axisDependency)!, axisIndex: (set?.axisIndex)!, duration: 0.5)
              self.centerViewToAnimated(xValue: newEntry.x, yValue: newEntry.y, axis: (set?.axisDependency)!, axisIndex: (set?.axisIndex)!, duration: 0.5)
          }
          
          CommonHelperFunctions.removeHighlightLayer(chart: self)
          
          self.lastSelected = newEntry
          
          if animate{
              DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(550), execute: {
                  self.performHighlight(newEntry: newEntry)
              })
          }
          else{
              performHighlight(newEntry: newEntry)
          }*/
          
          let block = {
              CommonHelperFunctions.removeHighlightLayer(chart: chart)
//              chart.lastSelected = newEntry
                chart.updateLastSelectedEntry(entry: newEntry)
              self.toolTipHighlight(newEntry: newEntry)
          }
        CommonHelperFunctions.scrollViewToXAndExecuteBlock(x: newEntry.x, y: newEntry.y, duration: 0.5, executionBlock: block, alignCenter: false, chart: chart)
    }
    
}

extension AxisChartPreprocessor {
    
    public static func prepareAxisCompounds(chart: ChartViewBase) {
        
        for renderer in chart.yAxisRenderers {
            
            guard let yAxis = renderer.axis as? YAxis,
                  let viewPortHandler = chart.viewPortHandler,
                  yAxis.isEnabled || yAxis.isVisible else {
                continue
            }
            
            let positions = renderer.transformedPositions()
            
            let from = yAxis.isDrawBottomYLabelEntryEnabled ? 0 : 1
            let to = yAxis.isDrawTopYLabelEntryEnabled ? yAxis.entryCount : (yAxis.entryCount - 1)
            
            if let renderer = renderer as? YAxisRenderer, yAxis.drawLabelsEnabled {
                renderer.tickLabels.removeAll()
                
                var maxSize = CGSize()
                
                yAxis.computeMaxTickSize(maxSize: &maxSize, isRotated: chart.isRotated)
                
                for i in stride(from: from, to: to, by: 1)
                {
                    
                    let ticklabelModel = TickLabel.createTickModel(axis: yAxis, axisEntryIndex: i, constrainedToSize: maxSize, anchorPoint: chart.isRotated ? CGPoint(x: 0.5, y: 0.0) : CGPoint(x: 0.5, y: 0.5))
                    var size = CGSize()
                    
                    if !chart.isRotated {
                        size = ChartUtils.sizeOfRotatedRectangle(ticklabelModel.label.size(withAttributes: ticklabelModel.attributes), radians: ticklabelModel.angleInRadians)
                    }
                    
                    yAxis.calculateOffsetForFixed(position: positions[i], tickLabelSize: size, axisTickPosition: &ticklabelModel.point, isRotated: chart.isRotated, viewPortHandler: viewPortHandler)
                    
                    ticklabelModel.updateTickBounds()
                    
                    if renderer.tickLabels.count > 0 && ticklabelModel.boundPath.boundingBoxOfPath.intersects(renderer.tickLabels[renderer.tickLabels.count - 1].boundPath.boundingBoxOfPath) {
                        continue
                    }
                    
                    renderer.tickLabels.append(ticklabelModel)
                }
            }
            
            if yAxis.isDrawGridLinesEnabled {
                
                renderer.tickPositions.removeAll()
                
                for i in 0..<yAxis.entries.count
                {
                    if let position = positions[safe:i] {
                        renderer.tickPositions.append(TickModel.createTickPosition(axis: yAxis, axisEntryIndex: i, axisTickPosition: position))
                    }
                }
            }
        }
        
        if let chartData = chart.data, let viewPortHandler = chart.viewPortHandler, chart.xAxis.isEnabled || chart.xAxis.isVisible {
            
            let xAxis = chart.xAxis
            
            var positions = chart.xAxisRenderer.transformedPositions()
            
            if chart.xAxis.drawLabelsEnabled {
                chart.xAxisRenderer.tickLabels.removeAll()
                
                var maxSize = CGSize()
                
                let isMekko = (chart.plotTypes.contains(.Mekko))
                
                if isMekko
                {
                    chart.xAxis.entries = []
                    if let xStringArr = chart.data?.xString {
                        for i in 0..<xStringArr.count
                        {
                            chart.xAxis.entries.append(Double(i))
                        }
                    }
                    positions = chart.xAxisRenderer.transformedPositions()
                    
                    maxSize = chart.xAxis.longestSize
                    chart.xAxis.labelRotationAngle = 0
                }
                else {
                    //            xAxis.scaleType == .Time && !chart.isRotated ? maxSize.width = CommonHelperFunctions.getMaxWidthBetweenEntries(barLine: chart) : chart.xAxis.computeMaxTickSize(maxSize: &maxSize, isRotated: chart.isRotated)
                    
                    if !chart.isRotated {
                        maxSize.width = chartData.xMin == chartData.xMax ? (viewPortHandler.contentWidth) : xAxis.labelRotatedWidth
                        
                        if xAxis.scaleType == .Time
                        {
                            maxSize.width = CommonHelperFunctions.getMaxWidthBetweenEntries(barLine: chart)
                        }
                    }
                    
                    chart.xAxis.computeMaxTickSize(maxSize: &maxSize, isRotated: chart.isRotated)
                }
                
                if xAxis.labelPosition == .bothSided {
                    
                    prepareTickLabelModelForXAxis(
                        positions: positions,
                        anchorPoint: xAxis.getAnchorForAxisTickLabel(isRotated: chart.isRotated, labelPosition: .top),
                        maxSize: maxSize,
                        chart: chart)
                    
                    prepareTickLabelModelForXAxis(
                        positions: positions,
                        anchorPoint: xAxis.getAnchorForAxisTickLabel(isRotated: chart.isRotated, labelPosition: .bottom),
                        maxSize: maxSize,
                        chart: chart)
                }
                else {
                    prepareTickLabelModelForXAxis(
                        positions: positions,
                        anchorPoint: xAxis.getAnchorForAxisTickLabel(isRotated: chart.isRotated),
                        maxSize: maxSize,
                        chart: chart)
                }
                
            }
            
            if xAxis.drawGridLinesEnabled {
                
                chart.xAxisRenderer.tickPositions.removeAll()
                
                for i in stride(from: 0, to: xAxis.entryCount, by: 1)
                {
                    if positions[safe:i] != nil {
                        chart.xAxisRenderer.tickPositions.append(TickModel.createTickPosition(axis: xAxis, axisEntryIndex: i, axisTickPosition: positions[i]))
                    }
                }
            }
        }
    }
    
    fileprivate static func prepareTickLabelModelForXAxis(positions: [CGPoint], anchorPoint: CGPoint, maxSize: CGSize, chart: ChartViewBase) {
        
        guard let chartData = chart.data,
              let viewPortHandler = chart.viewPortHandler else {
            return
        }
        
        let isMekko = (chart.plotTypes.contains(.Mekko))
        var sumX:CGFloat = 0
        
        for i in stride(from: 0, to: chart.xAxis.entryCount, by: 1)
        {
            
            /*Added this snippet to ignore the label rendering for invalid x-entries, case::Only 2 bar entry in singlebarchart, to render the bar as center aligned, then need to add outerpadding properties and thus lead rendering for invalid-labels actually not available in datasets */
            /*if (chart.isRotated) && (chartData.dataSetCount) == 1 //Only for single barchart
            {
                let value =  ChartUtils.doubleToIntSafeCast(value:chart.xAxis.entries[i])
                let dataset = chartData.dataSets.first
                let entry = dataset?.entryForIndex(value)
                if entry == nil
                {
                    continue
                }
            }*/
            
            /*Added this snippet to ignore the label rendering for invalid x-entries, case::Only 2 bar entry in singlebarchart, to render the bar as center aligned, then need to add outerpadding properties and thus lead rendering for invalid-labels actually not available in datasets */
            var dataMin = chartData.xMin
            var dataMax = chartData.xMax
            
            if chart.xAxis.scaleType == .Time
            {
                dataMin = TimeScale.getMinimumValue(value: dataMin, currentType: (chart.xAxis.scaleTypeProtocol as! TimeScale).currentType)
                dataMax = TimeScale.getMaximumValue(value: dataMax, currentType: (chart.xAxis.scaleTypeProtocol as! TimeScale).currentType)
            }
            
            if chart.xAxis.entries[i] < dataMin || chart.xAxis.entries[i] > dataMax
            {
                continue
            }
            
            var labelMaxSize = maxSize
            
            if positions.count < i || positions[safe:i] == nil {
                break
            }
            
            var position = positions[i]
            
            if isMekko
            {
                guard let processor = chart.getProcessor(type: .Mekko) as? MekkoPreprocessor,
                      let xString = chartData.xString?[ChartUtils.doubleToIntSafeCast(value:chart.xAxis.entries[i])],
                      let sizeValue = processor.categoryToSize[xString]?.1
                else { return }
                
                if chart.xAxis.tickLabelMode == .wordwrap
                {
                    let temp = CGPoint(x: sizeValue, y: 0)
                    labelMaxSize = CGSize(width: chart.pixelForValues(point: temp, axisIndex: 0).x-viewPortHandler.contentLeft, height: chart.xAxis.maxLabelHeight)
                }
                
                let xVal = sumX + (sizeValue/2)
                sumX += sizeValue
                position.x = xVal
                position.y = 0.0
                position = chart.pixelForValues(point: position, axisIndex: 0)
            }
            
            let tickLabel = TickLabel.createTickModel(axis: chart.xAxis, axisEntryIndex: i, constrainedToSize: labelMaxSize, anchorPoint: anchorPoint)
            
            var size = CGSize()
            
            if chart.isRotated {
                size = ChartUtils.sizeOfRotatedRectangle(tickLabel.label.size(withAttributes: tickLabel.attributes), radians: tickLabel.angleInRadians)
            }
            
            chart.xAxis.calculateOffsetForFixed(position: position, axisTickPosition: &tickLabel.point, tickLabelSize: size, isRotated: chart.isRotated, viewPortHandler: viewPortHandler)
            
            
            /*
            if (chart.plotTypes.contains(.Bar)) && (chartData.dataSetCount) > 1 && !(((chart.getPlotOptions(type: .Bar)) as? BarPlotOptions)?.groupSpace == 0)
            {
                tickLabel.point.x = getNewPositionForBarChart(value: chart.xAxis.entries[i], valueToPixelMatrix: transformer.valueToPixelMatrix, position: tickLabel.point)
            }
            
            if chart.xAxis.isAvoidFirstLastClippingEnabled
            {
                // avoid clipping of the last
                if i == chart.xAxis.entryCount - 1 && chart.xAxis.entryCount > 1
                {
                    let width = tickLabel.label.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: tickLabel.attributes, context: nil).size.width
                    
                    if width > viewPortHandler.offsetRight * 2.0
                        && tickLabel.point.x + width > viewPortHandler.chartWidth
                    {
                        tickLabel.point.x -= width / 2.0
                    }
                }
                else if i == 0
                { // avoid clipping of the first
                    let width = tickLabel.label.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: tickLabel.attributes, context: nil).size.width
                    tickLabel.point.x += width / 2.0
                }
            }
            */
            
            if chart.xAxis.isAvoidFirstLastClippingEnabled
            {
                // avoid clipping of the last
                if i == chart.xAxis.entryCount - 1 && chart.xAxis.entryCount > 1
                {
                    let width = tickLabel.label.boundingRect(with: labelMaxSize, options: .usesLineFragmentOrigin, attributes: tickLabel.attributes, context: nil).size.width
                    
                    if width > viewPortHandler.offsetRight * 2.0
                        && tickLabel.point.x + width > viewPortHandler.chartWidth
                    {
                        tickLabel.point.x -= width / 2.0
                    }
                }
                else if i == 0
                { // avoid clipping of the first
                    let width = tickLabel.label.boundingRect(with: labelMaxSize, options: .usesLineFragmentOrigin, attributes: tickLabel.attributes, context: nil).size.width
                    tickLabel.point.x += width / 2.0
                }
            }
            
            tickLabel.updateTickBounds()
            
            if chart.xAxisRenderer.tickLabels.count > 0 && CommonHelperFunctions.isOverlapping(currentBound: tickLabel.boundPath, previousBound: chart.xAxisRenderer.tickLabels[chart.xAxisRenderer.tickLabels.count - 1].boundPath) {
                continue
            }
            
            chart.xAxisRenderer.tickLabels.append(tickLabel)
        }
    }
}
