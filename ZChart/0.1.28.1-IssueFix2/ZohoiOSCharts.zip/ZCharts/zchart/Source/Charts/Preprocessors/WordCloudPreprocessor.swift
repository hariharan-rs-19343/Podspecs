//
//  WordCloudPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 04/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//
import WebKit

open class WordCloudPreprocessor:ChartPreprocessor, WKNavigationDelegate
{
    fileprivate var isRedrawAllowed = false
    internal var isWebViewLoadAllowed = true
    
    // [CGRect] per dataset
    internal var _buffers:[[String:Any]] = []
    
    var webView:WKWebView!
    
//    // MARK: - Initializers
    override func initialize() {
    
        guard let chart = chart
            else { return }
        
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: CGRect.zero, configuration: webConfiguration)
        webView.navigationDelegate = self
        webView.nsuiLayer!.backgroundColor = NSUIColor.clear.cgColor
        #if !os(OSX)
            webView.isOpaque = false
        #endif
        
        chart.addSubview(webView)
        
        chart.xAxis.enabled = false
    }

    // MARK: - Data Updation Calculation
   open override func notifyDataSetChanged(redrawRequired: Bool)
   {
       guard  let chart = chart,
           let data = chart.data,
           let plotOption = chart.getPlotOptions(type: .WordCloud) as? WordCloudPlotOptions
           else {
               return
       }
    
       isRedrawAllowed = redrawRequired
    
       computeRenderers()
       
       webView.frame = chart.viewPortHandler.contentRect
        
       var fontNamesParams = "?q"
       if plotOption.isCustomFontUsed
       {
            for fontIndex in 0..<plotOption.customFontsList.count
            {
                let fontName = plotOption.customFontsList[fontIndex]
                
                fontNamesParams += String(fontIndex)+"="+fontName+"& q"
                
               let fileManager = FileManager.default
              
               guard let sourceURL = Bundle.main.path(forResource: fontName, ofType: "ttf")
                else { continue }
              
               let destPath = Bundle(for: ChartViewBase.self).bundlePath+"/"+fontName+".ttf"
              
               if !fileManager.fileExists(atPath: destPath) {
                  do  {
                      try fileManager.copyItem(atPath: sourceURL, toPath: destPath) }
                  catch {
                      print("Error in copying ")
                  }
               }
            }
       }
        if fontNamesParams.count > 2
        {
            fontNamesParams.removeLast(3)
        }
    
        if isWebViewLoadAllowed
        {
            _buffers.removeAll()
            let bundle = Bundle(for: ChartViewBase.self)
            do {
                guard let url1 = bundle.url(forResource: "WordCloudLayout", withExtension: "html"),
                let url2 = URL(string: fontNamesParams, relativeTo: url1)
                else { return }
                let myRequest = URLRequest(url: url2)
                webView.load(myRequest)
            } catch {
                // catch error
            }
        }
       
        if !isWebViewLoadAllowed && redrawRequired
        {
            chart.setNeedsDisplay()
        }
    
        chart.prepareValuePxMatrixForPlot()
   }
    
    override func calculateOffsets() {
        
        guard  let chart = chart,
            let plotOptions = chart.getPlotOptions(type: .WordCloud) as? WordCloudPlotOptions
        else {
                return
        }
        
        let outerPadding = plotOptions.outerPadding
        
        chart._viewPortHandler.restrainViewPort(
            offsetLeft: outerPadding,
            offsetTop: outerPadding,
            offsetRight: outerPadding,
            offsetBottom: outerPadding)
        
    }
    
    open func computeRenderers()
    {
         guard let chart = chart
            else { return }
        
        for renderer in chart.renderers
        {
                renderer.initBuffers()
        }
        
         if let data = chart._data
         {
             if chart._legend !== nil && chart.computeLegend
             {
                if chart.colorAxis.isEnabled {
                    if chart._legend.legendRange.Minimum == chart._legend.legendRange.Maximum
                    {
                        chart.colorAxis.calcMinMax(data: data)
                    }
                    
                }else {
                    chart._legendRenderer.computeLegend(data: data)
                }
//                chart.callDelegateForLegendReload()
             }
         }
        
         calculateOffsets()
    }
    
    fileprivate func prepareData() -> [String:Any]
    {
        var finalDict:[String:Any] = [:]
        
        guard  let chart = chart,
            let data = chart.data,
            let plotOption = chart.getPlotOptions(type: .WordCloud) as? WordCloudPlotOptions
            else {
                return finalDict
        }
        
        var sets:[Any] = []
        
        var fontFamilyArray:[String] = []
        
        var yMax:Double = -Double.greatestFiniteMagnitude
        
        for setIndex in 0..<data.dataSets.count
        {
            let set = data.dataSets[setIndex]
            
            let formatter = set.valueFormatter
            
            fontFamilyArray.append(set.valueFont.isSystemFont() ? "-apple-system" : set.valueFont.fontName)
            
            if !(set.isVisible)
            {
                continue
            }
            
            var entries:[Any] = []
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex),
                      !(entry.filterEnabled)
                else { continue }
                
                if entry.y > yMax
                {
                    yMax = entry.y
                }
                
                let valueString = formatter != nil ? formatter?.getFormattedValue(entry: entry) : entry.xString
                
                let yValue:Double? = (entry.y.isNaN || entry.y.isInfinite) ? nil : entry.y
                
                let values = [valueString as Any,yValue,setIndex,entryIndex] as [Any]
                entries.append(values)
            }
            sets.append(entries)
        }
        finalDict["data"] = sets
        
        let config:[String : Any] = [
            "dataMin": 0,
            "dataMax": yMax,
            "minSize": plotOption.minFontSize,
            "maxSize": plotOption.maxFontSize,
            "interPadding": plotOption.interPadding,
            "outerPadding": plotOption.outerPadding,
            "fontFamily": fontFamilyArray,
            "rotation": plotOption.rotation,
            "frame" :
                [
                    "x":chart.viewPortHandler.contentLeft,
                    "y":chart.viewPortHandler.contentTop,
                    "width":chart.viewPortHandler.contentRect.width,
                    "height":chart.viewPortHandler.contentRect.height
                ],
            
        ]
        
        finalDict["config"] = config
        
        return finalDict
    }
    
     /////====================== ****************************** ====================== /////
    
    
    // MARK: - Delegate
    
    public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        prepareDataAndBuffer(redraw: isRedrawAllowed, completionBlock: nil)
    }
    
    func prepareDataAndBuffer(redraw:Bool,completionBlock:(() -> Void)?)
    {
        _buffers.removeAll()
      
        let data = prepareData()
      
        do {
          
          let jsonData = try JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)

          guard let jsonString = String(data: jsonData, encoding: .utf8),
                (self.chart != nil)
            else { return }
          
          self.webView.evaluateJavaScript("getPrepareData(JSON.stringify("+jsonString+"))"){ (result, error) in
             if error == nil {
                  guard let dictArray = (result as? [[String:Any]])
                 else { return }
              
                  self._buffers = dictArray
                
                  if redraw
                  {
                      self.chart?.setNeedsDisplay()
                  }
                
                  if completionBlock != nil
                  {
                        completionBlock!()
                  }
                 _ = self.chart?.delegateToContainer?.chartBufferLoadedBeforeDraw?(chartView: self.chart!)
             }
          
          }
            
        } catch {

        }
    }
    
    /////====================== ****************************** ====================== /////
 
    // MARK: - Gesture Handled
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint) -> (entry: ChartDataEntry?, layer: ChartEntryLayer?) {
        
        guard let chart = chart
            else { return (nil,nil) }
        
        var entry:ChartDataEntry? = nil
        
        let textLayer = WordCloudTextLayer.getWordLayerInPoint(chart: chart, loc: location)
        
        if textLayer != nil
        {
            entry = textLayer?.chartEntry
        }
        
        return (entry,textLayer)
    }
    
  
    
    
    /////====================== ****************************** ====================== /////
    
    
    // MARK: - Protocol Implementations
    
    /// Tooltip tapped
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
        guard let chart = chart
            else { return }
        
        
    }
    
    /// Legend tapped
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard let chart = chart,
            let set = (chart.data?.dataSets[indexPath.item]) as? ChartDataSet
            else { return }
        
        WordCloudHelperFunctions.hideDatasetWithAnimations(dataSets: [set], chart: chart, duration: 1)
    }
        
        
    /// Legend tapped
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard let chart = chart,
            let set = (chart.data?.dataSets[indexPath.item]) as? ChartDataSet
            else { return }
        
        WordCloudHelperFunctions.includeDatasetWithAnimations(dataSets: [set], chart: chart, duration: 1)
    }
    
    /// Legend range adjusted
    open override func legendRangeSelected(minimum: Double, maximum: Double) {
        
        guard let chart = chart
        else { return  }
        
        super.legendRangeSelected(minimum: minimum, maximum: maximum)
        
        chart.lastSelected = nil
        
        WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: nil)
        
    }
    
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
        guard let entries = entry,
              let chart = chart
        else { return }
        WordCloudHelperFunctions.includeWordCloudEntriesWithAnimations(entries: entries, chart: chart, duration: 0.5)
    }
    
}

