//
//  AreaPreprocessor.swift
//  zchart
//
//  Created by Keerthivass B S on 09/05/24.
//

import Foundation

open class AreaPreprocessor: LineChartPreprocessor {
    
    open override func calcPosNegSum() {
        entriesStackedYValue.removeAll()
        
        xUniqueValues.removeAll()
       
        guard let data = chart?.data,
              let chart = chart,
              let areaPlotType = CommonHelperFunctions.getPlotOption(chart: chart, types: [ .Area]) as? AreaPlotOptions
              else { return }
        
        if !areaPlotType.isStacked{
            return
        }
        
        let areaDataSets:[IChartDataSet] = data.dataSets.filter({
            $0.plotType == .Area
        })
        
        updateEntriesStackValue(dataset: areaDataSets, plotOptions: areaPlotType)
    }
}
