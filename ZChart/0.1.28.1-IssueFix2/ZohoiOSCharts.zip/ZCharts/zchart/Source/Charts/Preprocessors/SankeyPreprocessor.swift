//
//  SankeyPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 15/09/22.
//

import Foundation
import WebKit

open class SankeyPreprocessor:ChartPreprocessor, WKNavigationDelegate
{
    fileprivate var isRedrawAllowed = false
    internal var isWebViewLoadAllowed = true
    
    var dataValues:[Any] = []
    
    var updatedNodeWidth = CGFloat(24)
    
    var webView:WKWebView!
    
    // MARK: - Initialize
    
    override func initialize() {
        
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: CGRect.zero, configuration: webConfiguration)
        webView.navigationDelegate = self
        webView.nsuiLayer?.backgroundColor = NSUIColor.clear.cgColor
        
        #if os(iOS) || os(tvOS)
        webView.isOpaque = false
        #endif
        
        chart?.addSubview(webView)
        
        chart?.xAxis.enabled  = false
    }
    
    // MARK: - Data Updation Calculation
    
    override open func notifyDataSetChanged(redrawRequired: Bool) {
    
        guard let chart = chart,
            let data = chart.data
        else { return }
        
        isRedrawAllowed = redrawRequired
        
        calculateOffsets()
        
        chart.prepareValuePxMatrixForPlot()
        
        webView.frame = chart.viewPortHandler.contentRect
     
         if isWebViewLoadAllowed
         {
             let bundle = Bundle(for: ChartViewBase.self)
             do {
                 guard let url1 = bundle.url(forResource: "sankeyLayout", withExtension: "html")
                 else { return }
                 
                 let myRequest = URLRequest(url: url1)
                 webView.load(myRequest)
             } catch {
                 // catch error
             }
         }
        //doSankyLayout()
        
        if chart._legend !== nil
        {
            chart._legendRenderer.computeLegend(data: data)
        }
        
        if !isWebViewLoadAllowed && redrawRequired
        {
            chart.setNeedsDisplay()
        }

    }
    
    public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        prepareDataAndBuffer(redraw: isRedrawAllowed, completionBlock: nil)
    }
    
    func prepareDataAndBuffer(redraw:Bool,completionBlock:(() -> Void)?)
    {
        guard let chart = chart
            else { return }
    
        let data = getDataInFormat()
        
        do {

          let jsonData = try JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)

          guard let jsonString = String(data: jsonData, encoding: .utf8),
                (self.chart != nil)
            else { return }
            
            self.webView.evaluateJavaScript("getPrepareData("+jsonString+")"){ (result, error) in
                
             if error == nil {
                 
                 
                 guard let dictArray = (result as? [Any])?[0] as? Any
                 else { return }

                 self.dataValues = [dictArray]
                 
                 self.updateNodeWidth()
                 
                  if redraw
                  {
                      chart.setNeedsDisplay()
                  }

                  if completionBlock != nil
                  {
                        completionBlock!()
                  }
                 _ = chart.delegateToContainer?.chartBufferLoadedBeforeDraw?(chartView: self.chart!)
             }
          }

        } catch {

        }
    }
    
    func updateNodeWidth()
    {
        guard
            let chart = chart,
            let processor = chart.getProcessor(type: .Sanky) as? SankeyPreprocessor,
            let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
            else { return }
        
            updatedNodeWidth = plotOption.maxNodeWidth
        
            let finalArray = processor.dataValues
        
            let actualWidthInterPolator = Interpolator.interpolate(a: plotOption.maxNodeWidth, b: plotOption.minNodeWidth)
        
            let nodeWidthInterpolateStartPercent = plotOption.nodeWidthInterpolateStartPercent
            let nodeWidthInterpolateEndPercent = plotOption.nodeWidthInterpolateEndPercent
            
        
            for arrayVal in finalArray {
            
                guard let parentObject = arrayVal as? NSDictionary,
                      let nodeObject = parentObject["nodes"] as? [NSDictionary],
                      let linkObject = parentObject["links"] as? [NSDictionary]
                else { continue }
                
    
                var firstX = CGFloat.greatestFiniteMagnitude
                var lastX = CGFloat.leastNormalMagnitude
                
                var firstLinkX = CGFloat.greatestFiniteMagnitude
                var lastLinkX = CGFloat.leastNormalMagnitude
                
                var nodeCount = 0
                var nodeCountDict:[Double:Int] = [:]
                
                for object in nodeObject
                {
                    guard let x0Value = object["x0"] as? CGFloat,
                          let x1Value = object["x1"] as? CGFloat
                    else { continue }
                    
                    firstX = min(firstX,x0Value)
                    lastX = max(lastX,x1Value)
                    
                    if nodeCountDict[x0Value] == nil
                    {
                        nodeCount += 1
                        nodeCountDict[x0Value] = 1
                    }
                }
                
                for object in linkObject
                {
                    guard let x0Value = (object["source"] as? NSDictionary)?["x1"] as? CGFloat,
                          let x1Value = (object["target"] as? NSDictionary)?["x0"] as? CGFloat
                    else { continue }
                    
                    firstLinkX = min(firstLinkX ,x0Value)
                    lastLinkX = max(lastLinkX ,x1Value)
                }
                
                let viewWidth = chart.viewPortHandler.contentWidth
                let totalNodeWidth = CGFloat(nodeCount) * plotOption.maxNodeWidth
                let currentPercent = (totalNodeWidth/viewWidth)*100
                var widthPercent = Interpolator.precentage(a: nodeWidthInterpolateStartPercent, b: nodeWidthInterpolateEndPercent, value: currentPercent)
                widthPercent = (widthPercent < 0) ? 0 : ((widthPercent > 1) ? 1 : widthPercent)
                
                updatedNodeWidth = actualWidthInterPolator(widthPercent)
            
            }
    }
    
    fileprivate func getDataInFormat() -> [String:Any]
    {
        var finalDict:[String:Any] = [:]
        var data:[String:Any] = [:]
        
        guard let chart = chart,
            let dataSets = chart.data?.dataSets as? [ChartDataSet],
            let plotOptions = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
            else { return data }
        
        for setIndex in 0..<(dataSets.count)
        {
            let set = dataSets[setIndex]
            
            if !(set.isVisible)
            {
                continue
            }
            var entryNodes:[[String:Any]] = []
            var links:[[String:Any]] = []
            
            var uniqueNodes:[String:Int] = [:]
            
            var nodeIndex = -1
            
            for entryIndex in 0..<set.values.count
            {
                
                let entry = set.values[entryIndex]
                
                if entry.filterEnabled || (entry.size ?? 0.0).isNaN
                {
                    continue
                }
                
                guard let source = entry.xString,
                      let target = entry.yString
                    else { continue}
                
                if uniqueNodes[source] == nil
                {
                    entryNodes.append(["name":source])
                    nodeIndex += 1
                    uniqueNodes[source] = nodeIndex
                }
                if uniqueNodes[target] == nil
                {
                    entryNodes.append(["name":target])
                    nodeIndex += 1
                    uniqueNodes[target] = nodeIndex
                }
                
                
                var entryLink:[String:Any] = [:]
                
                entryLink["source"] = uniqueNodes[source]
                entryLink["target"] = uniqueNodes[target]
                entryLink["value"] = entry.size ?? 0.0
                entryLink["entryIndex"] = entryIndex
                
                links.append(entryLink)
            }
            
            data["nodes"] = entryNodes
            data["links"] = links
        }
        
        let config:[String : Any] = [
            "nodeWidth": plotOptions.maxNodeWidth,
            "nodePadding": plotOptions.nodePadding,
            "align": plotOptions.nodeAlign.rawValue,
            "frame" :
                [
                    [plotOptions.outerPadding + chart.viewPortHandler.contentRect.origin.x,
                     plotOptions.outerPadding + chart.viewPortHandler.contentRect.origin.y],
                    [chart.viewPortHandler.contentRect.size.width, chart.viewPortHandler.contentRect.size.height]
                ],
        ]
        
        finalDict["data"] = data
        finalDict["config"] = config
        
        return finalDict
    }
    
    
    override func calculateOffsets() {
        
        guard  let chart = chart,
               let plotOptions = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
        else {
                return
        }
        
        let outerPadding:CGFloat = plotOptions.outerPadding
        
        chart._viewPortHandler.restrainViewPort(
            offsetLeft: outerPadding + chart.extraLeftOffset,
            offsetTop: outerPadding + chart.extraTopOffset,
            offsetRight: outerPadding + chart.extraRightOffset,
            offsetBottom: outerPadding + chart.extraBottomOffset)
        
    }
       
       /////====================== ****************************** ====================== /////
       
    // MARK: - Supporting Methods
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        var entry:ChartDataEntry? = nil
        
        var sankyLayers:SankyLayers? = nil

        if let chartView = chart
        {
            sankyLayers = SankyLayers.getSankeyLayerForTouchPoint(chart: chartView, loc: location)
            
            if let layer = sankyLayers {
                
                if layer.type == .Node {
                    if let dataset = chartView.data?.dataSets[safe: 0] as? ChartDataSet {
                        entry = SankeyHelperFunctions.getEntriesFornodeName(dataset: dataset, nodeName: layer.nodeName)[safe: 0]
                    }
                }
                else {
                    entry = layer.chartEntry
                }
            }
        }
        
        return (entry,sankyLayers)
        
    }
    
    // MARK: - Protocol Implementation
       
    public override func filterEntrySelected(entry: [ChartDataEntry]?) {
        guard let chart = chart,
            (entry != nil)
            else { return }
        
        ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: chart, entries: entry, duration: 0.5)
    }
    
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
    }
    
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
       
         guard let chart = chart,
               let set = (chart.data?.dataSets[0]) as? ChartDataSet
                   else { return }
        
        let enabledEntries = SankeyHelperFunctions.getInteractedEntriesForEnable(dataset: set, entryString: entry.label!)
               
         chart.interactionAnimationInProgress = true
        
        SankeyHelperFunctions.includeDataset(chart: chart, dataset: set, enabledEntries: enabledEntries, duration: 1)
       
    }
   
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
       
        guard let chart = chart,
              let data = chart.data,
              let set = (data.dataSets[0]) as? ChartDataSet,
              let entryLabel = entry.label
            else { return }
        
        let DisabledEntries = SankeyHelperFunctions.getInteractedEntriesForDisable(dataSet: set, entryString: entryLabel, isEnabled: false)
        
        if DisabledEntries.count == 0 {
            chart._legendRenderer.computeLegend(data: data)
            chart.callDelegateForLegendReload()
            return
        }
        
        chart.interactionAnimationInProgress = true
        
        SankeyHelperFunctions.hideDataset(dataset: set, nodeNames: [entryLabel], disabledEntries: DisabledEntries,chart: chart, duration: 1)
       
    }
}

