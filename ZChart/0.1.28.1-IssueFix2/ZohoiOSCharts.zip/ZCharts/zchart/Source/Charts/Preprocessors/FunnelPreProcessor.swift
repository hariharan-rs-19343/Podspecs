//
//  FunnelPreProcessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 03/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

open class FunnelPreprocessor:ChartPreprocessor
{
//    open weak var dataProvider: ScatterChartDataProvider?
    
//    // MARK: - Initializers
    override func initialize() {
    
        guard let chart = chart
            else { return }
        
        chart.xAxis.enabled = false
    }

    // MARK: - Data Updation Calculation
   open override func notifyDataSetChanged(redrawRequired: Bool)
   {
       guard  let chart = chart,
           let data = chart.data
           else {
               return
       }
       
       if chart._legend !== nil
       {
           chart._legendRenderer.computeLegend(data: data)
       }
       
       calculateOffsets()
       
       chart.setNeedsDisplay()
   }
    
     /////====================== ****************************** ====================== /////
    
    
    // MARK: - Touch Events
/*
    @objc fileprivate func tapEventRecognized(_ recognizer: TapEventListener)
    {
        if isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        
        if recognizer.state == NSUIGestureRecognizerState.ended
        {
            let location = recognizer.location(in: self)
            
            tapHighlight(location: location, recognizer )
        }
        
    }
    
    @objc fileprivate func longPressEventRecognized(_ recognizer: LongPressEventListener)
    {
        if isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        
        if recognizer.state == .began
        {
            ChartUtils.longPressSound()
        }
        
         let location = recognizer.location(in: self)
        
         tapHighlight(location: location, recognizer: recognizer, eventHandler: recognizer.handler)
    }
    
    @objc fileprivate func panEventRecognized(_ recognizer: PanEventListener)
    {
        if self.isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        
        let location = recognizer.location(in: self)
        
        var entry:ChartDataEntry? = nil
        
        let _ = self.getHighlightByTouchPoint(location)
        
        var funnelLayer:FunnelLayer? = nil
        
        funnelLayer = FunnelLayer.getFunnelLayerInPoint(chart: self, loc: location)
        
        if funnelLayer != nil
        {
            //            entry = _data?.entryForHighlight(high!)
            entry = funnelLayer?.getFunnelChartEntry()
        }
        
        recognizer.handler?.execute(self, entry: entry, entryLayer: funnelLayer, recognizer, location)
        
        if chartActionListener != nil
        {
//            chartActionListener?.tapEventCalled?(chartView: self, selectedEntry: entry, selectedLayer: funnelLayer)
        }
        
    }*/
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Gesture Handled
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint) -> (entry: ChartDataEntry?, layer: ChartEntryLayer?) {
        
        guard let chart = chart
            else { return (nil,nil) }
        
        /*var handler:EventHandler?
        
        if recognizer.isKind(of: TapEventListener.self)
        {
            handler = (recognizer as? TapEventListener)?.handler
        }
        else if recognizer.isKind(of: PanEventListener.self)
        {
            handler = (recognizer as? PanEventListener)?.handler
        }
        else if recognizer.isKind(of: LongPressEventListener.self)
        {
            handler = (recognizer as? LongPressEventListener)?.handler
        }*/
        
        return FunnelHelperFunctions.tapHighlight(location: location, recognizer: recognizer, chart: chart)
    }
    
  
    
    
    /////====================== ****************************** ====================== /////
    
    
    // MARK: - Protocol Implementations
    
    /// Tooltip tapped
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
        guard let chart = chart,
              let sets = chart.data?.dataSets
            else { return }
        
        var nextIndex = -1
        
        if entry == nil
        {
            nextIndex = 0
        }
        else
        {
            guard let curIndex = chart.data?.dataSets[0].entryIndex(entry: entry!)
            else { return }
            
            nextIndex = (curIndex + 1) % (sets[0].entryCount)
            
        }
        
        guard var nextEntry = chart.data?.dataSets[0].entryForIndex(nextIndex)
        else { return }
        
        while !((nextEntry.enabled)) || (nextEntry.y.isNaN)
        {
            nextIndex = (nextIndex + 1) % (sets[0].entryCount)
            
            nextEntry = chart.data?.dataSets[0].entryForIndex(nextIndex) ?? nextEntry
        }
        
        FunnelHelperFunctions.highlightFunnelLayerForEntry(entry: nextEntry, funnelChart: chart)
        
    }
    
    /// Legend tapped
    public override func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard let chart = chart,
            let dataset = (chart.data?.dataSets[0]) as? ChartDataSet
        else { return }
        
        let index = indexPath.item
        
        Log.info("Legend Disabled \(index)")
        
        guard let removeEntry:ChartDataEntry = dataset.entryForIndex(index)
            else { return }

        FunnelHelperFunctions.removeEntries(entries: [removeEntry], chart: chart, duration: 2)
    }
        
        
    /// Legend tapped
    public override func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard let chart = chart,
            let dataSet = (chart.data?.dataSets[0]) as? ChartDataSet
        else { return }
        
        let index = indexPath.item
        
        guard let entryToInclude = dataSet.entryForIndex(index)
        else { return }
        
        FunnelHelperFunctions.includeEntries(entries: [entryToInclude], chart: chart, duration: 2)
    }
        
    

    
    override func calculateOffsets() {
        
        guard  let chart = chart,
            let plotOptions = chart.getPlotOptions(type: .Funnel) as? FunnelPlotOptions
        else {
                return
        }
        
        /*     _viewPortHandler.restrainViewPort(
         offsetLeft: max(self.minOffset, offsetLeft),
         offsetTop: max(self.minOffset, offsetTop),
         offsetRight: max(self.minOffset, offsetRight),
         offsetBottom: max(self.minOffset, offsetBottom)) */
        
        let outerPadding = plotOptions.outerPadding
        
        chart._viewPortHandler.restrainViewPort(
            offsetLeft: outerPadding + chart.extraLeftOffset,
            offsetTop: outerPadding + chart.extraTopOffset,
            offsetRight: outerPadding + chart.extraRightOffset,
            offsetBottom: outerPadding + chart.extraBottomOffset)
        
    }
    
    fileprivate func prepareShapeSize()
    {
        guard  let chart = chart ,
            let scatterData = chart.data,
            let plotOptions = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions,
            let viewPortHandler = chart.viewPortHandler
            else {
                return
        }

        let maxSize = plotOptions.maximumShapeSizeInPixel
        
        let minSize = plotOptions.minimumShapeSizeInPixel
        
        //Backup of scaleValues
        let lastScaleX = viewPortHandler._touchMatrix.a
        
        // To reset scaleX Value
        viewPortHandler._touchMatrix.a = 1
        
        chart.prepareValuePxMatrix()
        
        chart.updatePadding()
        
        var currentOnePointWidth = CommonHelperFunctions.getOnePointWidth(chart: chart)
        
        if chart.xAxis.scaleType != .Ordinal
        {
            currentOnePointWidth =  CommonHelperFunctions.getMaxWidthBetweenEntriesAcrossAllVisibleData(barLine: chart)
        }
        
        // Reset Scale Value
        viewPortHandler._touchMatrix.a = lastScaleX
        
        chart.prepareValuePxMatrix()
        
        chart.updatePadding()
        
        let scatterSize = ((currentOnePointWidth >= minSize) && (currentOnePointWidth <= maxSize))
            ?   currentOnePointWidth
            : ((currentOnePointWidth > maxSize) ? maxSize : minSize)
        
        for set in (scatterData.dataSets) where set.plotType == .Scatter
        {
            guard let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
            else { continue }
            let shapeProperties = dataOption.shapeProperties
            shapeProperties.size = CGSize(width: scatterSize, height: scatterSize)
        }
        
    }
    
    func calculateOnDataSetChanged()
    {
        guard  let chart = chart
            else {
                return
        }
        
        let scaleValue:CGFloat = 1
        
        /* //Backup of scaleValues
         let lastScaleX = viewPortHandler._touchMatrix.a
         
         // To reset scaleX Value
         viewPortHandler._touchMatrix.a = 1
         
         let currentWidth = getCurrentWidthAfterPadding(padding: CGFloat(((scatterData.xMax) - (scatterData.xMin))/Double((scatterData.maxEntryCountSet?.entryCount)!)))
         
         // Padding
         if currentWidth > scatterData.interSpace
         {
         var padding:CGFloat = 0
         
         var currentWidth:CGFloat = 0
         
         // trail and error checking for padding value to get bar width close to maxwidth
         repeat
         {
         padding += 1
         
         currentWidth = getCurrentWidthAfterPadding(padding: padding)
         }
         while(currentWidth > scatterData.interSpace)
         
         
         padding = getPaddingValueBinarySearch(padding: padding-1,expectedWidth: scatterData.interSpace)
         
         currentWidth = getCurrentWidthAfterPadding(padding: padding)
         
         }
         else if currentWidth == 0
         {
         _ = getCurrentWidthAfterPadding(padding: 0.5)
         }
         else{
         // Current view width
         var viewSize:CGFloat
         
         viewSize = viewPortHandler.contentRect.width
         
         let neededLabelCount = viewSize/scatterData.interSpace
         
         scaleValue = CGFloat((chart.data?.maxEntryCountSet?.entryCount)!) / neededLabelCount
         
         if lastScaleX > scaleValue && chart.scaleXEnabled
         {
         viewPortHandler._touchMatrix.a = lastScaleX
         }
         }*/
        
        chart.setScaleMinima(scaleValue, scaleY: 1)
        
    }
    
}
