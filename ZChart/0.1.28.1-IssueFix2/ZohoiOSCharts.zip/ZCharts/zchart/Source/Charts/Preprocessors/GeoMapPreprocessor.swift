//
//  GeoMapPreprocessor.swift
//  zchart
//
//  Created by Aravinth T on 26/11/21.
//

import Foundation
import JavaScriptCore

open class GeoMapPreprocessor:ChartPreprocessor
{
    var jsContext: JSContext!
    
    var geoJSONString:String = ""
    
    var backgroundPathString:String? = nil
    
    var featureCollection:NSDictionary = [:]
    
    var featureMap:[String:NSDictionary] = [:]
        
    var featurePathStringMap:[String:String] = [:]
    
    var backgroundPath:SVGPath? = nil
    
    var featurePath:[String:SVGPath] = [:]
    
    var featureKeys:Set<String> = []
    
    override func initialize() {
        super.initialize()
        
        chart?.xAxis.enabled  = false
        
        initializeJS()
        
        JSGarbageCollect(self.jsContext.jsGlobalContextRef)
    }
    
    func initializeJS() {
        
        self.jsContext = JSContext()
        
        // Add an exception handler.
        self.jsContext.exceptionHandler = { context, exception in
            if let exc = exception {
                print("JS Exception:", exc.toString() ?? "null")
            }
        }
    
        let bundle = Bundle(for: ChartViewBase.self)
    
//        if let d3MinPath = bundle.path(forResource: "d3.min", ofType: "js") {
     /*   if let d3MinPath = bundle.path(forResource: "d3.v7.min", ofType: "js") {
           do {
                   // Load its contents to a String variable.
                   let jsSourceContents = try String(contentsOfFile: d3MinPath)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
               print(error.localizedDescription)
            }
        }*/
        
        if let d3Array = bundle.path(forResource: "d3-array.min", ofType: "js") {
           do {
                   // Load its contents to a String variable.
                   let jsSourceContents = try String(contentsOfFile: d3Array)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
               print(error.localizedDescription)
            }
        }
        
        if let d3GeoProjection = bundle.path(forResource: "d3-geo-projection.min", ofType: "js") {
           do {
                   // Load its contents to a String variable.
                   let jsSourceContents = try String(contentsOfFile: d3GeoProjection)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
               print(error.localizedDescription)
            }
        }
        
        if let d3GeoPath = bundle.path(forResource: "d3-geo.min", ofType: "js") {
           do {
                   // Load its contents to a String variable.
                   let jsSourceContents = try String(contentsOfFile: d3GeoPath)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
               print(error.localizedDescription)
            }
        }
        
        if let topoJSONMinPath = bundle.path(forResource: "topojson-client.min", ofType: "js") {
           do {
                   // Load its contents to a String variable.
                   let jsSourceContents = try String(contentsOfFile: topoJSONMinPath)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents)
            }
            catch {
               print(error.localizedDescription)
            }
        }
        
        if let jsSourcePath1 = bundle.path(forResource: "geoMap", ofType: "js") {
            do {
                   // Load its contents to a String variable.
                   let jsSourceContents1 = try String(contentsOfFile: jsSourcePath1)
        
                   // Add the Javascript code that currently exists in the jsSourceContents to the Javascript Runtime through the jsContext object.
                   self.jsContext.evaluateScript(jsSourceContents1)
               }
               catch {
                   print(error.localizedDescription)
               }
        }
    }
    
    override open func notifyDataSetChanged(redrawRequired: Bool) {
    
        guard let chart = chart,
            let data = chart.data
        else { return }
        
        if  chart._legend !== nil
        {
            if chart.colorAxis.isEnabled {
                if chart.legend.legendRange.Minimum == chart.legend.legendRange.Maximum
                {
                    chart.colorAxis.calcMinMax(data: data)
                }
            }else {
                chart._legendRenderer.computeLegend(data: data)
            }
        }
        
        copyGeoJSONData()
        
        calculateOffsets()
        
        chart.prepareValuePxMatrixForPlot()
        
        prepareGeoData(chart: chart)
        
        if redrawRequired
        {
            chart.setNeedsDisplay()
        }

    }
    
    fileprivate func copyGeoJSONData()
    {
        guard  let chart = chart,
            let plotOptions = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions,
               !plotOptions.scope.isEmpty
        else {
                return
        }
     
        let geoJSONFileName = plotOptions.scope
        
        let fileType = "json"
        
        let fileExtension = "."+fileType
        
        let fileManager = FileManager.default
       
        guard let sourceURL = Bundle.main.path(forResource: geoJSONFileName, ofType: fileType)
        else { return }
       
        let destPath = Bundle(for: ChartViewBase.self).bundlePath+"/"+geoJSONFileName+fileExtension
       
        if !fileManager.fileExists(atPath: destPath) {
           do  {
               try fileManager.copyItem(atPath: sourceURL, toPath: destPath) }
           catch {
               print("Error in copying ")
           }
        }
    }
    
    override func calculateOffsets() {
        
        guard  let chart = chart,
            let plotOptions = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
        else {
                return
        }
        
        let outerPadding:CGFloat = plotOptions.outerPadding
        
        chart._viewPortHandler.restrainViewPort(
            offsetLeft: outerPadding,
            offsetTop: outerPadding,
            offsetRight: outerPadding,
            offsetBottom: outerPadding)
        
    }
    
    fileprivate func loadFeaturePathStringMap() {
        
        featurePathStringMap.removeAll()
        featurePath.removeAll()
        
        for  key in featureMap.keys {
            
            if let feature = featureMap[key] {
                
                if let pathString = getSVGPathString(data: feature) {
                    featurePathStringMap[key] = pathString
                    let svgPath = SVGPath(pathString)
                    featurePath[key] = svgPath
                }
                
            }
            
        }
    }
    
    func prepareGeoData(chart:ChartViewBase) {
        
        guard let plotOptions = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
        else {
            return
        }
        
        if let jsonString = readGeoDataJSON()
        {
            geoJSONString = jsonString
            
            let newJSONString = excludeFeatures(plotOptions: plotOptions, chart: chart)
            
            featureCollection =  getFeatureCollection(topoJSON: newJSONString)
            
            initGeoLayout(data: featureCollection, rect: chart.viewPortHandler.contentRect, plotOption: plotOptions)
            
            /*backgroundPathString = getSVGPathString(data: featureCollection)
            
            if backgroundPathString == nil{
                return
            }
            
            backgroundPath = SVGPath(backgroundPathString!)*/
            
            loadFeatureMap(chart: chart, plotOptions: plotOptions)
            
            loadFeaturePathStringMap()
        }
    }
    
    fileprivate func updateExcludeKeys(chart:ChartViewBase, excludeKeys: inout [String])
    {
        guard let plotOptions = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
        else {
            return
        }
        
        if plotOptions.allAreas {
            return
        }
        
        let geoJSONKeys = getGeoJSONKeys(chart: chart)
        
        var dataKeys:[String:String] = [:]
        
        if let datasets = chart.data?.getDataSetForPlotType(plotType: ChartType.GeoHeatMap)
        {
            for dataset in datasets where dataset.isVisible {
                
                for i in stride(from: 0, to: dataset.entryCount, by: 1)
                {
                    guard let entry = dataset.entryForIndex(i),
                            entry.enabled else {
                        continue
                    }
                    
                    guard let key = GeoMapPreprocessor.getKey(entry: entry, plotOptions: plotOptions) else
                    {
                        continue
                    }
                    
                    dataKeys[key] = key
                }
                                
            }
        }
        
        for key in geoJSONKeys
        {
            if (dataKeys[key] == nil && !excludeKeys.contains(key))
            {
                excludeKeys.append(key)
            }
        }
        
    }
    
    fileprivate func getGeoJSONKeys(chart:ChartViewBase) -> [String]
    {
        var keyMap:[String] = []
        guard let plotOptions = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
        else {
            return keyMap
        }
        
        if let rootObject = getRootJSONObject(geoJSONString: geoJSONString) {
            
            if let geometryArray = getJSONGeometryArray(rootObject: rootObject)
            {
                for i in stride(from: 0, to: geometryArray.count, by: 1)
                {
                    guard let geometry = geometryArray[i] as? NSDictionary
                    else { continue }
                    if let key = getKey(feature: geometry, plotOptions: plotOptions)
                    {
                        keyMap.append(key)
                    }
                }
            }
        }
        return keyMap
    }
    
    fileprivate func getProjectionName(plotOption:GeoMapPlotOptions) -> String {
        
        if let projectionName = plotOption.projection {
            return projectionName
        }
        
        var projectionName:String = "geoMercator"
        
        if let rootObject = getRootJSONObject(geoJSONString: geoJSONString) {
            
            if rootObject["projection"] != nil,
            let objectJSON = rootObject["projection"] as? [String:AnyObject]
            {
                projectionName = (objectJSON["name"] as? String) ?? ""
            }
        }
        
        return projectionName
    }
    
    fileprivate func excludeFeatures(plotOptions:GeoMapPlotOptions, chart:ChartViewBase) -> String
    {
        var excludeKeys = prepareExcludeKeys(plotOptions: plotOptions)
        updateExcludeKeys(chart: chart, excludeKeys: &excludeKeys)
        
        if excludeKeys.isEmpty
        {
            return geoJSONString
        }
        
        if var rootObject = getRootJSONObject(geoJSONString: geoJSONString) {
            
            if var geometryArray = getJSONGeometryArray(rootObject: rootObject)
            {
             
                for excludeKey in excludeKeys {
                    
                    var removedIndex:Int = -1
                    
                    for i in stride(from: 0, to: geometryArray.count, by: 1)
                    {
                        guard let geometry = geometryArray[i] as? NSDictionary
                        else { continue }
                        
                        if let key = getKey(feature: geometry, plotOptions: plotOptions)
                        {
                            if excludeKey == key {
                                removedIndex = i
                                break
                            }
                        }
                    }
                    if removedIndex != -1 {
                        geometryArray.remove(at: removedIndex)
                    }
                }
                
                rootObject = updateRootJSONGeometryArray(rootObject: rootObject, geometryArray: geometryArray)
            }
            
            
            
            if let jsonString = jsonToString(jsonTOConvert: rootObject) {
                return jsonString
            }
            
        }
        
        return geoJSONString
    }
    
    fileprivate func getJSONGeometryArray(rootObject:[String:AnyObject]) -> [AnyObject]?
    {
        
        if (rootObject["objects"] == nil) {
            return nil
        }
        
        guard let objectJSON = rootObject["objects"] as? [String:AnyObject]
        else { return nil }
        
        if (objectJSON["source"] == nil) {
            return nil
        }
        
        guard let sourceJSON = objectJSON["source"] as? [String:AnyObject]
        else { return nil }
                
        
        if (sourceJSON["geometries"] == nil) {
            return nil
        }
        
        return sourceJSON["geometries"] as? [AnyObject]
    }
    
    fileprivate func updateRootJSONGeometryArray(rootObject:[String:AnyObject], geometryArray:[AnyObject]) -> [String:AnyObject]
    {
        var rootObject = rootObject
        
        if (rootObject["objects"] == nil) {
            return rootObject
        }
        
        guard var objectJSON = rootObject["objects"] as? [String:AnyObject]
        else { return rootObject }
        
        if (objectJSON["source"] == nil) {
            return rootObject
        }
        
        guard var sourceJSON = objectJSON["source"] as? [String:AnyObject]
        else { return rootObject }
                        
        if (sourceJSON["geometries"] == nil) {
            return rootObject
        }
        
        sourceJSON["geometries"] = geometryArray as AnyObject
        objectJSON["source"] = sourceJSON as AnyObject
        rootObject["objects"] = objectJSON as AnyObject
        return rootObject
                
    }
    
    fileprivate func getRootJSONObject(geoJSONString:String?) -> [String: AnyObject]?  {
        
        guard let content = geoJSONString else {
            return nil
        }
        
        if let jsonData = content.data(using: String.Encoding.utf8)
        {
            do {
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    return jsonDict
                }
            }
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return nil
    }
    
    
    fileprivate func jsonToString(jsonTOConvert: Any) -> String? {
          do {
              let data =  try JSONSerialization.data(withJSONObject: jsonTOConvert, options: JSONSerialization.WritingOptions.prettyPrinted)
              let convertedString = String(data: data, encoding: String.Encoding.utf8)
              return convertedString
          } catch let myJSONError {
              print(myJSONError)
          }
        return nil
    }
    
    fileprivate func prepareExcludeKeys(plotOptions:GeoMapPlotOptions) -> [String] {
        var excludeKeys:[String] = []
        
        let excludeAreas = plotOptions.excludeAreas
        
        if (excludeAreas.isEmpty)
        {
            return excludeKeys
        }
        
        for excludeArea in excludeAreas {
            
            var excludeKey:String? = nil
            
            if plotOptions.mapKey == .LATLONG || plotOptions.mapKey == .LONGLAT
            {
                guard let doubleList = excludeArea as? [Double]
                else { continue }
                
                excludeKey = String(doubleList[0])+"-"+String(doubleList[1])
            }
            else
            {
                excludeKey = excludeArea as? String
            }
            
            
            if excludeKey != nil {
                excludeKeys.append(excludeKey!)
            }
                        
        }
        
        return excludeKeys
    }
    
    func loadFeatureMap(chart: ChartViewBase, plotOptions:GeoMapPlotOptions) {
        
        featureMap.removeAll()
        
        guard let features = featureCollection["features"] as? NSArray
        else { return }
        
        for featureObj in features {
            guard let feature = featureObj as? NSDictionary
            else { continue }
            if let key = getKey(feature: feature, plotOptions: plotOptions) {
                featureMap[key] = feature
                featureKeys.insert(key)
            }
        }
        
    }
    
    func getKey(feature: NSDictionary, plotOptions:GeoMapPlotOptions) -> String? {
        
        guard let propertiesObj = feature["properties"] as? NSDictionary
        else { return nil }
        
        let keyString = plotOptions.mapKey.rawValue
        
        var key:String? = nil
        
        if (plotOptions.mapKey == .LATLONG || plotOptions.mapKey == .LONGLAT)
        {
            guard let latitude = propertiesObj["latitute"] as? String,
                    let longitude = propertiesObj["longitude"] as? String
            else { return nil}
            
            key = plotOptions.mapKey == .LATLONG ? latitude+"-"+longitude : longitude+"-"+latitude
        }
        else
        {
            key = propertiesObj[keyString] as? String
        }
                
        return key
    }
    
    static func getKey(entry:ChartDataEntry, plotOptions:GeoMapPlotOptions) -> String? {
        
        var key:String? = nil
        
        if (plotOptions.mapKey == .LATLONG || plotOptions.mapKey == .LONGLAT)
        {
            key = String(entry.x)+"-"+String(entry.y)
        }
        else
        {
            key = entry.xString
        }
                
        return key
    }
    
    
    func readGeoDataJSON() -> String? {
        guard let chart = chart,
              let geoPlotOption = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
        else {
            return nil
        }
        
        let bundle = Bundle(for: ChartViewBase.self)
        
        
        //world-india.json//countries-ind-1.json
        let fileName =  geoPlotOption.scope//  "countries-ind-1" //"world-india"
        let fileExtension = "json"
        
        if let jsSourcePath1 = bundle.path(forResource: fileName, ofType: fileExtension) {
            do {
                   let jsSourceContents1 = try String(contentsOfFile: jsSourcePath1)
                        
                   return jsSourceContents1
               }
               catch {
                   print(error.localizedDescription)
               }
        }
        return nil
    }
    
    func initGeoLayout(data:NSDictionary, rect:CGRect, plotOption:GeoMapPlotOptions)  {
        let x = rect.origin.x
        let y = rect.origin.y
        let height =  rect.size.height
        let width = rect.size.width
        let projection = getProjectionName(plotOption: plotOption)
        if let initGeoObject = self.jsContext.objectForKeyedSubscript("initGeoObject")
        {
           if let results = initGeoObject.call(withArguments: [data,x,y, width, height, projection])
           {
               Log.info("Initial Bound \(String(describing: results.toString()))")
            }
        }
    }
    
    func getFeatureCollection(topoJSON:String?) -> NSDictionary {
        
        var dict:NSDictionary = [:]
        
        guard let jsonData = topoJSON else {
            return dict
        }
       
        if let featuresDataMethod = self.jsContext.objectForKeyedSubscript("getFeatures")
        {
           if let results = featuresDataMethod.call(withArguments: [jsonData])
           {
               let obj = results.toObject() as AnyObject
               
               dict = (obj as? NSDictionary) ?? dict
            }
        }
        
        return dict
    }
    
    func getSVGPathString(data:NSDictionary) -> String? {
        
        if let getSVGPath = self.jsContext.objectForKeyedSubscript("getSVGPath")
        {
           if let results = getSVGPath.call(withArguments: [data])
           {
               return results.toString()
           }
        }
        return nil
    }
    
    public func isPointInFeature(data:NSDictionary, coordinates:[Double]) -> Bool {
        
        if let getSVGPath = self.jsContext.objectForKeyedSubscript("geoContains")
        {
           if let results = getSVGPath.call(withArguments: [data, coordinates])
           {
               return results.toBool()
           }
        }
        return false
    }
    
    public func getGeoCoordinates(x:CGFloat, y:CGFloat) -> [Double]? {
        
        if let getSVGPath = self.jsContext.objectForKeyedSubscript("getGeoPoint")
        {
           if let results = getSVGPath.call(withArguments: [x,y])
           {
               return results.toArray() as? [Double]
           }
        }
        return nil
    }

    public func getProjectionPoint(x:CGFloat, y:CGFloat) -> [CGFloat]? {
        
        if let getSVGPath = self.jsContext.objectForKeyedSubscript("getPoint")
        {
           if let results = getSVGPath.call(withArguments: [x,y])
           {
               return results.toArray() as? [CGFloat]
           }
        }
        return nil
    }
    
    public static func parseSVGPath(pathString:String) -> CGPath
    {
        let svgPathObj = SVGPath(pathString)
        
        return getCGPath(svgPathObj: svgPathObj)
    }
            
    
    static func getCGPath(svgPathObj:SVGPath) -> CGPath {
                        
        let finalPath = CGMutablePath()
        
        var pathArray:[CGMutablePath] = []
        var path = CGMutablePath()
        
        
        for command in svgPathObj.commands {
            
            if (command.type == SVGCommand.Kind.move)
            {
                path = CGMutablePath()
                path.move(to:  command.point)
            }
            else if (command.type == SVGCommand.Kind.line)
            {
                path.addLine(to: command.point)
            }
            else if (command.type == SVGCommand.Kind.cubeCurve)
            {
                path.addCurve(to: command.point, control1: command.control1, control2: command.control2)
            }
            else if (command.type == SVGCommand.Kind.close)
            {
                path.closeSubpath()
                pathArray.append(path)
            }
        }
        
        for tempPath in pathArray {
            finalPath.addPath(tempPath)
        }
        
        return finalPath
        
    }
    
    public static func parseSVGPath(pathString:String, transformer:Transformer) -> CGPath?
    {
        let svgPathObj = SVGPath(pathString)
        
        return getCGPath(svgPathObj: svgPathObj, transformer: transformer)
    }
    
    static func getCGPath(svgPathObj:SVGPath, transformer:Transformer) -> CGPath? {
                        
        let finalPath = CGMutablePath()
        
        var pathArray:[CGMutablePath] = []
        var path = CGMutablePath()
        
        for command in svgPathObj.commands {
            
            if (command.type == SVGCommand.Kind.move)
            {
                path = CGMutablePath()
                path.move(to: getTransformerPoint(point: command.point, transformer: transformer))
            }
            else if (command.type == SVGCommand.Kind.line)
            {
                path.addLine(to: getTransformerPoint(point: command.point, transformer: transformer))
            }
            else if (command.type == SVGCommand.Kind.cubeCurve)
            {
                path.addCurve(to: getTransformerPoint(point: command.point, transformer: transformer), control1: getTransformerPoint(point: command.control1, transformer: transformer), control2: getTransformerPoint(point: command.control2, transformer: transformer))
            }
            else if (command.type == SVGCommand.Kind.close)
            {
                path.closeSubpath()
                pathArray.append(path)
            }
        }
                
        for tempPath in pathArray {
            finalPath.addPath(tempPath)
        }
        
        return finalPath
        
    }
    
//    static func getTransformerPoint(point:CGPoint, transformer:Transformer) -> CGPoint? {
//            var newPoint = CGPoint(x: point.x, y: point.y)
//            transformer.pointValueToPixel(&newPoint)
//            return transformer._viewPortHandler.contentRect.contains(newPoint) ?  newPoint : nil
//    }
    
    static func getTransformerPoint(point:CGPoint, transformer:Transformer) -> CGPoint {
        var newPoint = CGPoint(x: point.x, y: point.y)
        transformer.pointValueToPixel(&newPoint)
        return newPoint
    }
    
    /// Legend range adjusted
    open override func legendRangeSelected(minimum: Double, maximum: Double) {
        
        guard let chart = chart
        else { return  }
        
        super.legendRangeSelected(minimum: minimum, maximum: maximum)
        
        chart.lastSelected = nil
        
        GeoMapHelperFunctions.highLightMapEntry(chart: chart, entry: nil)
        
    }
    
    public override func tooltipSelected(entry: ChartDataEntry?) {
        
        guard let _ = chart
            else { return }
        
    }
    
}
