//
//  WaterFallPreprocessor.swift
//  zchart
//
//  Created by keerthi-pt4274 on 24/06/22.
//

import Foundation

open class WaterFallPreprocessor: BarPreprocessor {
    
    open var cascadeIndex = Set<Int>()
    
    open override func updateEntriesStackValue() {
        
        super.updateEntriesStackValue()
        
        guard let chart = chart,
              let data = chart.data,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.WaterFall]) as? WaterFallPlotOptions
            else {
                return
            }
        
        var posY:[Double:Double] = [:]
        
        var negY:[Double:Double] = [:]
        
        var baseValues:[Double:Double] = [:]
        
        var posSum:[Double:[Int:Double]] = [:]
        var negSum:[Double:[Int:Double]] = [:]
        
        var maxY = -(Double.greatestFiniteMagnitude)
        var minY = (Double.greatestFiniteMagnitude)
        
        cascadeIndex.removeAll()
        
        for setIndex in 0..<data.dataSets.count {
            
            let dataset = data.dataSets[setIndex]
            
            if !(dataset.plotType == .WaterFall) || !dataset.isVisible
            {
                continue
            }
            
            var currentSum = 0.0
            
            var currentBaseValue = 0.0
            
            for entryIndex in 0..<dataset.entryCount {
                
                guard let entry = dataset.entryForIndex(entryIndex) else {
                    continue
                }
                
                var entryYValue = entry.y.isNaN ? 0.0 : entry.y
                
                var currentYValue = entryYValue
                
                var baseValue = 0.0
                
                let isCascade = (entry.plotData as? Int) != nil && (entry.plotData as! Int) == 1
                
                if entry.x.isNaN
                {
                    currentBaseValue = 0
                    continue
                }
                
                guard let dataXString = data.xString?[0]
                else { continue }
                
                if entry.xString != dataXString {
                    
                    if (posSum[entry.x] == nil || negSum[entry.x] == nil) && !isCascade {
                    
                        var prevEntry = dataset.entryForIndex(entryIndex - 1)
                    
                        var counterIndex = entryIndex - 1

                        while prevEntry != nil && (prevEntry?.x.isNaN)!
                        {
                            counterIndex -= 1
                            prevEntry = dataset.entryForIndex(counterIndex)
                        }
                    
                        if prevEntry != nil {
                            
                            var prevEntryX: Double = prevEntry!.x
                            
                            if plotOption.isStacked {
                                guard let xStringEntry = entry.xString,
                                    let indexOfXstring = (data.xString?.firstIndex(of: xStringEntry))
                                else { continue }
                                prevEntryX = Double(indexOfXstring - 1)
                            }
                            
                            var val = 0.0
                            
                            if let positiveVal = positiveSum[Double(prevEntryX)] {
                                val = max(val, positiveVal)
                            }
                            
                            if let negativeVal = negativeSum[Double(prevEntryX)]{
                                val = max(val, negativeVal)
                                
                                if negativeVal == val {
                                    val = -val
                                }
                            }
                            
                            baseValue = currentBaseValue + val
                            currentBaseValue = baseValue
                        }
                        
                        if baseValues[entry.x] != nil && plotOption.isStacked {
                            baseValue = baseValues[entry.x]!
                        }
                        else{
                            baseValues[entry.x] = currentBaseValue
                        }
                    }
                    
                    if isCascade {
                        
                        baseValue = 0.0
                        
                        if entry.y == 0 || entry.y.isNaN || (entry.origY != nil && entry.origY == 0) {
                            
                            entry.origY = 0
                            
                            entryYValue = 0
                            
                            currentYValue = currentSum
                            entry.y = currentSum
                        }
                        
                        currentBaseValue = 0
                        baseValues[entry.x] = currentBaseValue
                        
                        cascadeIndex.insert(entryIndex)
                    }
                    
                    if currentYValue.isNaN {
                        if entriesStackedYValue[setIndex] == nil {
                            entriesStackedYValue[setIndex] = [entryIndex:currentBaseValue]
                        }
                        else{
                            entriesStackedYValue[setIndex]![entryIndex] = currentBaseValue
                        }
                        continue
                    }
                    
                    if currentYValue >= 0
                    {
                        if posSum[entry.x] == nil
                        {
                            
                            let yVal = baseValue + currentYValue
                            
                            
                            posSum[entry.x] = [setIndex:yVal]
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yVal
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yVal]
                            }
                            
                            posY[entry.x] = yVal
                        }
                        else{
                            
                            let  lastPositiveDataSetIndexSoFar = posSum[entry.x]?.keys.max()
                            
                            let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + currentYValue
                            
                            posSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            posY[entry.x] = yValue
                            
                        }
                        
                    }
                    else {
                        
                        if negSum[entry.x] == nil
                        {
                            
                            let yVal = baseValue + currentYValue
                            
                            negSum[entry.x] = [setIndex:yVal]
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yVal
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yVal]
                            }
                            
                            negY[entry.x] = yVal
                            
                        }
                        else{
                            
                            let  lastNegativeDataSetIndexSoFar = negSum[entry.x]?.keys.max()
                            
                            let negSumVal = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]!
                            
                            let yValue = negSumVal + currentYValue
                            
                            negSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            negY[entry.x] = yValue
                        }
                    }
                    
                }
                else{
                    
                    if isCascade {
                        cascadeIndex.insert(0)
                    }

                    if positiveSum[entry.x] != nil {
                        posY[entry.x] = positiveSum[entry.x]
                    }

                    if negativeSum[entry.x] != nil {
                        negY[entry.x] = negativeSum[entry.x]!
                    }
                    
                }
                
                currentSum += entryYValue

                // Min & Max
                
                if let val = entriesStackedYValue[setIndex]![entryIndex] {
                    if val > 0 && val > maxY
                    {
                        maxY = val
                    }
                
                    if val < 0 && val < minY
                    {
                        minY = val
                    }
                }
            }
            
        }
        
        positiveSum = posY
        negativeSum = negY
        
        minY = (minY == Double.greatestFiniteMagnitude) ?  0 : minY
        maxY = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        
        data._yAxisMinArray[data.dataSets[0].axisIndex] = minY
       
        data._yAxisMaxArray[data.dataSets[0].axisIndex] = maxY
       
        data._yMin = minY
        
        data._yMax = maxY
    }
    
    internal func getBaseValue(basevalue: Double, dataset: IChartDataSet, datasetIndex: Int, entryIndex: Int) -> Double {
        
        var prevBasevalue = basevalue
        
        let prevEntryIndex = CommonHelperFunctions.getPrevEntryIndex(dataset: dataset, entryIndex: entryIndex)
        
        if cascadeIndex.contains(Int(entryIndex)) {
            prevBasevalue = 0.0
        }
        else {
            if let prevYValue = entriesStackedYValue[datasetIndex]?[prevEntryIndex] {
                prevBasevalue = prevYValue
            }
        }
        
        return prevBasevalue
    }
    
    open override func calcPosNegSum()
    {
        updateEntriesStackValue()
    }
    
    open override func animatorUpdated(_ chartAnimator: Animator)
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.WaterFall]) as? WaterFallPlotOptions
           else { return }
        
        super.animatorUpdated(chartAnimator)
        
        if plotOption.connectorEnabled {
            plotOption.isConnectorEnabled = false
        }
        
    }
    
    open override func animatorStopped(_ chartAnimator: Animator)
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.WaterFall]) as? WaterFallPlotOptions
        else { return }
        
        super.animatorStopped(chartAnimator)
        
        if plotOption.connectorEnabled {
            plotOption.isConnectorEnabled = true
        }
    }
}
