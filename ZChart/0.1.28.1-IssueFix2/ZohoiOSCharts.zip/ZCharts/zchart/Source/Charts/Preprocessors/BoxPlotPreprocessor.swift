//
//  BoxPlotPreprocessor.swift
//  zchart
//
//  Created by keerthi-pt4274 on 04/08/22.
//

import Foundation

open class BoxPlotPreprocessor: BarPreprocessor {
    
    override open func updateEntriesStackValue() {
        
        super.updateEntriesStackValue()
        
        updateMinMaxBasedOnWhiskers()
        
    }
}
