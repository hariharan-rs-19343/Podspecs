//
//  PieRadarPreprocessor.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 10/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation


open class PieRadarPreprocessor:ChartPreprocessor
{
    open override func notifyDataSetChanged(redrawRequired:Bool)
    {
        guard  let chart = chart,
            let data = chart.data
            else {
                return
        }
        
        chart.maxVisibleCount = data.entryCount ?? 0
        
        calcMinMax()
               
        if  chart._legend !== nil
        {
            if chart.colorAxis.isEnabled {
                if chart.legend.legendRange.Minimum == chart.legend.legendRange.Maximum
                {
                    chart.colorAxis.calcMinMax(data: data)
                }
            }else {
                chart._legendRenderer.computeLegend(data: data)
            }
        }
       
        calculateOffsets()
       
        if redrawRequired
        {
            chart.setNeedsDisplay()
        }
    }
    
    open override func calcMinMax()
    {
       /*_xAxis.axisRange = Double((_data?.xVals.count ?? 0) - 1)*/
    }
    
    /// Calculates the offsets of the chart to the border depending on the position of an eventual legend or depending on the length of the y-axis and x-axis labels and their position
    internal override func calculateOffsets()
    {
        guard  let chart = chart,
            let piePlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Pie, .Dial, .Radar]) as? PiePlotOptions
            else {
                return
        }
        
        
        var legendLeft = CGFloat(0.0)
        var legendRight = CGFloat(0.0)
        var legendBottom = CGFloat(0.0)
        var legendTop = CGFloat(0.0)
        
        if chart._legend != nil && chart._legend.enabled && !(chart._legend.drawInside)
        {
            let fullLegendWidth = min(chart._legend.neededWidth, chart._viewPortHandler.chartWidth * chart._legend.maxSizePercent)
            
            switch chart._legend.orientation
            {
            case .vertical:
                
                var xLegendOffset: CGFloat = 0.0
                
                if chart._legend.horizontalAlignment == .left
                    || chart._legend.horizontalAlignment == .right
                {
                    if chart._legend.verticalAlignment == .center
                    {
                        // this is the space between the legend and the chart
                        let spacing = CGFloat(13.0)
                        
                        xLegendOffset = fullLegendWidth + spacing
                    }
                    else
                    {
                        // this is the space between the legend and the chart
                        let spacing = CGFloat(8.0)
                        
                        let legendWidth = fullLegendWidth + spacing
                        let legendHeight = chart._legend.neededHeight + chart._legend.textHeightMax
                        
                        let c = chart.midPoint
                        
                        let bottomX = chart._legend.horizontalAlignment == .right
                            ? chart.bounds.width - legendWidth + 15.0
                            : legendWidth - 15.0
                        let bottomY = legendHeight + 15
                        let distLegend = distanceToCenter(x: bottomX, y: bottomY)
                        
                        let reference = PieHelperFunctions.getPosition(center: c, dist: piePlot.radius,
                                                                       angle: PieHelperFunctions.angleForPoint(x: bottomX, y: bottomY, center: piePlot.centerCircleBox))
                        
                        let distReference = distanceToCenter(x: reference.x, y: reference.y)
                        let minOffset = CGFloat(5.0)
                        
                        if bottomY >= c.y
                            && chart.bounds.height - legendWidth > chart.bounds.width
                        {
                            xLegendOffset = legendWidth
                        }
                        else if distLegend < distReference
                        {
                            let diff = distReference - distLegend
                            xLegendOffset = minOffset + diff
                        }
                    }
                }
                
                switch chart._legend.horizontalAlignment
                {
                case .left:
                    legendLeft = xLegendOffset
                    
                case .right:
                    legendRight = xLegendOffset
                    
                case .center:
                    
                    switch chart._legend.verticalAlignment
                    {
                    case .top:
                        legendTop = min(chart._legend.neededHeight, chart._viewPortHandler.chartHeight * chart._legend.maxSizePercent)
                        
                    case .bottom:
                        legendBottom = min(chart._legend.neededHeight, chart._viewPortHandler.chartHeight * chart._legend.maxSizePercent)
                        
                    default:
                        break
                    }
                }
                
            case .horizontal:
                
                var yLegendOffset: CGFloat = 0.0
                
                if chart._legend.verticalAlignment == .top
                    || chart._legend.verticalAlignment == .bottom
                {
                    // It's possible that we do not need this offset anymore as it
                    //   is available through the extraOffsets, but changing it can mean
                    //   changing default visibility for existing apps.
                    let yOffset = chart._legend.font.pointSize * 2.0
                    
                    yLegendOffset = min(
                        chart._legend.neededHeight + yOffset,
                        chart._viewPortHandler.chartHeight * chart._legend.maxSizePercent)
                }
                
                switch chart._legend.verticalAlignment
                {
                case .top:
                    
                    legendTop = yLegendOffset
                    
                case .bottom:
                    
                    legendBottom = yLegendOffset
                    
                default:
                    break
                }
            }
            
            legendLeft += piePlot.requiredBaseOffset
            legendRight += piePlot.requiredBaseOffset
            legendTop += piePlot.requiredBaseOffset
            legendBottom += piePlot.requiredBaseOffset
        }
        
        legendTop += chart.extraTopOffset
        legendRight += chart.extraRightOffset
        legendBottom += chart.extraBottomOffset
        legendLeft += chart.extraLeftOffset
        
        let minOffset = piePlot.minOffset
        
        /* Need to Add
        if (self.isKind(of: RadarChartView.self))
        {
            let x = self.xAxis
            
            if x.isEnabled && x.drawLabelsEnabled
            {
                minOffset = max(minOffset, x.labelRotatedWidth)
            }
        }*/
        
        var minLeftRightOffset = minOffset
        var minTopBottomOffset = minOffset
        
        if (chart.plotTypes.contains(.Dial))
        {
            for yAxisRenderer in chart.yAxisRenderers where yAxisRenderer.axis != nil && yAxisRenderer.axis!.enabled
            {
                guard let polarRenderer = yAxisRenderer as? YAxisPolarRenderer
                else { continue }
                
//                minOffset = max(minOffset, polarRenderer.getRequiredSize())
                let requiredSize = polarRenderer.getRequiredSize()
                minLeftRightOffset = max(minOffset, requiredSize.width)
                minTopBottomOffset = max(minOffset, requiredSize.width)
            }
        }
        
        if (chart.plotTypes.contains(.Radar))
        {
            guard let polarRenderer = chart.xAxisRenderer as? AxisPolarAngleRenderer
                    else { return }
            let requiredSize = polarRenderer.getRequiredSize()
            minLeftRightOffset = max(minLeftRightOffset, requiredSize.width)
            minTopBottomOffset = max(minTopBottomOffset, requiredSize.height)
        }
        
        let offsetLeft = max(minLeftRightOffset, legendLeft)
        let offsetTop = max(minTopBottomOffset, legendTop)
        let offsetRight = max(minLeftRightOffset, legendRight)
        let offsetBottom = max(minTopBottomOffset, max(piePlot.requiredBaseOffset, legendBottom))
        
        chart._viewPortHandler.restrainViewPort(offsetLeft: offsetLeft, offsetTop: offsetTop, offsetRight: offsetRight, offsetBottom: offsetBottom)
    }
    
    // MARK: - Gesture Handled
    
    override func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint) -> (entry: ChartDataEntry?, layer: ChartEntryLayer?) {
        
        /*var handler:EventHandler?
        
        if recognizer.isKind(of: TapEventListener.self)
        {
            handler = (recognizer as? TapEventListener)?.handler
        }
        else if recognizer.isKind(of: PanEventListener.self)
        {
            handler = (recognizer as? PanEventListener)?.handler
        }
        else if recognizer.isKind(of: LongPressEventListener.self)
        {
            handler = (recognizer as? LongPressEventListener)?.handler
        }*/
        
        return super.getEntryAndLayer(recognizer, location: location)
    }
    
    // MARK: - Supporting Methods
    
    /// - returns: The distance of a certain point on the chart to the center of the chart.
    open func distanceToCenter(x: CGFloat, y: CGFloat) -> CGFloat
    {
        guard  let chart = chart
            else {
                return 0
        }
        
        let c = chart.centerOffsets
        
        var dist = CGFloat(0.0)
        
        var xDist = CGFloat(0.0)
        var yDist = CGFloat(0.0)
        
        if x > c.x
        {
            xDist = x - c.x
        }
        else
        {
            xDist = c.x - x
        }
        
        if y > c.y
        {
            yDist = y - c.y
        }
        else
        {
            yDist = c.y - y
        }
        
        // pythagoras
        dist = sqrt(pow(xDist, 2.0) + pow(yDist, 2.0))
        
        return dist
    }
    
    /// - returns: The xIndex for the given angle around the center of the chart.
    /// -1 if not found / outofbounds.
    open func indexForAngle(_ angle: CGFloat) -> Int
    {
        fatalError("indexForAngle() cannot be called on PieRadarChartViewBase")
    }
    
    @objc override  func decelerationLoop()
    {
        /*let currentTime = CACurrentMediaTime()
         
         _decelerationAngularVelocity *= self.dragDecelerationFrictionCoef
         
         let timeInterval = CGFloat(currentTime - _decelerationLastTime)
         
         self.rotationAngle += _decelerationAngularVelocity * timeInterval
         
         _decelerationLastTime = currentTime
         
         if(abs(_decelerationAngularVelocity) < 0.001)
         {
         stopDeceleration()
         }*/

        guard let chart = chart,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
       
        let currentTime = CACurrentMediaTime()
        
        if chart._decelerationAngularVelocity > 1300
        {
           chart._decelerationAngularVelocity = 1000
        }
        
        if chart._decelerationAngularVelocity < -1300
        {
           chart._decelerationAngularVelocity = -1000
        }
        
       if chart._decelerationAngularVelocity < 300 && chart._decelerationAngularVelocity > -300
       {  chart._decelerationAngularVelocity *= chart.dragDecelerationFrictionCoef
        }
        else{
           if chart._decelerationAngularVelocity < 0
            {
               chart._decelerationAngularVelocity += 20
            }
            else{
               chart._decelerationAngularVelocity -= 20
            }
        }
        
       let timeInterval = CGFloat(currentTime - chart._decelerationLastTime)
        
       piePlot.rotationAngle += chart._decelerationAngularVelocity * timeInterval
        
        chart.setNeedsDisplay()
        
       if piePlot.arrowShow
       {
        PieHelperFunctions.checkForTickSound(chart: chart)
        }
        
       chart._decelerationLastTime = currentTime

        
        if piePlot.arrowShow
        {
           if(abs(chart._decelerationAngularVelocity) < 50 && abs(chart._decelerationAngularVelocity) > -50 )
            {
                
                PieHelperFunctions.positionMid(chart: chart, duration: 1.5)
                
                
                chart.stopDeceleration()
                
            }
        }
        else{
           if(abs(chart._decelerationAngularVelocity) < 4 && abs(chart._decelerationAngularVelocity) > -4)
            {
                chart.stopDeceleration()
                
                chart.data?.setDrawValues(true)
                
            }

        }
        
    }
    
    /*// MARK: - Protocol Implementations
         
     /// Tooltip tapped
     public func tooltipSelected(entry: ChartDataEntry?) {
         
      fatalError("No Calling")
         
     }
     
     /// Legend tapped
     public func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
         
        fatalError("No Calling")
     }
         
         
     /// Legend tapped
     public func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
         
         fatalError("No Calling")
     }
   /// Legend range adjusted
   open func legendRangeSelected(minimum: Double, maximum: Double) {
       fatalError("No Calling")
   }*/
    
    
}
