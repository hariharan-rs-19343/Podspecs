//
//  Interpolator.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 25/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

import Foundation


extension NSUIColor
{
open var coreImageColor: CIColor {
#if os(iOS) || os(tvOS)
        return CIColor(color: self)
#else
        return CIColor(color: self)!
#endif
}
open var components: (red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
    let coreImageColor = self.coreImageColor
    return (coreImageColor.red, coreImageColor.green, coreImageColor.blue, coreImageColor.alpha)
}
}

extension NSUIFont {
    func isSystemFont() -> Bool {
        return self.familyName == NSUIFont.systemFont(ofSize: 12.0).familyName
    }
}

open class Interpolator
{

    public static func interpolate(a:Double,b:Double) -> ((Double) -> Double) {
        
        func calc(c:Double) -> Double {
            return a + c * (b - a);
        }
        
        return calc
    }
    
    public static func interpolate(a:CGFloat,b:CGFloat) -> ((CGFloat) -> CGFloat) {
        
        func calc(c:CGFloat) -> CGFloat {
            return a + c * (b - a);
        }
        
        return calc
    }
    
    public static func precentage(a: CGFloat, b: CGFloat, value: CGFloat) -> CGFloat {
        
        if a == b {
            return 0.0
        }
        
        return  (((value - a)) / (b - a))
    }
    
    public static func precentage(a: Double, b: Double, value: Double) -> Double {
        
        if a == b {
            return 0.0
        }
        
        return  (((value - a)) / (b - a))
    }
    
    public static func interpolate(a:NSUIColor,b:NSUIColor) -> ((Double) -> NSUIColor) {
        
        let rVal = Interpolator.interpolate(a: Double(a.components.red), b:  Double(b.components.red))
        let gVal = Interpolator.interpolate(a: Double(a.components.green), b:  Double(b.components.green))
        let bVal = Interpolator.interpolate(a: Double(a.components.blue), b:  Double(b.components.blue))
        let alphaVal = Interpolator.interpolate(a: Double(a.components.alpha), b:  Double(b.components.alpha))
        
        func calc(c:Double) -> NSUIColor {
   
            return NSUIColor(red: CGFloat(rVal(c)), green: CGFloat(gVal(c)), blue: CGFloat(bVal(c)), alpha: CGFloat(alphaVal(c)))
        }
        
        return calc
    }

}
