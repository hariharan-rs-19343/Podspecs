//
//  ChartData.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

open class ChartData: NSObject, Codable
{
    // MARK: - Min Max Properties
    
    internal var _xMax: Double = -Double.greatestFiniteMagnitude
    internal var _xMin: Double = Double.greatestFiniteMagnitude
    
    internal var _yMax: Double = -Double.greatestFiniteMagnitude
    internal var _yMin: Double = Double.greatestFiniteMagnitude
    
    internal var _maxSize = -Double.greatestFiniteMagnitude
    
    internal var _minSize = 0.0//Double.greatestFiniteMagnitude
    
    internal var _yAxisMinArray:[Int:Double] = [:]
    internal var _yAxisMaxArray:[Int:Double] = [:]
    
    internal var _dataSets = [IChartDataSet]()
    
    internal var _datasetsGroupArray = [[Int]]() 
    
    internal var getdatasetsGroupArray: [[Int]] {
        get {
            return _datasetsGroupArray
        }
    }
    
    internal var _stackGroupArray = [[Int]]()
    
    internal var getStackGroupArray: [[Int]] {
        get {
            return _stackGroupArray
        }
    }
    
    // MARK: - HeatMap Properties
    
    open var rectWidth = Double(1)
    open var rectHeight = Double(1)
    
    open var paddingInPixels = CGFloat(0)
    
    var oneTime = true

    // MARK: - General Properties
    
    /// optional spot for additional user data this Data represents
    @objc open var userData: AnyObject?
    
    var xOrdinal:Bool!
    var yOrdinal = [Int:Bool]()
    
    open var xStringOrder:[String]?
    open var yStringOrder:[Int:[String]]?
    
    open var xString:[String]?
    open var yString:[Int:[String]]?
    
    // To check draw values enabled
    open var valuesEnabled:Bool? = nil
    
    @available(*, deprecated, message: "instead use dataLabelRenderingMode")
    open var skipDataValuesEnabled: Bool = false
    
    open var dataLabelRenderingMode: LabelRenderingMode = .showAll
    
    // To maintain one time loop
    fileprivate var allowed:Bool = true
    
    /// Enables / disables highlighting values for all DataSets this data object contains.
    /// If set to true, this means that values can be highlighted programmatically or by touch gesture.
    open var highlightEnabled: Bool
        {
        get
        {
            for set in dataSets
            {
                if !set.highlightEnabled
                {
                    return false
                }
            }
            
            return true
        }
        set
        {
            for set in dataSets
            {
                set.highlightEnabled = newValue
            }
        }
    }
    
    /// if true, value highlightning is enabled
    open var isHighlightEnabled: Bool { return highlightEnabled }
    
    /// - returns: The total entry count across all DataSet objects this data object contains.
    open var entryCount: Int
    {
        var count = 0
        
        for set in _dataSets
        {
            count += set.entryCount
        }
        
        return count
    }
    
    /// - returns: The DataSet object with the maximum number of entries or null if there are no DataSets.
    open var maxEntryCountSet: IChartDataSet?
    {
        if _dataSets.count == 0
        {
            return nil
        }
        
        var max = _dataSets[0]
        
        for set in _dataSets
        {
            if set.entryCount > max.entryCount
            {
                max = set
            }
        }
        
        return max
    }
    
    // MARK: - Accessors
    
    /// - returns: All DataSet objects this ChartData object holds.
    open var dataSets: [IChartDataSet]
        {
        get
        {
            return _dataSets
        }
        set
        {
            _dataSets = newValue
            notifyDataChanged()
        }
    }
    
    open var datasetsGroupArray: [[Int]]?
    open var stackGroupArray: [[Int]]?
    
    // DatasetGroupCount
//    internal var currentGroupCount = 0
    
    /// - returns: The number of LineDataSets this object contains
    open var dataSetCount: Int
    {
        return _dataSets.count
    }
    
    /// - returns: The minimum x-value the data object contains.
    open var xMin: Double
    {
        return _xMin
    }
    
    /// - returns: The maximum x-value the data object contains.
    open var xMax: Double
    {
        return _xMax
    }
    
    /// - returns: The smallest y-value the data object contains.
    open var yMin: Double
    {
        return _yMin
    }
    
    /// - returns: The greatest y-value the data object contains.
    open var yMax: Double
    {
        return _yMax
    }
    
    open var maxSize: CGFloat
    {
        return _maxSize
    }
    
    open var minSize: CGFloat
    {
        return _minSize
    }
    
    @nonobjc
    open func getYMin() -> Double
    {
        return _yMin
    }
    
    @nonobjc
    open func getYMax() -> Double
    {
        return _yMax
    }
    
    open func getYMin(axisIndex:Int) -> Double
    {
        if _yAxisMinArray[axisIndex] == nil || _yAxisMinArray[axisIndex] == Double.greatestFiniteMagnitude
        {
            return 0
        }
        
        return _yAxisMinArray[axisIndex]!
    }
    
    open func getYMax(axisIndex:Int) -> Double
    {
        if  _yAxisMaxArray[axisIndex] == nil || _yAxisMaxArray[axisIndex] == -Double.greatestFiniteMagnitude
        {
            return 0
        }
        
        return _yAxisMaxArray[axisIndex]!
    }
    
    /// - returns: The labels of all DataSets as a string array.
    internal func getDataSetLabels() -> [String]
    {
        var types = [String]()
        
        for i in 0 ..< _dataSets.count
        {
            if dataSets[i].label == nil
            {
                continue
            }
            
            types[i] = _dataSets[i].label!
        }
        
        return types
    }
    
    open func getDataSetByIndex(_ index: Int) -> IChartDataSet!
    {
        if index < 0 || index >= _dataSets.count
        {
            return nil
        }
        
        return _dataSets[index]
    }
    
    /// **IMPORTANT: This method does calculations at runtime. Use with care in performance critical situations.**
    ///
    /// - parameter label:
    /// - parameter ignorecase:
    /// - returns: The DataSet Object with the given label. Sensitive or not.
    open func getDataSetByLabel(_ label: String, ignorecase: Bool) -> IChartDataSet?
    {
        let index = getDataSetIndexByLabel(label, ignorecase: ignorecase)
        
        if index < 0 || index >= _dataSets.count
        {
            return nil
        }
        else
        {
            return _dataSets[index]
        }
    }
    
    /// Retrieve the index of a ChartDataSet with a specific label from the ChartData. Search can be case sensitive or not.
    ///
    /// **IMPORTANT: This method does calculations at runtime, do not over-use in performance critical situations.**
    ///
    /// - parameter dataSets: the DataSet array to search
    /// - parameter type:
    /// - parameter ignorecase: if true, the search is not case-sensitive
    /// - returns: The index of the DataSet Object with the given label. Sensitive or not.
    internal func getDataSetIndexByLabel(_ label: String, ignorecase: Bool) -> Int
    {
        if ignorecase
        {
            for i in 0 ..< dataSets.count
            {
                if dataSets[i].label == nil
                {
                    continue
                }
                if (label.caseInsensitiveCompare(dataSets[i].label!) == ComparisonResult.orderedSame)
                {
                    return i
                }
            }
        }
        else
        {
            for i in 0 ..< dataSets.count
            {
                if label == dataSets[i].label
                {
                    return i
                }
            }
        }
        
        return -1
    }
    
    /// - returns: The DataSet that contains the provided Entry, or null, if no DataSet contains this entry.
    open func getDataSetForEntry(_ e: ChartDataEntry!) -> IChartDataSet?
    {
        if e == nil
        {
            return nil
        }
        
        for i in 0 ..< _dataSets.count
        {
            let set = _dataSets[i]
            
            if set.entriesForXYValue(e.x, e.y).filter({$0 === e}).count == 1
            {
                return set
            }
            
            /// Old One
            /*if e === set.entryForXValue(e.x, closestToY: e.y)
             {
             return set
             }*/
        }
        
        
        return nil
    }
    
    /// - returns: The DataSet that contains the provided Entry, or null, if no DataSet contains this entry.
    open func getDataSetForPlotType(plotType: ChartType) -> [IChartDataSet]
    {
         var dataSetsArray:[IChartDataSet] = []
        
          for i in 0 ..< _dataSets.count
          {
            if _dataSets[i].plotType == plotType
            {
                dataSetsArray.append(_dataSets[i])
            }
          }
          return dataSetsArray
    }
    
    open func getDataSetFor(plotTypes: [ChartType], axisIndex: Int, isVisibleDatasets: Bool = true) -> [IChartDataSet]
    {
        var dataSetsArray:[IChartDataSet] = []
        
        for i in 0 ..< _dataSets.count where isVisibleDatasets ? _dataSets[i].isVisible : true
        {
            if plotTypes.contains(_dataSets[i].plotType) && _dataSets[i].axisIndex == axisIndex
            {
                dataSetsArray.append(_dataSets[i])
            }
        }
        return dataSetsArray
    }
    
    //Moved to ChartHighlighter object
    /*/// Get the Entry for a corresponding highlight object
    ///
    /// - parameter highlight:
    /// - returns: The entry that is highlighted
    open func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry?
    {
        if highlight.dataSetIndex >= dataSets.count
        {
            return nil
        }
        else
        {
            return dataSets[highlight.dataSetIndex].entryForXValue(highlight.x, closestToY: highlight.y)
        }
    }*/
    
    /// - returns: The index of the provided DataSet in the DataSet array of this data object, or -1 if it does not exist.
    open func indexOfDataSet(_ dataSet: IChartDataSet) -> Int
    {
        for i in 0 ..< _dataSets.count
        {
            if _dataSets[i] === dataSet
            {
                return i
            }
        }
        
        return -1
    }
    
    /// - returns: All colors used across all DataSet objects this object represents.
    open func getColors() -> [NSUIColor]?
    {
        var clrcnt = 0
        
        for i in 0 ..< _dataSets.count
        {
            clrcnt += _dataSets[i].colors.count
        }
        
        var colors = [NSUIColor]()
        
        for i in 0 ..< _dataSets.count
        {
            let clrs = _dataSets[i].colors
            
            for clr in clrs
            {
                colors.append(clr)
            }
        }
        
        return colors
    }
    
    /// Sets a custom IValueFormatter for all DataSets this data object contains.
    open func setValueFormatter(_ formatter: IValueFormatter?)
    {
        guard let formatter = formatter
            else { return }
        
        for set in dataSets
        {
            set.valueFormatter = formatter
        }
    }
    
    /// Sets the color of the value-text (color in which the value-labels are drawn) for all DataSets this data object contains.
    open func setValueTextColor(_ color: NSUIColor!)
    {
        for set in dataSets
        {
            set.valueTextColor = color ?? set.valueTextColor
        }
    }
    
    /// Sets the font for all value-labels for all DataSets this data object contains.
    open func setValueFont(_ font: NSUIFont!)
    {
        for set in dataSets
        {
            set.valueFont = font ?? set.valueFont
        }
    }
    
    /// Enables / disables drawing values (value-text) for all DataSets this data object contains.
    open func setDrawValues(_ enabled: Bool)
    {
        for set in dataSets
        {
            set.drawValuesEnabled = enabled
        }
        
        if allowed
        {
            valuesEnabled = enabled
            allowed = false
        }
        
    }
    
    
    /// Clears this data object from all DataSets and removes all Entries.
    /// Don't forget to invalidate the chart after this.
    open func clearValues()
    {
        dataSets.removeAll(keepingCapacity: false)
        notifyDataChanged()
    }
    
    /// Checks if this data object contains the specified DataSet.
    /// - returns: `true` if so, `false` ifnot.
    open func contains(dataSet: IChartDataSet) -> Bool
    {
        for set in dataSets
        {
            if set === dataSet
            {
                return true
            }
        }
        
        return false
    }
    
    
    // MARK: - Initializer
    
    public required override init()
    {
        super.init()
        
        _dataSets = [IChartDataSet]()
    }
    
    public init(dataSets: [IChartDataSet]?)
    {
        super.init()
        
        _dataSets = dataSets ?? [IChartDataSet]()
        
        self.initialize(dataSets: _dataSets)
    }
    
    public convenience init(dataSet: IChartDataSet?)
    {
        self.init(dataSets: dataSet === nil ? nil : [dataSet!])
    }
    
    internal func initialize(dataSets: [IChartDataSet])
    {
        guard dataSets.count > 0
            else { return }
        
        oneTime = true
//        updateXYValues()
//        notifyDataChanged()
    }
    
    func dataCalculation()
    {
        updateXYValues()
        notifyDataChanged()
    }
    
    open func reinit() {
        initialize(dataSets: _dataSets)
    }
    // MARK: - Min Max Calculation Methods
    
    internal func initAxisMinAndMaxArrays() {
        
        _yMax = -Double.greatestFiniteMagnitude
        _yMin = Double.greatestFiniteMagnitude
        _xMax = -Double.greatestFiniteMagnitude
        _xMin = Double.greatestFiniteMagnitude
        _maxSize = -Double.greatestFiniteMagnitude
        _minSize = 0.0//Double.greatestFiniteMagnitude
        
        let axisIndexSet = getUniqAxisIndex(dataSetArray: self.dataSets)
        
        for axisIndex in axisIndexSet {
            _yAxisMinArray[axisIndex] = Double.greatestFiniteMagnitude
            _yAxisMaxArray[axisIndex] = -Double.greatestFiniteMagnitude
        }
    }
    
    fileprivate func getUniqAxisIndex(dataSetArray:[IChartDataSet]) -> Set<Int> {
        //        let allowedLists = dataSetArray.filter ({ $0.visible })
        let axisIndexList = dataSetArray.map( {$0.axisIndex} )
        return Set(axisIndexList)
    }
    
    /// Call this method to let the ChartData know that the underlying data has changed.
    /// Calling this performs all necessary recalculations needed when the contained data has changed.
    open func notifyDataChanged()
    {
        calcMinMax()
        
        if  xStringOrder != nil && xOrdinal 
        {
            _xMin = 0
            _xMax = Double((xStringOrder!.count - 1))
        }
        
        for (axisIndex, ordinalEnabled) in yOrdinal where ordinalEnabled && yStringOrder?[axisIndex] != nil {
            
            _yAxisMinArray[axisIndex] = 0
            _yAxisMaxArray[axisIndex] = Double((yStringOrder![axisIndex]!.count - 1))
        }
    }
    
    open func calcMinMaxY(fromX: Double, toX: Double)
    {
        for set in _dataSets
        {
            set.calcMinMaxY(fromX: fromX, toX: toX)
        }
        
        // apply the new data
        calcMinMax()
    }
    
    /// calc minimum and maximum y value over all datasets
    open func calcMinMax()
    {
        //Need to test a lot
        initAxisMinAndMaxArrays()
        
        for set in _dataSets
        {
            calcMinMax(dataSet: set)
        }
    }
    
    /// Adjusts the current minimum and maximum values based on the provided Entry object.
    open func calcMinMax(entry e: ChartDataEntry, dataSet: IChartDataSet)
    {
        if _yMax < e.y
        {
            _yMax = e.y
        }
        
        if _yMin > e.y
        {
            _yMin = e.y
        }
        
        if _xMax < e.x
        {
            _xMax = e.x
        }
        
        if _xMin > e.x
        {
            _xMin = e.x
        }
        
        if _yAxisMaxArray[dataSet.axisIndex] != nil && _yAxisMaxArray[dataSet.axisIndex]! < dataSet.yMax
        {
            _yAxisMaxArray[dataSet.axisIndex] = dataSet.yMax
        }
        
        if  _yAxisMinArray[dataSet.axisIndex] != nil && _yAxisMinArray[dataSet.axisIndex]! > dataSet.yMin
        {
            _yAxisMinArray[dataSet.axisIndex] = dataSet.yMin
        }
     
    }
    
    /// Adjusts the minimum and maximum values based on the given DataSet.
    open func calcMinMax(dataSet d: IChartDataSet)
    {
        if !(d.isVisible) || d.entryCount <= 0
        {
            return
        }

        if _yMax < d.yMax
        {
            _yMax = d.yMax
        }
        
        if _yMin > d.yMin
        {
            _yMin = d.yMin
        }
        
        if _xMax < d.xMax
        {
            _xMax = d.xMax
        }
        
        if _xMin > d.xMin
        {
            _xMin = d.xMin
        }
        
        if _yAxisMaxArray[d.axisIndex] != nil && _yAxisMaxArray[d.axisIndex]! < d.yMax
        {
            _yAxisMaxArray[d.axisIndex] = d.yMax
        }
        
        if  _yAxisMinArray[d.axisIndex] != nil && _yAxisMinArray[d.axisIndex]! > d.yMin
        {
            _yAxisMinArray[d.axisIndex] = d.yMin
        }
        
        if _maxSize < d.maxSize
        {
            _maxSize = d.maxSize
        }
        
        if _minSize > d.minSize
        {
            _minSize = d.minSize
        }
    }
    

    
    // MARK: - CRUD Operations
    
    open func addDataSet(_ dataSet: IChartDataSet!)
    {
        calcMinMax(dataSet: dataSet)
        
        _dataSets.append(dataSet)
    }
    
    /// Removes the given DataSet from this data object.
    /// Also recalculates all minimum and maximum values.
    ///
    /// - returns: `true` if a DataSet was removed, `false` ifno DataSet could be removed.
    @discardableResult open func removeDataSet(_ dataSet: IChartDataSet!) -> Bool
    {
        if dataSet === nil
        {
            return false
        }
        
        for i in 0 ..< _dataSets.count
        {
            if _dataSets[i] === dataSet
            {
                return removeDataSetByIndex(i)
            }
        }
        
        return false
    }
    
    /// Removes the DataSet at the given index in the DataSet array from the data object. 
    /// Also recalculates all minimum and maximum values. 
    ///
    /// - returns: `true` if a DataSet was removed, `false` ifno DataSet could be removed.
    @discardableResult open func removeDataSetByIndex(_ index: Int) -> Bool
    {
        if index >= _dataSets.count || index < 0
        {
            return false
        }
        
        _dataSets.remove(at: index)
        
        calcMinMax()
        
        return true
    }
    
    /// Adds an Entry to the DataSet at the specified index. Entries are added to the end of the list.
    open func addEntry(_ e: ChartDataEntry, dataSetIndex: Int)
    {
        if _dataSets.count > dataSetIndex && dataSetIndex >= 0
        {
            let set = _dataSets[dataSetIndex]
            
            if !set.addEntry(e) { return }
            
//            calcMinMax(entry: e, axis: set.axisDependency)
             calcMinMax(entry: e, dataSet: set)
        }
        else
        {
            print("ChartData.addEntry() - Cannot add Entry because dataSetIndex too high or too low.", terminator: "\n")
        }
    }
    
    /// Removes the given Entry object from the DataSet at the specified index.
    @discardableResult open func removeEntry(_ entry: ChartDataEntry, dataSetIndex: Int) -> Bool
    {
        // entry outofbounds
        if dataSetIndex >= _dataSets.count
        {
            return false
        }
        
        // remove the entry from the dataset
        let removed = _dataSets[dataSetIndex].removeEntry(entry)
        
        if removed
        {
            calcMinMax()
        }
        
        return removed
    }
    
    /// Removes the Entry object closest to the given xIndex from the ChartDataSet at the
    /// specified index. 
    /// - returns: `true` if an entry was removed, `false` ifno Entry was found that meets the specified requirements.
    @discardableResult open func removeEntry(xValue: Double, dataSetIndex: Int) -> Bool
    {
        if dataSetIndex >= _dataSets.count
        {
            return false
        }
        
        if let entry = _dataSets[dataSetIndex].entryForXValue(xValue, closestToY: Double.nan)
        {
            return removeEntry(entry, dataSetIndex: dataSetIndex)
        }
        
        return false
    }
    
  
    // MARK: - Ordinal Scale Data Preparations
    
    
    func initializeOrdinalStringMap() {
        
        if  xOrdinal  {
            xString = [String]()
        }
        
        if yString == nil {
            yString = [Int:[String]]()
        }
        
        for (axisIndex, ordinalEnabled) in yOrdinal where ordinalEnabled {
            
            if yString![axisIndex] == nil {
                yString![axisIndex] = [String]()
            }
        }
        
    }
    
    open func updateXYValues()
    {
        
        if oneTime{
            
            oneTime = false
            
            initializeOrdinalStringMap()
        }
        
        if xOrdinal {
            prepareXValues()
        }
        
        if yOrdinal.count > 0 {
            prepareYValues()
        }
        
        for set in _dataSets
        {
            set.calcMinMax()
        }
        
    }
    
    func prepareXValues()
    {
        var xStringTemp = [String]()
        var xStringTestTemp = [String:Double]()
        
        if xStringOrder != nil
        {
            /*var xUniqueValues = Set<String>()
            
            for set in dataSets //where set.isVisible
            {
                for entryIndex in 0..<set.entryCount
                {
                    let entry = set.entryForIndex(entryIndex)!
                    
                    if !set.isVisible
                    {
                       entry.x = Double.leastNormalMagnitude
                       continue
                    }

                    if entry.xString == nil || (yOrdinal[set.axisIndex]! && entry.yString == nil)
                    {
                        continue
                    }
                    xUniqueValues.insert((entry.xString)!)
                }
            }*/
            
            xStringTemp = xStringOrder! // getXStringInOrder(currentXValues: xUniqueValues)
            
            var stringIndex:Int = -1
             for stringValue in xStringOrder! {
                 stringIndex += 1
                 if xStringTestTemp[stringValue] == nil {
                     xStringTestTemp[stringValue] = Double(stringIndex)
                 }
             }
        }
        
        var count = Double(-1)
        for set in _dataSets where set.isVisible
        {
            for entryIndex in 0..<set.entryCount
            {
                let entry = set.entryForIndex(entryIndex)!
                
                if entry.xString == nil || (yOrdinal[set.axisIndex]! && entry.yString == nil){
                    entry.x = Double.nan
                    entry.y = Double.nan
                    continue
                }
               /* if !(xStringTemp.contains(entry.xString!))
                {
                    count += 1
                    entry.x = count
                    xStringTemp.append(entry.xString!)
                }
                else{
                    entry.x = Double(xStringTemp.firstIndex(of: entry.xString!)!)
                }*/
                
                  if xStringOrder != nil && (xStringTestTemp[entry.xString!] == nil)
                  {
                      entry.x = Double.nan
                  }
                  else if (xStringTestTemp[entry.xString!] == nil)
                  {
                      count = Double(xStringTemp.count)
                      entry.x = count
                      xStringTemp.append(entry.xString!)
                      xStringTestTemp[entry.xString!] = count
                  }
                  else{
                      entry.x = xStringTestTemp[entry.xString!]! // Double(xStringTemp.firstIndex(of: entry.xString!)!)
                  }
            }
            
            _ = set.sortEntries { (a, b) -> Bool in
                (a.x.isNaN ? 0 : a.x) < (b.x.isNaN ? 0 : b.x)
            }
            
        }
        
        xString = xStringTemp
        
    }
    
    func prepareYValues()
    {
        var yStringTemp = [Int:[String]]()
        var yUniqueValues:[Int:Set<String>]?
        var yStringTestTemp = [Int:[String:Double]]()
        
        if (yStringOrder != nil  && (yStringOrder?.count)! > 0 )
        {
            yUniqueValues = [Int:Set<String>]()
            
            for set in dataSets //where set.isVisible
            {
                for entryIndex in 0..<set.entryCount
                {
                    let entry = set.entryForIndex(entryIndex)!
                    
                    if yOrdinal[set.axisIndex] != nil && yOrdinal[set.axisIndex]! && !set.isVisible
                    {
                       entry.y = Double.leastNormalMagnitude
                       continue
                    }

                    
                    if entry.yString == nil || (xOrdinal && entry.xString == nil)
                    {
                        continue
                    }
                    
                    if yUniqueValues![set.axisIndex] == nil {
                        yUniqueValues![set.axisIndex] = Set<String>()
                    }
                    yUniqueValues![set.axisIndex]!.insert((entry.yString)!)
                    
                }
            }
            
        }
        
        if yStringOrder != nil {
            yStringTemp = yStringOrder! //getYStringInOrder(currentYValueMap: yUniqueValues!)
            
            for (axisIndex, stringArray) in yStringOrder! {
                  var stringMap = [String:Double]()
                  var stringIndex:Int = -1
                  for stringValue in stringArray {
                      stringIndex += 1
                      if stringMap[stringValue] == nil {
                          stringMap[stringValue] = Double(stringIndex)
                      }
                  }
                 yStringTestTemp[axisIndex] = stringMap
              }
        }
        
        var count = Double(-1)

        var axisIndex = 0
        
        for set in _dataSets where set.entryCount > 0 && set.isVisible
        {
            axisIndex = set.axisIndex
            
            if yStringTemp[axisIndex] == nil {
                yStringTemp[axisIndex] = [String]()
            }
            
            if yStringTestTemp[axisIndex] == nil {
               yStringTestTemp[axisIndex] = [String:Double]()
            }
            
            if !yOrdinal[axisIndex]!
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                let entry = set.entryForIndex(entryIndex)!
                
                if entry.yString == nil || (xOrdinal && entry.xString == nil) || (yStringOrder?[axisIndex] == nil && entry.x.isNaN){
                    entry.y = Double.nan
                    entry.x = Double.nan
                    continue
                }
                
                let stringArray = yStringTemp[axisIndex]!
                let stringMap = yStringTestTemp[axisIndex]!
                
               /* if !(stringArray.contains(entry.yString!))
                {
                    count = Double(stringArray.count)
                    entry.y = count
                    yStringTemp[axisIndex]?.append(entry.yString!)
                }
                else{
                    entry.y = Double(stringArray.firstIndex(of: entry.yString!)!)
                }*/
                
               if yStringOrder?[axisIndex] != nil && stringMap[entry.yString!] == nil
               {
                   entry.y = Double.nan
               }
               else if (stringMap[entry.yString!] == nil)
               {
                   count = Double(stringArray.count)
                   entry.y = count
                   yStringTemp[axisIndex]?.append(entry.yString!)
                   yStringTestTemp[axisIndex]![entry.yString!] = count
               }
               else{
                   entry.y = yStringTestTemp[axisIndex]![entry.yString!]!
               }
            }
        }
        
        yString = yStringTemp
    }
    
    open func getXStringInOrder(currentXValues:Set<String>) ->[String]
    {
        var xGivenSet = Set<String>()
        
        for x in  xStringOrder!
        {
            xGivenSet.insert(x)
        }
        
        let xValuesMissing = xGivenSet.subtracting(currentXValues)
        
       /* xString = xStringOrder
        
        for setValue in xValuesMissing
        {
            let index = (xString?.firstIndex(of:setValue))!
            xString?.remove(at: index )
        }*/
        
        if xString == nil {
           xString = []
        }
        xString?.removeAll()
        for xStringVal in (xStringOrder)! where !(xValuesMissing.contains(xStringVal)) {
            xString!.append(xStringVal)
        }
        
        return xString!
    }
    
    open func getYStringInOrder(currentYValueMap:[Int:Set<String>]) ->[Int:[String]]
    {
        var yGivenMap:[Int:Set<String>] = [Int:Set<String>]()
        
        for (axisIndex, yData) in (yStringOrder)! {
            var yGivenSet = Set<String>()
            for y in yData {
                yGivenSet.insert(y)
            }
            yGivenMap[axisIndex] = yGivenSet
        }
        
        for (axisIndex, currentYValues) in currentYValueMap {
            if yGivenMap[axisIndex] == nil {
                continue
            }
            let yGivenSet = yGivenMap[axisIndex]!
            let valuesMissing = yGivenSet.subtracting(currentYValues)
            
           /* yString?[axisIndex]! = (yStringOrder?[axisIndex]!)!
            
            for setValue in valuesMissing
            {
                let index = (yString?[axisIndex]!.firstIndex(of:setValue))!
                yString?[axisIndex]!.remove(at: index)
            }*/
            
            if yString?[axisIndex] == nil {
               yString?[axisIndex] = []
            }
            yString?[axisIndex]!.removeAll()
            for yStringVal in (yStringOrder?[axisIndex]!)! where !(valuesMissing.contains(yStringVal)) {
                yString?[axisIndex]!.append(yStringVal)
            }
        }
        
        return (yString)!
    }
    
    // MARK: - NSCopying
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = type(of: self).init()
        
        var newDataSet:[ChartDataSet]  = []
        
        for i in 0 ..< _dataSets.count
        {
            let dataSet = (_dataSets[i] as! ChartDataSet).copy() as! ChartDataSet
            dataSet.notifyDataSetChanged()
            newDataSet.append(dataSet)
        }
        
        copy.valuesEnabled = valuesEnabled
        copy.allowed = allowed
        copy._dataSets = newDataSet
        copy.initAxisMinAndMaxArrays()
        copy.notifyDataChanged()
        copy.xString = xString
        copy.yString = yString
        copy.xOrdinal = xOrdinal
        copy.yOrdinal = yOrdinal
        copy.oneTime = oneTime
        copy.xStringOrder = xStringOrder
        copy.yStringOrder = yStringOrder
        copy.dataLabelRenderingMode = dataLabelRenderingMode
        copy.datasetsGroupArray = datasetsGroupArray
        copy.stackGroupArray = stackGroupArray
        
        return copy
    }
    
    // MARK: - Codable
    enum CodingKeys: CodingKey {
               case mDataSets
               case stackGroup
           }
    
    required public convenience init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let dataSets = try container.decode([ChartDataSet].self, forKey: .mDataSets)
        let stackGroup = container.contains(.stackGroup) ? try container.decode([[Int]].self, forKey: .stackGroup) : nil
        
        self.init(dataSets: dataSets)
        
        datasetsGroupArray = stackGroup
        
//        _datasetsGroupArray = setGroupArray
    }
    
    public func encode(to encoder: Encoder) throws {
        
    }
}

extension ChartData {
    
    func isVaild(dataset: [IChartDataSet], datasetIndex: Int) -> Bool {
        return (dataset[safe:datasetIndex] != nil) && dataset[datasetIndex].isVisible
    }
    
    internal func getStackGroupArrayFor(setIndex: Int) -> [Int] {
        
        for stackGroup in _stackGroupArray {
            if stackGroup.contains(where: { $0 == setIndex}) {
                return stackGroup
            }
        }
        
        return [0]
    }
}

public enum LabelRenderingMode {
    case skip
    case adjust
    case showAll
}
