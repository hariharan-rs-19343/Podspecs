//
//  BarChartDataEntry.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

/*open class BarChartDataEntry: ChartDataEntry
{
    // MARK: General Properties
 
    /// the ranges for the individual stack values - automatically calculated
    fileprivate var _ranges: [Range]?
    
    /// the sum of all negative values this entry (if stacked) contains
    fileprivate var _negativeSum: Double = 0.0
    
    /// the sum of all positive values this entry (if stacked) contains
    fileprivate var _positiveSum: Double = 0.0
    
//    open var sizeChanged:CGSize?
    
    // MARK: Accessors
    
    /// - returns: The ranges of the individual stack-entries. Will return null if this entry is not stacked.
    open var ranges: [Range]?
    {
        return _ranges
    }
    
    /// - returns: The sum of all negative values this entry (if stacked) contains. (this is a positive number)
    open var negativeSum: Double
    {
        return _negativeSum
    }
    
    /// - returns: The sum of all positive values this entry (if stacked) contains.
    open var positiveSum: Double
    {
        return _positiveSum
    }
    
    // MARK: NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! BarChartDataEntry
        copy.y = y
        copy._negativeSum = _negativeSum
        copy._positiveSum = _positiveSum
        copy._ranges = _ranges
        return copy
    }
    
}*/
