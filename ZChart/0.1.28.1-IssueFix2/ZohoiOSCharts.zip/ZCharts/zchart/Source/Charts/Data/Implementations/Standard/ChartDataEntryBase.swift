//
//  ChartDataEntryBase.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

open class ChartDataEntryBase: NSObject, Codable
{
    // MARK: General Properties
    
    /// the y value
       @objc open var y = Double(0.0)
    
    /// the y0 value
       @objc open var y0 = Double(0.0)
    
    /// yString value
    open var yString:String? = nil
    
    /// optional spot for additional data this Entry represents
    @objc open var data: AnyObject?
    
    /// optional spot for chart oriented additional data this Entry represents
    @objc open var plotData: AnyObject?
    
    /// optional icon image
    open var icon: NSUIImage?
    
    open override var description: String
    {
        return "ChartDataEntryBase, y \(y)"
    }
    
    // MARK: Properties Needed for Interactions
    
    /// Need to Refactor
    
    open var origIndex:Double? = nil
    
    open var origX:Double? = nil
    
    open var origY:Double? = nil
    
    open var filterEnabled:Bool = false
    
    open var barYValue:CGFloat = 1
    
    open var isIncluded:Bool = false
    
    open var layerEnabled:Bool = false
    
    open var centerChanged:CGPoint?
    
    open var filterChanged:AnyObject?
    
    open var lineCenterChanged:CGPoint?
    
    open var enabled:Bool = true
    
    open var sizeChanged:CGSize?
    
    open var opacityChanged: Float = 1.0
    
    
    // MARK: Initializers
    
    public override required init()
    {
        super.init()
    }
    
    /// An Entry represents one single entry in the chart.
    /// - parameter y: the y value (the actual value of the entry)
    public init(y: Double)
    {
        super.init()
        
        self.y = y
    }
    
    /// - parameter y: the y value (the actual value of the entry)
    /// - parameter data: Space for additional data this Entry represents.
    
    public init(y: Double, data: AnyObject?)
    {
        super.init()
        
        self.y = y
        self.data = data
    }
    
    public init(y: Double, y0: Double, data: AnyObject?)
    {
        super.init()
        
        self.y = y
        self.y0 = y0
        self.data = data
    }
  
    
    
    /// - parameter yString: the yString value (the actual value of the entry)
    /// - parameter data: Space for additional data this Entry represents.
    
    public init(yString: String?, data: AnyObject?)
    {
        super.init()
        
        self.yString = yString
        self.data = data
    }
    
    
    /// - parameter y: the y value (the actual value of the entry)
    /// - parameter icon: icon image
    
    public init(y: Double, icon: NSUIImage?)
    {
        super.init()
        
        self.y = y
        self.icon = icon
    }
    
    /// - parameter y: the y value (the actual value of the entry)
    /// - parameter icon: icon image
    /// - parameter data: Space for additional data this Entry represents.
    
    public init(y: Double, icon: NSUIImage?, data: AnyObject?)
    {
        super.init()
        
        self.y = y
        self.icon = icon
        self.data = data
    }
    
    open override func isEqual(_ object: Any?) -> Bool
    {
        if object == nil
        {
            return false
        }
        
        if !(object! as AnyObject).isKind(of: type(of: self))
        {
            return false
        }
        
        if ((object! as AnyObject).data === nil && self.data != nil) || ((object! as AnyObject).data !== nil && self.data == nil) {
            return false
        }
        
        if ((object! as AnyObject).plotData === nil && self.plotData != nil) || ((object! as AnyObject).plotData !== nil && self.plotData == nil) {
            return false
        }
        
        if ((object! as AnyObject).data !== nil && self.data != nil) && (object! as AnyObject).data !== data && !((object! as AnyObject).data??.isEqual(self.data))!
        {
            return false
        }
        
        if ((object! as AnyObject).plotData !== nil && self.plotData != nil) && (object! as AnyObject).plotData !== plotData && !((object! as AnyObject).plotData??.isEqual(self.plotData))!
        {
            return false
        }
        
        if fabs((object! as AnyObject).y - y) > Double.ulpOfOne
        {
            return false
        }
        
        return true
    }
    
    enum CodingKeys: CodingKey {
               case y
           }
    
    required public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        y = try container.decode(Double.self, forKey: .y)
    }
    
    public func encode(to encoder: Encoder) throws {
        
    }
    
    
}

public func ==(lhs: ChartDataEntryBase, rhs: ChartDataEntryBase) -> Bool
{
    if lhs === rhs
    {
        return true
    }
    
    if !lhs.isKind(of: type(of: rhs))
    {
        return false
    }
    
    if lhs.data !== rhs.data && !lhs.data!.isEqual(rhs.data)
    {
        return false
    }
    
    if lhs.plotData !== rhs.plotData && !lhs.plotData!.isEqual(rhs.plotData)
    {
        return false
    }
    
    if fabs(lhs.y - rhs.y) > Double.ulpOfOne
    {
        return false
    }
    
    return true
}
