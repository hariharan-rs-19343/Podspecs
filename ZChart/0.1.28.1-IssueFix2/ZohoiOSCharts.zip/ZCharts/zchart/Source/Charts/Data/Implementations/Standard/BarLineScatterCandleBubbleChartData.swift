//
//  BarLineScatterCandleBubbleChartData.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

/*open class BarLineScatterCandleBubbleChartData: ChartData
{
    open var minimumShapeSizeInPixel = CGFloat(0)
    
    open var maximumShapeSizeInPixel = CGFloat(0)

    open var maxWidthZoomRestrictionPixel = CGFloat.greatestFiniteMagnitude

    public required init()
    {
        super.init()
    }
    
    public override init(dataSets: [IChartDataSet]?)
    {
        super.init(dataSets: dataSets)
    }
    
   @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! BarLineScatterCandleBubbleChartData
        
        copy.maxWidthZoomRestrictionPixel = maxWidthZoomRestrictionPixel

        return copy
    }

}*/
