//
//  ChartDataEntry.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

open class ChartDataEntry: ChartDataEntryBase
{
    // MARK: General Properties
    
    open var childEntries:[ChartDataEntry] = []

    /// the x value
    @objc open var x = Double(0.0)
    
    /// xString value
    open var xString:String? = nil
    
    /// string data value for colorAxis
    open var colorString:String? = nil
    
    ///  data value for colorAxis
    open var colorValue:Double? = nil
    
    open override var description: String
    {
        return "ChartDataEntry, x: \(x), y \(y)"
    }
    
    open var entryColor:NSUIColor = NSUIColor.clear
    
    open var oldValue:Double?
    
    /// The size of the bubble.
    open var size: CGFloat?
    
    // MARK: -  LevelMarker Properties
       
       fileprivate  var _levelMarker: [Double]?
       
       fileprivate var _targetMarker: Double?
       
       fileprivate var _yMax: Double = 0
       
       fileprivate var _yMin: Double = 0
       
    // MARK: Accessors
      
      open var levelMarker: [Double]?
      {
          get { return self._levelMarker }
          set
          {
              self._levelMarker = newValue
              calcPosNegMax()
          }
      }
      
      open var targetMarker: Double?
      {
          get { return self._targetMarker }
          set{
              self._targetMarker = newValue
              calcPosNegMax()
          }
      }

      open var yMax: Double
      {
          return _yMax
      }
      
      open var yMin: Double
      {
          return _yMin
      }
    
    // MARK: Initializer
    
    public required init()
    {
        super.init()
    }
    
    /// An Entry represents one single entry in the chart.
    /// - parameter x: the x value
    /// - parameter y: the y value (the actual value of the entry)
    public init(x: Double, y: Double)
    {
        super.init(y: y)
        
        self.x = x
        
        // To retain old value
        self.oldValue = y
    }
    
    /// An Entry represents one single entry in the chart.
    /// - parameter x: the x value
    /// - parameter y: the y value (the actual value of the entry)
    /// - parameter data: Space for additional data this Entry represents.
    
    public init(x: Double, y: Double, data: AnyObject?)
    {
        super.init(y: y)
        
        self.x = x
        
        self.data = data
        
        // To retain old value
        self.oldValue = y
    }
    
    public init(x: Double, y: Double, y0: Double,  data: AnyObject?)
    {
        super.init(y: y, y0: y0, data: data)
        
        self.x = x
        
        // To retain old value
        self.oldValue = y
    }
    
    /// An Entry represents one single entry in the chart.
    /// - parameter x: the x value
    /// - parameter y: the y value (the actual value of the entry)
    /// - parameter icon: icon image
    
    public init(x: Double, y: Double, icon: NSUIImage?)
    {
        super.init(y: y, icon: icon)
        
        self.x = x
        
        // To retain old value
        self.oldValue = y
    }
    
    /// An Entry represents one single entry in the chart.
    /// - parameter x: the x value
    /// - parameter y: the y value (the actual value of the entry)
    /// - parameter icon: icon image
    /// - parameter data: Space for additional data this Entry represents.
    
    public init(x: Double, y: Double, icon: NSUIImage?, data: AnyObject?)
    {
        super.init(y: y, icon: icon, data: data)
        
        // To retain old value
        self.oldValue = y

        self.x = x
    }
    
    
    public init(x: Double, yString: String?, data: AnyObject?)
    {
        super.init(yString: yString, data: data)
        
        self.x = x
        
        self.y = Double.leastNormalMagnitude
        
    }
    
    public init(xString: String?, y: Double, data: AnyObject?)
    {
        super.init(y: y, data: data)
        
        self.x = Double.leastNormalMagnitude
        
        self.xString = xString
        
        // To retain old value
        self.oldValue = y
    }
    
    public init(xString: String?, y: Double, y0: Double,  data: AnyObject?)
    {
        super.init(y: y, y0: y0, data: data)
        
        self.x = Double.leastNormalMagnitude
        
        self.xString = xString
        
        // To retain old value
        self.oldValue = y
    }
    
    public init(xString: String?, yString: String?, data: AnyObject?)
    {
        super.init(yString: yString, data: data)
        
        self.xString = xString
        
        self.x = Double.leastNormalMagnitude
        
        self.y = Double.leastNormalMagnitude
        
    }
    
    /// Constructor for Bullet bar entries.
    public convenience init(x: Double, y: Double, levelMarker: [Double]?, targetMarker: Double?, data: AnyObject?)
       {
          self.init(x: x, y: y, data: data)
           self._levelMarker = levelMarker
           self._targetMarker = targetMarker
           calcPosNegMax()
           
        // To retain old value
            self.oldValue = y
       }
       
    public convenience init(xString: String?, y: Double, levelMarker: [Double]?, targetMarker: Double?, data: AnyObject?)
       {
           self.init(xString: xString, y: y, data: data)
           self._levelMarker = levelMarker
           self._targetMarker = targetMarker
           calcPosNegMax()
        // To retain old value
        self.oldValue = y
       }
    
    // MARK: Bubble
       
       /// - parameter x: The index on the x-axis.
       /// - parameter y: The value on the y-axis.
       /// - parameter size: The size of the bubble.
       public convenience init(x: Double, y: Double, size: CGFloat?)
       {
           self.init(x: x, y: y)
           
           self.size = size
       }
       
       /// - parameter x: The index on the x-axis.
       /// - parameter y: The value on the y-axis.
       /// - parameter size: The size of the bubble.
       /// - parameter data: Spot for additional data this Entry represents.
       public convenience init(x: Double, y: Double, size: CGFloat?, data: AnyObject?)
       {
           self.init(x: x, y: y, data: data)
           
           self.size = size
       }
       
       /// - parameter x: The index on the x-axis.
       /// - parameter y: The value on the y-axis.
       /// - parameter size: The size of the bubble.
       /// - parameter icon: icon image
       public convenience init(x: Double, y: Double, size: CGFloat?, icon: NSUIImage?)
       {
           self.init(x: x, y: y, icon: icon)
           
           self.size = size
       }
       
       /// - parameter x: The index on the x-axis.
       /// - parameter y: The value on the y-axis.
       /// - parameter size: The size of the bubble.
       /// - parameter icon: icon image
       /// - parameter data: Spot for additional data this Entry represents.
       public convenience init(x: Double, y: Double, size: CGFloat?, icon: NSUIImage?, data: AnyObject?)
       {
           self.init(x: x, y: y, icon: icon, data: data)
           
           self.size = size
       }
       
    
       /// - parameter xString: Category string on the x-axis.
       /// - parameter y: The value on the y-axis.
       /// - parameter size: The size of the bubble.
       /// - parameter data: Spot for additional data this Entry represents.
       public convenience init(xString: String?, y: Double, size: CGFloat?, data: AnyObject?) {
           
           self.init(xString: xString, y: y, data: data)
           
           self.size = size
       }
       
       
       /// - parameter x: The index on the x-axis.
       /// - parameter yString: Category string on the y-axis.
       /// - parameter size: The size of the bubble.
       /// - parameter data: Spot for additional data this Entry represents.
       public convenience init(x: Double, yString: String?,size: CGFloat?, data: AnyObject?) {
           self.init(x: x, yString: yString, data: data)
           
           self.size = size
       }
       
       
       /// - parameter xString: Category string on the x-axis.
       /// - parameter yString: Category string on the y-axis.
       /// - parameter size: The size of the bubble.
       /// - parameter data: Spot for additional data this Entry represents.
       public convenience init(xString: String?, yString: String?, size: CGFloat?, data: AnyObject?) {
           self.init(xString: xString, yString: yString, data: data)
           
           self.size = size
       }
    
    // MARK: Bubble-Pie
    
        /// - parameter x: The index on the x-axis.
        /// - parameter y: The value on the y-axis.
        /// - parameter size: The size of the bubble.
        /// - parameter data: Spot for additional data this Entry represents.
    public convenience init(x: Double, y: Double, size: CGFloat?, plotData:AnyObject?, data: AnyObject?)
        {
            self.init(x: x, y: y, data: data)
            
            self.size = size
            self.plotData = plotData
        }
    
        /// - parameter xString: Category string on the x-axis.
        /// - parameter y: The value on the y-axis.
        /// - parameter size: The size of the bubble.
        /// - parameter data: Spot for additional data this Entry represents.
        public convenience init(xString: String?, y: Double, size: CGFloat?, plotData:AnyObject?, data: AnyObject?) {
            
            self.init(xString: xString, y: y, data: data)
            
            self.size = size
            self.plotData = plotData
        }
        
        
        /// - parameter x: The index on the x-axis.
        /// - parameter yString: Category string on the y-axis.
        /// - parameter size: The size of the bubble.
        /// - parameter data: Spot for additional data this Entry represents.
        public convenience init(x: Double, yString: String?,size: CGFloat?, plotData:AnyObject?, data: AnyObject?) {
            self.init(x: x, yString: yString, data: data)
            
            self.size = size
            self.plotData = plotData
        }
    
    // MARK: WaterFall
    
        /// - parameter xString: Category string on the x-axis.
        /// - parameter yString: Category string on the y-axis.
        /// - parameter size: The size of the bubble.
        /// - parameter data: Spot for additional data this Entry represents.
    public convenience init(xString: String?, yString: String?, size: CGFloat?, plotData: AnyObject?, data: AnyObject?) {
            self.init(xString: xString, yString: yString, data: data)
            
            self.size = size
            self.plotData = plotData
        }
    
        /// - parameter xString: Category string on the x-axis.
        /// - parameter y: The value on the y-axis.
        /// - parameter data: Spot for additional data this Entry represents.
        public convenience init(xString: String?, y: Double, plotData:AnyObject?, data: AnyObject?) {
        
            self.init(xString: xString, y: y, data: data)
        
            self.plotData = plotData
        }
    
        /// - parameter x: The index on the x-axis.
        /// - parameter yString: Category string on the y-axis.
        /// - parameter data: Spot for additional data this Entry represents.
        public convenience init(x: Double, yString: String?, plotData:AnyObject?, data: AnyObject?) {
            self.init(x: x, yString: yString, data: data)
            
            self.plotData = plotData
        }
    
        /// - parameter xString: Category string on the x-axis.
        /// - parameter yString: Category string on the y-axis.
        /// - parameter data: Spot for additional data this Entry represents.
        public convenience init(xString: String?, yString: String?, plotData: AnyObject?, data: AnyObject?) {
        
            self.init(xString: xString, yString: yString, data: data)
            
            self.plotData = plotData
        }
    
    // MARK: BoxPlot
    public init(xString: String?, y: Double, y0: Double,  plotData: AnyObject?, data: AnyObject?)
        {
            super.init(y: y, y0: y0, data: data)
            
            self.x = Double.leastNormalMagnitude
            
            self.xString = xString
            
            self.plotData = plotData
            
            // To retain old value
            self.oldValue = y
        }
       
    // MARK: - MinMax Calculation
      
      open func calcPosNegMax()
      {
          var negMax:Double = 0
          var posMax:Double = 0
          
          levelMarkerIf: if _levelMarker != nil
          {
              guard let max = _levelMarker!.max(),
              let min = _levelMarker!.min()
                  else { break levelMarkerIf }
              
              let maxLevel = max
              let minLevel = min
              
              if maxLevel > posMax
              {
                  posMax = maxLevel
              }
              
              if minLevel < negMax
              {
                  negMax = minLevel
              }
              
          }
          
          if _targetMarker != nil
          {
              if _targetMarker! > posMax
              {
                  posMax = _targetMarker!
              }
              
              if _targetMarker! < negMax
              {
                  negMax = _targetMarker!
              }
          }
          
          if self.y > posMax
          {
              posMax = self.y
          }
          
          if self.y < negMax
          {
              negMax = self.y
          }
          
          self._yMax = posMax
          self._yMin = negMax
      }
    
    // MARK: NSObject
    
    open override func isEqual(_ object: Any?) -> Bool
    {
        if !super.isEqual(object)
        {
            return false
        }
        
        if fabs((object! as AnyObject).x - x) > Double.ulpOfOne
        {
            return false
        }
        
        return true
    }
    
    // MARK: NSCopying
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = type(of: self).init()
        
        copy.x = x
        copy.y = y
        copy.y0 = y0
        copy.data = data
        copy.plotData = plotData
        copy.origIndex = origIndex
        copy.origX = origX
        copy.origY = origY
        copy.oldValue = y
        copy.xString = xString
        copy.yString = yString
        copy.colorValue = colorValue
        copy.colorString = colorString
        
        copy._levelMarker = _levelMarker
        copy._targetMarker = _targetMarker
        copy._yMax = _yMax
        copy._yMin = _yMin
        
        copy.size = size
        
        return copy
    }
    
    // MARK: Codable
    
    enum chartDataEntryCodingKeys: CodingKey {
                case x
                case y
                case y0
                case xString
                case yString
                case objectData
                case childEntries
                case tempData
           }
    
    required public convenience init(from decoder: Decoder) throws {
        let isQAAutomation = decoder.userInfo[ChartViewBase.qaUserInfoKey]
        if (isQAAutomation != nil)
        {
            let container = try decoder.container(keyedBy: chartDataEntryCodingKeys.self)
            var xString = container.contains(.xString) ? try container.decode(String.self, forKey: .xString) : nil
            var yString = container.contains(.yString) ? try container.decode(String.self, forKey: .yString) : nil
            
            var x:Double = 0
            var y:Double = 0
            var y0:Double = 0
            
            let xOrdinal = xString != nil
            let yOrdinal = yString != nil
            
            if (try? container.decode(String.self, forKey: .x)) != nil
            {
                xString = nil
            }
            else{
                x = try container.decode(Double.self, forKey: .x)
            }
            
            if (try? container.decode(String.self, forKey: .y)) != nil
            {
                yString = nil
            }
            else{
                y = try container.decode(Double.self, forKey: .y)
            }
            
            if (try? container.decode(Double.self, forKey: .y0)) != nil
            {
                y0 = try container.decode(Double.self, forKey: .y0)
            }
            
            
            var unKeyedContainer = try container.nestedUnkeyedContainer(forKey: .objectData)
            
            var dataObject:[Any] = []
            
            while !unKeyedContainer.isAtEnd {
                        if let value = try? unKeyedContainer.decode(Bool.self) {
                            dataObject.append(value)
                        } else if let value = try? unKeyedContainer.decode(Double.self) {
                            dataObject.append(value)
                        } else if let value = try? unKeyedContainer.decode(String.self) {
                            dataObject.append(value)
                        } else if let value = try? unKeyedContainer.decode([Double].self) {
                            dataObject.append(value)
                        }
    //                    } else if let value = try? container.nestedContainer(keyedBy: JSONCodingKeys.self) {
    //                        arr.append(JSON(from: value))
    //                    } else if let value = try? container.nestedUnkeyedContainer() {
    //                        arr.append(JSON(from: value))
    //                    }
            }
            
            
            
    //        let xOrdinal = xString != nil
    //        let yOrdinal = yString != nil
            
            switch (xOrdinal,yOrdinal) {
                case (true,true):
                    self.init(xString: xString, yString: yString, data: nil)
                    break
                    
                case (true,false):
                    self.init(xString: xString, y: y, y0: y0, data: nil)
                    break
                    
                case (false,true):
                    self.init(x: x, yString: yString, data: nil)
                    break
                    
                case (false,false):
                    self.init(x: x, y: y, y0:y0, data: nil)
                    break
            }
            
            data = dataObject as AnyObject
            
            if dataObject.count > 1 {
                plotData = dataObject[1] as AnyObject
            }
            else{
                plotData = dataObject as AnyObject
            }
            
            childEntries = container.contains(.childEntries) ?  try container.decode([ChartDataEntry].self, forKey: .childEntries) : []
        }
        else
        {
            let container = try decoder.container(keyedBy: chartDataEntryCodingKeys.self)
            var xString = container.contains(.xString) ? try container.decode(String.self, forKey: .xString) : nil
            var yString = container.contains(.yString) && ((try? container.decode(String.self, forKey: .yString)) != nil) ? try container.decode(String.self, forKey: .yString) : nil
            
            var x:Double = 0
            var y:Double = 0
            var y0:Double = 0
            
            let xOrdinal = xString != nil
            let yOrdinal = yString != nil
            
            if (try? container.decode(String.self, forKey: .x)) != nil
            {
                xString = nil
            }
            else{
                if (try? container.decode(Double.self, forKey: .x)) != nil
                {
                    x = try container.decode(Double.self, forKey: .x)
                }
            }
            
            if (try? container.decode(String.self, forKey: .y)) != nil
            {
                yString = nil
            }
            else{
                if (try? container.decode(Double.self, forKey: .y)) != nil
                {
                    y = try container.decode(Double.self, forKey: .y)
                }
            }
            
            if (try? container.decode(Double.self, forKey: .y0)) != nil
            {
                y0 = try container.decode(Double.self, forKey: .y0)
            }
            
            var myDataClass = try container.decode(MyData.self, forKey: .tempData)
            
            
            
    //        var unKeyedContainer = try dataContainer.nestedUnkeyedContainer(forKey: .tempData)
            
            var dataObject:[Any] = []
            
    //        while !unKeyedContainer.isAtEnd {
    //            if let value = try? unKeyedContainer.decode(Bool.self) {
    //                dataObject.append(value)
    //            } else if let value = try? unKeyedContainer.decode(Double.self) {
    //                dataObject.append(value)
    //            } else if let value = try? unKeyedContainer.decode(String.self) {
    //                dataObject.append(value)
    //            } else if let value = try? unKeyedContainer.decode([Double].self) {
    //                dataObject.append(value)
    //            }
    //            //                    } else if let value = try? container.nestedContainer(keyedBy: JSONCodingKeys.self) {
    //            //                        arr.append(JSON(from: value))
    //            //                    } else if let value = try? container.nestedUnkeyedContainer() {
    //            //                        arr.append(JSON(from: value))
    //            //                    }
    //        }
                
            
            /*var unKeyedContainer = try container.nestedUnkeyedContainer(forKey: .objectData)
            
            var dataObject:[Any] = []
            
            while !unKeyedContainer.isAtEnd {
                        if let value = try? unKeyedContainer.decode(Bool.self) {
                            dataObject.append(value)
                        } else if let value = try? unKeyedContainer.decode(Double.self) {
                            dataObject.append(value)
                        } else if let value = try? unKeyedContainer.decode(String.self) {
                            dataObject.append(value)
                        } else if let value = try? unKeyedContainer.decode([Double].self) {
                            dataObject.append(value)
                        }
    //                    } else if let value = try? container.nestedContainer(keyedBy: JSONCodingKeys.self) {
    //                        arr.append(JSON(from: value))
    //                    } else if let value = try? container.nestedUnkeyedContainer() {
    //                        arr.append(JSON(from: value))
    //                    }
            }*/
            
            
            
    //        let xOrdinal = xString != nil
    //        let yOrdinal = yString != nil
            
            switch (xOrdinal,yOrdinal) {
                case (true,true):
                    self.init(xString: xString, yString: yString, data: nil)
                    break
                    
                case (true,false):
                    self.init(xString: xString, y: y, y0: y0, data: nil)
                    break
                    
                case (false,true):
                    self.init(x: x, yString: yString, data: nil)
                    break
                    
                case (false,false):
                    self.init(x: x, y: y, y0:y0, data: nil)
                    break
            }
            
            if (try? container.decode(Double.self, forKey: .x)) != nil
            {
                self.x = try container.decode(Double.self, forKey: .x)
            }
            else //if (try? container.decode(String.self, forKey: .x)) != nil
            {
                self.x = Double.nan
            }
            
            if (try? container.decode(Double.self, forKey: .y)) != nil
            {
                self.y = try container.decode(Double.self, forKey: .y)
            }
            else //if (try? container.decode(String.self, forKey: .y)) != nil
            {
                self.y = Double.nan
            }
            
            if (try? container.decode(String.self, forKey: .xString)) != nil
            {
                self.xString = (try container.decode(String.self, forKey: .xString)) == "null" ? nil : (try container.decode(String.self, forKey: .xString))
            }
            else{
                self.xString = nil
            }
            
            if (try? container.decode(String.self, forKey: .yString)) != nil
            {
                self.yString = (try container.decode(String.self, forKey: .yString)) == "null" ? nil : (try container.decode(String.self, forKey: .yString))
            }
            else{
                self.yString = nil
            }
            
            data = myDataClass.myDictionary as AnyObject
            /*data = dataObject as AnyObject
            
            if dataObject.count > 1 {
                plotData = dataObject[1] as AnyObject
            }
            else{
                plotData = dataObject as AnyObject
            }*/
            
            childEntries = container.contains(.childEntries) ?  try container.decode([ChartDataEntry].self, forKey: .childEntries) : []
            
        }
        
    }
    
    public override func encode(to encoder: Encoder) throws {

    }
}

struct MyData: Decodable {
    var myDictionary: [Any]

    enum DataCodingKeys:CodingKey, CaseIterable {
        case d0
        case d1
        case d2
        case d3
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: DataCodingKeys.self)
        
        var dataObject:[Any] = []
        
        for caseValue in DataCodingKeys.allCases
        {
            if let value = try? container.decode([Double].self, forKey: caseValue)
            {
                dataObject.append(value)
            }
            else if let value = try? container.decode(Double.self, forKey: caseValue)
            {
                dataObject.append(value)
            }
            else if let value = try? container.decode(String.self, forKey: caseValue)
            {
                dataObject.append(value)
            }
            else if container.contains(caseValue) {
                dataObject.append(Double.nan)
            }
        }
        print(dataObject)
    
        myDictionary = dataObject
    }
}

public func ==(lhs: ChartDataEntry, rhs: ChartDataEntry) -> Bool
{
    if lhs === rhs
    {
        return true
    }
    
    if !lhs.isKind(of: type(of: rhs))
    {
        return false
    }
    
    if (lhs.data == nil && rhs.data != nil) || (lhs.data != nil && rhs.data == nil) {
           return false
    }
    
    if (lhs.plotData == nil && rhs.plotData != nil) || (lhs.plotData != nil && rhs.plotData == nil) {
           return false
    }
    
    if lhs.data != nil && rhs.data != nil && lhs.data !== rhs.data && !lhs.data!.isEqual(rhs.data)
    {
        return false
    }
    
    if lhs.plotData != nil && rhs.plotData != nil && lhs.plotData !== rhs.plotData && !lhs.plotData!.isEqual(rhs.plotData)
    {
        return false
    }
    
    if fabs(lhs.x - rhs.x) > Double.ulpOfOne
    {
        return false
    }
    
    if fabs(lhs.y - rhs.y) > Double.ulpOfOne
    {
        return false
    }
    
    return true
}
