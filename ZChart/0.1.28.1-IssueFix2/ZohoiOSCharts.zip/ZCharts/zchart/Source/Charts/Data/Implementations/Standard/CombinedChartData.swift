//
//  CombinedChartData.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

/*open class CombinedChartData: ChartData
{
    fileprivate var _candleData: CandleChartData!
    
    public required init()
    {
        super.init()
    }
    
    public override init(dataSets: [IChartDataSet]?)
    {
        super.init(dataSets: dataSets)
    }
    
 /*   open override func updateXYValues()
    {
        var leftYAxisOrdinal:Bool!
        var rightYAxisOrdinal:Bool!
        
        
        if oneTime{
            
            oneTime = false
            
            xOrdinal = allData[0].xOrdinal
            
            for data in allData
            {
                if data.yOrdinal[.left] != nil
                {
                    yOrdinal[.left] = data.yOrdinal[.left]
                }
                
                if data.yOrdinal[.right] != nil
                {
                    yOrdinal[.right] = data.yOrdinal[.right]
                }
            }
            
            leftYAxisOrdinal = (yOrdinal[YAxis.AxisDependency.left]) != nil && (yOrdinal[YAxis.AxisDependency.left])!
            rightYAxisOrdinal = (yOrdinal[YAxis.AxisDependency.right]) != nil && (yOrdinal[YAxis.AxisDependency.right])!
            
            if xOrdinal
            {
                xString = [String]()
            }
            
            if ( leftYAxisOrdinal || rightYAxisOrdinal )
            {
                yString = [:]
                
                if leftYAxisOrdinal
                {
                    yString?[YAxis.AxisDependency.left] = [String]()
                }
                if rightYAxisOrdinal
                {
                    yString?[YAxis.AxisDependency.right] = [String]()
                }
            }
        }
        
        leftYAxisOrdinal = (yOrdinal[YAxis.AxisDependency.left]) != nil && (yOrdinal[YAxis.AxisDependency.left])!
        rightYAxisOrdinal = (yOrdinal[YAxis.AxisDependency.right]) != nil && (yOrdinal[YAxis.AxisDependency.right])!
        
        if xOrdinal && ( leftYAxisOrdinal || rightYAxisOrdinal )
        {
            prepareXValues()
            prepareYValues()
        }
        else if xOrdinal
        {
            prepareXValues()
        }
        else if ( leftYAxisOrdinal || rightYAxisOrdinal )
        {
            prepareYValues()
        }
        
        for set in _dataSets
        {
            set.calcMinMax()
        }
        
    }*/
    
    open var candleData: CandleChartData!
    {
        get
        {
            return _candleData
        }
        set
        {
            _candleData = newValue
            initialize(dataSets: _candleData.dataSets)
        }
    }
    
    open override func calcMinMax()
    {
        _dataSets.removeAll()
        
        _yMax = -Double.greatestFiniteMagnitude
        _yMin = Double.greatestFiniteMagnitude
        _xMax = -Double.greatestFiniteMagnitude
        _xMin = Double.greatestFiniteMagnitude
        
        /*_leftAxisMax = -Double.greatestFiniteMagnitude
        _leftAxisMin = Double.greatestFiniteMagnitude
        _rightAxisMax = -Double.greatestFiniteMagnitude
        _rightAxisMin = Double.greatestFiniteMagnitude*/
        
        let allData = self.allData
        
        for data in allData
        {
            let sets = data.dataSets
            _dataSets.append(contentsOf: sets)
        }
        
        initAxisMinAndMaxArrays()
        
        for data in allData
        {
            data.calcMinMax()
            
//            let sets = data.dataSets
//            _dataSets.append(contentsOf: sets)
            
            if data.yMax > _yMax
            {
                _yMax = data.yMax
            }
            
            if data.yMin < _yMin
            {
                _yMin = data.yMin
            }
            
            if data.xMax > _xMax
            {
                _xMax = data.xMax
            }
            
            if data.xMin < _xMin
            {
                _xMin = data.xMin
            }
            
            /// Since calcMinMax() calculated for all the data,compare directly with that property
            /// New Code
            
            for (axisIndex, _) in _yAxisMinArray {
                
                if data._yAxisMaxArray[axisIndex] != nil && data._yAxisMaxArray[axisIndex]! > _yAxisMaxArray[axisIndex]!
                {
                    _yAxisMaxArray[axisIndex] = data.getYMax(axisIndex: axisIndex)
                }
                
                if  data._yAxisMinArray[axisIndex] != nil && data._yAxisMinArray[axisIndex]! < _yAxisMinArray[axisIndex]!
                {
                    _yAxisMinArray[axisIndex] = data.getYMin(axisIndex: axisIndex)
                }
            }
            
            /*if data._leftAxisMax > _leftAxisMax
            {
                _leftAxisMax = data.getYMax(axis: .left)
            }
            
            if data._leftAxisMin < _leftAxisMin
            {
                _leftAxisMin = data.getYMin(axis: .left)
            }
            
            if data._rightAxisMax > _rightAxisMax
            {
                _rightAxisMax = data.getYMax(axis: .right)
            }
            
            if data._rightAxisMin < _rightAxisMin
            {
                _rightAxisMin = data.getYMin(axis: .right)
            }
            
            for (axisIndex, _) in _leftAxisMinArray {
                
                if data._leftAxisMaxArray[axisIndex] != nil && data._leftAxisMaxArray[axisIndex]! > _leftAxisMaxArray[axisIndex]!
                {
                    _leftAxisMaxArray[axisIndex] = data.getYMax(axis: .left, axisIndex: axisIndex)
                }
                
                if  data._leftAxisMinArray[axisIndex] != nil && data._leftAxisMinArray[axisIndex]! < _leftAxisMinArray[axisIndex]!
                {
                    _leftAxisMinArray[axisIndex] = data.getYMin(axis: .left, axisIndex: axisIndex)
                }
            }
            
            for (axisIndex, _) in _rightAxisMinArray {
                
                if data._rightAxisMaxArray[axisIndex] != nil && data._rightAxisMaxArray[axisIndex]! > _rightAxisMaxArray[axisIndex]!
                {
                    _rightAxisMaxArray[axisIndex] = data.getYMax(axis: .right, axisIndex: axisIndex)
                }
                
                if  data._rightAxisMinArray[axisIndex] != nil && data._rightAxisMinArray[axisIndex]! < _rightAxisMinArray[axisIndex]!
                {
                    _rightAxisMinArray[axisIndex] = data.getYMin(axis: .right, axisIndex: axisIndex)
                }
            }*/
        }
    }
    
    /// - returns: All data objects in row: line-bar-scatter-candle-bubble if not null.
    open var allData: [ChartData]
    {
        var data = [ChartData]()
        
        if candleData !== nil
        {
            data.append(candleData)
        }
        
        return data
    }
    
    open func dataByIndex(_ index: Int) -> ChartData
    {
        return allData[index]
    }
    
    open func dataIndex(_ data: ChartData) -> Int?
    {
        return allData.firstIndex(of: data)
    }
    
    open override func removeDataSet(_ dataSet: IChartDataSet!) -> Bool
    {
        let datas = allData
        
        var success = false
        
        for data in datas
        {
            success = data.removeDataSet(dataSet)
            
            if success
            {
                break
            }
        }
        
        return success
    }
    
    open override func removeDataSetByIndex(_ index: Int) -> Bool
    {
        print("removeDataSet(index) not supported for CombinedData", terminator: "\n")
        return false
    }
    
    open override func removeEntry(_ entry: ChartDataEntry, dataSetIndex: Int) -> Bool
    {
        print("removeEntry(entry, dataSetIndex) not supported for CombinedData", terminator: "\n")
        return false
    }
    
    open override func removeEntry(xValue: Double, dataSetIndex: Int) -> Bool
    {
        print("removeEntry(xValue, dataSetIndex) not supported for CombinedData", terminator: "\n")
        return false
    }
    
    open override func notifyDataChanged()
    {
        if _candleData !== nil
        {
            _candleData.notifyDataChanged()
        }
        
        super.notifyDataChanged() // recalculate everything
    }
    
    
    /*/// Get the Entry for a corresponding highlight object
    ///
    /// - parameter highlight:
    /// - returns: The entry that is highlighted
    open override func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry?
    {
        let dataObjects = allData
        
        if highlight.dataIndex >= dataObjects.count
        {
            return nil
        }
        
        let data = dataObjects[highlight.dataIndex]
        
        if highlight.dataSetIndex >= data.dataSetCount
        {
            return nil
        }
        else
        {
            // The value of the highlighted entry could be NaN - if we are not interested in highlighting a specific value.
            let entries = data.getDataSetByIndex(highlight.dataSetIndex).entriesForXValue(highlight.x)
            for e in entries
            {
                if e.y == highlight.y || highlight.y.isNaN
                {
                    return e
                }
            }
            
            return nil
        }
    }*/
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! CombinedChartData
        
        return copy
    }
    
    open override func updateXYValues()
    {
        
        if oneTime{
            
            oneTime = false
            
            xOrdinal = allData[0].xOrdinal
            
            /*for data in allData
            {
                
                for (axisDependency, ordinalEnabledMap) in data.yOrdinal {
                    if ordinalEnabledMap.count > 0 {
                        if yOrdinal[axisDependency] == nil {
                            yOrdinal[axisDependency] = [Int:Bool]()
                        }
                        
                        for (axisIndex,enabled) in ordinalEnabledMap {
                            yOrdinal[axisDependency]![axisIndex] = enabled
                        }
                    }
                }
            }*/
            
            for data in allData
            {
                for (axisIndex,enabled) in data.yOrdinal {
                    yOrdinal[axisIndex] = enabled
                }            
            }
            
            initializeOrdinalStringMap()
            
        }
        
        if xOrdinal {
            prepareXValues()
        }
        
        if yOrdinal.count > 0 {
            prepareYValues()
        }
        
        for set in _dataSets
        {
            set.calcMinMax()
        }
    }
}*/
