//
//  ChartDataSet.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

/// Determines how to round DataSet index values for `ChartDataSet.entryIndex(x, rounding)` when an exact x-value is not found.
@objc
public enum ChartDataSetRounding: Int
{
    case up = 0
    case down = 1
    case closest = 2
}

/// The DataSet class represents one group or type of entries (Entry) in the Chart that belong together.
/// It is designed to logically separate different groups of values inside the Chart (e.g. the values for a specific line in the LineChart, or the values of a specific group of bars in the BarChart).
open class ChartDataSet: ChartBaseDataSet, Codable
{
    public required init()
    {
        super.init()
        
        _values = [ChartDataEntry]()
    }
    
    public override init(label: String?)
    {
        super.init(label: label)
        
        _values = [ChartDataEntry]()
    }
    
    public init(values: [ChartDataEntry]?, label: String?)
    {
        super.init(label: label)
        
        _values = values == nil ? [ChartDataEntry]() : values
        
        self.calcMinMax()
    }
    
    public convenience init(values: [ChartDataEntry]?)
    {
        self.init(values: values, label: "DataSet")
    }
    
    // MARK: - Data functions and accessors
    
    /// the entries that this dataset represents / holds together
    internal var _values: [ChartDataEntry]!
    
    /// maximum y-value in the value array
    internal var _yMax: Double = -Double.greatestFiniteMagnitude
    
    /// minimum y-value in the value array
    internal var _yMin: Double = Double.greatestFiniteMagnitude
    
    /// maximum x-value in the value array
    internal var _xMax: Double = -Double.greatestFiniteMagnitude
    
    /// minimum x-value in the value array
    internal var _xMin: Double = Double.greatestFiniteMagnitude
    
    /// maximum size in the value array
    internal var _maxSize = -Double.greatestFiniteMagnitude
    
    /// minimum size in the value array
    internal var _minSize = 0.0//Double.greatestFiniteMagnitude
    
    /// *
    /// - note: Calls `notifyDataSetChanged()` after setting a new value.
    /// - returns: The array of y-values that this DataSet represents.
    open var values: [ChartDataEntry]
    {
        get
        {
            return _values
        }
        set
        {
            _values = newValue
            notifyDataSetChanged()
        }
    }
    
    /// Use this method to tell the data set that the underlying data has changed
    open override func notifyDataSetChanged()
    {
        calcMinMax()
    }
    
    open override func calcMinMax()
    {
        if _values.count == 0
        {
            return
        }
        
        _yMax = -Double.greatestFiniteMagnitude
        _yMin = Double.greatestFiniteMagnitude
        _xMax = -Double.greatestFiniteMagnitude
        _xMin = Double.greatestFiniteMagnitude
        _maxSize = -Double.greatestFiniteMagnitude
        _minSize = 0.0//Double.greatestFiniteMagnitude
        
        for e in _values
        {   if (e.xString != nil && e.x.isNaN) || (e.yString != nil && e.y.isNaN) || e.x.isNaN || e.y.isNaN
            {
                continue
            }
            calcMinMax(entry: e)
        }
        
    }
    
    open override func calcMinMaxY(fromX: Double, toX: Double)
    {
        if _values.count == 0
        {
            return
        }
        
        _yMax = -Double.greatestFiniteMagnitude
        _yMin = Double.greatestFiniteMagnitude
        
        let indexFrom = entryIndex(x: fromX, closestToY: Double.nan, rounding: .down)
        let indexTo = entryIndex(x: toX, closestToY: Double.nan, rounding: .up)
        
        if indexTo < indexFrom || indexTo == -1 || indexFrom == -1 { return }
        
        for i in indexFrom...indexTo
        {
            // only recalculate y
            calcMinMaxY(entry: _values[i])
        }
    }
    
    open func calcMinMaxX(entry e: ChartDataEntry)
    {
        if e.x < _xMin
        {
            _xMin = e.x
        }
        if e.x > _xMax
        {
            _xMax = e.x
        }
    }
    
    open func calcMinMaxY(entry e: ChartDataEntry)
    {
       /* if e.y < _yMin
        {
            _yMin = e.y
        }
        if e.y > _yMax
        {
            _yMax = e.y
        }*/
        
        //Checking both levelMarker or targetMarker
        let minValue = (e.levelMarker != nil || e.targetMarker != nil ) ? e.yMin : (plotType == .LineRange || plotType == .BoxPlot || plotType == .HorizontalBarRange) ? min(e.y,e.y0) : e.y
        let maxValue = (e.levelMarker != nil || e.targetMarker != nil ) ? e.yMax : (plotType == .LineRange || plotType == .BoxPlot || plotType == .HorizontalBarRange) ? max(e.y,e.y0) : e.y
      
        if minValue != Double.leastNormalMagnitude && minValue < _yMin
        {
            _yMin = minValue
        }
        if maxValue != Double.leastNormalMagnitude && maxValue > _yMax
        {
            _yMax = maxValue
        }
    }
    
    open func calcMinMaxSize(entry e:ChartDataEntry)
    {
        if let size = e.size {
            
            if size > _maxSize
            {
                _maxSize = size
            }
            if size < _minSize
            {
                _minSize = size
            }
        }
    }
    
    /// Updates the min and max x and y value of this DataSet based on the given Entry.
    ///
    /// - parameter e:
    internal func calcMinMax(entry e: ChartDataEntry)
    {
        calcMinMaxX(entry: e)
        calcMinMaxY(entry: e)
        calcMinMaxSize(entry: e)
    }
    
    /// - returns: The minimum y-value this DataSet holds
    open override var yMin: Double { return _yMin }
    
    /// - returns: The maximum y-value this DataSet holds
    open override var yMax: Double { return _yMax }
    
    /// - returns: The minimum x-value this DataSet holds
    open override var xMin: Double { return _xMin }
    
    /// - returns: The maximum x-value this DataSet holds
    open override var xMax: Double { return _xMax }
    
    /// - returns: The maximum size this DataSet holds
    open override var maxSize: CGFloat { return _maxSize }
    
    /// - returns: The minimum size this DataSet holds
    open override var minSize: CGFloat { return _minSize }
    
    /// - returns: The number of y-values this DataSet represents
    open override var entryCount: Int { return _values?.count ?? 0 }
    
    /// - returns: The entry object found at the given index (not x-value!)
    /// - throws: out of bounds
    /// if `i` is out of bounds, it may throw an out-of-bounds exception
    open override func entryForIndex(_ i: Int) -> ChartDataEntry?
    {
        guard i >= 0 && i < _values.count else {
            return nil
        }
        return _values[i]
    }
    
    /// - returns: The entry object for the given xString
    /// - throws: out of bounds
    /// if `i` is out of bounds, it may throw an out-of-bounds exception
    open override func entryForString(_ xString: String) -> ChartDataEntry?
    {
        if _values.count > 0
        {
//           return traverseValues(entry: _values[0], xString: xString)
           return traverseAllValues(entries: _values, xString: xString)
        }
        
        return nil
        
    }
    
    fileprivate func traverseAllValues(entries:[ChartDataEntry], xString:String) -> ChartDataEntry?
    {
        if entries.count > 0 {
            for entry in entries {
                if let finalEntry = traverseValues(entry: entry, xString: xString)
                {
                    if (finalEntry.xString != nil && finalEntry.xString == xString) {
                        return finalEntry
                    }
                }
            }
        }
        return nil
    }
    
    open override func entryForPath(_ pathIndex: [Int]) -> ChartDataEntry?
    {
        if _values.count <= 0
        {
            return nil
        }
        var traverseEntry = _values[pathIndex[0]]
        
        for i in 0..<pathIndex.count
        {
            if i == 0
            {
                continue
            }
            
            let path = pathIndex[i]
            
            if traverseEntry.childEntries[safe:path] == nil
            {
                return nil
            }
            traverseEntry = traverseEntry.childEntries[path]
        }
        
        return traverseEntry
        
    }

    fileprivate func traverseValues(entry:ChartDataEntry, xString:String) -> ChartDataEntry?
    {
        if entry.xString != nil && entry.xString == xString
        {
            return entry
        }
        
        for child in entry.childEntries
        {
            if let returnEntry = traverseValues(entry: child, xString: xString)
            {
                return returnEntry
            }
        }
        
        return nil
    }
    
    /// - returns: The first Entry object found at the given x-value with binary search.
    /// If the no Entry at the specified x-value is found, this method returns the Entry at the closest x-value according to the rounding.
    /// nil if no Entry object at that x-value.
    /// - parameter xValue: the x-value
    /// - parameter closestToY: If there are multiple y-values for the specified x-value,
    /// - parameter rounding: determine whether to round up/down/closest if there is no Entry matching the provided x-value
    open override func entryForXValue(
        _ xValue: Double,
        closestToY yValue: Double,
        rounding: ChartDataSetRounding) -> ChartDataEntry?
    {
        let index = self.entryIndex(x: xValue, closestToY: yValue, rounding: rounding)
        if index > -1
        {
            return _values[index]
        }
        return nil
    }
    
    /// - returns: The first Entry object found at the given x-value with binary search.
    /// If the no Entry at the specified x-value is found, this method returns the Entry at the closest x-value.
    /// nil if no Entry object at that x-value.
    /// - parameter xValue: the x-value
    /// - parameter closestToY: If there are multiple y-values for the specified x-value,
    open override func entryForXValue(
        _ xValue: Double,
        closestToY yValue: Double) -> ChartDataEntry?
    {
        return entryForXValue(xValue, closestToY: yValue, rounding: .closest)
    }
    
    /// - returns: All Entry objects found at the given xIndex with binary search.
    /// An empty array if no Entry object at that index.
    open override func entriesForXValue(_ xValue: Double) -> [ChartDataEntry]
    {
        var entries = [ChartDataEntry]()
        
        var low = 0
        var high = _values.count - 1
        
        while low <= high
        {
            var m = (high + low) / 2
            var entry = _values[m]
            
            var curX = entry.x
            
            if curX.isNaN
            {
                let indexPosition = getClosestEntryandIndex(currentIndex: m, closestToIndex: m, closestToX: nil)
                
                guard indexPosition != -1
                    else { return [] }
                
                curX = _values[indexPosition].x
            }
            
            // if we have a match
            if xValue == curX
            {
                if _values[m].x.isNaN
                {
                    m = getClosestEntryandIndex(currentIndex: m, closestToIndex: nil, closestToX: xValue)
                    
                    guard m != -1
                        else { return [] }
                }
                
                var leftMostMValue = m
                
                while m > 0 && (_values[m - 1].x == xValue || _values[m-1].x.isNaN)
                {
                    if !(_values[m-1].x.isNaN)
                    {
                        leftMostMValue = m-1
                    }
                    m -= 1
                }
                
                m = leftMostMValue
                
                high = _values.count
                
                // loop over all "equal" entries
                while m < high
                {
                    entry = _values[m]
                    if entry.x == xValue
                    {
                        entries.append(entry)
                    }
                    else if entry.x.isNaN
                    {
                        m += 1
                        continue
                    }
                    else
                    {
                        break
                    }
                    
                    m += 1
                }
                
                break
            }
            else
            {
                if xValue > curX
                {
                    low = m + 1
                }
                else
                {
                    high = m - 1
                }
            }
        }
        
        return entries
    }
    
    open override func entriesForXYValue(_ xValue: Double,_ yValue: Double) -> [ChartDataEntry]
    {
        let entries = entriesForXValue(xValue)
        
        let entriesWithXY = entries.filter({
            ($0.y == yValue || $0.y.isNaN)
        })
        
        return entriesWithXY
    }
    
    
    
    func getClosestEntryandIndex(currentIndex:Int,closestToIndex:Int?,closestToX:Double?) -> Int
    {
        var entryBeforeClosestWithNoNan:Int? = nil
        var entryAfterClosestWithNoNan:Int? = nil
        
        
        var backIndex = currentIndex-1
        var forwardIndex = currentIndex+1
        
        var closest = 0
        
        while backIndex >= 0
        {
            let entryWithNoNan = _values[backIndex].x
            backIndex -= 1
            
            if !entryWithNoNan.isNaN
            {
                entryBeforeClosestWithNoNan = backIndex + 1
                break
            }
        }
        while forwardIndex < _values.count
        {
            let entryWithNoNan = _values[forwardIndex].x
            forwardIndex += 1
            
            if !entryWithNoNan.isNaN
            {
                entryAfterClosestWithNoNan = forwardIndex - 1
                break
            }
        }
        if entryBeforeClosestWithNoNan == nil{
            guard entryAfterClosestWithNoNan != nil
                else { return -1 }
            closest = entryAfterClosestWithNoNan!
        }
        else if entryAfterClosestWithNoNan == nil
        {
            guard entryBeforeClosestWithNoNan != nil
                else { return -1 }
            closest = entryBeforeClosestWithNoNan!
        }
        else{
            
            if closestToX != nil
            {
                if abs(_values[entryBeforeClosestWithNoNan!].x - closestToX!) < abs(_values[entryAfterClosestWithNoNan!].x - closestToX!)
                {
                    closest = entryBeforeClosestWithNoNan!
                }
                else{
                    closest = entryAfterClosestWithNoNan!
                }
            }
            else if closestToIndex != nil {
                if abs(entryBeforeClosestWithNoNan! - closestToIndex!) < abs(entryAfterClosestWithNoNan! - closestToIndex!)
                {
                    closest = entryBeforeClosestWithNoNan!
                }
                else{
                    closest = entryAfterClosestWithNoNan!
                }
            }
        }
        
        return closest
    }
    
    
    /// - returns: The array-index of the specified entry.
    /// If the no Entry at the specified x-value is found, this method returns the index of the Entry at the closest x-value according to the rounding.
    ///
    /// - parameter xValue: x-value of the entry to search for
    /// - parameter closestToY: If there are multiple y-values for the specified x-value,
    /// - parameter rounding: Rounding method if exact value was not found
    open override func entryIndex(
        x xValue: Double,
        closestToY yValue: Double,
        rounding: ChartDataSetRounding) -> Int
    {
        if xValue.isNaN
        {
            return -1
        }
        
        var low = 0
        var high = _values.count - 1
        var closest = high
        
        while low < high
        {
            let m = (low + high) / 2
            
            var d1 = _values[m].x - xValue
          
            if d1.isNaN
            {
                let indexPosition = getClosestEntryandIndex(currentIndex: m, closestToIndex: m ,closestToX:nil)
                
                guard indexPosition != -1
                    else { return indexPosition }
                
                d1 = _values[indexPosition].x - xValue
            }
            
            var d2 = _values[m + 1].x - xValue
            if d2.isNaN
            {
                d2 = d1
            }
            let ad1 = abs(d1), ad2 = abs(d2)
            
            if ad2 < ad1
            {
                // [m + 1] is closer to xValue
                // Search in an higher place
                low = m + 1
            }
            else if ad1 < ad2
            {
                // [m] is closer to xValue
                // Search in a lower place
                high = m
            }
            else
            {
                // We have multiple sequential x-value with same distance
                
                if d1 >= 0.0
                {
                    // Search in a lower place
                    high = m
                }
                else if d1 < 0.0
                {
                    // Search in an higher place
                    low = m + 1
                }
            }
            
            closest = high
        }
        
        
        if closest != -1 && _values[closest].x.isNaN
        {
            
            closest = getClosestEntryandIndex(currentIndex: closest, closestToIndex: nil, closestToX: xValue)
            
        }
        
        
        if closest != -1
        {
            let closestXValue = _values[closest].x
            
            if rounding == .up
            {
                // If rounding up, and found x-value is lower than specified x, and we can go upper...
                if closestXValue < xValue && closest < _values.count - 1
                {
                    var tempClosest = closest
                    //return non x nan value
                    while closest < _values.count - 1
                    {
                        if _values[closest+1].x.isNaN
                        {
                            closest += 1
                        }
                        else{
                            tempClosest = closest + 1
                            break
                        }
                    }
                    
                    closest = tempClosest
                }
            }
            else if rounding == .down
            {
                // If rounding down, and found x-value is upper than specified x, and we can go lower...
                if closestXValue > xValue && closest > 0
                {
                    var tempClosest = closest
                    //return non x nan value
                    while closest > 0
                    {
                        if _values[closest-1].x.isNaN
                        {
                            closest -= 1
                        }
                        else{
                            tempClosest = closest - 1
                            break
                        }
                    }
                    
                    closest = tempClosest
                }
            }
            
            // Search by closest to y-value
            if !yValue.isNaN
            {
                var validClosest = closest
                
                while closest > 0 && (_values[closest - 1].x == closestXValue || (_values[closest - 1].x.isNaN))
                {
                    if !(_values[closest - 1].x.isNaN)
                    {
                        validClosest = closest - 1
                    }
                    closest -= 1
                }
                
                closest = validClosest
                
                var closestYValue = _values[closest].y
                var closestYIndex = closest
    
                
                while true
                {
                    closest += 1
                    if closest >= _values.count { break }
                    
                    let value = _values[closest]
                    
                    if value.x != closestXValue && !(value.x.isNaN) { break }
                    
                    if value.x.isNaN || value.y.isNaN
                    {
                        continue
                    }
                    
                    if abs(value.y - yValue) < abs(closestYValue - yValue) || closestYValue.isNaN
                    {
                        closestYValue = value.y
                        closestYIndex = closest
                    }
                }
                
                closest = closestYIndex
            }
        }
        
        return closest
    }
    
    /// - returns: The array-index of the specified entry
    ///
    /// - parameter e: the entry to search for
    open override func entryIndex(entry e: ChartDataEntry) -> Int
    {
        for i in 0 ..< _values.count
        {
            if _values[i] === e
            {
                return i
            }
        }
        
        return -1
    }
    
    fileprivate func addXlabel(entry:ChartDataEntry)
    {
        if entry.x == Double.leastNormalMagnitude
        {
            entry.x = Double(self.entryCount)
        }
    }
    
   /// To reset Dataset Entries
   open override func resetEntries(entries e: [ChartDataEntry]) -> Bool
   {
        _values = e
        return true
    
    }
    
    override public func sortEntries(block: ((ChartDataEntry, ChartDataEntry) -> Bool)) -> Bool {
        _values = _values.sorted { (a, b) -> Bool in
            block(a,b)
        }
        return true
    }
    
    /// Adds an Entry to the DataSet dynamically.
    /// Entries are added to the end of the list.
    /// This will also recalculate the current minimum and maximum values of the DataSet and the value-sum.
    /// - parameter e: the entry to add
    /// - returns: True
    open override func addEntry(_ e: ChartDataEntry) -> Bool
    {
        addXlabel(entry: e)
        
        if _values == nil
        {
            _values = [ChartDataEntry]()
        }
        
        calcMinMax(entry: e)
        
        _values.append(e)
        
        return true
    }
    
    /// Adds an Entry to the DataSet dynamically.
    /// Entries are added to their appropriate index respective to it's x-index.
    /// This will also recalculate the current minimum and maximum values of the DataSet and the value-sum.
    /// - parameter e: the entry to add
    /// - returns: True
    open override func addEntryOrdered(_ e: ChartDataEntry) -> Bool
    {
        
        addXlabel(entry: e)
        
        if _values == nil
        {
            _values = [ChartDataEntry]()
        }
        
        calcMinMax(entry: e)
        
        if _values.count > 0
        {
            var lastNotNanIndex = _values.count-1
            
            while lastNotNanIndex >= 0 && _values[lastNotNanIndex].x.isNaN
            {
                lastNotNanIndex -= 1
            }
            if lastNotNanIndex == -1
            {
                _values.append(e)
                return true
            }
            
            if _values[lastNotNanIndex].x > e.x{
                
                var closestIndex = entryIndex(x: e.x, closestToY: e.y, rounding: .up)
                while _values[closestIndex].x < e.x
                {
                    closestIndex += 1
                }
                _values.insert(e, at: closestIndex)
            }
            else{
                _values.append(e)
            }
            
        }
        else
        {
            _values.append(e)
        }
        
        return true
    }
    
    /// Removes an Entry from the DataSet dynamically.
    /// This will also recalculate the current minimum and maximum values of the DataSet and the value-sum.
    /// - parameter entry: the entry to remove
    /// - returns: `true` if the entry was removed successfully, else if the entry does not exist
    open override func removeEntry(_ entry: ChartDataEntry) -> Bool
    {
        var removed = false
        
        for i in 0 ..< _values.count
        {
            if _values[i] === entry
            {
                _values.remove(at: i)
                removed = true
                break
            }
        }
        
        if removed
        {
            calcMinMax()
        }
        
        return removed
    }
    
    // To remove entry orderly
    open override func removeEntryOrdered(_ entry: ChartDataEntry) -> Bool
    {
        var removed = false
        
        for i in 0 ..< _values.count
        {
            if _values[i] === entry
            {
                _values.remove(at: i)
                removed = true
                for j in (i) ..< _values.count
                {
                    _values[j].x = _values[j].x - 1
                }
                break
            }
        }
        
        if removed
        {
            calcMinMax()
        }
        
        return removed
    }
    
    /// Removes the first Entry (at index 0) of this DataSet from the entries array.
    ///
    /// - returns: `true` if successful, `false` ifnot.
    open override func removeFirst() -> Bool
    {
        let entry: ChartDataEntry? = _values.isEmpty ? nil : _values.removeFirst()
        
        let removed = entry != nil
        
        if removed
        {
            calcMinMax()
        }
        
        return removed
    }
    
    /// Removes the last Entry (at index size-1) of this DataSet from the entries array.
    ///
    /// - returns: `true` if successful, `false` ifnot.
    open override func removeLast() -> Bool
    {
        let entry: ChartDataEntry? = _values.isEmpty ? nil : _values.removeLast()
        
        let removed = entry != nil
        
        if removed
        {
            calcMinMax()
        }
        
        return removed
    }
    
    /// Checks if this DataSet contains the specified Entry.
    /// - returns: `true` if contains the entry, `false` ifnot.
    open override func contains(_ e: ChartDataEntry) -> Bool
    {
        for entry in _values
        {
            if (entry.isEqual(e))
            {
                return true
            }
        }
        
        return false
    }
    
    /// Removes all values from this DataSet and recalculates min and max value.
    open override func clear()
    {
        _values.removeAll(keepingCapacity: true)
        notifyDataSetChanged()
    }
    
    // MARK: - Data functions and accessors

    // MARK: - NSCopying
    
   @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! ChartDataSet
        
        var newValues:[ChartDataEntry] = []
        for entry in _values
        {
            let newEntry = entry.copy() as! ChartDataEntry
            newValues.append(newEntry)
        }
        copy._values = newValues
//      copy._values = _values
        
        copy._yMax = _yMax
        copy._yMin = _yMin
        
        copy.visible = visible
        
        copy.drawValuesEnabled = drawValuesEnabled
        
        copy.plotType = plotType
        copy.dataSetOptions = dataSetOptions
        
        return copy
    }
    
    // MARK: - Codable
    enum CodingKeys: CodingKey {
               case axisIndex
               case mValues
               case mLabel
               case mColors
               case chartType
               case dataSetOption
               case mDrawValues
               case mVisible
           }

    required public convenience init(from decoder: Decoder) throws {
        
        let isQAAutomation = decoder.userInfo[ChartViewBase.qaUserInfoKey]
        
        if (isQAAutomation != nil)
        {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            let values =  try container.decode([ChartDataEntry].self, forKey: .mValues)
            let label = container.contains(.mLabel) ? try container.decode(String.self, forKey: .mLabel) : nil
            let colorsCode = try container.decode([Int].self, forKey: .mColors)
            let plotType = try container.decode(String.self, forKey: .chartType)
            
            self.init(values: values, label: label)
            
            var colorsArray = [NSUIColor]()
            for code in colorsCode
            {
                colorsArray.append(NSUIColor(rgb:code))
            }
            
            colors = colorsArray
            axisIndex = try container.decode(Int.self, forKey: .axisIndex)
            
            drawValuesEnabled = container.contains(.mDrawValues) ? try container.decode(Bool.self, forKey: .mDrawValues) : drawValuesEnabled
            
            visible = container.contains(.mVisible) ? try container.decode(Bool.self, forKey: .mVisible) : visible
            
            let containsDataSetOptions = container.contains(.dataSetOption)
            
            switch plotType
            {
                case "BAR":
                    self.plotType = .Bar
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(BarDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    
                    if (dataSetOptions as! BarDataSetOptions).levelMarkerColors.count > 0
                    {
                        self._plotType = .Bullet
                    }
                    break

                case "PIE":
                    self.plotType = .Pie
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "DIAL":
                    self.plotType = .Dial
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break

                case "LINE":
                    self.plotType = .Line
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(LineDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "AREA_RANGE":
                    self.plotType = .LineRange
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(LineDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "HEAT_MAP":
                    self.plotType = .HeatMap
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "GEO_HEATMAP":
                    self.plotType = .GeoHeatMap
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "SCATTER":
                    self.plotType = .Scatter
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "BUBBLE":
                    self.plotType = .Bubble
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "BUBBLE_PIE":
                    self.plotType = .BubblePie
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "PACKED_BUBBLE":
                    self.plotType = .PackedBubble
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "RADAR":
                    self.plotType = .Radar
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(LineDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "FUNNEL":
                    self.plotType = .Funnel
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                    
                case "WORD_CLOUD":
                    self.plotType = .WordCloud
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
                
                case "WATERFALL":
                    self.plotType = .WaterFall
                    self.dataSetOptions = BarDataSetOptions()
                    
                    let waterFallDict = try container.decode([String:Int].self, forKey: .dataSetOption)
            
                    let cascadeCategoriesColor = waterFallDict["cascadeCategoriesColor"]!
                        
                    let fallingCategoriesColor = waterFallDict["fallingCategoriesColor"]!
                        
                    let risingCategoriesColor = waterFallDict["risingCategoriesColor"]!
                            
                    if cascadeCategoriesColor != -1 {
                        cascadedCategoryColor = NSUIColor(rgb: cascadeCategoriesColor)
                    }
                                
                    if fallingCategoriesColor != -1 {
                        fallingCategorycolor = NSUIColor(rgb: fallingCategoriesColor)
                    }
                                
                    if risingCategoriesColor != -1 {
                        risingCategorycolor = NSUIColor(rgb: risingCategoriesColor)
                    }
                    break
                
                case "BOXPLOT":
                    self.plotType = .BoxPlot
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(BarDataSetOptions.self, forKey: .dataSetOption) : BarDataSetOptions()
                    break
                
                case "MARIMEKKO":
                    self.plotType = .Mekko
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(BarDataSetOptions.self, forKey: .dataSetOption) : BarDataSetOptions()
                    break
                
                case "SANKEY":
                    self.plotType = .Sanky
                    self.dataSetOptions = containsDataSetOptions ? try container.decode(AxisChartDataSetOptions.self, forKey: .dataSetOption) : dataSetOptions
                    break
            
                default:
                   break
            }

        }
        else
        {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            let values =  try container.decode([ChartDataEntry].self, forKey: .mValues)
            let label = container.contains(.mLabel) ? try container.decode(String.self, forKey: .mLabel) : nil
            let colorsCode = try container.decode([Int].self, forKey: .mColors)
            let plotType = try container.decode(String.self, forKey: .chartType)
            
            self.init(values: values, label: label)
            
            var colorsArray = [NSUIColor]()
            for code in colorsCode
            {
                colorsArray.append(NSUIColor(rgb:code))
            }
            
            colors = colorsArray
            axisIndex = try container.decode(Int.self, forKey: .axisIndex)
            
            drawValuesEnabled = container.contains(.mDrawValues) ? try container.decode(Bool.self, forKey: .mDrawValues) : drawValuesEnabled
            
            visible = container.contains(.mVisible) ? try container.decode(Bool.self, forKey: .mVisible) : visible
            
            var containsDataSetOptions = container.contains(.dataSetOption)
    //        if containsDataSetOptions && (try? container.decode(String.self, forKey: .dataSetOption)) != nil
    //        {
    //            containsDataSetOptions = false
    //        }
        enum SetCodingKeys: CodingKey {
            case setOption
        }
        let subContainer = try decoder.container(keyedBy: SetCodingKeys.self)
        
        var setOptionContainer = containsDataSetOptions ? try container.nestedContainer(keyedBy: SetCodingKeys.self, forKey: .dataSetOption) : subContainer
            
            switch plotType
            {
                case "BAR":
                    self.plotType = .Bar
                
                    if let option = try setOptionContainer.decodeIfPresent(BarDataSetOptions.self, forKey: .setOption)
                    {
                        self.dataSetOptions = option
                    }
                    else
                    {
                        self.dataSetOptions = dataSetOptions
                    }
                    
                    if (dataSetOptions as! BarDataSetOptions).levelMarkerColors.count > 0
                    {
                        self._plotType = .Bullet
                    }
                    break

                case "PIE":
                    self.plotType = .Pie
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "DIAL":
                    self.plotType = .Dial
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break

                case "LINE":
                    self.plotType = .Line
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(LineDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "AREA_RANGE":
                    self.plotType = .LineRange
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(LineDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "HEAT_MAP":
                    self.plotType = .HeatMap
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "GEO_HEATMAP":
                    self.plotType = .GeoHeatMap
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "SCATTER":
                    self.plotType = .Scatter
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "BUBBLE":
                    self.plotType = .Bubble
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "BUBBLE_PIE":
                    self.plotType = .BubblePie
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "PACKED_BUBBLE":
                    self.plotType = .PackedBubble
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "RADAR":
                    self.plotType = .Radar
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(LineDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "FUNNEL":
                    self.plotType = .Funnel
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                    
                case "WORD_CLOUD":
                    self.plotType = .WordCloud
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
                
                case "WATERFALL":
                    self.plotType = .WaterFall
                    self.dataSetOptions = BarDataSetOptions()
                    
                    let waterFallDict = try setOptionContainer.decode([String:Int].self, forKey: .setOption)
            
                    let cascadeCategoriesColor = waterFallDict["cascadeCategoriesColor"]!
                        
                    let fallingCategoriesColor = waterFallDict["fallingCategoriesColor"]!
                        
                    let risingCategoriesColor = waterFallDict["risingCategoriesColor"]!
                            
                    if cascadeCategoriesColor != -1 {
                        cascadedCategoryColor = NSUIColor(rgb: cascadeCategoriesColor)
                    }
                                
                    if fallingCategoriesColor != -1 {
                        fallingCategorycolor = NSUIColor(rgb: fallingCategoriesColor)
                    }
                                
                    if risingCategoriesColor != -1 {
                        risingCategorycolor = NSUIColor(rgb: risingCategoriesColor)
                    }
                    break
                
                case "BOXPLOT":
                    self.plotType = .BoxPlot
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(BarDataSetOptions.self, forKey: .setOption) : BarDataSetOptions()
                    break
                
                case "MARIMEKKO":
                    self.plotType = .Mekko
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(BarDataSetOptions.self, forKey: .setOption) : BarDataSetOptions()
                    break
                
                case "SANKEY":
                    self.plotType = .Sanky
                    self.dataSetOptions = containsDataSetOptions ? try setOptionContainer.decode(AxisChartDataSetOptions.self, forKey: .setOption) : dataSetOptions
                    break
            
                default:
                   break
            }
            
            switch self.plotType
            {
                case .Bar, .BoxPlot, .Mekko:
                    
                    if let option = try setOptionContainer.decodeIfPresent(BarDataSetOptions.self, forKey: .setOption)
                    {
                        self.dataSetOptions = option
                    }
                    else
                    {
                        self.dataSetOptions = dataSetOptions
                    }
                    
                    if self.plotType == .Bar && (dataSetOptions as! BarDataSetOptions).levelMarkerColors.count > 0
                    {
                        self._plotType = .Bullet
                    }
                    break

                case .Pie, .Dial, .HeatMap, .GeoHeatMap, .Scatter, .Bubble, .BubblePie, .PackedBubble, .Funnel, .WordCloud, .Sanky :
                    
                    if let option = try setOptionContainer.decodeIfPresent(AxisChartDataSetOptions.self, forKey: .setOption)
                    {
                        self.dataSetOptions = option
                    }
                    else
                    {
                        self.dataSetOptions = dataSetOptions
                    }
                    
                    break
                    
                case .Line,.LineRange, .Radar:
                    
                    if let option = try setOptionContainer.decodeIfPresent(LineDataSetOptions.self, forKey: .setOption)
                    {
                        self.dataSetOptions = option
                    }
                    else
                    {
                        self.dataSetOptions = dataSetOptions
                    }
                    break
                
                case .WaterFall:
                    
                    self.dataSetOptions = BarDataSetOptions()
                    
                    let waterFallDict = try setOptionContainer.decode([String:Int].self, forKey: .setOption)
            
                    let cascadeCategoriesColor = waterFallDict["cascadeCategoriesColor"]!
                        
                    let fallingCategoriesColor = waterFallDict["fallingCategoriesColor"]!
                        
                    let risingCategoriesColor = waterFallDict["risingCategoriesColor"]!
                            
                    if cascadeCategoriesColor != -1 {
                        cascadedCategoryColor = NSUIColor(rgb: cascadeCategoriesColor)
                    }
                                
                    if fallingCategoriesColor != -1 {
                        fallingCategorycolor = NSUIColor(rgb: fallingCategoriesColor)
                    }
                                
                    if risingCategoriesColor != -1 {
                        risingCategorycolor = NSUIColor(rgb: risingCategoriesColor)
                    }
                    break
                
                default:
                   break
            }

        }
    }
    
    public func encode(to encoder: Encoder) throws {
        
    }
}


