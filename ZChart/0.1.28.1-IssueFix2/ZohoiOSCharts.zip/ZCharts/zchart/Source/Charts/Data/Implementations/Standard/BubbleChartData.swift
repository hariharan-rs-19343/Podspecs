//
//  BubbleChartData.swift
//  Charts
//
//  Bubble chart implementation:
//    Copyright 2015 Pierre-Marc Airoldi
//    Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

/*open class BubbleChartData: BarLineScatterCandleBubbleChartData
{
    public required init()
    {
        super.init()
    }
    
    public override init(dataSets: [IChartDataSet]?)
    {
        super.init(dataSets: dataSets)
    }
    
    open override func calcMinMax() {
        
        _maxSize = 0
        
        super.calcMinMax()
    }
    
    open override func calcMinMax(dataSet d: IChartDataSet) {
        
        guard let set = d as? BubbleChartDataSet,
            (set.isVisible)
            else { return }
        
        let size = set.maxSize
        
        if maxSize < size
        {
            _maxSize = size
        }
        
        super.calcMinMax(dataSet: d)
    }
    
    /// Sets the width of the circle that surrounds the bubble when highlighted for all DataSet objects this data object contains
    open func setHighlightCircleWidth(_ width: CGFloat)
    {
        for set in (_dataSets as? [IBubbleChartDataSet])!
        {
            set.highlightCircleWidth = width
        }
    }
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! BubbleChartData
        
        return copy
    }
}*/
