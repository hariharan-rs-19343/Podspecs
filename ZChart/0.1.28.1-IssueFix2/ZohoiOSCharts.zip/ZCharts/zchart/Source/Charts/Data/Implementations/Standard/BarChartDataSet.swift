//
//  BarChartDataSet.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics


/*open class BarChartDataSet: BarLineScatterCandleBubbleChartDataSet, IBarChartDataSet
{
    
    /// All the colors that are used for this DataSet.
    /// Colors are reused as soon as the number of levelMarkers in the Entries is higher than the size of the colors array.
    open var levelMarkerColors = [[NSUIColor]]()
    
    // Holds all the shape properties
    open var targetMarkerShapeProperties:ShapeProperties = ShapeProperties(type: LineShapes.line)
    
    fileprivate func initialize()
    {
        self.highlightColor = NSUIColor.black
    }
    
    public required init()
    {
        super.init()
        initialize()
    }
    
    public override init(values: [ChartDataEntry]?, label: String?)
    {
        super.init(values: values, label: label)
        initialize()
    }

    // MARK: - Data functions and accessors
    
    /// the maximum number of bars that are stacked upon each other, this value
    /// is calculated from the Entries that are added to the DataSet
    fileprivate var _stackSize = 1
    
    /// the overall entry count, including counting each stack-value individually
    fileprivate var _entryCountStacks = 0
    
    open override func calcMinMax(entry e: ChartDataEntry)
    { 
        let entryMinValue:Double
        
        let entryMaxValue:Double
        
        if  bulletModel
        {
            entryMinValue = e.yMin
            entryMaxValue = e.yMax
        }
        else
        {
            entryMinValue = e.y
            entryMaxValue = e.y
        }
    
        if entryMinValue < _yMin
        {
            _yMin = entryMinValue
        }
    
        if entryMaxValue > _yMax
        {
            _yMax = entryMaxValue
        }

        
        calcMinMaxX(entry: e)

    }
    
    /// - returns: The maximum number of bars that can be stacked upon another in this DataSet.
    open var stackSize: Int
    {
        return _stackSize
    }
    
    fileprivate var _bulletModel:Bool = false
    
    open var bulletModel:Bool {
        set
        {
            _bulletModel = newValue
        }
        get
        {
            return _bulletModel
        }
    }
    
    /// - returns: `true` if this DataSet is stacked (stacksize > 1) or not.
    open var isBulletBar: Bool
    {
        return (_bulletModel)
    }
    
    /// - returns: The overall entry count, including counting each stack-value individually
    open var entryCountStacks: Int
    {
        return _entryCountStacks
    }
    
    // MARK: - Styling functions and accessors
    
    /// the color used for drawing the bar-shadows. The bar shadows is a surface behind the bar that indicates the maximum value
    open var barShadowColor = NSUIColor(red: 215.0/255.0, green: 215.0/255.0, blue: 215.0/255.0, alpha: 1.0)

    /// the width used for drawing borders around the bars. If borderWidth == 0, no border will be drawn.
    open var barBorderWidth : CGFloat = 0.0

    /// the color drawing borders around the bars.
    open var barBorderColor = NSUIColor.black

    /// the alpha value (transparency) that is used for drawing the highlight indicator bar. min = 0.0 (fully transparent), max = 1.0 (fully opaque)
    open var highlightAlpha = CGFloat(120.0 / 255.0)
    
    // MARK: - NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! BarChartDataSet
        copy._stackSize = _stackSize
        copy._entryCountStacks = _entryCountStacks
        copy.barShadowColor = barShadowColor
        copy.highlightAlpha = highlightAlpha
        return copy
    }
}*/
