//
//  LineChartData.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

/// Data object that encapsulates all data associated with a LineChart.
/*open class LineChartData: BarLineScatterCandleBubbleChartData
{
    
    fileprivate var _stacked:Bool = false
    
    open var isStacked:Bool
    {
        get{
            return _stacked
        }
        set{
            _stacked = newValue
            if newValue
            {
                calcPosNegSum()
            }
        }
    }
    
    public required init()
    {
        super.init()
    }
    
    public override init(dataSets: [IChartDataSet]?)
    {
        super.init(dataSets: dataSets)
    }
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! LineChartData
        
        copy._stacked = isStacked
        
//        copy.xUniqueValues = xUniqueValues
//        copy.entriesStackedYValue = entriesStackedYValue
        
        return copy
    }
    
    open override func notifyDataChanged() {
        super.notifyDataChanged()
        // Calling calcPosNegSum may not be needed here..... Check later
        if _stacked
        {
            calcPosNegSum()
        }
    }
    
    open override func calcMinMax() {
        super.calcMinMax()
        if _stacked
        {
            calcPosNegSum()
        }
    }
    
    // Set Index -> EntryIndex -> YValue
    open var entriesStackedYValue:[Int:[Int:Double]] = [:]
    
    open var xUniqueValues = Set<Double>()
    
    open func calcPosNegSum()
    {
        entriesStackedYValue.removeAll()
        
        xUniqueValues.removeAll()
        
        var xDatasetUniqueValues = [Set<Double>]()
        
        for set in dataSets
        {
            var setXValues = Set<Double>()
            for entryIndex in 0..<set.entryCount
            {
                let entry = set.entryForIndex(entryIndex)
                if (entry?.x.isNaN)!
                {
                    continue
                }
                xUniqueValues.insert((entry?.x)!)
                setXValues.insert((entry?.x)!)
            }
            xDatasetUniqueValues.append(setXValues)
        }
        
        
        for setIndex in  0..<dataSets.count
        {
            let currentSet = dataSets[setIndex]

            let xValuesToAdd = xUniqueValues.subtracting(xDatasetUniqueValues[setIndex])
            
            for setValue in xValuesToAdd
            {
                let tempEntry = ChartDataEntry(x: setValue, y: Double.nan, data: nil)
                _ = currentSet.addEntryOrdered(tempEntry)
            }
        }
        
        
        var posY:[Double:Double] = [:]
        
        var negY:[Double:Double] = [:]
        
        var posSum:[Double:[Int:Double]] = [:]
        var negSum:[Double:[Int:Double]] = [:]
        
        var maxY = -(Double.greatestFiniteMagnitude)
        var minY = -(Double.greatestFiniteMagnitude)
        
        for setIndex in 0..<dataSets.count
        {
            let set = dataSets[setIndex]
            
            if !set.isVisible
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                let entry = set.entryForIndex(entryIndex)!
                
                if  entry.x.isNaN
                {
                    continue
                }
                else if entry.y.isNaN
                {
                    var posValue:Double = 0
                    var negValue:Double = 0
                    
                    if set.yMax > 0
                    {
                        if posY[entry.x] != nil
                        {
                            posValue = posY[entry.x]!
                        }
                    }
                    else{
                        if negY[entry.x] != nil
                        {
                            negValue = -negY[entry.x]!
                        }
                    }
                    
                    if entriesStackedYValue[setIndex] == nil {
                        entriesStackedYValue[setIndex] = [:]
                    }
                    
                    if set.yMax > 0
                    {
                        entriesStackedYValue[setIndex]![entryIndex] = posValue
                    }
                    else{
                        entriesStackedYValue[setIndex]![entryIndex] = negValue
                    }
                    
                    continue
                }
                
                if entry.y >= 0
                {
                    if posSum[entry.x] == nil
                    {
                        
                        posSum[entry.x] = [setIndex:entry.y]
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entry.y
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entry.y]
                        }
                        
                        
                        posY[entry.x] = entry.y
                    }
                    else{
                        
                        let  lastPositiveDataSetIndexSoFar = posSum[entry.x]?.keys.max()
                        
                        
                        // CASE :- Same X For differnt entry
                        if lastPositiveDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if posSum[entry.x]?.keys.count == 1
                            {
                                if posSum[entry.x]![setIndex]! < entry.y
                                {
                                    posSum[entry.x]![setIndex] = entry.y
                                    posY[entry.x] = entry.y
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entry.y
                                
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (posSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    //Ignoring the current data set index
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                    
                                }
                                
                                let yValue = posSum[entry.x]![prevDataSetIndex]! + entry.y
                                
                                if yValue > posSum[entry.x]![setIndex]!
                                {
                                    posSum[entry.x]![setIndex] = yValue
                                    posY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                                
                                
                            }
                        }
                        else{
                            let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + entry.y
                            
                            posSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            posY[entry.x] = yValue
                            
                        }
                        
                    }
                    
                }
                else{
                    
                    if negSum[entry.x] == nil
                    {
                        
                        negSum[entry.x] = [setIndex:abs(entry.y)]
                        
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entry.y
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entry.y]
                        }
                        
                        negY[entry.x] = abs(entry.y)
                        
                    }
                    else{
                        
                        let  lastNegativeDataSetIndexSoFar = negSum[entry.x]?.keys.max()
                        
                        
                        // CASE :- Same X For differnt entry
                        if lastNegativeDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if negSum[entry.x]?.keys.count == 1
                            {
                                if negSum[entry.x]![setIndex]! < abs(entry.y)
                                {
                                    negSum[entry.x]![setIndex] = abs(entry.y)
                                    negY[entry.x] = abs(entry.y)
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entry.y
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (negSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                }
                                
                                let yValue = negSum[entry.x]![prevDataSetIndex]! + abs(entry.y)
                                
                                if yValue > negSum[entry.x]![setIndex]!
                                {
                                    negSum[entry.x]![setIndex] = yValue
                                    negY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                        }
                        else{
                            let yValue = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]! + abs(entry.y)
                            
                            negSum[entry.x]![setIndex] = yValue
                            
                            negY[entry.x] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                            }
                            
                            
                            
                        }
                    }
                }
                
                // Min & Max
                if posY[entry.x] != nil && posY[entry.x]! > maxY
                {
                    maxY = posY[entry.x]!
                }

                if negY[entry.x] != nil && negY[entry.x]! > minY
                {
                    minY = negY[entry.x]!
                }
            }
            
        }
        
        // Need to revise first two lines
        self._yMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        self._yMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        
        //Need to check on below code based on actual available axis indices
        //otherwise Data yMin/yMax values will be written on all axis Index arrays
        for axisIndex in 0 ..< _yAxisMinArray.count {
            _yAxisMinArray[axisIndex] = self._yMin
        }
        
        for axisIndex in 0 ..< _yAxisMaxArray.count {
            _yAxisMaxArray[axisIndex] = self._yMax
        }
        
       /*for dict in _leftAxisMinArray
        {
            _leftAxisMinArray[dict.key] = -minY
        }
        for dict in _leftAxisMaxArray
        {
            _leftAxisMaxArray[dict.key] = maxY
        }
        
        for dict in _rightAxisMinArray
        {
            _rightAxisMinArray[dict.key] = -minY
        }
        for dict in _rightAxisMaxArray
        {
            _rightAxisMaxArray[dict.key] = maxY
        }
        
        self._leftAxisMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        self._leftAxisMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        self._rightAxisMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        self._rightAxisMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        */
    }
}*/
