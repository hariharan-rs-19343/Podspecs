//
//  BarChartData.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

/*open class BarChartData: BarLineScatterCandleBubbleChartData
{
   // MARK:Properties
    
    fileprivate var _stacked:Bool = false
    
    open var isStacked:Bool
        {
        get{
            return _stacked
        }
        set{
            _stacked = newValue
            if newValue
            {
                calcPosNegSum()
            }
        }
    }
    
    /// No. of visible bars
    open var barCount:Int = 6
    
    fileprivate var _stackedPercentEnabled:Bool = false
    
    /// Stacked Percentage
    open var stackedPercentEnabled:Bool
        {
        get{
            return _stackedPercentEnabled
        }
        set{
            _stackedPercentEnabled = newValue
            if newValue
            {
                calcPosNegSum()
            }
        }
    }
    
    /// Adds half of the bar width to each side of the x-axis range in order to allow the bars of the barchart to be fully displayed.
    /// **default**: false
    open var fitBars = false
    
    /// To hold group space
    open var groupSpace:Double = 0
    
    /// To hold bar space
    open var barSpace:Double = 0
    
    // To hold highlight Color
    open var highlightColor:NSUIColor? = nil
    open var nonHighlightColor:NSUIColor? = nil
    
    open var highlightGradient:BaseGradient? = nil
    open var nonHighlightGradient:BaseGradient? = nil
    
    /// The width of the bars on the x-axis, in values (not pixels)
    ///
    /// **default**: 0.85
    open var barWidth = Double(0.85)
    
    open var levelMarkerWidth = Double(0)
    
    open var minimumBarPixel = Double(0)
    
    open var maximumBarPixel = Double(0)
    
    open var barSpacePixel = Double(0)
    
    open var groupSpacePixel = Double(0)
    
    open var barWidthPixel = Double(0)
    
    open var levelMarkerWidthPixel = Double(0)
    
    open var adjustViewToLevelWidth = false
    
    // Set Index -> EntryIndex -> YValue
    open var entriesStackedYValue:[Int:[Int:Double]] = [:]
    
    //    open var xUniqueValues = Set<Double>()
    
    open var positiveSum:[Double:Double] = [:]
    
    open var negativeSum:[Double:Double] = [:]
    
    open var stackSpacing:CGFloat = 0
    
    
    // MARK:Initializers
    
    public required init()
    {
        super.init()
    }
    
    public override init(dataSets: [IChartDataSet]?)
    {
        super.init(dataSets: dataSets)
    }
    
    
    /// Groups all BarDataSet objects this data object holds together by modifying the x-value of their entries.
    /// Previously set x-values of entries will be overwritten. Leaves space between bars and groups as specified by the parameters.
    /// Do not forget to call notifyDataSetChanged() on your BarChart object after calling this method.
    ///
    /// - parameter the starting point on the x-axis where the grouping should begin
    /// - parameter groupSpace: The space between groups of bars in values (not pixels) e.g. 0.8f for bar width 1f
    /// - parameter barSpace: The space between individual bars in values (not pixels) e.g. 0.1f for bar width 1f
   /* open func groupBars(fromX: Double, groupSpace: Double, barSpace: Double)
    {
        self.groupSpace = groupSpace
        self.barSpace = barSpace
        
        let setCount = _dataSets.count
        if setCount <= 1
        {
            print("BarData needs to hold at least 2 BarDataSets to allow grouping.", terminator: "\n")
            return
        }
        
        let max = maxEntryCountSet
        let maxEntryCount = max?.entryCount ?? 0
        
        let groupSpaceWidthHalf = groupSpace / 2.0
        let barSpaceHalf = barSpace / 2.0
        let barWidthHalf = self.barWidth / 2.0
        
        var removedCount = 0
        
        for i in _dataSets
        {
            if i.isVisible
            {
                continue
            }
            removedCount += 1
        }
        
        var fromX = fromX + ((barWidthHalf + barSpaceHalf) * Double(removedCount))
        
        let interval = groupWidth(groupSpace: groupSpace, barSpace: barSpace)
        
        for i in stride(from: 0, to: maxEntryCount, by: 1)
        {
            let start = fromX
            fromX += groupSpaceWidthHalf
            
            for set in _dataSets as! [IBarChartDataSet]
            {
                if !(set.isVisible) {
                    continue
                }
                
                fromX += barSpaceHalf
                fromX += barWidthHalf
                
                if i < set.entryCount
                {
                    if let entry = set.entryForIndex(i)
                    {
                        entry.x = fromX
                    }
                }
                
                fromX += barWidthHalf
                fromX += barSpaceHalf
            }
            
            fromX += groupSpaceWidthHalf
            let end = fromX
            let innerInterval = end - start
            let diff = interval - innerInterval
            
            // correct rounding errors
            if diff > 0 || diff < 0
            {
                fromX += diff
            }
            
        }
        
        notifyDataChanged()
    }*/
 
    
    /// Backup Code
    /*open func groupBars(fromX: Double, groupSpace: Double, barSpace: Double)
    {
         let setCount = _dataSets.count
        
         if setCount <= 1
         {
            print("BarData needs to hold at least 2 BarDataSets to allow grouping.", terminator: "\n")
            return
         }
        
         let max = maxEntryCountSet
         let maxEntryCount = max?.entryCount ?? 0
        
         let groupSpaceWidthHalf = groupSpace / 2.0
         let barSpaceHalf = barSpace / 2.0
         let barWidthHalf = self.barWidth / 2.0
        
         var removedCount = 0
        
         for i in _dataSets
         {
             if i.isVisible
             {
                 continue
             }
             removedCount += 1
         }
     
         var fromX = fromX - 0.5
        
         let interval = groupWidth(groupSpace: groupSpace, barSpace: barSpace)
        
         for i in stride(from: 0, to: maxEntryCount, by: 1)
         {
             let start = fromX
             fromX += groupSpaceWidthHalf
            
             for set in _dataSets as! [IBarChartDataSet]
             {
                if !(set.isVisible) {
                    continue
                }
                
                 fromX += barSpaceHalf
                 fromX += barWidthHalf
                
                 if i < set.entryCount
                 {
                     if let entry = set.entryForIndex(i)
                     {
                        entry.x = fromX
                     }
                 }
                
                 fromX += barWidthHalf
                 fromX += barSpaceHalf
             }
            
             fromX += groupSpaceWidthHalf
             let end = fromX
             let innerInterval = end - start
             let diff = interval - innerInterval
            
             // correct rounding errors
             if diff > 0 || diff < 0
             {
                fromX += diff
             }
            
         }
        
         notifyDataChanged()
     }*/
    
    open override func notifyDataChanged() {
        super.notifyDataChanged()
        calcPosNegSum()
    }
    
    open override func calcMinMax() {
        super.calcMinMax()
        calcPosNegSum()
    }
    
    open func calcPosNegSum()
    {
        if stackedPercentEnabled
        {
            updatePosNegSum()
        }
        updateEntriesStackValue()
    }
    
    open func updateEntriesStackValue()
    {
        entriesStackedYValue.removeAll()
        
        var posY:[Double:Double] = [:]
        
        var negY:[Double:Double] = [:]
        
        var posSum:[Double:[Int:Double]] = [:]
        var negSum:[Double:[Int:Double]] = [:]
        
        var maxY = -(Double.greatestFiniteMagnitude)
        var minY = -(Double.greatestFiniteMagnitude)
        
        for setIndex in 0..<dataSets.count
        {
            let set =       dataSets[setIndex]
            
            let baseLineValue = set.axisIndex
            
            if !set.isVisible
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                let entry = set.entryForIndex(entryIndex)!
                
                var entryYValue = entry.y
                
                if stackedPercentEnabled
                {
                    
                    
                    entryYValue = positiveSum[entry.x] != nil ? (entry.y/positiveSum[entry.x]!)*100 : Double.nan
                    
                    if entry.y < 0
                    {
                        entryYValue = Double.nan
                    }
                }
                
                if  entry.x.isNaN
                {
                    /// Newly added from line calposnegsum
                    if entriesStackedYValue[setIndex] != nil
                    {
                        entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                    }
                    else{
                        entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                    }
                    ///*************************///
                    
                    continue
                }
                else if entryYValue.isNaN
                {
                    var posValue:Double = 0
                    var negValue:Double = 0
                    
                    if set.yMax > 0
                    {
                        if posY[entry.x] != nil
                        {
                            posValue = posY[entry.x]!
                        }
                    }
                    else{
                        if negY[entry.x] != nil
                        {
                            negValue = -negY[entry.x]!
                        }
                    }
                    
                    if entriesStackedYValue[setIndex] == nil {
                        entriesStackedYValue[setIndex] = [:]
                    }
                    
                    if set.yMax > 0
                    {
                        entriesStackedYValue[setIndex]![entryIndex] = posValue
                    }
                    else{
                        entriesStackedYValue[setIndex]![entryIndex] = negValue
                    }
                    
                    continue
                }
                
                if entryYValue >= 0
                {
                    if posSum[entry.x] == nil
                    {
                        
                        posSum[entry.x] = [setIndex:entryYValue]
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                        }
                        
                        
                        posY[entry.x] = entryYValue
                    }
                    else{
                        
                        let  lastPositiveDataSetIndexSoFar = posSum[entry.x]?.keys.max()
                        
                        let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + entryYValue
                        
                        posSum[entry.x]![setIndex] = yValue
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = yValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:yValue]
                        }
                        
                        posY[entry.x] = yValue
                        
                        // CASE :- Same X For differnt entry
                        // Since Bar has only unique X. This case won't come.
                        /*if false    //lastPositiveDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if posSum[entry.x]?.keys.count == 1
                            {
                                if posSum[entry.x]![setIndex]! < entryYValue
                                {
                                    posSum[entry.x]![setIndex] = entryYValue
                                    posY[entry.x] = entryYValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                                
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (posSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    //Ignoring the current data set index
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                    
                                }
                                
                                let yValue = posSum[entry.x]![prevDataSetIndex]! + entryYValue
                                
                                if yValue > posSum[entry.x]![setIndex]!
                                {
                                    posSum[entry.x]![setIndex] = yValue
                                    posY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                                
                                
                            }
                        }
                        else{
                            let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + entryYValue
                            
                            posSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            posY[entry.x] = yValue
                            
                        }*/
                        
                    }
                    
                }
                else{
                    
                    if negSum[entry.x] == nil
                    {
                        
                        negSum[entry.x] = [setIndex:abs(entryYValue)]
                        
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entryYValue]
                        }
                        
                        negY[entry.x] = abs(entryYValue)
                        
                    }
                    else{
                        
                        let  lastNegativeDataSetIndexSoFar = negSum[entry.x]?.keys.max()
                        
                        let yValue = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]! + abs(entryYValue)
                        
                        negSum[entry.x]![setIndex] = yValue
                        
                        negY[entry.x] = yValue
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = -yValue
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                        }
                        
                        // CASE :- Same X For differnt entry
                        // Since Bar has only unique X. This case won't come.
                        /*if lastNegativeDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if negSum[entry.x]?.keys.count == 1
                            {
                                if negSum[entry.x]![setIndex]! < abs(entryYValue)
                                {
                                    negSum[entry.x]![setIndex] = abs(entryYValue)
                                    negY[entry.x] = abs(entryYValue)
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entryYValue
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (negSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                }
                                
                                let yValue = negSum[entry.x]![prevDataSetIndex]! + abs(entryYValue)
                                
                                if yValue > negSum[entry.x]![setIndex]!
                                {
                                    negSum[entry.x]![setIndex] = yValue
                                    negY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                        }
                        else{
                            let yValue = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]! + abs(entryYValue)
                            
                            negSum[entry.x]![setIndex] = yValue
                            
                            negY[entry.x] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                            }
                            
                            
                            
                        }*/
                    }
                }
                
                // Min & Max
                if posY[entry.x] != nil && posY[entry.x]! > maxY
                {
                    maxY = posY[entry.x]!
                }
                
                if negY[entry.x] != nil && negY[entry.x]! > minY
                {
                    minY = negY[entry.x]!
                }
            }
            
        }
        
        if !stackedPercentEnabled
        {
            positiveSum = posY
            negativeSum = negY
        }
        
        if !((dataSets[0] as! BarChartDataSet).isBulletBar) &&  groupSpacePixel == 0  && groupSpace == 0  /// Not Multibar Check   // !((dataSetCount > 1) && isStacked)
        {
            // Need to revise first two lines
            self._yMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
            self._yMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
            
            _yAxisMinArray[dataSets[0].axisIndex] = self._yMin
            _yAxisMaxArray[dataSets[0].axisIndex] = self._yMax
            
            /*for axisIndex in 0 ..< _yAxisMinArray.count {
                _yAxisMinArray[axisIndex] = self._yMin
            }
            
            for axisIndex in 0 ..< _yAxisMaxArray.count {
                _yAxisMaxArray[axisIndex] = self._yMax
            }*/
        }
    }
    
    open func updatePosNegSum()
    {
        positiveSum.removeAll()
        
        negativeSum.removeAll()
        
        for setIndex in 0..<dataSets.count
        {
            let set = dataSets[setIndex]
            
            if !set.isVisible
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                let entry = set.entryForIndex(entryIndex)!
                
                if  entry.x.isNaN || entry.y.isNaN
                {
                    continue
                }
                
                if entry.y >= 0
                {
                    if positiveSum[entry.x] == nil
                    {
                        positiveSum[entry.x] = entry.y
                    }
                    else{
                        let yValue = positiveSum[entry.x]! + entry.y
                     
                        positiveSum[entry.x] = yValue
                   }
                    
                }
                else{
                    
                    if negativeSum[entry.x] == nil
                    {
                        negativeSum[entry.x] = abs(entry.y)
                    }
                    else{
                        let yValue = negativeSum[entry.x]! + abs(entry.y)
                        
                        negativeSum[entry.x] = yValue
                    }
                }
              
            }
        }
    }
    
    open func groupBars(fromX: Double, groupSpace: Double, barSpace: Double, xInverted:Bool)
    {
        let setCount = _dataSets.count
        
        if setCount <= 1
        {
            print("BarData needs to hold at least 2 BarDataSets to allow grouping.", terminator: "\n")
            return
        }
        
        let max = maxEntryCountSet
        let maxEntryCount = max?.entryCount ?? 0
        
        let groupSpaceWidthHalf = groupSpace / 2.0
        let barSpaceHalf = barSpace / 2.0
        let barWidthHalf = self.barWidth / 2.0
        
        var removedCount = 0
        
        for i in _dataSets
        {
            if i.isVisible
            {
                continue
            }
            removedCount += 1
        }
        
        var fromX = fromX - 0.5
        
        let interval = groupWidth(groupSpace: groupSpace, barSpace: barSpace)
        
        var dataSetLastIndexMapping:[Int:Int] = [:]
        
        for i in stride(from: 0, to: (xString?.count)!, by: 1)
        {
            let currentX = xString![i]
            let start = fromX
            fromX += groupSpaceWidthHalf
            
            var startIndex = 0
            var endIndex = _dataSets.count - 1
            var increment = 1
            
            if (xInverted) {
                startIndex = _dataSets.count - 1
                endIndex = 0
                increment = -1
            }
            
//            for setIndex in 0..<_dataSets.count
            for setIndex in stride(from: startIndex, through: endIndex, by: increment)
            {
                let set = _dataSets[setIndex]  as! IBarChartDataSet
                
                if dataSetLastIndexMapping[setIndex] == nil
                {
                    dataSetLastIndexMapping[setIndex] = 0
                }
                
                if !(set.isVisible) {
                    continue
                }
                
                fromX += barSpaceHalf
                fromX += barWidthHalf
                
                let lastIndex = dataSetLastIndexMapping[setIndex]!
                
                if let entry = set.entryForIndex(lastIndex)
                {
                    if entry.xString == currentX
                    {
                        entry.x = fromX
                        dataSetLastIndexMapping[setIndex] = lastIndex + 1
                    }
                }
                
                fromX += barWidthHalf
                fromX += barSpaceHalf
            }
            
            fromX += groupSpaceWidthHalf
            let end = fromX
            let innerInterval = end - start
            let diff = interval - innerInterval
            
            // correct rounding errors
            if diff > 0 || diff < 0
            {
                fromX += diff
            }
            
        }
        
        notifyDataChanged()
    }
    
    /// In case of grouped bars, this method returns the space an individual group of bar needs on the x-axis.
    ///
    /// - parameter groupSpace:
    /// - parameter barSpace:
    open func groupWidth(groupSpace: Double, barSpace: Double) -> Double
    {
        var currentDatasetCount = 0
        
        for i in _dataSets
        {
            if i.isVisible
            {
                currentDatasetCount += 1
            }
        }
        return Double(currentDatasetCount) * (self.barWidth + barSpace) + groupSpace
    }
    
   @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! BarChartData
        copy.barWidth = barWidth
        copy.barSpace = barSpace
        copy.groupSpace = groupSpace
        
        copy.barSpacePixel = barSpacePixel
        copy.groupSpacePixel = groupSpacePixel
        copy.barWidthPixel = barWidthPixel
        
        copy.minimumBarPixel = minimumBarPixel
        copy.maximumBarPixel = maximumBarPixel
        
        copy.highlightColor = highlightColor
        copy.nonHighlightColor = nonHighlightColor
        
        copy.isStacked = isStacked
        copy.stackedPercentEnabled = stackedPercentEnabled
        copy.fitBars = fitBars
        copy.barCount = barCount
        copy.stackSpacing = stackSpacing
        
        
        return copy
    }
    
}*/
