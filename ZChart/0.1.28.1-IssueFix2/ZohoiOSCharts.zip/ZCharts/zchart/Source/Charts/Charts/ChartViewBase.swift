//
//  ChartViewBase.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//
//  Based on https://github.com/PhilJay/MPAndroidChart/commit/c42b880

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

@objc
public protocol ChartViewDelegate
{
    // MARK: -  Data Delegates
    @objc optional func chartDataNil(chartView: ChartViewBase)
    
    // True - No Data Text drawn; False - Renders Data values
    @objc optional func chartCheckNoDataAvailable(chartView: ChartViewBase) -> Bool
    
    // To notify data loaded
    @objc optional func chartBufferLoadedBeforeDraw(chartView: ChartViewBase) -> Bool
    
    
    // MARK: -  Highlights Delegates
    /// Called when a value has been selected inside the chart.
    @objc optional func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight)
    
    @objc optional func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry)
    
    /// Called when nothing has been selected or an "un-select" has been made.
    @objc optional func chartValueNothingSelected(_ chartView: ChartViewBase)
    
    @objc optional func chartValueLongPressed(_ chartView: ChartViewBase, entry: ChartDataEntry)
    
    // MARK: -  Transform Delegates
    
    /// Callbacks when the chart is scaled / zoomed via pinch zoom gesture.
    @objc optional func chartScaled(_ chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat)
    
    /// Callbacks when the chart is moved / translated via drag gesture.
    @objc optional func chartTranslated(_ chartView: ChartViewBase, dX: CGFloat, dY: CGFloat)
    
    @objc optional func chartProcessedBeforeDraw(_ chartView: ChartViewBase, redrawRequired: Bool)
    
    @objc optional func chartXRangeUpdated(minimum: Double, maximum: Double, updateLayer: Bool)
    
    // MARK: -  Filter/Drill Delegates
    
    @objc optional func chartValueRemoved(_ chartView: ChartViewBase, entries: [ChartDataEntry]?, dataSets: [ChartDataSet]?, dataSetRemoved:Bool, showTrackerView:Bool)
    
    @objc optional func chartValueAdded(chartView: ChartViewBase, entries: [ChartDataEntry]?, dataSets: [ChartDataSet]?, dataSetAdded:Bool)
    
    @objc optional func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int)
    
    @objc optional func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    
    // MARK: -  Legend Delegates
    // Callbacks when the chart is moved / translated via drag gesture.
    @objc optional func legendReloaded(_ chartView: ChartViewBase, _ legendEntries:[LegendEntry]?)
}

@objc
public protocol  RendererDelegate {
    @objc optional func drawOthers(_ chartView:ChartViewBase)
    
    @objc optional func delegateToHighlight(layer: ChartEntryLayer, isHighlighted: Bool)
}

@objc
public protocol  PlotDelegate {
    @objc optional func updatePlotOptions(plotOption:PlotOptionsBase,type:ChartType)
}

open class ChartViewBase: NSUIView, AnimatorDelegate, ContainerDelegate, NSUIGestureRecognizerDelegate
{
    public typealias DrawRenderOrder = ChartType
    
    public typealias scalePriority = ChartType
    
    // MARK: - Properties
    
    internal var plotView:PlotView? = nil
    
    open var showPlotView = true
    
    internal var _rotated:Bool = false
    
    /// object responsible for rendering the data
//    open var renderer: DataRenderer? // REmove
     
    open var preProcessor: ChartPreprocessor? // Remove
    
    open var renderers: [DataRenderer] = []
    
    open var customRenderers: [ChartType:DataRenderer] = [:]
    
    open var preProcessors: [ChartPreprocessor] = []
     
    open var plotOptions:[ChartType:IPlotOptions] = [:]
    
    open var isPlotBeyondAxisLine = false
    
    internal var plotTypes:[ChartType] = []
    
    internal var _drawRenderOrder: [DrawRenderOrder] = [.Pie, .Dial, .Bar, .Mekko, .Sanky, .Bubble, .BubblePie, .Line, .Area, .LineRange, .Scatter, .Funnel, .HeatMap, .Combined, .Bullet, .PackedBubble, .Radar, .WordCloud, .GeoHeatMap, .WaterFall, .BoxPlot, .HorizontalBarRange]
    
    /// To mention which scaling type is preferred
    open var scalePreference:scalePriority = .Line
    
    internal var _notes:Notes? = nil
    
    open var notes:Notes?
    {
        get { return _notes }
        set {
            if let entries = newValue?.noteEntries
            {
                for entry in entries
                {
                    if entry.noteEntryData != nil
                    {
                        guard let set = data?.getDataSetForEntry(entry.noteEntryData),
                              let setIndex = data?.indexOfDataSet(set)
                        else { continue }
                        entry.noteEntryDataSetIndex = setIndex
                    }
                }
            }
            
            _notes = newValue
        }
    }
    
    fileprivate var _combined:Bool = false
    
    open var isRotated:Bool
    {
        get { return _rotated }
        set {
            _rotated = newValue
            if _rotated
            {
                let (oldWidth, oldHeight) = (viewPortHandler.chartWidth, viewPortHandler.chartHeight)
                _viewPortHandler = ViewPortHandlerHorizontalBarChart()
                _viewPortHandler.chartViewBase = self
                viewPortHandler.setChartDimens(width: oldWidth, height: oldHeight)
                _xAxisRenderer = XAxisRendererHorizontalBarChart(viewPortHandler: _viewPortHandler, xAxis: _xAxis, transformer: nil, chart: self)
            }
            else
            {
                let (oldWidth, oldHeight) = (viewPortHandler.chartWidth, viewPortHandler.chartHeight)
                _viewPortHandler = ViewPortHandler()
                plotTransformer._viewPortHandler = _viewPortHandler
                _viewPortHandler.chartViewBase = self
                viewPortHandler.setChartDimens(width: oldWidth, height: oldHeight)
                _xAxisRenderer = XAxisRenderer(viewPortHandler: _viewPortHandler, xAxis: _xAxis, transformer: nil, chartViewBase: self)
            
            }
        }
    }
    
    open var isCombined:Bool
    {
        get {
            return _combined
        }
        set {
            _combined = newValue
        }
    }
    
    /// the order in which the provided data objects should be drawn.
    /// The earlier you place them in the provided array, the further they will be in the background.
    /// e.g. if you provide [DrawRenderOrder.Bar, DrawRenderOrder.Line], the bars will be drawn behind the lines.
    open var drawRenderOrder: [DrawRenderOrder]
    {
        get
        {
            return _drawRenderOrder
        }
        set
        {
            if newValue.count > 0
            {
                _drawRenderOrder = newValue
            }
        }
    }
    
    
    /// the maximum number of entries to which values will be drawn
    /// (entry numbers greater than this value will cause value-labels to disappear)
    internal var _maxVisibleCount = 1000000
    
    /// flag that indicates if auto scaling on the y axis is enabled
    fileprivate var _autoScaleMinMaxEnabled = false
    
    fileprivate var _scaleXEnabled = true
    
    fileprivate var _scaleYEnabled = true
    
    /// Set this to provide custom scaling for chart
    open var customScaleEnabled = false
    
//    open var isOverviewChart = false
    
    /////====================== ****************************** ====================== /////
    
    // MARK:  Plot Properties
    
    /// object that holds all data that was originally set for the chart, before it was modified or any filtering algorithms had been applied
    internal var _data: ChartData?
    
    /// The object representing the labels on the x-axis
    internal var _xAxis: XAxis!
    
    internal var _xAxisRenderer: AxisRendererBase!
    
    /// The legend object containing all data associated with the legend
    internal var _legend: Legend!
    
    internal var _legendRenderer: LegendRenderer!
    
    internal var _colorAxis: ColorAxis!
    
    /// object that manages the bounds and drawing constraints of the chart
    internal var _viewPortHandler: ViewPortHandler!
    
    /// flag that indicates if a custom viewport offset has been set
    internal var _customViewPortEnabled = false
    
    /// object responsible for animations
    internal var _animator: Animator!
    
    internal var _viewportJobs = [ViewPortJob]()
    
    internal var labelRects:[CGRect]? = nil
    
    //DatasetIndex/entryIndex/key:labelSize
    internal var labelSizeIndexMap = [Int:[Int:[String:CGSize]]]()
    
    internal var isOccupancgGridMappingIsInitialized = false
    internal var longestDatalabelSize: CGSize = CGSize()
    internal var labelRectIndexMap = [Int:[Int:[String:CGRect]]]()
    internal var labelRectIndexForStackedSum = [Double:[Any]]()
    
    open var borderEnabled = false
    open var borderColor = NSUIColor.gray
    open var borderWidth = CGFloat(0.5)
    open var borderDashPhase = CGFloat(0.0)
    open var borderDashLengths: [CGFloat]!

    
    // MARK:  Accessors
    
    /// The data for the chart
    open var data: ChartData?
    {
         get
         {
             return _data
         }
         set
         {
             _data = newValue
             _offsetsCalculated = false
             
             _data?.xOrdinal = xAxis.scaleType == .Ordinal
             
             for axis in yAxisArray
             {
                 _data?.yOrdinal[axis.axisIndex] = axis.scaleType == .Ordinal
             }
             
             _data?.dataCalculation()
             
//             data?.updateArrayOfDataSets()
             
             (delegateToContainer as? ChartContainer)?.isAxisChart = !data!.dataSets.contains(where: { $0.plotType == .Dial || $0.plotType == .Pie || $0.plotType == .Funnel || $0.plotType == .PackedBubble || $0.plotType == .WordCloud || $0.plotType == .Sanky || $0.plotType == .GeoHeatMap})
            
            if _data == nil
            {
                return
            }
            
             trackEntriesEnabledCount()
             
             setFormatters()
             
             setPlotTypes()
             
             createPlotOptions()
            
             setDefaultValues()
            
             createRenderers()
          
             for dataRenderer in renderers
             {
                 dataRenderer.initBuffers()
             }
            
            // let the chart know there is new data
            // notifyDataSetChanged()
            
            let flag = updateDataCategoryOrder()
            
            if flag
            {
                data?.updateXYValues()
                data?.notifyDataChanged()
            }
             
             prepareDataLabelSize()
         }
     }
    
     /// - returns: The object representing all x-labels, this method can be used to
     /// acquire the XAxis object and modify it (e.g. change the position of the
     /// labels)
     open var xAxis: XAxis
     {
        get { return _xAxis }
        set { _xAxis = newValue }
     }
     
     /// The X axis renderer. This is a read-write property so you can set your own custom renderer here.
     /// **default**: An instance of XAxisRenderer
     /// - returns: The current set X axis renderer
     open var xAxisRenderer: AxisRendererBase
     {
         get { return _xAxisRenderer }
         set { _xAxisRenderer = newValue }
     }
    
     /// - returns: The Legend object of the chart. This method can be used to get an instance of the legend in order to customize the automatically generated Legend.
     open var legend: Legend
     {
        return _legend
     }
       
     /// - returns: The renderer object responsible for rendering / drawing the Legend.
     open var legendRenderer: LegendRenderer!
     {
         return _legendRenderer
     }
     
    open var computeLegend:Bool = true
    
     /// - returns: The ColorAxis object of the chart. This method can be used to get an instance of the legend in order to customize the automatically generated Legend.
     open var colorAxis: ColorAxis
     {
        get { return _colorAxis }
        set { _colorAxis = newValue }
     }
    
     /// - returns: The ViewPortHandler of the chart that is responsible for the
     /// content area of the chart and its offsets and dimensions.
     open var viewPortHandler: ViewPortHandler!
     {
         return _viewPortHandler
     }
     
     /// - returns: The animator responsible for animating chart values.
     open var chartAnimator: Animator!
     {
         return _animator
     }

     /// - returns: The current y-max value across all DataSets
     open var chartYMax: Double
     {
        for processor in preProcessors
        {
            return processor.chartYMax
        }
        return 0
     }
    
     /// - returns: The current y-min value across all DataSets
     open var chartYMin: Double
     {
         for processor in preProcessors
         {
             return processor.chartYMin
         }
        return 0
     }
    
     open var chartXMax: Double
     {
         return _xAxis._axisMaximum
     }
    
     open var chartXMin: Double
     {
         return _xAxis._axisMinimum
     }
    
     open var xRange: Double
     {
         return _xAxis.axisRange
     }
    
     /// *
     /// - note: (Equivalent of getCenter() in MPAndroidChart, as center is already a standard in iOS that returns the center point relative to superview, and MPAndroidChart returns relative to self)*
     /// - returns: The center point of the chart (the whole View) in pixels.
     open var midPoint: CGPoint
     {
         let bounds = self.bounds
         return CGPoint(x: bounds.origin.x + bounds.size.width / 2.0, y: bounds.origin.y + bounds.size.height / 2.0)
     }
    
     /// - returns: The center of the chart taking offsets under consideration. (returns the center of the content rectangle)
     open var centerOffsets: CGPoint
     {
         return _viewPortHandler.contentCenter
     }
    
     /// - returns: The rectangle that defines the borders of the chart-value surface (into which the actual values are drawn).
     open var contentRect: CGRect
     {
         return _viewPortHandler.contentRect
     }
    
    /// When enabled, the values will be clipped to contentRect, otherwise they can bleed outside the content rect.
    open var clipValuesToContentEnabled: Bool = false
    
    
    /////====================== ****************************** ====================== /////
    
    
      // MARK:  Listener Properties
      
      open var touchEventsEnabled:Bool = true
      
      internal var _interceptTouchEvents = false
      
      internal var _tapEventListener: TapEventListener? = nil
      
      internal var _doubleTapEventListener: TapEventListener? = nil
      #if os(iOS)
        internal var _longPressEventListener: LongPressEventListener? = nil
    
        internal var _hoverEventListener: NSUIGestureRecognizer? = nil
      #endif
      internal var _panEventListener: PanEventListener? = nil
    
      /// iOS && OSX only: Enabled multi-touch rotation using two fingers.
      fileprivate var _rotationWithTwoFingers = false
    
      #if !os(tvOS)
      fileprivate var _rotationGestureRecognizer: NSUIRotationGestureRecognizer!
      #endif
      
      #if !os(tvOS)
      internal var _pinchEventListener: PinchEventListener? = nil
      #endif
      
      open var tapEventListener: TapEventListener? {
          get {
              return _tapEventListener
          }
      }
      
      open var doubleTapEventListener: TapEventListener? {
          get {
              return _doubleTapEventListener
          }
      }
      
      #if os(iOS)
      open var longPressEventListener: LongPressEventListener? {
          get {
              return _longPressEventListener
          }
      }
    
    @available(iOS 13.0, *)
    open var hoverEventListener: HoverEventListener? {
        get {
            return (_hoverEventListener as? HoverEventListener) ?? nil
        }
    }
      #endif
      open var panEventListener: PanEventListener? {
          get {
              return _panEventListener
          }
      }
      
      #if !os(tvOS)
      open var pinchEventListener: PinchEventListener? {
          get {
              return _pinchEventListener
          }
      }
      #endif
    
      open var touchHandler:TouchHandler = RotationTouchHandler()
    
    /// flag that indicates if rotation is done with two fingers or one.
    /// when the chart is inside a scrollview, you need a two-finger rotation because a one-finger rotation eats up all touch events.
    ///
    /// On iOS this will disable one-finger rotation.
    /// On OSX this will keep two-finger multitouch rotation, and one-pointer mouse rotation.
    ///
    /// **default**: false
    open var rotationWithTwoFingers: Bool
    {
        get
        {
            return _rotationWithTwoFingers
        }
        set
        {
            _rotationWithTwoFingers = newValue
            #if !os(tvOS)
                _rotationGestureRecognizer.isEnabled = _rotationWithTwoFingers
            #endif
        }
    }
    
    /// flag that indicates if rotation is done with two fingers or one.
    /// when the chart is inside a scrollview, you need a two-finger rotation because a one-finger rotation eats up all touch events.
    ///
    /// On iOS this will disable one-finger rotation.
    /// On OSX this will keep two-finger multitouch rotation, and one-pointer mouse rotation.
    ///
    /// **default**: false
    open var isRotationWithTwoFingers: Bool
    {
        return _rotationWithTwoFingers
    }

    
    fileprivate var _pinchZoomEnabled = false
    
    fileprivate var _doubleTapToZoomEnabled = true
    
    fileprivate var _doubleTapEnabled = false

    fileprivate var _dragEnabled = true
       
       
      
     /////====================== ****************************** ====================== /////
    
     // MARK:  Delegate Properties
     
     /// delegate to receive chart events
//     open weak var delegate: ChartViewDelegate?
    
    /// delegate to update PlotOptions
    open weak var plotDelegate: PlotDelegate?
     
     /// delegate to receive chart events on Container
     open weak var delegateToContainer: ChartViewDelegate?
     
     // delegate to notify draw highlights
     open weak var rendererDelegate:RendererDelegate? = nil
     
     //Holds Listeners for charts
//     open weak var chartActionListener:ChartActionListener? = nil
     
     /////====================== ****************************** ====================== /////
     
     // MARK:  Tracker Properties
     
     open var highlighter: IHighlighter?
     
     /// - returns: The array of currently highlighted values. This might an empty if nothing is highlighted.
     open var highlighted: [Highlight]
     {
         return _indicesToHighlight
     }
     
     /// array of Highlight objects that reference the highlighted slices in the chart
     internal var _indicesToHighlight = [Highlight]()
     
     /// The last value that was highlighted via touch.
     open var lastHighlighted: Highlight?
     
     //To hold last selected entry object on highlight
    fileprivate var _lastSelected:[ChartDataEntry]? = nil
   
    open var lastSelected:[ChartDataEntry]?
    {
       get { return _lastSelected }
       set {
           _lastSelected = newValue
           if _lastSelected != nil
           {
               lastSelectedSet = []
               for entry in _lastSelected!
               {
                   lastSelectedSet?.append(self.data?.getDataSetForEntry(entry) as? ChartDataSet)
               }
           }
           else{
               lastSelectedSet = nil
           }
       }
    }
   
    open var lastSelectedSet:[ChartDataSet?]? = nil
    
    open var xGroupSelected:Bool = false
    
    open func resetHighlight() {
        datasetSelected = false
        xGroupSelected = false
    }
     
     /////====================== ****************************** ====================== /////
     
     // MARK:  Styling Properties
     
     /// The default IValueFormatter that has been determined by the chart considering the provided minimum and maximum values.
     internal var _defaultValueFormatter: IValueFormatter? = DefaultValueFormatter(decimals: 0)
     
     /// If set to true, chart continues to scroll after touch up
     open var dragDecelerationEnabled = true
     
     /// Deceleration friction coefficient in [0 ; 1] interval, higher values indicate that speed will decrease slowly, for example if it set to 0, it will stop immediately.
     /// 1 is an invalid value, and will be converted to 0.999 automatically.
     fileprivate var _dragDecelerationFrictionCoef: CGFloat = 0.9
     
     /// **default**: true
     /// - returns: `true` if chart continues to scroll after touch up, `false` ifnot.
     open var isDragDecelerationEnabled: Bool
     {
         return dragDecelerationEnabled
     }
     
     /// Deceleration friction coefficient in [0 ; 1] interval, higher values indicate that speed will decrease slowly, for example if it set to 0, it will stop immediately.
     /// 1 is an invalid value, and will be converted to 0.999 automatically.
     ///
     /// **default**: true
     open var dragDecelerationFrictionCoef: CGFloat
         {
         get
         {
             return _dragDecelerationFrictionCoef
         }
         set
         {
             var val = newValue
             if val < 0.0
             {
                 val = 0.0
             }
             if val >= 1.0
             {
                 val = 0.999
             }
             
             _dragDecelerationFrictionCoef = val
         }
     }
     
     /// The maximum distance in screen pixels away from an entry causing it to highlight.
     /// **default**: 500.0
     open var maxHighlightDistance: CGFloat = 500.0
     
     /// if true, units are drawn next to the values in the chart
     internal var _drawUnitInChart = false
     
     /// The `Description` object of the chart.
     /// This should have been called just "description", but
     open var chartDescription: Description?
     
     /// text that is displayed when the chart is empty
     open var noDataText = "No chart data available."
     
     /// Font to be used for the no data text.
     open var noDataFont: NSUIFont! = NSUIFont(name: "HelveticaNeue", size: 12.0)
     
     /// color of the no data text
     open var noDataTextColor: NSUIColor = NSUIColor.black
    
    open var noDataTextEnabled = true
     
     /////====================== ****************************** ====================== /////
     
     // MARK:  Marker Properties
     
     /// The marker that is displayed when a value is clicked on the chart
     open var marker: IMarker?
     
     /// `true` if drawing the marker is enabled when tapping on values
     /// (use the `marker` property to specify a marker)
     open var drawMarkers = true
     
     /// - returns: `true` if drawing the marker is enabled when tapping on values
     /// (use the `marker` property to specify a marker)
     open var isDrawMarkersEnabled: Bool { return drawMarkers }
     
    /////====================== ****************************** ====================== /////
     
     // MARK:  Offset Properties
     
     /// flag that indicates if offsets calculation has already been done or not
     fileprivate var _offsetsCalculated = false
     
     /// An extra offset to be appended to the viewport's top
     open var extraTopOffset: CGFloat = 0.0
     
     /// An extra offset to be appended to the viewport's right
     open var extraRightOffset: CGFloat = 0.0
     
     /// An extra offset to be appended to the viewport's bottom
     open var extraBottomOffset: CGFloat = 0.0
     
     /// An extra offset to be appended to the viewport's left
     open var extraLeftOffset: CGFloat = 0.0
     
     /////====================== ****************************** ====================== /////
     
     // MARK:  Miscellaneous Properties
     
    /// To track whether dataset is selected or not
      open var datasetSelected:Bool = false
    
     fileprivate var firstTime = true
     
     /// Holds all the entries at particular X - value
     /// X-Value -> SetIndex -> EntryIndex
     open var originalMap:[Double:[Int:[Int]]] = [:]
     
     /// To track initial animation status
     open var customAnimationInProgress:Bool = false
     
     /// To track interaction animation status
     open var interactionAnimationInProgress:Bool = false
     
     /// To track Filtered count
     open var removedCount = 0
     
     /// To track drill level
     open var curLevel:Int = -1
     
     /// To find Orientation
     open var isVertical:Bool = true
     
     open var backupDataArray:[ChartData] = []
     
     open var includeLayer:Bool = true
    
    // MARK: - Multi Y-Axis
    
    open var yAxisArray: [YAxis] = []
    
    internal var plotTransformer:Transformer!
    
    internal var yAxisTransformers: [Transformer] = []
    
    internal var yAxisRenderers: [AxisRendererBase] = []
    
    open var yAxisRenderersArray: [AxisRendererBase] {
        get {
            return yAxisRenderers
        }
    }
        
    ///Creating or Disabling the YAxis object based on DataSet visibility, axis index
    internal func updateAxisObjects() {
        
        if self.data?.dataSets == nil {
            return
        }
        
        var axisIndices = Set<Int>()
        for dataset in ((self.data?.dataSets)!) {
            axisIndices.insert(dataset.axisIndex)
        }
        
        createYAxisArray( dataSets: (self.data?.dataSets)!, uniqueIndices: axisIndices)
        
        for yAxis in yAxisArray {
            createYAxisTransformerAndRenderer(yAxis: yAxis)
        }
        
        if xAxisRenderer.transformer == nil
        {
            _xAxisRenderer.transformer = yAxisRenderer(atIndex: 0).transformer
        }
    }
    
    internal func createYAxis(position: YAxis.AxisDependency) -> YAxis {
        return createYAxis(axisIndex: getNextAxisIndex(), position: position)
    }
    
    internal func createYAxis() -> YAxis {
        return createYAxis(axisIndex: getNextAxisIndex(), position: .left)
    }
    
    internal func createYAxisArray(dataSets:[IChartDataSet], uniqueIndices:Set<Int>) {
        
        for axisIndex in uniqueIndices {
            _ = createYAxis(axisIndex: axisIndex)
        }
        
        var visibleUniqueIndices = Set<Int>()
        for dataSet in dataSets {
            if dataSet.visible {
                visibleUniqueIndices.insert(dataSet.axisIndex)
            }
        }
        
        //Disabling the axis if none of the dataSet belongs to the axis index is visible
        for axis in getYAxisArray()
        {
            if visibleUniqueIndices.contains(axis.axisIndex)
            {
                axis.enabled = true
            }
            else {
                axis.enabled = false
            }
        }
        
    }
    
    internal func createYAxisTransformerAndRenderer(yAxis:YAxis) {
        
//        for yAxis in yAxisArray {
            
//            let yAxis = getYAxis(atIndex: axisIndex)
            guard let firstIndex = yAxisArray.firstIndex(of: yAxis)
            else { return }
            
            if firstIndex < yAxisTransformers.count || plotTypes.count == 0
            {
                return
            }
            var type:ChartType = .Pie
            
            for plot in plotTypes
            {
                type = plot
                break
            }
            
            let (transformer,renderer) = createAxisScaleAndRenderer(yAxis: yAxis, type: type)
            yAxisTransformers.append(transformer)
            yAxisRenderers.append(renderer)
//        }
        
    }
    
    open func createYAxis(axisIndex:Int) -> YAxis {
        return createYAxis(axisIndex: axisIndex, position: .left)
    }
    
    internal func createYAxis(axisIndex:Int, position:YAxis.AxisDependency) -> YAxis {
        var axis = getYAxis(atIndex: axisIndex)
        if axis != nil {
            return axis!
        }
        axis = YAxis(position: position)
        guard let yAxis = axis
        else { return YAxis()}
        yAxis.axisIndex = axisIndex
        
//        let (transformer,renderer) = preProcessors[0].createAxisScaleAndRenderer(yAxis: yAxis)
        
        self.yAxisArray.append(yAxis)
//        self.yAxisTransformers.append(transformer)
//        self.yAxisRenderers.append(renderer)
        
        yAxis.valueFormatter = ValueFormatter(chart: self)
        
        return yAxis
    }
    
    internal func createAxisScaleAndRenderer(yAxis:YAxis,type:ChartType) -> (transformer:Transformer, renderer:AxisRendererBase) {

        switch(type)
        {
            case .Dial:
                    guard let dialPlotOption = self.getPlotOptions(type: .Dial) as? DialPlotOptions
                    else { return (Transformer(viewPortHandler: self._viewPortHandler),AxisRendererBase()) }
                    
                    let transformer = PolarTransformer(xScaleRange: dialPlotOption.maxAngle, yScaleRange: dialPlotOption.maxAngle,startAngle: dialPlotOption.startAngle, centerPoint: dialPlotOption.centerCircleBox, radius: dialPlotOption.radius, viewPortHandler: self._viewPortHandler)
                      
                    let renderer = YAxisPolarRenderer(viewPortHandler: self._viewPortHandler, yAxis: yAxis, transformer: transformer, chart: self)
                         
                    return (transformer,renderer)
            
            case .Radar:
                    guard let radarPlotOption = self.getPlotOptions(type: .Radar) as? DialPlotOptions
                    else { return (Transformer(viewPortHandler: self._viewPortHandler),AxisRendererBase()) }
            
                    var transformer: Transformer
            
                    if yAxis.scaleType == .Log || xAxis.scaleType == .Log {
                        transformer = LogPolarTransformer( base: (yAxis.scaleTypeProtocol as? LogScale)?.Base ?? 10.0, isXaxisLogScale: xAxis.scaleType == .Log, isYaxisLogScale: yAxis.scaleType == .Log, xScaleRange: radarPlotOption.maxAngle, yScaleRange: radarPlotOption.maxAngle,startAngle: radarPlotOption.startAngle, centerPoint: radarPlotOption.centerCircleBox, radius: radarPlotOption.radius, viewPortHandler: self._viewPortHandler)
                    }
                    else if yAxis.scaleType == .SQRT || xAxis.scaleType == .SQRT {
                        transformer = SQRTPolarTransformer( isXaxisSQRTScale: xAxis.scaleType == .SQRT, isYaxisSQRTScale: yAxis.scaleType == .SQRT, xScaleRange: radarPlotOption.maxAngle, yScaleRange: radarPlotOption.maxAngle,startAngle: radarPlotOption.startAngle, centerPoint: radarPlotOption.centerCircleBox, radius: radarPlotOption.radius, viewPortHandler: self._viewPortHandler)
                    }
                    else {
                        transformer = PolarTransformer(xScaleRange: radarPlotOption.maxAngle, yScaleRange: radarPlotOption.maxAngle,startAngle: radarPlotOption.startAngle, centerPoint: radarPlotOption.centerCircleBox, radius: radarPlotOption.radius, viewPortHandler: self._viewPortHandler)
                    }
                         
                    let renderer = AxisPolarRadiusRenderer(viewPortHandler: _viewPortHandler, transformer: transformer, axis: yAxis, chartViewBase: self)
                            
                    return (transformer,renderer)
            
            case .HorizontalBarRange:
                    let transformer = TransformerHorizontalBarChart(viewPortHandler: _viewPortHandler)
                    let renderer = YAxisRendererHorizontalBarChart(viewPortHandler: _viewPortHandler, yAxis: yAxis, transformer: transformer, chart: self)
            
                    return (transformer,renderer)
             
            default :
            
                var transformer: Transformer
                var renderer: AxisRendererBase
            
                if isRotated {
                    if yAxis.scaleType == .Log || xAxis.scaleType == .Log {
                        transformer = LogTransformerHorizontalChart(viewPortHandler: self._viewPortHandler, base: (yAxis.scaleTypeProtocol as? LogScale)?.Base ?? 10.0, isXaxisLogScale: xAxis.scaleType == .Log, isYaxisLogScale: yAxis.scaleType == .Log)
                    }
                    else if yAxis.scaleType == .SQRT || xAxis.scaleType == .SQRT {
                        transformer = SQRTTransformerHorizontalChart(viewPortHandler: _viewPortHandler, isXaxisSQRTScale: xAxis.scaleType == .SQRT, isYaxisSQRTScale: yAxis.scaleType == .SQRT)
                    }
                    else {
                        transformer = TransformerHorizontalBarChart(viewPortHandler: self._viewPortHandler)
                    }
                    
                    renderer = YAxisRendererHorizontalBarChart(viewPortHandler: _viewPortHandler, yAxis: yAxis, transformer: transformer, chart: self)
                }
                else {
                    if yAxis.scaleType == .Log || xAxis.scaleType == .Log {
                        transformer = LogTransformer(viewPortHandler: self._viewPortHandler, base: (yAxis.scaleTypeProtocol as? LogScale)?.Base ?? 10.0, isXaxisLogScale: xAxis.scaleType == .Log, isYaxisLogScale: yAxis.scaleType == .Log)
                    }
                    else if yAxis.scaleType == .SQRT || xAxis.scaleType == .SQRT {
                        transformer = SQRTTransformer(viewPortHandler: _viewPortHandler, isXaxisSQRTScale: xAxis.scaleType == .SQRT, isYaxisSQRTScale: yAxis.scaleType == .SQRT)
                    }
                    else {
                        transformer = Transformer(viewPortHandler: self._viewPortHandler)
                    }
                    
                    renderer = YAxisRenderer(viewPortHandler: _viewPortHandler, yAxis: yAxis, transformer: transformer, chart: self)
                }
                
                return (transformer,renderer)
        }
           
    }
    
    internal func getNextAxisIndex() -> Int {
          let yAxisObjects = getYAxisArray()
          if yAxisObjects.isEmpty {
              return 0
          }
        
          guard let curMax = yAxisObjects.map { $0.axisIndex }.max()
            else { return 0 }
          return curMax + 1
      }
    
    @objc public func getYAxis(atIndex axisIndex:Int) -> YAxis? {
        
        let yaxisObjects = getYAxisArray()
        
        if yaxisObjects.count == 0 {
            return nil
        }
        
        for yAxis in yaxisObjects where yAxis.axisIndex == axisIndex {
            return yAxis
        }
        
        return nil
    }
    
    open func getYAxisArray() -> [YAxis]
    {
           return yAxisArray
    }
    
    open func getPlotTransformer() -> Transformer
    {
        return plotTransformer
    }
    
    /// - returns: The Transformer class that contains all matrices and is
       /// responsible for transforming values into pixels on the screen and
       /// backwards.
    open func getTransformer(axisIndex: Int) -> Transformer {
        
        guard data != nil,
              let yAxis = getYAxis(atIndex: axisIndex),
              let firstIndex = yAxisArray.firstIndex(of: yAxis)
        else { return Transformer(viewPortHandler: viewPortHandler) }
        
        if firstIndex >= yAxisTransformers.count
        {
            createYAxisTransformerAndRenderer(yAxis: yAxis)
        }
       return yAxisTransformers[firstIndex]
    }
    
     // MARK: - Multiple (Y) Axis Management
        
    ///Get the axis for dependency and columnorder
    /// - returns: The y-axis object to the corresponding AxisDependency. In the
    /// horizontal bar-chart, LEFT == top, RIGHT == BOTTOM
 /*    @objc public func getAxis(forAxis axis: YAxis.AxisDependency, axisIndex:Int) -> YAxis? {
        updateAxisObjects()
        var axisArray = getYAxisArray(forAxis: axis)
        //index underflow or overflow
        if axisIndex < 0 || axisIndex > axisArray.count {
            return nil
        }
        if axisIndex == axisArray.count {
            _ = createYAxis(position: axis, chart: self)
        }
        axisArray = getYAxisArray(forAxis: axis)
        return axisArray[axisIndex]
    }
    
    ///Creating or Disabling the YAxis object based on DataSet visibility, axis dependency/index
   internal func updateAxisObjects() {
        
        if self.data?.dataSets == nil {
            return
        }
        
        var leftSetIndices = Set<Int>(), rightSetIndices = Set<Int>()
        var leftDataSets:[IChartDataSet] = [], rightDataSets:[IChartDataSet] = []
        for dataset in ((self.data?.dataSets)!) {
            if dataset.axisDependency == .left {
                leftSetIndices.insert(dataset.axisIndex)
                leftDataSets.append(dataset)
            }else {
                rightSetIndices.insert(dataset.axisIndex)
                rightDataSets.append(dataset)
            }
        }
        
        createYAxisArray(axisDependency: .left, dataSets: leftDataSets, uniqueIndices: leftSetIndices)
        createYAxisArray(axisDependency: .right, dataSets: rightDataSets, uniqueIndices: rightSetIndices)
    }
    
    fileprivate func createYAxisArray(axisDependency: YAxis.AxisDependency, dataSets:[IChartDataSet], uniqueIndices:Set<Int>) {
        
        let axisArray = getYAxisArray(forAxis: axisDependency)
        if uniqueIndices.count > 0 && (uniqueIndices.count - axisArray.count) > 0 {
            for _ in 0 ..< (uniqueIndices.count - axisArray.count) {
                _ = createYAxis(position: axisDependency, chart: self)
            }
        }
        
        var hiddenUniqueIndices = Set<Int>()
        var visibleUniqueIndices = Set<Int>()
        for dataSet in dataSets {
            if dataSet.visible {
                visibleUniqueIndices.insert(dataSet.axisIndex)
            }else {
                hiddenUniqueIndices.insert(dataSet.axisIndex)
            }
        }
        
        for axisIndex in visibleUniqueIndices {
            hiddenUniqueIndices.remove(axisIndex)
        }
        
        
        //Disabling the axis if none of the dataSet belongs to the axis index is visible
        let newAxisArray = getYAxisArray(forAxis: axisDependency)
        for index in hiddenUniqueIndices {
            if index < 0 || index >= newAxisArray.count {
                Log.warning("DataSet Axis index and axis count mismatch  ")
                continue
            }
            newAxisArray[index].enabled = false
        }
        
        for index in visibleUniqueIndices {
            if index < 0 || index >= newAxisArray.count {
                Log.warning("DataSet Axis index and axis count mismatch  ")
                continue
            }
            newAxisArray[index].enabled = true
        }
        
    }*/

    
    open func getAxisIndex(axis:YAxis) -> Int? {
//        let axisArray = getYAxisArray(forAxis: axis.axisDependency)
       /* let axisArray = getYAxisArray()
        return axisArray.firstIndex(of: axis)*/
        return axis.axisIndex
    }
    
  /*  /// The left Y axis renderer. This is a read-write property so you can set your own custom renderer here.
    /// **default**: An instance of YAxisRenderer
    /// - returns: The current set left Y axis renderer
    open func leftYAxisRenderer(atIndex axisIndex:Int) -> YAxisRenderer {
        return yAxisRenderer(forAxis: .left, atIndex: axisIndex)
    }
    
    /// The right Y axis renderer. This is a read-write property so you can set your own custom renderer here.
    /// **default**: An instance of YAxisRenderer
    /// - returns: The current set right Y axis r
    open func rightYAxisRenderer(atIndex axisIndex:Int) -> YAxisRenderer {
        return yAxisRenderer(forAxis: .right, atIndex: axisIndex)
    }
    
    func yAxisRenderer(forAxis axis:YAxis.AxisDependency, atIndex axisIndex:Int) -> YAxisRenderer {
        let yAxis = getAxis(forAxis: axis, axisIndex: axisIndex)
        let firstIndex = yAxisArray.firstIndex(of: yAxis!)
        return yAxisRenderers[firstIndex!]
    }*/
    
    /// The Y axis renderer. This is a read-write property so you can set your own custom renderer here.
    /// **default**: An instance of YAxisRenderer
    /// - returns: The current set left Y axis renderer
    open func yAxisRenderer(atIndex axisIndex:Int) -> AxisRendererBase {
        guard let yAxis = getYAxis(atIndex: axisIndex),
              let firstIndex = yAxisArray.firstIndex(of: yAxis)
        else { return AxisRendererBase()}
        
        return yAxisRenderers[firstIndex]
    }
    
    open func isInverted(axisIndex:Int) -> Bool {
        return getYAxis(atIndex: axisIndex)?.isInverted ?? false
    }
    
    /// - returns: The left y-axis object. In the horizontal bar-chart, this is the
    /// top axis.
   /* open func leftAxis(atIndex axisIndex:Int) -> YAxis {
        return getAxis(forAxis: .left, axisIndex: axisIndex)!
    }
    
    /// - returns: The right y-axis object. In the horizontal bar-chart, this is the
    /// bottom axis.
    open func rightAxis(atIndex axisIndex:Int) -> YAxis {
        return getAxis(forAxis: .right, axisIndex: axisIndex)!
    }*/
    
  /* @objc public func getYAxis(atIndex axisIndex:Int) -> YAxis? {
        if axisIndex < 0 || axisIndex > yAxisArray.count {
            return nil
        }
        
        if axisIndex == yAxisArray.count {
            _ = createYAxis(chart: self)
        }
        
        return yAxisArray[axisIndex]
    }*/
    
    public func swapAxis(axisIndexA:Int, axisIndexZ:Int) {
        
        guard let axisObjectA = getYAxis(atIndex: axisIndexA),
              let axisObjectZ = getYAxis(atIndex: axisIndexZ)
        else { return}
        
        let axisADependency = axisObjectA.axisDependency
        let axisZDependency = axisObjectZ.axisDependency
        
        guard let axisArrayIndexA = getYAxisArray().firstIndex(of: axisObjectA),
        let axisArrayIndexZ = getYAxisArray().firstIndex(of: axisObjectZ)
        else { return }
        
        let tempAxisObject = yAxisArray[axisArrayIndexA]
        let tempTransformer = yAxisTransformers[axisArrayIndexA]
        let tempRenderer = yAxisRenderers[axisArrayIndexA]
        
        
        yAxisArray[axisArrayIndexA] = yAxisArray[axisArrayIndexZ]
        yAxisTransformers[axisArrayIndexA] = yAxisTransformers[axisArrayIndexZ]
        yAxisRenderers[axisArrayIndexA] = yAxisRenderers[axisArrayIndexZ]
        yAxisArray[axisArrayIndexA].axisDependency = axisADependency
        
        yAxisArray[axisArrayIndexZ] = tempAxisObject
        yAxisTransformers[axisArrayIndexZ] = tempTransformer
        yAxisRenderers[axisArrayIndexZ] = tempRenderer
        yAxisArray[axisArrayIndexZ].axisDependency = axisZDependency
        
        //Update the axis dependency of all dataset related to axis index A and axis index Z
        notifyDataSetChanged(redrawRequired: true)
        
    }
    
    open func getPlotOptions(type:ChartType) -> IPlotOptions?
    {
        return plotOptions[type]
    }
    
    open func getPlotOptions() -> IPlotOptions
    {
        if plotOptions.count > 0
        {
            for option in plotOptions.values
            {
                return option
            }
        }
        
        return PlotOptionsBase()
        
    }
    
    open func getPlotTypes() -> [ChartType]
    {
        return plotTypes
    }
    
    open func getRenderer() -> DataRenderer?
    {
       if renderers.count > 0
       {
           for renderer in renderers
           {
               return renderer
           }
       }
       
       return nil
           
    }
    
    internal func getProcessor(type:ChartType) -> ChartPreprocessor?
    {
        
        switch  type {
            
            case .Pie:
                let processor = preProcessors.filter{ $0.isKind(of: PiePreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Dial:
                let processor = preProcessors.filter{ $0.isKind(of: DialPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Bar, .Bullet:
            
                if isRotated {
                    let processor = preProcessors.filter{ $0.isKind(of: HorizontalBarPreprocessor.self)}
                    return processor.count > 0 ? processor[0] : nil
                }
                else {
                    let processor = preProcessors.filter{ $0.isKind(of: BarPreprocessor.self)}
                    return processor.count > 0 ? processor[0] : nil
                }
            
            case .Mekko:
                let processor = preProcessors.filter{ $0.isKind(of: MekkoPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Sanky:
                let processor = preProcessors.filter{ $0.isKind(of: SankeyPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .HorizontalBarRange:
                let processor = preProcessors.filter{ $0.isKind(of: HorizontalBarPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Line, .LineRange:
            let processor = preProcessors.filter{ $0.isKind(of: LineChartPreprocessor.self) && !$0.isKind(of: AreaPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case  .Area:
                let processor = preProcessors.filter{ $0.isKind(of: AreaPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
                
            case .Bubble:
                let processor = preProcessors.filter{ $0.isKind(of: BubblePreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
                
            case .BubblePie:
                let processor = preProcessors.filter{ $0.isKind(of: BubblePiePreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .PackedBubble:
                let processor = preProcessors.filter{ $0.isKind(of: PackedBubblePreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
                
            case .Scatter:
                let processor = preProcessors.filter{ $0.isKind(of: ScatterPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Funnel:
                let processor = preProcessors.filter{ $0.isKind(of: FunnelPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .HeatMap:
                let processor = preProcessors.filter{ $0.isKind(of: HeatMapPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Radar:
                let processor = preProcessors.filter{ $0.isKind(of: RadarPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
                
            case .WordCloud:
                let processor = preProcessors.filter{ $0.isKind(of: WordCloudPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            
            case .GeoHeatMap:
                let processor = preProcessors.filter{ $0.isKind(of: GeoMapPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .WaterFall:
                let processor = preProcessors.filter{ $0.isKind(of: WaterFallPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .BoxPlot:
                let processor = preProcessors.filter{ $0.isKind(of: BoxPlotPreprocessor.self)}
                return processor.count > 0 ? processor[0] : nil
            
            case .Combined:
                return nil

        }
            
    }
    
    internal func prepareValuePxMatrix()
    {
        if _rotated
        {
            for i in 0 ..< yAxisTransformers.count {
                yAxisTransformers[i].prepareMatrixValuePx(chartXMin: yAxisArray[i]._axisMinimum, deltaX: CGFloat(yAxisArray[i].axisRange), deltaY: CGFloat(_xAxis.axisRange), chartYMin: _xAxis._axisMinimum)
            }
        }
        else{
            var type:ChartType = .Pie
            
            for plot in plotTypes
            {
                type = plot
                break
            }
            
            var xRange = xAxis.axisRange
            
            switch type {
                case .Radar:
                    if xAxis.scaleType == .Ordinal
                    {
//                        guard let data = data
//                        else { return }
//                        let dataCount = ChartUtils.doubleToIntSafeCast(value:data.xMax+1)
//                        let threshold = 3
//                        var runCount = 1
//                        if dataCount > (xAxis.labelCount + threshold)
//                        {
//                            var interval =  ChartUtils.doubleToIntSafeCast(value:Double((dataCount/xAxis.labelCount)+1))
//                            while (ChartUtils.doubleToIntSafeCast(value:xRange) + runCount)  % interval != 0 {
//                                runCount = runCount + 1
//                            }
//                        }
                        
//                        xRange = xRange + Double(runCount)
                        xRange = xRange + Double(1)
                    }
                
                default:
                    break
            }
            
            for i in 0 ..< yAxisTransformers.count {
                yAxisTransformers[i].prepareMatrixValuePx(chartXMin: _xAxis._axisMinimum, deltaX: CGFloat(xRange), deltaY: CGFloat(yAxisArray[i].axisRange), chartYMin: yAxisArray[i]._axisMinimum)
            }
            
        }
    }
    
    internal func prepareValuePxMatrixForPlot()
    {
        plotTransformer.prepareMatrixValuePxforPlot(chartXMin: 0, deltaX: viewPortHandler.contentWidth, deltaY: viewPortHandler.contentHeight, chartYMin: 0)
    }
      
    internal func prepareOffsetMatrix()
    {
        for i in 0 ..< yAxisTransformers.count {
            yAxisTransformers[i].prepareMatrixOffset(inverted: yAxisArray[i].isInverted)
        }
    }
    
    open func resetMatricesForDataReload()
    {
           Log.info("Resetting matrices")
           for yAxisTransformer in yAxisTransformers {
               yAxisTransformer.resetMatrices()
           }
           self._viewPortHandler.resetMatrix()
           
    }
    
    /////====================== ****************************** ====================== /////
    
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Initializers
    
    public override init(frame: CGRect)
    {
        super.init(frame: frame)
        initialize()
    }
    
    public required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        initialize()
    }
    
    deinit
    {
        self.removeObserver(self, forKeyPath: "bounds")
        self.removeObserver(self, forKeyPath: "frame")
        self.stopDeceleration()
    }
    
    internal func initialize()
    {
        #if os(iOS)
            self.backgroundColor = NSUIColor.clear
        #endif
        
        _animator = Animator()
        _animator.delegate = self
        
        _viewPortHandler = ViewPortHandler()
        _viewPortHandler.setChartDimens(width: bounds.size.width, height: bounds.size.height)
        _viewPortHandler.chartViewBase = self
        
        chartDescription = Description()
        
        _legend = Legend()
        _legend.enabled = false
        _legendRenderer = LegendRenderer(viewPortHandler: _viewPortHandler, legend: _legend)
        
        _colorAxis = ColorAxis(legend: _legend)
        
        _xAxis = XAxis()
        
        _xAxis.valueFormatter = ValueFormatter(chart: self)
        
        _ = createYAxis(position: .left)
        
        _ = createYAxis(position: .right)
        
        _xAxisRenderer = XAxisRenderer(viewPortHandler: _viewPortHandler, xAxis: _xAxis, transformer: nil, chartViewBase: self)
        
        plotTransformer = Transformer(viewPortHandler: _viewPortHandler)
    
        self.addObserver(self, forKeyPath: "bounds", options: .new, context: nil)
        self.addObserver(self, forKeyPath: "frame", options: .new, context: nil)
        
        _tapEventListener = TapEventListener(target: self, action: #selector(tapEventRecognized(_:)))
        _tapEventListener?.nsuiNumberOfTapsRequired = 1 //.numberOfTapsRequired = 1
        
        _doubleTapEventListener = TapEventListener(target: self, action: #selector(doubleTapEventRecognized(_:)))
        _doubleTapEventListener?.nsuiNumberOfTapsRequired = 2 //.numberOfTapsRequired = 2
        _doubleTapEventListener?.isEnabled = false
        
        #if os(iOS)
        _longPressEventListener = LongPressEventListener(target: self, action: #selector(longPressEventRecognized(_:)))
        
        if #available(iOS 13.0, *) {
            _hoverEventListener = HoverEventListener(target: self, action: #selector(hoverEventRecognized(_:)))
        }
        
        #endif
        _panEventListener = PanEventListener(target: self, action: #selector(panEventRecognized(_:)))
        _panEventListener?.delegate = self
        
        _pinchEventListener?.isEnabled = _pinchZoomEnabled || _scaleXEnabled || _scaleYEnabled
        
        #if !os(tvOS)
        _rotationGestureRecognizer = NSUIRotationGestureRecognizer(target: self, action: #selector(rotationGestureRecognized(_:)))
        _rotationGestureRecognizer.isEnabled = rotationWithTwoFingers
        _pinchEventListener = PinchEventListener(target: self, action: #selector(pinchEventRecognized(_:)))
        _pinchEventListener?.delegate = self
       #endif
        
        self.addGestureRecognizer(_tapEventListener!)
        self.addGestureRecognizer(_doubleTapEventListener!)
        #if os(iOS)
        self.addGestureRecognizer(_longPressEventListener!)
        
        if let _hoverEventListener {
            self.addGestureRecognizer(_hoverEventListener)
        }
        
        #endif
        self.addGestureRecognizer(_panEventListener!)
        #if !os(tvOS)
        self.addGestureRecognizer(_rotationGestureRecognizer)
        self.addGestureRecognizer(_pinchEventListener!)
        #endif
        
        isOccupancgGridMappingIsInitialized = false
    }
    
    /// calculates the required number of digits for the values that might be drawn in the chart (if enabled), and creates the default value formatter
    internal func setupDefaultFormatter(min: Double, max: Double)
    {
        // check if a custom formatter is set or not
        var reference = Double(0.0)
        
        if let data = _data , data.entryCount >= 2
        {
            reference = fabs(max - min)
        }
        else
        {
            let absMin = fabs(min)
            let absMax = fabs(max)
            reference = absMin > absMax ? absMin : absMax
        }
        
        
        if _defaultValueFormatter is DefaultValueFormatter
        {
            // setup the formatter with a new number of digits
            let digits = ChartUtils.decimals(reference)
            
            (_defaultValueFormatter as? DefaultValueFormatter)?.decimals
                = digits
        }
    }
    
    /// calculate and sets default formatters
    internal func setFormatters()
    {
        // calculate how many digits are needed
        guard let data = _data
        else { return }
        setupDefaultFormatter(min: data.getYMin(), max: data.getYMax())
        
        for set in data.dataSets
        {
            if set.needsFormatter || set.valueFormatter === _defaultValueFormatter
            {
                set.valueFormatter = _defaultValueFormatter
            }
        }
    }
    
    /// Track Removed Counts
    internal func trackEntriesEnabledCount()
    {
        removedCount = 0
        
        guard let data = _data
        else { return }
       
        if data.dataSetCount == 1
        {
            for i in 0..<(data.dataSets[0].entryCount)
            {
                guard let entry = data.dataSets[0].entryForIndex(i)
                else { continue }
                if  !(entry.enabled)
                {
                    removedCount += 1
                }
            }
        }
    }
    
    /// Sets unique plot types in data
    internal func setPlotTypes()
    {
        plotTypes.removeAll()
        
        if let dataSets = _data?.dataSets
        {
            for set in dataSets
            {
                if !(plotTypes.contains(set.plotType))
                {
                    plotTypes.append(set.plotType)
                }
            }
        }
        
        if plotTypes.count > 1
        {
            isCombined = true
            doubleTapEnabled = true
        }
        
    }
    
    /// create PlotOptions
    internal func createPlotOptions()
    {
        preProcessors.removeAll()
        
        highlighter = ChartHighlighter(chart: self)
        
        for plot in plotTypes
        {
            switch plot {
            case .Pie:
                plotOptions[.Pie] = PiePlotOptions()
                preProcessors.append(PiePreprocessor(chart: self))
                highlighter = PieHighlighter(chart: self)
                
            case .Bar,.Bullet:
                plotOptions[plot] = BarPlotOptions()
                
                if isRotated {
                    preProcessors.append(HorizontalBarPreprocessor(chart: self))
                }
                else {
                    preProcessors.append(BarPreprocessor(chart:self))
                }
                highlighter = BarHighlighter(chart: self)
                
            case .Mekko:
                plotOptions[plot] = BarPlotOptions()
                preProcessors.append(MekkoPreprocessor(chart:self))
                highlighter = BarHighlighter(chart: self)
                
            case .Sanky:
                plotOptions[plot] = SankeyPlotOptions()
                preProcessors.append(SankeyPreprocessor(chart:self))
                highlighter = BarHighlighter(chart: self)
                
            case .HorizontalBarRange:
                plotOptions[plot] = BarPlotOptions()
                preProcessors.append(HorizontalBarPreprocessor(chart: self))
                highlighter = HorizontalBarHighlighter(chart: self)
                
            case .Line, .LineRange:
                plotOptions[plot] = LinePlotOptions()
                preProcessors.append(LineChartPreprocessor(chart: self))
                highlighter = LineHighlighter(chart: self)
                
            case .Area:
                plotOptions[plot] = AreaPlotOptions()
                preProcessors.append(AreaPreprocessor(chart: self))
                highlighter = AreaHighlighter(chart: self)
                
            case .Scatter:
                plotOptions[.Scatter] = AxisChartPlotOptions()
                preProcessors.append(ScatterPreprocessor(chart: self))
                
            case .Bubble:
                plotOptions[.Bubble] = BubblePlotOptions()
                preProcessors.append(BubblePreprocessor(chart: self))
                
            case .BubblePie:
                plotOptions[.BubblePie] = BubblePiePlotOptions()
                preProcessors.append(BubblePiePreprocessor(chart: self))
                
            case .PackedBubble:
                plotOptions[plot] = BubblePlotOptions()
                preProcessors.append(PackedBubblePreprocessor(chart: self))
                highlighter = PackedBubbleHighlighter(chart: self)
                
            case .Funnel:
                plotOptions[.Funnel] = FunnelPlotOptions()
                preProcessors.append(FunnelPreprocessor(chart: self))
                highlighter = FunnelHighlighter(chart: self)
                
            case .Dial:
                plotOptions[.Dial] = DialPlotOptions()
                preProcessors.append(DialPreprocessor(chart: self))
                highlighter = PieHighlighter(chart: self)
                
            case .Radar:
                plotOptions[.Radar] = DialPlotOptions()
                preProcessors.append(RadarPreprocessor(chart: self))
                
            case .HeatMap:
                plotOptions[plot] = HeatMapPlotOptions()
                preProcessors.append(HeatMapPreprocessor(chart: self))
                highlighter = BarHighlighter(chart: self)
                
                
            case .WordCloud:
                plotOptions[.WordCloud] = WordCloudPlotOptions()
                preProcessors.append(WordCloudPreprocessor(chart: self))
                highlighter = WordCloudHighlighter(chart: self)
                                
            case .GeoHeatMap:
                plotOptions[.GeoHeatMap] = GeoMapPlotOptions()
                preProcessors.append(GeoMapPreprocessor(chart: self))
                highlighter = GeoMapHighlighter(chart: self)
                
            case .WaterFall:
                plotOptions[plot] = WaterFallPlotOptions()
                preProcessors.append(WaterFallPreprocessor(chart:self))
                highlighter = BarHighlighter(chart: self)
                
            case .BoxPlot:
                plotOptions[plot] = BoxPlotPlotOptions()
                preProcessors.append(BoxPlotPreprocessor(chart:self))
                highlighter = BarHighlighter(chart: self)
                
            
            default:
                plotOptions[plot] = AxisChartPlotOptions()
            }
        }
        
        if isCombined
        {
            highlighter = CombinedHighlighter(chart: self)
        }
    }
    
    /// create PlotOptions
     internal func setDefaultValues()
     {
          for processor in preProcessors
          {
            processor.initialize()
          }
     }
    
    func updateDataCategoryOrder() -> Bool
    {
        var flag = false
        
        // X-Axis
        if ( xAxis.scaleType == .Ordinal && (xAxis.categoryOrder != nil))
        {
            data?.xStringOrder = xAxis.categoryOrder
            flag = true
        }

        for yAxis in yAxisArray where yAxis.scaleType == .Ordinal && (yAxis.categoryOrder != nil && yAxis.categoryOrder!.count > 0)  {
            
            flag = true
         
            if data?.yStringOrder == nil {
                data?.yStringOrder = [Int:[String]]()
            }
            
            data?.yStringOrder![yAxis.axisIndex] = yAxis.categoryOrder
        }
        
        return flag
    }
    
    /// Creates the renderers needed for this combined-renderer in the required order. Also takes the DrawOrder into consideration.
    open func createRenderers()
    {
        // Date Renderers
        renderers.removeAll()
       
        for order in drawRenderOrder
        {
            let renderer = customRenderers[order]
            
            switch (order)
            {
                case .Pie:
                    if plotTypes.contains(ChartType.Pie)
                    {
                        
                        renderers.append(renderer != nil ? renderer! : PieChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Dial:
                    if plotTypes.contains(ChartType.Dial)
                    {
                        renderers.append(renderer != nil ? renderer! : DialChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Radar:
                    if plotTypes.contains(ChartType.Radar)
                    {
                        renderers.append(renderer != nil ? renderer! : RadarChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Bar, .Bullet, .Mekko:
                    if plotTypes.contains(order)
                    {
                        renderers.append(renderer != nil ? renderer! : BarChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .HorizontalBarRange:
                    if plotTypes.contains(order)
                    {
                        renderers.append(renderer != nil ? renderer! : HorizontalBarChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Line,.LineRange:
                    if plotTypes.contains(order) && !renderers.contains(where: { $0.isKind(of: LineChartRenderer.self) && !$0.isKind(of: AreaChartRenderer.self) })
                    {
                        renderers.append(renderer != nil ? renderer! : LineChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Area:
                    if plotTypes.contains(order)
                    {
                        renderers.append(renderer != nil ? renderer! : AreaChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Scatter:
                    if plotTypes.contains(ChartType.Scatter)
                    {
                        renderers.append(renderer != nil ? renderer! : ScatterChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Sanky:
                    if plotTypes.contains(ChartType.Sanky)
                    {
                        renderers.append(renderer != nil ? renderer! : SankeyChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Bubble:
                    if plotTypes.contains(ChartType.Bubble)
                    {
                        renderers.append(renderer != nil ? renderer! : BubbleChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                    
                case .BubblePie:
                    if plotTypes.contains(ChartType.BubblePie)
                    {
                        renderers.append(renderer != nil ? renderer! : BubblePieChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .PackedBubble:
                    if plotTypes.contains(ChartType.PackedBubble)
                    {
                        renderers.append(renderer != nil ? renderer! : PackedBubbleRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                 
                case .HeatMap:
                    if plotTypes.contains(ChartType.HeatMap)
                    {
                        renderers.append(renderer != nil ? renderer! : HeatMapChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .Funnel:
                    if plotTypes.contains(ChartType.Funnel)
                    {
                        renderers.append(renderer != nil ? renderer! : FunnelChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                    
                case .WordCloud:
                    if plotTypes.contains(ChartType.WordCloud)
                    {
                        renderers.append(renderer != nil ? renderer! : TextChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                                
                case .GeoHeatMap:
                    if plotTypes.contains(ChartType.GeoHeatMap)
                    {
                        renderers.append(renderer != nil ? renderer! : GeoMapRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .WaterFall:
                    if plotTypes.contains(ChartType.WaterFall)
                    {
                        renderers.append(renderer != nil ? renderer! : WaterFallChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                
                case .BoxPlot:
                    if plotTypes.contains(order)
                    {
                        renderers.append(renderer != nil ? renderer! : BoxPlotChartRenderer(chart: self, animator: _animator, viewPortHandler: _viewPortHandler))
                    }
                    break
                            
                default :
                    break
            }
        }
        
        // X-Axis Renderer
        var type:ChartType = .Pie
        
        for plot in plotTypes
        {
            type = plot
            break
        }
        if type == .Radar
        {
            xAxisRenderer = AxisPolarAngleRenderer(viewPortHandler: viewPortHandler, transformer: nil, axis: xAxis, chartViewBase: self)
        }

    }
    
    /////====================== ****************************** ====================== /////
    
     // MARK: - Touch Events
        
    @objc fileprivate func tapEventRecognized(_ recognizer: TapEventListener)
    {
        if isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        
        let location = recognizer.location(in: self)
        
        var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
        
        if isCombined
        {
            (entry,layer) = self.getEntryAndLayer(recognizer, location: location)
        }
        else{
            // Only one processor will be available
            for processor in preProcessors
            {
                (entry,layer) = processor.getEntryAndLayer(recognizer, location: location)
            }
        }
        
        recognizer.handler?.execute(self, entry: entry, entryLayer: layer, recognizer, recognizer.location(in: self))
        
//        if chartActionListener != nil{
//            chartActionListener?.tapEventCalled?(chartView: self, selectedEntry: entry, selectedLayer: layer)
//        }
        
    }
    
    /// Double Tap Gesture
    @objc fileprivate func doubleTapEventRecognized(_ recognizer: TapEventListener)
    {
        Log.info(" Double Tap Gesture Type ")
        
        tapEventRecognized(recognizer)
    }
    
    #if os(iOS)
    @objc fileprivate func longPressEventRecognized(_ recognizer: LongPressEventListener)
    {
        if isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        let location = recognizer.location(in: self)
        
        var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
        
        if isCombined
        {
            (entry,layer) = self.getEntryAndLayer(recognizer, location: location)
        }
        else{
            // Only one processor will be available
            for processor in preProcessors
            {
                (entry,layer) = processor.getEntryAndLayer(recognizer, location: location)
            }
        }
        
        recognizer.handler?.execute(self, entry: entry, entryLayer: layer, recognizer, recognizer.location(in: self))
        
    }
    
    @available(iOS 13.0, *)
    @objc fileprivate func hoverEventRecognized(_ recognizer: HoverEventListener) {
        
        if isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        
        let location = recognizer.location(in: self)
        
        var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
        
        if isCombined
        {
            (entry,layer) = self.getEntryAndLayer(recognizer, location: location)
        }
        else{
            // Only one processor will be available
            for processor in preProcessors
            {
                (entry,layer) = processor.getEntryAndLayer(recognizer, location: location)
            }
        }
        
        recognizer.handler?.execute(self, entry: entry, entryLayer: layer, recognizer, recognizer.location(in: self))
        
    }
    #endif
        
    @objc fileprivate func panEventRecognized(_ recognizer: PanEventListener)
    {
        if self.isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        let location = recognizer.location(in: self)
        
        var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
        
        if isCombined
        {
            (entry,layer) = self.getEntryAndLayer(recognizer, location: location)
        }
        else{
            // Only one processor will be available
            for processor in preProcessors
            {
                (entry,layer) = processor.getEntryAndLayer(recognizer, location: location)
            }
        }
        
        recognizer.handler?.execute(self, entry: entry, entryLayer: layer, recognizer, recognizer.location(in: self))
        
    }
    
    #if !os(tvOS)
    
    @objc fileprivate func pinchEventRecognized(_ recognizer: PinchEventListener)
    {
        if self.isAnimationinProgress()
        {
            recognizer.isEnabled = false
            recognizer.isEnabled = true
            return
        }
        let location = recognizer.location(in: self)
        
        var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
        
        if isCombined
        {
            (entry,layer) = self.getEntryAndLayer(recognizer, location: location)
        }
        else{
            // Only one processor will be available
            for processor in preProcessors
            {
                (entry,layer) = processor.getEntryAndLayer(recognizer, location: location)
            }
        }
        
        recognizer.handler?.execute(self, entry: entry, entryLayer: layer, recognizer, recognizer.location(in: self))
        
    }
    
    @objc fileprivate func rotationGestureRecognized(_ recognizer: NSUIRotationGestureRecognizer)
    {
       /* if recognizer.state == NSUIGestureRecognizerState.began
        {
            PieHelperFunctions.stopDeceleration()
           
            _startAngle = self.rawRotationAngle
        }
       
        if recognizer.state == NSUIGestureRecognizerState.began || recognizer.state == NSUIGestureRecognizerState.changed
        {
            let angle = ChartUtils.Math.FRAD2DEG * recognizer.nsuiRotation
           
            self.rotationAngle = _startAngle + angle
            setNeedsDisplay()
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended
        {
            let angle = ChartUtils.Math.FRAD2DEG * recognizer.nsuiRotation
           
            self.rotationAngle = _startAngle + angle
            setNeedsDisplay()
           
            if isDragDecelerationEnabled
            {
                stopDeceleration()
               
                _decelerationAngularVelocity = ChartUtils.Math.FRAD2DEG * recognizer.velocity
               
                if _decelerationAngularVelocity != 0.0
                {
                    _decelerationLastTime = CACurrentMediaTime()
                    _decelerationDisplayLink = NSUIDisplayLink(target: self, selector: #selector(PieRadarChartViewBase.decelerationLoop))
                    _decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                }
            }
        }*/
    }
    #endif
        
        /////====================== ****************************** ====================== /////
    
    // MARK: - Frame Change
   
    open func setExtraOffsets(left: CGFloat, top: CGFloat, right: CGFloat, bottom: CGFloat)
    {
        extraLeftOffset = left
        extraTopOffset = top
        extraRightOffset = right
        extraBottomOffset = bottom
    }
    
    open func layoutUpdate()
    {
        if firstTime
        {
            firstTime = false
        }
        else{
            /// Need to check
            //            customAnimationInProgress = false
        }
    }
    
    open override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?)
    {
        if keyPath == "bounds" || keyPath == "frame"
        {
            let bounds = self.bounds
            
            if (_viewPortHandler !== nil &&
                (bounds.size.width != _viewPortHandler.chartWidth ||
                    bounds.size.height != _viewPortHandler.chartHeight))
            {
                _viewPortHandler.setChartDimens(width: bounds.size.width, height: bounds.size.height)
                
                if isOccupancgGridMappingIsInitialized {
                    isOccupancgGridMappingIsInitialized = false
                }
                
                // This may cause the chart view to mutate properties affecting the view port -- lets do this
                // before we try to run any pending jobs on the view port itself
                if self.data != nil {
                    notifyDataSetChanged(redrawRequired: true)
                }
                
                callDelegateForLegendReload()
                
                // Finish any pending viewport changes
                while (!_viewportJobs.isEmpty)
                {
                    let job = _viewportJobs.remove(at: 0)
                    job.doJob()
                }
            }
        }
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Data Backup
    
   func takeDataBackup()
    {
        guard let newData = self.data?.copy() as? ChartData
        else { return }
        backupDataArray.append(newData)
    }
    
    open func getDataBackUpAtLevel(level:Int) -> ChartData?
    {
        var chartData:ChartData? = nil
        
        for i in stride(from: (self.backupDataArray.count - 1), through: level, by: -1)
        {
            chartData = self.removeLastDataBackup()
            
            if i == level
            {
                curLevel = level
            }
            
        }
        
        curLevel = curLevel - 1
        
        return chartData
    }
    
    open func updateBackupData()
    {
        if curLevel == backupDataArray.count - 1
        {
            self.updateDataOrigIndex()
            self.takeDataBackup()
        }
    }
    
    open func updateDataOrigIndex()
    {
        guard let chartData = _data
        else { return }
        
        for set in chartData.dataSets
        {
            for i in 0 ..< set.entryCount
            {
                let entry = set.entryForIndex(i)
                
                if entry?.origIndex == nil
                {
                    entry?.origIndex = Double(i)
                    entry?.origX = entry?.x
                }
                else{
                    break
                }
            }
        }
        
        if originalMap.count == 0 {
            
            for setIndex in 0..<(chartData.dataSets.count)
            {
                guard let set = (data?.getDataSetByIndex(setIndex))
                else { continue }
                
                for entryIndex in 0 ..< set.entryCount
                {
                    guard let entry = (set.entryForIndex(entryIndex))
                    else { continue }
                    let key = entry.x
                    
                    if originalMap[key] == nil{
                        originalMap[key] = [setIndex:[entryIndex]]
                    }
                    else{
                        if originalMap[key]![setIndex] == nil{
                            originalMap[key]![setIndex] = [entryIndex]
                        }
                        else{
                            originalMap[key]![setIndex]?.append(entryIndex)
                        }
                    }
                }
            }
            
        }
        
    }
    
    open func removeLastDataBackup() -> ChartData?
    {
        var lastBackUpData:ChartData? = nil
        let count = backupDataArray.count
        if count > 0
        {
            lastBackUpData = backupDataArray.remove(at: count-1)
        }
        return lastBackUpData
    }
    
    /// - returns: The index of the DataSet this x-index belongs to.
    open func dataSetIndexForIndex(_ xValue: Double) -> Int
    {
        let dataSets = _data?.dataSets ?? []
        
        for i in 0 ..< dataSets.count
        {
            if (dataSets[i].entryForXValue(xValue, closestToY: Double.nan) !== nil)
            {
                return i
            }
        }
        
        return -1
    }

    /////====================== ****************************** ====================== /////
    
    // MARK: - MisCellaneous Methods
    
    /// Clears the chart from all data (sets it to null) and refreshes it (by calling setNeedsDisplay()).
    open func clear()
    {
        _data = nil
        _offsetsCalculated = false
        _indicesToHighlight.removeAll()
        lastHighlighted = nil
        
        setNeedsDisplay()
    }
    
    /// Removes all DataSets (and thereby Entries) from the chart. Does not set the data object to nil. Also refreshes the chart by calling setNeedsDisplay().
    open func clearValues()
    {
        _data?.clearValues()
        setNeedsDisplay()
    }
    
    /// - returns: `true` if the chart is empty (meaning it's data object is either null or contains no entries).
    open func isEmpty() -> Bool
    {
        guard let data = _data else { return true }
        
        if data.entryCount <= 0
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    open func isAnimationinProgress()->Bool{
        if _animator._displayLink != nil || self.customAnimationInProgress || self.interactionAnimationInProgress
        {
            return true
        }else{
            return false
        }
    }
    
    open func updateLastSelectedEntry(entry:ChartDataEntry?) {
         if lastSelected == nil {
             lastSelected = []
         }else {
             lastSelected?.removeAll()
         }
         if let entry = entry {
             lastSelected?.append(entry)
         }
     }
     
     open func updateLastSelectedEntries(entries:[ChartDataEntry]) {
         if lastSelected == nil {
             lastSelected = []
         }else {
             lastSelected?.removeAll()
         }
         lastSelected?.append(contentsOf: entries)
     }
     
     open func IsEntrySelected(entry:ChartDataEntry?) -> Bool {
         guard let lastSelected = self.lastSelected,
                 let entry = entry
             else {
             return false
         }
         
         var isEntryAvailable:Bool = false
         
         for availableEntry in lastSelected where availableEntry === entry {
             isEntryAvailable = true
             break
         }
         
         return isEntryAvailable
     }
     
     open func IsEntryXSelected(x:Double) -> Bool {
         guard let lastSelected = self.lastSelected else {
             return false
         }
         
         var isEntryAvailable:Bool = false
         
         for availableEntry in lastSelected where availableEntry.x == x {
             isEntryAvailable = true
             break
         }
         
         return isEntryAvailable
     }
     
     open func IsEntryRoundedXSelected(x:Double) -> Bool {
         guard let lastSelected = self.lastSelected else {
             return false
         }
         
         var isEntryAvailable:Bool = false
         
         for availableEntry in lastSelected where round(availableEntry.x) == x {
             isEntryAvailable = true
             break
         }
         
         return isEntryAvailable
     }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Data updation calculation
    
    /// Lets the chart know its underlying data has changed and should perform all necessary recalculations.
    /// It is crucial that this method is called everytime data is changed dynamically. Not calling this method can lead to crashes or unexpected behaviour.
    open func notifyDataSetChanged(redrawRequired: Bool)
    {
        updateLongestLabelOfAllData()
        
        if isCombined{
            var processor = getProcessor(type: scalePreference)
            
            if processor == nil && plotTypes.count > 0
            {
                scalePreference = plotTypes[0]
                processor = getProcessor(type: scalePreference)
            }
            
//            processor.notifyDataSetChanged(redrawRequired: redrawRequired)
            
            if(getVisibleDataCount(plotType: scalePreference) == 0)
            {
                var otherProcessor:ChartPreprocessor? = processor
                
                for otherType in plotTypes where otherType != scalePreference
                {
                    if (getVisibleDataCount(plotType: otherType) > 0)
                    {
                        otherProcessor = getProcessor(type: otherType) ?? processor
                        break
                    }
                }
                otherProcessor?.notifyDataSetChanged(redrawRequired: redrawRequired)
            }else {
                processor?.notifyDataSetChanged(redrawRequired: redrawRequired)
            }
            
            if scalePreference != .BubblePie && plotTypes.contains(.BubblePie)
            {
                (getProcessor(type: .BubblePie) as? BubblePiePreprocessor)?.updateBuffer()
            }
            
            if plotTypes.contains(.Line) && (getVisibleDataCount(plotType: .Line) > 0) || plotTypes.contains(.LineRange) && (getVisibleDataCount(plotType: .LineRange) > 0)
            {
                (getProcessor(type: .Line) as? LineChartPreprocessor)?.calcPosNegSum()
                (getProcessor(type: .Line) as? LineChartPreprocessor)?.calcMinMax()
                (getProcessor(type: .Line) as? LineChartPreprocessor)?.axisCorrection()
            }
            
            if plotTypes.contains(.Area) && (getVisibleDataCount(plotType: .Area) > 0)
            {
                (getProcessor(type: .Area) as? AreaPreprocessor)?.calcPosNegSum()
                (getProcessor(type: .Area) as? AreaPreprocessor)?.calcMinMax()
                (getProcessor(type: .Area) as? AreaPreprocessor)?.axisCorrection()
            }

            if plotTypes.contains(.Bar) && (getVisibleDataCount(plotType: .Bar) > 0)
            {
                (getProcessor(type: .Bar) as? BarPreprocessor)?.calcPosNegSum()
                (getProcessor(type: .Bar) as? BarPreprocessor)?.calcMinMax()
                (getProcessor(type: .Bar) as? BarPreprocessor)?.axisCorrections()
            }
        }
        else{
            for processor in preProcessors
            {
                processor.notifyDataSetChanged(redrawRequired: redrawRequired)
            }
        }
        
        calculateOffsets()
        
        updateAxisMinAndMax()
        
        if redrawRequired && !plotTypes.contains(where: { $0 == .Dial || $0 == .Pie || $0 == .Funnel || $0 == .PackedBubble || $0 == .WordCloud || $0 == .Sanky || $0 == .GeoHeatMap || $0 == .HeatMap}) {
            
            if let chartData = data, !isOccupancgGridMappingIsInitialized && !(chartData.dataLabelRenderingMode == .showAll) {
                OccupancyGridMapping.initializeMatrix(viewPortSize: CGSize(width: viewPortHandler.chartWidth, height: viewPortHandler.chartHeight))
                isOccupancgGridMappingIsInitialized = true
            }
            
            prepareDataLabelSize()
            ChartPreprocessor.prepareDataLabelRects(chart: self)
        }
    }
    
    func getVisibleDataCount(plotType:ChartType) -> Int
    {
        guard let data = data else {
            return 0
        }
        var count = 0
        for set in data.dataSets where set.visible && set.plotType == plotType {
            count = count + 1
        }
        return count;
    }
    
    func getVisibleProcessors() -> [ChartPreprocessor]
    {
        var visibleProcessors:[ChartPreprocessor] = []
        guard let data = data else {
            return visibleProcessors
        }
        
        for set in data.dataSets where set.visible {
            guard let processor = getProcessor(type: set.plotType)
            else { continue }
            visibleProcessors.append(processor)
        }
        return visibleProcessors
    }
    
    open func notifyPlotUpdated()
    {
        guard let sublayers = (self.nsuiLayer?.sublayers)
        else { return }

           for layer in sublayers
           {

                if layer.delegate == nil
                {
                    layer.removeFromSuperlayer()
                }

            }
        
           _offsetsCalculated = false
          
           trackEntriesEnabledCount()
           
           setPlotTypes()
           
           createPlotOptions()
    
            for (type,plot) in plotOptions
            {
                guard let plotValue = plot as? PlotOptionsBase
                else { continue }
                plotDelegate?.updatePlotOptions?(plotOption: plotValue, type: type)
            }
          
        yAxisTransformers.removeAll()
        yAxisRenderers.removeAll()
        for yAxis in yAxisArray {
            createYAxisTransformerAndRenderer(yAxis: yAxis)
        }
        _xAxisRenderer.transformer = yAxisRenderer(atIndex: 0).transformer
        
        prepareOffsetMatrix()
        
        setDefaultValues()
          
           createRenderers()
        
           for dataRenderer in renderers
           {
               dataRenderer.initBuffers()
           }
          
          // let the chart know there is new data
          // notifyDataSetChanged()
          
          var flag = false
          
          // X-Axis
          if ( xAxis.scaleType == .Ordinal && (xAxis.categoryOrder != nil))
          {
              data?.xStringOrder = xAxis.categoryOrder
              flag = true
          }

          for yAxis in yAxisArray where yAxis.scaleType == .Ordinal && yAxis.categoryOrder != nil  {
              
              flag = true
           
              if data?.yStringOrder == nil {
                  data?.yStringOrder = [Int:[String]]()
              }
              
              data?.yStringOrder![yAxis.axisIndex] = yAxis.categoryOrder
          }
          
          
          if flag
          {
              data?.updateXYValues()
              data?.notifyDataChanged()
          }
        
        self.notifyDataSetChanged(redrawRequired: true)

    }
    
    func updateLongestLabelOfAllData()
    {
        guard let dataSets = self.data?.dataSets,
              xAxis.longestLabel == ""
        else {
            return
        }
        
        xAxis.resetLongestLabelProps()
        
        for yAxis in getYAxisArray() {
            yAxis.resetLongestLabelProps()
        }
        
        let axisAttributes = prepareLabelAttributes()
        
//        for axis in axisAttributes.keys {
//            let size = axis.getStoredSize(text: axis.longestLabel, labelAttrs: axisAttributes[axis]!)
//        }
        
        var customTickLongestSize = CGSize.zero
        for set in dataSets where set.isVisible
        {
            guard let yAxis = getYAxis(atIndex: set.axisIndex)
            else { continue }
                                    
            for i in 0 ..< set.entryCount
            {
                let entryObj = set.entryForIndex(i)
                
                if (entryObj == nil) {
                    continue
                }
                
                let entry = entryObj!
                                
                if (!entry.x.isNaN){
                    let xString = xAxis.getFormattedValue(value: entry.x)
                    if let xAttributes = axisAttributes[xAxis] {
                        xAxis.updateLongest(text: xString, labelAttrs: xAttributes)
                    }
                    if xAxis.customTickEnabled && xAxis.tickDelegate != nil
                    {
                        let size = xAxis.tickDelegate!.getTickSizeforEntry(axis: xAxis, value: entry.x, chart: self)
                        customTickLongestSize = CGSize(width:max(customTickLongestSize.width,size.width),height: max(customTickLongestSize.height,size.height))
                    }
                }
                
                if yAxis.isEnabled{
                    if (!entry.y.isNaN){
                        let yString = yAxis.getFormattedValue(value: entry.y)
                        if let yAttributes = axisAttributes[yAxis] {
                            yAxis.updateLongest(text: yString, labelAttrs: yAttributes)
                        }
                    }
                }
                                
            }
        }
        
        xAxis.longestSize = customTickLongestSize
        
        for yAxis in yAxisArray where yAxis.scaleType == .Ordinal && yAxis.categoryOrder != nil  {
            if let yAttributes = axisAttributes[yAxis] {
                for stringValue in yAxis.categoryOrder!
                {
                    yAxis.updateLongest(text: stringValue, labelAttrs: yAttributes)
                }
            }
        }
                
    }
    
    fileprivate func prepareLabelAttributes() -> [AxisBase : [NSAttributedString.Key : Any]] {
    
        var axisAttributes : [AxisBase : [NSAttributedString.Key : Any]] = [:]
        
        let labelAttrs = [NSAttributedString.Key.font: self.xAxis.labelHighlightFont ?? self.xAxis.labelFont]
            
        axisAttributes[self.xAxis] = labelAttrs
        
        for yAxis in getYAxisArray() {
            let labelAttrs = [NSAttributedString.Key.font: yAxis.labelHighlightFont ?? yAxis.labelFont]
            axisAttributes[yAxis] = labelAttrs
            
        }
    
        return axisAttributes
    }

    
    /*fileprivate func getProcessor(type:CombinedChartView.scalePriority) -> ChartPreprocessor?
    {
        switch  type {
            
        case .Line:
            for calc in p
            {
                if calc.isKind(of: LineChartPreprocessor.self)
                {
                    return calc
                }
            }
            return nil
            
        case .Bar:
            for calc in _preProcessors
            {
                if calc.isKind(of: BarPreprocessor.self)
                {
                    return calc
                }
            }
            return nil
            
        case .Bubble:
            for calc in _preProcessors
            {
                if calc.isKind(of: LineChartPreprocessor.self)
                {
                    return calc
                }
            }
            return nil
            
//        case .candle:
//            for calc in _preProcessors
//            {
//                if calc.isKind(of: LineChartPreprocessor.self)
//                {
//                    return calc
//                }
//            }
//            return nil
            
            
        case .Scatter:
            for calc in _preProcessors
            {
                if calc.isKind(of: ScatterPreprocessor.self)
                {
                    return calc
                }
            }
            return nil
            
        default :
            return nil
        }
        
    }*/
    
    /// Calculates the offsets of the chart to the border depending on the position of an eventual legend or depending on the length of the y-axis and x-axis labels and their position
    internal func calculateOffsets()
    {
        for processor in preProcessors
        {
            processor.calculateOffsets()
        }
    }
    
    /// calcualtes the y-min and y-max value and the y-delta and x-delta value
    internal func calcMinMax()
    {
        if isCombined{
            for processor in getVisibleProcessors()
            {
                processor.calcMinMax()
            }
        }
        else{
            for processor in preProcessors
            {
                processor.calcMinMax()
            }
        }
    }
    
    internal func updateNoteEntries() {
        
        guard let notes = notes, let chartData = data else {
            return
        }
        
        for noteEntry in notes.noteEntries {
            
            guard let noteDataEntry = noteEntry.noteEntryData else {
                continue
            }
            
            let dataset = chartData.dataSets[noteEntry.noteEntryDataSetIndex]
            
            for entryIndex in 0..<dataset.entryCount {
                
                guard let entry = dataset.entryForIndex(entryIndex),let origX = entry.origX, let noteDataEntryOrigX = noteDataEntry.origX else {
                    continue
                }
                      
//                Since the reference of ChartEntryData is updated during entry removal or inclusion, ensure this reference replacement is also applied in note entries. revisit the cases involving reference replacement.
                if origX == noteDataEntryOrigX && entry.y == noteDataEntry.y {
                    noteEntry.noteEntryData = entry
                    break
                }
            }
        }
    }
    
    internal func updateAxisMinAndMax() {
        
        /// Axis Data
        // Computing axis data for both left and right axes
        for renderer in yAxisRenderers where (renderer.axis != nil) && (renderer.axis?.isEnabled)! {
            guard let yAxis = renderer.axis as? YAxis
            else { continue }
            renderer.computeAxis(min: yAxis._axisMinimum, max: yAxis._axisMaximum, inverted: yAxis.inverted)
        }
        
        if _xAxis.isEnabled
        {
            //            _xAxisRenderer?.computeAxis(min: _xAxis._axisMinimum, max: _xAxis._axisMaximum, inverted: false)
            _xAxisRenderer?.computeAxis(min: _xAxis._axisMinimum, max: _xAxis._axisMaximum, inverted: _xAxis.isInverted)
//            updatePlotViewFrame()
        }
        
        AxisChartPreprocessor.prepareAxisCompounds(chart: self)
    }
    
    // MARK: - Datalabel helperFunctions
    
    internal var notAllowedTypes: [ChartType] = [.Dial,.Pie,.Sanky,.PackedBubble,.GeoHeatMap,.HeatMap,.Funnel,.WordCloud]
    
    internal func prepareDataLabelSize() {
        
        guard let chartData = data,
              let viewPortHandler = viewPortHandler else {
            return
        }
        
        labelSizeIndexMap.removeAll()
        
        for dataSetIndex in 0..<chartData.dataSets.count {
            let dataSet = chartData.dataSets[dataSetIndex]
            
            guard dataSet.isVisible, !notAllowedTypes.contains(dataSet.plotType) else {
                continue
            }
            
            if labelSizeIndexMap[dataSetIndex] == nil {
                labelSizeIndexMap[dataSetIndex] = [:]
            }
            else {
                labelSizeIndexMap[dataSetIndex]?.removeAll()
            }
            
            let isIncludeY0 = dataSet.plotType == .BoxPlot || dataSet.plotType == .LineRange
            let isBubbleFamily = dataSet.plotType == .Bubble
            
            for entryIndex in 0..<dataSet.entryCount {
                
                guard let entry = dataSet.entryForIndex(entryIndex), !entry.filterEnabled , let formatter = dataSet.valueFormatter, !entry.x.isNaN , !entry.y.isNaN else {
                    continue
                }
                
                var sizeDict = [String:CGSize]()
                
                let yLabel = formatter.stringForValue(
                    isBubbleFamily ? Double(entry.size ?? 0.0) : entry.y,
                    entry: entry,
                    dataSetIndex: dataSetIndex,
                    viewPortHandler: viewPortHandler)
                
                let yLabelSize = yLabel.size(withAttributes: [NSAttributedString.Key.font: dataSet.valueFont])
                
                sizeDict["y"] = yLabelSize
                
                if isIncludeY0 {
                    
                    let y0Label = formatter.stringForValue(
                        entry.y0,
                        entry: entry,
                        dataSetIndex: dataSetIndex,
                        viewPortHandler: viewPortHandler)
                    
                    let y0LabelSize = y0Label.size(withAttributes: [NSAttributedString.Key.font: dataSet.valueFont])
                    
                    sizeDict["y0"] = y0LabelSize
                }
                
                labelSizeIndexMap[dataSetIndex]?[entryIndex] = sizeDict
            }
        }
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Padding
       
       func updatePadding()
       {
           if self.xAxis.spaceMinPixel != 0 || self.xAxis.spaceMaxPixel != 0
           {
               updateXPadding()
           }
        for yAxis in self.yAxisArray where yAxis.isEnabled && yAxis.spaceMinPixel != 0 || yAxis.spaceMaxPixel != 0 {
               updateYPadding(axis: yAxis)
           }
       }
       
       func updateXPadding()
       {
           
           var xMinMaxAcrossData = CommonHelperFunctions.getXMinMaxValueforVisibleDatasetAcrossData(chart: self)
           
           if let categoryOrder = xAxis.categoryOrder, xAxis.scaleType == .Ordinal {
               xMinMaxAcrossData.min = 0
               xMinMaxAcrossData.max = Double(categoryOrder.count - 1)
           }
           /*
            if xMinMaxAcrossData.min == xMinMaxAcrossData.max || xMinMaxAcrossData.min == Double.greatestFiniteMagnitude || data?.xMin == data?.xMax
           {
               return
           }
           
            var axisProcessor:AxisChartPreprocessor!
            for processor in preProcessors where processor.isKind(of: AxisChartPreprocessor.self)
            {
                axisProcessor = processor as? AxisChartPreprocessor
                break
            }
        
            _ = axisProcessor.getCurrentWidthAfterPadding(padding: 0)
           
           let viewWidth = self.isRotated ? Double(self.viewPortHandler.contentHeight) : Double(self.viewPortHandler.contentWidth)
           let neededWidth:Double = self.xAxis.spaceMaxPixel + self.xAxis.spaceMinPixel
            let xMinMaxValue = CommonHelperFunctions.getXMinAndMaxValue(chart: self)
           let range = xMinMaxValue.max - xMinMaxValue.min
           
           if viewWidth <= 0 || range <= 0
           {
               return
           }
           
           let padRange = (range/viewWidth)*neededWidth
        
           let padValue = axisProcessor.getPaddingValueBinarySearch(min: padRange, max: padRange*2, expectedWidth: CGFloat(neededWidth),axis:self.xAxis)
           
           if padValue != 0
           {
               let (spaceMin,spaceMax) = CommonHelperFunctions.getPaddingValues(spaceMinPixel: xAxis.spaceMinPixel, spaceMaxPixel: xAxis.spaceMaxPixel, overAllPadding: padValue)
               
               self.xAxis.spaceMin = spaceMin
               self.xAxis.spaceMax = spaceMax
           }
           
           
           let xMinMaxAcrossData = getXMinMaxValueforVisibleDatasetAcrossData()*/
            if xMinMaxAcrossData.min == xMinMaxAcrossData.max || xMinMaxAcrossData.min == Double.greatestFiniteMagnitude
            {
            return
            }
           let axisProcessor = preProcessors.first(where: { $0 is AxisChartPreprocessor }) as? AxisChartPreprocessor
           
            _ = axisProcessor?.getCurrentWidthAfterPadding(padding: 0)
            
           let viewWidth = self.isRotated ? Double(self.viewPortHandler.contentHeight) : Double(self.viewPortHandler.contentWidth)
            
            var neededWidth:Double = xAxis.spaceMaxPixel + xAxis.spaceMinPixel
           
            let xMinMaxValue = CommonHelperFunctions.getXMinAndMaxValue(chart: self)
            
            let range = xMinMaxValue.max - xMinMaxValue.min
            
            if viewWidth <= 0 || range <= 0
            {
            return
            }
            
            if (neededWidth) >= viewWidth
            {
            neededWidth = viewWidth/4
            }
            
            let widthToMapRange = viewWidth - (neededWidth)
            
            let oneRangeinPixelAfterMappingToWidth = widthToMapRange/range
            
            let padValue = (1/oneRangeinPixelAfterMappingToWidth)*neededWidth
           
           if padValue != 0
           {
               _ = axisProcessor?.getCurrentWidthAfterPadding(padding: padValue)
           }
       }
       
       func updateYPadding(axis:YAxis)
       {
           guard let data = data
           else { return }
          
            var yMinMaxValueAcrossVisibleData = CommonHelperFunctions.getYMinMaxValue(axis: axis, chart: self)
        
            if BarHelperFunctions.isBarChart(chart: self) && getVisibleDataCount(plotType: .Bar) > 0
            {
                
                if (data.getYMin(axisIndex: axis.axisIndex)) >= Double(0)
                {
                    yMinMaxValueAcrossVisibleData.min = 0
                }
                  
                if (data.getYMax(axisIndex: axis.axisIndex)) <= Double(0)
                {
                    if data.getYMax(axisIndex: axis.axisIndex) == 0 && data.getYMin(axisIndex:  axis.axisIndex) == 0
                    {
                        yMinMaxValueAcrossVisibleData.max = 1
                    }
                    else
                    {
                        yMinMaxValueAcrossVisibleData.max = 0
                    }
                }
            }
           
           if let categoryOrder = getYAxis(atIndex: axis.axisIndex)?.categoryOrder, axis.scaleType == .Ordinal {
               yMinMaxValueAcrossVisibleData.min = 0
               yMinMaxValueAcrossVisibleData.max = Double(categoryOrder.count - 1)
           }
           
           if yMinMaxValueAcrossVisibleData.min == yMinMaxValueAcrossVisibleData.max || yMinMaxValueAcrossVisibleData.min == Double.greatestFiniteMagnitude
           {
               return
           }
        
           let range = yMinMaxValueAcrossVisibleData.max - yMinMaxValueAcrossVisibleData.min
           
           let polarTransform = self.getTransformer(axisIndex: axis.axisIndex) as? PolarTransformer
           
           let padValue = computeYPaddingValue(axis:axis, range: range, neededWidth: axis.spaceMaxPixel + axis.spaceMinPixel)
           
           let (spaceMin,spaceMax) = CommonHelperFunctions.getPaddingValues(spaceMinPixel: axis.spaceMinPixel, spaceMaxPixel: axis.spaceMaxPixel, overAllPadding: padValue)
           
           axis.spaceMin = polarTransform != nil ? axis.spaceMin : spaceMin
           axis.spaceMax = spaceMax
        
           calcMinMax()
        
           self.prepareValuePxMatrix()
       }
    
    func computeYPaddingValue(axis:YAxis, range: Double, neededWidth: Double) -> CGFloat {
        
        var neededWidth:Double = neededWidth
        
        let polarTransform = self.getTransformer(axisIndex: axis.axisIndex) as? PolarTransformer
         
        let viewWidth = (polarTransform != nil) ? Double(polarTransform!.radius) :
         self.isRotated ? Double(self.viewPortHandler.contentWidth) : Double(self.viewPortHandler.contentHeight)
        
        if viewWidth <= 0 || range <= 0
        {
            return 0.0
        }
        
        if neededWidth >= viewWidth
        {
            neededWidth = viewWidth/4
        }
        
        let widthToMapRange = viewWidth - neededWidth
        
        let oneRangeinPixelAfterMappingToWidth = widthToMapRange/range
        
        return (1/oneRangeinPixelAfterMappingToWidth)*neededWidth
    }
    
    
    // MARK: - Draw data
        
    
    open override func draw(_ rect: CGRect)
    {
        let optionalContext = NSUIGraphicsGetCurrentContext()
        guard let context = optionalContext else { return }
       
        if let subLayer = self.nsuiLayer?.sublayers
        {
            for layer in subLayer
            {
                if layer.isKind(of: TickLayer.self) || layer.isKind(of: HighlightLayer.self) || layer.isKind(of: ValueTextLayer.self)
                {
                    layer.removeFromSuperlayer()
                }
            }
        }
        
        (delegateToContainer as? ChartContainer)?.overviewView.reloadLayer()
        
        let frame = self.bounds
        
        
        /// Data Nil Check
        
        let xDataNil = data?.xMin == Double.greatestFiniteMagnitude
        
        let yDataNil = data?.yMin == Double.greatestFiniteMagnitude
        
        if (delegateToContainer != nil &&  delegateToContainer!.chartCheckNoDataAvailable != nil &&  delegateToContainer!.chartCheckNoDataAvailable!(chartView: self)) || (_data === nil && noDataText.count > 0 || (xDataNil && yDataNil))
        {
            plotView?.nsuiLayer?.sublayers?.removeAll()
            
            LimitLineLayer.removeAllLimitLineLayer(chartViewBase: self)
            
            if (_data === nil)
            {
                legend.entries = []
            }

            if let legendCollection = (delegateToContainer as! ChartContainer).legendView.collectionView
            {
                legendCollection.reloadData()
                #if os(iOS)
                    legendCollection.layoutIfNeeded()
                #elseif os(OSX)
                    legendCollection.layoutSubtreeIfNeeded()
                #endif
            }

            (delegateToContainer as! ChartContainer).toolTipView.reloadData(entry: nil)
            
            drawNoDataText(context: context,frame:frame)
            
            return
        }
        
        /// Offset Calculation
        
        if !_offsetsCalculated
        {
//            calculateOffsets()
            _offsetsCalculated = true
        }
        
        updatePlotViewFrame()
        
     
               
//        //PLOT VIEW NOT REQUIRED FOR FUNNEL CHART
//        if plotView != nil {
//            plotView?.removeFromSuperview()
//        }
           
        if _data === nil
        {
            return
        }
        
        // execute all drawing commands
        drawGridBackground(context: context)
        
        if _autoScaleMinMaxEnabled
        {
            for processor in preProcessors
            {
                if let axisProcessor = processor as? AxisChartPreprocessor
                {
                    axisProcessor.autoScale()
                }
            }
        }
        
        /// Axis Grid Lines
        // The renderers are responsible for clipping, to account for line-width center etc.
        if !(xDataNil)
        {
            _xAxisRenderer?.renderGridLines(context: context)
        }
        if !(yDataNil)
        {
            for renderer in yAxisRenderers {
                renderer.renderGridLines(context: context)
            }
        }
        
        /// Axis Line
        if _xAxis.isEnabled
        {
            _xAxisRenderer?.renderAxisLine(context: context)
        }
        
        for renderer in yAxisRenderers {
            renderer.renderAxisLine(context: context)
        }
        
        /// Axis Limit Lines Behind Data
        LimitLineLayer.removeAllLimitLineLayer(chartViewBase: self)
               
        if _xAxis.isEnabled && _xAxis.isDrawLimitLinesBehindDataEnabled && !xDataNil
        {
            plotView?.nsuiLayer?.zPosition = 1
            _xAxisRenderer?.renderLimitLines(context: context)
        }
       
        //Limit Lines behind data
        if !yDataNil {
            for renderer in yAxisRenderers where (renderer.axis != nil) && ((renderer.axis?.isEnabled)! && (renderer.axis?.isDrawLimitLinesBehindDataEnabled)!) {
                plotView?.nsuiLayer?.zPosition = 1
                renderer.renderLimitLines(context: context)
            }
        }
        
        /// Draw Data
        // make sure the data cannot be drawn outside the content-rect
        context.saveGState()
        context.clip(to: _viewPortHandler.contentRect)
        
        for dataRenderer in renderers
        {
            dataRenderer.drawData(context: context)
        }
        
        // if highlighting is enabled
        if (valuesToHighlight())
        {
            // renderer?.drawHighlighted(context: context, indices: _indicesToHighlight)
        }
        
        context.restoreGState()
        
        /// Draw Extras
        for dataRenderer in renderers
        {
            dataRenderer.drawExtras(context: context)
        }
        
        drawPlotBorder(context: context)
        
        /// Axis Labels
        _xAxisRenderer?.renderAxisLabels(context: context)
        
        for renderer in yAxisRenderers {
             renderer.renderAxisLabels(context: context)
        }
        
        /// Axis Limit Lines After Data
        if _xAxis.isEnabled && !_xAxis.isDrawLimitLinesBehindDataEnabled && !xDataNil
        {
            _xAxisRenderer?.renderLimitLines(context: context)
        }
               
        //Limit Lines above data
        if !yDataNil {
            for renderer in yAxisRenderers where (renderer.axis != nil) && ((renderer.axis?.isEnabled)! && !(renderer.axis?.isDrawLimitLinesBehindDataEnabled)!) {
                renderer.renderLimitLines(context: context)
            }
        }
        
        /// BaseLine
        BaseLineLayer.removeAllBaseLineLayer(chartViewBase: self)
       
        if _xAxis.isEnabled && _xAxis.baseLineEnabled && !xDataNil
        {
            //_xAxisRenderer?.renderBaseLine()
        }
               
        if !yDataNil {
            for renderer in yAxisRenderers where (renderer.axis != nil) && ((renderer.axis?.isEnabled)! &&
                (renderer.axis?.baseLineEnabled)!) {
                    renderer.renderBaseLine()
            }
        }
        
        labelRects = [CGRect]()
        
        /// Data Values
        if  clipValuesToContentEnabled
        {
            context.saveGState()
            context.clip(to: _viewPortHandler.contentRect)
            
            for dataRenderer in renderers
            {
                if !self.customAnimationInProgress && !self.interactionAnimationInProgress {
                    dataRenderer.drawValues(context: context)
                }
            }
            
            context.restoreGState()
        }
        else
        {
            for dataRenderer in renderers
            {
                if !self.customAnimationInProgress && !self.interactionAnimationInProgress {
                    dataRenderer.drawValues(context: context)
                }
            }
        }
        
        labelRects = nil
        
        /// Legend Rendering
        _legendRenderer.renderLegend(context: context)
               
        /// Description
        drawDescription(context: context)
            
        /// Markers
        drawMarkers(context: context)
        
        /// Annotation-Notes
        drawNotes()
           
        /// Render Delegate
        rendererDelegate?.drawOthers?(self)
        
        /// Nil Data Text
        if xDataNil && yDataNil
        {
            drawNoDataText(context: context, frame: self.bounds)
        }
    }
    
    internal func drawPlotBorder(context: CGContext)
    {
        guard
            let viewPortHandler = self.viewPortHandler
            else { return }
        
        if  !self.borderEnabled
        {
            return
        }
        
        context.saveGState()
        
        context.setStrokeColor(borderColor.cgColor)
        context.setLineWidth(borderWidth)
        if borderDashLengths != nil
        {
            context.setLineDash(phase: borderDashPhase, lengths: borderDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        context.beginPath()
        context.move(to: CGPoint(x: viewPortHandler.contentLeft , y: viewPortHandler.contentTop))
        context.addLine(to: CGPoint(x: viewPortHandler.contentRight , y: viewPortHandler.contentTop))
        context.addLine(to: CGPoint(x: viewPortHandler.contentRight , y: viewPortHandler.contentBottom))
        context.addLine(to: CGPoint(x: viewPortHandler.contentLeft , y: viewPortHandler.contentBottom))
        context.closePath()
        context.strokePath()
        
       
        context.restoreGState()
    }
    
    /// draws the grid background
    internal func drawGridBackground(context: CGContext)
    {
        guard let axisPlotOption = getPlotOptions() as? AxisChartPlotOptions
            else { return }
        
        if axisPlotOption.drawGridBackgroundEnabled || axisPlotOption.drawBordersEnabled
       {
           context.saveGState()
       }
       
        if axisPlotOption.drawGridBackgroundEnabled
       {
           // draw the grid background
            context.setFillColor(axisPlotOption.gridBackgroundColor.cgColor)
           context.fill(_viewPortHandler.contentRect)
       }
       
        if axisPlotOption.drawBordersEnabled
       {
            context.setLineWidth(axisPlotOption.borderLineWidth)
            context.setStrokeColor(axisPlotOption.borderColor.cgColor)
            context.stroke(_viewPortHandler.contentRect)
       }
       
        if axisPlotOption.drawGridBackgroundEnabled || axisPlotOption.drawBordersEnabled
       {
           context.restoreGState()
       }
    }
    
    func updatePlotViewFrame() {
        //TO DRAW PLOT VIEW
        
        let plotFrame = CGRect(x: 0, y: 0 , width: _viewPortHandler.contentWidth + _viewPortHandler.contentLeft, height: _viewPortHandler.contentHeight + _viewPortHandler.contentTop)
        
        if plotView != nil
        {
            plotView?.nsuiLayer?.sublayers?.removeAll()
            plotView?.frame = plotFrame
            //Check
//            if self.isKind(of: BarLineChartViewBase.self)
//            {
                plotView?.drawMaskLayer()
//            }
        }
        else {
            plotView = PlotView(frame: plotFrame, chart: self)
            self.addSubview(plotView!)
        }
    }
    
    open func drawNoDataText(context:CGContext,frame:CGRect)
    {
        
        delegateToContainer?.chartDataNil?(chartView: self)
        
        if noDataTextEnabled
        {
            ChartUtils.drawMultilineText(
                context: context,
                text: noDataText,
                point: CGPoint(x: frame.width / 2.0, y: frame.height / 2.0),
                attributes:
                [NSAttributedString.Key.font: noDataFont,
                 NSAttributedString.Key.foregroundColor: noDataTextColor],
                constrainedToSize: self.bounds.size,
                anchor: CGPoint(x: 0.5, y: 0.5),
                angleRadians: 0.0)
        }
    }
    
    /// Draws the description text in the bottom right corner of the chart (per default)
    internal func drawDescription(context: CGContext)
    {
        // check if description should be drawn
        guard
            let description = chartDescription,
            description.isEnabled,
            let descriptionText = description.text,
            descriptionText.count > 0
            else { return }
        
        var position = description.position
        
        // if no position specified, draw on default position
        if position == nil
        {
            let frame = self.bounds
            position = CGPoint(
                x: frame.width - _viewPortHandler.offsetRight - description.xOffset,
                y: frame.height - _viewPortHandler.offsetBottom - description.yOffset - description.font.lineHeight)
        }
        
        var attrs = [NSAttributedString.Key : AnyObject]()
        
        attrs[NSAttributedString.Key.font] = description.font
        attrs[NSAttributedString.Key.foregroundColor] = description.textColor
        
        ChartUtils.drawText(
            context: context,
            text: descriptionText,
            point: position!,
            align: description.textAlign,
            attributes: attrs)
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Highlighting
    
    
    /// To track last selected highlight object
    open var lastSelectedHigh:Highlight? = nil
    
    /// Checks if the highlight array is null, has a length of zero or if the first object is null.
    /// - returns: `true` if there are values to highlight, `false` ifthere are no values to highlight.
    open func valuesToHighlight() -> Bool
    {
        return _indicesToHighlight.count > 0
    }
    
    /// Checks if the given index is set to be highlighted.
    open func needsHighlight(index: Int) -> Bool
    {
        // no highlight
        if !valuesToHighlight()
        {
            return false
        }
        
        for i in 0 ..< _indicesToHighlight.count
        {
            // check if the xvalue for the given dataset needs highlight
            if  ChartUtils.doubleToIntSafeCast(value:_indicesToHighlight[i].x) == index
            {
                return true
            }
        }
        
        return false
    }
    
    /// Highlights the values at the given indices in the given DataSets. Provide
    /// null or an empty array to undo all highlighting.
    /// This should be used to programmatically highlight values.
    /// This method *will not* call the delegate.
    open func highlightValues(_ highs: [Highlight]?)
    {
        // set the indices to highlight
        _indicesToHighlight = highs ?? [Highlight]()
        
        if _indicesToHighlight.isEmpty
        {
            self.lastHighlighted = nil
        }
        else
        {
            self.lastHighlighted = _indicesToHighlight[0]
        }
        
        // redraw the chart
        setNeedsDisplay()
    }
    
    /// Highlights any y-value at the given x-value in the given DataSet.
    /// Provide -1 as the dataSetIndex to undo all highlighting.
    /// This method will call the delegate.
    /// - parameter x: The x-value to highlight
    /// - parameter dataSetIndex: The dataset index to search in
    open func highlightValue(x: Double, dataSetIndex: Int)
    {
        highlightValue(x: x, dataSetIndex: dataSetIndex, callDelegate: true)
    }
    
    /// Highlights the value at the given x-value in the given DataSet. Provide -1 as the dataSetIndex to undo all highlighting.
    /// - parameter x:
    /// - parameter dataSetIndex:
    /// - parameter stackIndex: the index inside the stack - only relevant for stacked entries
    open func highlightValue(x: Double, dataSetIndex: Int, stackIndex: Int)
    {
        highlightValue(Highlight(x: x, dataSetIndex: dataSetIndex, stackIndex: stackIndex))
    }
    
    /// Highlights the value at the given x-value and y-value in the given DataSet.
    /// Provide -1 as the dataSetIndex to undo all highlighting.
    /// This method will call the delegate.
    /// - parameter x: The x-value to highlight
    /// - parameter y: The y-value to highlight. Supply `NaN` for "any"
    /// - parameter dataSetIndex: The dataset index to search in
    open func highlightValue(x: Double, y: Double, dataSetIndex: Int)
    {
        highlightValue(x: x, y: y, dataSetIndex: dataSetIndex, callDelegate: true)
    }
    
    /// Highlights any y-value at the given x-value in the given DataSet.
    /// Provide -1 as the dataSetIndex to undo all highlighting.
    /// - parameter x: The x-value to highlight
    /// - parameter dataSetIndex: The dataset index to search in
    /// - parameter callDelegate: Should the delegate be called for this change
    open func highlightValue(x: Double, dataSetIndex: Int, callDelegate: Bool)
    {
        highlightValue(x: x, y: Double.nan, dataSetIndex: dataSetIndex, callDelegate: callDelegate)
    }
    
    /// Highlights the value at the given x-value and y-value in the given DataSet.
    /// Provide -1 as the dataSetIndex to undo all highlighting.
    /// - parameter x: The x-value to highlight
    /// - parameter y: The y-value to highlight. Supply `NaN` for "any"
    /// - parameter dataSetIndex: The dataset index to search in
    /// - parameter callDelegate: Should the delegate be called for this change
    open func highlightValue(x: Double, y: Double, dataSetIndex: Int, callDelegate: Bool)
    {
        guard let data = _data else
        {
            Swift.print("Value not highlighted because data is nil")
            return
        }
        
        if dataSetIndex < 0 || dataSetIndex >= data.dataSetCount
        {
            highlightValue(nil, callDelegate: callDelegate)
        }
        else
        {
            highlightValue(Highlight(x: x, y: y, dataSetIndex: dataSetIndex), callDelegate: callDelegate)
        }
    }
    
    /// Highlights the values represented by the provided Highlight object
    /// This method *will not* call the delegate.
    /// - parameter highlight: contains information about which entry should be highlighted
    open func highlightValue(_ highlight: Highlight?)
    {
        highlightValue(highlight, callDelegate: false)
    }
    
    /// Highlights the value selected by touch gesture.
    open func highlightValue(_ highlight: Highlight?, callDelegate: Bool)
    {
       /* var entry: ChartDataEntry?
        var h = highlight
        
        if h == nil
        {
            _indicesToHighlight.removeAll(keepingCapacity: false)
        }
        else
        {
            // set the indices to highlight
            entry = _data?.entryForHighlight(h!)
            if entry == nil
            {
                h = nil
                _indicesToHighlight.removeAll(keepingCapacity: false)
            }
            else
            {
                _indicesToHighlight = [h!]
            }
        }
        
        if callDelegate && delegate != nil
        {
            if h == nil
            {
                delegate!.chartValueNothingSelected?(self)
            }
            else
            {
                // notify the listener
                delegate!.chartValueSelected?(self, entry: entry!, highlight: h!)
            }
        }
        
        //Notify Container for OtherChanges
        callDelegateToContainer(highlight: highlight, entry: entry)
        
        // redraw the chart
        setNeedsDisplay() */
        
        highlightValue(highlight,callDelegate: callDelegate, redrawRequired: true)
    }
    
    /// Highlights the value selected by touch gesture.
    open func highlightValue(_ highlight: Highlight?, callDelegate: Bool, redrawRequired:Bool)
    {
        var entry: ChartDataEntry?
        var h = highlight
        
        if h == nil
        {
            _indicesToHighlight.removeAll(keepingCapacity: false)
        }
        else
        {
            // set the indices to highlight
            entry = self.entryForHighlight(h!)
            if entry == nil
            {
                h = nil
                _indicesToHighlight.removeAll(keepingCapacity: false)
            }
            else
            {
                _indicesToHighlight = [h!]
            }
        }
        
        if callDelegate && delegateToContainer != nil
        {
            if h == nil
            {
                delegateToContainer!.chartValueNothingSelected?(self)
            }
            else
            {
                guard let e = entry
                else { return }
                // notify the listener
                delegateToContainer!.chartValueSelected?(self, entry: e, highlight: h!)
            }
        }
        
        //Notify Container for OtherChanges
        callDelegateToContainer(highlight: highlight, entry: entry)
        
        if redrawRequired {
            // redraw the chart
            setNeedsDisplay()
        }
    }
    
    /// - returns: The Highlight object (contains x-index and DataSet index) of the
    /// selected value at the given touch point inside the Line-, Scatter-, or
    /// CandleStick-Chart.
    open func getHighlightByTouchPoint(_ pt: CGPoint) -> Highlight?
    {
        if _data === nil
        {
            Swift.print("Can't select by touch. No data set.")
            return nil
        }
        
        return self.highlighter?.getHighlight(x: pt.x, y: pt.y)
    }
    
    open func getHighlightByEntry(_ e: ChartDataEntry) -> Highlight?
    {
        if _data === nil
        {
            Swift.print("Can't select by touch. No data set.")
            return nil
        }
        
        return self.highlighter?.getHighlight(entry: e)
    }
    
    open func entryForHighlight(_ highlight: Highlight) -> ChartDataEntry? {
        
        return self.highlighter?.entryForHighlight(highlight)
        
    }
    
    open func getHighlightByEntry(_ e: ChartDataEntry, customHighlighter:IHighlighter) -> Highlight?
       {
           if _data === nil
           {
               Swift.print("Can't select by touch. No data set.")
               return nil
           }
           
           return customHighlighter.getHighlight(entry: e)
       }
       
       open func entryForHighlight(_ highlight: Highlight, customHighlighter:IHighlighter) -> ChartDataEntry? {
           
           return customHighlighter.entryForHighlight(highlight)
           
       }
    
     func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer?, location:CGPoint ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
     {
           var entry:ChartDataEntry? = nil
           
           let high = self.getHighlightByTouchPoint(location)
           
           let entryLayer:ChartEntryLayer? = nil
           
           if high != nil
           {
               entry = self.entryForHighlight(high!)
           }
           
           return (entry,entryLayer)
       }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Markers
    
    /// draws all MarkerViews on the highlighted positions
    internal func drawMarkers(context: CGContext)
    {
        // if there is no marker view or drawing marker is disabled
        guard
            let marker = marker
            , isDrawMarkersEnabled &&
                valuesToHighlight()
            else { return }
        
        for i in 0 ..< _indicesToHighlight.count
        {
            let highlight = _indicesToHighlight[i]
            
            guard let
                set = data?.getDataSetByIndex(highlight.dataSetIndex),
                let e = self.entryForHighlight(highlight)
                else { continue }
            
            let entryIndex = set.entryIndex(entry: e)
            if entryIndex >  ChartUtils.doubleToIntSafeCast(value:Double(set.entryCount) * _animator.phaseX)
            {
                continue
            }
            
            let pos = getMarkerPosition(highlight: highlight)
            
            // check bounds
            if !_viewPortHandler.isInBounds(x: pos.x, y: pos.y)
            {
                continue
            }
            
            // callbacks to update the content
            marker.refreshContent(entry: e, highlight: highlight)
            
            // draw the marker
            marker.draw(context: context, point: pos)
        }
    }
    
    // MARK: - Notes
    
    /// draws all MarkerViews on the highlighted positions
    internal func drawNotes()
    {
        // if there is no marker view or drawing marker is disabled
        guard
            let notes = notes,
            !(customAnimationInProgress),
            notes.drawNotesEnabled,
            let chartData = data,
            let animator = _animator, animator.phaseX == 1.0 && animator.phaseY == 1.0
            else { return }
        
        let noteEntries = notes.noteEntries
        
        if notes.cusotmNoteEnabled
        {
            for entry in noteEntries
            {
                if entry.notesFilterEnabled || chartData.dataSets.count > entry.noteEntryDataSetIndex && !(chartData.dataSets[safe:entry.noteEntryDataSetIndex]?.isVisible ?? false) {
                    continue
                }
                
                let noteLayer = CommonHelperFunctions.createNoteLayer(noteEntry: entry)
                
                notes.notesShape.customPathDataSource?.updateShapeProperties?(frame: CGRect.zero, shapeInstance: notes.notesShape, entry: entry)
                
                notes.customNoteDelegate?.updateNoteLayer?(noteLayer: noteLayer, noteShape: notes.notesShape)
                
                if interactionAnimationInProgress {
                    noteLayer.opacity = Float(entry.opacityChanged)
                }
                
                self.plotView?.nsuiLayer?.addSublayer(noteLayer)
            }
            return
        }
         
        for entry in noteEntries
        {
            let tempPoint = entry.point
            var tempPixelPoint:CGPoint? = nil
            if let noteEntryData = entry.noteEntryData
            {
                guard CommonHelperFunctions.entryDatasetIsVisible(data: chartData, entry: noteEntryData)
                else { continue }
                
                let xVal = noteEntryData.x
                let yVal = noteEntryData.y
                
                /*
                // Both Ordinal
                if chartData.xOrdinal && chartData.yOrdinal[entry.axisIndex] != nil && chartData.yOrdinal[entry.axisIndex]!
                {
                    guard let entryXstring = entry.noteEntryData?.xString,
                        let xIndex = chartData.xString?.firstIndex(of: entryXstring) as? Int
                    else { continue }
                    
                    xVal = Double(xIndex)
                     
                    guard let entryYstring = entry.noteEntryData?.yString,
                          let yIndex = chartData.yString?[entry.axisIndex]?.firstIndex(of: entryYstring) as? Int
                    else { continue }
                    
                    yVal = Double(yIndex)
                }
                // X - Ordinal && y - Linear
                else if chartData.xOrdinal {
                 
                    guard let entryXstring = entry.noteEntryData?.xString,
                          let xIndex = chartData.xString?.firstIndex(of: entryXstring) as? Int,
                          entry.noteEntryDataSetIndex < chartData.dataSetCount
                    else { continue }
                    
                    xVal = Double(xIndex)
                    
                    // No entry found
                    if chartData.dataSets[entry.noteEntryDataSetIndex].entriesForXYValue(xVal, entry.noteEntryData!.y).count <= 0
                    {
                        continue
                    }
                    
                }
                // X - Linear && y - Ordinal
                else if chartData.yOrdinal[entry.axisIndex] != nil && chartData.yOrdinal[entry.axisIndex]! {
                    
                    guard let entryYstring = entry.noteEntryData?.yString,
                          let yIndex = chartData.yString?[entry.axisIndex]?.firstIndex(of: entryYstring) as? Int,
                          entry.noteEntryDataSetIndex < chartData.dataSetCount
                    else { continue }
                    
                    yVal = Double(yIndex)
                    
                    // No entry found
                    if chartData.dataSets[entry.noteEntryDataSetIndex].entriesForXYValue(entry.noteEntryData!.x, yVal).count <= 0
                    {
                        continue
                    }
                    
                }
                // X - Linear && y - Linear
                else {
                    if entry.noteEntryDataSetIndex >= chartData.dataSetCount || chartData.dataSets[entry.noteEntryDataSetIndex].entriesForXYValue(entry.noteEntryData!.x, entry.noteEntryData!.y).count <= 0
                    {
                        continue
                    }
                }
                */
                
                if isRotated {
                    tempPixelPoint  = pixelForValues(x: yVal, y: xVal, axisIndex: entry.axisIndex)
                }
                else {
                    tempPixelPoint  = pixelForValues(x: xVal, y: yVal, axisIndex: entry.axisIndex)
                }
                
                if BarHelperFunctions.isStacked(chart: self) {
                    
                    if let entryForLayer = BarLayer.getBarLayerForEntry(chart: self, entry: noteEntryData), let barRect =  entryForLayer.barRect {
                        
                        if isRotated {
                            tempPixelPoint?.x = barRect.origin.x
                        }
                        else {
                            tempPixelPoint?.y = barRect.origin.y
                        }
                    }
                }
                
                if !entry.notesFilterEnabled && !noteEntryData.filterEnabled && noteEntryData.centerChanged != nil && interactionAnimationInProgress {
                    
                    tempPixelPoint = entry.noteEntryData!.centerChanged!
                    
                    if let dataset = chartData.getDataSetForEntry(noteEntryData) {

                        if BarHelperFunctions.typeAllowed.contains(dataset.plotType) {

                            if isRotated {
                                tempPixelPoint?.y += (noteEntryData.sizeChanged?.height ?? 0.0) / 2.0
                            }
                            else {
                                tempPixelPoint?.x += (noteEntryData.sizeChanged?.width ?? 0.0) / 2.0
                            }
                        }
                    }
                }
            }
            else if tempPoint != nil{
                var xVal:Double? = (tempPoint?.x as? Double) != nil ? (tempPoint?.x as? Double) :
                (tempPoint?.x as? Int) != nil ? Double((tempPoint?.x as! Int)) : nil
                
                if let xString = (tempPoint?.x as? String)
                {
                    guard let index = data?.xString?.firstIndex(of: xString) as? Int
                    else { continue }
                    xVal = Double(index)
                }
                
                var yVal:Double? = (tempPoint?.y as? Double) != nil ? (tempPoint?.y as? Double) :
                (tempPoint?.y as? Int) != nil ? Double((tempPoint?.y as! Int)) : nil
                
                if let yString = (tempPoint?.y as? String)
                {
                    guard let index = data?.yString?[entry.axisIndex]?.firstIndex(of: yString) as? Int
                    else { continue }
                    yVal = Double(index)
                }
                
                if xVal != nil && yVal != nil
                {
                    if isRotated {
                        tempPixelPoint  = pixelForValues(x: yVal!, y: xVal!, axisIndex: entry.axisIndex)
                    }
                    else {
                        tempPixelPoint  = pixelForValues(x: xVal!, y: yVal!, axisIndex: entry.axisIndex)
                    }
                }
            }
            guard let pixelValue = tempPixelPoint
            else { continue }
            
            let noteLayer = CommonHelperFunctions.createNoteLayer(noteEntry: entry)
            
            let noteSubLayer = CAShapeLayer()
            
            let noteSize = notes.notesShape.size
            
            noteSubLayer.bounds = CGRect(x:pixelValue.x - noteSize.width/2, y: pixelValue.y - noteSize.height/2, width: noteSize.width, height: noteSize.height)
            
            _ = CommonHelperFunctions.drawShapeLayerGeneric(shapeProperties: notes.notesShape, entry: entry, currentLayer: noteSubLayer)
            
            noteSubLayer.frame =  CGRect(x:pixelValue.x - noteSize.width/2, y: pixelValue.y - noteSize.height/2, width: noteSize.width, height: noteSize.height)
           
            noteLayer.addSublayer(noteSubLayer)
            
            if entry.text != ""
            {
                let labelAttrs = [NSAttributedString.Key.font: entry.textFont,
                                  NSAttributedString.Key.foregroundColor: entry.textColor]
                
                let textLayer = ChartUtils.drawTextLayer(text: entry.text, point: pixelValue, align: .center, attributes: labelAttrs)
                
                noteLayer.addSublayer(textLayer)
            }
            
            if interactionAnimationInProgress {
                noteLayer.opacity = Float(entry.opacityChanged)
            }

            self.plotView?.nsuiLayer?.addSublayer(noteLayer)
           
        }
        
        
        
        
    }
    
    /// - returns: The actual position in pixels of the MarkerView for the given Entry in the given DataSet.
    open func getMarkerPosition(highlight: Highlight) -> CGPoint
    {
        for processor in preProcessors
        {
            return processor.getMarkerPosition(highlight: highlight)
        }
        return CGPoint()
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Animation
    
    /// Animates the drawing / rendering of the chart on both x- and y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter yAxisDuration: duration for animating the y axis
    /// - parameter easingX: an easing function for the animation on the x axis
    /// - parameter easingY: an easing function for the animation on the y axis
    open func animate(xAxisDuration: TimeInterval, yAxisDuration: TimeInterval, easingX: ChartEasingFunctionBlock?, easingY: ChartEasingFunctionBlock?)
    {
        _animator.animate(xAxisDuration: xAxisDuration, yAxisDuration: yAxisDuration, easingX: easingX, easingY: easingY)
    }
    
    /// Animates the drawing / rendering of the chart on both x- and y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter yAxisDuration: duration for animating the y axis
    /// - parameter easingOptionX: the easing function for the animation on the x axis
    /// - parameter easingOptionY: the easing function for the animation on the y axis
    open func animate(xAxisDuration: TimeInterval, yAxisDuration: TimeInterval, easingOptionX: ChartEasingOption, easingOptionY: ChartEasingOption)
    {
        _animator.animate(xAxisDuration: xAxisDuration, yAxisDuration: yAxisDuration, easingOptionX: easingOptionX, easingOptionY: easingOptionY)
    }
    
    /// Animates the drawing / rendering of the chart on both x- and y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter yAxisDuration: duration for animating the y axis
    /// - parameter easing: an easing function for the animation
    open func animate(xAxisDuration: TimeInterval, yAxisDuration: TimeInterval, easing: ChartEasingFunctionBlock?)
    {
        _animator.animate(xAxisDuration: xAxisDuration, yAxisDuration: yAxisDuration, easing: easing)
    }
    
    /// Animates the drawing / rendering of the chart on both x- and y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter yAxisDuration: duration for animating the y axis
    /// - parameter easingOption: the easing function for the animation
    open func animate(xAxisDuration: TimeInterval, yAxisDuration: TimeInterval, easingOption: ChartEasingOption)
    {
        _animator.animate(xAxisDuration: xAxisDuration, yAxisDuration: yAxisDuration, easingOption: easingOption)
    }
    
    /// Animates the drawing / rendering of the chart on both x- and y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter yAxisDuration: duration for animating the y axis
    open func animate(xAxisDuration: TimeInterval, yAxisDuration: TimeInterval)
    {
        _animator.animate(xAxisDuration: xAxisDuration, yAxisDuration: yAxisDuration)
    }
    
    /// Animates the drawing / rendering of the chart the x-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter easing: an easing function for the animation
    open func animate(xAxisDuration: TimeInterval, easing: ChartEasingFunctionBlock?)
    {
        _animator.animate(xAxisDuration: xAxisDuration, easing: easing)
    }
    
    /// Animates the drawing / rendering of the chart the x-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    /// - parameter easingOption: the easing function for the animation
    open func animate(xAxisDuration: TimeInterval, easingOption: ChartEasingOption)
    {
        _animator.animate(xAxisDuration: xAxisDuration, easingOption: easingOption)
    }
    
    /// Animates the drawing / rendering of the chart the x-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter xAxisDuration: duration for animating the x axis
    open func animate(xAxisDuration: TimeInterval)
    {
        _animator.animate(xAxisDuration: xAxisDuration)
    }
    
    /// Animates the drawing / rendering of the chart the y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter yAxisDuration: duration for animating the y axis
    /// - parameter easing: an easing function for the animation
    open func animate(yAxisDuration: TimeInterval, easing: ChartEasingFunctionBlock?)
    {
        _animator.animate(yAxisDuration: yAxisDuration, easing: easing)
    }
    
    /// Animates the drawing / rendering of the chart the y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter yAxisDuration: duration for animating the y axis
    /// - parameter easingOption: the easing function for the animation
    open func animate(yAxisDuration: TimeInterval, easingOption: ChartEasingOption)
    {
        _animator.animate(yAxisDuration: yAxisDuration, easingOption: easingOption)
    }
    
    /// Animates the drawing / rendering of the chart the y-axis with the specified animation time.
    /// If `animate(...)` is called, no further calling of `invalidate()` is necessary to refresh the chart.
    /// - parameter yAxisDuration: duration for animating the y axis
    open func animate(yAxisDuration: TimeInterval)
    {
        _animator.animate(yAxisDuration: yAxisDuration)
    }
    
    open func stopDeceleration()
    {
        if _decelerationDisplayLink !== nil
        {
            _decelerationDisplayLink.remove(from: RunLoop.main, forMode: RunLoop.Mode.common)
            _decelerationDisplayLink = nil
            
        }
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Imaging
    
    /// - returns: The bitmap that represents the chart.
    open func getChartImage(transparent: Bool) -> NSUIImage?
    {
        NSUIGraphicsBeginImageContextWithOptions(bounds.size, isOpaque || !transparent, NSUIMainScreen()?.nsuiScale ?? 1.0)
        
        guard let context = NSUIGraphicsGetCurrentContext()
            else { return nil }
        
        let rect = CGRect(origin: CGPoint(x: 0, y: 0), size: bounds.size)
        
        if isOpaque || !transparent
        {
            // Background color may be partially transparent, we must fill with white if we want to output an opaque image
            context.setFillColor(NSUIColor.white.cgColor)
            context.fill(rect)
            
            if let backgroundColor = self.backgroundColor
            {
                context.setFillColor(backgroundColor.cgColor)
                context.fill(rect)
            }
        }
        
        nsuiLayer?.render(in: context)
        
        let image = NSUIGraphicsGetImageFromCurrentImageContext()
        
        NSUIGraphicsEndImageContext()
        
        return image
    }
    
    public enum ImageFormat
    {
        case jpeg
        case png
    }
    
    /// Saves the current chart state with the given name to the given path on
    /// the sdcard leaving the path empty "" will put the saved file directly on
    /// the SD card chart is saved as a PNG image, example:
    /// saveToPath("myfilename", "foldername1/foldername2")
    ///
    /// - parameter to: path to the image to save
    /// - parameter format: the format to save
    /// - parameter compressionQuality: compression quality for lossless formats (JPEG)
    ///
    /// - returns: `true` if the image was saved successfully
    open func save(to path: String, format: ImageFormat, compressionQuality: Double) -> Bool
    {
        guard let image = getChartImage(transparent: format != .jpeg)
            else { return false }
        
        var imageData: Data!
        switch (format)
        {
        case .png:
            imageData = NSUIImagePNGRepresentation(image)
            break
            
        case .jpeg:
            imageData = NSUIImageJPEGRepresentation(image, CGFloat(compressionQuality))
            break
        }
        
        do
        {
            try imageData.write(to: URL(fileURLWithPath: path), options: .atomic)
        }
        catch
        {
            return false
        }
        
        return true
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Viewport modifiers
      
      open var visibleXRange: Double
      {
          return abs(highestVisibleX - lowestVisibleX)
      }
      
      /// Zooms in by 1.4, into the charts center.
      open func zoomIn()
      {
          let center = _viewPortHandler.contentCenter
          
          let matrix = _viewPortHandler.zoomIn(x: center.x, y: -center.y)
          let _ = _viewPortHandler.refresh(newMatrix: matrix, chart: self, invalidate: false)
          
          // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
          calculateOffsets()
          setNeedsDisplay()
      }
      
      /// Zooms out by 0.7, from the charts center.
      open func zoomOut()
      {
          let center = _viewPortHandler.contentCenter
          
          let matrix = _viewPortHandler.zoomOut(x: center.x, y: -center.y)
          let _ = _viewPortHandler.refresh(newMatrix: matrix, chart: self, invalidate: false)
          
          // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
          calculateOffsets()
          setNeedsDisplay()
      }
      
      /// Zooms out to original size.
      open func resetZoom()
      {
          let matrix = _viewPortHandler.resetZoom()
          let _ = _viewPortHandler.refresh(newMatrix: matrix, chart: self, invalidate: false)
          
          // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
          calculateOffsets()
          setNeedsDisplay()
      }
    
      /// Zooms out to original size.
      open func resetPlotZoom()
      {
          let matrix = CGAffineTransform.identity
          let _ = _viewPortHandler.refreshPlot(newMatrix: matrix, chart: self, invalidate: false)
          
          // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
          calculateOffsets()
          setNeedsDisplay()
      }
      
      /// Zooms in or out by the given scale factor. x and y are the coordinates
      /// (in pixels) of the zoom center.
      ///
      /// - parameter scaleX: if < 1 --> zoom out, if > 1 --> zoom in
      /// - parameter scaleY: if < 1 --> zoom out, if > 1 --> zoom in
      /// - parameter x:
      /// - parameter y:
      open func zoom(
          scaleX: CGFloat,
          scaleY: CGFloat,
          x: CGFloat,
          y: CGFloat)
      {
          let matrix = _viewPortHandler.zoom(scaleX: scaleX, scaleY: scaleY, x: x, y: -y)
          let _ = _viewPortHandler.refresh(newMatrix: matrix, chart: self, invalidate: false)
          
          // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
          calculateOffsets()
          setNeedsDisplay()
      }
      
      /// Zooms in or out by the given scale factor.
      /// x and y are the values (**not pixels**) of the zoom center.
      ///
      /// - parameter scaleX: if < 1 --> zoom out, if > 1 --> zoom in
      /// - parameter scaleY: if < 1 --> zoom out, if > 1 --> zoom in
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis:
      open func zoom(
          scaleX: CGFloat,
          scaleY: CGFloat,
          xValue: Double,
          yValue: Double,
          axisIndex:Int)
      {
          let job = ZoomViewJob(
              viewPortHandler: viewPortHandler,
              scaleX: scaleX,
              scaleY: scaleY,
              xValue: xValue,
              yValue: yValue,
              transformer: getTransformer(axisIndex: axisIndex),
              axisIndex: axisIndex,
              view: self)
          addViewportJob(job)
      }
      
      /// Zooms to the center of the chart with the given scale factor.
      ///
      /// - parameter scaleX: if < 1 --> zoom out, if > 1 --> zoom in
      /// - parameter scaleY: if < 1 --> zoom out, if > 1 --> zoom in
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis:
      open func zoomToCenter(
          scaleX: CGFloat,
          scaleY: CGFloat)
      {
          let center = centerOffsets
          let matrix = viewPortHandler.zoom(
              scaleX: scaleX,
              scaleY: scaleY,
              x: center.x,
              y: -center.y)
          let _ = viewPortHandler.refresh(newMatrix: matrix, chart: self, invalidate: false)
      }
      
      /// Zooms by the specified scale factor to the specified values on the specified axis.
      ///
      /// - parameter scaleX:
      /// - parameter scaleY:
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func zoomAndCenterViewAnimated(
          scaleX: CGFloat,
          scaleY: CGFloat,
          xValue: Double,
          yValue: Double,
          axisIndex: Int,
          duration: TimeInterval,
          easing: ChartEasingFunctionBlock?)
      {
          let origin = valueForTouchPoint(
              point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop),
               axisIndex: axisIndex)
          
          let job = AnimatedZoomViewJob(
              viewPortHandler: viewPortHandler,
              transformer: getTransformer(axisIndex: axisIndex),
              view: self,
              yAxis: getYAxis(atIndex: axisIndex)!,
              xAxisRange: _xAxis.axisRange,
              scaleX: scaleX,
              scaleY: scaleY,
              xOrigin: viewPortHandler.scaleX,
              yOrigin: viewPortHandler.scaleY,
              zoomCenterX: CGFloat(xValue),
              zoomCenterY: CGFloat(yValue),
              zoomOriginX: origin.x,
              zoomOriginY: origin.y,
              duration: duration,
              easing: easing)
          
          addViewportJob(job)
      }
      
      /// Zooms by the specified scale factor to the specified values on the specified axis.
      ///
      /// - parameter scaleX:
      /// - parameter scaleY:
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func zoomAndCenterViewAnimated(
          scaleX: CGFloat,
          scaleY: CGFloat,
          xValue: Double,
          yValue: Double,
          axisIndex: Int,
          duration: TimeInterval,
          easingOption: ChartEasingOption)
      {
          zoomAndCenterViewAnimated(scaleX: scaleX, scaleY: scaleY, xValue: xValue, yValue: yValue, axisIndex: axisIndex, duration: duration, easing: easingFunctionFromOption(easingOption))
      }
      
      /// Zooms by the specified scale factor to the specified values on the specified axis.
      ///
      /// - parameter scaleX:
      /// - parameter scaleY:
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter axisIndex: which axis index should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func zoomAndCenterViewAnimated(
          scaleX: CGFloat,
          scaleY: CGFloat,
          xValue: Double,
          yValue: Double,
          axisIndex: Int,
          duration: TimeInterval)
      {
          zoomAndCenterViewAnimated(scaleX: scaleX, scaleY: scaleY, xValue: xValue, yValue: yValue,axisIndex:axisIndex, duration: duration, easingOption: .easeInOutSine)
      }
      
      /// Resets all zooming and dragging and makes the chart fit exactly it's bounds.
      open func fitScreen()
      {
          let matrix = _viewPortHandler.fitScreen()
          let _ = _viewPortHandler.refresh(newMatrix: matrix, chart: self, invalidate: false)
          
          calculateOffsets()
          setNeedsDisplay()
      }
      
      /// Sets the minimum scale value to which can be zoomed out. 1 = fitScreen
      open func setScaleMinima(_ scaleX: CGFloat, scaleY: CGFloat)
      {
          _viewPortHandler.setMinimumScaleX(scaleX)
          _viewPortHandler.setMinimumScaleY(scaleY)
      }
      
      /// Sets the size of the area (range on the x-axis) that should be maximum visible at once (no further zooming out allowed).
      ///
      /// If this is e.g. set to 10, no more than a range of 10 values on the x-axis can be viewed at once without scrolling.
      ///
      /// If you call this method, chart must have data or it has no effect.
      open func setVisibleXRangeMaximum(_ maxXRange: Double)
      {
          let xScale = _xAxis.axisRange / maxXRange
          
          if _rotated
          {
            _viewPortHandler.setMinimumScaleY(CGFloat(xScale))
          }
          else{
            _viewPortHandler.setMinimumScaleX(CGFloat(xScale))
          }
          
      }

      
      /// Sets the size of the area (range on the x-axis) that should be minimum visible at once (no further zooming in allowed).
      ///
      /// If this is e.g. set to 10, no less than a range of 10 values on the x-axis can be viewed at once without scrolling.
      ///
      /// If you call this method, chart must have data or it has no effect.
      open func setVisibleXRangeMinimum(_ minXRange: Double)
      {
          let xScale = _xAxis.axisRange / minXRange
        
            if _rotated
            {
                _viewPortHandler.setMaximumScaleY(CGFloat(xScale))
            }
            else{
                _viewPortHandler.setMaximumScaleX(CGFloat(xScale))
            }
          
      }
      
      /// Limits the maximum and minimum value count that can be visible by pinching and zooming.
      ///
      /// e.g. minRange=10, maxRange=100 no less than 10 values and no more that 100 values can be viewed
      /// at once without scrolling.
      ///
      /// If you call this method, chart must have data or it has no effect.
      open func setVisibleXRange(minXRange: Double, maxXRange: Double)
      {
          let minScale = _xAxis.axisRange / maxXRange
          let maxScale = _xAxis.axisRange / minXRange
        
          if _rotated
          {
                   _viewPortHandler.setMinMaxScaleY(minScaleY: CGFloat(minScale), maxScaleY: CGFloat(maxScale))
          }
          else{
                   _viewPortHandler.setMinMaxScaleX(
                   minScaleX: CGFloat(minScale),
                   maxScaleX: CGFloat(maxScale))
            }
          
      }
    
      /// Sets the size of the area (range on the y-axis) that should be maximum visible at once.
      ///
      /// - parameter yRange:
      /// - parameter axis: - the axis for which this limit should apply
      open func setVisibleYRangeMaximum(_ maxYRange: Double, axisIndex: Int)
      {
          let yScale = getAxisRange(axisIndex: axisIndex) / maxYRange
            if _rotated
            {
                _viewPortHandler.setMinimumScaleX(CGFloat(yScale))
            }
            else{
                _viewPortHandler.setMinimumScaleY(CGFloat(yScale))
            }
          
      }
      
      /// Sets the size of the area (range on the y-axis) that should be minimum visible at once, no further zooming in possible.
      ///
      /// - parameter yRange:
      /// - parameter axis: - the axis for which this limit should apply
      open func setVisibleYRangeMinimum(_ minYRange: Double, axisIndex: Int)
      {
          let yScale = getAxisRange(axisIndex: axisIndex) / minYRange
        
            if _rotated
            {
                _viewPortHandler.setMaximumScaleX(CGFloat(yScale))
            }
            else{
                _viewPortHandler.setMaximumScaleY(CGFloat(yScale))
            }
          
      }
   
      /// Limits the maximum and minimum y range that can be visible by pinching and zooming.
      ///
      /// - parameter minYRange:
      /// - parameter maxYRange:
      /// - parameter axis:
      open func setVisibleYRange(minYRange: Double, maxYRange: Double, axisIndex: Int)
      {
          let minScale = getAxisRange(axisIndex: axisIndex) / minYRange
          let maxScale = getAxisRange(axisIndex: axisIndex) / maxYRange
            if _rotated
            {
                _viewPortHandler.setMinMaxScaleX(minScaleX: CGFloat(minScale), maxScaleX: CGFloat(maxScale))
            }
            else{
                _viewPortHandler.setMinMaxScaleY(minScaleY: CGFloat(minScale), maxScaleY: CGFloat(maxScale))
            }
          
      }
    
    open func showViewRange(from: Double,to: Double) {
        
        let range = ChartUtils.roundNumber(number: abs(from - to))
        
        let scaleX = xAxis.axisRange / range
        
        viewPortHandler._touchMatrix = .identity
        
        updatePadding()
        
        if isRotated {
            setScaleMinima(1.0, scaleY: scaleX)
        }
        else {
            setScaleMinima(scaleX, scaleY: 1.0)
        }
        
        if xAxis.isInverted {
            moveViewToX(to)
        }
        else {
            moveViewToX(from)
        }
        
    }
      
      /// Moves the left side of the current viewport to the specified x-value.
      /// This also refreshes the chart by calling setNeedsDisplay().
      open func moveViewToX(_ xValue: Double)
      {
            let job:ViewPortJob!
            
            if _rotated
            {
                job = MoveViewJob(
                viewPortHandler: viewPortHandler,
                xValue: 0,
                yValue: xValue,
                transformer: getTransformer(axisIndex: 0),
                view: self)
            }
            else {
                job = MoveViewJob(
                viewPortHandler: viewPortHandler,
                xValue: xValue,
                yValue: 0.0,
                transformer: getTransformer(axisIndex: 0),
                view: self)
            }
          
          addViewportJob(job)
      }
      
      open func moveViewToXWithoutRedraw(xValue: Double)
      {
          var pt = CGPoint(
              x: CGFloat(xValue),
              y: CGFloat(0)
          )
        
        if _rotated
        {
            pt = CGPoint(
                x: CGFloat(0),
                y: CGFloat(xValue)
            )
        }
          
          getTransformer(axisIndex: 0).pointValueToPixel(&pt)
          
          let translateX = pt.x - viewPortHandler.offsetLeft
          let translateY = pt.y - viewPortHandler.offsetTop
          
          let matrix = viewPortHandler.touchMatrix.concatenating(CGAffineTransform(translationX: -translateX, y: -translateY))
          
          viewPortHandler._touchMatrix = matrix
          
          viewPortHandler.limitTransAndScale(matrix: &(viewPortHandler._touchMatrix), content: viewPortHandler.contentRect)
          
      }
      
      /// Centers the viewport to the specified y-value on the y-axis.
      /// This also refreshes the chart by calling setNeedsDisplay().
      ///
      /// - parameter yValue:
      /// - parameter axis: - which axis should be used as a reference for the y-axis
      open func moveViewToY(_ yValue: Double, axisIndex:Int)
      {
          
          let job = MoveViewJob(
              viewPortHandler: viewPortHandler,
              xValue: 0.0,
              yValue: yValue,
              transformer: getTransformer(axisIndex: axisIndex),
              view: self)
          
          addViewportJob(job)
      }
      
      /// This will move the left side of the current viewport to the specified x-value on the x-axis, and center the viewport to the specified y-value on the y-axis.
      /// This also refreshes the chart by calling setNeedsDisplay().
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: - which axis should be used as a reference for the y-axis
      open func moveViewTo(xValue: Double, yValue: Double, axisIndex:Int)
      {
          let job = MoveViewJob(
              viewPortHandler: viewPortHandler,
              xValue: xValue,
              yValue: yValue,
              transformer: getTransformer(axisIndex: axisIndex),
              view: self)
          
          addViewportJob(job)
      }
      
      /// This will move the left side of the current viewport to the specified x-position and center the viewport to the specified y-position animated.
      /// This also refreshes the chart by calling setNeedsDisplay().
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func moveViewToAnimated(
          xValue: Double,
          yValue: Double,
          axisIndex:Int,
          duration: TimeInterval,
          easing: ChartEasingFunctionBlock?)
      {
          let bounds = valueForTouchPoint(
              point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop),
               axisIndex: axisIndex)
        
          if _rotated
          {
                var yInView = getAxisRange(axisIndex: axisIndex) / Double(_viewPortHandler.scaleX)
                
                if (self.xAxis.inverted) {
                    yInView = -yInView
                }
                
                let job = AnimatedMoveViewJob(
                    viewPortHandler: viewPortHandler,
                    xValue: yValue - yInView / 2.0,
                    yValue: xValue,
                    transformer: getTransformer(axisIndex: axisIndex),
                    view: self,
                    xOrigin: bounds.x,
                    yOrigin: bounds.y,
                    duration: duration,
                    easing: easing)
                
                addViewportJob(job)
          }
          else {
            
              let yInView = getAxisRange(axisIndex: axisIndex) / Double(_viewPortHandler.scaleY)
              
              let job = AnimatedMoveViewJob(
                  viewPortHandler: viewPortHandler,
                  xValue: xValue,
                  yValue: yValue + yInView / 2.0,
                  transformer: getTransformer(axisIndex: axisIndex),
                  view: self,
                  xOrigin: bounds.x,
                  yOrigin: bounds.y,
                  duration: duration,
                  easing: easing)
              
              addViewportJob(job)
           }
      }
      
      /// This will move the left side of the current viewport to the specified x-position and center the viewport to the specified y-position animated.
      /// This also refreshes the chart by calling setNeedsDisplay().
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func moveViewToAnimated(
          xValue: Double,
          yValue: Double,
          axisIndex:Int,
          duration: TimeInterval,
          easingOption: ChartEasingOption)
      {
          moveViewToAnimated(xValue: xValue, yValue: yValue, axisIndex:axisIndex, duration: duration, easing: easingFunctionFromOption(easingOption))
      }
      
      /// This will move the left side of the current viewport to the specified x-position and center the viewport to the specified y-position animated.
      /// This also refreshes the chart by calling setNeedsDisplay().
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func moveViewToAnimated(
          xValue: Double,
          yValue: Double,
          axisIndex:Int,
          duration: TimeInterval)
      {
          moveViewToAnimated(xValue: xValue, yValue: yValue, axisIndex: axisIndex, duration: duration, easingOption: .easeInOutSine)
      }
      
      /// This will move the center of the current viewport to the specified x-value and y-value.
      /// This also refreshes the chart by calling setNeedsDisplay().
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: - which axis should be used as a reference for the y-axis
      open func centerViewTo(
          xValue: Double,
          yValue: Double,
          axisIndex:Int)
      {
          let yInView = getAxisRange(axisIndex: axisIndex) / Double(_viewPortHandler.scaleY)
          let xInView = xAxis.axisRange / Double(_viewPortHandler.scaleX)
          
          let job = MoveViewJob(
              viewPortHandler: viewPortHandler,
              xValue: xValue - xInView / 2.0,
              yValue: yValue + yInView / 2.0,
              transformer: getTransformer(axisIndex: axisIndex),
              view: self)
          
          addViewportJob(job)
      }
      
      /// This will move the center of the current viewport to the specified x-value and y-value animated.
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func centerViewToAnimated(
          xValue: Double,
          yValue: Double,
          axisIndex:Int,
          duration: TimeInterval,
          easing: ChartEasingFunctionBlock?)
      {
          let bounds = valueForTouchPoint(
              point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop),
               axisIndex: axisIndex)
        
          if _rotated
          {
                var yInView = getAxisRange(axisIndex: axisIndex) / Double(_viewPortHandler.scaleX)
                var xInView = xAxis.axisRange / Double(_viewPortHandler.scaleY)
                
                if (self.xAxis.inverted) {
                    xInView = -xInView
                    yInView = -yInView
                }
                let job = AnimatedMoveViewJob(
                    viewPortHandler: viewPortHandler,
                    xValue: yValue - yInView / 2.0,
                    yValue: xValue - xInView / 2.0,
                    transformer: getTransformer(axisIndex: axisIndex),
                    view: self,
                    xOrigin: bounds.x,
                    yOrigin: bounds.y,
                    duration: duration,
                    easing: easing)
                
                addViewportJob(job)
          }
          else{
              let yInView = getAxisRange(axisIndex: axisIndex) / Double(_viewPortHandler.scaleY)
              var xInView = xAxis.axisRange / Double(_viewPortHandler.scaleX)
              if (self.xAxis.inverted) {
                  xInView = -xInView
              }
              let job = AnimatedMoveViewJob(
                  viewPortHandler: viewPortHandler,
                  xValue: xValue - xInView / 2.0,
                  yValue: yValue + yInView / 2.0,
                  transformer: getTransformer(axisIndex: axisIndex),
                  view: self,
                  xOrigin: bounds.x,
                  yOrigin: bounds.y,
                  duration: duration,
                  easing: easing)
              
              addViewportJob(job)
          }
      }
      
      /// This will move the center of the current viewport to the specified x-value and y-value animated.
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func centerViewToAnimated(
          xValue: Double,
          yValue: Double,
          axisIndex:Int,
          duration: TimeInterval,
          easingOption: ChartEasingOption)
      {
          centerViewToAnimated(xValue: xValue, yValue: yValue, axisIndex: axisIndex, duration: duration, easing: easingFunctionFromOption(easingOption))
      }
      
      /// This will move the center of the current viewport to the specified x-value and y-value animated.
      ///
      /// - parameter xValue:
      /// - parameter yValue:
      /// - parameter axis: which axis should be used as a reference for the y-axis
      /// - parameter duration: the duration of the animation in seconds
      /// - parameter easing:
      open func centerViewToAnimated(
          xValue: Double,
          yValue: Double,
          axisIndex:Int,
          duration: TimeInterval)
      {
          centerViewToAnimated(xValue: xValue, yValue: yValue, axisIndex: axisIndex, duration: duration, easingOption: .easeInOutSine)
      }
      
      /// Sets custom offsets for the current `ChartViewPort` (the offsets on the sides of the actual chart window). Setting this will prevent the chart from automatically calculating it's offsets. Use `resetViewPortOffsets()` to undo this.
      /// ONLY USE THIS WHEN YOU KNOW WHAT YOU ARE DOING, else use `setExtraOffsets(...)`.
      open func setViewPortOffsets(left: CGFloat, top: CGFloat, right: CGFloat, bottom: CGFloat)
      {
          _customViewPortEnabled = true
          
          if Thread.isMainThread
          {
              self._viewPortHandler.restrainViewPort(offsetLeft: left, offsetTop: top, offsetRight: right, offsetBottom: bottom)
              prepareOffsetMatrix()
              prepareValuePxMatrix()
          }
          else
          {
              DispatchQueue.main.async(execute: {
                  self.setViewPortOffsets(left: left, top: top, right: right, bottom: bottom)
              })
          }
      }
      
      /// Resets all custom offsets set via `setViewPortOffsets(...)` method. Allows the chart to again calculate all offsets automatically.
      open func resetViewPortOffsets()
      {
          _customViewPortEnabled = false
          calculateOffsets()
      }
    
    // MARK: - Viewport Jobs
    
    open func removeViewportJob(_ job: ViewPortJob)
    {
        if let index = _viewportJobs.firstIndex(where: { $0 === job })
        {
            _viewportJobs.remove(at: index)
        }
    }
    
    open func clearAllViewportJobs()
    {
        _viewportJobs.removeAll(keepingCapacity: false)
    }
    
    open func addViewportJob(_ job: ViewPortJob)
    {
        if _viewPortHandler.hasChartDimens
        {
            job.doJob()
        }
        else
        {
            _viewportJobs.append(job)
        }
    }
    
    /////====================== ****************************** ====================== /////
    
    // MARK: - Accessors
      
      /// - returns: The current x-scale factor
      open var scaleX: CGFloat
      {
          if _viewPortHandler === nil
          {
              return 1.0
          }
          return _viewPortHandler.scaleX
      }
      
      /// - returns: The current y-scale factor
      open var scaleY: CGFloat
      {
          if _viewPortHandler === nil
          {
              return 1.0
          }
          return _viewPortHandler.scaleY
      }
      
      /// if the chart is fully zoomed out, return true
      open var isFullyZoomedOut: Bool { return _viewPortHandler.isFullyZoomedOut }
      
      /// flag that indicates if pinch-zoom is enabled. if true, both x and y axis can be scaled simultaneously with 2 fingers, if false, x and y axis can be scaled separately
      open var pinchZoomEnabled: Bool
          {
          get
          {
              return _pinchZoomEnabled
          }
          set
          {
              if _pinchZoomEnabled != newValue
              {
                  _pinchZoomEnabled = newValue
                  #if !os(tvOS)
                  _pinchEventListener?.isEnabled = _pinchZoomEnabled || _scaleXEnabled || _scaleYEnabled
                  #endif
              }
          }
      }
    
    /// flag that indicates if pinch-zoom is enabled. if true, both x and y axis can be scaled simultaneously with 2 fingers, if false, x and y axis can be scaled separately
    open var doubleTapEnabled: Bool
    {
        get
        {
            return _doubleTapEnabled
        }
        set
        {
            if _doubleTapEnabled != newValue
            {
                _doubleTapEnabled = newValue
                
                if _doubleTapEnabled
                {
            #if os(iOS)
                    _tapEventListener?.require(toFail: _doubleTapEventListener!)
            #elseif os(OSX)
                    _tapEventListener?.shouldBeRequiredToFail(by: _doubleTapEventListener!)
            #endif
                }
                
                _doubleTapEventListener?.isEnabled = _doubleTapEnabled
                
            }
        }
    }
      
      /// **default**: false
      /// - returns: `true` if pinch-zoom is enabled, `false` ifnot
      open var isPinchZoomEnabled: Bool { return pinchZoomEnabled }
      
      /// - returns: `true` if both drag offsets (x and y) are zero or smaller.
      open var hasNoDragOffset: Bool { return _viewPortHandler.hasNoDragOffset }
      
      /*/// The left Y axis renderer. This is a read-write property so you can set your own custom renderer here.
       /// **default**: An instance of YAxisRenderer
       /// - returns: The current set left Y axis renderer
       open var leftYAxisRenderer: YAxisRenderer
       {
       get { return _leftYAxisRenderer }
       set { _leftYAxisRenderer = newValue }
       }
       
       /// The right Y axis renderer. This is a read-write property so you can set your own custom renderer here.
       /// **default**: An instance of YAxisRenderer
       /// - returns: The current set right Y axis renderer
       open var rightYAxisRenderer: YAxisRenderer
       {
       get { return _rightYAxisRenderer }
       set { _rightYAxisRenderer = newValue }
       }*/
      
      /// - returns: `true` if either the left or the right or both axes are inverted.
      open var isAnyAxisInverted: Bool
      {
          for yAxis in yAxisArray where yAxis.isInverted {
              return true
          }
          return false
      }
      
      /// flag that indicates if auto scaling on the y axis is enabled.
      /// if yes, the y axis automatically adjusts to the min and max y values of the current x axis range whenever the viewport changes
      open var autoScaleMinMaxEnabled: Bool
          {
          get { return _autoScaleMinMaxEnabled }
          set { _autoScaleMinMaxEnabled = newValue }
      }
      
      /// is dragging enabled? (moving the chart with the finger) for the chart (this does not affect scaling).
      open var dragEnabled: Bool
          {
          get
          {
              return _dragEnabled
          }
          set
          {
              if _dragEnabled != newValue
              {
                  _dragEnabled = newValue
              }
          }
      }
      
      /// is dragging enabled? (moving the chart with the finger) for the chart (this does not affect scaling).
      open var isDragEnabled: Bool
      {
          return dragEnabled
      }
      
      open var scaleXEnabled: Bool
          {
          get
          {
              return _scaleXEnabled
          }
          set
          {
              if _scaleXEnabled != newValue
              {
                  _scaleXEnabled = newValue
                  #if !os(tvOS)
                  _pinchEventListener?.isEnabled = _pinchZoomEnabled || _scaleXEnabled || _scaleYEnabled
                  #endif
              }
          }
      }
      
      open var scaleYEnabled: Bool
          {
          get
          {
              return _scaleYEnabled
          }
          set
          {
              if _scaleYEnabled != newValue
              {
                  _scaleYEnabled = newValue
                  #if !os(tvOS)
                  _pinchEventListener?.isEnabled = _pinchZoomEnabled || _scaleXEnabled || _scaleYEnabled
                  #endif
              }
          }
      }
      
      open var isScaleXEnabled: Bool { return scaleXEnabled }
      open var isScaleYEnabled: Bool { return scaleYEnabled }
      
      /// flag that indicates if double tap zoom is enabled or not
      open var doubleTapToZoomEnabled: Bool
          {
          get
          {
              return _doubleTapToZoomEnabled
          }
          set
          {
              if _doubleTapToZoomEnabled != newValue
              {
                  _doubleTapToZoomEnabled = newValue
                  _doubleTapEventListener?.isEnabled = _doubleTapToZoomEnabled
              }
          }
      }
      
      /// **default**: true
      /// - returns: `true` if zooming via double-tap is enabled `false` ifnot.
      open var isDoubleTapToZoomEnabled: Bool
      {
          return doubleTapToZoomEnabled
      }
      
      /// flag that indicates if highlighting per dragging over a fully zoomed out chart is enabled
      open var highlightPerDragEnabled = true
      
      /// If set to true, highlighting per dragging over a fully zoomed out chart is enabled
      /// You might want to disable this when using inside a `NSUIScrollView`
      ///
      /// **default**: true
      open var isHighlightPerDragEnabled: Bool
      {
          return highlightPerDragEnabled
      }
      
      
      
      /// **default**: false
      /// - returns: `true` if auto scaling on the y axis is enabled.
      open var isAutoScaleMinMaxEnabled : Bool { return autoScaleMinMaxEnabled }
      
      /// - returns: The range of the specified axis.
      open func getAxisRange(axisIndex:Int) -> Double
      {
          return (getYAxis(atIndex: axisIndex)?.axisRange) ?? 0
      }
      
      /// - returns: The position (in pixels) the provided Entry has inside the chart view
      open func getPosition(entry e: ChartDataEntry, axisIndex:Int) -> CGPoint
      {
          var vals = CGPoint(x: CGFloat(e.x), y: CGFloat(e.y))
        
          if _rotated
          {
              vals = CGPoint(x: CGFloat(e.y), y: CGFloat(e.x))
          }
          
          getTransformer(axisIndex: axisIndex).pointValueToPixel(&vals)
          
          return vals
      }
      
      /// is scaling enabled? (zooming in and out by gesture) for the chart (this does not affect dragging).
      open func setScaleEnabled(_ enabled: Bool)
      {
          if _scaleXEnabled != enabled || _scaleYEnabled != enabled
          {
              _scaleXEnabled = enabled
              _scaleYEnabled = enabled
              #if !os(tvOS)
              _pinchEventListener?.isEnabled = _pinchZoomEnabled || _scaleXEnabled || _scaleYEnabled
              #endif
          }
      }
      
      /// - returns: The x and y values in the chart at the given touch point
      /// (encapsulated in a `CGPoint`). This method transforms pixel coordinates to
      /// coordinates / values in the chart. This is the opposite method to
      /// `getPixelsForValues(...)`.
      open func valueForTouchPoint(point pt: CGPoint, axisIndex: Int) -> CGPoint
      {
          return getTransformer(axisIndex: axisIndex).valueForTouchPoint(pt)
      }
    
      open func valueForTouchPoint(point pt: CGPoint, axisIndex: Int,isRotated:Bool) -> CGPoint
      {
          let newPoint = getTransformer(axisIndex: axisIndex).valueForTouchPoint(pt)
          return isRotated ? CGPoint(x: newPoint.y, y: newPoint.x) : newPoint
      }
      
      /// Transforms the given chart values into pixels. This is the opposite
      /// method to `valueForTouchPoint(...)`.
      open func pixelForValues(x: Double, y: Double, isOriginal: Bool = true , axisIndex:Int) -> CGPoint
      {
          return getTransformer(axisIndex: axisIndex).pixelForValues(x: x, y: y, isOriginal: isOriginal)
      }
    
        open func pixelForValues(isRotated: Bool,x: Double,y: Double, isOriginal: Bool = true, axisIndex: Int) -> CGPoint {
            return isRotated ? pixelForValues(x: y, y: x, isOriginal: isOriginal, axisIndex: axisIndex) : pixelForValues(x: x, y: y, isOriginal: isOriginal, axisIndex: axisIndex)
        }
    
    func pixelForValues(point: CGPoint, isOriginal: Bool = true, axisIndex: Int) -> CGPoint {
        return pixelForValues(isRotated: isRotated, x: point.x, y: point.y, isOriginal: isOriginal, axisIndex: axisIndex)
    }
      
      /// - returns: The Entry object displayed at the touched position of the chart
      open func getEntryByTouchPoint(point pt: CGPoint) -> ChartDataEntry!
      {
          if let h = getHighlightByTouchPoint(pt)
          {
              return self.entryForHighlight(h)
          }
          return nil
      }
      
      /// - returns: The DataSet object displayed at the touched position of the chart
      open func getDataSetByTouchPoint(point pt: CGPoint) -> IChartDataSet!
      {
          let h = getHighlightByTouchPoint(pt)
          if h !== nil
          {
              return _data?.getDataSetByIndex(h!.dataSetIndex)
          }
          return nil
      }
      
      /// Set an offset in dp that allows the user to drag the chart over it's
      /// bounds on the x-axis.
      open func setDragOffsetX(_ offset: CGFloat)
      {
          _viewPortHandler.setDragOffsetX(offset)
      }
      
      /// Set an offset in dp that allows the user to drag the chart over it's
      /// bounds on the y-axis.
      open func setDragOffsetY(_ offset: CGFloat)
      {
          _viewPortHandler.setDragOffsetY(offset)
      }
      
      /// Sets a minimum width to the specified y axis.
      open func setYAxisMinWidth(axisIndex:Int, width: CGFloat)
      {
          getYAxis(atIndex: axisIndex)?.minWidth = width
      }
      
      /// **default**: 0.0
      /// - returns: The (custom) minimum width of the specified Y axis.
      open func getYAxisMinWidth(axisIndex:Int) -> CGFloat
      {
          return (getYAxis(atIndex: axisIndex)?.minWidth) ?? 0
      }
      /// Sets a maximum width to the specified y axis.
      /// Zero (0.0) means there's no maximum width
      open func setYAxisMaxWidth(axisIndex:Int, width: CGFloat)
      {
          getYAxis(atIndex: axisIndex)?.maxLabelWidth = width
      }
      
      /// Zero (0.0) means there's no maximum width
      ///
      /// **default**: 0.0 (no maximum specified)
      /// - returns: The (custom) maximum width of the specified Y axis.
      open func getYAxisMaxWidth( axisIndex:Int) -> CGFloat
      {
          return (getYAxis(atIndex: axisIndex)?.maxLabelWidth) ?? 0
      }
      
      /// - returns the width of the specified y axis.
      open func getYAxisWidth(axisIndex:Int) -> CGFloat
      {
          return (getYAxis(atIndex: axisIndex)?.requiredSize().width) ?? 0
      }
    
    // MARK: - BarLineScatterCandleBubbleChartDataProvider Properties
    
    /// the number of maximum visible drawn values on the chart only active when `drawValuesEnabled` is enabled
    open var maxVisibleCount: Int
    {
        get
        {
            if plotTypes.contains(.Pie) || plotTypes.contains(.Dial) || plotTypes.contains(.Funnel)
            {
                _maxVisibleCount = data?.entryCount ?? 0
            }
            return _maxVisibleCount
        }
        set
        {
            _maxVisibleCount = newValue
        }
    }
    
    /// - returns: The lowest x-index (value on the x-axis) that is still visible on he chart.
    open var lowestVisibleX: Double
    {
        if _rotated
        {
            var pt = CGPoint(
                x: viewPortHandler.contentLeft,
                y: viewPortHandler.contentTop)
            
            if self.xAxis.inverted
            {
                pt = CGPoint(
                    x: viewPortHandler.contentLeft,
                    y: viewPortHandler.contentBottom)
            }
            
            getTransformer(axisIndex: 0).pixelToValues(&pt)
            
            return max(xAxis.axisMinimum, Double(pt.y))
        }
        else{
            var pt = CGPoint(
                x: viewPortHandler.contentLeft,
                y: viewPortHandler.contentBottom)
            
            if self.xAxis.inverted
            {
                pt = CGPoint(
                    x: viewPortHandler.contentRight,
                    y: viewPortHandler.contentBottom)
            }
            
            getTransformer(axisIndex: 0).pixelToValues(&pt)
            
            return max(xAxis.axisMinimum, Double(pt.x))
        }
        
    }
    
    /// - returns: The highest x-index (value on the x-axis) that is still visible on the chart.
    open var highestVisibleX: Double
    {
        if _rotated
        {
            var pt = CGPoint(
                x: viewPortHandler.contentLeft,
                y: viewPortHandler.contentBottom)
            
            if self.xAxis.inverted
            {
                pt = CGPoint(
                    x: viewPortHandler.contentLeft,
                    y: viewPortHandler.contentTop)
            }
            getTransformer(axisIndex: 0).pixelToValues(&pt)
            
            return min(xAxis.axisMaximum, Double(pt.y))
        }
        else{
            var pt = CGPoint(
                x: viewPortHandler.contentRight,
                y: viewPortHandler.contentBottom)
            
            if self.xAxis.inverted
            {
                pt = CGPoint(
                    x: viewPortHandler.contentLeft,
                    y: viewPortHandler.contentBottom)
            }
            
            getTransformer(axisIndex: 0).pixelToValues(&pt)
            
            return min(xAxis.axisMaximum, Double(pt.x))
        }
    }
    
    
    fileprivate var _autoScaleLastLowestVisibleX: Double?
    fileprivate var _autoScaleLastHighestVisibleX: Double?
    
    
    
      
      /////====================== ****************************** ====================== /////
    
    
    // MARK: - Touches
    
    open func superTouchBegan(_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    {
        super.nsuiTouchesBegan(touches, withEvent: event)
    }
    
    open override func nsuiTouchesBegan(_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    {
        if !_interceptTouchEvents
        {
            if !self.touchEventsEnabled
            {
                return
            }
            
            let touch = touches.first
            
            guard let touchLocation = touch?.location(in: self)
                else { return }
            
            var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
            
            if isCombined
            {
                (entry,layer) = self.getEntryAndLayer(nil,location: touchLocation)
            }
            else{
                // Only one processor will be available
                for processor in preProcessors
                {
                  (entry,layer) = processor.getEntryAndLayer(nil, location: touchLocation)
                }
            }
           
            self.touchHandler.touchEventBegan(self, entry: entry, sliceLayer: layer, touches, withEvent: event)
            
        }
    }
    
    open func superTouchMoved(_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    {
        super.nsuiTouchesMoved(touches, withEvent: event)
    }
    
    open override func nsuiTouchesMoved(_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    {
        if !_interceptTouchEvents
        {
            if !self.touchEventsEnabled
             {
                 return
             }
             
             let touch = touches.first
             
             guard let touchLocation = touch?.location(in: self)
                 else { return }
             
             var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
             
             if isCombined
             {
                 (entry,layer) = self.getEntryAndLayer(nil,location: touchLocation)
             }
             else{
                 // Only one processor will be available
                 for processor in preProcessors
                 {
                   (entry,layer) = processor.getEntryAndLayer(nil, location: touchLocation)
                 }
             }
            
             self.touchHandler.touchEventMoved(self, entry: entry, sliceLayer: layer, touches, withEvent: event)
        }
    }
    
    open func superTouchEnd(_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    {
        super.nsuiTouchesEnded(touches, withEvent: event)
    }
    
    open override func nsuiTouchesEnded(_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    {
        if !_interceptTouchEvents
        {
            if !self.touchEventsEnabled
             {
                 return
             }
             
             let touch = touches.first
             
             guard let touchLocation = touch?.location(in: self)
                 else { return }
             
             var (entry,layer):(entry:ChartDataEntry?,layer:ChartEntryLayer?)
             
             if isCombined
             {
                 (entry,layer) = self.getEntryAndLayer(nil,location: touchLocation)
             }
             else{
                 // Only one processor will be available
                 for processor in preProcessors
                 {
                   (entry,layer) = processor.getEntryAndLayer(nil, location: touchLocation)
                 }
             }
            
             self.touchHandler.touchEventEnded(self, entry: entry, sliceLayer: layer, touches, withEvent: event)
        }
    }
    
    open override func nsuiTouchesCancelled(_ touches: Set<NSUITouch>?, withEvent event: NSUIEvent?)
    {
        if !_interceptTouchEvents
        {
            if !self.touchEventsEnabled
            {
                return
            }
            
            super.nsuiTouchesCancelled(touches, withEvent: event)
            
            guard let touchesValue = touches
            else { return }
            
            self.touchHandler.touchEventCancelled?(self, entry: nil, sliceLayer: nil, touchesValue, withEvent: event)
        }
    }
    
    #if os(OSX)
    open override func mouseDown(with theEvent: NSEvent)
    {
    super.mouseDown(with: theEvent)
  /*  // if rotation by touch is enabled
    if rotationEnabled
    {
    stopDeceleration()
    
    let location = self.convert(theEvent.locationInWindow, from: nil)
    
    processRotationGestureBegan(location: location)
    }
    
    if !_isRotating
    {
    super.mouseDown(with: theEvent)
    }*/
    }
    
    open override func mouseDragged(with theEvent: NSEvent)
    {
    super.mouseDragged(with: theEvent)
   /* if rotationEnabled
    {
    let location = self.convert(theEvent.locationInWindow, from: nil)
    
    processRotationGestureMoved(location: location)
    }
    
    if !_isRotating
    {
    super.mouseDragged(with: theEvent)
    }*/
    }
    
    open override func mouseUp(with theEvent: NSEvent)
    {
    super.mouseUp(with: theEvent)
   /* if !_isRotating
    {
    super.mouseUp(with: theEvent)
    }
    
    if rotationEnabled
    {
    let location = self.convert(theEvent.locationInWindow, from: nil)
    
    processRotationGestureEnded(location: location)
    }
    
    if _isRotating
    {
    _isRotating = false
    }*/
    }
    #endif
    
    open func enableDrawValues() {
        guard let valuesEnabled = data?.valuesEnabled
        else { return }
        if valuesEnabled
        {
            self.data?.setDrawValues(true)
        }
    }
    
    // MARK: - Gestures
      
      enum GestureScaleAxis
      {
          case both
          case x
          case y
      }
      
      open var _isDragging = false
      open var _isScaling = false
      var _gestureScaleAxis = GestureScaleAxis.both
      open var _closestDataSetToTouch: IChartDataSet!
      var _panGestureReachedEdge: Bool = false
      weak open var _outerScrollView: NSUIScrollView?
      
      open var _lastPanPoint = CGPoint() /// This is to prevent using setTranslation which resets velocity
      
      open var _decelerationLastTime: TimeInterval = 0.0
      open var _decelerationDisplayLink: NSUIDisplayLink!
      open var _decelerationVelocity = CGPoint()
      internal var _decelerationAngularVelocity: CGFloat = 0.0
      
      
      fileprivate func nsuiGestureRecognizerShouldBegin(_ gestureRecognizer: NSUIGestureRecognizer) -> Bool
      {
          if gestureRecognizer == _panEventListener
          {
              if _data === nil || !_dragEnabled ||
                  (self.hasNoDragOffset && self.isFullyZoomedOut && !self.isHighlightPerDragEnabled)
              {
                  return false
              }
          }
          else
          {
              #if !os(tvOS)
              if gestureRecognizer == _pinchEventListener
              {
                  if _data === nil || (!_pinchZoomEnabled && !_scaleXEnabled && !_scaleYEnabled)
                  {
                      return false
                  }
              }
              #endif
          }
          
          return true
      }
      
      #if !os(OSX)
      open override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool
      {
          if !super.gestureRecognizerShouldBegin(gestureRecognizer)
          {
              return false
          }
          
          return nsuiGestureRecognizerShouldBegin(gestureRecognizer)
      }
      #endif
      
      #if os(OSX)
      public func gestureRecognizerShouldBegin(gestureRecognizer: NSGestureRecognizer) -> Bool
      {
          return nsuiGestureRecognizerShouldBegin(gestureRecognizer)
      }
      #endif
      
    open func gestureRecognizer(_ gestureRecognizer: NSUIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: NSUIGestureRecognizer) -> Bool
      {
          #if !os(tvOS)
          //        if ((gestureRecognizer.isKind(of: NSUIPinchGestureRecognizer.self) &&
          //            otherGestureRecognizer.isKind(of: NSUIPanGestureRecognizer.self)) ||
          //            (gestureRecognizer.isKind(of: NSUIPanGestureRecognizer.self) &&
          //                otherGestureRecognizer.isKind(of: NSUIPinchGestureRecognizer.self)))
          //        {
          //            return true
          //        }
          #endif
          
          if ((gestureRecognizer == self.panEventListener &&
              otherGestureRecognizer == self.tapEventListener) || (gestureRecognizer == self.tapEventListener &&
                                                                   otherGestureRecognizer == self.panEventListener) ||
              (gestureRecognizer == self.pinchEventListener &&
                  otherGestureRecognizer == self.tapEventListener) || (gestureRecognizer == self.tapEventListener &&
                                                                       otherGestureRecognizer == self.pinchEventListener))
          {
              return true
          }
          
          if (gestureRecognizer.isKind(of: NSUIPanGestureRecognizer.self) &&
              otherGestureRecognizer.isKind(of: NSUIPanGestureRecognizer.self) && (
                  gestureRecognizer == _panEventListener
              ))
          {
              var scrollView = self.superview
              while (scrollView !== nil && !scrollView!.isKind(of: NSUIScrollView.self))
              {
                  scrollView = scrollView?.superview
              }
              
              // If there is two scrollview together, we pick the superview of the inner scrollview.
              // In the case of UITableViewWrepperView, the superview will be UITableView
              if let superViewOfScrollView = scrollView?.superview
                  , superViewOfScrollView.isKind(of: NSUIScrollView.self)
              {
                  scrollView = superViewOfScrollView
              }
              
              var foundScrollView = scrollView as? NSUIScrollView
              
              if foundScrollView !== nil && !foundScrollView!.nsuiIsScrollEnabled
              {
                  foundScrollView = nil
              }
              
              var scrollViewPanGestureRecognizer: NSUIGestureRecognizer!
              
              if foundScrollView !== nil
              {
                  for scrollRecognizer in foundScrollView!.nsuiGestureRecognizers!
                  {
                      if scrollRecognizer.isKind(of: NSUIPanGestureRecognizer.self)
                      {
                          scrollViewPanGestureRecognizer = scrollRecognizer as! NSUIPanGestureRecognizer
                          break
                      }
                  }
              }
              
              if otherGestureRecognizer === scrollViewPanGestureRecognizer
              {
                  _outerScrollView = foundScrollView
                  
                  return true
              }
          }
          
          return false
      }
      
      /////====================== ****************************** ====================== /////
    
    // MARK: - Delegates
    
    /// Delegates to Container
    open func callDelegateToContainer(highlight: Highlight?, entry: ChartDataEntry?)
    {
        
        if  delegateToContainer != nil
        {
            if highlight == nil || entry  == nil
            {
                delegateToContainer!.chartValueNothingSelected?(self)
            }
            else if highlight != nil && entry != nil
            {
                // notify the listener
                delegateToContainer!.chartValueSelected?(self, entry: entry!, highlight: highlight!)
            }
        }
        
    }
    
    open func callDelegateForLegendReload()
    {
        if  delegateToContainer != nil
        {
            delegateToContainer?.legendReloaded?(self, _legend.entries)
        }
        
    }
    
    // MARK: - AnimatorDelegate
    
    open func animatorUpdated(_ chartAnimator: Animator)
    {
         for processor in preProcessors
         {
                processor.animatorUpdated(chartAnimator)
         }
    }
    
    open func animatorStopped(_ chartAnimator: Animator)
    {
        for processor in preProcessors
        {
               processor.animatorStopped(chartAnimator)
        }
    }
    
    /////====================== ****************************** ====================== /////
    
    
    // MARK: - Protocol Implementations
      
    public func filterEntrySelected(entry: [ChartDataEntry]?) {
        if isCombined
        {
            if entry != nil
            {
                self.interactionAnimationInProgress = true
                ChartInteractionHelperFunction.chartEntriesEnabled(axisChartBase: self, entries: entry, duration: 1)
            }
        }
        else{
            // Only one processor
            for processor in preProcessors
            {
                processor.filterEntrySelected(entry: entry)
            }
        }
        
    }
    
      /// Tooltip tapped
      public func tooltipSelected(entry: ChartDataEntry?) {
          
        if isCombined
        {
            
        }
        else{
            // Only one processor
            for processor in preProcessors
            {
                processor.tooltipSelected(entry: entry)
            }
        }
      }
      
      /// Legend tapped
      public func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
          
          if isCombined
          {
            ChartInteractionHelperFunction.legendDisabled(axisChartBase: self, indexPath: indexPath, entry: entry)// combinedLegendDisabled(chart: self, indexPath: indexPath, entry: entry)
          }
          else{
              // Only one processor
              for processor in preProcessors
              {
                  processor.legendDisabled(indexPath: indexPath, entry: entry)
              }
          }
      }
          
          
      /// Legend tapped
      public func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
          
          if isCombined
          {
            ChartInteractionHelperFunction.legendEnabled(axisChartBase: self, indexPath: indexPath, entry: entry)
          }
          else{
              // Only one processor
              for processor in preProcessors
              {
                  processor.legendEnabled(indexPath: indexPath, entry: entry)
              }
          }
      }
    /// Legend range adjusted
    open func legendRangeSelected(minimum: Double, maximum: Double) {
      
        if isCombined
        {
            
        }
        else{
            // Only one processor
            for processor in preProcessors
            {
                processor.legendRangeSelected(minimum: minimum, maximum: maximum)
            }
        }
    }
    
    public func drillEntrySelected(entry: ChartDataEntry, level: Int) {
           
//         self.chartActionListener?.drillReverted?(chartView: self, selectedEntry: entry, index: level)
           
    }
    
    open func drillEntry(selectedEntry:ChartDataEntry)
    {
//           let index = data?.dataSets[0].entryIndex(entry: selectedEntry)
           
           delegateToContainer?.chartValueDrillPerformed?(self, entry: selectedEntry, level: curLevel)
           
//           self.chartActionListener?.drillPerformed!(chartView: self, selectedEntry: selectedEntry, index: index!)
       }
    
    public static func getAllTextLayer(chartView : ChartViewBase) -> [CATextLayer]
    {
        let newChart = chartView.plotView
        
        var barArray:[CATextLayer] = []
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    barArray.append((caLayer as! CATextLayer))
                }
                else if caLayer.isKind(of: ValueTextLayer.self)
                {
                    if let childLayers = caLayer.sublayers, childLayers.count > 0 {
                        barArray.append((childLayers[0] as! CATextLayer))
                    }
                }
            }
        }
        return barArray
    }
    
    public static var qaUserInfoKey: CodingUserInfoKey {
           return CodingUserInfoKey(rawValue: "QAAUTOMATION")!
    }
}

// MARK: - General Extensions

extension Array {
    subscript(safe index: Index) -> Element? {
        let isValidIndex = index >= 0 && index < count
        return isValidIndex ? self[index] : nil
    }
}
