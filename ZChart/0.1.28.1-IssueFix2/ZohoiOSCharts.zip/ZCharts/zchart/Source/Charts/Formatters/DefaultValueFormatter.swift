//
//  DefaultValueFormatter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation

@objc(ChartDefaultValueFormatter)
open class DefaultValueFormatter: NSObject, IValueFormatter
{
    public typealias Block = (
        _ value: Double,
        _ entry: ChartDataEntry,
        _ dataSetIndex: Int,
        _ viewPortHandler: ViewPortHandler?) -> String
    
    open var block: Block?
    
    open var hasAutoDecimals: Bool = false
    
    fileprivate var _formatter: NumberFormatter?
    open var formatter: NumberFormatter?
    {
        get { return _formatter }
        set
        {
            hasAutoDecimals = false
            _formatter = newValue
        }
    }
    
    fileprivate var _decimals: Int?
    open var decimals: Int?
    {
        get { return _decimals }
        set
        {
            _decimals = newValue
            
            if let digits = newValue
            {
                self.formatter?.minimumFractionDigits = digits
                self.formatter?.maximumFractionDigits = digits
                self.formatter?.usesGroupingSeparator = true
            }
        }
    }
    
    public override init()
    {
        super.init()
        
        self.formatter = NumberFormatter()
        hasAutoDecimals = true
    }
    
    public init(formatter: NumberFormatter)
    {
        super.init()
        
        self.formatter = formatter
    }
    
    public init(decimals: Int)
    {
        super.init()
        
        self.formatter = NumberFormatter()
        self.formatter?.usesGroupingSeparator = true
        self.decimals = decimals
        hasAutoDecimals = true
    }
    
    public init(block: @escaping Block)
    {
        super.init()
        
        self.block = block
    }
    
    public static func with(block: @escaping Block) -> DefaultValueFormatter?
    {
        return DefaultValueFormatter(block: block)
    }
    
    open func stringForValue(_ value: Double,
                             entry: ChartDataEntry,
                             dataSetIndex: Int,
                             viewPortHandler: ViewPortHandler?) -> String
    {
        if block != nil
        {
            return block!(value, entry, dataSetIndex, viewPortHandler)
        }
        else
        {
            return formatter?.string(from: NSNumber(floatLiteral: value)) ?? ""
        }
    }
    
    open func getFormattedTextforValue(value:Double, type: FieldType, data:AnyObject?) -> String {
        return formatter?.string(from: NSNumber(floatLiteral: value)) ?? ""
    }
    open func getFormattedTextforLabel(label: String, type: FieldType, data:AnyObject?) -> String {
        return label
    }
    
    open func getFormattedValue(entry: ChartDataEntry?, nodeName: String) -> String {
        return nodeName
    }
    
    public func getFormattedValue(entry: ChartDataEntry) -> String {
        return entry.xString ?? ""
    }
    
    public func getFormattedValue(stackSum: Double, entryX: Double) -> String {
        return String(stackSum)
    }
    
    public func getFormattedValue(medianValue: Double) -> String {
        return String(medianValue)
    }
    
    public func getFormattedValue(whiskersValue: Double) -> String {
        return String(whiskersValue)
    }
    
    public func stringForLabel(datasetLabel: String) -> String {
        return datasetLabel
    }
    
}
