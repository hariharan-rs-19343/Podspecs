//
//  DefaultFillFormatter.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

/// Default formatter that calculates the position of the filled line.
@objc(ChartDefaultFillFormatter)
open class DefaultFillFormatter: NSObject, IFillFormatter
{
    public typealias Block = (
        _ dataSet: IChartDataSet, _ chart:ChartViewBase) -> CGFloat
    
    open var block: Block?
    
    public override init()
    {
        
    }
    
    public init(block: @escaping Block)
    {
        self.block = block
    }
    
    public static func with(block: @escaping Block) -> DefaultFillFormatter?
    {
        return DefaultFillFormatter(block: block)
    }
    
    open func getFillLinePosition(
        dataSet: IChartDataSet, chart:ChartViewBase) -> CGFloat
    {
        if block != nil
        {
            return block!(dataSet, chart)
        }
        else
        {
            let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
            
            var fillMin = CGFloat(baseLineValue)
            
            guard let data = chart.data
                else { return fillMin }
            
            if (data.yMax > baseLineValue && data.yMin < baseLineValue) || (data.yMax == baseLineValue && data.yMin == baseLineValue)
            {
                fillMin = CGFloat(baseLineValue)
            }
            else
            {
                fillMin = 0.0//CGFloat(dataSet.yMin >= 0.0 ? chart.chartYMin : chart.chartYMax)
            
                if baseLineValue != 0
                {
                    fillMin = CGFloat(baseLineValue)
                }
                
            }
            
            return fillMin
        }
    }
}
