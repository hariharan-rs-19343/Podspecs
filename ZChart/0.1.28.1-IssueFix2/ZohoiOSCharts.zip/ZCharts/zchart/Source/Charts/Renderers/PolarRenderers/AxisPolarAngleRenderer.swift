//
//  AxisPolarAngleRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 10/07/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

open class AxisPolarAngleRenderer:AxisRendererBase
{
    internal func getRequiredSize() -> CGSize
    {
         var radiusXOffset:CGFloat = 0
         var radiusYOffset:CGFloat = 0
         if let axis = self.axis
         {
            if axis.drawAxisLineEnabled && axis.visible
            {
                radiusXOffset += axis.axisLineWidth
            }
            
            if axis.drawTickMarksEnabled && axis.visible
            {
                radiusXOffset += axis.axisTickMarkSize
            }

            if axis.drawLabelsEnabled || axis.isDrawTopYLabelEntryEnabled || axis.isDrawBottomYLabelEntryEnabled
            {
                radiusYOffset = radiusXOffset
                let text = self.getLongestLabelfromEntries(axis:axis)
                let textSize = text.size(withAttributes: [NSAttributedString.Key.font: axis.labelFont])
                radiusXOffset += min(axis.maxLabelWidth,textSize.width) + axis.yOffset
                radiusYOffset += min(axis.maxLabelWidth,textSize.height) + axis.yOffset
                
            }
         }
         return CGSize(width: radiusXOffset, height: radiusYOffset)
    }
    
    override open func renderAxisLine(context: CGContext)
    {
        guard
            let axis = self.axis,
            let polarTransformer = transformer as? PolarTransformer,
            let entries = self.axis?.entries,
            (entries.count > 0)
            else { return }
        
        if !axis.isEnabled || !axis.isDrawAxisLineEnabled || !axis.isVisible
        {
            return
        }
        
        guard let isXaxis = (self.axis?.isKind(of: XAxis.self))
        else { return }
        
        context.saveGState()
        
        context.setStrokeColor(axis.axisLineColor.cgColor)
        context.setLineWidth(axis.axisLineWidth)
        if axis.axisLineDashLengths != nil
        {
            context.setLineDash(phase: axis.axisLineDashPhase, lengths: axis.axisLineDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
       
        let axisLinePath = CGMutablePath()
        
        let radius = polarTransformer.radius
       
        let angleValues = polarTransformer.pixelForValues(x: entries[0], y: entries[0])
       
        var angle = isXaxis ? angleValues.x : angleValues.y
       
        angle = polarTransformer.getAbsoluteAngleForGivenAngle(angle: angle)
       
        let entryPosition = ChartUtils.getPosition(center: polarTransformer.centerPoint, dist: radius, angle: angle)
       
        axisLinePath.move(to: entryPosition)
        
        for axisValue in entries
        {
           let angleValues = polarTransformer.pixelForValues(x: axisValue, y: axisValue)
           
           var angle = isXaxis ? angleValues.x : angleValues.y
           
           angle = polarTransformer.getAbsoluteAngleForGivenAngle(angle: angle)
           
           let entryPosition = ChartUtils.getPosition(center: polarTransformer.centerPoint, dist: radius, angle: angle)
           
           axisLinePath.addLine(to: entryPosition)
           
        }
       
        axisLinePath.closeSubpath()
        
        context.beginPath()
        context.addPath(axisLinePath)
        context.strokePath()
        
        context.restoreGState()
    }
    
    override open func renderAxisLabels(context: CGContext)
    {
        guard
            let axis = self.axis,
            let polarTransformer = transformer as? PolarTransformer,
            let chart = chartViewBase
            else { return }
        
        if !axis.isEnabled
        {
            return
        }
        
        var entries = [Int:Double]()
        
        for entryEnum in axis.entries.enumerated() {
            entries[entryEnum.offset] = entryEnum.element
        }
        
        let isEmptyEntries = axis.entries.isEmpty
        
        if !axis.drawLabelsEnabled || !axis.visible {
            
            var flag = true
            
            entries = [:]
           
            if axis.isDrawBottomYLabelEntryEnabled
            {
                entries[0] = axis.axisMinimum
                if !isEmptyEntries && axis.entries[safe:0] != nil {
                    axis.entries[0] = axis.axisMinimum
                }
                else {
                    axis.entries.append(axis.axisMinimum)
                }
                flag = false
            }
            
            if axis.isDrawTopYLabelEntryEnabled
            {
                if !isEmptyEntries && axis.entries[safe:axis.entries.count - 1] != nil {
                    axis.entries[axis.entries.count - 1] = axis.axisMaximum
                }
                else {
                    axis.entries.append(axis.axisMaximum)
                }
                entries[axis.entries.count - 1] = axis.axisMaximum
                flag = false
            }
            
            if flag
            {
                return
            }
        }

        let chartRadius = polarTransformer.radius
        let chartCenter = polarTransformer.centerPoint
        
        let labelFont = axis.labelFont
        let labelTextColor = axis.labelTextColor
        
        let from = axis.isDrawBottomYLabelEntryEnabled ? 0 : 1
        let to = axis.isDrawTopYLabelEntryEnabled ? entries.count : (entries.count - 1)
        
//        let labelAttrs = [NSAttributedString.Key.font: labelFont, NSAttributedString.Key.foregroundColor: labelTextColor]
        
        
        var radiusOffset:CGFloat = 0
        
        if axis.drawAxisLineEnabled
        {
            radiusOffset += axis.axisLineWidth
        }
        
        let tickMarkRadiusStart = chartRadius + radiusOffset + axis.yOffset
        
        if axis.drawTickMarksEnabled
        {
            radiusOffset += axis.axisTickMarkSize
        }
        
        let labelRadius = axis.visible ? (chartRadius + radiusOffset + axis.yOffset) : (chartRadius + axis.yOffset) //+ (textSize.height)/2
        
        let tickMarkRadiusEnd = labelRadius
        
        tickLabels.removeAll()
        
        let curEntry = chart.lastSelected
        
        let keys = entries.keys.sorted()
        
        for i in stride(from: from, to: to, by: 1)
        {
            var labelTextColor = axis.labelTextColor
            
            var labelFont = axis.labelFont
            
            if curEntry != nil{
                
                let boldText = chart.IsEntryXSelected(x: entries[keys[i]] ?? 0.0 ) //xAxis.entries[i] == curEntry?.x
                
                //TODO HANDLE FOR BAR, CHECK XAXISRENDERER
                
                if (boldText)
                {
                    (labelFont, labelTextColor) = XAxisRenderer.getBoldAttributes(axis: axis)
                }
            }
            
            let labelAttrs = [NSAttributedString.Key.font: labelFont, NSAttributedString.Key.foregroundColor: labelTextColor]
            
            let value = (i >= 0 && i < entries.count) ? entries[keys[i]] ?? 0 : 0
            
            let text = axis.getFormattedLabel(keys[i])
            
            let textSize = text.size(withAttributes: [NSAttributedString.Key.font: labelFont])
            
            let constrainedToSize = CGSize(width: axis.maxLabelWidth, height: textSize.height)
            
            let angle = polarTransformer.absoluteAngleForValue(value: value)
            
            let radius = labelRadius //+ (textSize.width/2)
            
            let point = ChartUtils.getPosition(center: chartCenter, dist: radius, angle: angle)
            
            let anchor = CommonHelperFunctions.getPolarAnchorPoint(angle: angle, chart: chart)
            
            drawLabelTruncated(context: context, formattedLabel: text, x: point.x, y: point.y, attributes: labelAttrs, constrainedToSize: constrainedToSize, anchor: anchor, angleRadians: (0 * ChartUtils.Math.FDEG2RAD))
            
            let tickLabel = TickLabel()
            
            tickLabel.label = text
            
            tickLabel.value = entries[keys[i]] ?? 0.0
            
            tickLabel.point = point
            
            tickLabel.constrainedSize = constrainedToSize
            
            tickLabel.angleInRadians = (0 * ChartUtils.Math.FDEG2RAD)
            
            tickLabel.anchorPoint = anchor
            
            tickLabel.attributes = labelAttrs
            
            tickLabel.stringDrawingOption = .truncatesLastVisibleLine
           
            tickLabel.updateTickBounds()
            
            tickLabels.append(tickLabel)
            
            if axis.drawTickMarksEnabled && axis.visible
            {
                context.saveGState()
                
                context.setStrokeColor(axis.axisTickMarkColor.cgColor)
                context.setLineWidth(axis.axisTickMarkLineWidth)
                context.beginPath()
                context.move(to: ChartUtils.getPosition(center: chartCenter, dist: tickMarkRadiusStart, angle: angle) )
                context.addLine(to: ChartUtils.getPosition(center: chartCenter, dist: tickMarkRadiusEnd, angle: angle))
                context.strokePath()
                
                context.restoreGState()
            }

        }
        
    }
    
    override open func renderLimitLines(context: CGContext) {
        
    }
    
    override open func renderBaseLine() {
        
    }
    
    override open func drawGridLine(context: CGContext, position:CGPoint) {
        guard
            let axis = self.axis,
            let polarTransformer = transformer as? PolarTransformer,
            let entries = self.axis?.entries,
            (entries.count > 0)
            else { return }
        
        context.setLineWidth(axis.gridLineWidth)
        
        if axis.gridLineDashLengths != nil
        {
            context.setLineDash(phase: axis.gridLineDashPhase, lengths: axis.gridLineDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        guard let isXaxis = (self.axis?.isKind(of: XAxis.self))
        else { return }
        
        let radius = polarTransformer.radius
        
        context.beginPath()
 
        for axisValue in  entries
        {
            context.move(to: polarTransformer.centerPoint)
            
            let angleValues = polarTransformer.pixelForValues(x: axisValue, y: axisValue)
            
            var angle = isXaxis ? angleValues.x : angleValues.y
            
            angle = polarTransformer.getAbsoluteAngleForGivenAngle(angle: angle)
            
            let entryPosition = ChartUtils.getPosition(center: polarTransformer.centerPoint, dist: radius, angle: angle)
            
            context.addLine(to: entryPosition)
            
        }
        
        context.strokePath()
    }
}
