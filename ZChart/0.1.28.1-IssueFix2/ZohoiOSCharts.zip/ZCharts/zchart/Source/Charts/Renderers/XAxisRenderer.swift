//
//  XAxisRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
import UIKit
#endif

@objc(ChartXAxisRenderer)
open class XAxisRenderer: AxisRendererBase
{
    
    //    weak var chartViewBase:ChartViewBase? = nil
    
    // Longest label
//    var longest = ""
    
    fileprivate let barTypesAllowed = [ChartType.Bar, ChartType.Bullet, ChartType.WaterFall]
    
    public init(viewPortHandler: ViewPortHandler?, xAxis: XAxis?, transformer: Transformer?, chartViewBase: ChartViewBase?)
    {
        super.init(viewPortHandler: viewPortHandler, transformer: transformer, axis: xAxis, chartViewBase: chartViewBase)
        
    }
    
    open override func computeAxis(min: Double, max: Double, inverted: Bool)
    {
        guard let
            viewPortHandler = self.viewPortHandler
            else { return }
        
        var min = min, max = max
        
        if let transformer = self.transformer
        {
            // calculate the starting and entry point of the y-labels (depending on
            // zoom / contentrect bounds)
            if viewPortHandler.contentWidth > 10 && !viewPortHandler.isFullyZoomedOutX
            {
                var p1 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop))
                var p2 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentRight, y: viewPortHandler.contentTop))
                
                p1 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: 0, point: p1)
                p2 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: 0, point: p2)
                
                if inverted
                {
                    min = Double(p2.x)
                    max = Double(p1.x)
                }
                else
                {
                    min = Double(p1.x)
                    max = Double(p2.x)
                }
            }
        }
        
        computeAxisValues(min: min, max: max)
    }
    
    open override func computeAxisValues(min: Double, max: Double)
    {
        //        super.computeAxisValues(min: min, max: max)
        guard let axis = self.axis,
              let chart = chartViewBase
        else { return }
        self.axis?.scaleTypeProtocol.computeAxisValues(min: min, max: max, axis: axis, chart: chart)
    }
    
    
    func resetXAxisLabelSizes(_ xAxis: XAxis) {
        xAxis.labelHeight = 1.0
        xAxis.labelWidth = 1.0
        xAxis.labelRotatedHeight = 1.0
        xAxis.labelRotatedWidth = 1.0
    }
    
    open override func computeSize()
    {
        guard let
            xAxis = self.axis as? XAxis
            else { return }
        
        resetXAxisLabelSizes(xAxis)
        
        defer {
            computeSizeForAxisTitle()
        }
        
        if !xAxis.drawLabelsEnabled {
            return
        }
        
        if xAxis.customTickEnabled
        {
            if xAxis.tickDelegate != nil
            {
                xAxis.labelWidth = xAxis.longestSize.width
                xAxis.labelHeight = xAxis.longestSize.height
                xAxis.labelRotatedWidth = xAxis.longestSize.width
                xAxis.labelRotatedHeight = xAxis.longestSize.height
                return
                
            }
            
        }
        
        guard let chart = self.chartViewBase,
              let chartData = (self.chartViewBase?.data),
              let viewPort = viewPortHandler
        else { return }
        
        /*if longest == ""
        {
            longest =  getLongestLabelOfAllData(axis: xAxis)
        }*/
        
        var labelFont = xAxis.labelHighlightFont ?? xAxis.labelFont
        
        if xAxis.labelHighlightFont != nil
        {
            labelFont = xAxis.labelHighlightFont!
        }
        else{
            var symTraits = labelFont.fontDescriptor.symbolicTraits
            #if os(iOS) || os(tvOS)
                symTraits.insert([.traitBold])
                
                guard let fontDescriptorVar = labelFont.fontDescriptor.withSymbolicTraits(symTraits)
                else { return }
                
                labelFont =  UIFont(descriptor: fontDescriptorVar, size: 0)
            #else
                symTraits.insert(NSFontDescriptor.SymbolicTraits.bold)
                let fontDescriptorVar = labelFont.fontDescriptor.withSymbolicTraits(symTraits)
                labelFont =  NSUIFont(descriptor: fontDescriptorVar, size: 0)!
            #endif
        }
     
        let labelAttrs = [NSAttributedString.Key.font: labelFont]
        
        var labelSize = xAxis.longestLabel.size(withAttributes: labelAttrs)
        
        // width for single point
        var maxLabelWidth = chartData.xMin == chartData.xMax ? (viewPort.contentWidth) : xAxis.maxLabelWidth //CommonHelperFunctions.getOnePointWidth(chart: self.chartViewBase!)
        
        if (self.axis?.scaleType)! == .Time
        {
        
            maxLabelWidth =  chartData.xMin == chartData.xMax ? (viewPort.contentWidth) : CommonHelperFunctions.getMaxWidthBetweenEntries(barLine: chart)
            
            if xAxis.entries.count > 1 && xAxis.tickLabelMode == .auto
            {
                let startPosition = chart.pixelForValues(x: xAxis.entries[0], y: 0, axisIndex: 0).x
                let endPosition = chart.pixelForValues(x: xAxis.entries[xAxis.entries.count-1], y: 0, axisIndex: 0).x
                let widthAvailable = endPosition - startPosition
                
                if CGFloat(xAxis.entries.count) > floor(widthAvailable/labelSize.width)
                {
                    maxLabelWidth = 0
                }
            }
            
            
        }
        
        var labelRotatedSize = CGSize()
        
        if xAxis.maxLabelHeight <= 0{
            xAxis.maxLabelHeight = labelSize.height
        }
        
        let isOrdinalScale = xAxis.scaleType == .Ordinal
        
        switch xAxis.tickLabelMode{
            
        case .auto:
            //label width is less then requried maxlabel width (horizontal case)
            
            xAxis.labelRotationAngle = 0
            
            labelRotatedSize = labelSize
            
            let width = labelSize.width.isZero || labelSize.width.isNaN ? 1.0 : labelSize.width
            let scaleX = viewPort.scaleX.isZero ? 1.0 : viewPort.scaleX
            
            //rotation case
            if isOrdinalScale && (labelSize.width > CommonHelperFunctions.getOnePointWidth(chart: chart) || ceil(xAxis.axisRange / scaleX) > floor(viewPort.contentWidth / width)) || !isOrdinalScale && xAxis.entries.count > ChartUtils.doubleToIntSafeCast(value: floor(viewPort.contentWidth / width))
            {
                let rotatedLabelSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: xAxis.autoRotateAngle)
                
                if round(abs(labelSize.width * cos(xAxis.autoRotateAngle * ChartUtils.Math.FDEG2RAD))) < round(labelSize.width) {
                    
                    xAxis.labelRotationAngle = xAxis.autoRotateAngle
                    
                    labelRotatedSize = rotatedLabelSize
                    
                    if xAxis.labelRotationAngle != 0 && xAxis.labelRotationAngle != 180 && xAxis.labelRotationAngle != 360
                    {
                        
                        //height restiction
                        if labelRotatedSize.height > xAxis.maxLabelHeight {
                            computeLongestTickLabel(MaxLabelSize: CGSize(width: abs( xAxis.maxLabelHeight / sin(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) ), height: 0),angle: xAxis.labelRotationAngle)
                            
                            labelRotatedSize = longestTickLabel.boundPath.boundingBox.size//.bounds.size
                        }
                        
                    }
                    else{
                        //width restiction
                        if maxLabelWidth >= 0 {
                            labelRotatedSize.width = maxLabelWidth
                        }
                    }
                }
            }
            
            break
            
        case .forced:
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: xAxis.labelRotationAngle)
            
            //height restiction
            
            let height = (labelRotatedSize.height < xAxis.maxLabelHeight) ? labelRotatedSize.height : xAxis.maxLabelHeight
            
            if maxLabelWidth == .infinity{
                labelRotatedSize.width = maxLabelWidth
                labelRotatedSize.height = height
                break
            }
                
            if xAxis.labelRotationAngle != 0 && xAxis.labelRotationAngle != 180 && xAxis.labelRotationAngle != 360
            {
                if labelRotatedSize.height > xAxis.maxLabelHeight {
                    
                    computeLongestTickLabel(MaxLabelSize: CGSize(width: abs( xAxis.maxLabelHeight / sin(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) ), height: 0),angle: xAxis.labelRotationAngle)
                    
                    labelRotatedSize = longestTickLabel.boundPath.boundingBox.size //.bounds.size
                }
            }
            else{

                //width restiction
                if labelSize.width > maxLabelWidth && maxLabelWidth != 0 {
                    labelRotatedSize.width = maxLabelWidth
                }

            }
            
            break
            
        case .wordwrap:
            
            var labelMaxSize = CGSize()
            
            if maxLabelWidth <= 0 || maxLabelWidth > labelSize.width{
                maxLabelWidth = labelSize.width
            }
            
            
            labelMaxSize.width = maxLabelWidth
            
            //Inverted X axis results in negative value
            /*if xAxis.isInverted
            {
                labelMaxSize.width = -(labelMaxSize.width)
            }*/
            
            // calculate rect constrained to max width
            let rect = xAxis.longestLabel.boundingRect(with: labelMaxSize, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: labelAttrs, context: nil)
            
            // To maintain space between axis line and bottom
            labelSize = rect.size
            
            labelMaxSize = rect.size
            
            if labelMaxSize.height > xAxis.maxLabelHeight
            {
                labelMaxSize.height = xAxis.maxLabelHeight
                
                labelSize.height = labelMaxSize.height
            }
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelMaxSize, degrees: xAxis.labelRotationAngle)
            
            break
        }
        
        let labelWidth = labelSize.width
        let labelHeight = labelSize.height
        
        xAxis.longestSize = labelSize
        xAxis.labelWidth = labelWidth
        xAxis.labelHeight = labelHeight
        xAxis.labelRotatedWidth = labelRotatedSize.width
        xAxis.labelRotatedHeight = labelRotatedSize.height
    }
    
    
    func computeSizeForAxisTitle()
    {
        guard let
            xAxis = self.axis as? XAxis
            else { return }
        
        if !xAxis.axisTitleEnabled {
            return
        }
        
        let axisTitleSize =  (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont])
        
        xAxis.labelHeight +=  axisTitleSize.height
        xAxis.labelRotatedHeight += axisTitleSize.height
    }
    
    open override func renderAxisLabels(context: CGContext)
    {
        guard let
            xAxis = self.axis as? XAxis
            else { return }
        
        if !xAxis.isEnabled //|| !xAxis.isDrawLabelsEnabled
        {
            return
        }
        
       drawLabels(context: context)
    }
    
    fileprivate var _axisLineSegmentsBuffer = [CGPoint](repeating: CGPoint(), count: 2)
    
    open override func renderAxisLine(context: CGContext)
    {
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        if !xAxis.isEnabled || !xAxis.isDrawAxisLineEnabled
        {
            return
        }
        
        context.saveGState()
        
        context.setStrokeColor(xAxis.axisLineColor.cgColor)
        context.setLineWidth(xAxis.axisLineWidth)
        if xAxis.axisLineDashLengths != nil
        {
            context.setLineDash(phase: xAxis.axisLineDashPhase, lengths: xAxis.axisLineDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        let contentTop = CommonHelperFunctions.contentTop(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentBottom = CommonHelperFunctions.contentBottom(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentLeft = CommonHelperFunctions.contentLeft(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentRight = CommonHelperFunctions.contentRight(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        if xAxis.labelPosition == .top
            || xAxis.labelPosition == .topInside
            || xAxis.labelPosition == .bothSided
        {
            _axisLineSegmentsBuffer[0].x = contentLeft
            _axisLineSegmentsBuffer[0].y = contentTop
            _axisLineSegmentsBuffer[1].x = contentRight
            _axisLineSegmentsBuffer[1].y = contentTop
            context.strokeLineSegments(between: _axisLineSegmentsBuffer)
        }
        
        if xAxis.labelPosition == .bottom
            || xAxis.labelPosition == .bottomInside
            || xAxis.labelPosition == .bothSided
        {
            _axisLineSegmentsBuffer[0].x = contentLeft
            _axisLineSegmentsBuffer[0].y = contentBottom
            _axisLineSegmentsBuffer[1].x = contentRight
            _axisLineSegmentsBuffer[1].y = contentBottom
            context.strokeLineSegments(between: _axisLineSegmentsBuffer)
        }
        
        context.restoreGState()
    }
    
    //Need to change according to barChart defined group space, barwidth and bar space (hardcoded)
    func getNewPositionForBarChart(value:Double, valueToPixelMatrix: CGAffineTransform, position: CGPoint) -> CGFloat
    {
        guard let xStringCount = (chartViewBase?.data?.xString?.count)
        else { return 0 }
        let val  =  ChartUtils.doubleToIntSafeCast(value:Double(abs(ChartUtils.doubleToIntSafeCast(value:value)) % xStringCount))
        /*  var count  =  0//(chartViewBase?.data?._dataSets.count)!
         var hideCount = 0
         for i in 0 ..< (chartViewBase?.data?._dataSets.count)!
         {
         let dataset = chartViewBase?.data?._dataSets[i]
         if (dataset?.isVisible)!
         {
         count = count + 1
         }
         else
         {
         hideCount = hideCount + 1
         }
         }
         
         var initVal:CGPoint = CGPoint.zero
         
         for i in 0 ..< (chartViewBase?.data?._dataSets.count)!
         {
         let dataset = chartViewBase?.data?._dataSets[i]
         if (dataset?.isVisible)!
         {
         initVal.x = CGFloat((dataset!.entryForIndex(val)?.x)!)
         break
         }
         }
         
         let barChart = (self.chartViewBase) as! BarChartView
         
         let interval = Double(count) * (((barChart.data) as! ChartData).barWidth) + Double(count-1) * (((barChart.data) as! ChartData).barSpace) //bar width and bar space
         initVal.x = initVal.x + CGFloat(interval/2) - CGFloat((((barChart.data) as! ChartData).groupSpace/4)) // group space
         initVal = initVal.applying(valueToPixelMatrix)*/
        
        var initVal:CGPoint = CGPoint.zero
        
        initVal.x = CGFloat(val) //+ 0.5
        
        initVal = initVal.applying(valueToPixelMatrix)
        
        return initVal.x
    }
    
    static func getBoldAttributes(axis:AxisBase)  -> (NSUIFont, NSUIColor){
        
        var labelFont = axis.labelFont
                
        if axis.labelHighlightFont != nil
        {
            labelFont = axis.labelHighlightFont!
        }
        else{
            var symTraits = labelFont.fontDescriptor.symbolicTraits
            
        #if os(iOS) || os(tvOS)
            symTraits.insert([.traitBold])
            
            guard let fontDescriptorVar = labelFont.fontDescriptor.withSymbolicTraits(symTraits)
            else { return (labelFont,axis.labelHighlightColor)}
            
            labelFont =  UIFont(descriptor: fontDescriptorVar, size: 0)
        #else
            symTraits.insert(NSFontDescriptor.SymbolicTraits.bold)
            let fontDescriptorVar = labelFont.fontDescriptor.withSymbolicTraits(symTraits)
            
            labelFont =  NSUIFont(descriptor: fontDescriptorVar, size: 0) ?? labelFont
        #endif
        }
        
        let labelColor = axis.labelHighlightColor
        
        return (labelFont, labelColor)
    }
    
    /// draws the x-labels on the specified y-position
    open func drawLabels(context: CGContext) {
        
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler,
            let chart = self.chartViewBase,
            let chartData = (chart.data)
            else { return }
        
        let anchor = xAxis.getAnchorForAxisTickLabel(isRotated: chart.isRotated)
        
        defer {
            drawAxisTitle(context: context, anchor: chart.isRotated ? anchor : CGPoint(x: anchor.x, y: 1))
        }
        
        if !xAxis.drawLabelsEnabled {
            return
        }
        
        for tickLabel in tickLabels {
            
            var boldText = false
            
            let curEntry = chart.lastSelected
            
            var labelColor = xAxis.labelTextColor
            
            var labelFont = xAxis.labelFont
            
            if curEntry != nil {
                boldText = chart.IsEntryXSelected(x: tickLabel.value)
            }
            
            if let barPlotOptions = chart.getPlotOptions(type: .Bar) as? BarPlotOptions, !barPlotOptions.groupSpace.isZero && (chartData.dataSetCount) > 1 {
//                tickLabel.point.x = getNewPositionForBarChart(value: tickLabel.value, valueToPixelMatrix: transformer.valueToPixelMatrix, position: tickLabel.point)
                
                if curEntry != nil {
                    boldText = chart.IsEntryRoundedXSelected(x: tickLabel.value)
                }
            }
            
            if boldText
            {
                (labelFont, labelColor) = XAxisRenderer.getBoldAttributes(axis: xAxis)
            }
            
            let labelAttrs = boldText ? [NSAttributedString.Key.font: labelFont,
                                         NSAttributedString.Key.foregroundColor: labelColor,
                                         NSAttributedString.Key.paragraphStyle: tickLabel.attributes[.paragraphStyle]!] : tickLabel.attributes
            
            if chart.isRotated {
                if !viewPortHandler.isInBoundsY(tickLabel.point.y) {
                    continue
                }
            }
            else {
                if !viewPortHandler.isInBoundsX(tickLabel.point.x) {
                    continue
                }
            }
            
            if xAxis.customTickEnabled && xAxis.tickDelegate != nil
            {
                guard let tickLayer =  xAxis.tickDelegate?.getTickLayer(axis: xAxis, value: tickLabel.value, position: tickLabel.point, size: xAxis.longestSize, anchor: anchor, text: tickLabel.label, chart: chart)
                else { return }
                
                chart.nsuiLayer?.addSublayer(tickLayer)
                
                tickLayer.tickValue = tickLabel.value
                tickLayer.tickPosition = tickLabel.point
                tickLayer.tickSize = xAxis.longestSize
                tickLayer.tickAnchor = tickLabel.anchorPoint
                tickLayer.opacity = Float(tickLabel.opacity)
                
                continue
                
            }
            
            if chart.isRotated {
                drawLabelHorizontal(context: context, formattedLabel: tickLabel.label, x: tickLabel.point.x, y: tickLabel.point.y, attributes: labelAttrs, constrainedToSize: tickLabel.constrainedSize, anchor: tickLabel.anchorPoint, angleRadians: tickLabel.angleInRadians,options: tickLabel.stringDrawingOption)
            }
            else {
                drawLabel(context: context,
                          formattedLabel: tickLabel.label,
                          x: tickLabel.point.x,
                          y: tickLabel.point.y,
                          attributes: labelAttrs,
                          constrainedToSize: tickLabel.constrainedSize,
                          anchor: tickLabel.anchorPoint,
                          angleRadians: tickLabel.angleInRadians)
            }
        }
        
        
    }
    
    
    
    func drawAxisTitle(context: CGContext, anchor: CGPoint){
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler
            else { return }
        
        if !xAxis.enabled || !xAxis.axisTitleEnabled {
            return
        }
        
        let xLabelAttrs = [NSAttributedString.Key.font: xAxis.axisTitleFont,
                           NSAttributedString.Key.foregroundColor: xAxis.axisTitleColor,
                           NSAttributedString.Key.paragraphStyle: getParaStyle()]
        
        let x = (viewPortHandler.contentLeft) + ((viewPortHandler.contentRect.width)/2)
        
        let titleHeight = (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont]).height
        
        var labelMaxSize = CGSize()
        labelMaxSize.width = (viewPortHandler.contentRect.width)*(3/4)
        labelMaxSize.height = titleHeight
        
//        drawLabel(context: context, formattedLabel: xAxis.axisTitle, x: x, y: (viewPortHandler.chartHeight)-(titleHeight) , attributes: xLabelAttrs, constrainedToSize: labelMaxSize, anchor: anchor, angleRadians: 0)
        
        let point = xAxis.labelPosition == .bottom ? CGPoint(x: x, y: (viewPortHandler.chartHeight)-xAxis.axisTitleOffsets.marginBotom) : CGPoint(x: x, y: (titleHeight+xAxis.axisTitleOffsets.marginTop))
        let rect = xAxis.axisTitle.boundingRect(with: labelMaxSize, options:  [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: xLabelAttrs, context: nil)
        
        if xAxis.labelPosition == .bottom && viewPortHandler.contentBottom < viewPortHandler.chartHeight || (xAxis.labelPosition == .top) && viewPortHandler.contentTop > 0 {
            ChartUtils.drawMultilineText(context: context, text: xAxis.axisTitle, knownTextSize: rect.size, point: point, attributes: xLabelAttrs, constrainedToSize: labelMaxSize, anchor: anchor, angleRadians: 0)
        }
    }
    
    open override var gridClippingRect: CGRect
    {
        var contentRect = viewPortHandler?.contentRect ?? CGRect.zero
        let dx = self.axis?.gridLineWidth ?? 0.0
        contentRect.origin.x -= dx / 2.0
        contentRect.size.width += dx
        return contentRect
    }
    
    open override func drawGridLine(context: CGContext, position:CGPoint)
    {
        guard
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        let x = position.x
        
        let contentTop = CommonHelperFunctions.contentTop(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentBottom = CommonHelperFunctions.contentBottom(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        if x >= viewPortHandler.offsetLeft
            && x <= viewPortHandler.chartWidth
        {
            context.beginPath()
            context.move(to: CGPoint(x: x, y: contentTop))
            context.addLine(to: CGPoint(x: x, y: contentBottom))
            context.strokePath()
        }
    }
    
    // Called method from draw(_:)
    open override func renderLimitLines(context: CGContext)
    {
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = chartViewBase
            else { return }
        
        let limitLines = xAxis.limitLines
        
        if limitLines.count == 0
        {
            return
        }
        
        if !(chart.includeLayer)
        {
            return
        }
        
        let trans = transformer.valueToPixelMatrix
        
        var position = CGPoint(x: 0.0, y: 0.0)
        
        for i in 0 ..< limitLines.count
        {
            let l = limitLines[i]
            
            if !l.isEnabled
            {
                continue
            }
            
            //            context.saveGState()
            //            defer { context.restoreGState() }
            //
            //            var clippingRect = viewPortHandler.contentRect
            //            clippingRect.origin.x -= l.lineWidth / 2.0
            //            clippingRect.size.width += l.lineWidth
            //            context.clip(to: clippingRect)
            
            position.x = CGFloat(l.limit)
            position.y = 0.0
            position = chart.pixelForValues(point: position, axisIndex: 0)
            
            if !(viewPortHandler.isInBoundsX(position.x))
            {
                continue
            }
            
            let limitValueSize = l.getLimitValueSize(formattedString: l.getLimitValue(axis: xAxis))
            
            var limitTextSizeMax = max(xAxis.longestLabel.size(withAttributes: [NSAttributedString.Key.font: l.limitValueFont]).width, limitValueSize.width)
            
            if limitTextSizeMax > xAxis.maxLabelWidth
            {
                limitTextSizeMax = xAxis.maxLabelWidth
            }
            
            let limitValueHeight = max(xAxis.labelRotatedHeight, limitValueSize.height)
            
//            limitValueHeight = limitValueHeight > xAxis.maxLabelHeight ? xAxis.maxLabelHeight : limitValueHeight
            
            let titleHeight = xAxis.axisTitleEnabled ? (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont]).height : 0
            
            position.y =  viewPortHandler.contentBottom + (limitValueHeight - titleHeight) + xAxis.axisLabelOffsets.marginTop + xAxis.axisLabelOffsets.marginBotom
            
            var height = abs(position.y - viewPortHandler.contentBottom)
            
            var frame = CGRect(x: position.x - (limitTextSizeMax/2), y: viewPortHandler.contentBottom, width: limitTextSizeMax, height: height )
            
            var endPoint = CGPoint(x: position.x, y: viewPortHandler.contentTop)
            
            if xAxis.labelPosition == .top
            {
                // position.y contains y bound limit for limitline shape
                position.y =  viewPortHandler.contentTop - (limitValueHeight - titleHeight) - xAxis.axisLabelOffsets.marginTop - xAxis.axisLabelOffsets.marginBotom
                
                height = abs(viewPortHandler.contentTop - position.y)
                
                frame = CGRect(x: position.x - (limitTextSizeMax/2), y: position.y, width: limitTextSizeMax, height: height )
                
                endPoint = CGPoint(x: position.x, y: viewPortHandler.contentBottom)
            }
            
            let layer = LimitLineLayer(chartViewBase: chart, axisRendererBase: self, charLimitLine: l, position: frame,endPoint:endPoint)
            self.chartViewBase?.nsuiLayer?.addSublayer(layer)
            
            if l.drawLabelEnabled && !l.label.isEmpty
            {
                renderLimitLineLabel(limitLine: l, limitLineLayer: layer, position: position, limitLineType: .vertical)
            }
        }
    }
    
    open func renderLimitLineLine(context: CGContext, limitLine: ChartLimitLine, position: CGPoint)
    {
        guard
            //            let viewPortHandler = self.viewPortHandler
            self.viewPortHandler != nil
            else { return }
        
        //        let layer = LimitLineLayer(chartViewBase: self.chartViewBase!, axisRendererBase: self, charLimitLine: limitLine, position: position)
        //        self.chartViewBase?.layer.addSublayer(layer)
        
        /* context.beginPath()
         context.move(to: CGPoint(x: position.x, y: viewPortHandler.contentTop))
         context.addLine(to: CGPoint(x: position.x, y: viewPortHandler.contentBottom))
         
         context.setStrokeColor(limitLine.lineColor.cgColor)
         context.setLineWidth(limitLine.lineWidth)
         if limitLine.lineDashLengths != nil
         {
         context.setLineDash(phase: limitLine.lineDashPhase, lengths: limitLine.lineDashLengths!)
         }
         else
         {
         context.setLineDash(phase: 0.0, lengths: [])
         }
         
         context.strokePath() */
    }
}

extension XAxisRenderer{
    
    func computeLongestTickLabel(MaxLabelSize: CGSize,angle: CGFloat){
            
            guard let
                xAxis = self.axis as? XAxis
                else { return }
            
            let labelColor = xAxis.labelTextColor
            
            let labelFont = xAxis.labelHighlightFont ?? xAxis.labelFont
            
            let paraStyle = getParaStyle()
            
            if xAxis.tickLabelMode != .wordwrap{
                paraStyle.lineBreakMode = .byTruncatingTail
            }
            
            let labelAttrs = [NSAttributedString.Key.font: labelFont,
                              NSAttributedString.Key.foregroundColor: labelColor,
                              NSAttributedString.Key.paragraphStyle: paraStyle]
            
            let labelRotationAngleRadians = angle * ChartUtils.Math.FDEG2RAD
            
            longestTickLabel.label = xAxis.longestLabel
            
            longestTickLabel.constrainedSize = MaxLabelSize
            
            longestTickLabel.angleInRadians = labelRotationAngleRadians
            
            longestTickLabel.attributes = labelAttrs
        
            longestTickLabel.updateTickBounds()
            
        }
}
