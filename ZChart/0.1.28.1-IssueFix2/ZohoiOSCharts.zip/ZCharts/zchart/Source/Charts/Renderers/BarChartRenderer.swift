//
//  BarChartRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

open class BarChartRenderer: BarLineScatterCandleBubbleRenderer
{
    fileprivate let typeAllowed = [ChartType.Bar, ChartType.Mekko, ChartType.WaterFall, ChartType.BoxPlot, ChartType.HorizontalBarRange, ChartType.Bullet]
    
    open var barDeleted:Bool = false
    
    open class Buffer
    {
      open var rects = [CGRect]()
    }
    
    // [CGRect] per dataset
    open var _buffers = [Buffer]()
    
    open override func initBuffers()
    {
        if let barData = chart?.data
        {
            // Matche buffers count to dataset count
            if _buffers.count != barData.dataSetCount
            {
                while _buffers.count < barData.dataSetCount
                {
                    _buffers.append(Buffer())
                }
                while _buffers.count > barData.dataSetCount
                {
                    _buffers.removeLast()
                }
            }
            
            for i in stride(from: 0, to: barData.dataSetCount, by: 1)
            {
                let set = barData.dataSets[i]
                let size = set.entryCount
                if _buffers[i].rects.count != size
                {
                    _buffers[i].rects = [CGRect](repeating: CGRect(), count: size)
                }
            }
        }
        else
        {
            _buffers.removeAll()
        }
    }
    
    open func prepareBuffer(dataSet: IChartDataSet, index: Int)
    {
        guard
            let barLineChart = chart,
            let processor = barLineChart.getProcessor(type: dataSet.plotType) as? BarPreprocessor,
            let barPlotOption = barLineChart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions,
            let animator = animator,
            processor.entriesStackedYValue[index] != nil
            else { return }
        
        var barWidthHalf = barPlotOption.barWidth / 2.0
    
        let requiredSpace = barLineChart.getTransformer(axisIndex: dataSet.axisIndex).valueForTouchPoint(CGPoint(x: viewPortHandler!.contentLeft+barPlotOption.barSpacePixel, y: 10))

        let buffer = _buffers[index]
        var bufferIndex = 0
        let containsStacks = barPlotOption.isStacked
        
        let setIndex = index
        
        let isInverted = barLineChart.isInverted(axisIndex: dataSet.axisIndex)
        let phaseY = animator.phaseY
        var barRect = CGRect()
        var x: Double
        var y: Double
        
        var baseLineValue:Double = CommonHelperFunctions.getBaseLineValue(chart: barLineChart, dataSet: dataSet)
        
        var start = 0
        var end = min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)
        var increment = 1
        
        if (barLineChart.xAxis.inverted) {
            start = dataSet.entryCount - 1
            end = dataSet.entryCount - (min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)) - 1
            increment = -1
        }
        
        for i in stride(from: start, to: end, by: increment)
        {
            guard let e = dataSet.entryForIndex(i) else { continue }
            
            var prevEntry = dataSet.entryForIndex(i-1)
            
            var counterIndex = i-1
            
            while prevEntry != nil && (prevEntry?.x.isNaN)!
            {
                counterIndex -= 1
                prevEntry = dataSet.entryForIndex(counterIndex)
            }
            
            x = e.x
            
            if dataSet.plotType == .Mekko
            {
                guard let processor = processor as? MekkoPreprocessor
                else { continue}
                
                if
                   let xString = e.xString,
                   let sizeValueStart = processor.categoryToSize[xString]?.0,
                   let eSize = e.size {
                    
                    if eSize.isZero {
                        x = .nan
//                        value = .nan
                    }
                    else {
                        barWidthHalf = ((barPlotOption.barWidth / 2.0) - (requiredSpace.x/eSize)/2)*eSize
                        x = sizeValueStart + eSize/2
                    }
                }
            }
            
            y = e.y
            
            let isSegment = (prevEntry != nil && prevEntry?.x == e.x)
            
            guard let value = (processor.entriesStackedYValue[setIndex]?[i])
            else { continue}
            
            if barPlotOption.stackedPercentEnabled
            {
                y = processor.positiveSum[e.x] != nil ? (e.y/processor.positiveSum[e.x]!)*100 : Double.nan
                
                if e.y < 0
                {
                    y = Double.nan
                }
            }
            
            if dataSet.plotType == .BoxPlot {
                
                baseLineValue = e.y0
            }
            
            let yValue = y.isNaN ? 0 : y
            
            var yStart = baseLineValue
            
            if containsStacks || isSegment
            {
                if yValue >= baseLineValue
                {
                    yStart = value - abs(yValue)
                }
                else{
                    yStart = value + abs(yValue)
                }
            }
            
            let left = CGFloat(x - barWidthHalf)
            let right = CGFloat(x + barWidthHalf)
            var top = isInverted
                ? (value <= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value >= yStart ? CGFloat(value) : CGFloat(yStart))
            var bottom = isInverted
                ? (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value <= yStart ? CGFloat(value) : CGFloat(yStart))
            
            if barPlotOption.segmentSpacing != 0 && isSegment {
                BarChartRenderer.requriedPointFor(barSpacing: barPlotOption.segmentSpacing, yValue: yValue, baseLineValue: baseLineValue, bottom: &bottom, top: &top, chart: barLineChart, axisindex: dataSet.axisIndex)
            }
            
            if barPlotOption.stackSpacing != 0 && (bottom != baseLineValue && top != baseLineValue) && !isSegment
            {
                BarChartRenderer.requriedPointFor(barSpacing: barPlotOption.stackSpacing, yValue: yValue, baseLineValue: baseLineValue, bottom: &bottom, top: &top, chart: barLineChart, axisindex: dataSet.axisIndex)
            }
            
            if dataSet.plotType == .BoxPlot {
                
                if yValue > e.y0 {
                    baseLineValue = e.y0
                }
                else {
                    baseLineValue = y
                }
            }
            
            // multiply the height of the rect with the phase
            let topInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: top)
            top = topInterPolator(CGFloat(phaseY))
            
            let bottomInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: bottom)
            bottom = bottomInterPolator(CGFloat(phaseY))
            
            BarChartRenderer.updateBarRect(barRect: &barRect, isRotated: barLineChart.isRotated, top: top, bottom: bottom, left: left, right: right)
            
            buffer.rects[bufferIndex] = barRect
            bufferIndex += 1
        }
    }
    
    static func requriedPointFor(barSpacing: CGFloat, yValue: CGFloat, baseLineValue: CGFloat, bottom:  inout CGFloat, top: inout CGFloat, chart: ChartViewBase, axisindex: Int) {
        
        let onePointSize = CommonHelperFunctions.getOnePointSize(chart: chart, axis: chart.yAxisArray[axisindex])
        let size = chart.isRotated ? onePointSize.width : onePointSize.height
        let barHeight = size * abs(bottom - top)
        let requiredSpacing = barSpacing < barHeight ? barSpacing : barHeight * (0.8)
        let requiredPoints = (1/size) * requiredSpacing
        
        top = chart.isInverted(axisIndex: axisindex)
            ? ((yValue >= baseLineValue) ? (top + requiredPoints) : top)
            : ((yValue >= baseLineValue) ? top : (top - requiredPoints))
        
        bottom = chart.isInverted(axisIndex: axisindex)
            ? ((yValue < baseLineValue) ? (bottom - requiredPoints) : bottom)
            : ((yValue < baseLineValue) ? bottom : (bottom + requiredPoints))
        
    }
    
    
    
    public static func getBarRectArray(entries: [ChartDataEntry],animator: Animator,dataSet: IChartDataSet,chart:ChartViewBase) -> [CGRect]
    {
        var barRectArray:[CGRect] = []
        
        let typeAllowed = [ChartType.Bar, ChartType.Bullet, ChartType.BoxPlot, ChartType.Mekko]
        
        guard
            let barData = chart.data,
            let processor = chart.getProcessor(type: dataSet.plotType) as? BarPreprocessor,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
             else { return barRectArray }
        
        var barWidthHalf = (barPlotOptions.barWidth) / 2.0
        
        let viewPortHandler = chart.getPlotTransformer()._viewPortHandler
        
        let requiredSpace = chart.getTransformer(axisIndex: dataSet.axisIndex).valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft+barPlotOptions.barSpacePixel, y: 10))
        
        var bufferIndex = 0
        let containsStacks = barPlotOptions.isStacked
        
        let setIndex = barData.indexOfDataSet(dataSet)
        
        let isInverted = chart.isInverted(axisIndex: dataSet.axisIndex)
        let phaseY = animator.phaseY
        
        var baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
        var barRect = CGRect()
        
        for j in stride(from: 0, to: entries.count, by: 1)
        {
            let e = entries[j]
            
            var x: Double = e.x
            var y: Double = e.y
            
            var prevEntry = ((j-1) >= 0 && (j-1) < entries.count) ? entries[j-1] : nil
            
            var counterIndex = j-1
            
            while prevEntry != nil && (prevEntry?.x.isNaN)!
            {
                counterIndex -= 1
                prevEntry = (counterIndex >= 0 && counterIndex < entries.count) ? entries[counterIndex] : nil
            }
            
            let isSegment = (prevEntry != nil && prevEntry?.x == e.x)
            
            if dataSet.plotType == .Mekko
            {
                guard let processor = processor as? MekkoPreprocessor
                else { continue}
                
                if
                   let xString = e.xString,
                   let sizeValueStart = processor.categoryToSize[xString]?.0, let eSize = e.size {
                    barWidthHalf = ((barPlotOptions.barWidth / 2.0) - (requiredSpace.x/eSize)/2)*eSize
                    x = sizeValueStart + eSize/2
                }
               // sumX += e.size
            }
            
            guard let value = (processor.entriesStackedYValue[setIndex]?[j])
            else { return barRectArray }
            
            if barPlotOptions.stackedPercentEnabled
            {
                y = processor.positiveSum[e.x] != nil ? (e.y/processor.positiveSum[e.x]!)*100 : Double.nan
                
                if e.y < 0
                {
                    y = Double.nan
                }
            }
            
            if dataSet.plotType == .BoxPlot {
                
                baseLineValue = e.y0
            }
            
            let yValue = y.isNaN ? 0 : y
            
            var yStart = baseLineValue
            
            if containsStacks || isSegment
            {
                if yValue >= baseLineValue
                {
                    yStart = value - abs(yValue)
                }
                else{
                    yStart = value + abs(yValue)
                }
            }
            
            let left = CGFloat(x - barWidthHalf)
            let right = CGFloat(x + barWidthHalf)
            var top = isInverted
                ? (value <= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value >= yStart ? CGFloat(value) : CGFloat(yStart))
            var bottom = isInverted
                ? (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value <= yStart ? CGFloat(value) : CGFloat(yStart))
            
            if barPlotOptions.segmentSpacing != 0 && isSegment {
                requriedPointFor(barSpacing: barPlotOptions.segmentSpacing, yValue: yValue, baseLineValue: baseLineValue, bottom: &bottom, top: &top, chart: chart, axisindex: dataSet.axisIndex)
            }
            
            if barPlotOptions.stackSpacing != 0 && (bottom != baseLineValue && top != baseLineValue) && !isSegment
            {
                requriedPointFor(barSpacing: barPlotOptions.stackSpacing, yValue: yValue, baseLineValue: baseLineValue, bottom: &bottom, top: &top, chart: chart, axisindex: dataSet.axisIndex)
            }
            
            if dataSet.plotType == .BoxPlot {
                
                if yValue > e.y0 {
                    baseLineValue = e.y0
                }
                else {
                    baseLineValue = y
                }
            }
            
            // multiply the height of the rect with the phase
            let topInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: top)
            top = topInterPolator(CGFloat(phaseY))
            
            let bottomInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: bottom)
            bottom = bottomInterPolator(CGFloat(phaseY))
            
            updateBarRect(barRect: &barRect, isRotated: chart.isRotated, top: top, bottom: bottom, left: left, right: right)
            
            barRectArray.append(barRect)
            bufferIndex += 1
        }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        trans.rectValuesToPixel(&barRectArray)
        return barRectArray
    }
    
    open override func drawData(context: CGContext)
    {
        guard
            let chart = chart,
            let barData = chart.data
            else { return }
        
        BarLayer.removeAllBarLayer(chart: chart)
        
        for i in 0 ..< barData.dataSetCount
        {
            guard let set = barData.getDataSetByIndex(i) else { continue }
            
            if set.isVisible
            {
//                if !(set is IBarChartDataSet)
                if !(set.plotType == .Bar || set.plotType == .Mekko || set.plotType == .Bullet || set.plotType == .WaterFall || set.plotType == .BoxPlot || set.plotType == .HorizontalBarRange)
                {
                    continue
                }
                
                drawDataSet(context: context, dataSet: set, index: i)
            }
        }
    }
    
    fileprivate var _barShadowRectBuffer: CGRect = CGRect()
    
    open func drawDataSet(context: CGContext, dataSet: IChartDataSet, index: Int)
    {
        guard
            let chart = chart
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)

        prepareBuffer(dataSet: dataSet, index: index)
        trans.rectValuesToPixel(&_buffers[index].rects)
        
        drawRenderer(context: context, dataSet: dataSet, index: index)
        
    }
    
    open func drawRenderer(context: CGContext, dataSet: IChartDataSet, index: Int)
    {
        guard
            let chart = chart,
            let viewPortHandler = self.viewPortHandler,
            let barDataSetOption = dataSet.dataSetOptions as? BarDataSetOptions,
            let barPlotOption = chart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let borderWidth = barDataSetOption.barBorderWidth
        let borderColor = barDataSetOption.barBorderColor
        let drawBorder = borderWidth > 0.0
        
        _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
        
        context.saveGState()
        
        // draw the bar shadow before the values
        if barPlotOption.isDrawBarShadowEnabled
        {
            guard
                let animator = animator
                else { return }
            
            let barWidth = barPlotOption.barWidth
            let barWidthHalf = barWidth / 2.0
            var x: Double = 0.0
            
            for i in stride(from: 0, to: min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount), by: 1)
            {
                
                let index = i

                guard let e = dataSet.entryForIndex(index) else { continue }
                
                x = e.x
                
                if x.isNaN {
                    continue
                }
                
                if chart.isRotated {
                    _barShadowRectBuffer.origin.y = CGFloat(x - barWidthHalf)
                    _barShadowRectBuffer.size.height = CGFloat(barWidth)
                }
                else {
                    _barShadowRectBuffer.origin.x = CGFloat(x - barWidthHalf)
                    _barShadowRectBuffer.size.width = CGFloat(barWidth)
                }
                
                trans.rectValueToPixel(&_barShadowRectBuffer)
                
                /*************************** DELETE BAR HANDLED ****************************/
                
                if e.filterEnabled
                {
                    continue
                }
                
                if barDeleted
                {
                    if e.centerChanged != nil{
                        _barShadowRectBuffer.origin.x = (e.centerChanged?.x)!
                        _barShadowRectBuffer.origin.y = (e.centerChanged?.y)!
                    }
                    
                    if e.sizeChanged != nil{
                        _barShadowRectBuffer.size.width = (e.sizeChanged?.width)!
                        _barShadowRectBuffer.size.height = (e.sizeChanged?.height)!
                    }
                }
                
                /*************************** DELETE BAR HANDLED ****************************/
                
                if !isInStartOfBound(isRotated: chart.isRotated, rect: _barShadowRectBuffer) {
                    continue
                }
                
                if !isInEndOfBound(isRotated: chart.isRotated, rect: _barShadowRectBuffer) {
                    break
                }
                
                if chart.isRotated {
                    _barShadowRectBuffer.origin.x = viewPortHandler.contentLeft
                    _barShadowRectBuffer.size.width = viewPortHandler.contentWidth
                }
                else {
                    _barShadowRectBuffer.origin.y = viewPortHandler.contentTop
                    _barShadowRectBuffer.size.height = viewPortHandler.contentHeight
                }
                
                context.setFillColor(barDataSetOption.barShadowColor.cgColor)
                context.fill(_barShadowRectBuffer)
            }
        }
        
        let buffer = _buffers[index]
        /*
        // draw the bar shadow before the values
        if barPlotOption.isDrawBarShadowEnabled
        {
            for j in stride(from: 0, to: buffer.rects.count, by: 1)
            {
                var barRect = buffer.rects[j]
                
                let index = j

                /*************************** DELETE BAR HANDLED ****************************/
                
                //                guard let e = dataSet.entryForIndex(j) else { continue }
                guard let e = dataSet.entryForIndex(index) else { continue }
                
                if e.filterEnabled
                {
                    continue
                }
                
                if barDeleted
                {
                    if e.centerChanged != nil{
                        barRect.origin.x = (e.centerChanged?.x)!
                        barRect.origin.y = (e.centerChanged?.y)!
                    }
                    
                    if e.sizeChanged != nil{
                        barRect.size.width = (e.sizeChanged?.width)!
                        barRect.size.height = (e.sizeChanged?.height)!
                    }
                }
                
                /*************************** DELETE BAR HANDLED ****************************/
                
                
                if (!viewPortHandler.isInBoundsLeft(barRect.origin.x + barRect.size.width))
                {
                    if (chart.xAxis.isInverted)
                    {
                        continue//break
                    }
                    else
                    {
                        continue
                    }
                }
                
                if (!viewPortHandler.isInBoundsRight(barRect.origin.x))
                {
                    if (chart.xAxis.isInverted)
                    {
                        break//continue
                    }
                    else
                    {
                        break
                    }
                }
                
                context.setFillColor(barDataSetOption.barShadowColor.cgColor)
                context.fill(barRect)
            }
        }
        */
        let isSingleColor = dataSet.colors.count == 1
        
        if isSingleColor
        {
            context.setFillColor(dataSet.color(atIndex: 0).cgColor)
        }
        
        let isXReverse = (chart.xAxis.isInverted)
        
        for j in stride(from: 0, to: buffer.rects.count, by: 1)
        {
            var barRect = buffer.rects[j]
            
            var index = j
            
            if (isXReverse) {
                index = (buffer.rects.count - 1 - j )
            }
            
            let includeLevelLayers = true
            
            let includeTargetLayer = true
            
            /*if isStackedBar
            {
                var tempJ = j
                if (isXReverse) {
                    tempJ = (buffer.rects.count - 1 - j )
                }
                index = tempJ / yValsCount
                
                includeTargetLayer = false
                
                if tempJ % yValsCount != 0
                {
                    includeLevelLayers = false
                }
                
                if tempJ % yValsCount == yValsCount - 1
                {
                    includeTargetLayer = true
                }
               /* index = j / yValsCount
                
                includeTargetLayer = false
                
                if j % yValsCount != 0
                {
                    includeLevelLayers = false
                }
                
                if j % yValsCount == yValsCount - 1
                {
                    includeTargetLayer = true
                }*/
            }*/
          
            guard let e = dataSet.entryForIndex(index)  else { continue }
            
            /*************************** X NAN HANDLED ****************************/
            if (e.xString == nil && chart.xAxis.scaleType == .Ordinal) || e.x == Double.nan {
                continue
            }
            
            /*************************** DELETE BAR HANDLED ****************************/
            
            if e.filterEnabled
            {
                continue
            }
            
            if barDeleted
            {
                if e.centerChanged != nil{
                    barRect.origin.x = (e.centerChanged?.x)!
                    barRect.origin.y = (e.centerChanged?.y)!
                }
                
                if e.sizeChanged != nil{
                    barRect.size.width = (e.sizeChanged?.width)!
                    barRect.size.height = (e.sizeChanged?.height)!
                }
            }
            
            if e.isIncluded
            {
                let baseValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
                
                if e.y > baseValue
                {
                    if e.sizeChanged != nil{
                        if chart.isRotated {
                            barRect.size.width =  (e.sizeChanged?.width)!
                        }
                        else {
                            barRect.size.height =  (e.sizeChanged?.height)!
                            barRect.origin.y = (e.barYValue)
                        }
                    }
                }
                else{
                    if e.sizeChanged != nil{
                        if chart.isRotated {
                            barRect.size.width =  (e.sizeChanged?.width)!
                            barRect.origin.x = (e.barYValue)
                        }
                        else {
                            barRect.size.height = (e.sizeChanged?.height)!
                        }
                    }
                }
                
            }
            
            /*************************** DELETE BAR HANDLED ****************************/
            
            if !isInStartOfBound(isRotated: chart.isRotated, rect: barRect) {
                continue
            }
            
            if !isInEndOfBound(isRotated: chart.isRotated, rect: barRect) {
                break
            }
            
            if !(chart.includeLayer)
            {
                //Commented out to draw the bars in Layer
                if !isSingleColor
                {
                    // Set the color for the currently drawn value. If the index is out of bounds, reuse colors.
                    context.setFillColor(dataSet.color(atIndex: j).cgColor)
                }
                
                context.fill(barRect)
                
                if drawBorder
                {
                    context.setStrokeColor(borderColor.cgColor)
                    context.setLineWidth(borderWidth)
                    context.stroke(barRect)
                }
                
            }
            else
            {

                let barLayer = BarLayer(chartView: chart, chartEntry: e, dataSet: dataSet, barRect: barRect, barRectIndex: j)
                
                if customOpacity {
                    barLayer.opacity = e.opacityChanged
                }

                var maxBarRect = barRect
                
                if (dataSet.plotType == .Bullet) && includeLevelLayers
                {
                    let baseLineValue:Double = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
                    let isInverted = chart.isInverted(axisIndex: dataSet.axisIndex)
                    
                    let isSingleColor = barDataSetOption.levelMarkerColors.count == 1
                    
                    let levelColorEntryIndex:Int
                    
                    if isSingleColor
                    {
                        levelColorEntryIndex = 0
                    }
                    else{
                        levelColorEntryIndex = (chart.data?.dataSets[0].entryIndex(entry: e)) ?? 0
                    }
                    
                    let levelWidthHalf = (barPlotOption.levelMarkerWidth)/2
                    
                    
                    guard var eLevelMarkers = e.levelMarker
                    else { return }
                    
                    eLevelMarkers = eLevelMarkers.sorted(by: { $0 < $1 })
                    
                    let baseValues = BarHelperFunctions.prepareBaseValueForLevelMarker(levelValues: eLevelMarkers, basevalue: baseLineValue)
                    
                    for index in 0..<eLevelMarkers.count
                    {
                        guard let level = eLevelMarkers[safe:index], let baseValue = baseValues[safe:index] else {
                            continue
                        }
                        
                        let levelIndex = ((eLevelMarkers.lastIndex(of: level)) ?? 0) % barDataSetOption.levelMarkerColors[levelColorEntryIndex].count
                        
                        let levelTop = isInverted
                            ? (level <= baseValue ? CGFloat(level) : CGFloat(baseValue))
                            : (level >= baseValue ? CGFloat(level) : CGFloat(baseValue))
                        
                        let levelBottom = isInverted
                            ? (level >= baseValue ? CGFloat(level) : CGFloat(baseValue))
                            : (level <= baseValue ? CGFloat(level) : CGFloat(baseValue))
                        
                        let levelLeft = CGFloat(e.x - levelWidthHalf)
                        
                        let levelRight = CGFloat(e.x + levelWidthHalf)
                        
                        var levelRect = CGRect()
                        
                        BarChartRenderer.updateBarRect(barRect: &levelRect, isRotated: chart.isRotated, top: levelTop, bottom: levelBottom, left: levelLeft, right: levelRight)
                        
                        trans.rectValueToPixel(&levelRect)
                        
                        if !chart.isRotated && maxBarRect.width < levelRect.width || chart.isRotated && maxBarRect.height < levelRect.height {
                            maxBarRect = levelRect
                        }
                        
                        let levelLayer = LevelLayer(chartView: chart, chartEntry: e, dataSet: dataSet, barRect: levelRect, barRectIndex: j)
                        
                        levelLayer.levelValue = level
                        
                        levelLayer.fillColor = barDataSetOption.levelMarkerColors[levelColorEntryIndex][levelIndex].cgColor
                        
                        chart.plotView?.nsuiLayer?.addSublayer(levelLayer)
                        
                    }
                }
                
                chart.plotView?.nsuiLayer?.addSublayer(barLayer)
                
                if e.targetMarker != nil && includeTargetLayer
                {
                    let targetLayer = CAShapeLayer()
                   
                    let shapeProp =  barDataSetOption.targetMarkerShapeProperties
                    
                    var point = chart.pixelForValues(isRotated: chart.isRotated, x: e.x, y: e.targetMarker!, axisIndex: dataSet.axisIndex)
                    
                    _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProp, point: point, strokeColor: (shapeProp.strokeColor?.cgColor) ?? NSUIColor.black.cgColor, currentLayer: targetLayer)
                    
                    chart.plotView?.nsuiLayer?.addSublayer(targetLayer)
                    
                    if barPlotOption.targetLabelConfig.enabled {
                        
                        let textLayer = ValueTextLayer()
                        
                        let text = barPlotOption.targetLabelConfig.formatter.getFormattedTextforValue?(value: e.targetMarker!, type: .targetValue, data: nil) ?? String(e.targetMarker!)
                        
                        let textSize = text.size(withAttributes: barPlotOption.targetLabelConfig.AttributedString)
                        
                        if chart.isRotated {
                            if barPlotOption.targetLabelConfig.labelVerticalAlignment == .top {
                                point.y = maxBarRect.minY
                            }
                            
                            if barPlotOption.targetLabelConfig.labelVerticalAlignment == .bottom {
                                point.y = maxBarRect.maxY
                            }
                        }
                        else {
                            
                            if barPlotOption.targetLabelConfig.labelHorizontalAlignment == .left {
                                point.x = maxBarRect.minX
                            }
                            
                            if barPlotOption.targetLabelConfig.labelHorizontalAlignment == .right {
                                point.x = maxBarRect.maxX
                            }
                        }
                        
                        switch barPlotOption.targetLabelConfig.labelHorizontalAlignment {
                        case .none,.right:
                            break
                        case .center:
                            point.x -= textSize.width / 2.0
                        case .left:
                            point.x -= textSize.width
                        }
                        
                        switch barPlotOption.targetLabelConfig.labelVerticalAlignment {
                        case .none,.bottom:
                            break
                        case .center:
                            point.y -= textSize.height / 2.0
                        case .top:
                            point.y -= textSize.height
                        }
                        
                        point.x += barPlotOption.targetLabelConfig.xOffset
                        point.y += barPlotOption.targetLabelConfig.yOffset
                        
                        let layer = ChartUtils.drawTextLayer(text: text, point: point, align: .right, attributes: barPlotOption.targetLabelConfig.AttributedString)
                        
                        layer.backgroundColor = NSUIColor.gray.withAlphaComponent(0.4).cgColor
                        layer.borderColor = NSUIColor.black.cgColor
                        layer.borderWidth = 1.0
                        
                        textLayer.addSublayer(layer)
                                        
                        chart.nsuiLayer?.addSublayer(textLayer)
                    }
                }
                
                
            }
            
      
        }
        
        
        context.restoreGState()
    }
    
    open func prepareBarHighlight(
        x: Double,
          y1: Double,
          y2: Double,
          barWidthHalf: Double,
          trans: Transformer,
          rect: inout CGRect)
    {
        let left = x - barWidthHalf
        let right = x + barWidthHalf
        let top = y1
        let bottom = y2
        
        rect.origin.x = CGFloat(left)
        rect.origin.y = CGFloat(top)
        rect.size.width = CGFloat(right - left)
        rect.size.height = CGFloat(bottom - top)
        
        trans.rectValueToPixel(&rect, phaseY: animator?.phaseY ?? 1.0)
    }

    open override func drawValues(context: CGContext)
    {
        guard
        let chart = chart,
        let viewPortHandler = chart.viewPortHandler,
        let barPlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions,
        let barData = chart.data,
        let animator = animator,
        let processor = CommonHelperFunctions.getProcessor(chart: chart, types: typeAllowed)
        else { return }
         
         for dataSetIndex in 0 ..< barData.dataSetCount
         {
             let dataSet = barData.dataSets[dataSetIndex]
             
             guard let labelRectsforDataSet = chart.labelRectIndexMap[dataSetIndex], dataSet.isVisible, BarHelperFunctions.typeAllowed.contains( where: {$0 == dataSet.plotType}) else  {
                 continue
             }
             
             let xAxisInverted = (chart.xAxis.inverted)
             
             guard let formatter = dataSet.valueFormatter else { continue }
             
             var start = 0
             var end =  ChartUtils.doubleToIntSafeCast(value:ceil(Double(dataSet.entryCount) * animator.phaseX))
             var increment = 1
             
             if (xAxisInverted) {
                 start = dataSet.entryCount - 1
                 end = dataSet.entryCount - (Int(ceil(Double(dataSet.entryCount) * animator.phaseX))) - 1
                 increment = -1
             }
             
             let buffer = _buffers[dataSetIndex]
             
             if !dataSet.drawValuesEnabled && !barPlotOption.stackedPercentEnabled && !((barPlotOption as? BoxPlotPlotOptions)?.medianEnabled ?? false) && !((barPlotOption as? BoxPlotPlotOptions)?.whiskersEnabled ?? false) {
                 continue
             }
             
             for j in stride(from: start, to: end, by: increment) {
                 guard let e = dataSet.entryForIndex(j), let labelRectDict = labelRectsforDataSet[j], !e.y.isNaN else { continue }
                 
                 if barPlotOption.stackedPercentEnabled && e.y < 0 {
                     continue
                 }
                 
                 var bufferIndex = j
                 
                 if (xAxisInverted) {
                     bufferIndex = buffer.rects.count - 1 - j
                 }
                 
                 let rect = buffer.rects[bufferIndex]
                 let originPoint = CGPoint(x: rect.midX, y: rect.midY)
                 
                 if let allowed = isInBounds(viewPortHandler: chart.viewPortHandler,originPoint: originPoint) {
                     if allowed == 1 {
                         continue
                     }
                     else {
                         break
                     }
                 }
                 
                 if dataSet.isDrawValuesEnabled {
                     if var labelRect = labelRectDict["y"] {
                         
                         labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                         
                         var entryY = e.y
                         
                         if let processor = processor as? BarPreprocessor, barPlotOption.stackedPercentEnabled {
                             entryY = processor.positiveSum[e.x] != nil ? (entryY/processor.positiveSum[e.x]!)*100 :  entryY
                         }
                         
                         let label = formatter.stringForValue(
                            entryY,
                            entry: e,
                            dataSetIndex: dataSetIndex,
                            viewPortHandler: viewPortHandler)
                         
                         let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(j)]
                         
                         drawLabel(chart: chart, label: label, labelAttributes: attributes, labelRect: labelRect)
                     }
                     
                     if var labelRect = labelRectDict["y0"] {
                         
                         labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                         
                         let label = formatter.stringForValue(
                            e.y0,
                            entry: e,
                            dataSetIndex: dataSetIndex,
                            viewPortHandler: viewPortHandler)
                         
                         let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(j)]
                         
                         drawLabel(chart: chart, label: label, labelAttributes: attributes, labelRect: labelRect)
                     }
                 }
                 
                 if let boxPlotPlotOption = barPlotOption as? BoxPlotPlotOptions, let plotData = e.plotData as? [Double] {
                     
                     if var labelRect = labelRectDict["median"], let medianVal = plotData[safe:boxPlotPlotOption.medianIndex], !medianVal.isNaN {
                         
                         labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                         
                         let medianValueText = boxPlotPlotOption.medianValueFormatter.getFormattedValue?(medianValue: medianVal) ?? String(medianVal)
                         
                         let attributes = [NSAttributedString.Key.font: boxPlotPlotOption.medianValueFont, NSAttributedString.Key.foregroundColor: boxPlotPlotOption.medianValueTextColor]
                         
                         drawLabel(chart: chart, label: medianValueText, labelAttributes: attributes, labelRect: labelRect)
                     }
                     
                     if var labelRect = labelRectDict["minWhiskers"], let minWhiskersVal = plotData[safe:boxPlotPlotOption.minWhiskersIndex], !minWhiskersVal.isNaN {
                         
                         labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                             
                         let minWhiskersValueText = boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: minWhiskersVal) ?? String(minWhiskersVal)
                         
                         let attributes = [NSAttributedString.Key.font: boxPlotPlotOption.whiskersValueFont, NSAttributedString.Key.foregroundColor: boxPlotPlotOption.whiskersValueTextColor]
                         
                         drawLabel(chart: chart, label: minWhiskersValueText, labelAttributes: attributes, labelRect: labelRect)
                     }
                     
                     if var labelRect = labelRectDict["maxWhiskers"], let maxWhiskersVal = plotData[safe:boxPlotPlotOption.maxWhiskersIndex], !maxWhiskersVal.isNaN {
                         
                         labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                         
                         let maxWhiskersValueText = boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: maxWhiskersVal) ?? String(maxWhiskersVal)
                         
                         let attributes = [NSAttributedString.Key.font: boxPlotPlotOption.whiskersValueFont, NSAttributedString.Key.foregroundColor: boxPlotPlotOption.whiskersValueTextColor]
                         
                         drawLabel(chart: chart, label: maxWhiskersValueText, labelAttributes: attributes, labelRect: labelRect)
                     }
                 }
             }
         }
        
        if barPlotOption.isStacked && barPlotOption.isStackedSumEnabled {
            
            let attributes = [NSAttributedString.Key.font: barPlotOption.stackSumValueFont, NSAttributedString.Key.foregroundColor: barPlotOption.stackSumValueTextColor]
                
            for xValue in chart.labelRectIndexForStackedSum.keys.sorted() {
                
                let originPoint = chart.pixelForValues(isRotated: chart.isRotated, x: xValue, y: 0.0, axisIndex: 0)
                
                if let allowed = isInBounds(viewPortHandler: chart.viewPortHandler, originPoint: originPoint) {
                    if allowed == 1 {
                        continue
                    }
                    else {
                        break
                    }
                }
                    
                if let labelProperties = chart.labelRectIndexForStackedSum[xValue] as? [LabelProperties] {
                    
                    for index in 0..<labelProperties.count {
                        
                        let currentLabelProp = labelProperties[index]
                        
                        var labelRectProp = LabelProperties(value: currentLabelProp.value, rect: currentLabelProp.rect, axisIndex: currentLabelProp.axisIndex)
                        
                        labelRectProp.formattedLabel = currentLabelProp.formattedLabel
                        
                        labelRectProp.rect.origin = chart.pixelForValues(point: currentLabelProp.rect.origin, axisIndex: currentLabelProp.axisIndex)
                        
                        drawLabel(chart: chart, labelProperties: labelRectProp, attributes: attributes)
                    }
                }
            }
        }
    }
    
    /// Draws a value at the specified x and y position.
    open func drawValue(context: CGContext, value: String, xPos: CGFloat, yPos: CGFloat, font: NSUIFont, align: NSTextAlignment, color: NSUIColor, constrainedWidth: CGFloat)
    {
        guard let chart = chart
        else { return }
        
        if !(chart.includeLayer)
        {
            ChartUtils.drawText(context: context, text: value, point: CGPoint(x: xPos, y: yPos), align: align, attributes: [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: color], constrainedWidth: constrainedWidth)
        }
        else
        {
            let layer = ChartUtils.drawTextLayer(text: value, point: CGPoint(x: xPos, y: yPos), align: align, attributes: [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: color], constrainedToWidth: constrainedWidth, truncationMode: .end)
            
            chart.plotView?.nsuiLayer?.addSublayer(layer)
        }
    }
    
    open override func drawExtras(context: CGContext)
    {
        
    }
    
    open override func drawHighlighted(context: CGContext, indices: [Highlight])
    {
        guard
            let barChartView = chart,
            let barData = barChartView.data,
            let processor = barChartView.getProcessor(type: .Bar) as? BarPreprocessor,
            let barPlotOption = CommonHelperFunctions.getPlotOption(chart: barChartView, types: typeAllowed) as? BarPlotOptions
            else { return }
        
        context.saveGState()
        
        var barRect = CGRect()
        
        for high in indices
        {
            guard
                let set = barData.getDataSetByIndex(high.dataSetIndex),
                set.isHighlightEnabled,
                let barDataSetOption = set.dataSetOptions as? BarDataSetOptions
                else { continue }
            
            if let e = set.entryForXValue(high.x, closestToY: high.y)
            {
                if !isInBoundsX(entry: e, dataSet: set)
                {
                    continue
                }
                
                let trans = barChartView.getTransformer(axisIndex: set.axisIndex)
                
                context.setFillColor(barDataSetOption.highlightColor.cgColor)
                context.setAlpha(barDataSetOption.highlightAlpha)
                
                let isStack = high.stackIndex >= 0 //&& e.isStacked
                
                let y1: Double
                let y2: Double
                
                let entryIndex = set.entryIndex(entry: e)
                
                if isStack
                {
                     guard let value = (processor.entriesStackedYValue[high.dataSetIndex]?[entryIndex])
                    else { continue }
                    
                     y1 = value
                     y2 = y1 - e.y
                
                    /*if dataProvider.isHighlightFullBarEnabled
                    {
                        y1 = e.positiveSum
                        y2 = -e.negativeSum
                    }
                    else
                    {
                        let range = e.ranges?[high.stackIndex]
                        
                        y1 = range?.from ?? 0.0
                        y2 = range?.to ?? 0.0
                    } */
                }
                else
                {
                    y1 = e.y
                    y2 = 0.0
                }
                
                prepareBarHighlight(x: e.x, y1: y1, y2: y2, barWidthHalf: barPlotOption.barWidth / 2.0, trans: trans, rect: &barRect)
                
                setHighlightDrawPos(highlight: high, barRect: barRect)
                
                context.fill(barRect)
            }
        }
        
        context.restoreGState()
    }
    
    /// Sets the drawing position of the highlight object based on the riven bar-rect.
    internal func setHighlightDrawPos(highlight high: Highlight, barRect: CGRect)
    {
        high.setDraw(x: barRect.midX, y: barRect.origin.y)
    }
    
    static func updateBarRect(barRect: inout CGRect,isRotated: Bool,top: Double,bottom: Double,left: Double, right: Double) {
        if isRotated {
            barRect.origin.x = bottom
            barRect.size.width = top - bottom
            barRect.origin.y = right
            barRect.size.height = left - right
        }
        else {
            barRect.origin.x = left
            barRect.size.width = right - left
            barRect.origin.y = top
            barRect.size.height = bottom - top
        }
    }
    
    override internal func isInBounds(viewPortHandler: ViewPortHandler, originPoint: CGPoint) -> Int? {
        
        guard let chart = chart else {
            return nil
        }
        
        let rect = CGRect(origin: CGPoint(x: originPoint.x - chart.longestDatalabelSize.width / 2.0, y: originPoint.y - chart.longestDatalabelSize.height / 2.0), size: chart.longestDatalabelSize)
        
        if viewPortHandler.contentRect.intersects(rect) {
            return nil
        }
        else if !viewPortHandler.isInBoundsRight(rect.minX) && !viewPortHandler.isInBoundsRight(rect.maxX) && !chart.isRotated || !viewPortHandler.isInBoundsBottom(rect.minY) && !viewPortHandler.isInBoundsBottom(rect.maxY) && chart.isRotated {
            return 0
        }
        else if !viewPortHandler.isInBoundsLeft(rect.minX) && !viewPortHandler.isInBoundsLeft(rect.maxX) && !chart.isRotated || !viewPortHandler.isInBoundsTop(rect.minY) && !viewPortHandler.isInBoundsTop(rect.maxY) && chart.isRotated {
            return 1
        }
        
        return nil
    }
}

extension BarChartRenderer {
    
    func isInStartOfBound(isRotated: Bool, rect: CGRect) -> Bool {
        
        guard let viewPortHandler = viewPortHandler else {
            return false
        }
        
        return isRotated ? viewPortHandler.isInBoundsTop(rect.origin.y + rect.size.height) : viewPortHandler.isInBoundsLeft(rect.origin.x + rect.size.width)
    }
    
    func isInEndOfBound(isRotated: Bool, rect: CGRect) -> Bool {
        
        guard let viewPortHandler = viewPortHandler else {
            return false
        }
        
        return isRotated ? viewPortHandler.isInBoundsBottom(rect.origin.y) : viewPortHandler.isInBoundsRight(rect.origin.x)
    }
}
