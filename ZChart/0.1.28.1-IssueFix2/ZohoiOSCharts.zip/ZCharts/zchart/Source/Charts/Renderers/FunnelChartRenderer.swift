//
//  FunnelChartRenderer.swift
//  zchart
//
//  Created by Aravinth T on 04/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//


import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


open class FunnelChartRenderer: DataRenderer
{
    public static let textLayerKey = "ENTRYINDEX"
    
    let numberFormatter = NumberFormatter()
    
    open override func drawData(context: CGContext) {
     
        guard let chart = chart else { return }
        
        FunnelLayer.removeAllFunnelLayer(chart: chart)
        
        guard let funnelData = chart.data,
              let funnelSets = funnelData.dataSets as? [ChartDataSet]
        else { return}
        
        
        for set in funnelSets
        {
            if set.isVisible && set.entryCount > 0
            {
                drawDataSet(context: context, dataSet: set)
            }
        }
        
    }
    
    open func drawDataSet(context: CGContext, dataSet: ChartDataSet)
    {
        guard
            let chart = chart
             else {return }
        
      /*  let entries = dataSet.values as! [ChartDataEntry]
        
        let allowedEntries = FunnelChartRenderer.getValidEntries(entries: entries)
        
        var entryPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
        if chart.funnelWeightedType == .Width {
            entryPointMap = FunnelChartRenderer.preparePointsForWidthWeightage(entries: allowedEntries, chart: chart)
        }else {
            entryPointMap = FunnelChartRenderer.preparePointsForHeightWeightage(entries: allowedEntries, chart: chart)
        }
        */
        
        let entryPointMap = FunnelChartRenderer.getEntryPointMap(dataSet: dataSet, chart: chart)
        
        let entries = dataSet.values
        
        let allowedEntries = FunnelChartRenderer.getValidEntries(entries: entries)
        
        for entry in allowedEntries {
            guard let funnelSlicePoint = entryPointMap[entry]
            else { continue }
            let _ = FunnelLayer(chartView: chart, chartEntry: entry, funnelSlicePoint: funnelSlicePoint)
        }
        
    }
    
  
    
    open override func drawValues(context: CGContext) {
        
        guard let chart = chart else { return }
        
        FunnelLayer.removeAllFunnelValueLayer(chart: chart)
        
        guard let funnelData = chart.data,
              let funnelSets = funnelData.dataSets as? [ChartDataSet]
        else { return}
        
        
        for set in funnelSets
        {
            if set.isVisible && set.entryCount > 0 && set.drawValuesEnabled
            {
                drawValueForDataSet(context: context, dataSet: set)
            }
        }
        
    }
    
    override open func drawExtras(context: CGContext) {
        return
    }
    
    open func drawValueForDataSet(context: CGContext, dataSet: ChartDataSet)
    {
        guard
            let chart = chart
            else {return }
        
        let entries = dataSet.values
        
        let allowedEntries = FunnelChartRenderer.getValidEntries(entries: entries)
        
//        var entryPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
//        if chart.funnelWeightedType == .Width {
//            entryPointMap = FunnelChartRenderer.preparePointsForWidthWeightage(entries: allowedEntries, chart: chart)
//        }else {
//            entryPointMap = FunnelChartRenderer.preparePointsForHeightWeightage(entries: allowedEntries, chart: chart)
//        }
        
        let entryPointMap = FunnelChartRenderer.getEntryPointMap(dataSet: dataSet, chart: chart)
        
        let ySum = FunnelChartRenderer.getSumOfValues(entries: allowedEntries)
        
        for entry in allowedEntries {
            
            guard let funnelSlicePoint = entryPointMap[entry]
            else { continue }
            
            drawTextLayer(dataSet: dataSet, funnelSlicePoint: funnelSlicePoint, entry: entry, ySum: ySum)
            
        }
        
    }
    
    
    public static func getEntryPointMap (dataSet:ChartDataSet, chart:ChartViewBase) -> [ChartDataEntry:FunnelSlicePoint] {
        
        var entryPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
        guard let funnelPlotOptions = chart.getPlotOptions(type: .Funnel) as? FunnelPlotOptions
            else { return entryPointMap }
        
        let entries = dataSet.values
        
        let allowedEntries = FunnelChartRenderer.getValidEntries(entries: entries)
        
        if funnelPlotOptions.funnelWeightedType == .Width {
            entryPointMap = FunnelChartRenderer.preparePointsForWidthWeightage(entries: allowedEntries, chart: chart)
        }else {
//            entryPointMap = FunnelChartRenderer.preparePointsForHeightWeightage(entries: allowedEntries, chart: chart)
            entryPointMap = FunnelChartRenderer.preparePointsForHeightType(entries: allowedEntries, chart: chart)
        }
        
        return entryPointMap
    }
    
    public static func getValidEntries(entries: [ChartDataEntry]) -> [ChartDataEntry] {
        
        var allowedEntries:[ChartDataEntry] = []
        
        for entry in entries {
            if entry.enabled {
                allowedEntries.append(entry)
            }
        }
        
        return allowedEntries
    }

    static func getEndPointsForFunnelSlicePoint(funnelSlicePoint: FunnelSlicePoint) -> [CGPoint] {
        
        let points = funnelSlicePoint.points
        
        var endPoints:[CGPoint] = []
        
        endPoints.append(points[0])
        endPoints.append(points[1])
        
        if points.count == 6 {
            endPoints.append(points[3])
            endPoints.append(points[4])
        } else if points.count == 4 {
            endPoints.append(points[2])
            endPoints.append(points[3])
        }
        
       return endPoints
    }
    
    static func getCenterPoint(funnelSlicePoint: FunnelSlicePoint) -> CGPoint {
        
        let midY = getMidY(funnelSlicePoint: funnelSlicePoint)
        
        let (x1,x2) = getMidXEnds(funnelSlicePoint: funnelSlicePoint)
        
        let midX = (x1 + x2) / 2
        
        return CGPoint(x: midX, y: midY)
    }
    
    static func getMidY(funnelSlicePoint: FunnelSlicePoint) -> CGFloat {
        
        let (startY,endY) = getStartYEndYForFunnelSlicePoint(funnelSlicePoint: funnelSlicePoint)
        
        return ((startY + endY) / 2)
    }
    
    
    static func getMidXEnds(funnelSlicePoint: FunnelSlicePoint) -> (CGFloat, CGFloat) {
        
        let endPoints = getEndPointsForFunnelSlicePoint(funnelSlicePoint: funnelSlicePoint)
        
        let originalPoints = funnelSlicePoint.points
        
        var leftMid = ( endPoints[0].x + endPoints[3].x ) / 2
        
        var rightMid = ( endPoints[1].x + endPoints[2].x ) / 2
        
        if originalPoints.count == 6 {
            
            let midY = getMidY(funnelSlicePoint: funnelSlicePoint)
            
            let stemY = originalPoints[2].y
            
            if stemY <= midY {
                leftMid = ( originalPoints[0].x + originalPoints[5].x ) / 2
                rightMid = ( originalPoints[1].x + originalPoints[2].x ) / 2
            }
        }
        
        return (leftMid, rightMid)
        
    }
    
    
    
    
   static func getStartYEndYForFunnelSlicePoint(funnelSlicePoint: FunnelSlicePoint) -> (CGFloat, CGFloat) {
        
        let endPoints = getEndPointsForFunnelSlicePoint(funnelSlicePoint: funnelSlicePoint)
        
        let startY = endPoints[0].y
        
        let endY = endPoints[3].y
        
        return (startY, endY)
    }
    
    static func getStartXEndXForFunnelSlicePoint(funnelSlicePoint: FunnelSlicePoint) -> (CGFloat, CGFloat) {
        
        let endPoints = getEndPointsForFunnelSlicePoint(funnelSlicePoint: funnelSlicePoint)
        
        let startX1 = endPoints[3].x
        
        let startX2 = endPoints[2].x
        
        return (startX1, startX2)
    }
    
    static func getSliceWidthForFunnelPoint(funnelSlicePoint: FunnelSlicePoint) -> CGFloat {
        
        let (midX1,midX2) = getMidXEnds(funnelSlicePoint: funnelSlicePoint)
        
        return (midX2 - midX1)
    }
    
   static func getSliceHeightForFunnelPoint(funnelSlicePoint: FunnelSlicePoint) -> CGFloat {
        
        let (startY,endY) = getStartYEndYForFunnelSlicePoint(funnelSlicePoint: funnelSlicePoint)
        
        return (startY - endY)
    }
    
    
    func drawTextLayer(dataSet: ChartDataSet, funnelSlicePoint: FunnelSlicePoint, entry: ChartDataEntry, ySum: Double) {
        
        guard let plotOptions = chart?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
              let paraStyle = NSParagraphStyle.default.mutableCopy() as? NSMutableParagraphStyle,
              let chart = chart
            else { return }
        
        let label:String = getDataToShow(dataSet: dataSet , entry: entry, ySum: ySum)
        
        let entryIndex = dataSet.entryIndex(entry: entry)
        
        let labelMaxSize = CGSize.zero
        
        let labelFont = dataSet.valueFont
        let labelColor = dataSet.valueTextColor
        
        let labelAttrs = [NSAttributedString.Key.font: labelFont,
                          NSAttributedString.Key.foregroundColor: labelColor,
                          NSAttributedString.Key.paragraphStyle: paraStyle]
        
//        let labelAttrs = [NSAttributedStringKey.font: labelFont,
//                          NSAttributedStringKey.foregroundColor: labelColor,
//                          NSAttributedStringKey.paragraphStyle: paraStyle] as [NSAttributedStringKey : NSObject]
        
//        let midX = (self.viewPortHandler?.contentCenter.x)! //TODEL
        
        let valueString  = label as NSString
        
        var boundingRect = valueString.boundingRect(with: labelMaxSize, options: .usesLineFragmentOrigin, attributes: labelAttrs, context: nil)
        
        boundingRect.size.width = boundingRect.size.width + 5
        
//        let midY = (startY + endY) / 2 //TODEL
//        let midY = getMidY(funnelSlicePoint: funnelSlicePoint)
        
//        var position = CGPoint(x: midX, y: midY) //TODEL
        
        let position = FunnelChartRenderer.getCenterPoint(funnelSlicePoint: funnelSlicePoint)
        
        var (midX1,midX2) = FunnelChartRenderer.getMidXEnds(funnelSlicePoint: funnelSlicePoint)
        
        let midY = FunnelChartRenderer.getMidY(funnelSlicePoint: funnelSlicePoint) - (boundingRect.height/2)
        
        if  plotOptions.funnelWeightedType == FunnelWeightedType.Height && !(midY > ( (chart.viewPortHandler.contentBottom) - (plotOptions.stemHeight)))
        {
            midX1 += boundingRect.height/2
            midX2 -= boundingRect.height/2
        }
    
        let barWidth = (midX2 - midX1)
        let barHeight = FunnelChartRenderer.getSliceHeightForFunnelPoint(funnelSlicePoint: funnelSlicePoint)
     
        if boundingRect.width > barWidth || boundingRect.height > barHeight {
            Log.info("Ignoring label draw ")
            return
        }
        
/*      //TODRAWLABEL OUTSIDE
        let (midX1, midX2) = getMidXEnds(funnelSlicePoint: funnelSlicePoint)
        

        let barWidth = getSliceWidthForFunnelPoint(funnelSlicePoint: funnelSlicePoint)
        let barHeight = getSliceHeightForFunnelPoint(funnelSlicePoint: funnelSlicePoint)
       
//        position.x =  ( midX1) + (boundingRect.size.width / 2) + 5 //LEFT alignment
//         position.x =  ( midX2) - (boundingRect.size.width / 2) - 5  //RIGHT alignment
        
        var wordWrapRequired:Bool = false
        
        let outTextPadding:CGFloat = 0
         
         */
 
       /* if boundingRect.size.width > barWidth {
           
 
            let (_, startX2) = getStartXEndXForFunnelSlicePoint(funnelSlicePoint: funnelSlicePoint)
            
            let remainingWidth = (self.viewPortHandler?.contentRight)! - startX2
 
            if boundingRect.width > remainingWidth {
                
                boundingRect = valueString.boundingRect(with: CGSize(width: remainingWidth, height: 0), options: .usesLineFragmentOrigin, attributes: labelAttrs, context: nil)
                
                boundingRect.size.width = remainingWidth - outTextPadding
                
                position.x = position.x + (barWidth/2) + (remainingWidth/2)
                
                wordWrapRequired = true
                
            }
            else {
                
                position.x = position.x + (boundingRect.size.width)
            }
        } */

        let textLayer = CATextLayer()
        textLayer.setValue(entryIndex, forKey: FunnelChartRenderer.textLayerKey)
        textLayer.bounds = boundingRect
        textLayer.position = position
        textLayer.string = label
        textLayer.contentsScale = NSUIMainScreen()!.nsuiScale// UIScreen.main.scale
        textLayer.fontSize = labelFont.pointSize
        textLayer.alignmentMode = convertToCATextLayerAlignmentMode("center")
       /* if wordWrapRequired {
            textLayer.isWrapped = true
        } */
        
        let fontName = labelFont.fontName as NSString
        let cgFont = CGFont(fontName)
        textLayer.font =  cgFont
        
        textLayer.foregroundColor = labelColor.cgColor
        
        //textLayer.anchorPoint = CGPoint(x: 1.0, y: 0.5)
        
        if (chart.customAnimationInProgress) {
            textLayer.opacity = 0.0
        }
        
        self.chart?.nsuiLayer?.addSublayer(textLayer)
    }
    
    func getDataToShow(dataSet:ChartDataSet, entry:ChartDataEntry, ySum: Double) -> String {
        
        guard let plotOptions = chart?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
              let dataSetIndex = (self.chart?.data?.indexOfDataSet(dataSet)),
              let viewPort = self.viewPortHandler
        else { return ""}
        
        var label = entry.xString
        
        
        
        if plotOptions.dataToShow == .showValue {
            label = dataSet.valueFormatter?.stringForValue(entry.y, entry: entry, dataSetIndex: dataSetIndex, viewPortHandler: viewPort)
        } else if plotOptions.dataToShow == .showPercent {
            
            let value =  ((entry.y / ySum) * 100.0)
            let number = NSNumber(floatLiteral: value)
            label = (numberFormatter.string(from: number) ?? "") + "%"
        }
        else {
            label = dataSet.valueFormatter?.getFormattedValue(entry:entry)
        }
        
        if label == nil {
            label = String(entry.y)
        }
        
        return label!
    }
    
    public static func preparePointsForWidthWeightage(entries: [ChartDataEntry], chart:ChartViewBase?) -> [ChartDataEntry:FunnelSlicePoint] {
        
        var entryPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
        guard let plotOptions = chart?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
              let viewPortHandler = chart?.viewPortHandler
        else { return entryPointMap }
        
        let totalHeight = (viewPortHandler.contentHeight)
        
        let totalWidth = (viewPortHandler.contentWidth)
        
        var index = 0
        
        let midX = (viewPortHandler.contentCenter.x)
        
        var topValue = (viewPortHandler.contentTop)
        
        let interSpace = (plotOptions.interSliceSpacing)
        
//        var finalValues = entries
        
        let maximumValue = getMaxValue(entries: entries)
        
//        if reverseDirection {
//            finalValues = getReversedArrayValues()
//        }
        var iterationIndex:Int = 0
        var count:Int = 0
        var invalidEntryCount:Int = 0
        
        for entry in entries {
            if !entry.y.isNaN && entry.y != 0 {
                count = count + 1
            }
        }
        
//        var sliceHeight = Double(totalHeight) / Double(entries.count)//BeforeNAN
        var sliceHeight = Double(totalHeight) / Double(count)

        if plotOptions.maxSliceHeight != 0 && CGFloat(sliceHeight) > plotOptions.maxSliceHeight {
            
            let diff =  CGFloat(sliceHeight) - plotOptions.maxSliceHeight
            topValue = topValue + (CGFloat(count) * (diff / 2))
//            topValue = topValue + (CGFloat(entries.count) * (diff / 2))//BeforeNAN
            
           sliceHeight = Double(plotOptions.maxSliceHeight)
            
        }
        
        guard let phaseY = chart?._animator.phaseY
        else { return entryPointMap }
        
        for entry in entries {
            
//            let value = entry.value//BeforeNAN
            var value = entry.y
            
            value = getValueForNaN(value: value)
            
            index = ( iterationIndex - invalidEntryCount ) < 0 ? 0 : (iterationIndex - invalidEntryCount)
            
            value = abs(value)
            
            var cgPoints:[CGPoint] = []
            
            //value percent of total width
//            let widthForValue = ((value / maximumValue) * Double(totalWidth))
            var widthForValue = ((value / maximumValue) * Double(totalWidth))
            widthForValue = getValueForNaN(value: widthForValue)
            
            
//            let startY = ((CGFloat(sliceHeight * Double(index))) + (index == 0 ? 0 : (interSpace/2)) + (topValue))
//
//            let endY = (CGFloat((sliceHeight * Double(index)) + sliceHeight) - (index == (entries.count - 1) ? 0 : (interSpace/2)) + topValue)
            
            let tempStartY = ((CGFloat(sliceHeight * Double(index))) + (topValue))
//            let startY = ((CGFloat(sliceHeight * Double(index))) + (topValue))
            
            let endY = (CGFloat((sliceHeight * Double(index)) + sliceHeight) - ((interSpace)) + topValue)
            
            let diff = (endY - tempStartY)
            
            let startY = endY - (diff * CGFloat(phaseY)) //((CGFloat(sliceHeight * Double(index))) + (topValue))
 
            let startX = CGFloat(Double(midX) - (widthForValue/2))
            let endX = CGFloat(Double(midX) + (widthForValue/2))
            
            cgPoints.append(CGPoint(x: startX, y: endY))
            cgPoints.append(CGPoint(x: endX, y: endY))
            cgPoints.append(CGPoint(x: endX, y: startY))
            cgPoints.append(CGPoint(x: startX, y: startY))
            
            if entry.y.isNaN || entry.y == 0 {
                cgPoints.removeAll()
                cgPoints.append(CGPoint(x: startX, y: startY))
                cgPoints.append(CGPoint(x: endX, y: startY))
                cgPoints.append(CGPoint(x: endX, y: startY))
                cgPoints.append(CGPoint(x: startX, y: startY))
            }
            
            let funnelSlicePoint = FunnelSlicePoint()
            funnelSlicePoint.points.append(contentsOf: cgPoints)
            
            entryPointMap[entry] = funnelSlicePoint
            
//            index += 1
            iterationIndex += 1
            if entry.y.isNaN {
                invalidEntryCount = invalidEntryCount + 1
            }
        }
        
        return entryPointMap
    }
    
    
    public static func preparePointsForHeightWeightage(entries: [ChartDataEntry], chart:ChartViewBase?) -> [ChartDataEntry:FunnelSlicePoint] {
     
        var entryPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
        guard let plotOptions = chart?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
              let phaseY = (chart?._animator.phaseY),
              let viewPortHandler = chart?.viewPortHandler
        else { return entryPointMap }
        
        let totalHeight = (viewPortHandler.contentHeight)
        
        let totalWidth = (viewPortHandler.contentWidth)
        
        var index = 0
        
        var cumulativeValue:Double = 0.0
        
        let widthInterpolator = Interpolator.interpolate(a: Double(totalWidth), b: Double((plotOptions.stemWidth)))
        
        var stemEndY:CGFloat = (viewPortHandler.contentBottom)
        
        let midX = (viewPortHandler.contentCenter.x)
        
        let totalValues = getSumOfValues(entries: entries)
        
        if plotOptions.stemHeight != 0 && (plotOptions.stemWidth) > CGFloat(0.0) {
            stemEndY = stemEndY - (plotOptions.stemHeight)
        }
        
        let topValue = (viewPortHandler.contentTop)
        
        let interSpace = (plotOptions.interSliceSpacing)
        
        for entry in entries {
            
//            let value = entry.value
            var value = entry.y
            
            value = getValueForNaN(value: value)
            
            value = abs(value)
            
            var cgPoints:[CGPoint] = []
            
            //            let startY = ((CGFloat(cumulativeValue / totalValues) * totalHeight ) + (index == 0 ? 0 : interSpace))// + (index == 0 ?  contentTop  : 0))
            //            let endY = ((CGFloat((cumulativeValue + value) / totalValues) * totalHeight) - (index == (values.count - 1) ? 0 : interSpace))
            
//            let tempStartY = ((CGFloat(cumulativeValue / totalValues) * totalHeight ) + (index == 0 ? 0 : (interSpace/2)) + (index == 0 ?  topValue  : topValue))
            var tempStartY = ((CGFloat(cumulativeValue / totalValues) * totalHeight ) + (index == 0 ? 0 : (interSpace/2)) + (index == 0 ?  topValue  : topValue))
            tempStartY = CGFloat(getValueForNaN(value: Double(tempStartY)))
            
//            let endY = ((CGFloat((cumulativeValue + value) / totalValues) * totalHeight) - (index == (entries.count - 1) ? 0 : (interSpace/2)) + (index == 0 ?  topValue  : topValue))
            var endY = ((CGFloat((cumulativeValue + value) / totalValues) * totalHeight) - (index == (entries.count - 1) ? 0 : (interSpace/2)) + (index == 0 ?  topValue  : topValue))
            endY = CGFloat(getValueForNaN(value: Double(endY)))
            
            let diff = (endY - tempStartY)
            
            
            let startY = endY - ( diff * CGFloat(phaseY)) //((CGFloat(cumulativeValue / totalValues) * totalHeight ) + (index == 0 ? 0 : (interSpace/2)) + (index == 0 ?  topValue  : topValue))
 
            var (startX1, startX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(startY), stemEndY: Double(stemEndY), midX: midX)
            
            var (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(endY), stemEndY: Double(stemEndY), midX: midX)
            
            if endY != totalHeight && stemEndY <= (endY + interSpace) { //TO CHECK
                
                (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
            }
            
            if startY >= stemEndY && endY >= stemEndY {
                (startX1, startX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
                
                (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
            }
            
            var (midX1, midX2):(CGFloat, CGFloat) = (0.0,0.0)
            
            if stemEndY > startY && endY > stemEndY {
                
                (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
                
                (midX1, midX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
 
            }
            
            cgPoints.append(CGPoint(x: endX1, y: endY))
            cgPoints.append(CGPoint(x: endX2, y: endY))
            
            if midX1 != 0 && midX2 != 0 {
                cgPoints.append(CGPoint(x: midX2, y: stemEndY))//MIDEND
                cgPoints.append(CGPoint(x: startX2, y: startY))
                cgPoints.append(CGPoint(x: startX1, y: startY))
                cgPoints.append(CGPoint(x: midX1, y: stemEndY))//MIDSTART
            }else {
                cgPoints.append(CGPoint(x: startX2, y: startY))
                cgPoints.append(CGPoint(x: startX1, y: startY))
            }
            
            if entry.y.isNaN || entry.y == 0 {
                cgPoints.removeAll()
                cgPoints.append(CGPoint(x: endX1, y: endY))
                cgPoints.append(CGPoint(x: endX2, y: endY))
                cgPoints.append(CGPoint(x: endX2, y: endY))
                cgPoints.append(CGPoint(x: endX1, y: endY))
            }
            
            let funnelSlicePoint = FunnelSlicePoint()
            funnelSlicePoint.points.append(contentsOf: cgPoints)
            
            entryPointMap[entry] = funnelSlicePoint
            
            cumulativeValue += value
            index += 1
        }
        
        return entryPointMap
    }
    
    public static func preparePointsForHeightType(entries: [ChartDataEntry], chart:ChartViewBase?) -> [ChartDataEntry:FunnelSlicePoint] {
        
        var entryPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
        guard let viewPortHandler = chart?.viewPortHandler,
            let plotOptions = chart?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
              let phaseY = (chart?._animator.phaseY)
            else {
            return entryPointMap
        }
        
        let totalHeight = viewPortHandler.contentHeight
        
        let nonZeroEntries = getNonZeroEntries(entries: entries)
        
        let totalValues = getSumOfValues(entries: entries)
        
        let interSpace = (plotOptions.interSliceSpacing)
        
        let remainingHeight = totalHeight - (CGFloat(nonZeroEntries.count - 1) * interSpace)
        
        /*var minHeight = CGFloat(getMinValue(entries: entries) / totalValues) * (remainingHeight)
         while (minHeight < 1 && interSpace != 0) {
         print(" HEIGHT MIN", minHeight, " SPACE ", interSpace)
         interSpace = interSpace / 2
         remainingHeight = totalHeight - (CGFloat(nonZeroEntries.count - 1) * interSpace)
         minHeight = CGFloat(getMinValue(entries: entries) / totalValues) * (remainingHeight)
         }
         print("MIN HEIGHT ", minHeight, " SPACE ", interSpace)
         
         
         //FOR NOW, MAKING INTER SPACE TO ZERO
         if (remainingHeight <= 0) {
         interSpace = 0
         remainingHeight = totalHeight
         }
         */
        
        
        
        let totalWidth = (viewPortHandler.contentWidth)
        
        var index = 0
        
        var cumulativeValue:Double = 0.0
        
        let widthInterpolator = Interpolator.interpolate(a: Double(totalWidth), b: Double((plotOptions.stemWidth)))
        
        var stemEndY:CGFloat = (viewPortHandler.contentBottom)
        
        let midX = (viewPortHandler.contentCenter.x)
        
        
        if plotOptions.stemHeight != 0 && (plotOptions.stemWidth) > CGFloat(0.0) {
            stemEndY = stemEndY - (plotOptions.stemHeight)
        }
        
        let topValue = (viewPortHandler.contentTop)
        
        for entry in entries {
            
            var value = entry.y
            
            value = getValueForNaN(value: value)
            
            value = abs(value)
            
            var cgPoints:[CGPoint] = []
            
            let entryHeight = plotOptions.funnelWeightedType == .Height ? CGFloat(value / totalValues) * (remainingHeight) : value == 0.0 ? value : remainingHeight / (nonZeroEntries.count > 0 ? Double(nonZeroEntries.count) : 1.0)
            
            var tempStartY = CGFloat(cumulativeValue) + ( index == 0 ? 0 : interSpace) + ( index == 0 ? topValue : 0)
            tempStartY = CGFloat(getValueForNaN(value: Double(tempStartY)))
            
            var endY = tempStartY + entryHeight
            endY = CGFloat(getValueForNaN(value: Double(endY)))
            
            let diff = (endY - tempStartY)
            
            let startY = endY - ( diff * CGFloat(phaseY))
            
            var (startX1, startX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(startY), stemEndY: Double(stemEndY), midX: midX)
            
            var (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(endY), stemEndY: Double(stemEndY), midX: midX)
            
            if endY != totalHeight && stemEndY <= (endY + interSpace) { //TO CHECK
                
                (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
            }
            
            if startY >= stemEndY && endY >= stemEndY {
                (startX1, startX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
                
                (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
            }
            
            var (midX1, midX2):(CGFloat, CGFloat) = (0.0,0.0)
            
            if stemEndY > startY && endY > stemEndY {
                
                (endX1, endX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
                
                (midX1, midX2) = getStartXAndEndXForY(interpolator: widthInterpolator, yValue: Double(stemEndY), stemEndY: Double(stemEndY), midX: midX)
                
            }
            
            cgPoints.append(CGPoint(x: endX1, y: endY))
            cgPoints.append(CGPoint(x: endX2, y: endY))
            
            if midX1 != 0 && midX2 != 0 {
                cgPoints.append(CGPoint(x: midX2, y: stemEndY))//MIDEND
                cgPoints.append(CGPoint(x: startX2, y: startY))
                cgPoints.append(CGPoint(x: startX1, y: startY))
                cgPoints.append(CGPoint(x: midX1, y: stemEndY))//MIDSTART
            }else {
                cgPoints.append(CGPoint(x: startX2, y: startY))
                cgPoints.append(CGPoint(x: startX1, y: startY))
            }
            
            if entry.y.isNaN || entry.y == 0 {
                cgPoints.removeAll()
                cgPoints.append(CGPoint(x: endX1, y: endY))
                cgPoints.append(CGPoint(x: endX2, y: endY))
                cgPoints.append(CGPoint(x: endX2, y: endY))
                cgPoints.append(CGPoint(x: endX1, y: endY))
            }
            
            let funnelSlicePoint = FunnelSlicePoint()
            funnelSlicePoint.points.append(contentsOf: cgPoints)
            
            entryPointMap[entry] = funnelSlicePoint
            
            cumulativeValue = Double(endY)
            index += 1
        }
        
        return entryPointMap
    }
    
    static func getValueForNaN(value:Double) -> Double
    {
        if value.isNaN {
            return 0
        }
        return value
    }
    
    static func getMaxValue(entries:[ChartDataEntry]) -> Double {
        //        return entries.map { $0.value }.max()!
        return entries.map { $0.y.isNaN ? 0 : abs($0.y) }.max() ?? 0
    }
    
    static func getSumOfValues(entries:[ChartDataEntry]) -> Double {
        //        return entries.map { $0.value }.reduce(0, +)
        return entries.map { $0.y.isNaN ? 0 : abs($0.y) }.reduce(0, +)
    }
    
    static func getStartXAndEndXForY(interpolator: ((Double) -> Double), yValue:Double, stemEndY: Double, midX:CGFloat) -> (CGFloat, CGFloat) {
        let val = yValue / stemEndY
        
        let widthVal = interpolator(val)
        
        let startX = CGFloat(Double(midX) - (widthVal/2))
        let endX = CGFloat(Double(midX) + (widthVal/2))
   
        return (startX, endX)
    }
    
    static func getNonZeroEntries(entries:[ChartDataEntry]) -> [ChartDataEntry] {
        return entries.filter( { !($0.y.isNaN) && !($0.y.isZero) })
    }
    
    static func getMinValue(entries:[ChartDataEntry]) -> Double {
        return entries.map { $0.y.isNaN ? 0 : abs($0.y) }.min() ?? 0
    }
}

open class FunnelSlicePoint {
   open var points:[CGPoint] = []
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCATextLayerAlignmentMode(_ input: String) -> CATextLayerAlignmentMode {
	return CATextLayerAlignmentMode(rawValue: input)
}
