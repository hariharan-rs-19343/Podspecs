//
//  DataRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(ChartDataRendererBase)
open class DataRenderer: Renderer
{
    open weak var animator: Animator?
    
    open var customOpacity: Bool = false
    
    open weak var chart: ChartViewBase?
    
    internal var useForcedValue = false
    
    public init(animator: Animator?, viewPortHandler: ViewPortHandler?)
    {
        super.init(viewPortHandler: viewPortHandler)
        
        self.animator = animator
    }
    
    public init(chart:ChartViewBase, animator: Animator?, viewPortHandler: ViewPortHandler?)
    {
        super.init(viewPortHandler: viewPortHandler)
        self.animator = animator
        self.chart = chart
    }

    open func drawData(context: CGContext)
    {
        fatalError("drawData() cannot be called on DataRenderer")
    }
    
    open func drawValues(context: CGContext)
    {
        fatalError("drawValues() cannot be called on DataRenderer")
    }
    
    open func drawExtras(context: CGContext)
    {
        fatalError("drawExtras() cannot be called on DataRenderer")
    }
    
    /// Draws all highlight indicators for the values that are currently highlighted.
    ///
    /// - parameter indices: the highlighted values
    open func drawHighlighted(context: CGContext, indices: [Highlight])
    {
        fatalError("drawHighlighted() cannot be called on DataRenderer")
    }
    
    /// An opportunity for initializing internal buffers used for rendering with a new size.
    /// Since this might do memory allocations, it should only be called if necessary.
    open func initBuffers() { }
    
    open func isDrawingValuesAllowed(dataProvider: ChartViewBase?) -> Bool
    {
        guard let data = dataProvider?.data,
            let plotOptions  = dataProvider?.getPlotOptions() as? AxisChartPlotOptions,
              let chart = dataProvider
            else { return false }
        
        let maxCount = plotOptions.isStacked ? ((dataProvider?.maxVisibleCount ?? 0) * data.dataSetCount) : (dataProvider?.maxVisibleCount ?? 0)
        
        return chart.isRotated ? data.entryCount <  ChartUtils.doubleToIntSafeCast(value:CGFloat(maxCount) * (viewPortHandler?.scaleY ?? 1.0)) : data.entryCount <=  ChartUtils.doubleToIntSafeCast(value:CGFloat(maxCount) * (viewPortHandler?.scaleX ?? 1.0))
    }
    
    /// - returns: `true` if the DataSet values should be drawn, `false` if not.
    internal func shouldDrawValues(forDataSet set: IChartDataSet) -> Bool
    {
        return set.isVisible && (set.isDrawValuesEnabled || set.isDrawIconsEnabled)
    }
    
    internal func isDataLabelOverlapping(rect: CGRect) -> Bool {
        
        guard let chart = chart, let labelRects = chart.labelRects else {
            return true
        }
        
        if labelRects.isEmpty {
            return false
        }
            
        for labelRect in labelRects {
            
            if labelRect.intersects(rect) {
                return true
            }
        }
        
        return false
    }
    
    internal func isDataLappingOverLappingWithPlot(rect: CGRect) -> Bool {
        
        guard let chart = chart else {
            return true
        }
        
        let layers = ScatterLayer.getAllScatterLayer(chart: chart)
        
        for layer in layers {
            
            guard let layerBounds = layer.path?.boundingBox else {
                continue
            }
            
            if layerBounds.intersects(rect) {
                return true
            }
        }
        
        return false
    }
    
    func getLabelProperties(chart: ChartViewBase, label: String, valueFont: NSUIFont, origin: CGPoint) -> (CGRect,NSTextAlignment) {
        
        let textSize = label.size(withAttributes: [NSAttributedString.Key.font: valueFont])

        let alignment = ScatterHelperFunctions.getAlignmentForDataLabel(chart: chart, point: origin, textSize: textSize)
        
        let viewPort = chart._viewPortHandler.contentRect

        let xPoint = alignment == .center ? origin.x - textSize.width / 2.0 : alignment == .left ? viewPort.maxX - textSize.width : viewPort.minX
        
        let origin = CGPoint(x: xPoint, y: origin.y)
        
        let rect = CGRect(origin: origin, size: textSize)
        
        return (rect,alignment)
    }
    
    static func alignDataLabel(chart: ChartViewBase, translatedOrigin: inout CGPoint, labelSize: CGSize ) {
        
        if translatedOrigin.x < chart.viewPortHandler.contentRect.minX + chart.viewPortHandler.transX {
            translatedOrigin.x = chart.viewPortHandler.contentRect.minX + chart.viewPortHandler.transX
        }
        else if translatedOrigin.x + labelSize.width > chart.viewPortHandler.transX + chart.viewPortHandler.contentWidth * chart.scaleX + chart.viewPortHandler.contentLeft {
            translatedOrigin.x = chart.viewPortHandler.transX + chart.viewPortHandler.contentWidth * chart.scaleX + chart.viewPortHandler.contentLeft - labelSize.width
        }
    }
    
    static func getXTranslationForBounds(chart: ChartViewBase, x: Double, width: Double) -> CGFloat? {
        
        var translateX: CGFloat? = nil
        if let chartBounds = chart.nsuiLayer?.bounds {
            if x + width > chartBounds.maxX {
                translateX = chartBounds.maxX - width
            }
            else if (x - width) < chartBounds.minX {
                translateX = chartBounds.minX + width
            }
        }
        return translateX
    }
    
    static func getYTranslationForBounds(chart: ChartViewBase, y: Double, height: Double) -> CGFloat? {
        
        var translateY: CGFloat? = nil
        if let chartBounds = chart.nsuiLayer?.bounds {
            if y + height > chartBounds.maxY {
                translateY = chartBounds.maxY - height
            }
            else if y - height < chartBounds.minY {
                translateY = chartBounds.minY + height
            }
        }
        return translateY
    }
    
    internal func drawLabel(chart: ChartViewBase, label: String, labelAttributes: [NSAttributedString.Key:NSObject], labelRect: CGRect) {
        chart.plotView?.nsuiLayer?.addSublayer(ChartUtils.drawTextLayer(text: label, rect: labelRect, attributes: labelAttributes))
    }
    
    internal func drawLabel(chart: ChartViewBase, labelProperties: LabelProperties, attributes: [NSAttributedString.Key:NSObject]) {
        let textValue = labelProperties.formattedLabel ?? String(labelProperties.value)
        chart.plotView?.nsuiLayer?.addSublayer(ChartUtils.drawTextLayer(text: textValue, rect: labelProperties.rect, attributes: attributes))
    }
}
