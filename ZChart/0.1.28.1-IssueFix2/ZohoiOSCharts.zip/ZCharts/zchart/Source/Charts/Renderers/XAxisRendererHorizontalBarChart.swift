//
//  XAxisRendererHorizontalBarChart.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

open class XAxisRendererHorizontalBarChart: XAxisRenderer
{

    open var currentMaxLabelWidth:CGFloat = 0
    
    public init(viewPortHandler: ViewPortHandler?, xAxis: XAxis?, transformer: Transformer?, chart: ChartViewBase?)
    {
        super.init(viewPortHandler: viewPortHandler, xAxis: xAxis, transformer: transformer, chartViewBase: chart)
        
    }
    
    open override func computeAxis(min: Double, max: Double, inverted: Bool)
    {
        guard let
            viewPortHandler = self.viewPortHandler
            else { return }
        
        var min = min, max = max
        
        if let transformer = self.transformer
        {
            // calculate the starting and entry point of the y-labels (depending on
            // zoom / contentrect bounds)
            if viewPortHandler.contentWidth > 10 && !viewPortHandler.isFullyZoomedOutY
            {
                var p1 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentBottom))
                var p2 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop))
                
                p1 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: 0, point: p1)
                p2 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: 0, point: p2)
                
                if inverted
                {
                    /*min = Double(p2.y)
                    max = Double(p1.y)*/
                    min = Double(p1.y)
                    max = Double(p2.y)
                }
                else
                {
                    /*min = Double(p1.y)
                    max = Double(p2.y)*/
                    min = Double(p2.y)
                    max = Double(p1.y)
                }
            }
        }
        
        computeAxisValues(min: min, max: max)
    }
    
    
    open override func computeSize()
    {
        guard let
            xAxis = self.axis as? XAxis
            else { return }
        
        resetXAxisLabelSizes(xAxis)
        
        defer {
            computeSizeForAxisTitle()
        }
        
        if !xAxis.drawLabelsEnabled {
            return
        }
        
        if xAxis.customTickEnabled
        {
            if xAxis.tickDelegate != nil
            {
                xAxis.labelWidth = xAxis.longestSize.width
                xAxis.labelHeight = xAxis.longestSize.height
                xAxis.labelRotatedWidth = xAxis.longestSize.width
                xAxis.labelRotatedHeight = xAxis.longestSize.height
                return
                
            }
            
        }
        
        
        /*if longest == ""
        {
            longest = getLongestLabelOfAllData(axis: xAxis)
        }*/
        
        let labelAttrs = [NSAttributedString.Key.font: xAxis.labelHighlightFont ?? xAxis.labelFont]
        
        var labelSize = xAxis.longestLabel.size(withAttributes: labelAttrs)
        
        //        var labelRotatedSize = CGSize()
        
        //        labelRotatedSize.height += labelSize.height
        
        var maxLabelWidth = xAxis.maxLabelWidth
        
        var isHeightInfinity = false
        
        if xAxis.maxLabelHeight == .infinity{
            xAxis.maxLabelHeight = 0
            isHeightInfinity = true
        }
        
        var labelRotatedSize = CGSize()
        
        switch xAxis.tickLabelMode{
            
        case .auto:
            //label width is less then requried maxlabel width (horizontal case)
            
            xAxis.labelRotationAngle = 0
            
            labelRotatedSize = labelSize
            /*
            //rotation case
            if labelSize.width > maxLabelWidth
            {
                /*xAxis.labelRotationAngle = xAxis.autoRotateAngle
                
                labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: xAxis.labelRotationAngle)
                    
                if xAxis.labelRotationAngle != 0 && xAxis.labelRotationAngle != 180 && xAxis.labelRotationAngle != 360
                {
                        if labelRotatedSize.width > maxLabelWidth{
                            var restictedTextWidth = abs( maxLabelWidth / cos(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                            let height = restictedTextWidth * sin(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD)
                        
                            if height > xAxis.maxLabelHeight{
                                restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (xAxis.maxLabelHeight * xAxis.maxLabelHeight))
                            }
                        
                            labelRotatedSize.width = restictedTextWidth
                        }
                        else if labelRotatedSize.height > xAxis.maxLabelHeight{
                        
                            var restictedTextWidth = abs( xAxis.maxLabelHeight / sin(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                        
                            let width = restictedTextWidth * cos(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD)

                            if width > maxLabelWidth{
                            
                            restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (xAxis.maxLabelHeight * xAxis.maxLabelHeight))
                            }
                        
                            labelRotatedSize.width = restictedTextWidth
                        }
                    
                        computeLongestTickLabel(MaxLabelSize: CGSize(width: labelRotatedSize.width, height: 0),angle: xAxis.labelRotationAngle)
                
                    labelRotatedSize = longestTickLabel.boundPath.boundingBox.size//.bounds.size
                    
                }
                else{
                    //width restiction
                    labelRotatedSize.width = maxLabelWidth
                }*/
                labelRotatedSize.width = maxLabelWidth
            }
            else{
                //width restiction
                if maxLabelWidth != .infinity{
                    labelRotatedSize.width = maxLabelWidth
                }
            }
            */
            if labelSize.width > maxLabelWidth && maxLabelWidth > 0 {
                labelRotatedSize.width = maxLabelWidth
            }
             
            break
            
        case .forced:
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: xAxis.labelRotationAngle)
                
            if xAxis.labelRotationAngle != 0 && xAxis.labelRotationAngle != 180 && xAxis.labelRotationAngle != 360
            {
                    if labelRotatedSize.width > maxLabelWidth{
                        var restictedTextWidth = abs( maxLabelWidth / cos(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                        let height = restictedTextWidth * sin(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD)
                    
                        if height > xAxis.maxLabelHeight{
                            restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (xAxis.maxLabelHeight * xAxis.maxLabelHeight))
                        }
                    
                        labelRotatedSize.width = restictedTextWidth
                    }
                    else if labelRotatedSize.height > xAxis.maxLabelHeight{
                    
                        var restictedTextWidth = abs( xAxis.maxLabelHeight / sin(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
                    
                        let width = restictedTextWidth * cos(xAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD)

                        if width > maxLabelWidth{
                        
                            restictedTextWidth = sqrt((maxLabelWidth * maxLabelWidth) + (xAxis.maxLabelHeight * xAxis.maxLabelHeight))
                        }
                    
                        labelRotatedSize.width = restictedTextWidth
                    }
                
                    computeLongestTickLabel(MaxLabelSize: CGSize(width: labelRotatedSize.width, height: 0),angle: xAxis.labelRotationAngle)
            
                labelRotatedSize = longestTickLabel.boundPath.boundingBox.size//.bounds.size
                
                    if maxLabelWidth == .infinity && isHeightInfinity{
                        labelRotatedSize.height = .infinity
                        xAxis.maxLabelHeight = .infinity
                    }
                
            }
            else{

                //width restiction

                if labelSize.width > maxLabelWidth{
                    labelRotatedSize.width = maxLabelWidth
                }

            }
            break
            
        case .wordwrap:
            
            var labelMaxSize = CGSize()
            
            if maxLabelWidth <= 0 || maxLabelWidth > labelSize.width{
                maxLabelWidth = labelSize.width
            }
            
            labelMaxSize.width = maxLabelWidth
            
            // calculate rect constrained to max width
            let rect = xAxis.longestLabel.boundingRect(with: labelMaxSize, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: labelAttrs, context: nil)
            
            // To maintain space between axis line and bottom
            labelSize = rect.size
            
            labelMaxSize = rect.size
            
            if labelMaxSize.height > xAxis.maxLabelHeight
            {
                labelMaxSize.height = xAxis.maxLabelHeight
                
                labelSize.height = labelMaxSize.height
            }
            
            labelRotatedSize = ChartUtils.sizeOfRotatedRectangle(labelMaxSize, degrees: xAxis.labelRotationAngle)
            
            break
        }
        
//        if xAxis.maxLabelWidth != CGFloat.infinity
//        {
//            labelSize.width = min(xAxis.maxLabelWidth,labelSize.width)
//            //            labelRotatedSize.width = labelSize.width
//        }
//        xAxis.autoRotateAngle = 0
//        xAxis.labelRotationAngle = 0
        
        let labelWidth = labelSize.width
        let labelHeight = labelSize.height
       
        xAxis.longestSize = labelSize
        xAxis.labelWidth = labelWidth
        xAxis.labelHeight = labelHeight
        xAxis.labelRotatedWidth = labelRotatedSize.width    // round(labelRotatedSize.width + xAxis.xOffset * 2) + (xAxis.axisTitle).size(attributes: [NSFontAttributeName: xAxis.axisTitleFont]).height
        xAxis.labelRotatedHeight =  labelRotatedSize.height     //round(labelRotatedSize.height)
    }

    override func computeSizeForAxisTitle() {
        guard let
            xAxis = self.axis as? XAxis
            else { return }
        
        if !xAxis.axisTitleEnabled {
            return
        }
        
        let axisTitleSize =  (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont])
        
       xAxis.labelWidth +=  axisTitleSize.height
       xAxis.labelRotatedWidth += axisTitleSize.height //RotatedWidth not handled
    }
    
    open override func renderAxisLabels(context: CGContext)
    {
        guard
            let xAxis = self.axis as? XAxis
            else { return }
        
        if !xAxis.isEnabled || chartViewBase?.data === nil //|| !xAxis.isDrawLabelsEnabled
        {
            return
        }
        
        drawLabels(context: context)
    }

    /*/// draws the x-labels on the specified y-position
    open override func drawLabels(context: CGContext) {
        
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = self.chartViewBase,
            let chartData = (chart.data)
            else { return }
        
        let pos = fixedPosition(isRotated: chart.isRotated, viewPortHandler: viewPortHandler, xAxis: xAxis)
        
        let anchor = xAxis.getAnchorForAxisTickLabel(isRotated: chart.isRotated)
        
        defer {
            drawAxisTitle(context: context, pos: pos, anchor: anchor)
        }
        
        if !xAxis.drawLabelsEnabled {
            return
        }
        
        for tickLabel in tickLabels {
            
            if !viewPortHandler.isInBoundsY(tickLabel.point.y)
            {
                continue
            }
            
            var boldText = false
            
            let curEntry = chart.lastSelected
            
            var labelColor = xAxis.labelTextColor
            
            var labelFont = xAxis.labelFont
            
            if curEntry != nil {
                boldText = chart.IsEntryXSelected(x: tickLabel.value)
            }
            
            if let barPlotOptions = chart.getPlotOptions(type: .Bar) as? BarPlotOptions, !barPlotOptions.groupSpace.isZero && (chartData.dataSetCount) > 1 {
//                tickLabel.point.x = getNewPositionForBarChart(value: tickLabel.value, valueToPixelMatrix: transformer.valueToPixelMatrix, position: tickLabel.point)
                
                if curEntry != nil {
                    boldText = chart.IsEntryRoundedXSelected(x: tickLabel.value)
                }
            }
            
            if boldText
            {
                (labelFont, labelColor) = XAxisRenderer.getBoldAttributes(axis: xAxis)
            }
            
            let labelAttrs = boldText ? [NSAttributedString.Key.font: labelFont,
                                         NSAttributedString.Key.foregroundColor: labelColor,
                                         NSAttributedString.Key.paragraphStyle: tickLabel.attributes[.paragraphStyle]!] : tickLabel.attributes
            
            tickLabel.updateTickBounds()
            
            drawLabel(context: context,
                      formattedLabel: tickLabel.label,
                      x: tickLabel.point.x,
                      y: tickLabel.point.y,
                      attributes: labelAttrs,
                      constrainedToSize: tickLabel.constrainedSize,
                      anchor: tickLabel.anchorPoint,
                      angleRadians: tickLabel.angleInRadians)
            
        }
        
    }
    */
    override func drawAxisTitle(context: CGContext, anchor: CGPoint) {
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler
            else { return }
        
        if !xAxis.enabled || !xAxis.axisTitleEnabled {
            return
        }
        
        let xLabelAttrs = [NSAttributedString.Key.font: xAxis.axisTitleFont,
                           NSAttributedString.Key.foregroundColor: xAxis.axisTitleColor,
                           NSAttributedString.Key.paragraphStyle: getParaStyle()]
        
        var labelMaxSize = CGSize()
        
        labelMaxSize.width = (viewPortHandler.contentRect.height)*(3/4)
        labelMaxSize.height = (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont]).height
        
        let textWidth = (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont]).width
        
        var xInPixel = xAxis.axisTitleOffsets.marginLeft
        if xAxis.labelPosition == .top
        {
            xInPixel = viewPortHandler.chartWidth - xAxis.axisTitleOffsets.marginRight - labelMaxSize.height
        }
        let point = CGPoint(x: xInPixel, y: (viewPortHandler.contentRect.midY)-(min(labelMaxSize.width,textWidth)/2))
        
        if xAxis.labelPosition == .bottom && viewPortHandler.contentLeft > 0 || xAxis.labelPosition == .top && viewPortHandler.contentRight < viewPortHandler.chartWidth {
            drawLabelTruncated(context: context, formattedLabel: xAxis.axisTitle, x: point.x, y: point.y, attributes: xLabelAttrs, constrainedToSize: labelMaxSize, anchor: CGPoint(x:0,y:0.5), angleRadians: (270 * ChartUtils.Math.FDEG2RAD))
        }
    }
    
    open func drawLabel(
        context: CGContext,
        formattedLabel: String,
        x: CGFloat,
        y: CGFloat,
        attributes: [NSAttributedString.Key: NSObject],
        anchor: CGPoint,
        angleRadians: CGFloat)
    {
        ChartUtils.drawText(
            context: context,
            text: formattedLabel,
            point: CGPoint(x: x, y: y),
            attributes: attributes,
            anchor: anchor,
            angleRadians: angleRadians)
    }
    
    open override var gridClippingRect: CGRect
    {
        var contentRect = viewPortHandler?.contentRect ?? CGRect.zero
        let dy = self.axis?.gridLineWidth ?? 0.0
        contentRect.origin.y -= dy / 2.0
        contentRect.size.height += dy
        return contentRect
    }
    
    fileprivate var _gridLineSegmentsBuffer = [CGPoint](repeating: CGPoint(), count: 2)
    
    open override func drawGridLine(context: CGContext, position:CGPoint)
    {
        guard
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        let y = position.y
        
        let contentLeft = CommonHelperFunctions.contentLeft(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentRight = CommonHelperFunctions.contentRight(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        if viewPortHandler.isInBoundsY(y)
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentLeft, y: y))
            context.addLine(to: CGPoint(x: contentRight, y: y))
            context.strokePath()
        }
    }
    
    open override func renderAxisLine(context: CGContext)
    {
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        if !xAxis.isEnabled || !xAxis.isDrawAxisLineEnabled
        {
            return
        }
        
        context.saveGState()
        
        context.setStrokeColor(xAxis.axisLineColor.cgColor)
        context.setLineWidth(xAxis.axisLineWidth)
        if xAxis.axisLineDashLengths != nil
        {
            context.setLineDash(phase: xAxis.axisLineDashPhase, lengths: xAxis.axisLineDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        let contentTop = CommonHelperFunctions.contentTop(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentBottom = CommonHelperFunctions.contentBottom(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentLeft = CommonHelperFunctions.contentLeft(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentRight = CommonHelperFunctions.contentRight(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        if xAxis.labelPosition == .top ||
            xAxis.labelPosition == .topInside ||
            xAxis.labelPosition == .bothSided
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentRight, y: contentTop))
            context.addLine(to: CGPoint(x: contentRight, y: contentBottom))
            context.strokePath()
        }
        
        if xAxis.labelPosition == .bottom ||
            xAxis.labelPosition == .bottomInside ||
            xAxis.labelPosition == .bothSided
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentLeft, y: contentTop))
            context.addLine(to: CGPoint(x: contentLeft, y: contentBottom))
            context.strokePath()
        }
        
        context.restoreGState()
    }
    
    open override func renderLimitLines(context: CGContext)
    {
        guard
            let xAxis = self.axis as? XAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = chartViewBase
            else { return }
        
        var limitLines = xAxis.limitLines
        
        if limitLines.count == 0
        {
            return
        }
        
        let trans = transformer.valueToPixelMatrix
        
        var position = CGPoint(x: 0.0, y: 0.0)
        
        for i in 0 ..< limitLines.count
        {
            let l = limitLines[i]
            
            if !l.isEnabled
            {
                continue
            }
            
            context.saveGState()
            defer { context.restoreGState() }
            
            var clippingRect = viewPortHandler.contentRect
            clippingRect.origin.y -= l.lineWidth / 2.0
            clippingRect.size.height += l.lineWidth
            context.clip(to: clippingRect)

            position.x = 0.0
            position.y = CGFloat(l.limit)
            position = transformer.pixelForValues(x: position.x, y: position.y)
            
            if !(viewPortHandler.isInBoundsY(position.y))
            {
                continue
            }
            
          /*  context.beginPath()
            context.move(to: CGPoint(x: viewPortHandler.contentLeft, y: position.y))
            context.addLine(to: CGPoint(x: viewPortHandler.contentRight, y: position.y))
            
            context.setStrokeColor(l.lineColor.cgColor)
            context.setLineWidth(l.lineWidth)
            if l.lineDashLengths != nil
            {
                context.setLineDash(phase: l.lineDashPhase, lengths: l.lineDashLengths!)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
            
            context.strokePath()*/
            
            let limitValueSize = l.getLimitValueSize(formattedString: l.getLimitValue(axis: xAxis))
            
            var limitTextSizeMax = max(xAxis.longestLabel.size(withAttributes: [NSAttributedString.Key.font: l.limitValueFont]).width, limitValueSize.width)
            
            if limitTextSizeMax > xAxis.maxLabelWidth
            {
                limitTextSizeMax = xAxis.maxLabelWidth
            }
            
            let titleHeight =  xAxis.axisTitleEnabled ? (xAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:xAxis.axisTitleFont]).height : 0
            
            var x = viewPortHandler.contentLeft - (xAxis.axisLabelOffsets.marginLeft + xAxis.axisLabelOffsets.marginRight) - (limitTextSizeMax - titleHeight)
            var width = abs(viewPortHandler.contentLeft - x)
            var frame = CGRect(x: x, y: position.y - width/2, width: width, height: width)
            var endPoint = CGPoint(x: viewPortHandler.contentRight, y: frame.midY)
            
            if xAxis.labelPosition == .top
            {
                x = viewPortHandler.contentRight
                width = (xAxis.axisLabelOffsets.marginLeft + xAxis.axisLabelOffsets.marginRight) + (limitTextSizeMax - titleHeight)
                frame = CGRect(x: x, y: position.y - width/2, width: width, height: width)
                endPoint = CGPoint(x: viewPortHandler.contentLeft, y: frame.midY)
            }
            
            

            
            let layer = LimitLineLayer(chartViewBase: chart, axisRendererBase: self, charLimitLine: l, position: frame,endPoint:endPoint)
            self.chartViewBase?.nsuiLayer?.addSublayer(layer)
            
            if l.drawLabelEnabled && !l.label.isEmpty
            {
                renderLimitLineLabel(limitLine: l, limitLineLayer: layer, position: position, limitLineType: .horizontal)
            }
        }
    }
}
