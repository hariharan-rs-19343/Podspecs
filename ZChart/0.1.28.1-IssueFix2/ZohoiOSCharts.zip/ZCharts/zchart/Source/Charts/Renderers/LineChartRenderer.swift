//
//  LineChartRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


open class LineChartRenderer: LineRadarRenderer
{
    fileprivate var _lineSegments = [CGPoint](repeating: CGPoint(), count: 2)
    
    fileprivate var firstPoint = true

    // MARK: - Draw Data
    open override func drawData(context: CGContext)
    {
        guard let lineData = chart?.data else { return }
        
//        self.strokePathMap.removeAll()
        
        for i in 0 ..< lineData.dataSetCount
        {
            guard let set = lineData.getDataSetByIndex(i) else { continue }
            
            if set.isVisible && (set.plotType == .Line || set.plotType == .LineRange)
            {
//                if !(set.plotType == .Line)
//                {
//                    fatalError("Datasets for LineChartRenderer must conform to IChartDataSet")
//                }
                
                drawDataSet(context: context, dataSet: set)
            }
        }
    }
    
    open func drawDataSet(context: CGContext, dataSet: IChartDataSet)
    {
        if dataSet.entryCount < 1
        {
            return
        }
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        context.saveGState()
        
        context.setLineWidth(lineDataSetOptions.lineWidth)
        if lineDataSetOptions.lineDashLengths != nil
        {
            context.setLineDash(phase: lineDataSetOptions.lineDashPhase, lengths: lineDataSetOptions.lineDashLengths!)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        // if drawing cubic lines is enabled
        switch lineDataSetOptions.mode
        {
        case .linear: fallthrough
        case .stepped:
            drawLinear(context: context, dataSet: dataSet)
            
        case .cubicBezier:
            drawCubicBezier(context: context, dataSet: dataSet)
        case .horizontalBezier:
            drawHorizontalBezier(context: context, dataSet: dataSet)
        case .montonic:
            drawMonotoneBezier(context: context, dataSet: dataSet)
        }
        
        context.restoreGState()
    }
    
    func createLineStrokeLayer(lineLayer: LineLayer, dataSet: IChartDataSet, strokePath: CGPath) {
        
        lineLayer.lineWidth = 0
        let datasetoption = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        let shapeLayer = LineStrokeLayer()
        shapeLayer.strokeColor = dataSet.colors[0].cgColor
        shapeLayer.path = strokePath
        shapeLayer.lineWidth = datasetoption.lineWidth
        shapeLayer.fillColor = NSUIColor.clear.cgColor
        if (datasetoption.lineDashLengths != nil) {
            shapeLayer.lineDashPhase =  datasetoption.lineDashPhase
            shapeLayer.lineDashPattern = LimitLineLayer.getNSNumberArray(lineDashLengths: datasetoption.lineDashLengths)
        }
        if let isHighlighted = lineLayer.value(forKey: "isHighlighted") as? Bool {
            if !isHighlighted {
                if let nonHighlightStrokecolor = datasetoption.nonHighlightStrokecolor {
                    shapeLayer.strokeColor = nonHighlightStrokecolor.cgColor
                }
            }
        }
        lineLayer.addSublayer(shapeLayer)
        
    }
    
    // MARK: - Cubic
    open func drawCubicBezier(context: CGContext, dataSet: IChartDataSet)
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSet.plotType]) as? LinePlotOptions,
              let drawingColor = dataSet.colors.first
            else { return }
        
        // get the color that is specified for this position from the DataSet
        
        
        var (dataSetPath,strokePath):(CGPath,CGPath)
        
       
        
        if  (plotOption.isStacked)
        {
            (dataSetPath,strokePath) = LineHelperFunctions.getCubicStackedDataSetPathWithNAN(barLineChart: chart , dataSet: dataSet, animator: animator, lineRenderer: self)
        }
        else{
            (dataSetPath,strokePath) = LineHelperFunctions.getCubicDataSetPathWithNAN(barLineChart: chart, dataSet: dataSet, animator: animator, lineRenderer: self)
            
        }
        
        context.saveGState()
        
        if !(chart.includeLayer)
        {
            context.beginPath()
            context.addPath(dataSetPath)
            context.setStrokeColor(drawingColor.cgColor)
            context.strokePath()
        }
        else{
            guard let firstEntry = dataSet.entryForIndex(0)
            else { return }
            let lineLayer = LineLayer(chartView: chart, chartEntry: firstEntry, dataSet: dataSet, path: dataSetPath)
            
            if let entry = dataSet.entryForIndex(0){
                
                if customOpacity{
                    lineLayer.opacity = entry.opacityChanged
                }
            }
            
            if LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet).isDrawFilledEnabled
            {
                createLineStrokeLayer(lineLayer: lineLayer, dataSet: dataSet, strokePath: strokePath )
            }
        }
        context.restoreGState()
    }
    
    // MARK: -  Monotone
    open func drawMonotoneBezier(context: CGContext, dataSet: IChartDataSet)
    {
        guard let chart = chart,
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSet.plotType]) as? LinePlotOptions,
              let drawingColor = dataSet.colors.first
            else { return }
        
        
        // get the color that is specified for this position from the DataSet
        
        var (dataSetPath,strokePath):(CGPath,CGPath)
        
        
        if  (plotOption.isStacked)
        {
            (dataSetPath,strokePath) =   LineHelperFunctions.getMonotoneStackedDataSetPathWithNAN(barLineChart: chart, dataSet: dataSet, animator: animator, lineRenderer: self)
//            strokePath = CGMutablePath()
        }
        else{
            (dataSetPath,strokePath) = LineHelperFunctions.getMonotoneDataSetPathWithNAN(barLineChart: chart, dataSet: dataSet, animator: animator, lineRenderer: self)
            
        }
        
        context.saveGState()
        
        if !((chart.includeLayer))
        {
            context.beginPath()
            context.addPath(dataSetPath)
            context.setStrokeColor(drawingColor.cgColor)
            context.strokePath()
        }
        else{
            guard let firstEntry = dataSet.entryForIndex(0)
            else { return }
            let lineLayer = LineLayer(chartView: chart, chartEntry: firstEntry, dataSet: dataSet, path: dataSetPath)
            
            if let entry = dataSet.entryForIndex(0){
                
                if customOpacity{
                    lineLayer.opacity = entry.opacityChanged
                }
            }
            
            if LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet).isDrawFilledEnabled
            {
                createLineStrokeLayer(lineLayer: lineLayer, dataSet: dataSet, strokePath: strokePath )
            }
        }
        context.restoreGState()
    }
    
    // MARK: - Horizontal Bezier
    open func drawHorizontalBezier(context: CGContext, dataSet: IChartDataSet)
    {
        guard let chart = chart,
            let animator = animator,
              let drawingColor = dataSet.colors.first
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let phaseY = animator.phaseY
        
        _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
        
        // get the color that is specified for this position from the DataSet
        
        
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        if _xBounds.range >= 1
        {
            var prev: ChartDataEntry! = dataSet.entryForIndex(_xBounds.min)
            var cur: ChartDataEntry! = prev
            
            if cur == nil { return }
            
            // let the spline start
            cubicPath.move(to: CGPoint(x: CGFloat(cur.x), y: CGFloat(cur.y * phaseY)), transform: valueToPixelMatrix)
            
            for j in stride(from: (_xBounds.min + 1), through: _xBounds.range + _xBounds.min, by: 1)
            {
                prev = cur
                cur = dataSet.entryForIndex(j)
                
                let cpx = CGFloat(prev.x + (cur.x - prev.x) / 2.0)
                
                cubicPath.addCurve(
                    to: CGPoint(
                        x: CGFloat(cur.x),
                        y: CGFloat(cur.y * phaseY)),
                    control1: CGPoint(
                        x: cpx,
                        y: CGFloat(prev.y * phaseY)),
                    control2: CGPoint(
                        x: cpx,
                        y: CGFloat(cur.y * phaseY)),
                    transform: valueToPixelMatrix)
            }
        }
        
        context.saveGState()
        
        if LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet).isDrawFilledEnabled
        {
            
            // Copy this path because we make changes to it
            guard let fillPath = cubicPath.mutableCopy()
            else { return }
            
            drawCubicFill(context: context, dataSet: dataSet, spline: fillPath, matrix: valueToPixelMatrix, bounds: _xBounds)
        }
        
        context.beginPath()
        context.addPath(cubicPath)
        context.setStrokeColor(drawingColor.cgColor)
        context.strokePath()
        
        context.restoreGState()
    }
    
    /*func getDataSetIndex(dataSet: IChartDataSet) -> Int {
        return (self.dataProvider?.lineData?.indexOfDataSet(dataSet))!
    }
    
    func updateStrokePath(dataSet: IChartDataSet, pathArray: [CGMutablePath], path: CGMutablePath) {
        if dataSet.drawFilledEnabled && dataSet.lineWidth > 0 {
            
            var myPathArray = pathArray
            
            myPathArray.append(path)
            
            let strokePath = CGMutablePath()
            
            for path in myPathArray {
                strokePath.addPath(path.mutableCopy()!)
            }
            strokePathMap[getDataSetIndex(dataSet: dataSet)] = strokePath
            
            myPathArray.removeLast()
        }
    }
    
    func createLineStrokeLayer(lineLayer: LineLayer, dataSet: IChartDataSet) {
        if strokePathMap.count > 0 && strokePathMap[getDataSetIndex(dataSet: dataSet)] != nil {
            let strokePath = strokePathMap[getDataSetIndex(dataSet: dataSet)]
            lineLayer.lineWidth = 0
            let shapeLayer = LineStrokeLayer()
            shapeLayer.strokeColor = dataSet.colors[0].cgColor
            shapeLayer.path = strokePath
            shapeLayer.lineWidth = dataSet.lineWidth
            shapeLayer.fillColor = NSUIColor.clear.cgColor
            lineLayer.addSublayer(shapeLayer)
        }
    }*/
    
    // MARK: - Linear and Stepped
    open func drawLinear(context: CGContext, dataSet: IChartDataSet)
    {
        guard let chart = chart
        else { return }
        
        let (datasetPath,strokePath) = getLinearDataSetPath(context: context, dataSet: dataSet)
        
        context.saveGState()
        
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        
        if !(chart.includeLayer)
        {
            if !firstPoint
            {
                context.setLineCap(lineDataSetOptions.lineCapType)
                context.beginPath()
                context.addPath(datasetPath)
                context.setStrokeColor(dataSet.color(atIndex: 0).cgColor)
                context.strokePath()
            }
        }
        else{
            guard let firstEntry = dataSet.entryForIndex(0)
            else { return }
            let lineLayer = LineLayer(chartView: chart, chartEntry: firstEntry, dataSet: dataSet, path: datasetPath)
            
            if let entry = dataSet.entryForIndex(0){
                
                if customOpacity{
                    lineLayer.opacity = entry.opacityChanged
                }
            }
            
            if lineDataSetOptions.isDrawFilledEnabled
            {
                createLineStrokeLayer(lineLayer: lineLayer, dataSet: dataSet, strokePath:strokePath)
            }
        }
        
        context.restoreGState()
    }
    
    open func getLinearDataSetPath(context:CGContext?,dataSet:IChartDataSet) -> (CGPath,CGPath)
    {
        let path = CGMutablePath()
        
        guard let chart = chart,
            let animator = animator,
            let viewPortHandler = chart.viewPortHandler,
            let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSet.plotType]) as? LinePlotOptions
            else { return (path,path) }
        
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let entryCount = dataSet.entryCount
        let isDrawSteppedEnabled = lineDataSetOptions.mode == .stepped
        let pointsPerEntryPair = isDrawSteppedEnabled ? 4 : 2
        
        let phaseY = animator.phaseY
        
        _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
        
        // if drawing filled is enabled
        if lineDataSetOptions.isDrawFilledEnabled && entryCount > 0
        {
            if !(chart.includeLayer) && context != nil
            {
                drawLinearFill(context: context!, dataSet: dataSet, trans: trans, bounds: _xBounds)
            }
            
        }
        
        
        // more than 1 color
        if dataSet.colors.count > 1
        {
            if _lineSegments.count != pointsPerEntryPair
            {
                // Allocate once in correct size
                _lineSegments = [CGPoint](repeating: CGPoint(), count: pointsPerEntryPair)
            }
            
            for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
            {
                var e: ChartDataEntry! = dataSet.entryForIndex(j)
                
                if e == nil { continue }
                
                _lineSegments[0].x = CGFloat(e.x)
                _lineSegments[0].y = CGFloat(e.y * phaseY)
                
                if j < _xBounds.max
                {
                    e = dataSet.entryForIndex(j + 1)
                    
                    if e == nil { break }
                    
                    if isDrawSteppedEnabled
                    {
                        _lineSegments[1] = CGPoint(x: CGFloat(e.x), y: _lineSegments[0].y)
                        _lineSegments[2] = _lineSegments[1]
                        _lineSegments[3] = CGPoint(x: CGFloat(e.x), y: CGFloat(e.y * phaseY))
                    }
                    else
                    {
                        _lineSegments[1] = CGPoint(x: CGFloat(e.x), y: CGFloat(e.y * phaseY))
                    }
                }
                else
                {
                    _lineSegments[1] = _lineSegments[0]
                }
                
                for i in 0..<_lineSegments.count
                {
                    _lineSegments[i] = chart.pixelForValues(point: _lineSegments[i], axisIndex: dataSet.axisIndex)
                }
                
                if chart.isRotated {
                    if (!viewPortHandler.isInBoundsBottom(_lineSegments[0].y))
                    {
                        break
                    }
                    
                    if !viewPortHandler.isInBoundsTop(_lineSegments[1].y)
                        || (!viewPortHandler.isInBoundsLeft(_lineSegments[0].x) && !viewPortHandler.isInBoundsRight(_lineSegments[1].x))
                    {
                        continue
                    }
                }
                else {
                    if (!viewPortHandler.isInBoundsRight(_lineSegments[0].x))
                    {
                        break
                    }
                    
                    // make sure the lines don't do shitty things outside bounds
                    if !viewPortHandler.isInBoundsLeft(_lineSegments[1].x)
                        || (!viewPortHandler.isInBoundsTop(_lineSegments[0].y) && !viewPortHandler.isInBoundsBottom(_lineSegments[1].y))
                    {
                        continue
                    }
                }
                
                // get the color that is set for this line-segment
                context?.setStrokeColor(dataSet.color(atIndex: j).cgColor)
                context?.strokeLineSegments(between: _lineSegments)
            }
        }
        else
        {
            if plotOption.isStacked
            {
                return   LineHelperFunctions.getLinearStackedPathWithNAN(barLineChart: chart, dataSet: dataSet, animator: animator, lineRenderer: self)
            }
            else{
                return  LineHelperFunctions.getLinearPathWithNAN(barLineChart: chart, dataSet: dataSet, animator: animator, lineRenderer: self)
            }
            
        }
        
        return (path,path)
    }
    
    
    // TODO: - Remove this method
    open func closePathForFill(dataSet:IChartDataSet,bounds:XBounds,matrix:CGAffineTransform,dataSetPath:CGMutablePath)
    {
        guard let chart = chart
            else { return }
        
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        let fillMin = lineDataSetOptions.fillFormatter?.getFillLinePosition(dataSet: dataSet, chart: chart) ?? 0.0
        
        var pt1 = CGPoint(x: CGFloat(dataSet.entryForIndex(bounds.min + bounds.range)?.x ?? 0.0), y: fillMin)
        var pt2 = CGPoint(x: CGFloat(dataSet.entryForIndex(bounds.min)?.x ?? 0.0), y: fillMin)
        pt1 = chart.pixelForValues(point: pt1, axisIndex: dataSet.axisIndex)
        pt2 = chart.pixelForValues(point: pt2, axisIndex: dataSet.axisIndex)
        
        dataSetPath.addLine(to: pt1)
        dataSetPath.addLine(to: pt2)
        dataSetPath.closeSubpath()
    }
    
    open func drawLinearFill(context: CGContext, dataSet: IChartDataSet, trans: Transformer, bounds: XBounds)
    {
        guard let chart = chart
        else { return }
        
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        
        let filled = generateFilledPath(
            dataSet: dataSet,
            fillMin: lineDataSetOptions.fillFormatter?.getFillLinePosition(dataSet: dataSet, chart: chart) ?? 0.0,
            bounds: bounds,
            matrix: trans.valueToPixelMatrix)
        
        if lineDataSetOptions.fill != nil
        {
            drawFilledPath(context: context, path: filled, fill: lineDataSetOptions.fill!, fillAlpha: lineDataSetOptions.fillAlpha)
        }
        else
        {
            drawFilledPath(context: context, path: filled, fillColor: lineDataSetOptions.fillColor, fillAlpha: lineDataSetOptions.fillAlpha)
        }
    }
    
    open func drawCubicFill(
        context: CGContext,
        dataSet: IChartDataSet,
        spline: CGMutablePath,
        matrix: CGAffineTransform,
        bounds: XBounds)
    {
        if bounds.range <= 0
        {
            return
        }
        
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        
        closePathForFill(dataSet: dataSet, bounds: bounds, matrix: matrix, dataSetPath: spline)
        
        if lineDataSetOptions.fill != nil
        {
            drawFilledPath(context: context, path: spline, fill: lineDataSetOptions.fill!, fillAlpha: lineDataSetOptions.fillAlpha)
        }
        else
        {
            drawFilledPath(context: context, path: spline, fillColor: lineDataSetOptions.fillColor, fillAlpha: lineDataSetOptions.fillAlpha)
        }
    }
    
    /// Generates the path that is used for filled drawing.
    fileprivate func generateFilledPath(dataSet: IChartDataSet, fillMin: CGFloat, bounds: XBounds, matrix: CGAffineTransform) -> CGPath
    {
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        let phaseY = animator?.phaseY ?? 1.0
        let isDrawSteppedEnabled = lineDataSetOptions.mode == .stepped
        let matrix = matrix
        
        var e: ChartDataEntry!
        
        let filled = CGMutablePath()
        
        e = dataSet.entryForIndex(bounds.min)
        if e != nil
        {
            filled.move(to: CGPoint(x: CGFloat(e.x), y: fillMin), transform: matrix)
            filled.addLine(to: CGPoint(x: CGFloat(e.x), y: CGFloat(e.y * phaseY)), transform: matrix)
        }
        
        // create a new path
        for x in stride(from: (bounds.min + 1), through: bounds.range + bounds.min, by: 1)
        {
            guard let e = dataSet.entryForIndex(x) else { continue }
            
            if isDrawSteppedEnabled
            {
                guard let ePrev = dataSet.entryForIndex(x-1) else { continue }
                filled.addLine(to: CGPoint(x: CGFloat(e.x), y: CGFloat(ePrev.y * phaseY)), transform: matrix)
            }
            
            filled.addLine(to: CGPoint(x: CGFloat(e.x), y: CGFloat(e.y * phaseY)), transform: matrix)
        }
        
        // close up
        e = dataSet.entryForIndex(bounds.range + bounds.min)
        if e != nil
        {
            filled.addLine(to: CGPoint(x: CGFloat(e.x), y: fillMin), transform: matrix)
        }
        filled.closeSubpath()
        
        return filled
    }
    
    // MARK: - Draw Values
    open override func drawValues(context: CGContext)
    {
        guard let chart = chart,
            let lineData = chart.data,
            let animator = animator,
            let viewPortHandler = chart.viewPortHandler
            else { return }
        
        if isDrawingValuesAllowed(dataProvider: chart)
        {
            let dataSets = lineData.dataSets
            
            let phaseY = animator.phaseY
            
            var pt = CGPoint()
            
            for i in 0 ..< dataSets.count
            {
                let dataSet = dataSets[i]
                
                guard let formatter = dataSet.valueFormatter,
                      let labelRectsforDataSet = chart.labelRectIndexMap[i],
                      shouldDrawValues(forDataSet: dataSet),
                      (dataSet.plotType == .Line || dataSet.plotType == .LineRange || dataSet.plotType == .Area),
                      let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSet.plotType]) as? AxisChartPlotOptions else {
                    continue
                }
                
                let entriesStackedYValue = LineHelperFunctions.getLineEntryStackedValue(chartViewBase: chart, plotType: dataSet.plotType)
                
                let iconsOffset = dataSet.iconsOffset
                
                _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
                
                outerLoop:for j in stride(from: _xBounds.min, through: min(_xBounds.min + _xBounds.range, _xBounds.max), by: 1)
                {
                    guard let e = dataSet.entryForIndex(j) else { break }
                    
                    guard let labelRectDict = labelRectsforDataSet[j] else
                    {
                        continue
                    }
                    
                    var count = dataSet.plotType == .LineRange ? 2 : 1
                    
                    while count > 0
                    {
                    let yVal = count == 2 ? e.y0 : e.y
                    let labelRect = count == 2 ? labelRectDict["y0"] : labelRectDict["y"]
                    count = count - 1
                    
                    pt.x = CGFloat(e.x)
                    pt.y = CGFloat(yVal * phaseY)
                        
                    if plotOption.isStacked {
                        
                        guard let stackedYvalue = entriesStackedYValue[i]?[j] else {
                            continue
                        }
                        
                        pt.y = stackedYvalue
                    }
                        
                    pt = chart.pixelForValues(point: pt, axisIndex: dataSet.axisIndex)
                        
                    if pt.x.isNaN
                    {
                        continue outerLoop
                    }
                        
                    if var labelRect = labelRect {
                        
                        labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                        
                        if let allowed = isInBounds(viewPortHandler: chart.viewPortHandler, originPoint: labelRect.origin) {
                            if allowed == 1 {
                                continue outerLoop
                            }
                            else {
                                break outerLoop
                            }
                        }
                        
                        let label = formatter.stringForValue(
                            yVal,
                            entry: e,
                            dataSetIndex: i,
                            viewPortHandler: viewPortHandler)
                            
                        let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(j)]
                        
                        drawLabel(chart: chart, label: label, labelAttributes: attributes, labelRect: labelRect)
                    }
                    
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                        ChartUtils.drawImage(context: context,
                                             image: icon,
                                             x: pt.x + iconsOffset.x,
                                             y: pt.y + iconsOffset.y,
                                             size: icon.size)
                    }
                    }
                }
            }
        }
    }
    
    // MARK: - Draw Extras
    open override func drawExtras(context: CGContext)
    {
        drawMarkerLayers(context:context)

    }
    
    func drawMarkerLayers(context:CGContext)
    {
        guard let chart = chart,
            let lineData = chart.data
            else { return }
        
        if chart.interactionAnimationInProgress
        {
            return
        }
        
        let dataSets = lineData.dataSets
        
         context.saveGState()
        
        for i in 0 ..< dataSets.count
        {
            guard let dataSet = lineData.getDataSetByIndex(i),
            (dataSet.plotType == .Line) || (dataSet.plotType == .LineRange)
            else { continue }
            
            let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
            
            if !dataSet.isVisible ||  !lineDataSetOptions.drawShapeEnabled || dataSet.entryCount == 0
            {
                continue
            }
            
            drawMarkerLayer(context:context, dataSet: dataSet, setIndex: i, lineDataSetOptions: lineDataSetOptions)
        }
        
        context.restoreGState()
    }
    
    func drawMarkerLayer(context:CGContext, dataSet: IChartDataSet, setIndex: Int, lineDataSetOptions: LineDataSetOptions) {
        
        guard let chart = chart
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
        
        for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
        {
            guard let e = dataSet.entryForIndex(j) else { break }
            
            if dataSet.plotType == .Line || dataSet.plotType == .Area {
                if  e.y.isNaN || e.x.isNaN || e.filterEnabled {
                    continue
                }
                let returnValue = renderMarkerLayer(context: context, yVal: e.y, entryIndex: j, setIndex: setIndex, lineDataSetOptions: lineDataSetOptions, chart: chart, valueToPixelMatrix: valueToPixelMatrix)
                if returnValue == -1{ break} else{ continue}
            }
            
            if dataSet.plotType == .LineRange {
                if (e.y.isNaN && e.y0.isNaN) || e.x.isNaN || e.filterEnabled {
                    continue
                }
                if !(e.y.isNaN)
                {
                    let returnValue = renderMarkerLayer(context: context, yVal: e.y, entryIndex: j, setIndex: setIndex, lineDataSetOptions: lineDataSetOptions, chart: chart, valueToPixelMatrix: valueToPixelMatrix)
                    if returnValue == -1{ break} else if returnValue == 0{ continue}
                }
                if !(e.y0.isNaN){
                    let returnValue = renderMarkerLayer(context: context, yVal: e.y0, entryIndex: j, setIndex: setIndex, lineDataSetOptions: lineDataSetOptions, chart: chart, valueToPixelMatrix: valueToPixelMatrix)
                    if returnValue == -1{ break} else if returnValue == 0{ continue}
                }
            }
            
        }
    }
    
    
    fileprivate func renderMarkerLayer(context:CGContext, yVal:Double, entryIndex:Int, setIndex:Int, lineDataSetOptions: LineDataSetOptions, chart:ChartViewBase, valueToPixelMatrix:CGAffineTransform) -> Int
    {
        guard let lineData = chart.data,
            let animator = animator,
            let viewPortHandler = chart.viewPortHandler,
            let dataSet = lineData.getDataSetByIndex(setIndex),
              let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSet.plotType]) as? LinePlotOptions,
            let e = dataSet.entryForIndex(entryIndex)
            else { return -1 }
        
        let i = setIndex
        
        let j = entryIndex
        
        let entriesStackedYValue = LineHelperFunctions.getLineEntryStackedValue(chartViewBase: chart, plotType: dataSet.plotType)
        
        let phaseY = animator.phaseY
        
        var pt = CGPoint()
        
        pt.x = CGFloat(e.x)
        pt.y = CGFloat(yVal * phaseY)
        pt = chart.pixelForValues(point: pt, axisIndex: dataSet.axisIndex)
        
        if plotOption.isStacked
        {
            guard let stackValue = entriesStackedYValue[i]?[j]
            else { return 0 }
            pt = chart.pixelForValues(point: CGPoint(x: e.x, y: stackValue * phaseY), axisIndex: dataSet.axisIndex)
        }
        
        if useForcedValue
        {
            if e.centerChanged != nil
            {
                pt = e.centerChanged!
            }
        }
        
        if chart.isRotated {
            if (chart.xAxis.isInverted) {
                if !viewPortHandler.isInBoundsTop(pt.y)
                {
                    return -1
                }
            }else {
                if !viewPortHandler.isInBoundsBottom(pt.y)
                {
                    return -1
                }
            }
                
            if ((!viewPortHandler.isInBoundsTop(pt.y) || !viewPortHandler.isInBoundsBottom(pt.y) || !viewPortHandler.isInBoundsX(pt.x))) {
                return 0
            }
        }
        else {
            if (chart.xAxis.isInverted) {
                if (!viewPortHandler.isInBoundsLeft(pt.x))
                {
                    return -1
                }
            }else {
                if (!viewPortHandler.isInBoundsRight(pt.x))
                {
                    return -1
                }
            }
            
            // make sure the circles don't do shitty things outside bounds
            if (!viewPortHandler.isInBoundsLeft(pt.x) || !viewPortHandler.isInBoundsRight(pt.x) || !viewPortHandler.isInBoundsY(pt.y))
            {
                return 0
            }
        }
        
        let markerLayer = CAShapeLayer()
        
        let shapePath:CGPath
        
        if lineDataSetOptions.markerInstance.shapeType == .custom
        {
            shapePath = ((lineDataSetOptions.markerInstance.customPathDataSource?.shapePath?(point: pt, shapeInstance: lineDataSetOptions.markerInstance, shapeLayer: markerLayer))) ?? ShapeFactory.getPath(point: pt, shapeInstance: lineDataSetOptions.markerInstance)
        }
        else{
            shapePath = ShapeFactory.getPath(point: pt, shapeInstance: lineDataSetOptions.markerInstance)
        }
        
        let shapeStrokeSize = lineDataSetOptions.markerInstance.lineWidth
        
        
        if (chart.includeLayer)
        {
            markerLayer.path = shapePath
            markerLayer.fillColor = lineDataSetOptions.markerInstance.holeColor?.cgColor
            markerLayer.strokeColor = lineDataSetOptions.getShapeColor(atIndex: j)?.cgColor ?? NSUIColor.clear.cgColor
            markerLayer.lineWidth = CGFloat(shapeStrokeSize)
            markerLayer.lineCap =  convertToCAShapeLayerLineCap("round")
                
            if (chart.customAnimationInProgress)
            {
                markerLayer.opacity = 0
            }
            
            guard let setInstance = dataSet as? ChartDataSet,
                  let lineLayer = LineLayer.getLayerForDataset(chart: chart, lineChartDataSet:setInstance)
            else { return 0}
            
            lineLayer.addSublayer(markerLayer)
            
            lineLayer.markerShapeLayerIndex[j] = (((lineLayer.sublayers?.count) ?? 1)  - 1)
            
        }
        else{
        context.setLineWidth(shapeStrokeSize)
        context.setLineCap(lineDataSetOptions.markerInstance.lineCapType)
        context.beginPath()
        context.addPath(shapePath)
            context.setFillColor((lineDataSetOptions.markerInstance.holeColor)?.cgColor ?? NSUIColor.clear.cgColor)
        context.fillPath()
        context.addPath(shapePath)
            context.setStrokeColor(lineDataSetOptions.getShapeColor(atIndex: j)?.cgColor ?? NSUIColor.black.cgColor)
        context.strokePath()
            
        }
        return 1
    }
    
    fileprivate func drawCircles(context: CGContext)
    {
        guard let chart = chart,
            let lineData = chart.data,
            let animator = animator,
            let viewPortHandler = chart.viewPortHandler
            else { return }
        
        let phaseY = animator.phaseY
        
        let dataSets = lineData.dataSets
        
        var pt = CGPoint()
        var rect = CGRect()
        
        context.saveGState()
        
        for i in 0 ..< dataSets.count
        {
            guard let dataSet = lineData.getDataSetByIndex(i),
                  (dataSet.plotType == .Line) || (dataSet.plotType == .LineRange) || (dataSet.plotType == .Area)
                else { continue }
            
            let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
            
            if !dataSet.isVisible || !lineDataSetOptions.isDrawCirclesEnabled || !lineDataSetOptions.drawShapeEnabled || dataSet.entryCount == 0
            {
                continue
            }
            
            let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
            let valueToPixelMatrix = trans.valueToPixelMatrix
            
            _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
            
            let circleRadius = lineDataSetOptions.circleRadius
            let circleDiameter = circleRadius * 2.0
            let circleHoleRadius = lineDataSetOptions.circleHoleRadius
            let circleHoleDiameter = circleHoleRadius * 2.0
            
            let drawCircleHole = lineDataSetOptions.isDrawCircleHoleEnabled &&
                circleHoleRadius < circleRadius &&
                circleHoleRadius > 0.0
            let drawTransparentCircleHole = drawCircleHole &&
                (lineDataSetOptions.circleHoleColor == nil ||
                    lineDataSetOptions.circleHoleColor == NSUIColor.clear)
            
            for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
            {
                guard let e = dataSet.entryForIndex(j) else { break }

                pt.x = CGFloat(e.x)
                pt.y = CGFloat(e.y * phaseY)
                pt = pt.applying(valueToPixelMatrix)
                
                if (!viewPortHandler.isInBoundsRight(pt.x))
                {
                    break
                }
                
                // make sure the circles don't do shitty things outside bounds
                if (!viewPortHandler.isInBoundsLeft(pt.x) || !viewPortHandler.isInBoundsY(pt.y))
                {
                    continue
                }
                
                context.setFillColor(lineDataSetOptions.getCircleColor(atIndex: j)?.cgColor ?? NSUIColor.clear.cgColor)
                
                rect.origin.x = pt.x - circleRadius
                rect.origin.y = pt.y - circleRadius
                rect.size.width = circleDiameter
                rect.size.height = circleDiameter
                
                if drawTransparentCircleHole
                {
                    // Begin path for circle with hole
                    context.beginPath()
                    context.addEllipse(in: rect)
                    
                    // Cut hole in path
                    rect.origin.x = pt.x - circleHoleRadius
                    rect.origin.y = pt.y - circleHoleRadius
                    rect.size.width = circleHoleDiameter
                    rect.size.height = circleHoleDiameter
                    context.addEllipse(in: rect)
                    
                    // Fill in-between
                    context.fillPath(using: .evenOdd)
                }
                else
                {
                    context.fillEllipse(in: rect)
                    
                    if drawCircleHole
                    {
                        context.setFillColor(lineDataSetOptions.circleHoleColor?.cgColor ?? NSUIColor.clear.cgColor)
                     
                        // The hole rect
                        rect.origin.x = pt.x - circleHoleRadius
                        rect.origin.y = pt.y - circleHoleRadius
                        rect.size.width = circleHoleDiameter
                        rect.size.height = circleHoleDiameter
                        
                        context.fillEllipse(in: rect)
                    }
                }
            }
        }
        
        context.restoreGState()
    }
    
    open override func drawHighlighted(context: CGContext, indices: [Highlight])
    {
        guard let chart = chart,
            let lineData = chart.data,
            let animator = animator
            else { return }
        
        let chartXMax = chart.chartXMax
        
        context.saveGState()
        
        for high in indices
        {
            guard let set = lineData.getDataSetByIndex(high.dataSetIndex)
                , set.isHighlightEnabled
                else { continue }
            
            guard let e = set.entryForXValue(high.x, closestToY: high.y) else { continue }
            
            if !isInBoundsX(entry: e, dataSet: set)
            {
                continue
            }
        
            let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: set)
            
            context.setStrokeColor(lineDataSetOptions.highlightColor.cgColor)
            context.setLineWidth(lineDataSetOptions.highlightLineWidth)
            if lineDataSetOptions.highlightLineDashLengths != nil
            {
                context.setLineDash(phase: lineDataSetOptions.highlightLineDashPhase, lengths: lineDataSetOptions.highlightLineDashLengths!)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
            
            let x = high.x // get the x-position
            let y = high.y * Double(animator.phaseY)
            
            if x > chartXMax * animator.phaseX
            {
                continue
            }
            
            let trans = chart.getTransformer(axisIndex: set.axisIndex)
            
            let pt = trans.pixelForValues(x: x, y: y)
            
            high.setDraw(pt: pt)
            
            // draw the lines//Commented since drawHighlighted is not used anymore
//            drawHighlightLines(context: context, point: pt, set: set)
        }
        
        context.restoreGState()
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCAShapeLayerLineCap(_ input: String) -> CAShapeLayerLineCap {
	return CAShapeLayerLineCap(rawValue: input)
}
