//
//  SankyChartRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 15/09/22.
//


import Foundation
import CoreGraphics

#if !os(OSX)
import UIKit
#endif

open class SankeyChartRenderer: DataRenderer
{
    open override func drawData(context: CGContext)
    {
        drawRenderer(context: context)
    }
    func getWidth(value:CGFloat,chart:ChartViewBase) -> CGFloat
    {
        
        var start = CGPoint(x: 0, y: 0)
        var end = CGPoint(x: value, y: value)
        chart.plotTransformer.pointValueToPixel(&start)
        chart.plotTransformer.pointValueToPixel(&end)
        
        return abs(end.x - start.x)
        
    }
    
    open func drawRenderer(context: CGContext)
    {
        guard
            let chart = chart,
            let processor = chart.getProcessor(type: .Sanky) as? SankeyPreprocessor,
            let chartData = chart.data,
            let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
            else { return }
        
            let finalArray = processor.dataValues
        
            for arrayVal in finalArray {
            
                guard let parentObject = arrayVal as? NSDictionary,
                      let nodeObject = parentObject["nodes"] as? [NSDictionary],
                      let linkObject = parentObject["links"] as? [NSDictionary]
                else { continue }
                
                
                
                var nodeToColor:[String:Int] = [:]
                
                var firstX = CGFloat.greatestFiniteMagnitude
                var lastX = CGFloat.leastNormalMagnitude
                
                var firstLinkX = CGFloat.greatestFiniteMagnitude
                var lastLinkX = CGFloat.leastNormalMagnitude
                
                var nodeCount = 0
                var nodeCountDict:[Double:Int] = [:]
                
                for object in nodeObject
                {
                    guard let x0Value = object["x0"] as? CGFloat,
                          let x1Value = object["x1"] as? CGFloat
                    else { continue }
                    
                    firstX = min(firstX,x0Value)
                    lastX = max(lastX,x1Value)
                    
                    if nodeCountDict[x0Value] == nil
                    {
                        nodeCount += 1
                        nodeCountDict[x0Value] = 1
                    }
                }
                
                for object in linkObject
                {
                    guard let x0Value = (object["source"] as? NSDictionary)?["x1"] as? CGFloat,
                          let x1Value = (object["target"] as? NSDictionary)?["x0"] as? CGFloat
                    else { continue }
                    
                    firstLinkX = min(firstLinkX ,x0Value)
                    lastLinkX = max(lastLinkX ,x1Value)
                }
                
                let currentNodeWidth = getWidth(value: plotOption.maxNodeWidth, chart: chart)
                
                var requiredNodeWidth = getWidth(value: processor.updatedNodeWidth, chart: chart)
                
                if requiredNodeWidth > plotOption.maxNodeWidth
                {
                    requiredNodeWidth = plotOption.maxNodeWidth
                }
                
                let toAdjust:CGFloat = currentNodeWidth - requiredNodeWidth
                let toAdjustHalf:CGFloat = toAdjust/2
                
                for object in nodeObject
                {
                    guard let nodeName = object["name"] as? String,
                    let x0Value = object["x0"] as? CGFloat,
                    let x1Value = object["x1"] as? CGFloat,
                    let y0Value = object["y0"] as? CGFloat,
                    let y1Value = object["y1"] as? CGFloat
                    else { continue }
                    
                    let index = SankeyHelperFunctions
                        .getColorIndexForNodeName(chartData: chartData,nodeName: nodeName) ?? 0
                    
                    var newRect:[RectPoints:CGPoint] = [:]
                    newRect[.topLeft] = CGPoint(x: x0Value, y: y0Value)
                    newRect[.bottomLeft] = CGPoint(x: x0Value, y: y1Value)
                    newRect[.topRight] = CGPoint(x: x1Value, y: y0Value)
                    newRect[.bottomRight] = CGPoint(x: x1Value, y: y1Value)
                    
                    transformRectPoints(rectPoints: &newRect)
                    
                    if firstX != CGFloat.greatestFiniteMagnitude && firstX == x0Value
                    {
                        newRect[.topRight]?.x -= toAdjust
                        newRect[.bottomRight]?.x -= toAdjust
                    }
                    else if lastX != CGFloat.greatestFiniteMagnitude && lastX == x1Value
                    {
                        newRect[.topLeft]?.x += toAdjust
                        newRect[.bottomLeft]?.x += toAdjust
                    }
                    else{
                        newRect[.topLeft]?.x += toAdjustHalf
                        newRect[.bottomLeft]?.x += toAdjustHalf
                        newRect[.topRight]?.x -= toAdjustHalf
                        newRect[.bottomRight]?.x -= toAdjustHalf
                    }
                    
                    let nodeLayer = SankyLayers(chartView: chart, nodeName: nodeName, dataSet: chartData.dataSets[0], type: .Node, rect: newRect, index:index)
                    nodeToColor[nodeName] = index
                    
                    if customOpacity {
                        if let entry = SankeyHelperFunctions.getEntryForEnabledNodename(data: chartData, nameNode: nodeName) {
                            
                            let opacity = 1.0 * (entry.opacityChanged / Float(plotOption.linkOpacity))
                            nodeLayer.opacity = opacity
                        }
                    }
                }
                
                for link in linkObject
                {
                    guard let sourceName = (link["source"] as? NSDictionary)?["name"] as? String,
                          let sourceX = (link["source"] as? NSDictionary)?["x1"] as? CGFloat,
                          let linkIndex = link["entryIndex"] as? Int,
                          let entry = chartData.dataSets[0].entryForIndex(linkIndex),
                          let linkTopLeft = (link["y0"] as? CGFloat),
                          let linkTopRight = (link["y1"] as? CGFloat),
                          let targetX = (link["target"] as? NSDictionary)?["x0"] as? CGFloat,
                          let linkWidth = (link["width"] as? CGFloat),
                          let isCircular = (link["circular"] as? Bool)
                    else { continue }
                    
                    if isCircular
                    {
                        guard let circularType = (link["circularLinkType"] as? String),
                              let pathDict = (link["circularPathData"] as? NSDictionary) else {
                            continue
                        }
                        
                        if let circularLinkPath = SankeyHelperFunctions.constructCircularLink(chart: chart,circularType: circularType, pathDict: pathDict, linkWidth: linkWidth, linkPadding: plotOption.linkPadding,firstLinkX: firstLinkX, lastLinkX: lastLinkX, toAdjustHalf: toAdjustHalf, firstNodeX:firstX, lastNodeX:lastX) {
                            
                            let linkLayer = SankyLayers(chartView: chart, chartEntry: entry, dataSet: chartData.dataSets[0], type: .CircularLink, path: circularLinkPath, index: nodeToColor[sourceName] ?? 0)
                            
                            if customOpacity {
                                
                                let setColors = chartData.dataSets[0].colors
                                let index = nodeToColor[sourceName] ?? 0
                                
                                linkLayer.fillColor = setColors[index%setColors.count].withAlphaComponent(CGFloat(entry.opacityChanged)).cgColor
                            }
                        }
                    }
                    else {
                        let halfWidth = linkWidth/2
                        let x0 = sourceX
                        let y0 = linkTopLeft - halfWidth
                        let x1 = targetX
                        let y1 = linkTopRight - halfWidth
                        
                        var newRect:[RectPoints:CGPoint] = [:]
                        newRect[.topLeft] = CGPoint(x: x0, y: y0)
                        newRect[.bottomLeft] = CGPoint(x: x0, y: y0+linkWidth)
                        newRect[.topRight] = CGPoint(x: x1, y: y1)
                        newRect[.bottomRight] = CGPoint(x: x1, y: y1+linkWidth)
                        
                        transformRectPoints(rectPoints: &newRect)
                        
                        if (firstLinkX != CGFloat.greatestFiniteMagnitude && firstLinkX == x0) && (lastLinkX != CGFloat.greatestFiniteMagnitude && lastLinkX == x1)
                        {
                            newRect[.topLeft]?.x += plotOption.linkPadding - toAdjust
                            newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjust
                            newRect[.topRight]?.x -= plotOption.linkPadding - toAdjust
                            newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjust
                        }
                        else if firstLinkX != CGFloat.greatestFiniteMagnitude && firstLinkX == x0
                        {
                            newRect[.topLeft]?.x += plotOption.linkPadding - toAdjust
                            newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjust
                            newRect[.topRight]?.x -= plotOption.linkPadding - toAdjustHalf
                            newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjustHalf
                        }
                        else if lastLinkX != CGFloat.greatestFiniteMagnitude && lastLinkX == x1
                        {
                            newRect[.topLeft]?.x += plotOption.linkPadding - toAdjustHalf
                            newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjustHalf
                            newRect[.topRight]?.x -= plotOption.linkPadding - toAdjust
                            newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjust
                        }
                        else{
                            newRect[.topLeft]?.x += plotOption.linkPadding - toAdjustHalf
                            newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjustHalf
                            newRect[.topRight]?.x -= plotOption.linkPadding - toAdjustHalf
                            newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjustHalf
                        }
                        
                        
                        let linkLayer = SankyLayers(chartView: chart, chartEntry: entry, dataSet: chartData.dataSets[0], type: .Link, rect: newRect, index: nodeToColor[sourceName] ?? 0)
                            
                        if customOpacity {
                            
                            let setColors = chartData.dataSets[0].colors
                            let index = nodeToColor[sourceName] ?? 0
                            
                            linkLayer.fillColor = setColors[index%setColors.count].withAlphaComponent(CGFloat(entry.opacityChanged)).cgColor
                        }
                    }
                }
            
            }
    }

   
    open override func drawValues(context: CGContext)
    {
       guard
           let chart = chart,
           let chartData = chart.data,
           let viewPortHandler = viewPortHandler,
           let sankeyPlotoption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
           else { return }
        
           let setIndex = 0
           let set = chartData.dataSets[setIndex]
        
        if !shouldDrawValues(forDataSet: set) || !(set.isDrawValuesEnabled) || chart.interactionAnimationInProgress
           {
                return
           }
        
           let valueFont = chartData.dataSets[setIndex].valueFont
           let valueTextColor = chartData.dataSets[setIndex].valueTextColorAt(0)
        
           let attributes = [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
        
        let categorisedNodeLayers = SankeyHelperFunctions.getCategorisedNodeByX(chartview: chart)
        
        for (index,xPos) in categorisedNodeLayers.keys.sorted().enumerated() {
            
            let drawDataLabelCenteredEnabled = index != 0 && index != categorisedNodeLayers.keys.count - 1
            
            guard let categorisedNodeLayers = categorisedNodeLayers[xPos] else {
                continue
            }
            
            for nodeLayer in categorisedNodeLayers {
                
                let valueTextLayer = ValueTextLayer()
                
                guard let xRight = nodeLayer.rectPoints[.topRight]?.x,
                      let xLeft = nodeLayer.rectPoints[.topLeft]?.x,
                      let valtopY = (nodeLayer.rectPoints[.topRight]?.y),
                      let valbottomY = (nodeLayer.rectPoints[.bottomRight]?.y)
                else { continue }
                
                var y = (valtopY+valbottomY)/2
                
                if y.isNaN {
                    continue
                }
                
                let label = set.valueFormatter?.getFormattedValue?(entry: nil, nodeName: nodeLayer.nodeName) ?? nodeLayer.nodeName
                
                var valueTextSize = label.size(withAttributes: attributes)
                
                y -= (valueTextSize.height / 2.0)
                
                var rect: CGRect
                var point: CGPoint
                var constrainedWidth = -1.0
                let valueOffset = 5.0
                
                if sankeyPlotoption.drawDataLabelCenteredEnabled || drawDataLabelCenteredEnabled {
                    if sankeyPlotoption.dataValuesTrancateMode != .none {
                        valueTextSize = CGSize(width: min((xRight - xLeft), valueTextSize.width), height: valueTextSize.height)
                        constrainedWidth = valueTextSize.width
                    }
                    let midX = xLeft + (xRight - xLeft) / 2.0
                    point = CGPoint(x: midX - valueTextSize.width / 2.0, y: y)
                }
                else if index == 0 {
                    point = CGPoint(x: xRight + valueOffset, y: y)
                }
                else {
                    point = CGPoint(x: xLeft - valueTextSize.width - valueOffset, y: y)
                }
                
                if !drawDataLabelCenteredEnabled {
                    SankeyChartRenderer.alignDataLabel(chart: chart, translatedOrigin: &point, labelSize: valueTextSize)
                }
                
                rect = CGRect(origin: point, size: valueTextSize)
                
                if chartData.dataLabelRenderingMode == .showAll || !isDataLabelOverlapping(rect: rect) {
                    let textLayer = ChartUtils.drawTextLayer(
                     text: label,
                     point: point,
                     align: .right,
                     attributes: attributes,
                     constrainedToWidth: constrainedWidth, truncationMode: sankeyPlotoption.dataValuesTrancateMode)
                    
                    valueTextLayer.addSublayer(textLayer)
                    chart.plotView?.nsuiLayer?.addSublayer(valueTextLayer)
                    chart.labelRects?.append(rect)
                }
            }
        }
    }
    
    open override func drawExtras(context: CGContext)
    {
     
    }
    
    func transformRectPoints(rectPoints: inout [RectPoints:CGPoint]) {
        
        guard let chart = chart else {
            return
        }
        
        chart.plotTransformer.pointValueToPixel(&rectPoints[.topLeft]!)
        chart.plotTransformer.pointValueToPixel(&rectPoints[.bottomLeft]!)
        chart.plotTransformer.pointValueToPixel(&rectPoints[.topRight]!)
        chart.plotTransformer.pointValueToPixel(&rectPoints[.bottomRight]!)
        
    }
    
    //Working Good
    /*
     open func drawRenderer(context: CGContext)
     {
         guard
             let chart = chart,
             let processor = chart.getProcessor(type: .Sanky) as? SankeyPreprocessor,
             let chartData = chart.data,
             let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
             else { return }
         
             let finalArray = processor.dataValues
         
             for arrayVal in finalArray {
             
                 guard let parentObject = arrayVal as? NSDictionary,
                       let nodeObject = parentObject["nodes"] as? [NSDictionary],
                       let linkObject = parentObject["links"] as? [NSDictionary]
                 else { continue }
                 
                 
                 
                 var nodeToColor:[String:Int] = [:]
                 
                 var firstX = CGFloat.greatestFiniteMagnitude
                 var lastX = CGFloat.leastNormalMagnitude
                 
                 var firstLinkX = CGFloat.greatestFiniteMagnitude
                 var lastLinkX = CGFloat.leastNormalMagnitude
                 
                 var nodeCount = 0
                 var nodeCountDict:[Double:Int] = [:]
                 
                 for object in nodeObject
                 {
                     guard let x0Value = object["x0"] as? CGFloat,
                           let x1Value = object["x1"] as? CGFloat
                     else { continue }
                     
                     firstX = min(firstX,x0Value)
                     lastX = max(lastX,x1Value)
                     
                     if nodeCountDict[x0Value] == nil
                     {
                         nodeCount += 1
                         nodeCountDict[x0Value] = 1
                     }
                 }
                 
                 for object in linkObject
                 {
                     guard let x0Value = (object["source"] as? NSDictionary)?["x1"] as? CGFloat,
                           let x1Value = (object["target"] as? NSDictionary)?["x0"] as? CGFloat
                     else { continue }
                     
                     firstLinkX = min(firstLinkX ,x0Value)
                     lastLinkX = max(lastLinkX ,x1Value)
                 }
                 
                 let currentNodeWidth = getWidth(value: plotOption.maxNodeWidth, chart: chart)
                 
                 var requiredNodeWidth = getWidth(value: processor.updatedNodeWidth, chart: chart)
                 
                 if requiredNodeWidth > plotOption.maxNodeWidth
                 {
                     requiredNodeWidth = plotOption.maxNodeWidth
                 }
                 
                 let toAdjust:CGFloat = currentNodeWidth - requiredNodeWidth
                 let toAdjustHalf:CGFloat = toAdjust/2
                 
                 for object in nodeObject
                 {
                     guard let nodeName = object["name"] as? String,
                     let x0Value = object["x0"] as? CGFloat,
                     let x1Value = object["x1"] as? CGFloat,
                     let y0Value = object["y0"] as? CGFloat,
                     let y1Value = object["y1"] as? CGFloat
                     else { continue }
                     
                     let index = SankeyHelperFunctions
                         .getColorIndexForNodeName(chartData: chartData,nodeName: nodeName) ?? 0
                     
                     var newRect:[RectPoints:CGPoint] = [:]
                     newRect[.topLeft] = CGPoint(x: x0Value, y: y0Value)
                     newRect[.bottomLeft] = CGPoint(x: x0Value, y: y1Value)
                     newRect[.topRight] = CGPoint(x: x1Value, y: y0Value)
                     newRect[.bottomRight] = CGPoint(x: x1Value, y: y1Value)
                     
                     transformRectPoints(rectPoints: &newRect)
                     
                     if firstX != CGFloat.greatestFiniteMagnitude && firstX == x0Value
                     {
                         newRect[.topRight]?.x -= toAdjust
                         newRect[.bottomRight]?.x -= toAdjust
                     }
                     else if lastX != CGFloat.greatestFiniteMagnitude && lastX == x1Value
                     {
                         newRect[.topLeft]?.x += toAdjust
                         newRect[.bottomLeft]?.x += toAdjust
                     }
                     else{
                         newRect[.topLeft]?.x += toAdjustHalf
                         newRect[.bottomLeft]?.x += toAdjustHalf
                         newRect[.topRight]?.x -= toAdjustHalf
                         newRect[.bottomRight]?.x -= toAdjustHalf
                     }
                     
                     let nodeLayer = SankyLayers(chartView: chart, nodeName: nodeName, dataSet: chartData.dataSets[0], type: .Node, rect: newRect, index:index)
                     nodeToColor[nodeName] = index
                     
                     if customOpacity {
                         if let entry = SankeyHelperFunctions.getEntryForEnabledNodename(data: chartData, nameNode: nodeName) {
                             
                             let opacity = 1.0 * (entry.opacityChanged / Float(plotOption.linkOpacity))
                             nodeLayer.opacity = opacity
                         }
                     }
                 }
                 
                 for link in linkObject
                 {
                     guard let sourceName = (link["source"] as? NSDictionary)?["name"] as? String,
                           let sourceX = (link["source"] as? NSDictionary)?["x1"] as? CGFloat,
                           let linkIndex = link["entryIndex"] as? Int,
                           let entry = chartData.dataSets[0].entryForIndex(linkIndex),
                           let linkTopLeft = (link["y0"] as? CGFloat),
                           let linkTopRight = (link["y1"] as? CGFloat),
                           let targetX = (link["target"] as? NSDictionary)?["x0"] as? CGFloat,
                           let linkWidth = (link["width"] as? CGFloat),
                           let isCircular = (link["circular"] as? Bool)
                     else { continue }
                     
                     if isCircular
                     {
                         guard let circularType = (link["circularLinkType"] as? String),
                               let pathDict = (link["circularPathData"] as? NSDictionary) else {
                             continue
                         }
                         
                         if let circularLinkPath = SankeyHelperFunctions.constructCircularLink(chart: chart,circularType: circularType, pathDict: pathDict, linkWidth: linkWidth, linkPadding: plotOption.linkPadding) {
                             
                             let linkLayer = SankyLayers(chartView: chart, chartEntry: entry, dataSet: chartData.dataSets[0], type: .CircularLink, path: circularLinkPath, index: nodeToColor[sourceName] ?? 0)
                             
                             if customOpacity {
                                 
                                 let setColors = chartData.dataSets[0].colors
                                 let index = nodeToColor[sourceName] ?? 0
                                 
                                 linkLayer.fillColor = setColors[index%setColors.count].withAlphaComponent(CGFloat(entry.opacityChanged)).cgColor
                             }
                         }
                     }
                     else {
                         let halfWidth = linkWidth/2
                         let x0 = sourceX
                         let y0 = linkTopLeft - halfWidth
                         let x1 = targetX
                         let y1 = linkTopRight - halfWidth
                         
                         var newRect:[RectPoints:CGPoint] = [:]
                         newRect[.topLeft] = CGPoint(x: x0, y: y0)
                         newRect[.bottomLeft] = CGPoint(x: x0, y: y0+linkWidth)
                         newRect[.topRight] = CGPoint(x: x1, y: y1)
                         newRect[.bottomRight] = CGPoint(x: x1, y: y1+linkWidth)
                         
                         transformRectPoints(rectPoints: &newRect)
                         
                         if firstLinkX != CGFloat.greatestFiniteMagnitude && firstLinkX == x0
                         {
                             newRect[.topLeft]?.x += plotOption.linkPadding - toAdjust
                             newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjust
                             newRect[.topRight]?.x -= plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjustHalf
                         }
                         else if lastLinkX != CGFloat.greatestFiniteMagnitude && lastLinkX == x1
                         {
                             newRect[.topLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.topRight]?.x -= plotOption.linkPadding - toAdjust
                             newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjust
                         }
                         else{
                             newRect[.topLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.topRight]?.x -= plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjustHalf
                         }
                         
                         
                         let linkLayer = SankyLayers(chartView: chart, chartEntry: entry, dataSet: chartData.dataSets[0], type: .Link, rect: newRect, index: nodeToColor[sourceName] ?? 0)
                             
                         if customOpacity {
                             
                             let setColors = chartData.dataSets[0].colors
                             let index = nodeToColor[sourceName] ?? 0
                             
                             linkLayer.fillColor = setColors[index%setColors.count].withAlphaComponent(CGFloat(entry.opacityChanged)).cgColor
                         }
                     }
                 }
             
             }
     }
     */
    // Perfect
    /*
     open func drawRenderer(context: CGContext)
     {
         guard
             let chart = chart,
             let processor = chart.getProcessor(type: .Sanky) as? SankeyPreprocessor,
             let chartData = chart.data,
             let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions
             else { return }
         
             let finalArray = processor.dataValues
         
             let actualWidthInterPolator = Interpolator.interpolate(a: plotOption.maxNodeWidth, b: plotOption.minNodeWidth)
         
             let nodeWidthInterpolateStartPercent = plotOption.nodeWidthInterpolateStartPercent
             let nodeWidthInterpolateEndPercent = plotOption.nodeWidthInterpolateEndPercent
             
         
             for arrayVal in finalArray {
             
                 guard let parentObject = arrayVal as? NSDictionary,
                       let nodeObject = parentObject["nodes"] as? [NSDictionary],
                       let linkObject = parentObject["links"] as? [NSDictionary]
                 else { continue }
                 
                 
                 
                 var nodeToColor:[String:Int] = [:]
                 
                 var firstX = CGFloat.greatestFiniteMagnitude
                 var lastX = CGFloat.leastNormalMagnitude
                 
                 var firstLinkX = CGFloat.greatestFiniteMagnitude
                 var lastLinkX = CGFloat.leastNormalMagnitude
                 
                 var nodeCount = 0
                 var nodeCountDict:[Double:Int] = [:]
                 
                 for object in nodeObject
                 {
                     guard let x0Value = object["x0"] as? CGFloat,
                           let x1Value = object["x1"] as? CGFloat
                     else { continue }
                     
                     firstX = min(firstX,x0Value)
                     lastX = max(lastX,x1Value)
                     
                     if nodeCountDict[x0Value] == nil
                     {
                         nodeCount += 1
                         nodeCountDict[x0Value] = 1
                     }
                 }
                 
                 for object in linkObject
                 {
                     guard let x0Value = (object["source"] as? NSDictionary)?["x1"] as? CGFloat,
                           let x1Value = (object["target"] as? NSDictionary)?["x0"] as? CGFloat
                     else { continue }
                     
                     firstLinkX = min(firstLinkX ,x0Value)
                     lastLinkX = max(lastLinkX ,x1Value)
                 }
                 
                 let viewWidth = getWidth(value: chart.viewPortHandler.contentWidth, chart: chart)
                 
                 let currentNodeWidth = getWidth(value: plotOption.maxNodeWidth, chart: chart)
                 
                 let totalNodeWidth = CGFloat(nodeCount) * plotOption.maxNodeWidth
                 
                 let currentPercent = (totalNodeWidth/viewWidth)*100
                 var widthPercent = Interpolator.precentage(a: nodeWidthInterpolateStartPercent, b: nodeWidthInterpolateEndPercent, value: currentPercent)
                 widthPercent = (widthPercent < 0) ? 0 : ((widthPercent > 1) ? 1 : widthPercent)
                 
                 let toAdjust:CGFloat = currentNodeWidth - actualWidthInterPolator(widthPercent)
                 let toAdjustHalf:CGFloat = toAdjust/2
                 
                 
                 for object in nodeObject
                 {
                     guard let nodeName = object["name"] as? String,
                     let x0Value = object["x0"] as? CGFloat,
                     let x1Value = object["x1"] as? CGFloat,
                     let y0Value = object["y0"] as? CGFloat,
                     let y1Value = object["y1"] as? CGFloat
                     else { continue }
                     
                     let index = SankeyHelperFunctions
                         .getColorIndexForNodeName(chartData: chartData,nodeName: nodeName) ?? 0
                     
                     var newRect:[RectPoints:CGPoint] = [:]
                     newRect[.topLeft] = CGPoint(x: x0Value, y: y0Value)
                     newRect[.bottomLeft] = CGPoint(x: x0Value, y: y1Value)
                     newRect[.topRight] = CGPoint(x: x1Value, y: y0Value)
                     newRect[.bottomRight] = CGPoint(x: x1Value, y: y1Value)
                     
                     transformRectPoints(rectPoints: &newRect)
                     
                     if firstX != CGFloat.greatestFiniteMagnitude && firstX == x0Value
                     {
                         newRect[.topRight]?.x -= toAdjust
                         newRect[.bottomRight]?.x -= toAdjust
                     }
                     else if lastX != CGFloat.greatestFiniteMagnitude && lastX == x1Value
                     {
                         newRect[.topLeft]?.x += toAdjust
                         newRect[.bottomLeft]?.x += toAdjust
                     }
                     else{
                         newRect[.topLeft]?.x += toAdjustHalf
                         newRect[.bottomLeft]?.x += toAdjustHalf
                         newRect[.topRight]?.x -= toAdjustHalf
                         newRect[.bottomRight]?.x -= toAdjustHalf
                     }
                     
                     let nodeLayer = SankyLayers(chartView: chart, nodeName: nodeName, dataSet: chartData.dataSets[0], type: .Node, rect: newRect, index:index)
                     nodeToColor[nodeName] = index
                     
                     if customOpacity {
                         if let entry = SankeyHelperFunctions.getEntryForEnabledNodename(data: chartData, nameNode: nodeName) {
                             
                             let opacity = 1.0 * (entry.opacityChanged / Float(plotOption.linkOpacity))
                             nodeLayer.opacity = opacity
                         }
                     }
                 }
                 
                 for link in linkObject
                 {
                     guard let sourceName = (link["source"] as? NSDictionary)?["name"] as? String,
                           let sourceX = (link["source"] as? NSDictionary)?["x1"] as? CGFloat,
                           let linkIndex = link["entryIndex"] as? Int,
                           let entry = chartData.dataSets[0].entryForIndex(linkIndex),
                           let linkTopLeft = (link["y0"] as? CGFloat),
                           let linkTopRight = (link["y1"] as? CGFloat),
                           let targetX = (link["target"] as? NSDictionary)?["x0"] as? CGFloat,
                           let linkWidth = (link["width"] as? CGFloat),
                           let isCircular = (link["circular"] as? Bool)
                     else { continue }
                     
                     if isCircular
                     {
                         guard let circularType = (link["circularLinkType"] as? String),
                               let pathDict = (link["circularPathData"] as? NSDictionary) else {
                             continue
                         }
                         
                         if let circularLinkPath = SankeyHelperFunctions.constructCircularLink(chart: chart,circularType: circularType, pathDict: pathDict, linkWidth: linkWidth, linkPadding: plotOption.linkPadding) {
                             
                             let linkLayer = SankyLayers(chartView: chart, chartEntry: entry, dataSet: chartData.dataSets[0], type: .CircularLink, path: circularLinkPath, index: nodeToColor[sourceName] ?? 0)
                             
                             if customOpacity {
                                 
                                 let setColors = chartData.dataSets[0].colors
                                 let index = nodeToColor[sourceName] ?? 0
                                 
                                 linkLayer.fillColor = setColors[index%setColors.count].withAlphaComponent(CGFloat(entry.opacityChanged)).cgColor
                             }
                         }
                     }
                     else {
                         let halfWidth = linkWidth/2
                         let x0 = sourceX
                         let y0 = linkTopLeft - halfWidth
                         let x1 = targetX
                         let y1 = linkTopRight - halfWidth
                         
                         var newRect:[RectPoints:CGPoint] = [:]
                         newRect[.topLeft] = CGPoint(x: x0, y: y0)
                         newRect[.bottomLeft] = CGPoint(x: x0, y: y0+linkWidth)
                         newRect[.topRight] = CGPoint(x: x1, y: y1)
                         newRect[.bottomRight] = CGPoint(x: x1, y: y1+linkWidth)
                         
                         transformRectPoints(rectPoints: &newRect)
                         
                         if firstLinkX != CGFloat.greatestFiniteMagnitude && firstLinkX == x0
                         {
                             newRect[.topLeft]?.x += plotOption.linkPadding - toAdjust
                             newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjust
                             newRect[.topRight]?.x -= plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjustHalf
                         }
                         else if lastLinkX != CGFloat.greatestFiniteMagnitude && lastLinkX == x1
                         {
                             newRect[.topLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.topRight]?.x -= plotOption.linkPadding - toAdjust
                             newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjust
                         }
                         else{
                             newRect[.topLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomLeft]?.x += plotOption.linkPadding - toAdjustHalf
                             newRect[.topRight]?.x -= plotOption.linkPadding - toAdjustHalf
                             newRect[.bottomRight]?.x -= plotOption.linkPadding - toAdjustHalf
                         }
                         
                         
                         let linkLayer = SankyLayers(chartView: chart, chartEntry: entry, dataSet: chartData.dataSets[0], type: .Link, rect: newRect, index: nodeToColor[sourceName] ?? 0)
                             
                         if customOpacity {
                             
                             let setColors = chartData.dataSets[0].colors
                             let index = nodeToColor[sourceName] ?? 0
                             
                             linkLayer.fillColor = setColors[index%setColors.count].withAlphaComponent(CGFloat(entry.opacityChanged)).cgColor
                         }
                     }
                 }
             
             }
     }
     */
}




 
 
