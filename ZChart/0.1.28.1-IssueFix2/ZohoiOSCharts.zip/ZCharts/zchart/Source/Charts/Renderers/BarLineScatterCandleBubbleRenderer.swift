//
//  BarLineScatterCandleBubbleRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(BarLineScatterCandleBubbleChartRenderer)
open class BarLineScatterCandleBubbleRenderer: DataRenderer
{
    internal var _xBounds = XBounds() // Reusable XBounds object
    
    /// Checks if the provided entry object is in bounds for drawing considering the current animation phase.
    internal func isInBoundsX(entry e: ChartDataEntry, dataSet: IChartDataSet) -> Bool
    {
        let entryIndex = dataSet.entryIndex(entry: e)
        
        if Double(entryIndex) >= Double(dataSet.entryCount) * (animator?.phaseX ?? 1.0)
        {
            return false
        }
        else
        {
            return true
        }
    }

    /// Calculates and returns the x-bounds for the given DataSet in terms of index in their values array.
    /// This includes minimum and maximum visible x, as well as range.
    internal func xBounds(chart: ChartViewBase,
                          dataSet: IChartDataSet,
                          animator: Animator?) -> XBounds
    {
        return XBounds(chart: chart, dataSet: dataSet, animator: animator)
    }

    /// Class representing the bounds of the current viewport in terms of indices in the values array of a DataSet.
    open class XBounds
    {
        /// minimum visible entry index
        open var min: Int = 0

        /// maximum visible entry index
        open var max: Int = 0

        /// range of visible entry indices
        open var range: Int = 0

        public init()
        {
            
        }
        
        public init(chart: ChartViewBase,
                    dataSet: IChartDataSet,
                    animator: Animator?)
        {
            self.set(chart: chart, dataSet: dataSet, animator: animator)
        }
        
        /// Calculates the minimum and maximum x values as well as the range between them.
        open func set(chart: ChartViewBase,
                      dataSet: IChartDataSet,
                      animator: Animator?)
        {
            let phaseX = Swift.max(0.0, Swift.min(1.0, animator?.phaseX ?? 1.0))
            
            let low = chart.lowestVisibleX
            let high = chart.highestVisibleX
            
            let entryFrom = dataSet.entryForXValue(low, closestToY: Double.nan, rounding: ChartDataSetRounding.down)
            let entryTo = dataSet.entryForXValue(high, closestToY: Double.nan, rounding: ChartDataSetRounding.up)
            
            self.min = entryFrom == nil ? 0 : dataSet.entryIndex(entry: entryFrom!)
            self.max = entryTo == nil ? 0 : dataSet.entryIndex(entry: entryTo!)
            range =  ChartUtils.doubleToIntSafeCast(value:Double(self.max - self.min) * phaseX)
        }
    }
    
    internal func isInStartOfBound(chart: ChartViewBase, pos: CGPoint) -> Bool {
        
        guard let viewPortHandler = self.viewPortHandler else {
            return true
        }
        
        if (chart.xAxis.isInverted) {
            return chart.isRotated ? viewPortHandler.isInBoundsTop(pos.y) : viewPortHandler.isInBoundsLeft(pos.x)
        }else {
            return chart.isRotated ? viewPortHandler.isInBoundsBottom(pos.y) : viewPortHandler.isInBoundsRight(pos.x)
        }
    }
    
    internal func isInEndOfBound(chart: ChartViewBase, pos: CGPoint) -> Bool {
        
        guard let viewPortHandler = self.viewPortHandler else {
            return true
        }
        
        return chart.isRotated ? ((viewPortHandler.isInBoundsTop(pos.y) || viewPortHandler.isInBoundsBottom(pos.y) || viewPortHandler.isInBoundsX(pos.x))) : ((viewPortHandler.isInBoundsLeft(pos.x) || viewPortHandler.isInBoundsRight(pos.x) ||  viewPortHandler.isInBoundsY(pos.y)))
    }
    
    internal func transPoint(point: CGPoint, chart: ChartViewBase, labelRect: inout CGRect, isAlign: Bool, isCenter: Bool = false) {
        
        if isCenter {
            labelRect.origin.x = point.x - labelRect.width / 2.0
            labelRect.origin.y = point.y - labelRect.height / 2.0
        }
        else {
            if chart.isRotated {
                labelRect.origin.y = point.y - labelRect.height / 2.0
            }
            else {
                labelRect.origin.x = point.x - labelRect.width / 2.0
            }
        }
        
        if isAlign {
            DataRenderer.alignDataLabel(chart: chart, translatedOrigin: &labelRect.origin, labelSize: labelRect.size)
        }
    }
    
    internal func allowedToDraw(chart: ChartViewBase, rect: CGRect) -> Bool {
        return chart.viewPortHandler.contentRect.intersects(rect)
    }
    
    internal func isInBounds(viewPortHandler: ViewPortHandler, originPoint: CGPoint) -> Int? {
        
        guard let chart = chart else {
            return nil
        }
        
        let rect = CGRect(origin: originPoint, size: chart.longestDatalabelSize)
        
        if chart.isRotated {
            
            if chart.xAxis.isInverted {
                if !viewPortHandler.isInBoundsTop(rect.minY) && !viewPortHandler.isInBoundsTop(rect.maxY) {
                    return 0
                }
            }
            else {
                if !viewPortHandler.isInBoundsBottom(rect.minY) && !viewPortHandler.isInBoundsBottom(rect.maxY) {
                    return 0
                }
            }
            
            if !viewPortHandler.isInBoundsBottom(rect.minY) && !viewPortHandler.isInBoundsBottom(rect.maxY) || !viewPortHandler.isInBoundsTop(rect.minY) && !viewPortHandler.isInBoundsTop(rect.maxY) {
                return 1
            }
        }
        else {
            
            if chart.xAxis.isInverted {
                if  !viewPortHandler.isInBoundsLeft(rect.minX) && !viewPortHandler.isInBoundsLeft(rect.maxX) {
                    return 0
                }
            }
            else {
                if !viewPortHandler.isInBoundsRight(rect.minX) && !viewPortHandler.isInBoundsRight(rect.maxX) {
                    return 0
                }
            }
            
            if !viewPortHandler.isInBoundsLeft(rect.minX) && !viewPortHandler.isInBoundsLeft(rect.maxX) || !viewPortHandler.isInBoundsRight(rect.minX) && !viewPortHandler.isInBoundsRight(rect.maxX) {
                return 1
            }
        }
        
        return nil
    }
}
