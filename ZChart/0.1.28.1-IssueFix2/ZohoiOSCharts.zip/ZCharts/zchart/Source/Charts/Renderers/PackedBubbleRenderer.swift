//
//  PackedBubbleRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/05/20.
//  Copyright © 2020 zoho. All rights reserved.
//


import Foundation
import CoreGraphics

#if !os(OSX)
import UIKit
#endif

open class PackedBubbleRenderer: BarLineScatterCandleBubbleRenderer
{
    open var _buffers = [CGRect]()
        
    open override func initBuffers()
    {
        if let _ = chart?.data
        {
            
        }
        else
        {
            _buffers.removeAll()
        }
    }
    
    open override func drawData(context: CGContext)
    {
        drawRenderer(context: context)
    }
    
    open func drawRenderer(context: CGContext)
    {
        guard
            let chart = chart,
            let processor = chart.getProcessor(type: .PackedBubble) as? PackedBubblePreprocessor,
            let chartData = chart.data
            else { return }
        
            var index = 0
        
            let finalArray = processor.dataValues
        
            for arrayVal in finalArray {
                index = index + 1
            
                guard let object = arrayVal as? NSDictionary,
                let xValue = object["x"] as? CGFloat,
                let yValue = object["y"] as? CGFloat,
                let radius = object["radius"] as? CGFloat,
                let name = object["name"] as? String,
                let setIndex = (object["setIndex"] as? Int),
                let pathIndex = (object["pathIndex"] as? [Int])
                else { continue }
                
                let set = chartData.dataSets[setIndex]
                
                var rect = CGRect(x: xValue-radius, y: yValue-radius, width: radius * 2 , height: radius * 2)
                chart.plotTransformer.rectValueToPixel(&rect)
                
                if rect.width.isNaN || rect.height.isNaN || rect.minX.isNaN || rect.minY.isNaN
                {
                    rect = CGRect()
                }
                guard let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
                    else { continue }
                
                let isRoot = name == "root"
                
                let newShapeProperties = ShapeProperties()
                
                newShapeProperties.holeColor = isRoot ? NSUIColor.gray.withAlphaComponent(0.2) : dataOption.shapeProperties.holeColor
                newShapeProperties.shapeType = isRoot ? LineShapes.circle : dataOption.shapeProperties.shapeType
                newShapeProperties.lineWidth = isRoot ? 1 : dataOption.shapeProperties.lineWidth
                let shapeSize = rect.width - (newShapeProperties.lineWidth)/2
                newShapeProperties.size = CGSize(width: shapeSize, height: shapeSize)
                newShapeProperties.strokeColor = isRoot ? NSUIColor.black : dataOption.shapeProperties.strokeColor
                
                let center = CGPoint(x: rect.midX, y: rect.midY)

                guard let bubbleEntry = (name == "root") ? ChartDataEntry(xString: name, y: 0, data: nil) : set.entryForPath(pathIndex)
                else { continue }
                
                let bubbleLayer = BubbleLayer(chartView: chart, chartEntry: bubbleEntry, dataSet: set, point: center, shapeProperty: newShapeProperties)
                
                
                if customOpacity{
                    bubbleLayer.opacity = bubbleEntry.opacityChanged
                }
                
                
            }
    }
   
    open override func drawValues(context: CGContext)
    {
       guard
           let chart = chart,
           let processor = chart.getProcessor(type: .PackedBubble) as? PackedBubblePreprocessor,
           let chartData = chart.data
           else { return }
       
           var index = 0
       
           let finalArray = processor.dataValues
       
           for arrayVal in finalArray {
               index = index + 1
           
               guard let object = arrayVal as? NSDictionary,
               let xValue = object["x"] as? CGFloat,
               let yValue = object["y"] as? CGFloat,
               let radius = object["radius"] as? CGFloat,
               let name = object["name"] as? String,
               let setIndex = (object["setIndex"] as? Int),
               let pathIndex = (object["pathIndex"] as? [Int])
               else { continue }
                
               let set = chartData.dataSets[setIndex]
            
               if !shouldDrawValues(forDataSet: set) || set.plotType != .PackedBubble || !(set.isDrawValuesEnabled)
               {
                    continue
               }
            
               var rect = CGRect(x: xValue, y: yValue, width: radius * 2 , height: radius * 2)
               chart.plotTransformer.rectValueToPixel(&rect)
                
                if xValue.isNaN || yValue.isNaN
                {
                    rect.origin = CGPoint()
                }
            
               let valueFont = chartData.dataSets[setIndex].valueFont
               let valueTextColor = chartData.dataSets[setIndex].valueTextColorAt(index)
               
               guard let bubbleEntry = set.entryForPath(pathIndex) ?? set.entryForIndex(0), bubbleEntry.childEntries.isEmpty
               else { continue }
               
               let formattedText = set.valueFormatter?.getFormattedTextforLabel?(label: name, type: .x, data: bubbleEntry) ?? ""
               
               let labelAttributes = [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
               
               let labelSize = formattedText.size(withAttributes: labelAttributes)
               let labelRect = CGRect(origin: CGPoint(x: rect.origin.x - labelSize.width / 2.0, y: rect.origin.y - labelSize.height / 2.0), size: labelSize)
               
               if chartData.dataLabelRenderingMode == .showAll || ChartUtils.isRectFittedInCircle(radius: rect.width / 2.0, size: labelSize) {
                   drawLabel(chart: chart, label: formattedText, labelAttributes: labelAttributes, labelRect: labelRect)
               }

           }
    }
    
    open override func drawExtras(context: CGContext)
    {
     
    }
}



