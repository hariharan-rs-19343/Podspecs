//
//  DialChartRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 30/09/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

class DialChartRenderer:PieChartRenderer
{
    
    var midRadius = 0.0
    var innerRadius = 0.0
    
    var innerpading: CGFloat = 0.0
    var outerpading: CGFloat = 0.0
    
    var innerLevelpading: CGFloat = 0.0
    var outerLevelpading: CGFloat = 0.0
    
    open override func drawDataSet(context: CGContext, dataSet: IChartDataSet)
    {
            guard
                let chart = chart,
                let animator = animator,
                let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
                let transformer = chart.getTransformer(axisIndex: dataSet.axisIndex) as? PolarTransformer,
                let yAxis = chart.getYAxis(atIndex: dataSet.axisIndex)
                else {return }
        
            let entryCount = dataSet.entryCount
            let drawAngles = dialOption.drawAngles
            
            let radius = dialOption.radius
            innerRadius = radius * dialOption.innerRadiusPercent
            let bandWidth = radius - innerRadius
            midRadius = (radius + innerRadius)/2
        
            innerLevelpading = dialOption.dialInnerPaddingPercent > 0 ? -dialOption.dialInnerPaddingPercent * bandWidth : 0.0
            outerLevelpading = dialOption.dialOuterPaddingPercent > 0 ? dialOption.dialOuterPaddingPercent * bandWidth : 0.0
        
            let levelMarkerInnerRadius = innerRadius - innerLevelpading
            let levelMarkerOuterRadius = radius - outerLevelpading
        
            var visibleAngleCount = 0
        
            for j in 0 ..< entryCount
            {
                guard let e = dataSet.entryForIndex(j) else { continue }
                if ((abs(e.y) > Double.ulpOfOne))
                {
                    visibleAngleCount += 1
                }
            }
        
            context.saveGState()
            
            for j in 0 ..< entryCount
            {
                guard let setInstance = dataSet as? ChartDataSet,
                      let e = dataSet.entryForIndex(j) else { continue }
                
                // ******************************* Level Markers *******************************
                
                if e.levelMarker != nil && (e.levelMarker!.count > 0)
                {
                      let levelMarkerColors = dialOption.levelMarkerColors
                      
                      let isSingleColor = levelMarkerColors.count == 1
                      
                      let levelColorEntryIndex:Int
                      
                      if isSingleColor
                      {
                          levelColorEntryIndex = 0
                      }
                      else{
                          levelColorEntryIndex = j
                      }
                    
                    let tempLevelArray:[Double] = PieHelperFunctions.prepareLevelValues(chart: chart, dataset: dataSet,levelMarker: e.levelMarker!)
                    
                    let sortedLevels = e.levelMarker!.sorted(by: {$0 < $1})
                    var sortedLevelIndex = 0
                      
                    for levelIndex in 0..<tempLevelArray.count - 1
                    {
                        
                        var fromVal = tempLevelArray[levelIndex].isNaN ? 0 : tempLevelArray[levelIndex]
                        
                        let colorIndex = (tempLevelArray.lastIndex(of: fromVal) ?? 0) % levelMarkerColors[levelColorEntryIndex].count
                        
                        var toVal = tempLevelArray[levelIndex + 1].isNaN ? 0 : tempLevelArray[levelIndex + 1]
                          
                        let levelPath = PieHelperFunctions.getLevelMarkerPath(chart:chart, dataset: dataSet, entryIndex: j, fromVal: &fromVal, toVal: &toVal, innerRadius: levelMarkerInnerRadius, outerRadius: levelMarkerOuterRadius, phaseY: animator.phaseY)
                        
                        let levelLayer = DialLevelLayer(chart: chart, chartEntry: e, chartDataSet: setInstance, slicePath: levelPath)
                        
                        while sortedLevels[sortedLevelIndex].isNaN
                        {
                            sortedLevelIndex += 1
                        }
                        
                        levelLayer.levelValue = sortedLevels[sortedLevelIndex]
                        sortedLevelIndex += 1
                      
                        levelLayer.fillColor = levelMarkerColors[levelColorEntryIndex][colorIndex].cgColor
                          
                      }
                  }
                  else{
                        let levelAngle = yAxis.axisRange == 0 ? 1 : transformer.rangeForValue(yValue: yAxis.axisMaximum)
    
                        let levelPath = PieHelperFunctions.getSlicePath(chart:chart, dataSet: dataSet, entryIndex: j, visibleAngleCount: visibleAngleCount, startAngle: dialOption.startAngle, sliceAngle: levelAngle, innerRadius: levelMarkerInnerRadius, outerRadius: levelMarkerOuterRadius, animate: false, phaseY: animator.phaseY)
                      
                        let levelLayer = DialLevelLayer(chart: chart, chartEntry: e, chartDataSet: setInstance, slicePath: levelPath)
                       
                        levelLayer.fillColor = NSUIColor.lightGray.cgColor
                    
                        if dialOption.levelMarkerColors.count > 0 && dialOption.levelMarkerColors[0].count > 0 {
                            levelLayer.fillColor = dialOption.levelMarkerColors[0][0].cgColor
                        }
                    }
                
                // ******************************* Data *******************************
                
                // draw only if the value is greater than zero
                if (!e.y.isNaN && abs(e.y) > Double.ulpOfOne)
                {
                    
                    innerpading = dialOption.dialInnerPaddingPercent < 0 ? -dialOption.dialInnerPaddingPercent * bandWidth : 0.0
                    outerpading = dialOption.dialOuterPaddingPercent < 0 ? dialOption.dialOuterPaddingPercent * bandWidth : 0.0
                    
                    let innerRadius = innerRadius + innerpading
                    let outerRadius = radius + outerpading
                    
                    var startAngle = dialOption.startAngle
                    
                    // Negative Data Handling
                    if  yAxis.axisMinimum < 0
                    {
                        let val = min(yAxis.axisMaximum,0)
                        startAngle = transformer.absoluteAngleForValue(value: val)
                        
                    }
                    
                    let path = PieHelperFunctions.getSlicePath(chart:chart, dataSet: dataSet, entryIndex: j, visibleAngleCount: visibleAngleCount, startAngle: startAngle, sliceAngle: drawAngles[j], innerRadius: innerRadius, outerRadius: outerRadius, animate: true, phaseY: animator.phaseY)
                    
                    let _ = PieLayer(chart: chart, chartEntry: e, chartDataSet: setInstance, slicePath: path)
                    
//                  if !(chartEntry?.layerEnabled)! {
//                      drawGradients(context: context, path: path, entry: e, dataSet: dataSet)
//                  }
                }
                
                // ******************************* Target Marker *******************************
                
                if e.targetMarker != nil
                {
                     let targetLayer = CAShapeLayer()
                    
                     let shapeProp =  dialOption.targetMarkerShapeProperties
                    
                     if e.targetMarker!.isNaN
                     {
                         continue
                     }
                    
                     let targetValue = e.targetMarker! > yAxis.axisMaximum ? yAxis.axisMaximum : e.targetMarker!
                     
                     let angle = transformer.absoluteAngleForValue(value: targetValue)
                     
                     let point = ChartUtils.getPosition(center: dialOption.centerCircleBox, dist: midRadius, angle: angle)
                   
                     if dialOption.targetMarkerPadding != nil
                     {
                        let levelWidth = (radius - midRadius) * 2
                         let shapeSize = (1 - dialOption.targetMarkerPadding!) * levelWidth
                         dialOption.targetMarkerShapeProperties.size = CGSize(width: shapeSize, height: shapeSize)
                     }
                     
                    _ = CommonHelperFunctions.drawShapeLayerPolar(shapeProperties: shapeProp, point: point, strokeColor: (shapeProp.strokeColor?.cgColor) ?? NSUIColor.black.cgColor, currentLayer: targetLayer, angle: angle)
                     
                     chart.plotView?.nsuiLayer?.addSublayer(targetLayer)
                 }
                
            }
        
            context.restoreGState()
    }
    
    override func drawValues(context: CGContext) {
        guard
        let chart = chart,
        let dataSets = chart.data?.dataSets,
            let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions
        else { return  }
        
        context.saveGState()
        
        let minMaxLabelRects = minMaxLabel()
        
        var center = dialOption.centerCircleBox
        
        center.y += dialOption.needleEnabled ? (dialOption.needleShapeProperties.size.width)/2 + 5.0 : 0
        
        center.y += dialOption.centerLabelPadding
        
        for dataSet in dataSets where dataSet.isVisible
        {
            guard let formatter = dataSet.valueFormatter else { continue }
            
            if !dataSet.drawValuesEnabled && !dialOption.isDrawEntryLabelsEnabled
            {
                continue
            }
            
            for index in 0..<(dataSet.entryCount)
            {
                guard let e = dataSet.entryForIndex(index)
                    else { continue }
                
                let value = e.y.isNaN ? 0 : e.y
                
                let text = formatter.stringForValue(
                value,
                entry: e,
                dataSetIndex: index,
                viewPortHandler: viewPortHandler)
                
                let textSize = text.size(withAttributes: [NSAttributedString.Key.font: dataSet.valueFont])
                
                let constrainedToSize = CGSize(width: textSize.width, height: textSize.height)
                
                let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColor]
                
                var textFrame = CGRect(origin: CGPoint(x: center.x - textSize.width / 2.0, y: center.y), size: textSize)
                
                if let minRect = minMaxLabelRects[safe:0], let maxRect = minMaxLabelRects[safe:1], minMaxLabelRects[safe:0]?.intersects(textFrame) ?? false || minMaxLabelRects[safe:1]?.intersects(textFrame) ?? false {
                    center.y = max(minRect.maxY, maxRect.maxY) + 5.0
                    textFrame.origin.y = center.y
                }
                
                if !dialOption.centerLabelTrancate && (abs(dialOption.startAngle + dialOption.maxAngle - 360.0) > 180 && constrainedToSize.width > innerRadius * 2.0 || !isInChartView(rect: textFrame)) {
                    continue
                }
            
                ChartUtils.drawMultilineText(context: context, text: text, point: center, attributes: attributes, constrainedToSize: constrainedToSize, anchor: CGPoint(x: 0.5, y: 0.0), angleRadians: (0 * ChartUtils.Math.FDEG2RAD))
            }
        }
        
        context.restoreGState()
    }
    
    internal func isInChartView(rect: CGRect) -> Bool {
        guard
        let chart = chart else { return false }
        return chart.bounds.minY <= rect.minY && chart.bounds.maxY >= rect.maxY && chart.bounds.minX <= rect.minX && chart.bounds.maxX >= rect.maxX
    }
    
    override func drawExtras(context: CGContext) {
        
        drawNeedle()
        drawTargetLabel()
    }
    
    fileprivate func minMaxLabel() -> [CGRect] {
        
        var textRects: [CGRect] = []
        
        guard let chart = chart,
              let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              dialOption.minMaxLabelConfig.enabled,
              let polarTransformer = chart.getTransformer(axisIndex: 0) as? PolarTransformer,
              let yAxis = chart.getYAxis(atIndex: 0) else {
            return textRects
        }
        
        let isClockwise = dialOption.direction == .clockwise
        
        var endAngle = dialOption.startAngle + dialOption.maxAngle
        
        if !isClockwise {
            endAngle = dialOption.startAngle - dialOption.maxAngle
        }
        
        if endAngle >= 360 {
            endAngle = endAngle - 360
        }
        
        if endAngle < 0 {
            endAngle = 360 + endAngle
        }
        
        for (index,value) in [yAxis.axisMinimum,yAxis.axisMaximum].enumerated() {
            
            let text = (dialOption.minMaxLabelConfig.formatter.getFormattedTextforValue?(value: value, type: index == 0 ? .minValue : .maxValue, data: nil) ?? String(value))
            
            let textSize = text.size(withAttributes: dialOption.minMaxLabelConfig.AttributedString)
                      
            let angle = polarTransformer.absoluteAngleForValue(value: value)
                      
            var point = ChartUtils.getPosition(center: dialOption.centerCircleBox, dist: dialOption.radius, angle: angle)
            
            if (dialOption.startAngle == 180 && endAngle == 0 && !isClockwise) || (dialOption.startAngle >= 0 && dialOption.startAngle <= endAngle && endAngle <= 180 && isClockwise) {
                point.y -= textSize.height
            }
            
            point.x += dialOption.minMaxLabelConfig.xOffset
            point.y += dialOption.minMaxLabelConfig.yOffset
            
            var alignment = NSTextAlignment.left
            
            if angle < 270 && angle > 90 {
                alignment = .right
            }
            
            let constrainedWidth = min(textSize.width + dialOption.minimumSpacingBetweenDataLabel, dialOption.radius - (dialOption.minimumSpacingBetweenDataLabel / 2.0))
            
            if !dialOption.minMaxLabelConfig.truncate && constrainedWidth < textSize.width {
                continue
            }
                
            let dataLabel = ChartUtils.drawTextLayer(text: text, point: point, align: alignment, attributes: dialOption.minMaxLabelConfig.AttributedString, constrainedToWidth: constrainedWidth, truncationMode: .end)
            
            var labelRect = dataLabel.frame
            labelRect.size.width += dialOption.minimumSpacingBetweenDataLabel
            
            textRects.append(labelRect)
            
            let labelTextLayer = ValueTextLayer()
            labelTextLayer.addSublayer(dataLabel)
            
            chart.nsuiLayer?.addSublayer(labelTextLayer)
        }
        
        return textRects
    }
    
    fileprivate func drawTargetLabel() {
        
        guard
        let chart = chart,
        let dataSets = chart.data?.dataSets,
        let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions, dialOption.targetLabelConfig.enabled
        else { return  }
        
        for dataset in dataSets {
            
            guard let polarTransformer = chart.getTransformer(axisIndex: dataset.axisIndex) as? PolarTransformer else {
                continue
            }
            
            for entryIndex in 0..<dataset.entryCount {
                
                guard let entry = dataset.entryForIndex(entryIndex), let targetValue = entry.targetMarker, let yAxisRenderer = chart.yAxisRenderers[dataset.axisIndex] as? YAxisPolarRenderer else {
                    continue
                }
                
                let text = dialOption.targetLabelConfig.formatter.getFormattedTextforValue?(value: targetValue, type: .targetValue, data: nil) ?? String(targetValue)
                
                let textSize = text.size(withAttributes: dialOption.targetLabelConfig.AttributedString)
                
                let angle = polarTransformer.absoluteAngleForValue(value: targetValue)
                
                let radius = (angle < 180 && angle > 0 ? dialOption.radius : dialOption.radius + textSize.height) + yAxisRenderer.getRequiredSize().height
                let chartCenter = dialOption.centerCircleBox
                
                var targetPoint = ChartUtils.getPosition(center: chartCenter, dist: radius, angle: angle)
                
                var isTranslated = false
                var alignment = NSTextAlignment.right
                
                if angle > 90 && angle < 270 {
                    alignment = .left
                }
                
                if let translateX = DataRenderer.getXTranslationForBounds(chart: chart, x: targetPoint.x, width: textSize.width) {
                    targetPoint.x = translateX
                    isTranslated = true
                }
                
                let layer = ValueTextLayer()
                
                if isTranslated {
                    let y1 = sqrt(radius * radius - (targetPoint.x - chartCenter.x) * (targetPoint.x - chartCenter.x))
                    
                    if angle < 180 && angle > 0 {
                        targetPoint.y = chartCenter.y + y1
                    }
                    else {
                        targetPoint.y = chartCenter.y - y1
                    }
                    
                    if !(DataRenderer.getYTranslationForBounds(chart: chart, y: targetPoint.y, height: textSize.height) == nil) {
                        continue
                    }
                }
                else {
                    if let translateY = DataRenderer.getYTranslationForBounds(chart: chart, y: targetPoint.y, height: textSize.height) {
                        targetPoint.y = translateY
                        isTranslated = true
                    }
                    
                    if isTranslated {
                        
                        let x1 = sqrt(radius * radius - (targetPoint.y - chartCenter.y) * (targetPoint.y - chartCenter.y))
                        
                        if angle > 90 && angle < 270 {
                            targetPoint.x = chartCenter.x - x1
                        }
                        else {
                            targetPoint.x = chartCenter.x + x1
                        }
                        
                        if !(DataRenderer.getXTranslationForBounds(chart: chart, x: targetPoint.x, width: textSize.width) == nil) {
                            continue
                        }
                    }
                }
                
                if isTranslated {
                    let path = CGMutablePath()
                    
                    let fromTargetPoint = ChartUtils.getPosition(center: chartCenter, dist: dialOption.radius, angle: angle)
                    path.move(to: fromTargetPoint)
                    
                    let targetY = angle < 180 && angle > 0 ? targetPoint.y : targetPoint.y + textSize.height
                    path.addLine(to: CGPoint(x: fromTargetPoint.x, y: targetY))
                    
                    let targetMarkerIndicatorLineLayer = CAShapeLayer()
                    targetMarkerIndicatorLineLayer.path = path
                    dialOption.targetIndicatorLineConfiguration.setLineConfiguration(to: targetMarkerIndicatorLineLayer)
                    
                    layer.addSublayer(targetMarkerIndicatorLineLayer)
                }
                
                let textLayer = ChartUtils.drawTextLayer(text: text, point: targetPoint, align: alignment, attributes: dialOption.targetLabelConfig.AttributedString)
                
                layer.addSublayer(textLayer)
                
                chart.nsuiLayer?.addSublayer(layer)
            }
        }
    }
    
    fileprivate func drawNeedle()
    {
        guard
        let chart = chart,
        let dataSets = chart.data?.dataSets,
            let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
        let phaseY = animator?.phaseY
        else { return  }
        
        if !dialOption.needleEnabled
        {
            return
        }
        
        let radius = dialOption.radius
        
        let shapeProp = dialOption.needleShapeProperties
        
        let needleLayer = CAShapeLayer()
        
        for i in 0 ..< dataSets.count
        {
            let dataSet = dataSets[i]
            guard
                let entry = dataSet.entryForIndex(0),
                let transformer = chart.getTransformer(axisIndex: dataSet.axisIndex) as? PolarTransformer,
                let yAxis = chart.getYAxis(atIndex: dataSet.axisIndex)
                else { continue }
            
            if entry.y.isNaN
            {
                continue
            }
            
            let polarValue = entry.y > yAxis.axisMaximum ? yAxis.axisMaximum : entry.y
            
            shapeProp.polarAngle = transformer.absoluteAngleForValue(value: polarValue * phaseY)
            
            shapeProp.polarRadius = innerRadius * (1 - shapeProp.padding)
            
            let shapeSize = min(min(shapeProp.size.width, shapeProp.size.height),innerRadius / 2)
            
            shapeProp.size = CGSize(width: shapeSize, height: shapeSize)
                
            _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProp, point: dialOption.centerCircleBox, strokeColor: (shapeProp.strokeColor?.cgColor) ?? NSUIColor.black.cgColor, currentLayer: needleLayer)
        }
        
        let needleHightlayer = HighlightLayer()
        
        needleHightlayer.addSublayer(needleLayer)
        
        chart.nsuiLayer?.addSublayer(needleHightlayer)
        
//        chart.plotView?.layer.addSublayer(needleLayer)
    }
    
    /// Calculates the sliceSpace to use based on visible values and their size compared to the set sliceSpace.
    open override func getSliceSpace(dataSet: IChartDataSet) -> CGFloat
    {
        guard let piePlotOption = chart?.getPlotOptions(type: .Dial) as? DialPlotOptions,
            piePlotOption.automaticallyDisableSliceSpacing,
            let viewPortHandler = self.viewPortHandler
        else { return  ((chart?.getPlotOptions(type: .Dial) as? DialPlotOptions)?.sliceSpace) ?? 0 }
        
        let spaceSizeRatio = piePlotOption.sliceSpace / min(viewPortHandler.contentWidth, viewPortHandler.contentHeight)
        let minValueRatio = dataSet.yMin / PieHelperFunctions.getYValueSum(chart: chart!) * 2.0
        
        let sliceSpace = spaceSizeRatio > CGFloat(minValueRatio)
            ? 0.0
            : piePlotOption.sliceSpace
        
        return sliceSpace
    }
    
}


