//
//  BubbleChartRenderer.swift
//  Charts
//
//  Bubble chart implementation:
//    Copyright 2015 Pierre-Marc Airoldi
//    Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


open class BubbleChartRenderer: BarLineScatterCandleBubbleRenderer
{
    open var entryDeleted = false
    
    open override func drawData(context: CGContext)
    {
        guard let bubbleData = chart?.data
            else { return }
        
        for set in bubbleData.dataSets where (set.isVisible && set.plotType == .Bubble)
        {
            drawDataSet(context: context, dataSet: set)
        }
    }
    
    fileprivate func getShapeSize(
        entrySize: CGFloat,
        maxSize: CGFloat,
        reference: CGFloat,
        normalizeSize: Bool) -> CGFloat
    {
        let factor: CGFloat = normalizeSize
            ? ((maxSize == 0.0) ? 1.0 : sqrt(entrySize / maxSize))
            : entrySize
        let shapeSize: CGFloat = reference * factor
        return shapeSize
    }
    
    internal func getBubbleSizeScale(bubbleData:ChartData, plotOptions:BubblePlotOptions) -> CGAffineTransform
    {
       var matrixValueToSize = CGAffineTransform.identity
       matrixValueToSize = matrixValueToSize.scaledBy(x: (plotOptions.maximumShapeSizeInPixel - plotOptions.minimumShapeSizeInPixel) / (bubbleData.maxSize - bubbleData.minSize), y: 0)
       matrixValueToSize = matrixValueToSize.translatedBy(x: -bubbleData.minSize, y: 0)
       
       let matrixOffset = CGAffineTransform(translationX: plotOptions.minimumShapeSizeInPixel, y: 0)
       let finalMatrix = matrixValueToSize.concatenating(matrixOffset)
       return finalMatrix
    }
    
    internal func getBubbleSize(sizeValue:CGFloat, scale:CGAffineTransform, plotOptions:BubblePlotOptions,bubbleData:ChartData) -> CGFloat
    {
        var size = plotOptions.minimumShapeSizeInPixel
        
        if sizeValue.isNaN || (bubbleData.minSize == bubbleData.maxSize) {
            size = plotOptions.minimumShapeSizeInPixel
        }else {
            let pt = CGPoint(x: sizeValue, y: 0)
            size = pt.applying(scale).x
        }
        
        return size
    }

    internal var _pointBuffer = CGPoint()
    fileprivate var _sizeBuffer = [CGPoint](repeating: CGPoint(), count: 2)
    
    open func drawDataSet(context: CGContext, dataSet: IChartDataSet)
    {
        guard
            let chart = chart,
            let viewPortHandler = self.viewPortHandler,
            let animator = animator,
            let bubbleData = (chart.data),
            let plotOptions = chart.getPlotOptions(type: .Bubble) as? BubblePlotOptions,
            let dataSetOptions = dataSet.dataSetOptions as? AxisChartDataSetOptions
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let phaseY = animator.phaseY
        
        _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
        
        _xBounds.range =  ChartUtils.doubleToIntSafeCast(value:Double(_xBounds.max - _xBounds.min))
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
    
        _sizeBuffer[0].x = 0.0
        _sizeBuffer[0].y = 0.0
        _sizeBuffer[1].x = 1.0
        _sizeBuffer[1].y = 0.0
        
        trans.pointValuesToPixel(&_sizeBuffer)
        
        context.saveGState()
        
        /*let normalizeSize = plotOptions.isNormalizeSizeEnabled
        
        // calcualte the full width of 1 step on the x-axis
        let maxBubbleWidth: CGFloat = abs(_sizeBuffer[1].x - _sizeBuffer[0].x)
        let maxBubbleHeight: CGFloat = abs(viewPortHandler.contentBottom - viewPortHandler.contentTop)
        let referenceSize: CGFloat = min(maxBubbleHeight, maxBubbleWidth)
        
        let sizeInterPolator = Interpolator.interpolate(a: plotOptions.minimumShapeSizeInPixel, b: plotOptions.maximumShapeSizeInPixel)*/
        
        let bubbleSizeScale = getBubbleSizeScale(bubbleData: bubbleData, plotOptions: plotOptions)
        
        let rangeX = chart.lowestVisibleX + (chart.highestVisibleX - chart.lowestVisibleX) * animator.phaseX

        for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
        {
            guard let entry = dataSet.entryForIndex(j) else { continue }
            
            if entry.x.isNaN || entry.y.isNaN || entry.filterEnabled
            {
                continue
            }
            
            _pointBuffer.x = CGFloat(entry.x)
            _pointBuffer.y = CGFloat(entry.y * phaseY)
            _pointBuffer = chart.pixelForValues(isRotated: chart.isRotated, x: _pointBuffer.x, y: _pointBuffer.y, axisIndex: dataSet.axisIndex)
            
            /*var shapeSize:CGFloat
            
            if normalizeSize && plotOptions.minimumShapeSizeInPixel != 0 && plotOptions.maximumShapeSizeInPixel != 0
            {
                shapeSize = bubbleData.maxSize == 0 ? plotOptions.minimumShapeSizeInPixel : sizeInterPolator((abs(entry.size) / bubbleData.maxSize))
            }
            else{
                shapeSize = getShapeSize(entrySize: entry.size, maxSize: dataSet.maxSize, reference: referenceSize, normalizeSize: normalizeSize)
            }*/
            
            var shapeSize = getBubbleSize(sizeValue: entry.size ?? 0.0, scale: bubbleSizeScale, plotOptions: plotOptions, bubbleData: bubbleData)
            
            if entryDeleted
            {
                if entry.centerChanged != nil{
                    _pointBuffer = entry.centerChanged!
                }
                
                if entry.sizeChanged != nil {
                    shapeSize = entry.sizeChanged!.width
                }
            }

            let shapeHalf = shapeSize / 2.0
            
            var hightestPoint = CGPoint(x: rangeX, y: 0)
            
            hightestPoint = hightestPoint.applying(valueToPixelMatrix)
            
            if animator.phaseX < 1 && (_pointBuffer.x > hightestPoint.x + shapeHalf) {
                continue
            }

            
            if !viewPortHandler.isInBoundsTop(_pointBuffer.y + shapeHalf)
                || !viewPortHandler.isInBoundsBottom(_pointBuffer.y - shapeHalf)
            {
                continue
            }
            
            if chart.isRotated {
                if (chart.xAxis.isInverted) {
                    if !viewPortHandler.isInBoundsTop(_pointBuffer.y + shapeHalf)
                    {
                        break
                    }
                }else {
                    if !viewPortHandler.isInBoundsBottom(_pointBuffer.y - shapeHalf)
                    {
                        break
                    }
                }
                
                if !viewPortHandler.isInBoundsTop(_pointBuffer.y + shapeHalf) || !viewPortHandler.isInBoundsBottom(_pointBuffer.y - shapeHalf) {
                    continue
                }
                
            }
            else {
                if (chart.xAxis.isInverted) {
                    if !viewPortHandler.isInBoundsLeft(_pointBuffer.x + shapeHalf)
                    {
                        break
                    }
                }else {
                    if !viewPortHandler.isInBoundsRight(_pointBuffer.x - shapeHalf)
                    {
                        break
                    }
                }
                
                if !viewPortHandler.isInBoundsLeft(_pointBuffer.x + shapeHalf) || !viewPortHandler.isInBoundsRight(_pointBuffer.x - shapeHalf)
                {
                    continue
                }
            }
            
            /*if !viewPortHandler.isInBoundsRight(_pointBuffer.x - shapeHalf)
            {
                break
            }*/
            /*
            if entryDeleted
            {
                if entry.centerChanged != nil{
                    _pointBuffer = entry.centerChanged!
                }
            }
            */
            if entry.isIncluded
            {
                if chart.isRotated {
                    _pointBuffer.x = entry.barYValue
                }
                else {
                    _pointBuffer.y = entry.barYValue
                }
            }

            let color = dataSet.color(atIndex:  ChartUtils.doubleToIntSafeCast(value:entry.x))
            
            let rect = CGRect(
                x: _pointBuffer.x - shapeHalf,
                y: _pointBuffer.y - shapeHalf,
                width: shapeSize,
                height: shapeSize
            )
            
            
            // Since different shapes
            dataSetOptions.shapeProperties.size = CGSize(width: shapeSize, height: shapeSize)
            
            if (chart.includeLayer)
            {
                let bubbleLayer = BubbleLayer(chartView: chart, chartEntry: entry, dataSet: dataSet, point: _pointBuffer, shapeSize: dataSetOptions.shapeProperties.size)
                
                if customOpacity{
                    bubbleLayer.opacity = entry.opacityChanged
                }
                
            }
            else{
                context.setFillColor(color.cgColor)
                context.fillEllipse(in: rect)
            }
        }
        
        context.restoreGState()
    }
    
    open override func drawValues(context: CGContext)
    {
        guard
            let chart = chart,
            let viewPortHandler = self.viewPortHandler,
            let bubbleData = chart.data,
            let animator = animator
            else { return }
        
        // if values are drawn
//        if isDrawingValuesAllowed(dataProvider: dataProvider)
//        {
            let dataSets = bubbleData.dataSets
            
            let phaseX = max(0.0, min(1.0, animator.phaseX))
            let phaseY = animator.phaseY
            
            var pt = CGPoint()
            
            for i in 0..<dataSets.count
            {
                let dataSet = dataSets[i]
                
                guard let labelRectsforDataSet = chart.labelRectIndexMap[i], shouldDrawValues(forDataSet: dataSet) && dataSet.plotType == .Bubble || dataSet.plotType == .BubblePie else {
                    continue
                }
                
                let alpha = phaseX == 1 ? phaseY : phaseX
                
                guard let formatter = dataSet.valueFormatter else { continue }
                
                _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
                
                let iconsOffset = dataSet.iconsOffset
                
                for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
                {
                    guard let e = dataSet.entryForIndex(j) else { break }
                    
                    guard let labelRectDict = labelRectsforDataSet[j], !e.x.isNaN, !e.y.isNaN, !(e.size ?? 0.0).isNaN, !e.filterEnabled else
                    {
                        continue
                    }
                    
                    let valueTextColor = dataSet.valueTextColorAt(j).withAlphaComponent(CGFloat(alpha))
                    
                    pt.x = CGFloat(e.x)
                    pt.y = CGFloat(e.y * phaseY)
                    pt = chart.pixelForValues(isRotated: chart.isRotated, x: pt.x, y: pt.y, axisIndex: dataSet.axisIndex)
                    
                    if var labelRect = labelRectDict["y"] {
                        
                        labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                        
                        if let allowed = isInBounds(viewPortHandler: chart.viewPortHandler, originPoint: labelRect.origin) {
                            if allowed == 1 {
                                continue
                            }
                            else {
                                break
                            }
                        }
                        
                        let label = formatter.stringForValue(
                            Double(e.size ?? 0.0),
                            entry: e,
                            dataSetIndex: i,
                            viewPortHandler: viewPortHandler)
                            
                        let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
                            
                        drawLabel(chart: chart, label: label, labelAttributes: attributes, labelRect: labelRect)
                    }
                    
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                         ChartUtils.drawImage(context: context,
                                              image: icon,
                                              x: pt.x + iconsOffset.x,
                                              y: pt.y + iconsOffset.y,
                                              size: icon.size)
                    }
                    
                }
            }
    }
    
    open override func drawExtras(context: CGContext)
    {
        
    }
    
    /*open override func drawHighlighted(context: CGContext, indices: [Highlight])
    {
        guard let
            dataProvider = dataProvider,
            let viewPortHandler = self.viewPortHandler,
            let bubbleData = bubbleChartView?.data,
            let animator = animator
            else { return }
        
        context.saveGState()
        
        let phaseY = animator.phaseY
        
        for high in indices
        {
            guard
                let dataSet = bubbleData.getDataSetByIndex(high.dataSetIndex) as? IBubbleChartDataSet,
                dataSet.isHighlightEnabled
                else { continue }
                        
            guard let entry = dataSet.entryForXValue(high.x, closestToY: high.y) as? BubbleChartDataEntry else { continue }
            
            if !isInBoundsX(entry: entry, dataSet: dataSet) { continue }
            
            let trans = dataProvider.getTransformer(axisIndex: dataSet.axisIndex)
            
            _sizeBuffer[0].x = 0.0
            _sizeBuffer[0].y = 0.0
            _sizeBuffer[1].x = 1.0
            _sizeBuffer[1].y = 0.0
            
            trans.pointValuesToPixel(&_sizeBuffer)
            
            let normalizeSize = dataSet.isNormalizeSizeEnabled
            
            // calcualte the full width of 1 step on the x-axis
            let maxBubbleWidth: CGFloat = abs(_sizeBuffer[1].x - _sizeBuffer[0].x)
            let maxBubbleHeight: CGFloat = abs(viewPortHandler.contentBottom - viewPortHandler.contentTop)
            let referenceSize: CGFloat = min(maxBubbleHeight, maxBubbleWidth)
            
            _pointBuffer.x = CGFloat(entry.x)
            _pointBuffer.y = CGFloat(entry.y * phaseY)
            trans.pointValueToPixel(&_pointBuffer)
            
            let shapeSize = getShapeSize(entrySize: entry.size, maxSize: dataSet.maxSize, reference: referenceSize, normalizeSize: normalizeSize)
            let shapeHalf = shapeSize / 2.0
            
            if !viewPortHandler.isInBoundsTop(_pointBuffer.y + shapeHalf) ||
                !viewPortHandler.isInBoundsBottom(_pointBuffer.y - shapeHalf)
            {
                continue
            }
            
            if !viewPortHandler.isInBoundsLeft(_pointBuffer.x + shapeHalf)
            {
                continue
            }
            
            if !viewPortHandler.isInBoundsRight(_pointBuffer.x - shapeHalf)
            {
                break
            }
            
            let originalColor = dataSet.color(atIndex:  ChartUtils.doubleToIntSafeCast(value:entry.x))
            
            var h: CGFloat = 0.0
            var s: CGFloat = 0.0
            var b: CGFloat = 0.0
            var a: CGFloat = 0.0
            
            originalColor.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
            
            let color = NSUIColor(hue: h, saturation: s, brightness: b * 0.5, alpha: a)
            let rect = CGRect(
                x: _pointBuffer.x - shapeHalf,
                y: _pointBuffer.y - shapeHalf,
                width: shapeSize,
                height: shapeSize)
            
            context.setLineWidth(dataSet.highlightCircleWidth)
            context.setStrokeColor(color.cgColor)
            context.strokeEllipse(in: rect)
            
            high.setDraw(x: _pointBuffer.x, y: _pointBuffer.y)
        }
        
        context.restoreGState()
    }*/
}
