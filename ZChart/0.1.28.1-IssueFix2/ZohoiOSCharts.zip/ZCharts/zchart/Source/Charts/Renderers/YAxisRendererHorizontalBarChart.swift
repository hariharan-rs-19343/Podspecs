//
//  YAxisRendererHorizontalBarChart.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

open class YAxisRendererHorizontalBarChart: YAxisRenderer
{
    
    internal weak var chart: ChartViewBase?
    
    public override init(viewPortHandler: ViewPortHandler?, yAxis: YAxis?, transformer: Transformer?, chart: ChartViewBase?)
    {
        super.init(viewPortHandler: viewPortHandler, yAxis: yAxis, transformer: transformer, chart: chart)
        
        self.chart = chart
    }

    /// Computes the axis values.
    open override func computeAxis(min: Double, max: Double, inverted: Bool)
    {
        guard
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer
            else { return }
        
        var min = min, max = max
        
        // calculate the starting and entry point of the y-labels (depending on zoom / contentrect bounds)
        if viewPortHandler.contentHeight > 10.0 && !viewPortHandler.isFullyZoomedOutX
        {
            var p1 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop))
            var p2 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentRight, y: viewPortHandler.contentTop))
            
            p1 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: 0, point: p1)
            p2 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: 0, point: p2)
            
            if !inverted
            {
                min = Double(p1.x)
                max = Double(p2.x)
            }
            else
            {
                min = Double(p2.x)
                max = Double(p1.x)
            }
        }
        
//        computeAxisValues(min: min, max: max)
        guard let axis = axis,
              let chart = chart
        else { return }
        self.axis?.scaleTypeProtocol.computeAxisValues(min: min, max: max, axis: axis, chart: chart)
    }

    /// draws the y-axis labels to the screen
    open override func renderAxisLabels(context: CGContext)
    {
        guard
            let yAxis = axis as? YAxis,
            let viewPortHandler = self.viewPortHandler
            else { return }
        
        if !yAxis.isEnabled || !yAxis.isVisible  //|| !yAxis.isDrawLabelsEnabled
        {
            return
        }
        
        drawYLabels(context: context)
        
        drawAxisTitle(context: context,fixedPosition: yAxis.getFixedPositionForAxisTickLabel(isRotated: true, viewPortHandler: viewPortHandler))
    }
    
    open override func renderAxisLine(context: CGContext)
    {
        guard
            let yAxis = axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        if !yAxis.isEnabled || !yAxis.isVisible || !yAxis.drawAxisLineEnabled
        {
            return
        }
        
        context.saveGState()
        
        context.setStrokeColor(yAxis.axisLineColor.cgColor)
        context.setLineWidth(yAxis.axisLineWidth)
        if yAxis.axisLineDashLengths != nil
        {
            context.setLineDash(phase: yAxis.axisLineDashPhase, lengths: yAxis.axisLineDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        let contentTop = CommonHelperFunctions.contentTop(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentBottom = CommonHelperFunctions.contentBottom(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentLeft = CommonHelperFunctions.contentLeft(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentRight = CommonHelperFunctions.contentRight(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)

        if yAxis.axisDependency == .left
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentLeft, y: contentTop + yAxis.offsetCalculated))
            context.addLine(to: CGPoint(x: contentRight, y: contentTop + yAxis.offsetCalculated))
            context.strokePath()
        }
        else
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentLeft, y: contentBottom + yAxis.offsetCalculated))
            context.addLine(to: CGPoint(x: contentRight, y: contentBottom + yAxis.offsetCalculated))
            context.strokePath()        }
        
        context.restoreGState()
    }
/*
    /// draws the y-labels on the specified x-position
    open func drawYLabels(
        context: CGContext,
        fixedPosition: CGFloat,
        positions: [CGPoint],
        offset: CGFloat)
    {
        guard let
            yAxis = axis as? YAxis,
              let viewPort = viewPortHandler
            else { return }
        
        if !yAxis.drawLabelsEnabled {
            return
        }
        
        let labelFont = yAxis.labelFont
        let labelTextColor = yAxis.labelTextColor
        
        let from = yAxis.isDrawBottomYLabelEntryEnabled ? 0 : 1
        let to = yAxis.isDrawTopYLabelEntryEnabled ? yAxis.entryCount : (yAxis.entryCount - 1)
        
        let paraStyle = getParaStyle()
        
        let labelAttrs = [NSAttributedString.Key.font: labelFont, NSAttributedString.Key.foregroundColor: labelTextColor,NSAttributedString.Key.paragraphStyle: paraStyle]
        
        if !(yAxis.tickLabelMode == .wordwrap){
            paraStyle.lineBreakMode = .byTruncatingTail
        }
        
        var labelMaxSize = CGSize()
        
//        labelMaxSize.width = yAxis.labelRotatedWidth
        
        if yAxis.tickLabelMode == .wordwrap
        {
            labelMaxSize = yAxis.longestSize
        }
        
        if yAxis.tickLabelMode != .wordwrap
        {
            let labelSize = yAxis.longestLabel.size(withAttributes: labelAttrs)
            let rotatedSize = ChartUtils.sizeOfRotatedRectangle(labelSize, degrees: yAxis.labelRotationAngle)
            
            let height = (rotatedSize.height < yAxis.maxLabelHeight) ? rotatedSize.height : yAxis.maxLabelHeight
            
            if yAxis.labelRotationAngle != 0 && yAxis.labelRotationAngle != 180 && yAxis.labelRotationAngle != 360
            {
                labelMaxSize.width = abs( height / sin(yAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD) )
            }
            else{
                labelMaxSize.width = yAxis.labelRotatedWidth
            }
        }
        
        for i in stride(from: from, to: to, by: 1)
        {
            let text = yAxis.getFormattedLabel(i)
            
            var center = CGPoint(x: positions[i].x, y: fixedPosition)
            
                if yAxis.axisDependency == .left
                {
                    
                    var heightToAdd = (yAxis.labelRotationAngle == 0) ? yAxis.labelFont.lineHeight : min(yAxis.labelRotatedHeight,yAxis.maxLabelHeight)
                    
                    if yAxis.tickLabelMode == .wordwrap{
                        heightToAdd = yAxis.labelRotatedHeight
                    }
                    
                    center.y = center.y - yAxis.axisLabelOffsets.marginBotom
                    center.y = center.y - heightToAdd
                }
                else
                {
                    center.y = center.y + yAxis.axisLabelOffsets.marginTop
//                    center.y = center.y + offset
                }
            
            if !((viewPort.isInBoundsX(center.x)))
            {
                continue
            }
            
            drawLabel(context: context, formattedLabel: text, x: center.x, y: center.y, attributes: labelAttrs, constrainedToSize: labelMaxSize, anchor: CGPoint(x:0.5,y:0), angleRadians: yAxis.labelRotationAngle * ChartUtils.Math.FDEG2RAD)
        }
    }
    */
    override func drawAxisTitle(context: CGContext,fixedPosition: CGFloat)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPort = viewPortHandler,
            let chart = chart
            else { return }
        
        if !yAxis.axisTitleEnabled {
            return
        }
        
        let paraStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        
        let yLabelAttrs = [NSAttributedString.Key.font: yAxis.axisTitleFont,
                           NSAttributedString.Key.foregroundColor: yAxis.axisTitleColor,
                           NSAttributedString.Key.paragraphStyle: paraStyle]
        
        var labelMaxSize = CGSize()
        
        labelMaxSize.width = (viewPort.contentRect.width)*(3/4)
        
        let textWidth = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).width
        let textHeight = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).height
        
        var point = CGPoint()
        point.x = (viewPort.contentRect.midX) - (min(labelMaxSize.width,textWidth)/2)
        
        /*if yAxis.axisDependency == .left && yAxis.enabled
        {
            point.y = fixedPosition - (self.axis as! YAxis).getRequiredHeightSpace() + (yAxis.yOffset/2) + (textHeight)
        }
        else if yAxis.axisDependency == .right && yAxis.enabled
        {
            point.y = fixedPosition +  (self.axis as! YAxis).getRequiredHeightSpace() - (yAxis.yOffset/2) - (textHeight/2)          
            
        }*/
        
        if yAxis.axisDependency == .left && yAxis.enabled
        {
            point.y = fixedPosition - yAxis.getRequiredHeightSpace(constrainedWidth: viewPort.contentWidth, onePointWidth: CommonHelperFunctions.getOnePointWidth(chart: chart), scaleX: chart._viewPortHandler.scaleX) + yAxis.axisTitleOffsets.marginTop // (yAxis.yOffset)/2
        }
        else if yAxis.axisDependency == .right && yAxis.enabled
        {
            point.y = fixedPosition +  yAxis.getRequiredHeightSpace(constrainedWidth: viewPort.contentWidth, onePointWidth: CommonHelperFunctions.getOnePointWidth(chart: chart), scaleX: chart._viewPortHandler.scaleX) - yAxis.axisTitleOffsets.marginBotom - (textHeight)
            
        }
        
        drawLabelTruncated(context: context, formattedLabel: yAxis.axisTitle, x: point.x, y: point.y, attributes: yLabelAttrs, constrainedToSize: labelMaxSize, anchor: CGPoint(x:0,y:0), angleRadians: (0 * ChartUtils.Math.FDEG2RAD))
        
    }
    
    open override var gridClippingRect: CGRect
    {
        var contentRect = viewPortHandler?.contentRect ?? CGRect.zero
        let dx = self.axis?.gridLineWidth ?? 0.0
        contentRect.origin.x -= dx / 2.0
        contentRect.size.width += dx
        return contentRect
    }
    
    open override func drawGridLine(
        context: CGContext,
        position: CGPoint)
    {
        guard
            let viewPortHandler = self.viewPortHandler,
            let chart = chart
            else { return }
        
        let contentTop = CommonHelperFunctions.contentTop(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentBottom = CommonHelperFunctions.contentBottom(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        context.beginPath()
        context.move(to: CGPoint(x: position.x, y: contentTop))
        context.addLine(to: CGPoint(x: position.x, y: contentBottom))
        context.strokePath()
    }
    
    /// Draws the zero line at the specified position.
    open override func drawZeroLine(context: CGContext)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let zeroLineColor = yAxis.zeroLineColor
            else { return }
        
        context.saveGState()
        defer { context.restoreGState() }
        
        var clippingRect = viewPortHandler.contentRect
        clippingRect.origin.x -= yAxis.zeroLineWidth / 2.0
        clippingRect.size.width += yAxis.zeroLineWidth
        context.clip(to: clippingRect)
        
        context.setStrokeColor(zeroLineColor.cgColor)
        context.setLineWidth(yAxis.zeroLineWidth)
        
        let pos = transformer.pixelForValues(x: 0.0, y: 0.0)
        
        if yAxis.zeroLineDashLengths != nil
        {
            context.setLineDash(phase: yAxis.zeroLineDashPhase, lengths: yAxis.zeroLineDashLengths!)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        context.move(to: CGPoint(x: pos.x - 1.0, y: viewPortHandler.contentTop))
        context.addLine(to: CGPoint(x: pos.x - 1.0, y: viewPortHandler.contentBottom))
        context.drawPath(using: CGPathDrawingMode.stroke)
    }
    
    fileprivate var _limitLineSegmentsBuffer = [CGPoint](repeating: CGPoint(), count: 2)
    
    open override func renderLimitLines(context: CGContext)
    {
        guard
            let yAxis = axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = chartViewBase
            else { return }
        
        var limitLines = yAxis.limitLines
        
        if (!yAxis.isEnabled) || (!yAxis.visible) {
            return
        }

        if limitLines.count <= 0
        {
            return
        }
        
        context.saveGState()
        
        let trans = transformer.valueToPixelMatrix
        
        var position = CGPoint(x: 0.0, y: 0.0)
        
        for i in 0 ..< limitLines.count
        {
            let l = limitLines[i]
            
            if !l.isEnabled
            {
                continue
            }
            
            context.saveGState()
            defer { context.restoreGState() }

            var clippingRect = viewPortHandler.contentRect
            clippingRect.origin.x -= l.lineWidth / 2.0
            clippingRect.size.width += l.lineWidth
            context.clip(to: clippingRect)
            
            position.x = CGFloat(l.limit)
            position.y = 0.0
            position = transformer.pixelForValues(x: position.x, y: position.y)
            
            if !(viewPortHandler.isInBoundsX(position.x))
            {
                continue
            }
            
            let limitValueSize = l.getLimitValueSize(formattedString: l.getLimitValue(axis: yAxis))
            
            var limitTextSizeMax = max(yAxis.longestLabel.size(withAttributes: [NSAttributedString.Key.font: l.limitValueFont]).width, limitValueSize.width)
            
            if limitTextSizeMax > yAxis.maxLabelWidth
            {
                limitTextSizeMax = yAxis.maxLabelWidth
            }
            
            limitTextSizeMax = max(limitTextSizeMax,currentMaxLabelWidth)
            
            var frame:CGRect
            var endPoint:CGPoint
            
            let currentLabelHeight = max(yAxis.labelFont.lineHeight,limitValueSize.height)
            
//            currentLabelHeight = currentLabelHeight > yAxis.maxLabelHeight ? yAxis.maxLabelHeight : currentLabelHeight
            
            if yAxis.axisDependency == .left
            {
                let y = viewPortHandler.contentTop - (yAxis.axisLabelOffsets.marginBotom + yAxis.axisLabelOffsets.marginTop) - currentLabelHeight + yAxis.offsetCalculated
                
                let height = abs(viewPortHandler.contentTop - y) + yAxis.offsetCalculated
                
                frame = CGRect(x: position.x - (limitTextSizeMax/2), y: y, width: limitTextSizeMax, height: height )
                
                endPoint = CGPoint(x: position.x, y: viewPortHandler.contentBottom)
                
                if (!yAxis.drawLabelsEnabled || !yAxis.isVisible){
                    frame = CGRect(x: position.x, y: viewPortHandler.contentTop, width: 0, height: 0 )
                    endPoint = CGPoint(x: position.x, y: viewPortHandler.contentBottom)
                }
            }
            else{
                let height = (yAxis.axisLabelOffsets.marginBotom + yAxis.axisLabelOffsets.marginTop) + currentLabelHeight + yAxis.offsetCalculated
                
                frame = CGRect(x: position.x - (limitTextSizeMax/2), y: viewPortHandler.contentBottom + yAxis.offsetCalculated, width: limitTextSizeMax, height: height )
                
                endPoint = CGPoint(x: position.x, y: viewPortHandler.contentTop)
                
                if (!yAxis.drawLabelsEnabled || !yAxis.isVisible){
                    frame = CGRect(x: position.x, y: viewPortHandler.contentBottom, width: 0, height: 0 )
                    endPoint = CGPoint(x: position.x, y: viewPortHandler.contentTop)
                }
            }
            
            let layer = LimitLineLayer(chartViewBase: chart, axisRendererBase: self, charLimitLine: l, position: frame, endPoint: endPoint )
            self.chartViewBase?.nsuiLayer?.addSublayer(layer)
 
 
            
            
          /*  context.beginPath()
            context.move(to: CGPoint(x: position.x, y: viewPortHandler.contentTop))
            context.addLine(to: CGPoint(x: position.x, y: viewPortHandler.contentBottom))
            
            context.setStrokeColor(l.lineColor.cgColor)
            context.setLineWidth(l.lineWidth)
            if l.lineDashLengths != nil
            {
                context.setLineDash(phase: l.lineDashPhase, lengths: l.lineDashLengths!)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
            
            context.strokePath()*/
            if l.drawLabelEnabled && !l.label.isEmpty
            {
                renderLimitLineLabel(limitLine: l, limitLineLayer: layer, position: position, limitLineType: .vertical)
            }
        }
        
        context.restoreGState()
    }
    
    open override func renderBaseLine()
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = chartViewBase
            else { return }
        
        guard let baseLine = yAxis.baseLine
            else { return }
        
        if !yAxis.isEnabled || !yAxis.isVisible
        {
            return
        }
        
        let trans = transformer.valueToPixelMatrix
        
        var position = CGPoint(x: 0.0, y: 0.0)
        
        position.x = CGFloat(baseLine.baseValue)
        position.y = 0.0
        position = transformer.pixelForValues(x: position.x, y: position.y)
        
        let startPoint = CGPoint(x: position.x, y: viewPortHandler.contentTop)
        
        let endPoint = CGPoint(x: position.x, y: viewPortHandler.contentBottom)
        
        let layer = BaseLineLayer(chartViewBase: chart, axisRendererBase: self, chartBaseLine: baseLine, startPoint: startPoint, endPoint:endPoint)
        self.chartViewBase?.nsuiLayer?.addSublayer(layer)
  
    }
}
