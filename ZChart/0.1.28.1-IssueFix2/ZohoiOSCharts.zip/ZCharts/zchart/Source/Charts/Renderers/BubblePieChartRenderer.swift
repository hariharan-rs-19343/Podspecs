//
//  BubblePieChartRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 05/10/21.
//  Copyright © 2021 zoho. All rights reserved.


import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


open class BubblePieChartRenderer: BubbleChartRenderer
{
    
    open override func drawData(context: CGContext)
    {
        drawBubblePie(context: context)
    }
    
    open func drawBubblePie(context: CGContext)
    {
        guard
            let chart = chart,
            let viewPortHandler = self.viewPortHandler,
            let animator = animator,
            let bubbleData = (chart.data),
            let plotOptions = chart.getPlotOptions(type: .BubblePie) as? BubblePiePlotOptions,
            let processor = chart.getProcessor(type: .BubblePie) as? BubblePiePreprocessor,
            let dataSets = (chart.data?.dataSets.filter({$0.plotType == .BubblePie}))
            else { return }
        
        let dataSet = dataSets[0]
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        context.saveGState()
        
        let bubbleSizeScale = getBubbleSizeScale(bubbleData: bubbleData, plotOptions: plotOptions)
        
        let maxShapeSize = getBubbleSize(sizeValue: bubbleData.maxSize , scale: bubbleSizeScale, plotOptions: plotOptions, bubbleData: bubbleData)

        let maxShapeHalf = plotOptions.maximumShapeSizeInPixel != 0 ? plotOptions.maximumShapeSizeInPixel / 2.0 : maxShapeSize / 2.0

        let viewMinWidth = min(viewPortHandler.contentWidth, viewPortHandler.contentHeight)
        
        for (xVal,dict) in processor._buffer.sorted(by: {$0.0 < $1.0})
        {
            _pointBuffer = CGPoint()
            _pointBuffer.x = CGFloat(xVal)
           
            _pointBuffer = chart.pixelForValues(isRotated: chart.isRotated, x: _pointBuffer.x, y: _pointBuffer.y, axisIndex: dataSet.axisIndex)
            
            if chart.isRotated {
                if (chart.xAxis.isInverted) {
                    if !viewPortHandler.isInBoundsTop(_pointBuffer.y + maxShapeHalf)
                    {
                        break
                    }
                }else {
                    if !viewPortHandler.isInBoundsBottom(_pointBuffer.y - maxShapeHalf)
                    {
                        break
                    }
                }
                
                if !viewPortHandler.isInBoundsTop(_pointBuffer.y + maxShapeHalf) || !viewPortHandler.isInBoundsBottom(_pointBuffer.y - maxShapeHalf) {
                    continue
                }
                
            }
            else {
                if (chart.xAxis.isInverted) {
                    if !viewPortHandler.isInBoundsLeft(_pointBuffer.x + maxShapeHalf)
                    {
                        break
                    }
                }else {
                    if !viewPortHandler.isInBoundsRight(_pointBuffer.x - maxShapeHalf)
                    {
                        break
                    }
                }
                
                if !viewPortHandler.isInBoundsLeft(_pointBuffer.x + maxShapeHalf) || !viewPortHandler.isInBoundsRight(_pointBuffer.x - maxShapeHalf)
                {
                    continue
                }
            }
            
            for (yVal,pieConfigArray) in dict
            {
                _pointBuffer.x = CGFloat(xVal)
                _pointBuffer.y = CGFloat(yVal)
                _pointBuffer = chart.pixelForValues(isRotated: chart.isRotated, x: _pointBuffer.x, y: _pointBuffer.y, axisIndex: dataSet.axisIndex)
                
                if !viewPortHandler.isInBoundsTop(_pointBuffer.y + maxShapeHalf)
                    || !viewPortHandler.isInBoundsBottom(_pointBuffer.y - maxShapeHalf)
                {
                    continue
                }
                
                for pieConfig in pieConfigArray
                {
                    guard let entryArray = (pieConfig[0] as? [(ChartDataEntry,Int)]),
                          let pieBuilder = (pieConfig[1] as? PieBuilder)
                    else { continue }
                    
                    let sliceSpace = pieBuilder.values.count <= 1 ? 0.0 : PieChartRenderer.getSliceSpace(minValue: pieBuilder.values.min() ?? pieBuilder.values[0], minViewWidth: viewMinWidth, valueSum: pieBuilder.getYValueSum(), piePlotOption: plotOptions.piePlotoptions)
                    
                    var notNanSize = entryArray[0].0.size ?? 0.0
                    
                    if notNanSize.isNaN
                    {
                        for e in entryArray
                        {
                            if !((e.0.size ?? 0.0).isNaN)
                            {
                                notNanSize = e.0.size ?? 0.0
                                break
                            }
                        }
                    }
                    
                    let shapeSize = getBubbleSize(sizeValue: notNanSize , scale: bubbleSizeScale, plotOptions: plotOptions, bubbleData: bubbleData)

                    let shapeHalf = shapeSize / 2.0
                    
                    plotOptions.piePlotoptions.drawAngles = pieBuilder.drawAngles
                    plotOptions.piePlotoptions.radius = shapeHalf
                    
                    if  entryArray[0].0.filterEnabled
                    {
                        continue
                    }
                    
                    if entryDeleted
                    {
                        if entryArray[0].0.centerChanged != nil{
                            var center = entryArray[0].0.centerChanged!
                            if center.x.isNaN || center.y.isNaN
                            {
                                for e in entryArray
                                {
                                    if (!(e.0.centerChanged!.x.isNaN) && !(e.0.centerChanged!.y.isNaN))
                                    {
                                        center = e.0.centerChanged!
                                        break
                                    }
                                }
                            }
                            _pointBuffer = center
                        }
                        if entryArray[0].0.sizeChanged != nil{
                            var radius = entryArray[0].0.sizeChanged!.width/2.0
                            if radius.isNaN
                            {
                                for e in entryArray
                                {
                                    if !(e.0.sizeChanged!.width.isNaN)
                                    {
                                        radius = e.0.sizeChanged!.width/2.0
                                        break
                                    }
                                }
                            }
                            plotOptions.piePlotoptions.radius = radius
                        }
                    }
                    
                    if entryArray[0].0.isIncluded
                    {
                        var barYValue = entryArray[0].0.barYValue
                        if barYValue.isNaN
                        {
                            for e in entryArray
                            {
                                if !(e.0.barYValue.isNaN)
                                {
                                    barYValue = e.0.barYValue
                                    break
                                }
                            }
                        }
                        if chart.isRotated {
                            _pointBuffer.x = barYValue
                        }
                        else {
                            _pointBuffer.y = barYValue
                        }
                    }
                    
                    let pieBuffer = PieChartRenderer.prepareBuffer(entries: entryArray, piePlot: plotOptions.piePlotoptions, sliceCenter: _pointBuffer, sliceSpace: sliceSpace, animator: animator, isPiePlot: false)
                    
                    PieGenerator.generatePieLayers(_buffers: pieBuffer, chart: chart)
                }
            }
        }
        
        context.restoreGState()
    }
    
    open override func drawValues(context: CGContext)
    {
        guard
            let chart = chart,
            let viewPortHandler = self.viewPortHandler,
            let bubbleData = chart.data,
            let animator = animator
            else { return }
        
            let dataSets = bubbleData.dataSets
            
            let phaseX = max(0.0, min(1.0, animator.phaseX))
            let phaseY = animator.phaseY
            
            for i in 0..<dataSets.count
            {
                let dataSet = dataSets[i]
                
                guard let labelRectsforDataSet = chart.labelRectIndexMap[i], shouldDrawValues(forDataSet: dataSet) && dataSet.plotType == .BubblePie else {
                    continue
                }
                
                let alpha = phaseX == 1 ? phaseY : phaseX
                
                guard let formatter = dataSet.valueFormatter else { continue }
                
                _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
                
                let iconsOffset = dataSet.iconsOffset
                
                for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
                {
                    guard let e = dataSet.entryForIndex(j) else { break }
                    
                    guard let labelRectDict = labelRectsforDataSet[j], !e.x.isNaN, !e.y.isNaN, !(e.size ?? 0.0).isNaN, !e.filterEnabled else
                    {
                        continue
                    }
                    
                    let valueTextColor = dataSet.valueTextColorAt(j).withAlphaComponent(CGFloat(alpha))
                    
                    if var labelRect = labelRectDict["y"] {
                        
                        labelRect.origin = chart.pixelForValues(x: labelRect.origin.x, y: labelRect.origin.y, axisIndex: dataSet.axisIndex)
                        
                        if let allowed = isInBounds(viewPortHandler: chart.viewPortHandler, originPoint: labelRect.origin) {
                            if allowed == 1 {
                                continue
                            }
                            else {
                                break
                            }
                        }
                        
                        let label = formatter.stringForValue(
                            e.y,
                            entry: e,
                            dataSetIndex: i,
                            viewPortHandler: viewPortHandler)
                            
                        let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
                            
                        drawLabel(chart: chart, label: label, labelAttributes: attributes, labelRect: labelRect)
                    }
                    
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                        var pt = CGPoint()
                        pt.x = CGFloat(e.x)
                        pt.y = CGFloat(e.y * phaseY)
                        pt = chart.pixelForValues(isRotated: chart.isRotated, x: pt.x, y: pt.y, axisIndex: dataSet.axisIndex)
                        
                         ChartUtils.drawImage(context: context,
                                              image: icon,
                                              x: pt.x + iconsOffset.x,
                                              y: pt.y + iconsOffset.y,
                                              size: icon.size)
                    }
                }
            }
    }
}

