//
//  ScatterChartRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
import UIKit
#endif


open class ScatterChartRenderer: LineScatterCandleRadarRenderer
{
    open var entryDeleted = false
    
    open override func drawData(context: CGContext)
    {
        guard let chart = chart,
              let scatterData = chart.data else { return }
        
        ScatterLayer.removeAllScatterLayer(chart: chart)
        
        /* Dynamic scatter shape size
        if scatterData.minimumShapeSizeInPixel != 0 && scatterData.maximumShapeSizeInPixel != 0 && (scatterData.maxWidthZoomRestrictionPixel != CGFloat.greatestFiniteMagnitude)
        {
            prepareShapeSize()
        }*/
        
        for i in 0 ..< scatterData.dataSetCount
        {
            guard let set = scatterData.getDataSetByIndex(i) else { continue }
            
            if set.isVisible && set.plotType == .Scatter
            {
                drawDataSet(context: context, dataSet: set)
            }
        }
    }
    
    fileprivate var _lineSegments = [CGPoint](repeating: CGPoint(), count: 2)
    
    fileprivate func prepareShapeSize()
    {
        guard let scatterChart = chart,
              let linePlotOptions = scatterChart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
            else{ return }
        
        
        
        let maxSize = linePlotOptions.maximumShapeSizeInPixel
        
        let minSize = linePlotOptions.minimumShapeSizeInPixel
        
        let minimumOnePointWidth = minSize
        
        var currentOnePointWidth = CommonHelperFunctions.getOnePointWidth(chart: scatterChart)
        
        if scatterChart.xAxis.scaleType != .Ordinal
        {
            currentOnePointWidth =  CommonHelperFunctions.getMaxWidthBetweenEntries(barLine: scatterChart)
        }
        
        let maxOnePointWidth = linePlotOptions.maxWidthZoomRestrictionPixel
        
        let originalDifference = maxOnePointWidth - minimumOnePointWidth
        
        let curDifference = currentOnePointWidth - minimumOnePointWidth
        
        var percentage = (curDifference/originalDifference)
        
        if percentage > 1
        {
            percentage = 1
        }
        else if percentage < 0
        {
            percentage = 0
        }
        
        
        
        let interPolator = Interpolator.interpolate(a: minSize, b: maxSize)
        
        guard let scatterData = scatterChart.data
        else { return }
        for set in (scatterData.dataSets)
        {
            guard let dataSetOptions = set.dataSetOptions as? AxisChartDataSetOptions
                else { continue }
            let shapeProperties = dataSetOptions.shapeProperties
            let shapeSize = interPolator(percentage)
            shapeProperties.size = CGSize(width: shapeSize, height: shapeSize)
        }
        
    }
    
    
    open func drawDataSet(context: CGContext, dataSet: IChartDataSet)
    {
        guard
            let chart = chart,
            let animator = animator,
            let viewPortHandler = chart.viewPortHandler
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let phaseY = animator.phaseY
        
        let entryCount = dataSet.entryCount
        
        var point = CGPoint()
        
        if let dataSetOption = dataSet.dataSetOptions as? AxisChartDataSetOptions{
            if dataSetOption.shapeProperties.shapeType == .Default {
                dataSetOption.shapeProperties.shapeType = .circle
            }
        }
        
//        if let renderer = dataSet.shapeRenderer
//        {
        context.saveGState()
        
        for j in 0 ..<  ChartUtils.doubleToIntSafeCast(value:min(ceil(Double(entryCount) * animator.phaseX), Double(entryCount)))
        {
            guard let e = dataSet.entryForIndex(j) else { continue }
            
            if e.filterEnabled || e.x.isNaN || e.y.isNaN
            {
                continue
            }
            
            point.x = CGFloat(e.x)
            point.y = CGFloat(e.y * phaseY)
            point = chart.pixelForValues(isRotated: chart.isRotated, x: point.x, y: point.y, axisIndex: dataSet.axisIndex)
            
            if chart.isRotated {
                if (chart.xAxis.isInverted) {
                    if !viewPortHandler.isInBoundsTop(point.y)
                    {
                        break
                    }
                }else {
                    if !viewPortHandler.isInBoundsBottom(point.y)
                    {
                        break
                    }
                }
                
                if !viewPortHandler.isInBoundsTop(point.y) || !viewPortHandler.isInBoundsBottom(point.y) {
                    continue
                }
                
            }
            else {
                if (chart.xAxis.inverted) {
                    if !viewPortHandler.isInBoundsLeft(point.x)
                    {
                        break
                    }
                }else {
                    if !viewPortHandler.isInBoundsRight(point.x)
                    {
                        break
                    }
                }
                
                if !viewPortHandler.isInBoundsLeft(point.x) || !viewPortHandler.isInBoundsRight(point.x)
    //                || !viewPortHandler.isIn  BoundsY(point.y) //COMMENTED OUT Y BOUND FOR FILTER-IN ANIMATION
                {
                    continue
                }
            }
            
            if entryDeleted
            {
                if e.centerChanged != nil{
                    point = e.centerChanged!
                }
            }
            
            if e.isIncluded
            {
                if chart.isRotated {
                    point.x = e.barYValue
                }
                else {
                    point.y = e.barYValue
                    
                }
            }
            
            if (chart.includeLayer)
            {
                guard let dataSetOption = dataSet.dataSetOptions as? AxisChartDataSetOptions
                else { return }
                let scatterLayer = ScatterLayer(chartView: chart, chartEntry: e, dataSet: dataSet, point: point, shapeSize: dataSetOption.shapeProperties.size)
                
                if customOpacity{
                    scatterLayer.opacity = e.opacityChanged
                }
                
            }
            /*else{
                renderer.renderShape(context: context, dataSet: dataSet, viewPortHandler: viewPortHandler, point: point, color: dataSet.color(atIndex: j))
            }*/
        }
        
        context.restoreGState()
       /* }
        else
        {
            print("There's no IShapeRenderer specified for ScatterDataSet", terminator: "\n")
        }*/
    }
    
    open override func drawValues(context: CGContext)
    {
        guard
            let chart = chart,
            let scatterData = chart.data,
            let animator = animator,
            let viewPortHandler = self.viewPortHandler
            else { return }
        
            let dataSets = scatterData.dataSets
            
            let phaseY = animator.phaseY
            
            var pt = CGPoint()
            
            for i in 0 ..< scatterData.dataSetCount
            {
                let dataSet = dataSets[i]
                
                guard (dataSet.plotType == .Scatter) ,
                      let labelRectsforDataSet = chart.labelRectIndexMap[i]
                    else { continue }
                
                if !shouldDrawValues(forDataSet: dataSet)
                {
                    continue
                }
                
                guard let formatter = dataSet.valueFormatter else { continue }
                
                let iconsOffset = dataSet.iconsOffset
                
                _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
                
                for j in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
                {
                    guard let e = dataSet.entryForIndex(j) else { break }
                    
                    guard let labelRectDict = labelRectsforDataSet[j], !e.filterEnabled,  !e.x.isNaN, !e.y.isNaN else
                    {
                        continue
                    }
                    
                    pt.x = CGFloat(e.x)
                    pt.y = CGFloat(e.y * phaseY)
                    pt = chart.pixelForValues(isRotated: chart.isRotated, x: pt.x, y: pt.y, axisIndex: dataSet.axisIndex)
                    
                    if var labelRect = labelRectDict["y"] {
                        
                        labelRect.origin = chart.pixelForValues(point: labelRect.origin, axisIndex: dataSet.axisIndex)
                        
                        if let allowed = isInBounds(viewPortHandler: chart.viewPortHandler, originPoint: labelRect.origin) {
                            if allowed == 1 {
                                continue
                            }
                            else {
                                break
                            }
                        }
                        
                        if isDataLappingOverLappingWithPlot(rect: labelRect) {
                            continue
                        }
                        
                        let label = formatter.stringForValue(
                            e.y,
                            entry: e,
                            dataSetIndex: i,
                            viewPortHandler: viewPortHandler)
                            
                        let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(j)]
                            
                        drawLabel(chart: chart, label: label, labelAttributes: attributes, labelRect: labelRect)
                    }
                    
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                        ChartUtils.drawImage(context: context,
                                             image: icon,
                                             x: pt.x + iconsOffset.x,
                                             y: pt.y + iconsOffset.y,
                                             size: icon.size)
                    }
                }
            }
//        }
    }
    
    open override func drawExtras(context: CGContext)
    {
        
    }
    
    /*open override func drawHighlighted(context: CGContext, indices: [Highlight])
    {
        guard
            let dataProvider = dataProvider,
            let scatterData = scatterChartView?.data,
            let animator = animator
            else { return }
        
        context.saveGState()
        
        for high in indices
        {
            guard
                let set = scatterData.getDataSetByIndex(high.dataSetIndex) as? IScatterChartDataSet,
                set.isHighlightEnabled
                else { continue }
            
            guard let entry = set.entryForXValue(high.x, closestToY: high.y) else { continue }
            
            if !isInBoundsX(entry: entry, dataSet: set) { continue }
            
            context.setStrokeColor(set.highlightColor.cgColor)
            context.setLineWidth(set.highlightLineWidth)
            if set.highlightLineDashLengths != nil
            {
                context.setLineDash(phase: set.highlightLineDashPhase, lengths: set.highlightLineDashLengths!)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
            
            let x = entry.x // get the x-position
            let y = entry.y * Double(animator.phaseY)
            
            let trans = dataProvider.getTransformer(axisIndex: set.axisIndex)
            
            let pt = trans.pixelForValues(x: x, y: y)
            
            high.setDraw(pt: pt)
            
            // draw the lines
            drawHighlightLines(context: context, point: pt, set: set)
        }
        
        context.restoreGState()
    }*/
}
