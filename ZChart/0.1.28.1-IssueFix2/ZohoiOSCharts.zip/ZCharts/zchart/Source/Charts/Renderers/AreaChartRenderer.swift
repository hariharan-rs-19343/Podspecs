//
//  AreaChartRenderer.swift
//  zchart
//
//  Created by Keerthivass B S on 09/05/24.
//

import Foundation

open class AreaChartRenderer: LineChartRenderer {
    
    // MARK: - Draw Data
    open override func drawData(context: CGContext)
    {
        guard let lineData = chart?.data else { return }
        
        for i in 0 ..< lineData.dataSetCount
        {
            guard let set = lineData.getDataSetByIndex(i) else { continue }
            
            if set.isVisible && set.plotType == .Area
            {
                drawDataSet(context: context, dataSet: set)
            }
        }
    }
    
    override func drawMarkerLayers(context:CGContext)
    {
        guard let chart = chart,
            let lineData = chart.data,
            let animator = animator
            else { return }
        
        if chart.interactionAnimationInProgress
        {
            return
        }
        
        let dataSets = lineData.dataSets
        
         context.saveGState()
        
        for i in 0 ..< dataSets.count
        {
            guard let dataSet = lineData.getDataSetByIndex(i),
            (dataSet.plotType == .Area)
            else { continue }
            
            let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
            
            if !dataSet.isVisible ||  !lineDataSetOptions.drawShapeEnabled || dataSet.entryCount == 0
            {
                continue
            }
            
            drawMarkerLayer(context:context, dataSet: dataSet, setIndex: i, lineDataSetOptions: lineDataSetOptions)
            
        }
        
        context.restoreGState()
    }
}
