//
//  HorizontalWaterFallChartRenderer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 29/06/22.
//
/*
import Foundation

open class HorizontalWaterFallChartRenderer: HorizontalBarChartRenderer {
    
    override open func prepareBuffer(dataSet: IChartDataSet, index: Int) {
        
        guard
            let barLineChart = chart,
            let processor = barLineChart.getProcessor(type: .WaterFall) as? WaterFallPreprocessor,
            let plotOption = barLineChart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions,
            let animator = animator,
            processor.entriesStackedYValue[index] != nil
            else { return }
        
        let barWidthHalf = plotOption.barWidth / 2.0
    
        let buffer = _buffers[index]
        var bufferIndex = 0
        let containsStacks = plotOption.isStacked
        
        let setIndex = index
        
        let isInverted = barLineChart.isInverted(axisIndex: dataSet.axisIndex)
        let phaseY = animator.phaseY
        var barRect = CGRect()
        var x: Double
        var y: Double
        
        let baseLineValue:Double = CommonHelperFunctions.getBaseLineValue(chart: barLineChart, dataSet: dataSet)
        
        var start = 0
        var end = min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)
        var increment = 1
        
        if (barLineChart.xAxis.inverted) {
            start = dataSet.entryCount - 1
            end = dataSet.entryCount - (min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)) - 1
            increment = -1
        }
        
        for i in stride(from: start, to: end, by: increment)
        {
            guard let e = dataSet.entryForIndex(i),
                  let value = (processor.entriesStackedYValue[setIndex]?[i])
                  else { continue }
            
            x = e.x
            y = e.y
            
            var prevEntry = dataSet.entryForIndex(i-1)
            
            var counterIndex = i-1
            
            while prevEntry != nil && (prevEntry?.x.isNaN)!
            {
                counterIndex -= 1
                prevEntry = dataSet.entryForIndex(counterIndex)
            }
            
            var yStart = baseLineValue
            
            let yValue = y.isNaN ? 0 : y
            
            if prevEntry != nil && !WaterFallHelperFunction.isCascade(entry: e) {
                if let prevYval = (processor.entriesStackedYValue[setIndex]?[counterIndex]) {
                    yStart = prevYval
                }
            }
            
            var isPositive = yValue > 0 ? true : false
            
            if containsStacks
            {
                
                if WaterFallHelperFunction.isCascade(entry: e) {
                    
                    yStart = WaterFallHelperFunction.getBaseYvalueForCascade(chart: barLineChart, value: value, setIndex: setIndex, entryIndex: i)
                    
                }
                else {
                    if yValue >= baseLineValue
                    {
                        yStart = value - abs(yValue)
                    }
                    else{
                        yStart = value + abs(yValue)
                    }
                }
                
            }
            
            if WaterFallHelperFunction.isCascade(entry: e) {
                isPositive = value > 0 ? true : false
            }
            
            let top = CGFloat(x - barWidthHalf)
            let bottom = CGFloat(x + barWidthHalf)
            
            var left = isInverted
                ? (value <= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value >= yStart ? CGFloat(value) : CGFloat(yStart))
            var right = isInverted
                ? (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value <= yStart ? CGFloat(value) : CGFloat(yStart))
            
            // multiply the height of the rect with the phase
            
            var leftInterPolator = Interpolator.interpolate(a: CGFloat(right), b: left)
            
            var rightInterPolator = Interpolator.interpolate(a: CGFloat(left), b: right)
            
            if containsStacks {
                
                let baseValue = WaterFallHelperFunction.getBaseValue(chart: barLineChart, entry: e)
                
                rightInterPolator = Interpolator.interpolate(a: CGFloat(baseValue), b: right)
                
                leftInterPolator = Interpolator.interpolate(a: CGFloat(baseValue), b: left)
                
                right = rightInterPolator(CGFloat(phaseY))
                
                left = leftInterPolator(CGFloat(phaseY))
            }
            else {
                if isPositive {
                    left = leftInterPolator(CGFloat(phaseY))
                } else {
                    right = rightInterPolator(CGFloat(phaseY))
                }
            }
            
            barRect.origin.x = left
            barRect.size.width = right - left
            barRect.origin.y = top
            barRect.size.height = bottom - top
            
            buffer.rects[bufferIndex] = barRect
            bufferIndex += 1
            
        }
    }
    
    public static func getHorizontalWaterFallRectArray(entries: [ChartDataEntry],animator: Animator,dataSet: IChartDataSet,chart:ChartViewBase) -> [CGRect] {
        
        var waterFallRectArray:[CGRect] = []
        
        guard
            let index = chart.data?.indexOfDataSet(dataSet),
            let processor = chart.getProcessor(type: .WaterFall) as? WaterFallPreprocessor,
            let plotOption = chart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions,
            processor.entriesStackedYValue[index] != nil
            else { return waterFallRectArray }
        
        let barWidthHalf = plotOption.barWidth / 2.0
        
        var bufferIndex = 0
        let containsStacks = plotOption.isStacked
        
        let setIndex = index
        
        let isInverted = chart.isInverted(axisIndex: dataSet.axisIndex)
        let phaseY = animator.phaseY
        var waterFallRect = CGRect()
        var x: Double
        var y: Double
        
        let baseLineValue:Double = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
        
        var start = 0
        var end = min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)
        var increment = 1
        
        if (chart.xAxis.inverted) {
            start = dataSet.entryCount - 1
            end = dataSet.entryCount - (min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)) - 1
            increment = -1
        }
        
            for i in stride(from: start, to: end, by: increment)
            {
                guard let e = dataSet.entryForIndex(i),
                  let value = (processor.entriesStackedYValue[setIndex]?[i])
                  else { continue }
            
                x = e.x
                y = e.y
            
                var prevEntry = dataSet.entryForIndex(i-1)
            
                var counterIndex = i-1
            
                while prevEntry != nil && (prevEntry?.x.isNaN)!
                {
                    counterIndex -= 1
                    prevEntry = dataSet.entryForIndex(counterIndex)
                }
            
                var yStart = baseLineValue
            
                let yValue = y.isNaN ? 0 : y
            
                if prevEntry != nil && !WaterFallHelperFunction.isCascade(entry: e) {
                    if let prevYval = (processor.entriesStackedYValue[setIndex]?[counterIndex]) {
                        yStart = prevYval
                    }
                }
            
                var isPositive = yValue > 0 ? true : false
                
                if containsStacks
                {
                    
                    if WaterFallHelperFunction.isCascade(entry: e) {
                        
                        yStart = WaterFallHelperFunction.getBaseYvalueForCascade(chart: chart, value: value, setIndex: setIndex, entryIndex: i)
                        
                    }
                    else {
                        if yValue >= baseLineValue
                        {
                            yStart = value - abs(yValue)
                        }
                        else{
                            yStart = value + abs(yValue)
                        }
                    }
                    
                }
            
                if WaterFallHelperFunction.isCascade(entry: e) {
                    isPositive = value > 0 ? true : false
                }
                
                let top = CGFloat(x - barWidthHalf)
                let bottom = CGFloat(x + barWidthHalf)
            
                var left = isInverted
                    ? (value <= yStart ? CGFloat(value) : CGFloat(yStart))
                    : (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                var right = isInverted
                    ? (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                    : (value <= yStart ? CGFloat(value) : CGFloat(yStart))
            
                // multiply the height of the rect with the phase
                
                var leftInterPolator = Interpolator.interpolate(a: CGFloat(right), b: left)
                
                var rightInterPolator = Interpolator.interpolate(a: CGFloat(left), b: right)
                
                if containsStacks {
                    
                    let baseValue = WaterFallHelperFunction.getBaseValue(chart: chart, entry: e)
                    
                    rightInterPolator = Interpolator.interpolate(a: CGFloat(baseValue), b: right)
                    
                    leftInterPolator = Interpolator.interpolate(a: CGFloat(baseValue), b: left)
                    
                    right = rightInterPolator(CGFloat(phaseY))
                    
                    left = leftInterPolator(CGFloat(phaseY))
                }
                else {
                    if isPositive {
                        left = leftInterPolator(CGFloat(phaseY))
                    } else {
                        right = rightInterPolator(CGFloat(phaseY))
                    }
                }
            
                BarChartRenderer.updateBarRect(barRect: &waterFallRect, isRotated: chart.isRotated, top: top, bottom: bottom, left: left, right: right)
            
                waterFallRectArray.append(waterFallRect)
                bufferIndex += 1
            }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        trans.rectValuesToPixel(&waterFallRectArray)
        
        return waterFallRectArray
    }
    
    override open func drawExtras(context: CGContext) {
        
        guard
            let chart = chart,
            let data = chart.data,
            let processor = chart.getProcessor(type: .WaterFall) as? WaterFallPreprocessor,
            let plotOption = chart.getPlotOptions(type: .WaterFall) as? WaterFallPlotOptions
        else {
            return
        }
        
        if !plotOption.isConnectorEnabled || chart.interactionAnimationInProgress {
            return
        }
        
        let datasets = data.dataSets
        
        let isconnectorLineEnabledForZeroAndNan = plotOption.isconnectorLineEnabledForZeroAndNan
        
        context.saveGState()
        
        let path = CGMutablePath()
        
        let barHalf = plotOption.barWidth / 2.0
        
        if plotOption.isStacked {
            
            guard let xString = data.xString else {
                context.restoreGState()
                return
            }
            
            let trans = chart.getTransformer(axisIndex: datasets[0].axisIndex)
            
            let layer = WaterFallHelperFunction.createConnectorLayer(chart: chart)
            
            var basevalue = 0.0
            
            for xIndex in 0..<xString.count - 1{
                
                let currentYval = WaterFallHelperFunction.getMaxYValueForX(chart: chart, xVal: Double(xIndex), BaseValue: basevalue)
                
                var connectorLength = barHalf
                
                if isconnectorLineEnabledForZeroAndNan {
                    
                    if WaterFallHelperFunction.isZeroOrNan(entriesStackedYValue: processor.entriesStackedYValue, datasets: datasets, xIndex: xIndex, CurrentBaseValue: currentYval) {
                    
                        if xIndex == 0 {
                        
                            connectorLength = -barHalf
                        }
                        else {
                            connectorLength = 0.0
                        }
                    }
                }
                
                let isNextCascade = processor.cascadeIndex.contains(xIndex + 1)
                
                var fromPoint = CGPoint(x: currentYval,y: Double(xIndex) + connectorLength)
                
                var toPoint: CGPoint
                
                basevalue = currentYval
                
                if isNextCascade {
                    basevalue = 0.0
                }
                
                let nextYval = WaterFallHelperFunction.getMaxYValueForX(chart: chart, xVal: Double(xIndex + 1), BaseValue: basevalue)
                
                if isconnectorLineEnabledForZeroAndNan {
                    
                    if WaterFallHelperFunction.isZeroOrNan(entriesStackedYValue: processor.entriesStackedYValue, datasets: datasets, xIndex: xIndex + 1, CurrentBaseValue: nextYval) {
                        
                        if (xIndex + 1) == xString.count - 1 {
                            connectorLength = -barHalf
                        }
                        else {
                            connectorLength = 0.0
                        }
                        
                    }
                    else {
                        connectorLength = barHalf
                    }
                }
                                
                if isNextCascade {
                    toPoint = CGPoint(x: nextYval,y: Double(xIndex + 1) - connectorLength)
                }
                else {
                    toPoint = CGPoint(x: currentYval,y: Double(xIndex + 1) - connectorLength)
                }
                
                trans.pointValueToPixel(&fromPoint)
                
                trans.pointValueToPixel(&toPoint)
                
                path.move(to: fromPoint)
                path.addLine(to: toPoint)
            }
            
            layer.path = path//.cgPath
            
            self.chart?.plotView?.nsuiLayer?.addSublayer(layer)
            
            context.restoreGState()
            
            return
            
        }
        
        for setIndex in 0..<datasets.count {
            
            if !datasets[setIndex].isVisible {
                continue;
            }
            
            let trans = chart.getTransformer(axisIndex: datasets[setIndex].axisIndex)
            
            let layer = WaterFallHelperFunction.createConnectorLayer(chart: chart)
            
            if processor.entriesStackedYValue[setIndex] == nil {
                continue;
            }
            
            for entryIndex in 0..<datasets[setIndex].entryCount - 1 {
                
                guard let currentEntry = datasets[setIndex].entryForIndex(entryIndex),
                      let currentYval = processor.entriesStackedYValue[setIndex]?[entryIndex]
                    else {
                    return
                }
                
                if currentEntry.x.isNaN {
                    continue
                }
                
                var connectorLength = barHalf
                
                let isCurrentCascade = WaterFallHelperFunction.isCascade(entry: currentEntry)
                
                if isconnectorLineEnabledForZeroAndNan {
                    if (!isCurrentCascade && currentEntry.y.isZero || currentEntry.y.isNaN)
                        || isCurrentCascade && currentYval.isZero {
                    
                        if currentEntry.x.isZero {
                        
                            connectorLength = -barHalf
                        }
                        else {
                            connectorLength = 0.0
                        }
                    }
                }
                
                let nextEntry = WaterFallHelperFunction.getNextEntry(dataset: datasets[setIndex], index: entryIndex + 1)
                /*
                var counterIndex = entryIndex + 1
                
                while nextEntry != nil && (nextEntry?.x.isNaN)!
                {
                    counterIndex += 1
                    nextEntry = datasets[setIndex].entryForIndex(counterIndex)
                }
                */
                
                if nextEntry == nil {
                    continue
                }
                
                let counterIndex = datasets[setIndex].entryIndex(entry: nextEntry!)
                
                guard let nextYval = processor.entriesStackedYValue[setIndex]?[counterIndex]
                else { continue }
                                
                let isNextCascade = ((nextEntry!.plotData as? Int) != nil) && (nextEntry!.plotData as! Int) == 1
                
                var fromPoint = CGPoint(x: currentYval,y: currentEntry.x + connectorLength)
                
                var toPoint: CGPoint
                
                if isconnectorLineEnabledForZeroAndNan {
                    if (!isNextCascade && nextEntry!.y.isZero || nextEntry!.y.isNaN)
                        || isNextCascade && nextYval.isZero {
                        
                        if counterIndex == datasets[setIndex].entryCount - 1 {
                            connectorLength = -barHalf
                        }
                        else {
                            connectorLength = 0.0
                        }
                    }
                    else {
                        connectorLength = barHalf
                    }
                }
                                
                if isNextCascade && nextYval != nil {
                    toPoint = CGPoint(x: nextYval, y: nextEntry!.x - connectorLength)
                }
                else {
                    toPoint = CGPoint(x: currentYval,y: nextEntry!.x - connectorLength)
                }
                
                trans.pointValueToPixel(&fromPoint)
                
                trans.pointValueToPixel(&toPoint)
                
                path.move(to: fromPoint)
                path.addLine(to: toPoint)
            }
            
            layer.path = path//.cgPath
            
            self.chart?.plotView?.nsuiLayer?.addSublayer(layer)
        }
        
        context.restoreGState()
    }
}
*/
