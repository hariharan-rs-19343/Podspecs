//
//  YAxisRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

@objc(ChartYAxisRenderer)
open class YAxisRenderer: AxisRendererBase
{
    open var currentMaxLabelWidth:CGFloat = 0
    
    public init(viewPortHandler: ViewPortHandler?, yAxis: YAxis?, transformer: Transformer?, chart: ChartViewBase?)
    {
        super.init(viewPortHandler: viewPortHandler, transformer: transformer, axis: yAxis, chartViewBase: chart)
    }
    
    open override func computeAxis(min: Double, max: Double, inverted: Bool) {
        super.computeAxis(min: min, max: max, inverted: inverted)
    }
    
    open override func updateLongestLabel()
    {
        if let yAxis = self.axis as? YAxis
        {
            yAxis.longestLabel = getLongestLabelOfAllData(axis: yAxis)
        }
    }
    
    /// draws the y-axis labels to the screen
    open override func renderAxisLabels(context: CGContext)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler
            else { return }
        
        if !yAxis.isEnabled || !yAxis.isVisible //|| !yAxis.isDrawLabelsEnabled
        {
            return
        }
        
        drawYLabels(context: context)
        
        drawAxisTitle(context: context,fixedPosition: yAxis.getFixedPositionForAxisTickLabel(isRotated: false, viewPortHandler: viewPortHandler))
        
    }
    
    open override func renderAxisLine(context: CGContext)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        if !yAxis.isEnabled || !yAxis.isVisible || !yAxis.drawAxisLineEnabled
        {
            return
        }
        
        context.saveGState()
        
        context.setStrokeColor(yAxis.axisLineColor.cgColor)
        context.setLineWidth(yAxis.axisLineWidth)
        if yAxis.axisLineDashLengths != nil
        {
            context.setLineDash(phase: yAxis.axisLineDashPhase, lengths: yAxis.axisLineDashLengths)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        let contentTop = CommonHelperFunctions.contentTop(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentBottom = CommonHelperFunctions.contentBottom(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentLeft = CommonHelperFunctions.contentLeft(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentRight = CommonHelperFunctions.contentRight(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        if yAxis.axisDependency == .left
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentLeft + yAxis.offsetCalculated, y: contentTop))
            context.addLine(to: CGPoint(x: contentLeft + yAxis.offsetCalculated, y: contentBottom))
            context.strokePath()
        }
        else
        {
            context.beginPath()
            context.move(to: CGPoint(x: contentRight + yAxis.offsetCalculated, y: contentTop))
            context.addLine(to: CGPoint(x: contentRight + yAxis.offsetCalculated, y: contentBottom))
            context.strokePath()
        }
        
        context.restoreGState()
    }
    
    /// draws the y-labels on the specified x-position
    internal func drawYLabels(
        context: CGContext)
    {
        guard let viewPort = viewPortHandler, let chart = chartViewBase else {
            return
        }
        
        for tickLabel in self.tickLabels {
            
            if chart.isRotated {
                if !(viewPort.isInBoundsX(tickLabel.point.x))
                {
                    continue
                }
            }
            else {
                if !(viewPort.isInBoundsY(tickLabel.point.y))
                {
                    continue
                }
            }
            
            if chart.isRotated {
                drawLabel(context: context,
                          formattedLabel: tickLabel.label,
                          x: tickLabel.point.x,
                          y: tickLabel.point.y,
                          attributes: tickLabel.attributes,
                          constrainedToSize: tickLabel.constrainedSize,
                          anchor: tickLabel.anchorPoint,
                          angleRadians: tickLabel.angleInRadians)
            }
            else {
                drawLabelHorizontal(context: context, formattedLabel: tickLabel.label, x: tickLabel.point.x, y: tickLabel.point.y, attributes: tickLabel.attributes, constrainedToSize: tickLabel.constrainedSize, anchor: tickLabel.anchorPoint, angleRadians: tickLabel.angleInRadians,options: tickLabel.stringDrawingOption)
            }
        }

    }
    
    func drawAxisTitle(context: CGContext,fixedPosition:CGFloat)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPort = viewPortHandler
            else { return }
        
        if !yAxis.axisTitleEnabled {
            return
        }
        
        let paraStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        
        let yLabelAttrs = [NSAttributedString.Key.font: yAxis.axisTitleFont,
                           NSAttributedString.Key.foregroundColor: yAxis.axisTitleColor,
                           NSAttributedString.Key.paragraphStyle: paraStyle]
        
        
        var labelMaxSize = CGSize()
        
        labelMaxSize.height = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).height
        labelMaxSize.width = (viewPort.contentRect.height)*(3/4)
        
        let textWidth = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).width
        let textHeight = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).height
        
        var point = CGPoint()
        point.y = (viewPort.contentRect.midY) - (min(labelMaxSize.width,textWidth)/2)
        
        if yAxis.axisDependency == .left && yAxis.enabled
        {
            point.x = fixedPosition - yAxis.requiredSize().width + yAxis.axisTitleOffsets.marginLeft
        }
        else if yAxis.axisDependency == .right && yAxis.enabled
        {
            point.x = fixedPosition + yAxis.requiredSize().width - yAxis.axisTitleOffsets.marginRight - textHeight
            
        }
        
        drawLabelTruncated(context: context, formattedLabel: yAxis.axisTitle, x: point.x, y: point.y, attributes: yLabelAttrs, constrainedToSize: labelMaxSize, anchor: CGPoint(x:0,y:0.5), angleRadians: (270 * ChartUtils.Math.FDEG2RAD))
    }
    
    open override func renderGridLines(context: CGContext)
    {
        guard let
            yAxis = self.axis as? YAxis
            else { return }
        
        super.renderGridLines(context: context)

        if yAxis.drawZeroLineEnabled
        {
            // draw zero line
            drawZeroLine(context: context)
        }
    }
    
    open override var gridClippingRect: CGRect
    {
        var contentRect = viewPortHandler?.contentRect ?? CGRect.zero
        let dy = self.axis?.gridLineWidth ?? 0.0
        contentRect.origin.y -= dy / 2.0
        contentRect.size.height += dy
        return contentRect
    }
    
    open override func drawGridLine(
        context: CGContext,
        position: CGPoint)
    {
        guard
            let viewPortHandler = self.viewPortHandler,
            let chart = chartViewBase
            else { return }
        
        let contentLeft = CommonHelperFunctions.contentLeft(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        let contentRight = CommonHelperFunctions.contentRight(interactionAnimationInProgress: chart.interactionAnimationInProgress, viewPortHandler: viewPortHandler)
        
        context.beginPath()
        context.move(to: CGPoint(x: contentLeft, y: position.y))
        context.addLine(to: CGPoint(x: contentRight, y: position.y))
        context.strokePath()
    }

    /// Draws the zero line at the specified position.
    open func drawZeroLine(context: CGContext)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let zeroLineColor = yAxis.zeroLineColor
            else { return }
        
        context.saveGState()
        defer { context.restoreGState() }
        
        var clippingRect = viewPortHandler.contentRect
        clippingRect.origin.y -= yAxis.zeroLineWidth / 2.0
        clippingRect.size.height += yAxis.zeroLineWidth
        context.clip(to: clippingRect)

        context.setStrokeColor(zeroLineColor.cgColor)
        context.setLineWidth(yAxis.zeroLineWidth)
        
        let pos = transformer.pixelForValues(x: 0.0, y: 0.0)
    
        if yAxis.zeroLineDashLengths != nil
        {
            context.setLineDash(phase: yAxis.zeroLineDashPhase, lengths: yAxis.zeroLineDashLengths!)
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        context.move(to: CGPoint(x: viewPortHandler.contentLeft, y: pos.y))
        context.addLine(to: CGPoint(x: viewPortHandler.contentRight, y: pos.y))
        context.drawPath(using: CGPathDrawingMode.stroke)
    }
    
   
 
    open override func renderLimitLines(context: CGContext)
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = chartViewBase
            else { return }
        
        var limitLines = yAxis.limitLines
        
        if limitLines.count == 0
        {
            return
        }
        
        if !(chart.includeLayer)
        {
            return
        }
        
        context.saveGState()
        
        let trans = transformer.valueToPixelMatrix
        
        var position = CGPoint(x: 0.0, y: 0.0)
        
        for i in 0 ..< limitLines.count
        {
            let l = limitLines[i]
            
            if !l.isEnabled
            {
                continue
            }
            
//            context.saveGState()
//            defer { context.restoreGState() }
//
//            var clippingRect = viewPortHandler.contentRect
//            clippingRect.origin.y -= l.lineWidth / 2.0
//            clippingRect.size.height += l.lineWidth
//            context.clip(to: clippingRect)
            
            position.x = 0.0
            position.y = CGFloat(l.limit)
            position = chart.pixelForValues(point: position, axisIndex: yAxis.axisIndex)
            
            if !(viewPortHandler.isInBoundsY(position.y))
            {
                continue
            }
            
            
           /* context.beginPath()
            context.move(to: CGPoint(x: viewPortHandler.contentLeft, y: position.y))
            context.addLine(to: CGPoint(x: viewPortHandler.contentRight, y: position.y))
            
            context.setStrokeColor(l.lineColor.cgColor)
            context.setLineWidth(l.lineWidth)
            
            if l.lineDashLengths != nil
            {
                context.setLineDash(phase: l.lineDashPhase, lengths: l.lineDashLengths!)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
            
            context.strokePath() */
            
            let limitValueSize = l.getLimitValueSize(formattedString: l.getLimitValue(axis: yAxis))
            
            var limitTextSizeMax = max(yAxis.longestLabel.size(withAttributes: [NSAttributedString.Key.font: l.limitValueFont]).width,limitValueSize.width)
            
            if limitTextSizeMax > yAxis.maxLabelWidth
            {
                limitTextSizeMax = yAxis.maxLabelWidth
            }
            
            limitTextSizeMax = max(limitTextSizeMax,currentMaxLabelWidth)

            var frame:CGRect
            
            var endPoint:CGPoint
            
            if yAxis.axisDependency == .left
            {
                let x = viewPortHandler.contentLeft - limitTextSizeMax - (yAxis.axisLabelOffsets.marginLeft + yAxis.axisLabelOffsets.marginRight) + yAxis.offsetCalculated
                
                let width = abs(viewPortHandler.contentLeft - x) + yAxis.offsetCalculated
                
                frame = CGRect(x: x, y: position.y - width/2, width: width, height: width)
                
                endPoint = CGPoint(x: viewPortHandler.contentRight, y: frame.midY)
            }
            else{
                let x = viewPortHandler.contentRight + limitTextSizeMax + (yAxis.axisLabelOffsets.marginLeft + yAxis.axisLabelOffsets.marginRight) + yAxis.offsetCalculated
                
                let width = abs(x - viewPortHandler.contentRight) - yAxis.offsetCalculated

                frame = CGRect(x: viewPortHandler.contentRight + yAxis.offsetCalculated , y: position.y - width/2, width: width, height: width)
                
                endPoint = CGPoint(x: viewPortHandler.contentLeft, y: frame.midY)
            }
            
            let layer = LimitLineLayer(chartViewBase: chart, axisRendererBase: self, charLimitLine: l, position: frame, endPoint:endPoint)
            self.chartViewBase?.nsuiLayer?.addSublayer(layer)
            
            if l.drawLabelEnabled && !l.label.isEmpty
            {
                renderLimitLineLabel(limitLine: l, limitLineLayer: layer, position: position, limitLineType: .horizontal)
            }
        }
        
        context.restoreGState()
    }
    
    open override func renderBaseLine()
    {
        guard
            let yAxis = self.axis as? YAxis,
            let viewPortHandler = self.viewPortHandler,
            let transformer = self.transformer,
            let chart = chartViewBase
            else { return }
        
        guard let baseLine = yAxis.baseLine
            else { return }

        if !yAxis.isEnabled || !yAxis.isVisible
        {
            return
        }
        
        let trans = transformer.valueToPixelMatrix
        
        var position = CGPoint(x: 0.0, y: 0.0)
    
        position.x = 0.0
        position.y = CGFloat(baseLine.baseValue)
        position = transformer.pixelForValues(x: position.x, y: position.y)
        
        let startPoint = CGPoint(x: viewPortHandler.contentLeft, y: position.y)
        
        let endPoint = CGPoint(x: viewPortHandler.contentRight, y: position.y)
        
        let layer = BaseLineLayer(chartViewBase: chart, axisRendererBase: self, chartBaseLine: baseLine, startPoint: startPoint, endPoint:endPoint)
        self.chartViewBase?.nsuiLayer?.addSublayer(layer)

        
    }
}

open class YAxisPolarRenderer:YAxisRenderer
{
    internal func getRequiredSize() -> CGSize
    {
         var radiusXOffset:CGFloat = 0
         var radiusYOffset:CGFloat = 0
        var offset = 0.0
         if let yAxis = self.axis as? YAxis
         {
           if yAxis.drawAxisLineEnabled && yAxis.visible
            {
                offset += yAxis.axisLineWidth
            }
            
            if yAxis.drawTickMarksEnabled && yAxis.visible
            {
                offset += yAxis.axisTickMarkSize
            }
            
            if yAxis.drawLabelsEnabled && yAxis.visible //|| yAxis.isDrawTopYLabelEntryEnabled || yAxis.isDrawBottomYLabelEntryEnabled
            {
                let text = self.getLongestLabelfromEntries(axis:yAxis)
                let textSize = text.size(withAttributes: [NSAttributedString.Key.font: yAxis.labelFont])
                radiusXOffset = min(yAxis.maxLabelWidth,textSize.width) + offset + yAxis.yOffset
                radiusYOffset = min(yAxis.maxLabelWidth,textSize.height) + offset + yAxis.yOffset
            }
         }
         return CGSize(width: radiusXOffset, height: radiusYOffset)
    }
    
    open override func renderAxisLine(context: CGContext) {
        guard
            let yAxis = self.axis as? YAxis,
            let polarTransformer = transformer as? PolarTransformer
            else { return }
       
            if !yAxis.isEnabled || !yAxis.isVisible || !yAxis.drawAxisLineEnabled
            {
                return
            }
        
            let startAngle = polarTransformer.startAngle
            let maxAngle =  polarTransformer.direction == .clockwise ? polarTransformer.yScaleRange : -(polarTransformer.yScaleRange)
            let lineWidth = yAxis.axisLineWidth
            let axisRadius = yAxis.axisDependency == .left ? polarTransformer.radius + (lineWidth/2) + yAxis.yOffset : getInnerRadius() - (lineWidth/2) - yAxis.yOffset
            let axisCenter = polarTransformer.centerPoint
        
            let arcPath = CGMutablePath()
        
            arcPath.addRelativeArc(center: axisCenter, radius: axisRadius , startAngle: startAngle * CGFloat(ChartUtils.Math.DEG2RAD), delta: maxAngle * CGFloat(ChartUtils.Math.DEG2RAD))
           
          
            context.saveGState()
           
            context.setStrokeColor(yAxis.axisLineColor.cgColor)
            context.setLineWidth(yAxis.axisLineWidth)
             
            if yAxis.axisLineDashLengths != nil
            {
                context.setLineDash(phase: yAxis.axisLineDashPhase, lengths: yAxis.axisLineDashLengths)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
    
            context.beginPath()
            context.addPath(arcPath)
            context.strokePath()
       
            context.restoreGState()
          
    }
    
    /// draws the y-axis labels to the screen
    open override func renderAxisLabels(context: CGContext)
    {
       guard
            let yAxis = self.axis as? YAxis,
            let polarTransformer = transformer as? PolarTransformer
            else { return }
        
        if !yAxis.isEnabled || !yAxis.drawLabelsEnabled || !yAxis.visible
        {
            return
        }
        
        var entries = [Int:Double]()
        
        for entryEnum in yAxis.entries.enumerated() {
            entries[entryEnum.offset] = entryEnum.element
        }

        let chartRadius = yAxis.axisDependency == .left ? polarTransformer.radius : getInnerRadius()
        let chartCenter = polarTransformer.centerPoint
        
        let labelFont = yAxis.labelFont
        let labelTextColor = yAxis.labelTextColor
        
        let from = yAxis.isDrawBottomYLabelEntryEnabled ? 0 : 1
        let to = yAxis.isDrawTopYLabelEntryEnabled ? entries.count : (entries.count - 1)
        
        let labelAttrs = [NSAttributedString.Key.font: labelFont, NSAttributedString.Key.foregroundColor: labelTextColor]
        
        
        var radiusOffset:CGFloat = 0
        var tickMarkRadiusStart = 0.0
        var labelRadius = 0.0
        
        if yAxis.axisDependency == .left {
            
            if yAxis.drawAxisLineEnabled
            {
                radiusOffset += yAxis.axisLineWidth
            }
            
            tickMarkRadiusStart = chartRadius + radiusOffset + yAxis.yOffset
            
            if yAxis.drawTickMarksEnabled
            {
                radiusOffset += yAxis.axisTickMarkSize
            }
            
            labelRadius = yAxis.visible ? (chartRadius + radiusOffset + yAxis.yOffset) : (chartRadius + yAxis.yOffset) //+ (textSize.height)/2
        }
        else {
            
            if yAxis.drawAxisLineEnabled
            {
                radiusOffset += yAxis.axisLineWidth
            }
            
            tickMarkRadiusStart = chartRadius - radiusOffset - yAxis.yOffset
            
            if yAxis.drawTickMarksEnabled
            {
                radiusOffset += yAxis.axisTickMarkSize
            }
            
            labelRadius = yAxis.visible ? (chartRadius - radiusOffset - yAxis.yOffset) : (chartRadius - yAxis.yOffset) //+ (textSize.height)/2
        }
        
        var tickMarkRadiusEnd = labelRadius
        
        let keys = entries.keys.sorted()
        
        for i in stride(from: from, to: to, by: 1)
        {
            let value = (i >= 0 && i < entries.count) ? entries[keys[i]] ?? 0 : 0
            
            let text = yAxis.getFormattedLabel(keys[i])
            
            let textSize = text.size(withAttributes: [NSAttributedString.Key.font: labelFont])
            
            let constrainedToSize = CGSize(width: yAxis.maxLabelWidth, height: textSize.height)
            
            let angle = polarTransformer.absoluteAngleForValue(value: value)
            
            let radius = yAxis.axisDependency == .left ? labelRadius + (textSize.width/2) : labelRadius - (textSize.width/2)
            
            let point = ChartUtils.getPosition(center: chartCenter, dist: radius, angle: angle)
            
            drawLabelTruncated(context: context, formattedLabel: text, x: point.x, y: point.y, attributes: labelAttrs, constrainedToSize: constrainedToSize, anchor: CGPoint(x: 0.5, y: 0.5), angleRadians: (0 * ChartUtils.Math.FDEG2RAD))
            
            if yAxis.drawTickMarksEnabled && yAxis.visible
            {
                context.saveGState()
                
                context.setStrokeColor(yAxis.axisTickMarkColor.cgColor)
                context.setLineWidth(yAxis.axisTickMarkLineWidth)
                context.beginPath()
                context.move(to: ChartUtils.getPosition(center: chartCenter, dist: tickMarkRadiusStart, angle: angle) )
                 context.addLine(to: ChartUtils.getPosition(center: chartCenter, dist: tickMarkRadiusEnd, angle: angle))
                context.strokePath()
                
                context.restoreGState()
            }

        }
        
        if yAxis.drawSubTickMarksEnabled && yAxis.visible && yAxis.axisSubTickCount > 0 {
            
            if yAxis.axisDependency == .left {
                tickMarkRadiusEnd = tickMarkRadiusStart + yAxis.axisSubTickMarkSize
            }
            else {
                tickMarkRadiusEnd = tickMarkRadiusStart - yAxis.axisSubTickMarkSize
            }
            
            for i in stride(from: from, to: to - 1, by: 1)
            {
                if let fromValue = entries[keys[i]], let toValue = entries[keys[i+1]] {
                    
                    let fromAngle = polarTransformer.absoluteAngleForValue(value: fromValue)
                    
                    let toAngle = polarTransformer.absoluteAngleForValue(value: toValue)
                    
                    let interval = (toAngle - fromAngle) / Double(yAxis.axisSubTickCount + 1)
                    
                    var angle = fromAngle
                    
                    angle += interval
                    
                    for _ in stride(from: 0, to: yAxis.axisSubTickCount, by: 1){
                        
                        context.saveGState()
                            
                        context.setStrokeColor(yAxis.axisSubTickMarkColor.cgColor)
                        context.setLineWidth(yAxis.axisSubTickMarkLineWidth)
                        context.beginPath()
                        context.move(to: ChartUtils.getPosition(center: chartCenter, dist: tickMarkRadiusStart, angle: angle) )
                        context.addLine(to: ChartUtils.getPosition(center: chartCenter, dist: tickMarkRadiusEnd, angle: angle))
                        context.strokePath()
                            
                        context.restoreGState()
                        
                        angle += interval
                    }
                }
            }
        }
        
    }
    
    internal func getInnerRadius() -> CGFloat {
        
        guard let yAxis = self.axis as? YAxis,
              let chart = chartViewBase else {
            return 0.0
        }
        
        if let plotOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions, chart.plotTypes.contains(.Dial) {
            if yAxis.axisDependency == .right {
                return (plotOption.radius * plotOption.innerRadiusPercent)
            }
        }
        
        return 0.0
    }
}
