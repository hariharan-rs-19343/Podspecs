//
//  PieChartRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif

open class PieGenerator: NSObject
{
    public static func generatePieLayers(_buffers:[[String:Any]], chart:ChartViewBase)
    {
        for dict in _buffers
        {
            guard let center = dict["center"] as? CGPoint,
                  let radius = dict["radius"] as? CGFloat,
                  let startAngOuter = dict["startAngleOuter"] as? CGFloat,
                  let sweepAngOuter = dict["sweepAngleOuter"] as? CGFloat,
                  let drawInnerArc = dict["drawInnerArc"] as? Bool,
                  let innerRadius = dict["innerRadius"] as? CGFloat
            else { continue }
            
            let path = getArcPath(center: center, radius: radius, startAngleOuter: startAngOuter, sweepAngleOuter: sweepAngOuter, drawInnerArc: drawInnerArc, innerRadius: innerRadius)
                
            guard let setIndex = dict["setIndex"] as? Int,
                  let set = chart.data?.dataSets[setIndex] as? ChartDataSet,
                  let entry = dict["entry"] as? ChartDataEntry
            else { continue }
            let _ = PieLayer(chart: chart, chartEntry: entry, chartDataSet: set, slicePath: path)
        }
    }
    
    /// Angles in Degree
    public static func getArcPath(center:CGPoint, radius:CGFloat, startAngleOuter:CGFloat, sweepAngleOuter:CGFloat, drawInnerArc:Bool, innerRadius:CGFloat) -> CGMutablePath
    {
        let arcStartPointX = center.x + radius * cos(startAngleOuter * ChartUtils.Math.FDEG2RAD)
        
        let arcStartPointY = center.y + radius * sin(startAngleOuter * ChartUtils.Math.FDEG2RAD)
        
        let path = CGMutablePath()
    
        path.move(to: CGPoint(x: arcStartPointX,
                              y: arcStartPointY))
        
        path.addRelativeArc(center: center, radius: radius, startAngle: startAngleOuter * ChartUtils.Math.FDEG2RAD, delta: sweepAngleOuter * ChartUtils.Math.FDEG2RAD)
        
       
        if drawInnerArc && (innerRadius > 0.0)
        {
            let endAngleInner = startAngleOuter + sweepAngleOuter

            path.addLine(
                to: CGPoint(
                    x: center.x + innerRadius * cos(endAngleInner * ChartUtils.Math.FDEG2RAD),
                    y: center.y + innerRadius * sin(endAngleInner * ChartUtils.Math.FDEG2RAD)))

            path.addRelativeArc(center: center, radius: innerRadius, startAngle: endAngleInner * ChartUtils.Math.FDEG2RAD, delta: -sweepAngleOuter * ChartUtils.Math.FDEG2RAD)
        }
        else
        {
            path.addLine(to: center)
        }
        
        path.closeSubpath()
        
        
        return path
    }
}


open class PieChartRenderer: DataRenderer
{
    // [CGRect] per dataset
    internal var _buffers:[[String:Any]] = []
    
    // Pattern instance
    var dashPattern:SeriesPattern = SeriesPattern()
    
    open override func drawData(context: CGContext)
    {
        guard let chart = chart else { return }
        
        let pieData = chart.data
        
        if pieData != nil
        {
            for set in pieData!.dataSets
            {
                if set.isVisible && set.entryCount > 0
                {
                    drawDataSet(context: context, dataSet: set)
                }
            }
        }
    }
    
    open func calculateMinimumRadiusForSpacedSlice(
        center: CGPoint,
        radius: CGFloat,
        angle: CGFloat,
        arcStartPointX: CGFloat,
        arcStartPointY: CGFloat,
        startAngle: CGFloat,
        sweepAngle: CGFloat) -> CGFloat
    {
        let angleMiddle = startAngle + sweepAngle / 2.0
        
        // Other point of the arc
        let arcEndPointX = center.x + radius * cos((startAngle + sweepAngle) * ChartUtils.Math.FDEG2RAD)
        let arcEndPointY = center.y + radius * sin((startAngle + sweepAngle) * ChartUtils.Math.FDEG2RAD)
        
        // Middle point on the arc
        let arcMidPointX = center.x + radius * cos(angleMiddle * ChartUtils.Math.FDEG2RAD)
        let arcMidPointY = center.y + radius * sin(angleMiddle * ChartUtils.Math.FDEG2RAD)
        
        // This is the base of the contained triangle
        let basePointsDistance = sqrt(
            pow(arcEndPointX - arcStartPointX, 2) +
                pow(arcEndPointY - arcStartPointY, 2))
        
        // After reducing space from both sides of the "slice",
        //   the angle of the contained triangle should stay the same.
        // So let's find out the height of that triangle.
        let containedTriangleHeight = (basePointsDistance / 2.0 *
            tan((180.0 - angle) / 2.0 * ChartUtils.Math.FDEG2RAD))
        
        // Now we subtract that from the radius
        var spacedRadius = radius - containedTriangleHeight
        
        // And now subtract the height of the arc that's between the triangle and the outer circle
        spacedRadius -= sqrt(
            pow(arcMidPointX - (arcEndPointX + arcStartPointX) / 2.0, 2) +
                pow(arcMidPointY - (arcEndPointY + arcStartPointY) / 2.0, 2))
        
        return spacedRadius
    }
    
    /// Calculates the sliceSpace to use based on visible values and their size compared to the set sliceSpace.
    open func getSliceSpace(dataSet: IChartDataSet) -> CGFloat
    {
        guard let piePlotOption = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions,
            piePlotOption.automaticallyDisableSliceSpacing,
            let viewPortHandler = self.viewPortHandler,
              let chart = chart
            else { return (chart?.getPlotOptions(type: .Pie) as? PiePlotOptions)?.sliceSpace ?? 0}
        
        let spaceSizeRatio = piePlotOption.sliceSpace / min(viewPortHandler.contentWidth, viewPortHandler.contentHeight)
        let minValueRatio = dataSet.yMin / PieHelperFunctions.getYValueSum(chart: chart) * 2.0
        
        let sliceSpace = spaceSizeRatio > CGFloat(minValueRatio)
            ? 0.0
            : piePlotOption.sliceSpace
        
        return sliceSpace
    }

    open func drawDataSet(context: CGContext, dataSet: IChartDataSet)
    {
        guard
            let chart = chart,
            let animator = animator,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        let entryCount = dataSet.entryCount
        
        var entries:[(ChartDataEntry,Int)] = []
        var visibleAngleCount = 0
        for j in 0 ..< entryCount
        {
            guard let e = dataSet.entryForIndex(j) else { continue }
            entries.append((e,0))
            if ((abs(e.y) > Double.ulpOfOne))
            {
                visibleAngleCount += 1
            }
        }
        
        let sliceSpace = visibleAngleCount <= 1 ? 0.0 : getSliceSpace(dataSet: dataSet)

        context.saveGState()
        
        _buffers = []
        
        for j in 0 ..< entryCount
        {
            guard let e = dataSet.entryForIndex(j) else { continue }
            
            var finalFillColor:CGColor = NSUIColor.clear.cgColor
            if (e.filterEnabled) && piePlot.filterProgress
            {
                if piePlot.fadeSlice
                {
                finalFillColor = dataSet.color(atIndex: j).withAlphaComponent(piePlot.fadeFactor).cgColor         // To fade filtering or drilling slice
                }
                else
                {
                   finalFillColor = dataSet.color(atIndex: j).cgColor
                }
            }
            else
            {
                finalFillColor = dataSet.color(atIndex: j).cgColor
            }
            
            if chart.colorAxis.isEnabled {
                finalFillColor = (chart.colorAxis.getColor(entry: e)?.cgColor) ?? NSUIColor.gray.cgColor
            }
            
            if e.layerEnabled == true
            {
                finalFillColor = NSUIColor.clear.cgColor
            }
            
            // draw only if the value is greater than zero
            if (!e.y.isNaN && abs(e.y) > Double.ulpOfOne)
            {
                    if  chart.needsHighlight(index: j)
                    {
                        if piePlot.patternEnabled && !(e.layerEnabled)
                        {
                            dashPattern.getLinePattern(context:context,color: dataSet.color(atIndex: j).cgColor)
                        }
                        else{
                            if (e.enabled)
                            {
                                context.setFillColor(finalFillColor)
                            }
                            else{
                                context.setFillColor(NSUIColor.gray.withAlphaComponent(0.2).cgColor)
                            }
                        }
                    
                    }
                    else {
                        if (e.enabled)
                        {
                            context.setFillColor(finalFillColor)
                        }
                        else{
                            context.setFillColor(NSUIColor.gray.withAlphaComponent(0.2).cgColor)
                        }
                    }
            }
        }
        
        _buffers = PieChartRenderer.prepareBuffer(entries: entries, piePlot: piePlot, sliceCenter: piePlot.centerCircleBox, sliceSpace: sliceSpace, animator: animator)
        
        PieGenerator.generatePieLayers(_buffers: _buffers, chart: chart)

        context.restoreGState()
    }
    
    /// Calculates the sliceSpace to use based on visible values and their size compared to the set sliceSpace.
    public static func getSliceSpace(minValue: Double, minViewWidth:CGFloat, valueSum:Double, piePlotOption:PiePlotOptions) -> CGFloat
    {
        guard piePlotOption.automaticallyDisableSliceSpacing
            else { return piePlotOption.sliceSpace }
        
        let spaceSizeRatio = piePlotOption.sliceSpace / minViewWidth
        let minValueRatio = minValue / valueSum * 2.0
        
        let sliceSpace = spaceSizeRatio > CGFloat(minValueRatio)
            ? 0.0
            : piePlotOption.sliceSpace
        
        return sliceSpace
    }
    
    public static func prepareBuffer(entries:[(ChartDataEntry,Int)],piePlot:PiePlotOptions, sliceCenter:CGPoint, sliceSpace:CGFloat, animator:Animator?, isPiePlot: Bool = true) -> [[String:Any]]
    {
        var angle: CGFloat = 0.0
        
        let phaseX = animator != nil ? animator!.phaseX : 1
        let phaseY = animator != nil ? animator!.phaseY : 1
        
        let entryCount = entries.count
        
        var radius = piePlot.radius
        let rotationAngle = piePlot.rotationAngle
        let drawAngles = piePlot.drawAngles
        var drawInnerArc = piePlot.drawHoleEnabled && !piePlot.drawSlicesUnderHoleEnabled
        let userInnerRadius = drawInnerArc ? radius * piePlot.holeRadiusPercent : 0.0
        let clockwiseDirection = piePlot.sliceDirection == .clockwise
        
        var visibleAngleCount = 0
        for j in 0 ..< entryCount
        {
            let e = entries[j]
            if ((abs(e.0.y) > Double.ulpOfOne))
            {
                visibleAngleCount += 1
            }
        }
        
        var _tempBuffers:[[String:Any]] = []
        
        for j in 0 ..< entryCount
        {
            let chartEntry = entries[j].0
            
            let sliceAngle = drawAngles[j]
            let innerRadius = userInnerRadius
            
            if (chartEntry.filterEnabled) && piePlot.filterProgress
            {
                radius = piePlot.changedRadius
            }
            else
            {
                radius = piePlot.radius
            }
            
            // draw only if the value is greater than zero
            if (!chartEntry.y.isNaN && abs(chartEntry.y) > Double.ulpOfOne) || !isPiePlot
            {
                    let accountForSliceSpacing = sliceSpace > 0.0 && sliceAngle <= 180.0
                
                    var center:CGPoint = CGPoint(x: 0, y: 0)
                    if (chartEntry.filterEnabled)
                    {
                        if chartEntry.centerChanged != nil{
                            center = (chartEntry.centerChanged)!
                        }
                    }
                    else{
                        center = sliceCenter
                    }
                    
                    let sliceSpaceAngleOuter = visibleAngleCount == 1 ?
                        0.0 :
                        sliceSpace / (ChartUtils.Math.FDEG2RAD * radius)
                    var startAngleOuter = rotationAngle + (angle + sliceSpaceAngleOuter / 2.0) * CGFloat(phaseY)
                    if (!clockwiseDirection) {
                        startAngleOuter = rotationAngle + (angle - sliceSpaceAngleOuter / 2.0) * CGFloat(phaseY)
                    }
                    var sweepAngleOuter = (sliceAngle - sliceSpaceAngleOuter) * CGFloat(phaseY)
                    if sweepAngleOuter < 0.0
                    {
                        sweepAngleOuter = 0.0
                    }
                    if (!clockwiseDirection) {
                        sweepAngleOuter = -sweepAngleOuter
                    }
                        
                    if drawInnerArc
                    {
                        if  !((innerRadius > 0.0 || accountForSliceSpacing))
                        {
                            drawInnerArc = false
                        }
                    }
                    
                    var buffer:[String:Any] = [:]
                    
                    buffer["center"] = center
                    buffer["radius"] = radius
                    buffer["startAngleOuter"] = startAngleOuter
                    buffer["sweepAngleOuter"] = sweepAngleOuter
                    buffer["drawInnerArc"] = drawInnerArc
                    buffer["innerRadius"] = innerRadius
                    buffer["entry"] = chartEntry
                    buffer["setIndex"] = entries[j].1
                    
                    _tempBuffers.append(buffer)
                    
                    
                    if (!clockwiseDirection) {
                        angle -= sliceAngle * CGFloat(phaseX)
                    } else {
                        angle += sliceAngle * CGFloat(phaseX)
                    }
            }
        }
        
        return _tempBuffers
    }
    
    func drawGradients(context: CGContext, path: CGMutablePath, entry:ChartDataEntry,  dataSet: IChartDataSet) {
        
        guard let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        let gradients = dataSet.gradients
        
        if gradients.count == 0 {
            return
        }
        let entryIndex = dataSet.entryIndex(entry: entry)
        let baseGradient = dataSet.gradient(atIndex: entryIndex)
        context.saveGState()
        
        let cgGradient = baseGradient.getCGGradient()
        
        if cgGradient == nil {
            context.restoreGState()
            return
        }
        
        context.beginPath()
        context.addPath(path)
        context.clip()
        
        if baseGradient.isKind(of: LinearGradient.self) {
            /*
            let start = CGPoint(x: pathBounds.origin.x + pathBounds.width/2, y: pathBounds.origin.y)
            let end = CGPoint(x: pathBounds.origin.x + pathBounds.width/2, y: pathBounds.origin.y + pathBounds.height)
            
            context.drawLinearGradient(cgGradient!, start: start, end: end, options: baseGradient.options)
            */
            baseGradient.frame = path.boundingBox
            (baseGradient as? DrawableGradient)?.draw(cgGradient!, in: context)
            
        }
        else if baseGradient.isKind(of: RadialGradient.self) {

            let startCenter =  ((entry.filterEnabled) && entry.centerChanged != nil) ? (entry.centerChanged)! : piePlot.centerCircleBox
            let endCenter = startCenter
            let endRadius = piePlot.radius
            let startRadius = (piePlot.isDrawHoleEnabled) ? (piePlot.holeRadiusPercent * piePlot.radius) : 0

            
            context.drawRadialGradient(cgGradient!, startCenter: startCenter, startRadius: startRadius, endCenter: endCenter, endRadius: endRadius, options: baseGradient.options)
        }
        
        context.restoreGState()
        
    }
    
    open override func drawValues(context: CGContext)
    {
        guard let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        guard
            let chart = chart,
            let data = chart.data,
            let animator = animator
            else { return }
        
        let center = piePlot.centerCircleBox
        
        // get whole the radius
        let radius = piePlot.radius
        let rotationAngle = piePlot.rotationAngle
        var drawAngles = piePlot.drawAngles
        var absoluteAngles = piePlot.absoluteAngles
        
        let phaseX = animator.phaseX
        let phaseY = animator.phaseY
        
        var labelRadiusOffset = radius / 10.0 * 3.0
        
        if piePlot.drawHoleEnabled
        {
            labelRadiusOffset = (radius - (radius * piePlot.holeRadiusPercent)) / 2.0
        }
        
        let labelRadius = radius - labelRadiusOffset
        
        var dataSets = data.dataSets
        
        let yValueSum = PieHelperFunctions.getYValueSum(chart: chart)
        
        let drawEntryLabels = piePlot.isDrawEntryLabelsEnabled
        let usePercentValuesEnabled = piePlot.usePercentValuesEnabled
        let entryLabelColor = piePlot.entryLabelColor
        let entryLabelFont = piePlot.entryLabelFont
        let clockwiseDirection = piePlot.sliceDirection == .clockwise
        
        var angle: CGFloat = 0.0
        var xIndex = 0
        
        context.saveGState()
        defer { context.restoreGState() }
        
        for i in 0 ..< dataSets.count
        {
            let dataSet = dataSets[i]
            
            let drawValues = dataSet.isDrawValuesEnabled
            
            if !drawValues && !drawEntryLabels && !dataSet.isDrawIconsEnabled
            {
                continue
            }
            
            let iconsOffset = dataSet.iconsOffset
            
            let xValuePosition = piePlot.xValuePosition
            let yValuePosition = piePlot.yValuePosition
            
            let valueFont = dataSet.valueFont
            let entryLabelFont = piePlot.entryLabelFont
            
            var lineHeight = valueFont.lineHeight
            if (drawEntryLabels && xValuePosition == .outsideSlice) && !(drawValues && yValuePosition == .outsideSlice)
            {
                lineHeight = entryLabelFont != nil ? entryLabelFont!.lineHeight : valueFont.lineHeight
            }
            
            guard let formatter = dataSet.valueFormatter,
                  let viewPort = viewPortHandler
            else { continue }
            
            var lastYpointLeft = viewPort.contentRect.maxY
            var lastYpointRight = viewPort.contentRect.minY
            
            var OverlappedLeft = false
            var OverlappedRight = false
            
            var leftLabelTopCount = 0
            var leftLabelBottomCount = 0
            
            var rightLabelTopCount = 0
            var rightLabelBottomCount = 0
            
            var valueTextLayerLeft:[ValueTextLayer] = []
            var valueTextLayerRight:[ValueTextLayer] = []
            
            var labelIndexLeft:[(Int,CGPoint)] = []
            var labelIndexRight:[(Int,CGPoint)] = []
            
            var labelIndexLeftTop:[(Int,CGPoint)] = []
            var labelIndexLeftBottom:[(Int,CGPoint)] = []
            var labelIndexRightTop:[(Int,CGPoint)] = []
            var labelIndexRightBottom:[(Int,CGPoint)] = []
            
            for j in 0 ..< dataSet.entryCount
            {
                guard let e = dataSet.entryForIndex(j) else { continue }
                
                if xIndex == 0
                {
                    angle = 0.0
                }
                else
                {
                    angle = absoluteAngles[xIndex - 1] * CGFloat(phaseX)
                }
                
//                if (abs(e.y) <= Double.ulpOfOne)//DRAW VALUES ONLY IF GREATER THAN ZERO
                if (abs(e.y) <= Double.ulpOfOne || (!e.enabled && e.y.isNaN))//DRAW VALUES ONLY IF GREATER THAN ZERO
                {
                    xIndex += 1
                    continue
                }
                
                let sliceAngle = drawAngles[xIndex]
                let sliceSpace = getSliceSpace(dataSet: dataSet)
                let sliceSpaceMiddleAngle = sliceSpace / (ChartUtils.Math.FDEG2RAD * labelRadius)
                
                // offset needed to center the drawn text in the slice
                let angleOffset = (sliceAngle - sliceSpaceMiddleAngle / 2.0) / 2.0
               
                angle = angle + angleOffset
                
                if (!clockwiseDirection){
                    angle = -angle
                }
                let transformedAngle = rotationAngle + angle * CGFloat(phaseY)
                
                let value = usePercentValuesEnabled ? e.y / yValueSum * 100.0 : e.y
                let valueText = formatter.getFormattedTextforValue?(value: value, type: .y, data: e) ?? ""
                /*stringForValue(
                    value,
                    entry: e,
                    dataSetIndex: i,
                    viewPortHandler: viewPortHandler)*/
                
                var eXString = e.xString != nil ? formatter.getFormattedTextforLabel?(label: e.xString!, type: .x, data: e) : nil
                
                
                let sliceXBase = cos(transformedAngle * ChartUtils.Math.FDEG2RAD)
                let sliceYBase = sin(transformedAngle * ChartUtils.Math.FDEG2RAD)
                
                var drawXOutside = drawEntryLabels && xValuePosition == .outsideSlice
                var drawYOutside = drawValues && yValuePosition == .outsideSlice
                var drawXInside = drawEntryLabels && xValuePosition == .insideSlice
                var drawYInside = drawValues && yValuePosition == .insideSlice
                
                let valueTextColor = dataSet.valueTextColorAt(j)
                let entryLabelColor = piePlot.entryLabelColor
                
                
                if drawXInside || drawYInside
                {
                    // calculate the text position
                    let x = labelRadius * sliceXBase + center.x
                    let y = labelRadius * sliceYBase + center.y - lineHeight
                    
                    
                    if drawXInside && drawYInside
                    {
                        guard var eString = eXString
                        else { continue }
                        
                        let xWidth = (eString).size(withAttributes: [ NSAttributedString.Key.font: entryLabelFont ?? valueFont,
                                                                     NSAttributedString.Key.foregroundColor: entryLabelColor ?? valueTextColor]).width
                        
                        let yWidth = valueText.size(withAttributes: [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]).width
                        
                        let maxWidth = max(xWidth,yWidth)
                        
                        if !isFitInsideSlice(x: x, y: y, textWidth: maxWidth, curEntry: e)
                        {
                            if piePlot.drawLargeValue
                            {
                                drawXOutside = drawEntryLabels
                                drawYOutside = drawValues
                                drawXInside = false
                                drawYInside = false
                            }
                            else{
                                drawXOutside = false
                                drawXInside = false
                                drawYOutside = false
                                drawYInside = false
                            }
                        }
   
                    }
                    else if drawXInside
                    {
                        guard var eString = eXString
                        else { continue }
                        
                        let xWidth = (eString).size(withAttributes: [ NSAttributedString.Key.font: entryLabelFont ?? valueFont,
                                                                     NSAttributedString.Key.foregroundColor: entryLabelColor ?? valueTextColor]).width
                        
                        if !isFitInsideSlice(x: x, y: y, textWidth: xWidth, curEntry: e)
                        {
                            if piePlot.drawLargeValue
                            {
                                drawXOutside = drawEntryLabels
                                drawXInside = false
                            }
                            else{
                                drawXOutside = false
                                drawXInside = false
                            }
                        }
                    }
                    else if drawYInside
                    {
                        let yWidth = valueText.size(withAttributes: [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]).width
                        
                        if !isFitInsideSlice(x: x, y: y, textWidth: yWidth, curEntry: e)
                        {
                            if piePlot.drawLargeValue
                            {
                                drawYOutside = drawValues
                                drawYInside = false
                            }
                            else{
                                drawYOutside = false
                                drawYInside = false
                            }
                        }
                    }

                    
                    
                    if drawXInside && drawYInside
                    {
                        // To hold label and value
                        let valueTextLayer = ValueTextLayer()
                        
                        let layer = ChartUtils.drawTextLayer(
                            text: valueText,
                            point: CGPoint(x: x, y: y),
                            align: .center,
                            attributes: [NSAttributedString.Key.font : valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
                        )
                        
                        valueTextLayer.addSublayer(layer)
                        
                        if j < data.entryCount && eXString != nil
                        {
                            let labelLayer = ChartUtils.drawTextLayer(
                                text: eXString!,
                                point: CGPoint(x: x, y: y + lineHeight),
                                align: .center,
                                attributes: [
                                    NSAttributedString.Key.font : entryLabelFont ?? valueFont,
                                    NSAttributedString.Key.foregroundColor : entryLabelColor ?? valueTextColor]
                            )
                            
                            valueTextLayer.addSublayer(labelLayer)
                        }
                        
                        self.chart?.plotView?.nsuiLayer?.addSublayer(valueTextLayer)
                        
                    }
                    else if drawXInside
                    {
                        let valueTextLayer = ValueTextLayer()
                        if j < data.entryCount && eXString != nil
                        {
                            let layer = ChartUtils.drawTextLayer(
                                text: eXString!,
                                point: CGPoint(x: x, y: y + lineHeight / 2.0),
                                align: .center,
                                attributes: [
                                    NSAttributedString.Key.font: entryLabelFont ?? valueFont,
                                    NSAttributedString.Key.foregroundColor: entryLabelColor ?? valueTextColor]
                            )
                            
                            valueTextLayer.addSublayer(layer)
                        }
                        self.chart?.plotView?.nsuiLayer?.addSublayer(valueTextLayer)
                    }
                    else if drawYInside
                    {
                        let valueTextLayer = ValueTextLayer()
                        
                        let layer = ChartUtils.drawTextLayer(
                            text: valueText,
                            point: CGPoint(x: x, y: y + lineHeight / 2.0),
                            align: .center,
                            attributes: [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
                        )
                        
                        valueTextLayer.addSublayer(layer)
                        self.chart?.plotView?.nsuiLayer?.addSublayer(valueTextLayer)
                    }
                }
                
                if drawXOutside || drawYOutside
                {
                    
                    let valueTextLayer = ValueTextLayer()

//                    self.chart?.plotView?.layer.addSublayer(valueTextLayer)
                    
                    let valueLineLength1 = piePlot.valueLinePart1Length
                    let valueLineLength2 = piePlot.valueLinePart2Length
                    let valueLinePart1OffsetPercentage = piePlot.valueLinePart1OffsetPercentage
                    
                    var pt2: CGPoint
                    var labelPoint: CGPoint
                    var align: NSTextAlignment
                    
                    var line1Radius: CGFloat
                    
                    if piePlot.drawHoleEnabled
                    {
                        line1Radius = (radius - (radius * piePlot.holeRadiusPercent)) * valueLinePart1OffsetPercentage + (radius * piePlot.holeRadiusPercent)
                    }
                    else
                    {
                        line1Radius = radius * valueLinePart1OffsetPercentage
                    }
                    
                    let polyline2Length = piePlot.valueLineVariableLength
                        ? labelRadius * valueLineLength2 * abs(sin(transformedAngle * ChartUtils.Math.FDEG2RAD))
                        : labelRadius * valueLineLength2
                    
                    let pt0 = CGPoint(
                        x: line1Radius * sliceXBase + center.x,
                        y: line1Radius * sliceYBase + center.y)
                    
                    let pt1 = CGPoint(
                        x: labelRadius * (1 + valueLineLength1) * sliceXBase + center.x,
                        y: (labelRadius * (1 + valueLineLength1 * ellipse(angle: transformedAngle) * 1.5) * sliceYBase + center.y ))// labelRadius * (1 + valueLineLength1) * sliceYBase + center.y)
                    
                    if abs(transformedAngle).truncatingRemainder(dividingBy: 360.0) >= 90.0 && abs(transformedAngle).truncatingRemainder(dividingBy: 360.0) <= 270.0
                    {
                        pt2 = CGPoint(x: pt1.x - polyline2Length, y: pt1.y)
                        align = .left
                        labelPoint = CGPoint(x: pt2.x - 5, y: pt2.y - lineHeight)
                    }
                    else
                    {
                        pt2 = CGPoint(x: pt1.x + polyline2Length, y: pt1.y)
                        align = .right
                        labelPoint = CGPoint(x: pt2.x + 5, y: pt2.y - lineHeight)
                    }
                    
                    let bothOutside = drawXOutside && drawYOutside
                    
                    var changedLineHeight = lineHeight

                    if bothOutside
                    {
                        changedLineHeight = valueFont.lineHeight + (entryLabelFont != nil ? entryLabelFont!.lineHeight : valueFont.lineHeight)
                    }
                    
                    //Overlapped
                    if align == .left && !(drawYOutside && (yValuePosition == .insideSlice)) && !(drawXOutside && (xValuePosition == .insideSlice))
                    {
                        
                        valueTextLayerLeft.append(valueTextLayer)
                        
                        let contentMid = viewPort.contentRect.midY
                        
                        let currentTopYPoint = bothOutside ? labelPoint.y : labelPoint.y+changedLineHeight/2
                        let currentBottomYPoint = currentTopYPoint + changedLineHeight
                        
                        if currentTopYPoint <= contentMid
                        {
                            leftLabelTopCount += 1
                            labelIndexLeftTop.append((j,pt0))
                        }
                        else{
                            leftLabelBottomCount += 1
                            labelIndexLeftBottom.append((j,pt0))
                        }
                           
                        if clockwiseDirection
                        {
                            if currentBottomYPoint > lastYpointLeft
                            {
                                OverlappedLeft = true
                            }
                            else{
                                lastYpointLeft = currentTopYPoint
                            }
                        }
                        else{
                            if currentTopYPoint < lastYpointLeft
                            {
                                OverlappedLeft = true
                            }
                            else{
                                lastYpointLeft = currentBottomYPoint
                            }
                        }
                    }
                    
                    if align == .right && !(drawYOutside && (yValuePosition == .insideSlice)) && !(drawXOutside && (xValuePosition == .insideSlice))
                    {
                        valueTextLayerRight.append(valueTextLayer)
                        
                        let contentMid = viewPort.contentRect.midY
                        
                        let currentTopYPoint = bothOutside ? labelPoint.y : labelPoint.y+changedLineHeight/2
                        let currentBottomYPoint = currentTopYPoint + changedLineHeight
                        
                        if currentTopYPoint <= contentMid
                        {
                            rightLabelTopCount += 1
                            labelIndexRightTop.append((j,pt0))
                        }
                        else{
                            rightLabelBottomCount += 1
                            labelIndexRightBottom.append((j,pt0))
                        }
                          
                        if clockwiseDirection
                        {
                            if currentTopYPoint < lastYpointRight
                            {
                                OverlappedRight = true
                            }
                            else{
                                lastYpointRight = currentBottomYPoint
                            }
                        }
                        else{
                            if currentBottomYPoint > lastYpointRight
                            {
                                OverlappedRight = true
                            }
                            else{
                                lastYpointRight = currentTopYPoint
                            }
                        }
                    }
                    
                    if piePlot.valueLineColor != nil
                    {
                        let linePath = CGMutablePath() // UIBezierPath()
                        linePath.move(to: CGPoint(x: pt0.x, y: pt0.y))
                        linePath.addLine(to: CGPoint(x: pt1.x, y: pt1.y))
                        linePath.addLine(to: CGPoint(x: pt2.x, y: pt2.y))

                        
                        let lineLayer = CAShapeLayer()
                        lineLayer.path = linePath//.cgPath
                        lineLayer.strokeColor = piePlot.valueLineColor!.cgColor
                        lineLayer.lineWidth = piePlot.valueLineWidth
                        lineLayer.lineCap = convertToCAShapeLayerLineCap("round")
                        lineLayer.fillColor = NSUIColor.clear.cgColor
                        
                        valueTextLayer.addSublayer(lineLayer)
                        
                        
                    }
                    
                    let xLabelAttribute = [
                        NSAttributedString.Key.font: entryLabelFont ?? valueFont,
                        NSAttributedString.Key.foregroundColor: entryLabelColor ?? valueTextColor]
                    
                    let yLabelAttributes = [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: valueTextColor]
                    
                    let labelOrigin =  CGPoint(x: labelPoint.x, y: labelPoint.y + lineHeight / 2.0)
                    
                    if drawXOutside && drawYOutside
                    {
                        let constrainedWidthForYLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: labelPoint, align: align, size: valueText.size(withAttributes: yLabelAttributes))
                        
                        let layer = ChartUtils.drawTextLayer(
                            text: valueText,
                            point: labelPoint,
                            align: align,
                            attributes: yLabelAttributes,
                            constrainedToWidth: constrainedWidthForYLabel,
                            truncationMode: piePlot.dataValuesTrancateMode
                        )
                        
                        valueTextLayer.addSublayer(layer)
                        
                        let xLabelOrigin = CGPoint(x: labelPoint.x, y: labelPoint.y + lineHeight)
                        
                        if j < data.entryCount && eXString != nil
                        {
                            
                            let constrainedWidthForXLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: xLabelOrigin, align: align, size: eXString!.size(withAttributes: xLabelAttribute))
                            
                             let labelLayer =  ChartUtils.drawTextLayer(
                                text: eXString!,
                                point: xLabelOrigin,
                                align: align,
                                attributes: xLabelAttribute,
                                constrainedToWidth: constrainedWidthForXLabel,
                                truncationMode: piePlot.dataValuesTrancateMode
                            )
                            
                            valueTextLayer.addSublayer(labelLayer)
                            
                        }
                        
                        
                        
                    }
                    else if drawXOutside
                    {
                        if j < data.entryCount && eXString != nil
                        {
                            let constrainedWidthForXLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: labelOrigin, align: align, size: eXString!.size(withAttributes: xLabelAttribute))
                            
                            let layer = ChartUtils.drawTextLayer(
                                text: eXString!,
                                point: labelOrigin,
                                align: align,
                                attributes: xLabelAttribute,
                                constrainedToWidth: constrainedWidthForXLabel,
                                truncationMode: piePlot.dataValuesTrancateMode
                            )
                            
                            valueTextLayer.addSublayer(layer)

                        }
                    }
                    else if drawYOutside
                    {
                        
                        let constrainedWidthForYLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: labelOrigin, align: align, size: valueText.size(withAttributes: yLabelAttributes))
                        
                        let layer = ChartUtils.drawTextLayer(
                            text: valueText,
                            point: labelOrigin,
                            align: align,
                            attributes: yLabelAttributes,
                            constrainedToWidth: constrainedWidthForYLabel,
                            truncationMode: piePlot.dataValuesTrancateMode
                        )
                        
                        valueTextLayer.addSublayer(layer)
                    }
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                        // calculate the icon's position
                        
                        let x = (labelRadius + iconsOffset.y) * sliceXBase + center.x
                        var y = (labelRadius + iconsOffset.y) * sliceYBase + center.y
                        y += iconsOffset.x
                        
                        ChartUtils.drawImage(context: context,
                                             image: icon,
                                             x: x,
                                             y: y,
                                             size: icon.size)
                    }
                }
                
                xIndex += 1
            }
            if OverlappedLeft || OverlappedRight
            {
                let drawXOutside = piePlot.isDrawEntryLabelsEnabled //&& piePlot.xValuePosition == .outsideSlice
                let drawYOutside = dataSet.isDrawValuesEnabled //&& piePlot.yValuePosition == .outsideSlice
                
                if drawXOutside && drawYOutside
                {
                    lineHeight = valueFont.lineHeight + (entryLabelFont != nil ? entryLabelFont!.lineHeight : valueFont.lineHeight)
                }
                else if drawXOutside
                {
                    lineHeight = entryLabelFont != nil ? entryLabelFont!.lineHeight : valueFont.lineHeight
                }
                
                if OverlappedLeft
                {
                    var tempxLabelIndex:[(Int,CGPoint)] = []
                    
                    if clockwiseDirection
                    {
                        for i in (0..<labelIndexLeftTop.count).reversed()
                        {
                            tempxLabelIndex.append(labelIndexLeftTop[i])
                        }
                        for i in (0..<labelIndexLeftBottom.count).reversed()
                        {
                            tempxLabelIndex.append(labelIndexLeftBottom[i])
                        }
                    }
                    else{
                        for i in (0..<labelIndexLeftTop.count)
                        {
                            tempxLabelIndex.append(labelIndexLeftTop[i])
                        }
                        for i in (0..<labelIndexLeftBottom.count)
                        {
                            tempxLabelIndex.append(labelIndexLeftBottom[i])
                        }
                    }
                    
                    labelIndexLeft = tempxLabelIndex
                    
                    renderNonOverlappedLabels(dataSet: dataSet, viewPortHandler: viewPort, lineHeight: lineHeight, labelTopCount: leftLabelTopCount, labelBottomCount: leftLabelBottomCount, labelIndex: labelIndexLeft, piePlot: piePlot, align: .left)
                }
                else{
                    for textLayer in valueTextLayerLeft
                    {
                        self.chart?.plotView?.nsuiLayer?.addSublayer(textLayer)
                    }
                }
                if OverlappedRight
                {
                    var tempxLabelIndex:[(Int,CGPoint)] = []
                    
                    if clockwiseDirection
                    {
                        for i in (0..<labelIndexRightTop.count)
                        {
                            tempxLabelIndex.append(labelIndexRightTop[i])
                        }
                        for i in (0..<labelIndexRightBottom.count)
                        {
                            tempxLabelIndex.append(labelIndexRightBottom[i])
                        }
                    }
                    else{
                        for i in (0..<labelIndexRightTop.count).reversed()
                        {
                            tempxLabelIndex.append(labelIndexRightTop[i])
                        }
                        for i in (0..<labelIndexRightBottom.count).reversed()
                        {
                            tempxLabelIndex.append(labelIndexRightBottom[i])
                        }
                    }
                    
                    labelIndexRight = tempxLabelIndex
                    
                    renderNonOverlappedLabels(dataSet: dataSet, viewPortHandler: viewPort, lineHeight: lineHeight, labelTopCount: rightLabelTopCount, labelBottomCount: rightLabelBottomCount, labelIndex: labelIndexRight, piePlot: piePlot, align: .right)
                }
                else{
                    for textLayer in valueTextLayerRight
                    {
                        self.chart?.plotView?.nsuiLayer?.addSublayer(textLayer)
                    }
                }
            }
            else{
                for textLayer in valueTextLayerLeft
                {
                    self.chart?.plotView?.nsuiLayer?.addSublayer(textLayer)
                }
                for textLayer in valueTextLayerRight
                {
                    self.chart?.plotView?.nsuiLayer?.addSublayer(textLayer)
                }
            }
        }
    }
    
    func renderNonOverlappedLabels(dataSet:IChartDataSet, viewPortHandler:ViewPortHandler,lineHeight:CGFloat,labelTopCount:Int,labelBottomCount:Int,labelIndex:[(Int,CGPoint)],piePlot:PiePlotOptions,align:NSTextAlignment)
    {
        guard let dataSet = dataSet as? ChartDataSet
        else { return }
        var labelTopCount = labelTopCount
        var labelBottomCount = labelBottomCount
        var labelIndex = labelIndex
        let radius = piePlot.radius
        
        // fitsAllLabel()
        let contentHeight = viewPortHandler.contentHeight
        var requiredHeight = lineHeight * CGFloat(labelTopCount+labelBottomCount)
        
        // Not fits
        if contentHeight < requiredHeight
        {
            let possibleCount = floor(contentHeight/lineHeight)
            
            labelTopCount =  ChartUtils.doubleToIntSafeCast(value:ceil(possibleCount/2))
            labelBottomCount =  ChartUtils.doubleToIntSafeCast(value:floor(possibleCount/2))
            
            var tempxLabelIndex:[(Int,CGPoint)] = []
            
            for i in 0..<labelTopCount
            {
                tempxLabelIndex.append(labelIndex[i])
            }
            for i in (labelIndex.count-labelBottomCount..<labelIndex.count)
            {
                tempxLabelIndex.append(labelIndex[i])
            }
            labelIndex = tempxLabelIndex
            
            requiredHeight = lineHeight * CGFloat(labelTopCount+labelBottomCount)
        }
        // Fits
        if contentHeight >= requiredHeight
        {
            let contentHalf = contentHeight/2
            let requiredTopHalfHeight = lineHeight * CGFloat(labelTopCount)
            let requiredBottomHalfHeight = lineHeight * CGFloat(labelBottomCount)
            
            // Not Fits in Top - Move some to Bottom
            if contentHalf < requiredTopHalfHeight
            {
                var yStart = viewPortHandler.contentRect.minY
                
                var interval = CGFloat(0)
                
                createValueTextLayer(from: 0, to: labelTopCount, yStart: &yStart, interval: interval, radius: radius, lineHeight: lineHeight, labelIndex: labelIndex, piePlot: piePlot, dataSet: dataSet, align: align)
                
                interval = ((viewPortHandler.contentBottom - yStart) - requiredBottomHalfHeight) / CGFloat(labelBottomCount)
                
                createValueTextLayer(from: labelTopCount, to: (labelTopCount+labelBottomCount), yStart: &yStart, interval: interval, radius: radius, lineHeight: lineHeight, labelIndex: labelIndex, piePlot: piePlot, dataSet: dataSet, align: align)
                
            }
            // Not Fits in Bottom - Move some to Top
            else if contentHalf < requiredBottomHalfHeight
            {
                var yStart = viewPortHandler.contentRect.minY
                
                var interval = ((contentHeight - requiredBottomHalfHeight) - requiredTopHalfHeight) / CGFloat(labelTopCount)
                
                createValueTextLayer(from: 0, to: labelTopCount, yStart: &yStart, interval: interval, radius: radius, lineHeight: lineHeight, labelIndex: labelIndex, piePlot: piePlot, dataSet: dataSet, align: align)

                interval = 0
                
                createValueTextLayer(from: labelTopCount, to: (labelTopCount+labelBottomCount), yStart: &yStart, interval: interval, radius: radius, lineHeight: lineHeight, labelIndex: labelIndex, piePlot: piePlot, dataSet: dataSet, align: align)
                
            }
            // All Fits
            else{
                var interval = (contentHalf - requiredTopHalfHeight) / CGFloat(labelTopCount)
                
                var yStart = viewPortHandler.contentRect.minY
                
                createValueTextLayer(from: 0, to: labelTopCount, yStart: &yStart, interval: interval, radius: radius, lineHeight: lineHeight, labelIndex: labelIndex, piePlot: piePlot, dataSet: dataSet, align: align)
                
                interval = (contentHalf - requiredBottomHalfHeight) / CGFloat(labelBottomCount)
                
                createValueTextLayer(from: labelTopCount, to: (labelTopCount+labelBottomCount), yStart: &yStart, interval: interval, radius: radius, lineHeight: lineHeight, labelIndex: labelIndex, piePlot: piePlot, dataSet: dataSet, align: align)
            }
            
        }
    }
    
    func createValueTextLayer(from:Int,to:Int, yStart:inout CGFloat, interval:CGFloat, radius:CGFloat, lineHeight:CGFloat, labelIndex:[(Int,CGPoint)], piePlot:PiePlotOptions,dataSet:ChartDataSet, align:NSTextAlignment)
    {
        guard let viewPort = viewPortHandler
        else { return }
        let xPoint = align == .left ? viewPort.contentCenter.x-radius : viewPort.contentCenter.x+radius
        let offset = align == .left ? -(piePlot.valueLinePart2Length * (piePlot.radius*0.3)) : (piePlot.valueLinePart2Length * (piePlot.radius*0.3))
        let lineOffset = align == .left ? CGFloat(5) : CGFloat(-5)
        
        let drawXOutside = piePlot.isDrawEntryLabelsEnabled //&& piePlot.xValuePosition == .outsideSlice
        let drawYOutside = dataSet.isDrawValuesEnabled //&& piePlot.yValuePosition == .outsideSlice
        
        for i in from..<to
        {
            guard let e = dataSet.entryForIndex(labelIndex[i].0),
                  let chart = chart
            else { continue }
            
            yStart = yStart + interval/2
            
            let angleForPoint = PieHelperFunctions.angleForPoint(x: xPoint, y: yStart, center: viewPort.contentCenter)
            
            let point = PieHelperFunctions.getPosition(center: viewPort.contentCenter, dist: radius, angle: angleForPoint)
            
            let valueTextLayer = ValueTextLayer()
            
            self.chart?.plotView?.nsuiLayer?.addSublayer(valueTextLayer)
            
            let xLabel = ((dataSet.entryForIndex(labelIndex[i].0)?.xString) != nil) ? (dataSet.valueFormatter?.getFormattedTextforLabel?(label: (dataSet.entryForIndex(labelIndex[i].0)?.xString)!, type: .x, data: e) ?? "") : ""
            
            let xLabelAttribute = [
                NSAttributedString.Key.font: piePlot.entryLabelFont ?? dataSet.valueFont,
                NSAttributedString.Key.foregroundColor: piePlot.entryLabelColor ?? dataSet.valueTextColorAt(labelIndex[i].0)]
            
            let yLabelAttributes = [
                NSAttributedString.Key.font: dataSet.valueFont,
                NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(labelIndex[i].0)]
            
            if drawXOutside && drawYOutside
            {
                // Y - Label
                guard let formatter = dataSet.valueFormatter
                else { continue }
                
                let valueFontHeight = dataSet.valueFont.lineHeight
                
                let yValueSum = PieHelperFunctions.getYValueSum(chart: chart)
                
                let value = piePlot.usePercentValuesEnabled ? e.y / yValueSum * 100.0 : e.y
                let valueText = formatter.getFormattedTextforValue?(value: value, type: .y, data: e) ?? ""
                /*formatter.stringForValue(
                    value,
                    entry: e,
                    dataSetIndex: i,
                    viewPortHandler: viewPortHandler)*/
                
                let yLabelOrigin = CGPoint(x: point.x + offset, y: yStart)
                
                let constrainedWidthForYLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: yLabelOrigin, align: align, size: valueText.size(withAttributes: yLabelAttributes))
                
                let layer = ChartUtils.drawTextLayer(
                    text: valueText,
                    point: yLabelOrigin,
                    align: align,
                    attributes: yLabelAttributes,
                    constrainedToWidth: constrainedWidthForYLabel,
                    truncationMode: piePlot.dataValuesTrancateMode
                )
                
                valueTextLayer.addSublayer(layer)
                
                let xLabelOrigin = CGPoint(x: point.x + offset, y: yStart+valueFontHeight)
                
                let constrainedWidthForXLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: xLabelOrigin, align: align, size: xLabel.size(withAttributes: xLabelAttribute))
                
                // X -  Label
                let labellayer = ChartUtils.drawTextLayer(
                    text: xLabel,
                    point: xLabelOrigin,
                    align: align,
                    attributes: xLabelAttribute,
                    constrainedToWidth: constrainedWidthForXLabel,
                    truncationMode: piePlot.dataValuesTrancateMode
                )
                
                valueTextLayer.addSublayer(labellayer)
            }
            else if drawXOutside
            {
                
                let xLabelOrigin = CGPoint(x: point.x + offset, y: yStart)
                
                let constrainedWidthForXLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: xLabelOrigin, align: align, size: xLabel.size(withAttributes: xLabelAttribute))
                
                let layer = ChartUtils.drawTextLayer(
                    text: xLabel,
                    point: xLabelOrigin,
                    align: align,
                    attributes: xLabelAttribute,
                    constrainedToWidth: constrainedWidthForXLabel,
                    truncationMode: piePlot.dataValuesTrancateMode
                )
                
                valueTextLayer.addSublayer(layer)
            }
            else if drawYOutside
            {
                guard let formatter = dataSet.valueFormatter
                else { continue }
                
                let yValueSum = PieHelperFunctions.getYValueSum(chart: chart)
                
                let value = piePlot.usePercentValuesEnabled ? e.y / yValueSum * 100.0 : e.y
                let valueText = formatter.getFormattedTextforValue?(value: value, type: .y, data: e) ?? "" /*stringForValue(
                    value,
                    entry: e,
                    dataSetIndex: i,
                    viewPortHandler: viewPortHandler)*/
                
                let yLabelOrigin = CGPoint(x: point.x + offset, y: yStart)
                
                let constrainedWidthForYLabel = PieHelperFunctions.constrainedWidthForDataLabel(chart: chart, point: yLabelOrigin, align: align, size: valueText.size(withAttributes: yLabelAttributes))
                
                let layer = ChartUtils.drawTextLayer(
                    text: valueText,
                    point: yLabelOrigin,
                    align: align,
                    attributes: yLabelAttributes,
                    constrainedToWidth: constrainedWidthForYLabel,
                    truncationMode: piePlot.dataValuesTrancateMode
                )
                
                valueTextLayer.addSublayer(layer)
            }
            
            if piePlot.valueLineColor != nil
            {
                let linePath = CGMutablePath() // UIBezierPath()
                
                linePath.move(to: labelIndex[i].1)
                linePath.addLine(to: CGPoint(x: point.x, y: yStart+lineHeight/2))
                linePath.addLine(to: CGPoint(x: point.x + offset + lineOffset , y: yStart+lineHeight/2))

                
                let lineLayer = CAShapeLayer()
                lineLayer.path = linePath//.cgPath
                lineLayer.strokeColor = piePlot.valueLineColor!.cgColor
                lineLayer.lineWidth = piePlot.valueLineWidth
                lineLayer.lineCap = convertToCAShapeLayerLineCap("round")
                lineLayer.fillColor = NSUIColor.clear.cgColor
                
                valueTextLayer.addSublayer(lineLayer)
                
                
            }
            
            yStart += lineHeight + interval/2
        }
    }
    
    open func ellipse(angle: CGFloat) -> CGFloat{
                var a:CGFloat = 0
        
                let tempValue = angle.truncatingRemainder(dividingBy: 180)
        
                if (tempValue >= 0.0 && tempValue <= 90.0)
                {
                    a = tempValue/2
                }
                else {
                    a = 90 - tempValue/2
                }
                a = a * ChartUtils.Math.FDEG2RAD
                return tan(a)
    }

    open func isFitInsideSlice(x:CGFloat,y:CGFloat,textWidth:CGFloat,curEntry:ChartDataEntry) -> Bool
    {
        guard let chart = chart
        else { return  false}
        
        let leftX = x - textWidth/2
        let rightX = x + textWidth/2
        
        let leftHigh = chart.getHighlightByTouchPoint(CGPoint(x: leftX, y: y))
        let rightHigh = chart.getHighlightByTouchPoint(CGPoint(x: rightX, y: y))
        
        if leftHigh == nil || rightHigh == nil{
            return false
        }
        
        return !(!(leftHigh?.x == rightHigh?.x) && !(chart.data?.dataSets[0].entryForIndex(ChartUtils.doubleToIntSafeCast(value:(leftHigh?.x)!)) === curEntry))
    }
    
    open override func drawExtras(context: CGContext)
    {
        guard let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions,
              let chart = chart
            else { return }
        
        piePlot.pieComponents.addPieCompomnents(context: context)
        drawHole(context: context)
        drawCenterText(context: context)
        #if os(iOS)
        piePlot.centerTextInstance.addCenterLabel(chart:chart)
        #endif
    }
    
    /// draws the hole in the center of the chart and the transparent circle / hole
    fileprivate func drawHole(context: CGContext)
    {
        guard
            let chart = chart,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
            let animator = animator
            else { return }
        
        if piePlot.drawHoleEnabled
        {
            context.saveGState()
            
            let radius = piePlot.radius
            let holeRadius = radius * piePlot.holeRadiusPercent
            let center = piePlot.centerCircleBox
            
            // only draw the circle if it can be seen (not covered by the hole)
            if let transparentCircleColor = piePlot.transparentCircleColor
            {
                if transparentCircleColor != NSUIColor.clear &&
                    piePlot.transparentCircleRadiusPercent > piePlot.holeRadiusPercent
                {
                    let alpha = animator.phaseX * animator.phaseY
                    let secondHoleRadius = radius * piePlot.transparentCircleRadiusPercent
                    
                    let transparentLayerPath = CGMutablePath()
                    transparentLayerPath.addEllipse(in: CGRect(
                        x: center.x - secondHoleRadius,
                        y: center.y - secondHoleRadius,
                        width: secondHoleRadius * 2.0,
                        height: secondHoleRadius * 2.0))
                    transparentLayerPath.addEllipse(in: CGRect(
                        x: center.x - holeRadius,
                        y: center.y - holeRadius,
                        width: holeRadius * 2.0,
                        height: holeRadius * 2.0))
                    
                    let transparentLayer = CAShapeLayer()
                    transparentLayer.path = transparentLayerPath
                    transparentLayer.fillColor = transparentCircleColor.cgColor
                    transparentLayer.opacity = Float(alpha)
                    self.chart?.plotView?.nsuiLayer?.addSublayer(transparentLayer)
                }
            }
            
            if let holeColor = piePlot.holeColor
            {
                if holeColor != NSUIColor.clear
                {
//                    let holeLayerPath = UIBezierPath(ovalIn: CGRect(x: center.x - holeRadius, y: center.y - holeRadius, width: holeRadius * 2.0, height: holeRadius * 2.0))
                    let holeLayerPath = CGMutablePath(ellipseIn: CGRect(x: center.x - holeRadius, y: center.y - holeRadius, width: holeRadius * 2.0, height: holeRadius * 2.0), transform: nil)
                    let holeLayer = CAShapeLayer()
                    holeLayer.path = holeLayerPath//.cgPath
                    holeLayer.fillColor = piePlot.holeColor!.cgColor
                    self.chart?.plotView?.nsuiLayer?.addSublayer(holeLayer)
                }
            }
            
            context.restoreGState()
        }
    }
    
    /// draws the description text in the center of the pie chart makes most sense when center-hole is enabled
    fileprivate func drawCenterText(context: CGContext)
    {
        guard
            let chart = chart,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
            let centerAttributedText = piePlot.centerAttributedText
            else { return }
        
        if piePlot.drawCenterTextEnabled && centerAttributedText.length > 0
        {
            let minFontSize = 5.0
            let center = piePlot.centerCircleBox
            let offset = piePlot.centerTextOffset
            let innerRadius = piePlot.drawHoleEnabled && !piePlot.drawSlicesUnderHoleEnabled ? piePlot.radius * piePlot.holeRadiusPercent : piePlot.radius
            var text = ""
            var textFrame = CGRect.zero
            var fontSize = piePlot.centerTextFont.pointSize
            
            let regex = try? NSRegularExpression(pattern: "(\\S+|\\n)", options: [])
            let words = (regex?.matches(in: centerAttributedText.string, options: [], range: NSRange(location: 0, length: centerAttributedText.length)).map {
                (centerAttributedText.string as NSString).substring(with: $0.range)
            }) ?? centerAttributedText.string.split { $0.isWhitespace || $0 == "\n"}.map(String.init)
            
            let x = center.x + offset.x
            let y = center.y + offset.y
            
            var textSize = (centerAttributedText.string as NSString).size(withAttributes: [NSAttributedString.Key.font: piePlot.centerTextFont.withSize(fontSize)])
            var maxSize = CGSize(width: innerRadius * 2.0, height: innerRadius * 0.8 * 2.0)
            
            var currentLine = ""
            for word in words {
                if word == "\n" {
                    text = text.isEmpty ? currentLine : text + "\n" + currentLine
                    currentLine = ""
                }
                else {
                    let textLine = currentLine.isEmpty ? String(word) : currentLine + " " + word
                    let textSize = (textLine as NSString).size(withAttributes: [NSAttributedString.Key.font: piePlot.centerTextFont])
                    if textSize.width <= maxSize.width {
                        currentLine = textLine
                    }
                    else {
                        if !currentLine.isEmpty {
                            text = text.isEmpty ? currentLine : text + "\n" + currentLine
                        }
                        currentLine = String(word)
                    }
                }
            }
            if !currentLine.isEmpty {
                text = text.isEmpty ? currentLine : text + "\n" + currentLine
            }
            
            textSize = (text as NSString).size(withAttributes: [NSAttributedString.Key.font: piePlot.centerTextFont])
            
            if piePlot.maxAngle == 360 {
                maxSize.width = ChartUtils.widthOfTheCricleFor(y: (maxSize.height / 2.0) - textSize.height / 2.0, radius: innerRadius, centerYPoint: maxSize.height / 2.0) ?? ChartUtils.widthOfTheCricleFor(y: 0.0, radius: innerRadius, centerYPoint: maxSize.height / 2.0) ?? 0.0
                if (maxSize.width < textSize.width || maxSize.height < textSize.height) {
                    let scaleFactor = ChartUtils.scaleBoundToFit(bounds: maxSize, size: textSize)
                    fontSize = piePlot.centerTextFont.pointSize * scaleFactor
                    if piePlot.centerTextFont.pointSize * scaleFactor < minFontSize {
                        return
                    }
                    maxSize = (text as NSString).size(withAttributes: [NSAttributedString.Key.font: piePlot.centerTextFont.withSize(fontSize)])
                }
                maxSize.width = min(maxSize.width, textSize.width)
                maxSize.height = min(maxSize.height, textSize.height)
                textFrame = CGRect(origin: CGPoint(x: x - maxSize.width / 2.0, y: y - maxSize.height / 2.0), size: maxSize)
            }
            else {
                maxSize.height = (viewPortHandler?.contentBottom ?? innerRadius) - y
                if maxSize.width < textSize.width || maxSize.height < textSize.height {
                    let scaleFactor = ChartUtils.scaleBoundToFit(bounds: maxSize, size: textSize)
                    fontSize = piePlot.centerTextFont.pointSize * scaleFactor
                    if piePlot.centerTextFont.pointSize * scaleFactor < minFontSize {
                        return
                    }
                    maxSize = (text as NSString).size(withAttributes: [NSAttributedString.Key.font: piePlot.centerTextFont.withSize(fontSize)])
                }
                maxSize.width = min(maxSize.width, textSize.width)
                maxSize.height = min(maxSize.height, textSize.height)
                textFrame = CGRect(origin: CGPoint(x: x - maxSize.width / 2.0, y: y), size: maxSize)
            }
            let textLayer = CATextLayer()
            textLayer.string = text
            textLayer.font = piePlot.centerTextFont
            textLayer.alignmentMode = .center
            textLayer.foregroundColor = piePlot.centerTextColor.cgColor
            textLayer.fontSize = fontSize
            textLayer.alignmentMode = .center
            textLayer.contentsScale = UIScreen.main.scale
            textLayer.frame = textFrame
            chart.plotView?.layer.addSublayer(textLayer)
        }
    }
    
    open override func drawHighlighted(context: CGContext, indices: [Highlight])
    {
        guard
            let chart = chart,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
            let data = chart.data,
            let animator = animator
            else { return }
        
        context.saveGState()
        
        let phaseX = animator.phaseX
        let phaseY = animator.phaseY
        
        var angle: CGFloat = 0.0
        let rotationAngle = piePlot.rotationAngle
        
        let drawAngles = piePlot.drawAngles
        let absoluteAngles = piePlot.absoluteAngles
        let center = piePlot.centerCircleBox
        let radius = piePlot.radius
        let drawInnerArc = piePlot.drawHoleEnabled && !piePlot.drawSlicesUnderHoleEnabled
        let userInnerRadius = drawInnerArc ? radius * piePlot.holeRadiusPercent : 0.0
        let clockwiseDirection = piePlot.sliceDirection == .clockwise
        
        for i in 0 ..< indices.count
        {
            // get the index to highlight
            let index =  ChartUtils.doubleToIntSafeCast(value:indices[i].x)
            if index >= drawAngles.count
            {
                continue
            }
            
            guard let set = data.getDataSetByIndex(indices[i].dataSetIndex)  else { continue }
            
            if !set.isHighlightEnabled
            {
                continue
            }

            let entryCount = set.entryCount
            var visibleAngleCount = 0
            for j in 0 ..< entryCount
            {
                guard let e = set.entryForIndex(j) else { continue }
                if ((abs(e.y) > Double.ulpOfOne))
                {
                    visibleAngleCount += 1
                }
            }
            
            if index == 0
            {
                angle = 0.0
            }
            else
            {
                angle = absoluteAngles[index - 1] * CGFloat(phaseX)
            }
            
            let sliceSpace = visibleAngleCount <= 1 ? 0.0 : piePlot.sliceSpace
            
            let sliceAngle = drawAngles[index]
            var innerRadius = userInnerRadius
            
            let shift = piePlot.selectionShift
            let highlightedRadius = radius + shift
            
            let accountForSliceSpacing = sliceSpace > 0.0 && sliceAngle <= 180.0
            
            context.setFillColor(set.color(atIndex: index).cgColor)
            
            let sliceSpaceAngleOuter = visibleAngleCount == 1 ?
                0.0 :
                sliceSpace / (ChartUtils.Math.FDEG2RAD * radius)
            
            let sliceSpaceAngleShifted = visibleAngleCount == 1 ?
                0.0 :
                sliceSpace / (ChartUtils.Math.FDEG2RAD * highlightedRadius)
            
            let startAngleOuter = rotationAngle + (angle + sliceSpaceAngleOuter / 2.0) * CGFloat(phaseY)
            var sweepAngleOuter = (sliceAngle - sliceSpaceAngleOuter) * CGFloat(phaseY)
            if sweepAngleOuter < 0.0
            {
                sweepAngleOuter = 0.0
            }
            if (!clockwiseDirection) {
                sweepAngleOuter = -sweepAngleOuter
            }
            
            let startAngleShifted = rotationAngle + (angle + sliceSpaceAngleShifted / 2.0) * CGFloat(phaseY)
            var sweepAngleShifted = (sliceAngle - sliceSpaceAngleShifted) * CGFloat(phaseY)
            if sweepAngleShifted < 0.0
            {
                sweepAngleShifted = 0.0
            }
            if (!clockwiseDirection) {
                sweepAngleShifted = -sweepAngleShifted
            }
            
            let path = CGMutablePath()
            
            path.move(to: CGPoint(x: center.x + highlightedRadius * cos(startAngleShifted * ChartUtils.Math.FDEG2RAD),
                                  y: center.y + highlightedRadius * sin(startAngleShifted * ChartUtils.Math.FDEG2RAD)))
            
            path.addRelativeArc(center: center, radius: highlightedRadius, startAngle: startAngleShifted * ChartUtils.Math.FDEG2RAD,
                                delta: sweepAngleShifted * ChartUtils.Math.FDEG2RAD)
            
            var sliceSpaceRadius: CGFloat = 0.0
            if accountForSliceSpacing
            {
                sliceSpaceRadius = calculateMinimumRadiusForSpacedSlice(
                    center: center,
                    radius: radius,
                    angle: sliceAngle * CGFloat(phaseY),
                    arcStartPointX: center.x + radius * cos(startAngleOuter * ChartUtils.Math.FDEG2RAD),
                    arcStartPointY: center.y + radius * sin(startAngleOuter * ChartUtils.Math.FDEG2RAD),
                    startAngle: startAngleOuter,
                    sweepAngle: sweepAngleOuter)
            }
            
            if drawInnerArc &&
                (innerRadius > 0.0 || accountForSliceSpacing)
            {
                if accountForSliceSpacing
                {
                    var minSpacedRadius = sliceSpaceRadius
                    if minSpacedRadius < 0.0
                    {
                        minSpacedRadius = -minSpacedRadius
                    }
                    innerRadius = min(max(innerRadius, minSpacedRadius), radius)
                }
                
                let sliceSpaceAngleInner = visibleAngleCount == 1 || innerRadius == 0.0 ?
                    0.0 :
                    sliceSpace / (ChartUtils.Math.FDEG2RAD * innerRadius)
                let startAngleInner = rotationAngle + (angle + sliceSpaceAngleInner / 2.0) * CGFloat(phaseY)
                var sweepAngleInner = (sliceAngle - sliceSpaceAngleInner) * CGFloat(phaseY)
                if sweepAngleInner < 0.0
                {
                    sweepAngleInner = 0.0
                }
                var endAngleInner = startAngleInner + sweepAngleInner
                if (!clockwiseDirection) {
                    endAngleInner = -endAngleInner
                }
                path.addLine(
                    to: CGPoint(
                        x: center.x + innerRadius * cos(endAngleInner * ChartUtils.Math.FDEG2RAD),
                        y: center.y + innerRadius * sin(endAngleInner * ChartUtils.Math.FDEG2RAD)))
                
                path.addRelativeArc(center: center, radius: innerRadius,
                                    startAngle: endAngleInner * ChartUtils.Math.FDEG2RAD,
                                    delta: -sweepAngleInner * ChartUtils.Math.FDEG2RAD)
            }
            else
            {
                if accountForSliceSpacing
                {
                    let angleMiddle = startAngleOuter + sweepAngleOuter / 2.0
                    
                    let arcEndPointX = center.x + sliceSpaceRadius * cos(angleMiddle * ChartUtils.Math.FDEG2RAD)
                    let arcEndPointY = center.y + sliceSpaceRadius * sin(angleMiddle * ChartUtils.Math.FDEG2RAD)
                    
                    path.addLine(
                        to: CGPoint(
                            x: arcEndPointX,
                            y: arcEndPointY))
                }
                else
                {
                    path.addLine(to: center)
                }
            }
            
            path.closeSubpath()
            
            context.beginPath()
            context.addPath(path)
            context.fillPath(using: .evenOdd)
        }
        
        context.restoreGState()
    }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCAShapeLayerLineCap(_ input: String) -> CAShapeLayerLineCap {
    return CAShapeLayerLineCap(rawValue: input)
}
