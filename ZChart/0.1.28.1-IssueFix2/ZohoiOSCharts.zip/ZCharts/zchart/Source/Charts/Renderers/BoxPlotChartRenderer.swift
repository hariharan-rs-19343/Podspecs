//
//  BoxPlotChartRenderer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 05/08/22.
//

import Foundation

open class BoxPlotChartRenderer: BarChartRenderer {
    
    override open func drawExtras(context: CGContext) {
        
        guard
            let chart = chart,
            let data = chart.data,
            let boxPlotPlotOption = chart.getPlotOptions(type: .BoxPlot) as? BoxPlotPlotOptions,
            let animator = animator
            else { return }
        
        context.saveGState()
        
        let trans = chart.getTransformer(axisIndex: data.dataSets[0].axisIndex)
        
        for dataSet in data.dataSets {
            
            if !dataSet.isVisible || !(dataSet.plotType == .BoxPlot) {
                continue
            }
            
            for entryIndex in 0..<dataSet.entryCount {
                
                guard let entry = dataSet.entryForIndex(entryIndex) else {
                    continue
                }
                
                if entry.x.isNaN {
                    continue
                }
                
                let y = entry.y.isNaN ? 0 : entry.y
                
                let y0 = entry.y0.isNaN ? 0 : entry.y0
                
                let firstQuartile = min(y,y0)

                let thirdQuartile = max(y,y0)
                
                let barWidth = CommonHelperFunctions.stepSize(chart: chart, axisIndex: dataSet.axisIndex) * boxPlotPlotOption.barWidth
                
                if let valArr = entry.plotData as? [Double] {
                    
                    let minWhiskers = valArr[safe:boxPlotPlotOption.minWhiskersIndex]
                    
                    let maxWhiskers = valArr[safe: boxPlotPlotOption.maxWhiskersIndex]
                    
                    let medianVal = valArr[safe: boxPlotPlotOption.medianIndex]
                    
                    if medianVal != nil && boxPlotPlotOption.medianEnabled {
                        
                        let path = CGMutablePath()// UIBezierPath()
                        
                        let layer = MedianLayer(chartEntry: entry)
                        
                        layer.plotConfiguration(boxPlotPlotOption: boxPlotPlotOption)
                        
                        layer.opacity = Float(animator.phaseX)
                        
                        if chart.customAnimationInProgress {
                            layer.opacity = 0.0
                        }
                        
                        let medianLineWidthHalf = barWidth / 2.0
                        
                        var medianPoint = chart.pixelForValues(isRotated: chart.isRotated, x: entry.x, y: medianVal!, axisIndex: dataSet.axisIndex)
                        
                        if barDeleted && entry.filterChanged != nil && (entry.filterChanged as? [CGRect]) != nil {
                            if let point = (entry.filterChanged as! [CGRect])[safe:2]?.origin {
                                medianPoint = point
                            }
                        }
                        
                        path.move(to: CGPoint(x: medianPoint.x - medianLineWidthHalf, y: medianPoint.y))
                        
                        path.move(to: getPoint(isRotated: chart.isRotated, point: medianPoint, shapeHalf: -medianLineWidthHalf))
                        path.addLine(to: getPoint(isRotated: chart.isRotated, point: medianPoint, shapeHalf: medianLineWidthHalf))
                        
                        layer.path = path//.cgPath
                        
                        if customOpacity {
                            layer.opacity = entry.opacityChanged
                        }
                        
                        chart.plotView?.nsuiLayer?.addSublayer(layer)
                        
                    }
                    
                    if boxPlotPlotOption.whiskersEnabled {
                        
                        let path = CGMutablePath() // UIBezierPath()
                        
                        let layer = WhiskersLayer(chartEntry: entry)
                        
                        layer.plotConfiguration(boxPlotPlotOption: boxPlotPlotOption)
                        
                        layer.opacity = Float(animator.phaseX)
                        
                        if chart.customAnimationInProgress {
                            layer.opacity = 0.0
                        }
                    
                        var firstQuartilePoint = chart.pixelForValues(isRotated: chart.isRotated, x: entry.x, y: firstQuartile, axisIndex: dataSet.axisIndex)
                    
                        var thirdQuartilePoint = chart.pixelForValues(isRotated: chart.isRotated, x: entry.x, y: thirdQuartile, axisIndex: dataSet.axisIndex)
                        
                        if barDeleted {
                            if entry.sizeChanged != nil && entry.centerChanged != nil {
                                
                                if chart.isRotated {
                                    firstQuartilePoint.y = entry.centerChanged!.y + (entry.sizeChanged!.height / 2.0)
                                    thirdQuartilePoint.y = entry.centerChanged!.y + (entry.sizeChanged!.height / 2.0)
                                    
                                    let firstQuartileXPixelPoint = entry.centerChanged!.x
                                    
                                    let thirdQuartileXPixelPoint = entry.centerChanged!.x + entry.sizeChanged!.width
                                    
                                    firstQuartilePoint.x = firstQuartileXPixelPoint

                                    thirdQuartilePoint.x = thirdQuartileXPixelPoint
                                }
                                else {
                                    firstQuartilePoint.x = entry.centerChanged!.x + (entry.sizeChanged!.width / 2.0)
                                    
                                    thirdQuartilePoint.x = entry.centerChanged!.x + (entry.sizeChanged!.width / 2.0)
                                    
                                    let firstQuartileYPixelPoint = entry.centerChanged!.y + entry.sizeChanged!.height
                                    
                                    let thirdQuartileYPixelPoint = entry.centerChanged!.y
                                    
                                    
                                    firstQuartilePoint.y = firstQuartileYPixelPoint
                                    
                                    thirdQuartilePoint.y = thirdQuartileYPixelPoint
                                }
                            }
                        }
                    
                        let whiskersWidthHalf = (barWidth * boxPlotPlotOption.whiskersBandWidth) / 2.0
                        
                        if boxPlotPlotOption.whiskersOn == .overLay {
                            
                            if minWhiskers != nil && maxWhiskers != nil {
                                path.move(to: firstQuartilePoint)
                                path.addLine(to: thirdQuartilePoint)
                            }
                            else {
                                continue
                            }
                        }
                        
                        if minWhiskers != nil {

                            var toPoint = chart.pixelForValues(isRotated: chart.isRotated, x: entry.x, y: minWhiskers!, axisIndex: dataSet.axisIndex)
                            
                            if barDeleted && entry.filterChanged != nil && (entry.filterChanged as? [CGRect]) != nil {
                                if let point = (entry.filterChanged as! [CGRect])[safe:0]?.origin {
                                    toPoint = point
                                }
                            }

                            path.move(to: firstQuartilePoint)
                            path.addLine(to: toPoint)
                            
                            path.move(to: getPoint(isRotated: chart.isRotated, point: toPoint, shapeHalf: -whiskersWidthHalf))
                            path.addLine(to: getPoint(isRotated: chart.isRotated, point: toPoint, shapeHalf: whiskersWidthHalf))
                        }

                        if maxWhiskers != nil {

                            var toPoint = chart.pixelForValues(isRotated: chart.isRotated, x: entry.x, y: maxWhiskers!, axisIndex: dataSet.axisIndex)
                            
                            if barDeleted && entry.filterChanged != nil && (entry.filterChanged as? [CGRect]) != nil {
                                if let point = (entry.filterChanged as! [CGRect])[safe:1]?.origin {
                                    toPoint = point
                                }
                            }

                            path.move(to: thirdQuartilePoint)
                            path.addLine(to: toPoint)

                            path.move(to: getPoint(isRotated: chart.isRotated, point: toPoint, shapeHalf: -whiskersWidthHalf))
                            path.addLine(to: getPoint(isRotated: chart.isRotated, point: toPoint, shapeHalf: whiskersWidthHalf))
                        }
                        
                        layer.path = path//.cgPath
                        
                        if customOpacity {
                            layer.opacity = entry.opacityChanged
                        }
                        
                        chart.plotView?.nsuiLayer?.addSublayer(layer)
                    }
                }
                
            }
            
        }
        
        context.restoreGState()
    }
    
    internal func getPoint(isRotated: Bool, point: CGPoint, shapeHalf: Double) -> CGPoint {
        return isRotated ? CGPoint(x: point.x, y: point.y + shapeHalf) : CGPoint(x: point.x + shapeHalf, y: point.y)
    }
        
}
