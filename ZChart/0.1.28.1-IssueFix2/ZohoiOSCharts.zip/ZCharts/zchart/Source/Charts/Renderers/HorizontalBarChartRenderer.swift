//
//  HorizontalBarChartRenderer.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


open class HorizontalBarChartRenderer: BarChartRenderer
{
    fileprivate let typeAllowed = [ ChartType.WaterFall, ChartType.BoxPlot, ChartType.HorizontalBarRange]
    
    open override func prepareBuffer(dataSet: IChartDataSet, index: Int)
    {
        guard
            let barLineChart = chart ,
            let processor = barLineChart.getProcessor(type: .Bar) as? HorizontalBarPreprocessor,
            let barPlotOption = barLineChart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions,
            let barData = barLineChart.data,
            let animator = animator
            else { return }
        
        let barChartView = barLineChart
              
        
        
        let barWidthHalf = barPlotOption.barWidth / 2.0
        
        let buffer = _buffers[index]
        var bufferIndex = 0
        let containsStacks = barPlotOption.isStacked
        let setIndex = index
        
        let isInverted = barLineChart.isInverted(axisIndex: dataSet.axisIndex)
        let phaseY = animator.phaseY
        var barRect = CGRect()
        var x: Double
        var y: Double
        
        var baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barLineChart, dataSet: dataSet)
       
        var start = 0
        var end = min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)
        var inc = 1
        
        if (barChartView.xAxis.isInverted) {
            start = dataSet.entryCount - 1
            end = dataSet.entryCount - (min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)) - 1
            inc = -1
        }
        
//        for i in stride(from: 0, to: min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount), by: 1)
        for i in stride(from: start, to: end, by: inc)
        {
            guard let e = dataSet.entryForIndex(i)else { continue }
            
            var prevEntry = dataSet.entryForIndex(i-1)
            
            var counterIndex = i-1
            
            while prevEntry != nil && (prevEntry?.x.isNaN)!
            {
                counterIndex -= 1
                prevEntry = dataSet.entryForIndex(counterIndex)
            }
            
            x = e.x
            y = e.y
            
            guard var value = (processor.entriesStackedYValue[setIndex]?[i])
            else { continue }
            
            if dataSet.plotType == .BoxPlot || dataSet.plotType == .HorizontalBarRange {
                value = y
                baseLineValue = e.y0
            }
            
            var yStart = baseLineValue
            
            if barPlotOption.stackedPercentEnabled
            {
                y = processor.positiveSum[e.x] != nil ? (e.y/processor.positiveSum[e.x]!)*100 : Double.nan
                
                if e.y < 0
                {
                    y = Double.nan
                }
            }
            
            let yValue = y.isNaN ? 0 : y
            
            if containsStacks || (prevEntry != nil && prevEntry?.x == e.x)
            {
                if yValue >= baseLineValue
                {
                    yStart = value - abs(yValue)
                }
                else{
                    yStart = value + abs(yValue)
                }
            }
            
            let bottom = CGFloat(x - barWidthHalf)
            let top = CGFloat(x + barWidthHalf)
            var right = isInverted
                ? (value <= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value >= yStart ? CGFloat(value) : CGFloat(yStart))
            var left = isInverted
                ? (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value <= yStart ? CGFloat(value) : CGFloat(yStart))
            
            if barPlotOption.stackSpacing != 0 && (left != baseLineValue && right != baseLineValue)
            {
                let onePointHeight = CommonHelperFunctions.getOnePointSize(chart: barLineChart, axis: barLineChart.yAxisArray[dataSet.axisIndex]).width
                let barHeight = onePointHeight * abs(right - left)
                let requiredSpacing = barPlotOption.stackSpacing < barHeight ? barPlotOption.stackSpacing : barHeight * (0.8)
                let requiredPoints = (1/onePointHeight) * requiredSpacing
                
                right = isInverted
                    ? ((yValue >= baseLineValue) ? (right + requiredPoints) : right)
                    : ((yValue >= baseLineValue) ? right : (right - requiredPoints))
                
                left = isInverted
                    ? ((yValue < baseLineValue) ? (left - requiredPoints) : left)
                    : ((yValue < baseLineValue) ? left : (left + requiredPoints))
                
            }
            
            if dataSet.plotType == .BoxPlot || dataSet.plotType == .HorizontalBarRange {
                
                if yValue > e.y0 {
                    baseLineValue = e.y0
                }
                else {
                    baseLineValue = y
                }
            }
            
            // multiply the height of the rect with the phase
            let rightInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: right)
            right = rightInterPolator(CGFloat(phaseY))
            
            let leftInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: left)
            left = leftInterPolator(CGFloat(phaseY))
            
            barRect.origin.x = left
            barRect.size.width = right - left
            barRect.origin.y = top
            barRect.size.height = bottom - top
            
            buffer.rects[bufferIndex] = barRect
            bufferIndex += 1
        }
    }
    
    fileprivate var _barShadowRectBuffer: CGRect = CGRect()
    
    open override func drawRenderer(context: CGContext, dataSet: IChartDataSet, index: Int) {
       
        guard let chart = chart,
            let viewPortHandler = chart.viewPortHandler,
            let barDataSetOption = dataSet.dataSetOptions as? BarDataSetOptions,
            let barPlotOption = chart.getPlotOptions(type: dataSet.plotType) as? BarPlotOptions
            else { return }
        
        let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let borderWidth = barDataSetOption.barBorderWidth
        let borderColor = barDataSetOption.barBorderColor
        let drawBorder = borderWidth > 0.0
        
        context.saveGState()
        
        // draw the bar shadow before the values
        if barPlotOption.isDrawBarShadowEnabled
        {
            guard
                let animator = animator
                else { return }
            
            let barWidth = barPlotOption.barWidth
            let barWidthHalf = barWidth / 2.0
            var x: Double = 0.0
            
            for i in stride(from: 0, to: min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount), by: 1)
            {
                guard let e = dataSet.entryForIndex(i) else { continue }
                
                x = e.x
                
                _barShadowRectBuffer.origin.y = CGFloat(x - barWidthHalf)
                _barShadowRectBuffer.size.height = CGFloat(barWidth)
                
                trans.rectValueToPixel(&_barShadowRectBuffer)
                
                if !viewPortHandler.isInBoundsTop(_barShadowRectBuffer.origin.y + _barShadowRectBuffer.size.height)
                {
                    if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                    {
                        continue
                    }
                    else
                    {
                        continue//break
                    }
                }
                
                if !viewPortHandler.isInBoundsBottom(_barShadowRectBuffer.origin.y)
                {
                    if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                    {
                        break
                    }
                    else
                    {
                        break//continue
                    }
                }
                
                _barShadowRectBuffer.origin.x = viewPortHandler.contentLeft
                _barShadowRectBuffer.size.width = viewPortHandler.contentWidth
                
                context.setFillColor(barDataSetOption.barShadowColor.cgColor)
                context.fill(_barShadowRectBuffer)
            }
        }
        
        let buffer = _buffers[index]
        
        let isSingleColor = dataSet.colors.count == 1
        
        if isSingleColor
        {
            context.setFillColor(dataSet.color(atIndex: 0).cgColor)
        }
        
        let isXReverse = chart.xAxis.isInverted
        
        for j in stride(from: 0, to: buffer.rects.count, by: 1)
        {
            var barRect = buffer.rects[j]
            
            var index = j
            
            if (isXReverse) {
                index = (buffer.rects.count - 1 - j )
            }
            
            guard let e = dataSet.entryForIndex(index) else { continue }
            
            /*************************** X NAN HANDLED ****************************/
            if (e.xString == nil && chart.xAxis.scaleType == .Ordinal) || e.x == Double.nan {
                continue
            }
            
            /*************************** DELETE BAR HANDLED ****************************/
            
            if e.filterEnabled
            {
                continue
            }
            
            if barDeleted
            {
                if e.centerChanged != nil{
                    barRect.origin.x = (e.centerChanged?.x)!
                    barRect.origin.y = (e.centerChanged?.y)!
                }
                
                if e.sizeChanged != nil{
                    barRect.size.width = (e.sizeChanged?.width)!
                    barRect.size.height = (e.sizeChanged?.height)!
                }
                
            }
            
            if e.isIncluded
            {
                let baseValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
                
                if e.y > baseValue
                {
                    if e.sizeChanged != nil{
                        barRect.size.width =  (e.sizeChanged?.width)!
                    }
                }
                else{
                    if e.sizeChanged != nil{
                        barRect.size.width =  (e.sizeChanged?.width)!
                    }
                    barRect.origin.x = (e.barYValue)
                }
            }
            
            /*************************** DELETE BAR HANDLED ****************************/
            
            if (!viewPortHandler.isInBoundsTop(barRect.origin.y + barRect.size.height))
            {
                if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                {
                    continue
                }
                else
                {
                    continue//break
                }
            }
            
            if (!viewPortHandler.isInBoundsBottom(barRect.origin.y))
            {
                if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                {
                    break
                }
                else
                {
                    break//continue
                }
            }
            
            if !(chart.includeLayer)
            {
                if !isSingleColor
                {
                    context.setFillColor(dataSet.color(atIndex: j).cgColor)
                }
                
                context.fill(barRect)
                
                if drawBorder
                {
                    context.setStrokeColor(borderColor.cgColor)
                    context.setLineWidth(borderWidth)
                    context.stroke(barRect)
                }
            }
            else
            {
                let barLayer = BarLayer(chartView: chart, chartEntry: e, dataSet: dataSet, barRect: barRect, barRectIndex: j)
                
                if customOpacity{
                    barLayer.opacity = e.opacityChanged
                }
                
                if dataSet.plotType == .Bullet
                {
                    let baseLineValue:Double = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
                    let isInverted = chart.isInverted(axisIndex: dataSet.axisIndex)
                    
                    let isSingleColor = barDataSetOption.levelMarkerColors.count == 1
                    
                    let levelColorDataSetIndex:Int
                    
                    if isSingleColor
                    {
                        levelColorDataSetIndex = 0
                    }
                    else{
                        levelColorDataSetIndex = (chart.data?.dataSets[0].entryIndex(entry: e)) ?? 0
                    }
                    
                    let levelWidthHalf = (barPlotOption.levelMarkerWidth)/2
                    
                    guard let eLevelMarker = e.levelMarker
                    else { continue }
                    
                    for level in (eLevelMarker.sorted(by: { abs($0) > abs($1) }))
                    {
                        let levelIndex = ((eLevelMarker.lastIndex(of: level)) ?? 0) % barDataSetOption.levelMarkerColors[levelColorDataSetIndex].count

                        let levelRight = isInverted
                            ? (level <= baseLineValue ? CGFloat(level) : CGFloat(baseLineValue))
                            : (level >= baseLineValue ? CGFloat(level) : CGFloat(baseLineValue))
                        
                        let levelLeft = isInverted
                            ? (level >= baseLineValue ? CGFloat(level) : CGFloat(baseLineValue))
                            : (level <= baseLineValue ? CGFloat(level) : CGFloat(baseLineValue))
                        
                        let levelTop = CGFloat(e.x - levelWidthHalf)
                        
                        let levelBottom = CGFloat(e.x + levelWidthHalf)
                        
                        
                        var levelRect = CGRect(x: levelLeft, y: levelTop, width: levelRight-levelLeft, height: levelBottom-levelTop)
                        
                        trans.rectValueToPixel(&levelRect)
                        
                        let levelLayer = LevelLayer(chartView: chart, chartEntry: e, dataSet: dataSet, barRect: levelRect, barRectIndex: j)
                        
                        levelLayer.fillColor = barDataSetOption.levelMarkerColors[levelColorDataSetIndex][levelIndex].cgColor
                        
                        chart.plotView?.nsuiLayer?.addSublayer(levelLayer)
                        
                    }
                }
                
                chart.plotView?.nsuiLayer?.addSublayer(barLayer)
                
                if e.targetMarker != nil
                {
                    let targetLayer = CAShapeLayer()
                    
                    let shapeProp = barDataSetOption.targetMarkerShapeProperties
          
                    let point = chart.pixelForValues(x: e.targetMarker!, y: e.x, axisIndex: dataSet.axisIndex)

                    _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProp, point: point, strokeColor: (shapeProp.strokeColor?.cgColor) ?? NSUIColor.black.cgColor, currentLayer: targetLayer)
                    
                    chart.plotView?.nsuiLayer?.addSublayer(targetLayer)
                }
            }
        }
        
        context.restoreGState()
        }
    
    public static func getHorizontalBarRectArray(entries: [ChartDataEntry], animator: Animator, dataSet: IChartDataSet, chart:ChartViewBase) -> [CGRect]
    {
        var barRectArray:[CGRect] = []
        
        let typeAllowed = [ ChartType.Bullet, ChartType.BoxPlot, ChartType.HorizontalBarRange]
        
        guard  let barData = chart.data,
            let processor = chart.getProcessor(type: .Bar) as? HorizontalBarPreprocessor,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
            else { return barRectArray }
        
        let barChart = chart
        
        
        let barWidthHalf = (barPlotOptions.barWidth) / 2.0
        
        var bufferIndex = 0
        let containsStacks = barPlotOptions.isStacked
        let setIndex = barData.indexOfDataSet(dataSet)
        
        let isInverted = chart.isInverted(axisIndex: dataSet.axisIndex)
        let phaseY = animator.phaseY
        
        var baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barChart, dataSet: dataSet)
        
        for i in stride(from: 0, to: entries.count, by: 1)
        {
            let e = entries[i]
            
            var prevEntry = ((i-1) >= 0 && (i-1) < entries.count) ? entries[i-1] : nil
            
            var counterIndex = i-1
            
            while prevEntry != nil && (prevEntry?.x.isNaN)!
            {
                counterIndex -= 1
                prevEntry = dataSet.entryForIndex(counterIndex)
            }
            
            var barRect = CGRect()
            
            let x: Double = e.x
            var y: Double = e.y
            
            var yStart = baseLineValue
            
            guard var value = (processor.entriesStackedYValue[setIndex]?[i])
            else { continue }
            
            if dataSet.plotType == .BoxPlot || dataSet.plotType == .HorizontalBarRange{
                value = y
                baseLineValue = e.y0
            }
            
            if barPlotOptions.stackedPercentEnabled
            {
                y = processor.positiveSum[e.x] != nil ? (e.y/processor.positiveSum[e.x]!)*100 : Double.nan
                
                if e.y < 0
                {
                    y = Double.nan
                }
            }
            
            let yValue = y.isNaN ? 0 : y
            
            if containsStacks || (prevEntry != nil && prevEntry?.x == e.x)
            {
                if yValue >= baseLineValue
                {
                    yStart = value - abs(yValue)
                }
                else{
                    yStart = value + abs(yValue)
                }
            }
            
            let bottom = CGFloat(x - barWidthHalf)
            let top = CGFloat(x + barWidthHalf)
            var right = isInverted
                ? (value <= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value >= yStart ? CGFloat(value) : CGFloat(yStart))
            var left = isInverted
                ? (value >= yStart ? CGFloat(value) : CGFloat(yStart))
                : (value <= yStart ? CGFloat(value) : CGFloat(yStart))
            
            if barPlotOptions.stackSpacing != 0 && (left != baseLineValue && right != baseLineValue)
            {
                let onePointHeight = CommonHelperFunctions.getOnePointSize(chart: chart, axis: chart.yAxisArray[dataSet.axisIndex]).width
                let barHeight = onePointHeight * abs(right - left)
                let requiredSpacing = barPlotOptions.stackSpacing < barHeight ? barPlotOptions.stackSpacing : barHeight * (0.8)
                let requiredPoints = (1/onePointHeight) * requiredSpacing
                
                right = isInverted
                    ? ((yValue >= baseLineValue) ? (right + requiredPoints) : right)
                    : ((yValue >= baseLineValue) ? right : (right - requiredPoints))
                
                left = isInverted
                    ? ((yValue < baseLineValue) ? (left - requiredPoints) : left)
                    : ((yValue < baseLineValue) ? left : (left + requiredPoints))
                
            }
            
            if dataSet.plotType == .BoxPlot || dataSet.plotType == .HorizontalBarRange{
                
                if yValue > e.y0 {
                    baseLineValue = e.y0
                }
                else {
                    baseLineValue = y
                }
            }
            
            // multiply the height of the rect with the phase
            let rightInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: right)
            right = rightInterPolator(CGFloat(phaseY))
            
            let leftInterPolator = Interpolator.interpolate(a: CGFloat(baseLineValue), b: left)
            left = leftInterPolator(CGFloat(phaseY))
            
            barRect.origin.x = left
            barRect.size.width = right - left
            barRect.origin.y = top
            barRect.size.height = bottom - top
            
            barRectArray.append(barRect)
            bufferIndex += 1
        }
        
        let trans = barChart.getTransformer(axisIndex: dataSet.axisIndex)
        trans.rectValuesToPixel(&barRectArray)

        return barRectArray
    }
    
    open override func prepareBarHighlight(
        x: Double,
        y1: Double,
        y2: Double,
        barWidthHalf: Double,
        trans: Transformer,
        rect: inout CGRect)
    {
        let top = x - barWidthHalf
        let bottom = x + barWidthHalf
        let left = y1
        let right = y2
        
        rect.origin.x = CGFloat(left)
        rect.origin.y = CGFloat(top)
        rect.size.width = CGFloat(right - left)
        rect.size.height = CGFloat(bottom - top)
        
        trans.rectValueToPixelHorizontal(&rect, phaseY: animator?.phaseY ?? 1.0)
    }
    /*
    open override func drawValues(context: CGContext)
    {
        guard let chart = chart
        else { return }
        // if values are drawn
        if isDrawingValuesAllowed(dataProvider: chart)
        {
            guard
                let barData = chart.data,
                let animator = animator,
                let viewPortHandler = chart.viewPortHandler,
                let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
                else { return }
            
            let dataSets = barData.dataSets
            
            let textAlign = barPlotOptions.drawValueCenteredEnabled ? .center : NSTextAlignment.right
            
            let valueOffsetPlus: CGFloat = 5.0
            var posOffset: CGFloat
            var negOffset: CGFloat
            let drawValueAboveBar = barPlotOptions.isDrawValueAboveBarEnabled
            let xAxisInverted = (chart.xAxis.inverted)
            
            // X Value -> (Y Value, Y Position)
            var xValueToTopYPosition:[Double:(Double,Double)] = [:]
            var xValueToBottomYPosition:[Double:(Double,Double)] = [:]
            
            for dataSetIndex in 0 ..< barData.dataSetCount
            {
                let dataSet = dataSets[dataSetIndex]
                
                if !shouldDrawValues(forDataSet: dataSet) || !(dataSet.isDrawIconsEnabled && dataSet.isVisible)
                {
                    continue
                }
                
                let isInverted = chart.isInverted(axisIndex: dataSet.axisIndex)
                
                let valueFont = dataSet.valueFont
                let yOffset = -valueFont.lineHeight / 2.0
                
                guard let formatter = dataSet.valueFormatter else { continue }
                
                let iconsOffset = dataSet.iconsOffset
                
                let buffer = _buffers[dataSetIndex]
                
                var baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSet)
                
                var start = 0
                var end =  ChartUtils.doubleToIntSafeCast(value:ceil(Double(dataSet.entryCount) * animator.phaseX))
                var increment = 1
                
                if (xAxisInverted) {
                    start = dataSet.entryCount - 1
                    end = dataSet.entryCount - (Int(ceil(Double(dataSet.entryCount) * animator.phaseX))) - 1
                    increment = -1
                }
                
//                    for j in 0 ..<  ChartUtils.doubleToIntSafeCast(value:ceil(Double(dataSet.entryCount) * animator.phaseX))
                for j in stride(from: start, to: end, by: increment)
                {
                    guard let e = dataSet.entryForIndex(j) else { continue }
                    
                    if e.x.isNaN || e.y.isNaN
                    {
                        continue
                    }
                    
                    var bufferIndex = j
                    
                    if (xAxisInverted) {
                        bufferIndex = buffer.rects.count - 1 - j
                    }
                    
                    let rect = buffer.rects[bufferIndex]
//                        let rect = buffer.rects[j]
                    
                    if dataSet.plotType == .BoxPlot {
                        
                        if dataSet.plotType == .BoxPlot {

                            baseLineValue = e.y0
                        }
                        
                        drawHorizontalBoxPlotValues(context: context, dataset: dataSet, entry: e, drawValueAboveBar: drawValueAboveBar, valueOffsetPlus: valueOffsetPlus)
                        
                    }
                    
                    let xPos = barPlotOptions.drawValueCenteredEnabled ? rect.origin.x + rect.width / 2.0 : rect.origin.x + rect.width
                    let y = rect.origin.y + rect.size.height / 2.0
                    
                    if !viewPortHandler.isInBoundsTop(rect.origin.y)
                    {
                        if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                        {
                            continue
                        }
                        else
                        {
                            continue//break
                        }
                    }
                    
                    if !viewPortHandler.isInBoundsX(rect.origin.x)
                    {
                        if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                        {
                            continue//break
                        }
                        else
                        {
                            continue
                        }
                    }
                    
                    if !viewPortHandler.isInBoundsBottom(rect.origin.y)
                    {
                        if (viewPortHandler.chartViewBase?.xAxis.isInverted) ?? true
                        {
                            break
                        }
                        else
                        {
                            break//continue
                        }
                    }
                    
                    let val = e.y
                    let valueText = formatter.stringForValue(
                        val,
                        entry: e,
                        dataSetIndex: dataSetIndex,
                        viewPortHandler: viewPortHandler)
                    
                    // calculate the correct offset depending on the draw position of the value
                    let valueTextWidth = valueText.size(withAttributes: [NSAttributedString.Key.font: valueFont]).width
                    posOffset = (drawValueAboveBar ? valueOffsetPlus : -(valueTextWidth + valueOffsetPlus))
                    negOffset = (drawValueAboveBar ? -(valueTextWidth + valueOffsetPlus) : valueOffsetPlus)
                    
                    if isInverted
                    {
                        posOffset = -posOffset - valueTextWidth
                        negOffset = -negOffset - valueTextWidth
                    }
                    
                    if barPlotOptions.isStackedSumEnabled && barPlotOptions.isStacked || dataSet.plotType == .HorizontalBarRange
                    {
//                            let currentYPosition = val >= baseLineValue ? (rect.origin.y + -(valueTextHeight + valueOffsetPlus)) : (rect.origin.y + rect.size.height + valueOffsetPlus)
                        
                        if val >= baseLineValue && !isInverted
                        {
                            let yVal:Double = round(chart.valueForTouchPoint(point: CGPoint(x: rect.origin.x + rect.size.width, y: rect.origin.y), axisIndex: dataSet.axisIndex).x)
                            
                            var currentXPosition:Double = rect.origin.x + rect.size.width + valueOffsetPlus
                            
                            if drawValueAboveBar && dataSet.isDrawValuesEnabled
                            {
                                currentXPosition += valueTextWidth
                            }
                            
                            if xValueToTopYPosition[e.x] != nil
                            {
                                let topValue = xValueToTopYPosition[e.x]!.1 > currentXPosition ? xValueToTopYPosition[e.x]! : (yVal,currentXPosition)
                                xValueToTopYPosition[e.x] = topValue
                            }
                            else{
                                xValueToTopYPosition[e.x] = (yVal,currentXPosition)
                            }
                        }
                        else{
                            let yVal:Double = round(chart.valueForTouchPoint(point: CGPoint(x: rect.origin.x, y: rect.origin.y), axisIndex: dataSet.axisIndex).x)
                            
                            var currentXPosition:Double = (rect.origin.x - valueOffsetPlus)
                            
                            if drawValueAboveBar && dataSet.isDrawValuesEnabled
                            {
                                currentXPosition -= valueTextWidth
                            }
                            
                            if xValueToBottomYPosition[e.x] != nil
                            {
                                let bottomValue = xValueToBottomYPosition[e.x]!.1 < currentXPosition ? xValueToBottomYPosition[e.x]! : (yVal,currentXPosition)
                                xValueToBottomYPosition[e.x] = bottomValue
                            }
                            else{
                                xValueToBottomYPosition[e.x] = (yVal,currentXPosition)
                            }
                        }
                    }
                    
                    if dataSet.isDrawValuesEnabled
                    {
                        if "1850" == valueText {
                            
                        }
                        drawValue(
                            context: context,
                            value: valueText,
                            xPos: barPlotOptions.drawValueCenteredEnabled ? xPos : xPos
                                + (val >= baseLineValue ? posOffset : (negOffset - rect.size.width)),
                            yPos: y + yOffset,
                            font: valueFont,
                            align: textAlign,
                            color: dataSet.valueTextColorAt(j),
                            constrainedWidth: -1)
                        
                        if dataSet.plotType == .BoxPlot {
                            
                            let y0 = e.y0.isNaN ? 0 : e.y0
                            
                            drawValue(
                                context: context,
                                value: String(y0),
                                xPos: xPos
                                    + (val <= baseLineValue ? posOffset : (negOffset - rect.size.width)),
                                yPos: y + yOffset,
                                font: valueFont,
                                align: textAlign,
                                color: dataSet.valueTextColorAt(j),
                                constrainedWidth: -1)
                        }
                    }
                    
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                        var px = (rect.origin.x + rect.size.width)
                            + (val >= baseLineValue ? posOffset : (negOffset - rect.size.width))
                        var py = y
                        
                        px += iconsOffset.x
                        py += iconsOffset.y
                        
                        ChartUtils.drawImage(
                            context: context,
                            image: icon,
                            x: px,
                            y: py,
                            size: icon.size)
                    }
                }
            }
            
            if barPlotOptions.isStackedSumEnabled && dataSets.count > 1 && !chart.interactionAnimationInProgress && barPlotOptions.isStacked || chart.getPlotTypes().contains(where: {$0 == ChartType.HorizontalBarRange})
            {
                
                if chart.plotTypes.contains(.WaterFall) {
                    WaterFallHelperFunction.sumForStackedWaterFall(chart: chart, xPositiveDict: &xValueToTopYPosition, xNegativeDict: &xValueToBottomYPosition)
                }
                
                drawStackedSum(context:context,xPositiveDict:xValueToTopYPosition,xNegativeDict:xValueToBottomYPosition)
            }

        }
    }
    
    open func drawStackedSum(context:CGContext, xPositiveDict:[Double:(Double,Double)], xNegativeDict:[Double:(Double,Double)])
    {
        guard
        let chart = chart,
        let barPlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? BarPlotOptions
        else { return }
        
        for (key,value) in xPositiveDict
        {
            let yValue = value.0
            let xPixel = (value.1)  //chart.pixelForValues(x: key, y: value.0, axisIndex: 0).x
            let text = barPlotOption.stackSumValueFormatter.getFormattedValue?(stackSum: yValue, entryX: key) ?? String(yValue)
            let textSize = text.size(withAttributes: [NSAttributedString.Key.font: barPlotOption.stackSumValueFont])
            let yPixel = chart.pixelForValues(x: value.0, y: key, axisIndex: 0).y  - (textSize.height / 2.0)
            
            let labelRect = CGRect(origin: CGPoint(x: xPixel, y: yPixel), size: textSize)
            
            let constrainedWidth = ChartUtils.constrainedWidthForDataLabel(chart: chart, rect: labelRect, align: .left)
            
            drawValue(
                context: context,
                value: text,
                xPos: xPixel,
                yPos: yPixel,
                font: barPlotOption.stackSumValueFont,
                align: .left,
                color: barPlotOption.stackSumValueTextColor,
                constrainedWidth: constrainedWidth)
        }
        
        for (key,value) in xNegativeDict
        {
            let yValue = value.0
            let text = barPlotOption.stackSumValueFormatter.getFormattedValue?(stackSum: yValue, entryX: key) ?? String(yValue)
            let textSize = text.size(withAttributes: [NSAttributedString.Key.font: barPlotOption.stackSumValueFont])
            let xPixel = value.1
            let yPixel = chart.pixelForValues(x: value.0, y: key, axisIndex: 0).y - (textSize.height / 2.0)
            
            let labelRect = CGRect(origin: CGPoint(x: xPixel, y: yPixel), size: textSize)
            
            let constrainedWidth = ChartUtils.constrainedWidthForDataLabel(chart: chart, rect: labelRect, align: .left)
            
            drawValue(
                context: context,
                value: text,
                xPos: xPixel,
                yPos: yPixel,
                font: barPlotOption.stackSumValueFont,
                align: .left,
                color: barPlotOption.stackSumValueTextColor,
                constrainedWidth: constrainedWidth)
        }
    }
*/
    
    open override func isDrawingValuesAllowed(dataProvider: ChartViewBase?) -> Bool
    {
        guard let data = dataProvider?.data,
            let plotOptions  = dataProvider?.getPlotOptions() as? AxisChartPlotOptions
            else { return false }
        
        let maxCount = plotOptions.isStacked ? ((dataProvider?.maxVisibleCount ?? 0) * data.dataSetCount) : (dataProvider?.maxVisibleCount ?? 0)
        
        return data.entryCount <  ChartUtils.doubleToIntSafeCast(value:CGFloat(maxCount) * (viewPortHandler?.scaleY ?? 1.0))
    }
    
    /// Sets the drawing position of the highlight object based on the riven bar-rect.
    internal override func setHighlightDrawPos(highlight high: Highlight, barRect: CGRect)
    {
        high.setDraw(x: barRect.midY, y: barRect.origin.x + barRect.size.width)
    }
}

extension HorizontalBarChartRenderer {
    /*
    public func drawHorizontalBoxPlotValues(context: CGContext, dataset: IChartDataSet, entry: ChartDataEntry, drawValueAboveBar: Bool, valueOffsetPlus: Double) {
        
        guard let chart = chart,
              let boxPlotPlotOption = chart.getPlotOptions(type: .BoxPlot) as? BoxPlotPlotOptions
              else {
                return
            }
        
        if entry.x.isNaN || chart.interactionAnimationInProgress || chart.customAnimationInProgress {
            return
        }
        
        var posOffset: CGFloat
        
        var negOffset: CGFloat
        
        var yOffset: Double
        
        
        if let valArr = entry.plotData as? [Double] {
            
            let trans = chart.getTransformer(axisIndex: dataset.axisIndex)
            
            let minWhiskers = valArr[safe:boxPlotPlotOption.minWhiskersIndex]
            
            let maxWhiskers = valArr[safe: boxPlotPlotOption.maxWhiskersIndex]
            
            let medianVal = valArr[safe: boxPlotPlotOption.medianIndex]
        
            if boxPlotPlotOption.medianEnabled && boxPlotPlotOption.drawMedianValueEnabled &&
                medianVal != nil &&
                !medianVal!.isNaN {
                
                let medianValueFont = boxPlotPlotOption.medianValueFont
                
                yOffset = -medianValueFont.lineHeight / 2.0
                
                let medianValueText = boxPlotPlotOption.medianValueFormatter.getFormattedValue?(medianValue: medianVal!) ?? String(medianVal!)
                
                let valueTextWidth = medianValueText.size(withAttributes: [NSAttributedString.Key.font: medianValueFont]).width
                posOffset = (drawValueAboveBar ? valueOffsetPlus : -(valueTextWidth + valueOffsetPlus))
                
                if chart.isInverted(axisIndex: dataset.axisIndex)
                {
                    posOffset = -posOffset - valueTextWidth
                }
            
                var medianPoint = CGPoint(x: medianVal!, y: entry.x)
                
                trans.pointValueToPixel(&medianPoint)
                
                drawValue(
                    context: context,
                    value: medianValueText,
                    xPos: medianPoint.x + posOffset,
                    yPos: medianPoint.y + yOffset,
                    font: medianValueFont,
                    align: .right,
                    color: boxPlotPlotOption.medianValueTextColor,
                    constrainedWidth: -1)
            }
            
            if boxPlotPlotOption.whiskersEnabled && boxPlotPlotOption.drawWhiskersValueEnabled {
                
                if boxPlotPlotOption.whiskersOn == .overLay && !(minWhiskers != nil) || !(maxWhiskers != nil) {
                    return
                }
                
                let whiskersValueFont = boxPlotPlotOption.medianValueFont
                
                yOffset = -whiskersValueFont.lineHeight / 2.0
                
                var whiskersValueText: String
                
                var valueTextWidth: Double
                
                if minWhiskers != nil && !minWhiskers!.isNaN {
                    
                    whiskersValueText = boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: minWhiskers!) ?? String(minWhiskers!)
                    
                    // calculate the correct offset depending on the draw position of the value
                    valueTextWidth = whiskersValueText.size(withAttributes: [NSAttributedString.Key.font: whiskersValueFont]).width
                    
                    negOffset = (drawValueAboveBar ? -(valueTextWidth + valueOffsetPlus) : valueOffsetPlus)
                    
                    if chart.isInverted(axisIndex: dataset.axisIndex)
                    {
                        negOffset = -negOffset - valueTextWidth
                    }
                    
                    var minWhiskersPoint = CGPoint(x: minWhiskers!, y: entry.x)
                    
                    trans.pointValueToPixel(&minWhiskersPoint)
                    
                    drawValue(
                        context: context,
                        value: boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: minWhiskers!) ?? String(minWhiskers!),
                        xPos: minWhiskersPoint.x + negOffset,
                        yPos: minWhiskersPoint.y + yOffset,
                        font: boxPlotPlotOption.whiskersValueFont,
                        align: .right,
                        color: boxPlotPlotOption.whiskersValueTextColor,
                        constrainedWidth: -1)
                    
                }
                
                if maxWhiskers != nil && !maxWhiskers!.isNaN {
                    
                    whiskersValueText = boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: maxWhiskers!) ?? String(maxWhiskers!)
                    
                    valueTextWidth = whiskersValueText.size(withAttributes: [NSAttributedString.Key.font: whiskersValueFont]).width
                    
                    posOffset = (drawValueAboveBar ? valueOffsetPlus : -(valueTextWidth + valueOffsetPlus))
                    
                    if chart.isInverted(axisIndex: dataset.axisIndex)
                    {
                        posOffset = -posOffset - valueTextWidth
                    }
                    
                    var maxWhiskersPoint = CGPoint(x: maxWhiskers!, y: entry.x)
                    
                    trans.pointValueToPixel(&maxWhiskersPoint)
                    
                    drawValue(
                        context: context,
                        value: boxPlotPlotOption.whiskersValueFormatter.getFormattedValue?(whiskersValue: maxWhiskers!) ?? String(maxWhiskers!),
                        xPos: maxWhiskersPoint.x + posOffset,
                        yPos: maxWhiskersPoint.y + yOffset,
                        font: boxPlotPlotOption.whiskersValueFont,
                        align: .right,
                        color: boxPlotPlotOption.whiskersValueTextColor,
                        constrainedWidth: -1)
                    
                }
            }
        }
    }*/
}
