//
//  GradientLayerRenderer.swift
//  zchart
//
//  Created by Aravinth T on 08/10/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

@objc(ChartGradientLayerRenderer)
open class GradientLayerRenderer : NSObject
{
    public static func renderGradientLayer(container:CALayer, gradientPath:CGPath, gradient:BaseGradient, drawMaskEnabled:Bool) -> BaseGradientLayer?
    {
        let gradientLayer = createGradientLayer(baseGradient: gradient, gradientPath: gradientPath)
        if gradientLayer == nil
        {
            Log.info("Gradient Layer not created for " + String(describing: gradient) )
            return nil
        }
        gradientLayer?.drawMaskEnabled = drawMaskEnabled
        container.addSublayer(gradientLayer!)
        return gradientLayer
    }
    
    fileprivate static func createGradientLayer(baseGradient:BaseGradient, gradientPath:CGPath) -> BaseGradientLayer? {
        var gradientLayer:BaseGradientLayer? = nil
        if baseGradient.isKind(of: LinearGradient.self)
        {
          gradientLayer = LinearGradientLayer(gradient: baseGradient, gradientPath: gradientPath)
        }
        else if baseGradient.isKind(of: RadialGradient.self)
        {
            gradientLayer = RadialGradientLayer(gradient: baseGradient, gradientPath: gradientPath)
        }
        else
        {
            Log.info("Gradient type not supported " + String(describing: baseGradient))
        }
        return gradientLayer
    }
    
    public static func getGradientLayer(container:CALayer) -> BaseGradientLayer? {
        
        let subLayers = container.sublayers
        if subLayers == nil || subLayers!.count == 0 {
            return nil
        }
        
        var baseGradientLayer:BaseGradientLayer? = nil
        
        for child in subLayers! {
            if child.isKind(of: BaseGradientLayer.self){
                baseGradientLayer = (child as! BaseGradientLayer)
                break
            }
        }
        return baseGradientLayer
    }
    
    public static func getGradientLayerForAnimation(container:CALayer) -> CALayer? {
       
        let baseGradientLayer = getGradientLayer(container: container)
        
        if baseGradientLayer == nil {
            return nil
        }
        
        if !((baseGradientLayer?.drawMaskEnabled)!) || (baseGradientLayer?.mask == nil) {
            return baseGradientLayer
        }
        
        return baseGradientLayer?.mask
    }
    
    public static func removeGradientLayer(container:CALayer) {
        
        let baseGradientLayer = getGradientLayer(container: container)
        
        if baseGradientLayer == nil {
            return
        }
        baseGradientLayer?.mask = nil
        baseGradientLayer?.removeFromSuperlayer()
    }
    
    public static func updateGradientLayer(container:CALayer, gradientPath:CGPath, gradient:BaseGradient, drawMaskEnabled:Bool) -> BaseGradientLayer? {
      removeGradientLayer(container: container)
      return renderGradientLayer(container: container, gradientPath: gradientPath, gradient: gradient, drawMaskEnabled: drawMaskEnabled)
    }
    
    public static func updateGradientLayerPath(targetLayer:ChartEntryLayer,newPath:CGMutablePath) {
        let gradientLayer = getGradientLayerForAnimation(container: targetLayer)
        
        if gradientLayer == nil {
            Log.info("Gradient layer not found for " + String(describing: targetLayer.chartEntry))
            return
        }
        
        //Need to clear the existing color during magnifying operation
        targetLayer.fillColor = NSUIColor.clear.cgColor
        
        var isGradientLayer = true
        
        if (gradientLayer?.isKind(of: CAShapeLayer.self))!{
            isGradientLayer = false
        }
        
        if isGradientLayer {
            
            let pathFrame = newPath.boundingBox // newPath.bounds
            let endBounds = CGRect(origin: CGPoint.zero, size: pathFrame.size)
            
            let xPosition = pathFrame.origin.x + pathFrame.width / 2
            let yPosition = pathFrame.origin.y + pathFrame.height / 2
            let endPosition = CGPoint(x: xPosition, y: yPosition)
            
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            gradientLayer?.position = endPosition
            gradientLayer?.bounds = endBounds
            CATransaction.commit()
            
        }else {
            let shapeLayer = gradientLayer as! CAShapeLayer
            shapeLayer.path = newPath//.cgPath
        }
    }
    
    public static func performGradientLayerPathAnimation(targetLayer:CAShapeLayer,newPath:CGMutablePath,duration:TimeInterval) {
        
        let gradientLayer = getGradientLayerForAnimation(container: targetLayer)
        
        if gradientLayer == nil {
//            Log.info("Gradient layer not found for " + String(describing: targetLayer.chartEntry))
            return
        }
        
        //Need to clear the existing color during magnifying operation
        targetLayer.fillColor = NSUIColor.clear.cgColor
        
        var isGradientLayer = true
        
        if (gradientLayer?.isKind(of: CAShapeLayer.self))!{
            isGradientLayer = false
        }
        
        if isGradientLayer {
            addFrameAnimation(gradientLayer: gradientLayer as! BaseGradientLayer, newPath: newPath, duration: duration)
        }else {
            
            let pathFrame = newPath.boundingBox// newPath.bounds
            
            guard let actualGradientLayer = (getGradientLayer(container: targetLayer))
            else { return }
            
            addFrameAnimation(gradientLayer: actualGradientLayer, newPath: newPath, duration: duration)
            
            let shapeLayer = gradientLayer as! CAShapeLayer
            
            let endPosition = CGPoint(x: -pathFrame.origin.x, y: -pathFrame.origin.y)
            
            if duration > 0
            {
                CATransaction.begin()
                
                let anim = CABasicAnimation(keyPath: "path")
                anim.fromValue = shapeLayer.path
                anim.toValue = newPath//.cgPath
                anim.duration = duration
                anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
                shapeLayer.add(anim, forKey: "path")
                CATransaction.commit()
                
                CATransaction.begin()
                let positionAnimation = CABasicAnimation(keyPath: "position")
                positionAnimation.fromValue = shapeLayer.position
                positionAnimation.toValue = endPosition
                positionAnimation.duration = duration
                positionAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
                shapeLayer.add(positionAnimation, forKey: "position")
                CATransaction.commit()
            }
            
            shapeLayer.path = newPath//.cgPath
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            shapeLayer.position = endPosition
            CATransaction.commit()
        }
    }
    
    fileprivate static func addFrameAnimation(gradientLayer:BaseGradientLayer,newPath:CGMutablePath,duration:TimeInterval) {
      
        let pathFrame = newPath.boundingBox // newPath.bounds
        let endBounds = CGRect(origin: CGPoint.zero, size: pathFrame.size)
        
        let xPosition = pathFrame.origin.x + pathFrame.width / 2
        let yPosition = pathFrame.origin.y + pathFrame.height / 2
        let endPosition = CGPoint(x: xPosition, y: yPosition)
        
        let gradientFrame = gradientLayer.frame
        let startPosition = CGPoint(x: gradientFrame.width / 2 + gradientFrame.origin.x , y: gradientFrame.height / 2 + gradientFrame.origin.y)
        let startBounds = gradientLayer.bounds
        
        if duration > 0
        {
            CATransaction.begin()
            let boundAnimation = CABasicAnimation(keyPath: "bounds")
            boundAnimation.fromValue = startBounds
            boundAnimation.toValue = endBounds
            
            boundAnimation.duration = duration
            boundAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            gradientLayer.add(boundAnimation, forKey: "bounds")
            CATransaction.commit()
            
            CATransaction.begin()
            let positionAnimation = CABasicAnimation(keyPath: "position")
            positionAnimation.fromValue = startPosition
            positionAnimation.toValue = endPosition
            
            positionAnimation.duration = duration
            positionAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            gradientLayer.add(positionAnimation, forKey: "position")
            CATransaction.commit()
            
        }
        
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientLayer.position = endPosition
        gradientLayer.bounds = endBounds
        CATransaction.commit()
        
    }
}
