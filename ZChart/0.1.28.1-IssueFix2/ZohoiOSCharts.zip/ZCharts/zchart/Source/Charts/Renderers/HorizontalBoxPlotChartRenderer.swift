//
//  HorizontalBoxPlotChartRenderer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 10/08/22.
//
/*
import Foundation

class HorizontalBoxPlotChartRenderer: HorizontalBarChartRenderer {
    
    override open func drawExtras(context: CGContext) {
        
        guard
            let chart = chart,
            let data = chart.data,
            let boxPlotPlotOption = chart.getPlotOptions(type: .BoxPlot) as? BoxPlotPlotOptions,
            let animator = animator
            else { return }
        
        context.saveGState()
        
        let trans = chart.getTransformer(axisIndex: data.dataSets[0].axisIndex)
        
        for dataSet in data.dataSets {
            
            if !dataSet.isVisible || !(dataSet.plotType == .BoxPlot) {
                continue
            }
            
            for entryIndex in 0..<dataSet.entryCount {
                
                guard let entry = dataSet.entryForIndex(entryIndex) else {
                    continue
                }
                
                if entry.x.isNaN {
                    continue
                }
                
                let y = entry.y.isNaN ? 0 : entry.y
                
                let y0 = entry.y0.isNaN ? 0 : entry.y0
                
                let firstQuartile = min(y,y0)

                let thirdQuartile = max(y,y0)
                
                var barWidth = boxPlotPlotOption.barWidthPixel
                
                if let yAxis = chart.getYAxis(atIndex: dataSet.axisIndex) {
                    barWidth = CommonHelperFunctions.getOnePointHeight(chart: chart, axis: yAxis) * boxPlotPlotOption.barWidth
                }
                
                if let valArr = entry.plotData as? [Double] {
                    
                    let minWhiskers = valArr[safe:boxPlotPlotOption.minWhiskersIndex]
                    
                    let maxWhiskers = valArr[safe: boxPlotPlotOption.maxWhiskersIndex]
                    
                    let medianVal = valArr[safe: boxPlotPlotOption.medianIndex]
                    
                    if medianVal != nil && boxPlotPlotOption.medianEnabled {
                        
                        let path = CGMutablePath() //UIBezierPath()
                        
                        let layer = MedianLayer(chartEntry: entry)
                        
                        layer.plotConfiguration(boxPlotPlotOption: boxPlotPlotOption)
                        
                        layer.opacity = Float(animator.phaseX)
                        
                        if chart.customAnimationInProgress {
                            layer.opacity = 0.0
                        }
                        
                        let medianLineWidthHalf = barWidth / 2.0
                        
                        var medianPoint = CGPoint(x: medianVal!, y: entry.x)
                        
                        trans.pointValueToPixel(&medianPoint)
                        
                        if barDeleted && entry.filterChanged != nil && (entry.filterChanged as? [CGRect]) != nil {
                            if let point = (entry.filterChanged as! [CGRect])[safe:2]?.origin {
                                medianPoint = point
                            }
                        }
                        
                        path.move(to: CGPoint(x: medianPoint.x, y: medianPoint.y - medianLineWidthHalf))
                        
                        path.addLine(to: CGPoint(x: medianPoint.x, y: medianPoint.y + medianLineWidthHalf))
                        
                        layer.path = path//.cgPath
                        
                        if customOpacity {
                            layer.opacity = entry.opacityChanged
                        }
                        
                        chart.plotView?.nsuiLayer?.addSublayer(layer)
                        
                    }
                    
                    if boxPlotPlotOption.whiskersEnabled {
                        
                        let path = CGMutablePath() //UIBezierPath()
                        
                        let layer = WhiskersLayer(chartEntry: entry)
                        
                        layer.plotConfiguration(boxPlotPlotOption: boxPlotPlotOption)
                        
                        layer.opacity = Float(animator.phaseX)
                        
                        if chart.customAnimationInProgress {
                            layer.opacity = 0.0
                        }
                    
                        var firstQuartilePoint = CGPoint(x: firstQuartile, y: entry.x)
                    
                        var thirdQuartilePoint = CGPoint(x: thirdQuartile, y: entry.x)
                        
                        trans.pointValueToPixel(&firstQuartilePoint)

                        trans.pointValueToPixel(&thirdQuartilePoint)
                        
                        
                        if barDeleted {
                            if entry.sizeChanged != nil && entry.centerChanged != nil {
                                firstQuartilePoint.y = entry.centerChanged!.y + (entry.sizeChanged!.height / 2.0)
                                thirdQuartilePoint.y = entry.centerChanged!.y + (entry.sizeChanged!.height / 2.0)
                                
                                let firstQuartileXPixelPoint = entry.centerChanged!.x
                                
                                let thirdQuartileXPixelPoint = entry.centerChanged!.x + entry.sizeChanged!.width
                                
                                firstQuartilePoint.x = firstQuartileXPixelPoint

                                thirdQuartilePoint.x = thirdQuartileXPixelPoint
                            }
                        }
                    
                        let whiskersWidthHalf = (barWidth * boxPlotPlotOption.whiskersBandWidth) / 2.0
                        
                        if boxPlotPlotOption.whiskersOn == .overLay {
                            
                            if minWhiskers != nil && maxWhiskers != nil {
                                path.move(to: firstQuartilePoint)
                                path.addLine(to: thirdQuartilePoint)
                            }
                            else {
                                continue
                            }
                        }
                        
                        if minWhiskers != nil {

                            var toPoint = CGPoint(x: minWhiskers!, y: entry.x)

                            trans.pointValueToPixel(&toPoint)
                            
                            if barDeleted && entry.filterChanged != nil && (entry.filterChanged as? [CGRect]) != nil  {
                                if let point = (entry.filterChanged as! [CGRect])[safe:0]?.origin {
                                    toPoint = point
                                }
                            }

                            path.move(to: firstQuartilePoint)
                            path.addLine(to: toPoint)
                            
                            path.move(to: CGPoint(x: toPoint.x, y: toPoint.y - whiskersWidthHalf))
                            path.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y + whiskersWidthHalf))
                        }

                        if maxWhiskers != nil {

                            var toPoint = CGPoint( x: maxWhiskers!, y: entry.x)

                            trans.pointValueToPixel(&toPoint)
                            
                            if barDeleted && entry.filterChanged != nil && (entry.filterChanged as? [CGRect]) != nil {
                                if let point = (entry.filterChanged as! [CGRect])[safe:1]?.origin {
                                    toPoint = point
                                }
                            }

                            path.move(to: thirdQuartilePoint)
                            path.addLine(to: toPoint)

                            path.move(to: CGPoint(x: toPoint.x, y: toPoint.y - whiskersWidthHalf))
                            path.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y + whiskersWidthHalf))
                        }
                        
                        layer.path = path//.cgPath
                        
                        if customOpacity {
                            layer.opacity = entry.opacityChanged
                        }
                        
                        chart.plotView?.nsuiLayer?.addSublayer(layer)
                    }
                }
                
            }
            
        }
        
        context.restoreGState()
    }
    
}
*/
