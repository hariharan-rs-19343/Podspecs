//
//  GeoMapRenderer.swift
//  zchart
//
//  Created by Aravinth T on 26/11/21.
//

import Foundation

#if !os(OSX)
    import UIKit
#endif


open class GeoMapRenderer: DataRenderer
{
//    override open func drawData(context: CGContext) {
//        drawRenderer(context: context)
//    }
    
    open override func drawData(context: CGContext)
    {
        guard
            let chartView = chart,
            let chartData = chartView.data,
            let processor = chartView.getProcessor(type: .GeoHeatMap) as? GeoMapPreprocessor,
            let plotOptions = chartView.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
            else { return }
        
        GeoMapLayer.removeAllGeoMapLayer(chart: chartView)
        
//        drawBackgroundMap()
        
        var keys:Set<String> = []
        for key in processor.featureKeys {
            keys.insert(key)
        }
        
        for i in 0 ..< chartData.dataSetCount
        {
            guard let set = chartData.getDataSetByIndex(i) as? ChartDataSet else { continue }
            
            if set.isVisible
            {
                drawDataSet(context: context, dataSet: set, index: i, keys: &keys)
            }
        }
        
        for key in keys
        {
            if let svgPath =  processor.featurePath[key]
            {
                if let path = GeoMapPreprocessor.getCGPath(svgPathObj: svgPath, transformer: chartView.plotTransformer) {
                    let layer = GeoMapLayer(chartView: chartView, chartEntry: GeoMapRenderer.dummyEntry, dataSet: GeoMapRenderer.dummyDataSet, path: path)
                    
                    layer.fillColor = plotOptions.fillColor.cgColor
                    layer.strokeColor = plotOptions.strokeColor.cgColor
                    layer.lineWidth = plotOptions.strokeWidth
                }else
                {
                    Log.error("Ignoring the map renderer \(key)")
                }
            }
        }
    }
    
    open func drawDataSet(context: CGContext, dataSet: IChartDataSet, index: Int, keys:inout Set<String>)
    {
        guard
            let chartView = chart,
            let plotOptions = chartView.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions,
            let processor = chartView.getProcessor(type: .GeoHeatMap) as? GeoMapPreprocessor,
            let vpHanlder = chartView.viewPortHandler
            else { return }
               
        
        for i in stride(from: 0, to: dataSet.entryCount, by: 1)
        {
            guard let entry = dataSet.entryForIndex(i),
                    entry.enabled else {
                continue
            }
            
            guard let key = GeoMapPreprocessor.getKey(entry: entry, plotOptions: plotOptions) else
            {
                continue
            }
            
            /*if let pathString =  processor.featurePathStringMap[key]
            {
                if let path = GeoMapPreprocessor.parseSVGPath(pathString: pathString,transformer: chartView.plotTransformer) {
                    let _ = GeoMapLayer(chartView: chartView, chartEntry: entry, dataSet: dataSet, path: path)
                }else
                {
                    Log.error("Ignoring the map renderer \(key)")
                }
            }*/
            
            keys.remove(key)
            
            if let svgPath =  processor.featurePath[key]
            {
                if let path = GeoMapPreprocessor.getCGPath(svgPathObj: svgPath, transformer: chartView.plotTransformer) {
                    let _ = GeoMapLayer(chartView: chartView, chartEntry: entry, dataSet: dataSet, path: path)
                }else
                {
                    Log.error("Ignoring the map renderer \(key)")
                }
            }
            
        }

    }
    
    
    
    static let dummyDataSet = ChartDataSet()
    
    static let dummyEntry = ChartDataEntry()
    
//    open func drawRenderer(context: CGContext)
//    {
//        guard
//            let chart = chart,
//            let processor = chart.getProcessor(type: .GeoHeatMap) as? GeoMapPreprocessor,
//            let chartData = chart.data
//            else { return }
//
//     /*   let backgroundPathString = processor.backgroundPathString
//
//
//        let path = GeoMapPreprocessor.parseSVGPath(pathString: backgroundPathString!)
//
//        let dataset = chartData.dataSets[0]
//
//        let e = dataset.entryForIndex(0)!
//
//        let layer = GeoMapLayer(chartView: chart, chartEntry: e, dataSet: dataset, path: path)*/
//
//
//
//
//          /*  var index = 0
//
//            let finalArray = processor.dataValues
//
//            for arrayVal in finalArray {
//                index = index + 1
//
//                let object = arrayVal as! NSDictionary
//                let xValue = object["x"] as! CGFloat
//                let yValue = object["y"] as! CGFloat
//                let radius = object["radius"] as! CGFloat
//                let name = object["name"] as! String
//                let setIndex = (object["setIndex"] as! Int)
//                let pathIndex = (object["pathIndex"] as! [Int])
//                let set = chartData.dataSets[setIndex]
//
//                var rect = CGRect(x: xValue-radius, y: yValue-radius, width: radius * 2 , height: radius * 2)
//                chart.plotTransformer.rectValueToPixel(&rect)
//
//                if rect.width.isNaN || rect.height.isNaN || rect.minX.isNaN || rect.minY.isNaN
//                {
//                    rect = CGRect()
//                }
//                guard let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
//                    else { continue }
//
//                let isRoot = name == "root"
//
//                let newShapeProperties = ShapeProperties()
//
//                newShapeProperties.holeColor = isRoot ? NSUIColor.gray.withAlphaComponent(0.2) : dataOption.shapeProperties.holeColor
//                newShapeProperties.shapeType = isRoot ? LineShapes.circle : dataOption.shapeProperties.shapeType
//                newShapeProperties.lineWidth = isRoot ? 1 : dataOption.shapeProperties.lineWidth
//                newShapeProperties.shapeSize = rect.width - (newShapeProperties.lineWidth)/2
//                newShapeProperties.strokeColor = isRoot ? NSUIColor.black : dataOption.shapeProperties.strokeColor
//
//                let center = CGPoint(x: rect.midX, y: rect.midY)
//
//                let bubbleEntry = (name == "root") ? ChartDataEntry(xString: name, y: 0, data: nil) : set.entryForPath(pathIndex)
//
//                let _ = BubbleLayer(chartView: chart, chartEntry: bubbleEntry!, dataSet: set, point: center, shapeProperty: newShapeProperties)
//
//            }*/
//    }
    
    fileprivate func drawBackgroundMap() {
        
        guard
            let chart = chart,
            let processor = chart.getProcessor(type: .GeoHeatMap) as? GeoMapPreprocessor,
            let plotOptions = chart.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions,
            let backgroundPath = processor.backgroundPath
            else { return }
        
        let backgroundPathString = processor.backgroundPathString
        
                
        
        
//        if let path = GeoMapPreprocessor.parseSVGPath(pathString: backgroundPathString!,transformer: chart.plotTransformer) {
        if let path = GeoMapPreprocessor.getCGPath(svgPathObj: backgroundPath, transformer: chart.plotTransformer) {
                
            let layer = GeoMapLayer(chartView: chart, chartEntry: GeoMapRenderer.dummyEntry , dataSet: GeoMapRenderer.dummyDataSet, path: path)
            
            layer.fillColor = plotOptions.fillColor.cgColor
            layer.strokeColor = plotOptions.strokeColor.cgColor
            layer.lineWidth = plotOptions.strokeWidth
        
        } else {
            Log.error("Ignoring background map rendering ")
        }
                
        
        
    }
    
    open override func drawValues(context: CGContext) {
        return
    }
    
    open override func drawExtras(context: CGContext) {
        return
    }
}
