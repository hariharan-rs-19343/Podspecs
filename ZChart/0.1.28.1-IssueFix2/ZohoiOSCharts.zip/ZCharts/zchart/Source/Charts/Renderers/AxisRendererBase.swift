//
//  AxisRendererBase.swift
//  Charts
//
//  Copyright 2015 Daniel Cohen Gindi & Philipp Jahoda
//  A port of MPAndroidChart for iOS
//  Licensed under Apache License 2.0
//
//  https://github.com/danielgindi/Charts
//

import Foundation
import CoreGraphics

@objc(ChartAxisRendererBase)
open class AxisRendererBase: Renderer
{
    
    // MARK: - Properties
    
    /// base axis this axis renderer works with
    open var axis: AxisBase?
    
    open var tickLabels:[TickLabel] = []
    
    open var tickPositions:[TickModel] = []
    
    var longestTickLabel = TickLabel()
    
    /// transformer to transform values to screen pixels and return
    open var transformer: Transformer?
    
    weak var chartViewBase:ChartViewBase? = nil
    
    open var gridClippingRect: CGRect
    {
        let contentRect = viewPortHandler?.contentRect ?? CGRect.zero
        return contentRect
    }
    
    // MARK: - Initialize
    
    public override init()
    {
        super.init()
    }
    
    public init(viewPortHandler: ViewPortHandler?, transformer: Transformer?, axis: AxisBase?,chartViewBase: ChartViewBase?)
    {
        super.init(viewPortHandler: viewPortHandler)
        
        self.transformer = transformer
        self.axis = axis
        self.chartViewBase = chartViewBase
    }
    
    // MARK: - Support Methods
    open func getLongestLabelOfAllData(axis:AxisBase) -> String
    {
        var longestLabel = ""
        
        guard let dataSets = self.chartViewBase?.data?.dataSets,
            let axis = self.axis
            else { return longestLabel }
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont]
        
        for set in dataSets where set.isVisible
        {
            if axis.isKind(of: YAxis.self) && (set.axisIndex != (axis as! YAxis).axisIndex)
            {
                continue
            }
            
            for i in 0 ..< set.entryCount
            {
                guard let e = set.entryForIndex(i)
                else { continue }
                
                let entryValue = axis.isKind(of: YAxis.self) ? (e.y) : (e.x)
                
                if entryValue.isNaN
                {
                    continue
                }
                
                var text = ""//axis.valueFormatter?.stringForValue(entryValue, axis: axis) ?? ""
                
                if axis.scaleType == .Time
                {
                    let interValType = (axis.scaleTypeProtocol as! TimeScale).currentType
                    text = (axis.valueFormatter?.stringForValue?(entryValue, axis: axis, intervalType: interValType)) ?? ""
                }else
                {
                    text = axis.valueFormatter?.stringForValue(entryValue, axis: axis) ?? ""
                }
                
                if longestLabel.size(withAttributes: labelAttrs).width < text.size(withAttributes: labelAttrs).width
                {
                    longestLabel = text
                }
            }
        }
        
        return longestLabel
    }
    
    open func getLongestLabelfromEntries(axis:AxisBase) -> String
    {
        var longestLabel = ""
        
        guard let axis = self.axis
        else { return longestLabel }
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont]
        
        let from = axis.isDrawBottomYLabelEntryEnabled ? 0 : 1
        let to = axis.isDrawTopYLabelEntryEnabled ? axis.entryCount : (axis.entryCount - 1)
        
        for i in stride(from: from, to: to, by: 1)
        {
            let text = axis.getFormattedLabel(i)
            
            if longestLabel.size(withAttributes: labelAttrs).width < text.size(withAttributes: labelAttrs).width
            {
                longestLabel = text
            }
        }
        return longestLabel
    }
    
    open func updateLongestLabel()
    {
        return
    }
    
    open func transformedPositions() -> [CGPoint]
    {
        guard
            let axis = self.axis ,
            let transformer = self.transformer
            else { return [CGPoint]() }
        
        var positions = [CGPoint]()
        positions.reserveCapacity(axis.entryCount)
        
        let entries = axis.entries
        
        for i in stride(from: 0, to: axis.entryCount, by: 1)
        {
            positions.append(CGPoint(x: entries[i], y: entries[i]))
        }

        transformer.pointValuesToPixel(&positions)
        
        return positions
    }
    
    /// Draws the grid lines for the position.
    open func drawGridLine(context: CGContext, position:CGPoint)
    {
        fatalError("drawGridLine() cannot be called on AxisRendererBase")
    }
    
    // MARK: - Render Code
    /// Draws the axis labels on the specified context
    open func renderAxisLabels(context: CGContext)
    {
        fatalError("renderAxisLabels() cannot be called on AxisRendererBase")
    }
    
    /// Draws the grid lines belonging to the axis.
    open func renderGridLines(context: CGContext)
    {
        guard let
            axis = self.axis
            else { return }
        
        if !axis.isEnabled || !axis.isDrawGridLinesEnabled || !axis.visible
        {
            return
        }
        
        context.saveGState()
        defer { context.restoreGState() }
        context.clip(to: self.gridClippingRect)
        
        context.setShouldAntialias(axis.gridAntialiasEnabled)
        context.setLineWidth(axis.gridLineWidth)
        context.setLineCap(axis.gridLineCap)
        
        if axis.gridLineDashLengths != nil
        {
            context.setLineDash(phase: axis.gridLineDashPhase, lengths: axis.gridLineDashLengths)
            
        }
        else
        {
            context.setLineDash(phase: 0.0, lengths: [])
        }
        
        if self.isKind(of: AxisPolarRadiusRenderer.self) || self.isKind(of: AxisPolarAngleRenderer.self) {
            let positions = transformedPositions()
            for i in 0..<positions.count
            {
                context.setStrokeColor(axis.gridColor.cgColor)
                drawGridLine(context: context, position: positions[i])
            }
        }
        else {
            // draw the grid
            for i in 0 ..< tickPositions.count
            {
                var strokeAlpha = axis.gridColor.cgColor.alpha * tickPositions[i].opacity
                if i == 0 || i == tickPositions.count - 1 {
                    let isRotated = chartViewBase?.isRotated ?? false
                    
                    if ((isRotated && axis.isKind(of: XAxis.self) || !isRotated && axis.isKind(of: YAxis.self)) && (tickPositions[i].point.y == viewPortHandler!.contentBottom || tickPositions[i].point.y == viewPortHandler!.contentTop)) || ((!isRotated && axis.isKind(of: XAxis.self) || isRotated && axis.isKind(of: YAxis.self)) && (tickPositions[i].point.x == viewPortHandler!.contentLeft || tickPositions[i].point.x == viewPortHandler!.contentRight)) {
                        strokeAlpha = 0.0
                    }
                }
                context.setStrokeColor(axis.gridColor.withAlphaComponent(strokeAlpha).cgColor)
                drawGridLine(context: context, position: tickPositions[i].point)
            }
        }
    }
    
    /// Draws the line that goes alongside the axis.
    open func renderAxisLine(context: CGContext)
    {
        fatalError("renderAxisLine() cannot be called on AxisRendererBase")
    }
    
    /// Draws the LimitLines associated with this axis to the screen.
    open func renderLimitLines(context: CGContext)
    {
        fatalError("renderLimitLines() cannot be called on AxisRendererBase")
    }
    
    /// Draws the BaseLines associated with this axis to the screen.
    open func renderBaseLine()
    {
        fatalError("renderBaseLine() cannot be called on AxisRendererBase")
    }
    
    // MARK: - Axis Computation
    
    /// Computes the axis values.
    /// - parameter min: the minimum value in the data object for this axis
    /// - parameter max: the maximum value in the data object for this axis
    open func computeAxis(min: Double, max: Double, inverted: Bool)
    {
        var min = min, max = max
        
        if let transformer = self.transformer
        {
            // calculate the starting and entry point of the y-labels (depending on zoom / contentrect bounds)
            if let viewPortHandler = viewPortHandler
            {
                if viewPortHandler.contentWidth > 10.0 && !viewPortHandler.isFullyZoomedOutY
                {
                    var p1 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop))
                    var p2 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentBottom))
                    
                    p1 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: (axis as? YAxis)?.axisIndex ?? 0, point: p1)
                    p2 = CommonHelperFunctions.convertValue(chart: chartViewBase!, axisIndex: (axis as? YAxis)?.axisIndex ?? 0, point: p2)
                    if !inverted
                    {
                        min = Double(p2.y)
                        max = Double(p1.y)
                    }
                    else
                    {
                        min = Double(p1.y)
                        max = Double(p2.y)
                    }
                }
            }
        }
        
        guard let axis = self.axis,
              let chart = self.chartViewBase
        else { return }
        
        axis.scaleTypeProtocol.computeAxisValues(min: min, max: max, axis: axis, chart: chart)
    }
    
    open func computeSize()
    {
        return
    }
    
    // Draw MultiLine Text with truncate
    open func drawLabelTruncated(
        context: CGContext,
        formattedLabel: String,
        x: CGFloat,
        y: CGFloat,
        attributes: [NSAttributedString.Key: NSObject],
        constrainedToSize: CGSize,
        anchor: CGPoint,
        angleRadians: CGFloat)
    {
        let rect = formattedLabel.boundingRect(with: constrainedToSize, options: .truncatesLastVisibleLine, attributes: attributes, context: nil)
        ChartUtils.drawMultilineText(context: context, text: formattedLabel, knownTextSize: rect.size, point: CGPoint(x: x, y: y), attributes: attributes, constrainedToSize: constrainedToSize, anchor: anchor, angleRadians: angleRadians)
        
    }
    
    #if os(iOS) || os(tvOS)
    //Draw Horizontal text
    open func drawLabelHorizontal(
        context: CGContext,
        formattedLabel: String,
        x: CGFloat,
        y: CGFloat,
        attributes: [NSAttributedString.Key: NSObject],
        constrainedToSize: CGSize,
        anchor: CGPoint,
        angleRadians: CGFloat,options: NSStringDrawingOptions)
    {
        let rect = formattedLabel.boundingRect(with: constrainedToSize, options: options, attributes: attributes, context: nil)
        
        ChartUtils.horizontalDrawText(context: context, text: formattedLabel, knownTextSize: rect.size, point: CGPoint(x: x, y: y), attributes: attributes, constrainedToSize: constrainedToSize, anchor: anchor, angleRadians: angleRadians)
        
    }
    #else
    //Draw Horizontal text
    open func drawLabelHorizontal(
        context: CGContext,
        formattedLabel: String,
        x: CGFloat,
        y: CGFloat,
        attributes: [NSAttributedString.Key: NSObject],
        constrainedToSize: CGSize,
        anchor: CGPoint,
        angleRadians: CGFloat,options: NSString.DrawingOptions)
    {
        let rect = formattedLabel.boundingRect(with: constrainedToSize, options: options, attributes: attributes, context: nil)
        
        ChartUtils.horizontalDrawText(context: context, text: formattedLabel, knownTextSize: rect.size, point: CGPoint(x: x, y: y), attributes: attributes, constrainedToSize: constrainedToSize, anchor: anchor, angleRadians: angleRadians)
        
    }
    #endif
    
    /// Sets up the axis values. Computes the desired number of labels between the two given extremes.
    open func computeAxisValues(min: Double, max: Double)
    {
        guard let axis = self.axis else { return }
        
        let yMin = min
        let yMax = max
        
        let labelCount = axis.labelCount
        let range = abs(yMax - yMin)
        
        if labelCount == 0 || range <= 0 || range.isInfinite
        {
            axis.entries = [Double]()
            axis.centeredEntries = [Double]()
            return
        }
        
        // Find out how much spacing (in y value space) between axis values
        let rawInterval = range / Double(labelCount)
        var interval = ChartUtils.roundToNextSignificant(number: Double(rawInterval))
        
        // If granularity is enabled, then do not allow the interval to go below specified granularity.
        // This is used to avoid repeated values when rounding values for display.
        if axis.granularityEnabled
        {
            interval = interval < axis.granularity ? axis.granularity : interval
        }
        
        // Normalize interval
        let intervalMagnitude = ChartUtils.roundToNextSignificant(number: pow(10.0, Double(ChartUtils.doubleToIntSafeCast(value:log10(interval)))))
        let intervalSigDigit =  ChartUtils.doubleToIntSafeCast(value:interval / intervalMagnitude)
        if intervalSigDigit > 5
        {
            // Use one order of magnitude higher, to avoid intervals like 0.9 or 90
            interval = floor(10.0 * Double(intervalMagnitude))
        }
        
        var n = axis.centerAxisLabelsEnabled ? 1 : 0
        
        // force label count
        if axis.isForceLabelsEnabled
        {
            interval = Double(range) / Double(labelCount - 1)
            
            // Ensure stops contains at least n elements.
            axis.entries.removeAll(keepingCapacity: true)
            axis.entries.reserveCapacity(labelCount)
            
            var v = yMin
            
            for _ in 0 ..< labelCount
            {
                axis.entries.append(v)
                v += interval
            }
            
            n = labelCount
        }
        else
        {
            // no forced count
        
            var first = interval == 0.0 ? 0.0 : ceil(yMin / interval) * interval
            
            if axis.centerAxisLabelsEnabled
            {
                first -= interval
            }
            
            let last = interval == 0.0 ? 0.0 : ChartUtils.nextUp(floor(yMax / interval) * interval)
            
            if interval != 0.0 && last != first
            {
                for _ in stride(from: first, through: last, by: interval)
                {
                    n += 1
                }
            }
            
            // Ensure stops contains at least n elements.
            axis.entries.removeAll(keepingCapacity: true)
            axis.entries.reserveCapacity(labelCount)
            
            var f = first
            var i = 0
            while i < n
            {
                if f == 0.0
                {
                    // Fix for IEEE negative zero case (Where value == -0.0, and 0.0 == -0.0)
                    f = 0.0
                }
                
                axis.entries.append(Double(f))
                
                f += interval
                i += 1
            }
        }
        
        // set decimals
        if interval < 1
        {
            axis.decimals =  ChartUtils.doubleToIntSafeCast(value:ceil(-log10(interval)))
        }
        else
        {
            axis.decimals = 0
        }
        
        if axis.centerAxisLabelsEnabled
        {
            axis.centeredEntries.reserveCapacity(n)
            axis.centeredEntries.removeAll()
            
            let offset: Double = interval / 2.0
            
            for i in 0 ..< n
            {
                axis.centeredEntries.append(axis.entries[i] + offset)
            }
        }
    }
    
    func getParaStyle() -> NSMutableParagraphStyle {
        #if os(OSX)
        let paraStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        #else
        let paraStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        #endif
        paraStyle.alignment = .center
        return paraStyle
    }
    
    open func drawLabel(
        context: CGContext,
        formattedLabel: String,
        x: CGFloat,
        y: CGFloat,
        attributes: [NSAttributedString.Key: NSObject],
        constrainedToSize: CGSize,
        anchor: CGPoint,
        angleRadians: CGFloat)
    {
        guard
            let axis = axis else {
                return
            }
        
        if axis.tickLabelMode == .wordwrap{
            drawLabelHorizontal(context: context,
                      formattedLabel: formattedLabel,
                      x: x,
                      y: y,
                      attributes: attributes,
                      constrainedToSize: constrainedToSize,
                      anchor: anchor,
                      angleRadians: angleRadians,
                      options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine])
        }
        else{
            ChartUtils.drawMultilineText(
                context: context,
                text: formattedLabel,
                point: CGPoint(x: x, y: y),
                attributes: attributes,
                constrainedToSize: constrainedToSize,
                anchor: anchor,
                angleRadians: angleRadians)
        }
    }
    
    // MARK: - limitline
    
    func drawLimitLineLabel(limitLine: ChartLimitLine, rect: CGRect) -> CATextLayer {
        return ChartUtils.drawTextLayer(text: limitLine.label, rect: rect, attributes: [NSAttributedString.Key.font: limitLine.valueFont, NSAttributedString.Key.foregroundColor: limitLine.valueTextColor], rotationAngle: limitLine.rotationAngle, anchorPoint: .zero)
    }
    
    func renderLimitLineLabel(limitLine: ChartLimitLine, limitLineLayer: LimitLineLayer, position: CGPoint, limitLineType: LimitLineType) {
        
        guard let viewPortHandler = chartViewBase?.viewPortHandler else {
            return
        }
        
        var point: CGPoint?
        let labelSize: CGSize = limitLine.label.size(withAttributes: [NSAttributedString.Key.font: limitLine.valueFont])
        var xOffset: CGFloat = limitLine.xOffset
        var yOffset: CGFloat = limitLine.yOffset
        
        if limitLineType == .vertical {
            
            xOffset = limitLine.lineWidth + limitLine.xOffset
            yOffset = 2.0 + limitLine.yOffset
            
             switch limitLine.labelPosition {
                case .rightTop: point = CGPoint(
                    x: position.x + xOffset,
                    y: viewPortHandler.contentTop + yOffset)
                case .rightBottom: point = CGPoint(
                    x: position.x + xOffset,
                    y: viewPortHandler.contentBottom - labelSize.height - yOffset)
                case .leftTop: point = CGPoint(
                    x: position.x - xOffset,
                    y: viewPortHandler.contentTop + yOffset)
                case .leftBottom: point = CGPoint(
                    x: position.x - xOffset,
                    y: viewPortHandler.contentBottom - labelSize.height - yOffset)
                case .centerTop: point = CGPoint(
                    x: position.x + xOffset,
                    y:  viewPortHandler.contentRect.midY + yOffset)
                case .centerBottom: point = CGPoint(
                    x: position.x - xOffset,
                    y: viewPortHandler.contentRect.midY + yOffset)
            }
        }
        else {
            
            xOffset = 4.0 + limitLine.xOffset + labelSize.width
            yOffset = limitLine.lineWidth + labelSize.height + limitLine.yOffset
            
            switch limitLine.labelPosition {
                case .rightTop: point = CGPoint(
                    x: viewPortHandler.contentRight - xOffset,
                    y: position.y - yOffset)
                case .rightBottom: point = CGPoint(
                    x: viewPortHandler.contentRight - xOffset,
                    y: position.y + yOffset - labelSize.height)
                case .leftTop: point = CGPoint(
                    x: viewPortHandler.contentLeft + xOffset,
                    y: position.y - yOffset)
                case .leftBottom: point = CGPoint(
                    x: viewPortHandler.contentLeft + xOffset,
                    y: position.y + yOffset - labelSize.height)
                case .centerTop: point = CGPoint(
                    x: viewPortHandler.contentRect.midX + limitLine.xOffset - labelSize.width / 2.0,
                    y: position.y - yOffset)
                case .centerBottom: point = CGPoint(
                    x: viewPortHandler.contentRect.midX + limitLine.xOffset - labelSize.width / 2.0,
                    y: position.y + yOffset - labelSize.height)
            }
            
        }
        
        if var point = point {
            if limitLine.rotationAngle != 0.0 {
                point = ChartUtils.translatedPointFor(angleRadians: limitLine.rotationAngle * ChartUtils.Math.FDEG2RAD , point: point, knownTextSize: labelSize, anchor: .zero)
            }
            limitLineLayer.addSublayer(drawLimitLineLabel(limitLine: limitLine, rect: CGRect(origin: point, size: labelSize)))
        }
    }
}
