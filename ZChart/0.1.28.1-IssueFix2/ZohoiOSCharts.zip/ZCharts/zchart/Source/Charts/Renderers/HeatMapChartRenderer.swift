//
//  HeatMapChartRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 29/05/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

#if !os(OSX)
import UIKit
#endif

open class HeatMapChartRenderer: BarLineScatterCandleBubbleRenderer
{
    open class Buffer
    {
        open var rects = [CGRect]()
    }
    
    // [CGRect] per dataset
    open var _buffers = [Buffer]()
    
//    open weak var dataProvider: BarLineScatterCandleBubbleChartDataProvider?
    
    open override func initBuffers()
    {
        if let chartData = chart?.data
        {
            // Matche buffers count to dataset count
            if _buffers.count != chartData.dataSetCount
            {
                while _buffers.count < chartData.dataSetCount
                {
                    _buffers.append(Buffer())
                }
                while _buffers.count > chartData.dataSetCount
                {
                    _buffers.removeLast()
                }
            }
            
            for i in stride(from: 0, to: chartData.dataSetCount, by: 1)
            {
                let set = chartData.dataSets[i]
                let size = set.entryCount
                if _buffers[i].rects.count != size
                {
                    _buffers[i].rects = [CGRect](repeating: CGRect(), count: size)
                }
            }
        }
        else
        {
            _buffers.removeAll()
        }
    }
    
    open func prepareBuffer(dataSet: IChartDataSet, index: Int)
    {
        guard
            let dataProvider = chart,
            let chartData = dataProvider.data,
            let animator = animator,
            let heatMap = self.chart
            else { return }
        
        var rectWidthHalf = chartData.rectWidth / 2.0
        var rectHeightHalf = chartData.rectHeight / 2.0
        
        let sizeWidthInterpolator = Interpolator.interpolate(a: chartData.rectWidth*0.2, b: chartData.rectWidth)
        let sizeHeightInterpolator = Interpolator.interpolate(a: chartData.rectHeight*0.2, b: chartData.rectHeight)
        
        let range = chartData.maxSize - chartData.minSize //chartData.maxSize
        
        let buffer = _buffers[index]
        var bufferIndex = 0
        
        let phaseY = animator.phaseY
        var barRect = CGRect()
        var x: Double
        var y: Double
        
        var start = 0
        var end = min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)
        var increment = 1
        
        if (heatMap.xAxis.inverted) {
            start = dataSet.entryCount - 1
            end = dataSet.entryCount - (min(Int(ceil(Double(dataSet.entryCount) * animator.phaseX)), dataSet.entryCount)) - 1
            increment = -1
        }
        
        for i in stride(from: start, to: end, by: increment)
        {
            guard let e = dataSet.entryForIndex(i) else { continue }
            
            x = e.x
            y = e.y
            
            var sizeValuePercent = e.size == nil ? 1.0 : e.size!.isNaN ? 0 : Interpolator.precentage(a: chartData.minSize, b: chartData.maxSize, value: e.size!) //Double((e.size/range))
            
            if sizeValuePercent.isNaN
            {
                sizeValuePercent = 1
            }
            
            rectWidthHalf = (sizeWidthInterpolator(sizeValuePercent))/2
            rectHeightHalf = (sizeHeightInterpolator(sizeValuePercent))/2
            
            let left = CGFloat(x - rectWidthHalf)
            let right = CGFloat(x + rectWidthHalf)
            var top = CGFloat(y + rectHeightHalf)
            let bottom = CGFloat(y - rectHeightHalf)
            
            
            // multiply the height of the rect with the phase
            let topInterPolator = Interpolator.interpolate(a: bottom, b: top)
            top = topInterPolator(CGFloat(phaseY))
            
            barRect.origin.x = left
            barRect.size.width = right - left
            barRect.origin.y = top
            barRect.size.height = bottom - top
            
            buffer.rects[bufferIndex] = barRect
            bufferIndex += 1
            
        }
    }
    
    open override func drawData(context: CGContext)
    {
        guard
            let chartView = chart,
            let chartData = chartView.data
            else { return }
        
        MapLayer.removeAllMapLayer(chart: chartView)
        
        for i in 0 ..< chartData.dataSetCount
        {
            guard let set = chartData.getDataSetByIndex(i) as? ChartDataSet else { continue }
            
            if set.isVisible
            {
                drawDataSet(context: context, dataSet: set, index: i)
            }
        }
    }
    
    open func drawDataSet(context: CGContext, dataSet: IChartDataSet, index: Int)
    {
        guard
            let chartView = chart
            else { return }
        
        let trans = chartView.getTransformer(axisIndex: dataSet.axisIndex)
        
        prepareBuffer(dataSet: dataSet, index: index)
        trans.rectValuesToPixel(&_buffers[index].rects)
        
        drawRenderer(context: context, dataSet: dataSet, index: index)
        
    }
    
    open func drawRenderer(context: CGContext, dataSet: IChartDataSet, index: Int)
    {
        guard
            let chart = chart,
            let viewPortHandler = chart.viewPortHandler
            else { return }
        
        _xBounds.set(chart: chart, dataSet: dataSet, animator: animator)
        
        context.saveGState()
        
        let buffer = _buffers[index]
        
        let isXReverse = (chart.xAxis.isInverted)
        
        for j in stride(from: 0, to: buffer.rects.count, by: 1)
        {
            var frameRect = buffer.rects[j]
            
            if let datasetOption = dataSet.dataSetOptions as? BarDataSetOptions {

                let borderWidthHalf = datasetOption.barBorderWidth / 2.0
                frameRect.size.width -= borderWidthHalf
                frameRect.size.height -= borderWidthHalf
            }
            
            var index = j
            
            if (isXReverse) {
                index = (buffer.rects.count - 1 - j )
            }
            
            guard let e = dataSet.entryForIndex(index) else { continue }
            
            /*************************** X NAN HANDLED ****************************/
            if (e.xString == nil && chart.xAxis.scaleType == .Ordinal) || e.x == Double.nan {
                continue
            }
            
            
            if (!viewPortHandler.isInBoundsLeft(ChartUtils.roundNumber(number: (frameRect.origin.x + frameRect.size.width))))
            {
                if (chart.xAxis.isInverted)
                {
                    continue//break
                }
                else
                {
                    continue
                }
            }
            
            if (!viewPortHandler.isInBoundsRight(ChartUtils.roundNumber(number:frameRect.origin.x)))
            {
                if (chart.xAxis.isInverted)
                {
                    break//continue
                }
                else
                {
                    break
                }
            }
            
            
            let mapLayer = MapLayer(chartView: chart, chartEntry: e, dataSet: dataSet, frameRect: frameRect)
            
            chart.plotView?.nsuiLayer?.addSublayer(mapLayer)
            
        }
       
        context.restoreGState()
    }
   
    open override func drawValues(context: CGContext)
    {
        guard
            let chart = chart,
            let viewPortHandler = self.viewPortHandler,
            let chartData = chart.data,
            let animator = animator,
            let plotOption = chart.getPlotOptions(type: .HeatMap) as? HeatMapPlotOptions
            else { return }
        
        MapLayer.removeAllValueLayer(chart: chart)
        
        // if values are allowed
        if isDrawingValuesAllowed(dataProvider: chart)
        {
            let dataSets = chartData.dataSets
    
            let xAxisInverted = (chart.xAxis.inverted)
            
            for dataSetIndex in 0 ..< chartData.dataSetCount
            {
                guard let dataSet = dataSets[dataSetIndex] as? ChartDataSet else { continue }
                
                if !shouldDrawValues(forDataSet: dataSet)
                {
                    continue
                }
              
                // calculate the correct offset depending on the draw position of the value
                let valueFont = dataSet.valueFont
                let valueTextHeight = valueFont.lineHeight
                
                let buffer = _buffers[dataSetIndex]
                
                guard let formatter = dataSet.valueFormatter else { continue }
                
                let iconsOffset = dataSet.iconsOffset
                
                var start = 0
                var end =  ChartUtils.doubleToIntSafeCast(value:ceil(Double(dataSet.entryCount) * animator.phaseX))
                var increment = 1
                
                if (xAxisInverted) {
                    start = dataSet.entryCount - 1
                    end = dataSet.entryCount - (Int(ceil(Double(dataSet.entryCount) * animator.phaseX))) - 1
                    increment = -1
                }
                
                for j in stride(from: start, to: end, by: increment)
                {
                    guard let e = dataSet.entryForIndex(j) else { continue }
                    
                    var bufferIndex = j
                    
                    if (xAxisInverted) {
                        bufferIndex = buffer.rects.count - 1 - j
                    }
                    
                    let rect = buffer.rects[bufferIndex]
                    
                    let x = rect.origin.x + rect.size.width / 2.0
                    
                    let y = rect.origin.y + rect.size.height / 2.0
                    
                    if x.isNaN || y.isNaN
                    {
                        continue
                    }
                    
                    if !viewPortHandler.isInBoundsRight(ChartUtils.roundNumber(number: x))
                    {
                        if xAxisInverted
                        {
                            break//continue
                        }
                        else
                        {
                            break
                        }
                    }
                    
                    if !viewPortHandler.isInBoundsY(ChartUtils.roundNumber(number: rect.origin.y)) || !viewPortHandler.isInBoundsLeft(ChartUtils.roundNumber(number: x))
                    {
                        if xAxisInverted
                        {
                            continue//break
                        }
                        else
                        {
                            continue
                        }
                    }
                    
                    if dataSet.isDrawValuesEnabled
                    {
                        
                        let value = formatter.stringForValue(
                            e.colorValue ?? 0.0,
                            entry: e,
                            dataSetIndex: dataSetIndex,
                            viewPortHandler: viewPortHandler)
                        
                        let labelAttribute = [NSAttributedString.Key.font: valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(j)]
                        
                        let valueSize = value.size(withAttributes: labelAttribute)
                        
                        let yPos = y - (valueTextHeight/2)
                        
                        let origin = CGPoint(x: x - valueSize.width / 2.0, y: yPos)
                        
                        let labelRect = CGRect(origin: origin, size: valueSize)

                        if chartData.dataLabelRenderingMode == .showAll || chartData.dataLabelRenderingMode == .adjust || HeatMapHelperFunctions.isDataLabelWithInRectBound(chart: chart, labelRect: labelRect, rectBound: rect.size) {
                            
                            var bound = rect.size
                            
                            if plotOption.dataLabelTruncateToOnePointWidth, let yaxis = chart.getYAxis(atIndex: dataSet.axisIndex) {
                                bound = CommonHelperFunctions.getOnePointSize(chart: chart, axis: yaxis)
                            }
                            
                            let constrainedWidth = HeatMapHelperFunctions.constrainedWidthForDataLabel(chart: chart, entry: e, labelRect: labelRect, rectBound: bound)
                                
                            drawValue(
                                context: context,
                                value: value,
                                xPos: x,
                                yPos: yPos,
                                font: valueFont,
                                align: .center,
                                color: dataSet.valueTextColorAt(j),
                                constrainedWidth: constrainedWidth,
                                entry: e)
                        }
                    }
                    
                    if let icon = e.icon, dataSet.isDrawIconsEnabled
                    {
                        var px = x
                        var py = y - (valueTextHeight/2)
                        
                        px += iconsOffset.x
                        py += iconsOffset.y
                        
                        ChartUtils.drawImage(
                            context: context,
                            image: icon,
                            x: px,
                            y: py,
                            size: icon.size)
                    }
                }
                
            }
        }
    }
    
    /// Draws a value at the specified x and y position.
    open func drawValue(context: CGContext, value: String, xPos: CGFloat, yPos: CGFloat, font: NSUIFont, align: NSTextAlignment, color: NSUIColor, constrainedWidth: CGFloat, entry: ChartDataEntry)
    {
        guard let chart = chart
            else { return }
        
        if !(chart.includeLayer)
        {
            ChartUtils.drawText(context: context, text: value, point: CGPoint(x: xPos, y: yPos), align: align, attributes: [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: color], constrainedWidth: constrainedWidth)
        }
        else
        {
            let layer = ChartUtils.drawTextLayer(text: value, point: CGPoint(x: xPos, y: yPos), align: align, attributes: [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: color], constrainedToWidth: constrainedWidth, truncationMode: .end)
            
            layer.setValue(entry, forKey: "entryForHighlight")
            
            chart.plotView?.nsuiLayer?.addSublayer(layer)
        }
    }
    
    open override func drawExtras(context: CGContext)
    {
     
    }
}


