//
//  AxisPolarRadiusRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 10/07/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation
import CoreGraphics

open class AxisPolarRadiusRenderer:AxisRendererBase
{
    internal func getRequiredSize() -> CGFloat
    {
         var radiusOffset:CGFloat = 0
         if let yAxis = self.axis as? YAxis
         {
           if yAxis.drawAxisLineEnabled && yAxis.visible
            {
                radiusOffset += yAxis.axisLineWidth
            }
            
            if yAxis.drawTickMarksEnabled && yAxis.visible
            {
                radiusOffset += yAxis.axisTickMarkSize
            }
            
            if yAxis.drawLabelsEnabled || yAxis.isDrawTopYLabelEntryEnabled || yAxis.isDrawBottomYLabelEntryEnabled
            {
                let text = self.getLongestLabelfromEntries(axis:yAxis)
                let textSize = text.size(withAttributes: [NSAttributedString.Key.font: yAxis.labelFont])
                radiusOffset += textSize.width + yAxis.yOffset
                
            }
         }
         return radiusOffset
    }
    
    open override func renderAxisLine(context: CGContext) {
        guard
            let axis = self.axis,
            let polarTransformer = transformer as? PolarTransformer
            else { return }
       
            if !axis.isEnabled || !axis.drawAxisLineEnabled || axis.isKind(of: YAxis.self) && !(axis as! YAxis).isVisible
            {
                return
            }
        
            let startAngle = polarTransformer.startAngle
            let axisRadius = polarTransformer.radius //+ (lineWidth/2) + yAxis.yOffset
            let axisCenter = polarTransformer.centerPoint
        
            let endPoint = ChartUtils.getPosition(center: axisCenter, dist: axisRadius, angle: startAngle)
        
            let arcPath = CGMutablePath()
            
            arcPath.move(to: polarTransformer.centerPoint)
            arcPath.addLine(to: endPoint)
            
            context.saveGState()
           
            context.setStrokeColor(axis.axisLineColor.cgColor)
            context.setLineWidth(axis.axisLineWidth)
             
            if axis.axisLineDashLengths != nil
            {
                context.setLineDash(phase: axis.axisLineDashPhase, lengths: axis.axisLineDashLengths)
            }
            else
            {
                context.setLineDash(phase: 0.0, lengths: [])
            }
    
            context.beginPath()
            context.addPath(arcPath)
            context.strokePath()
       
            context.restoreGState()
          
    }
    
    /// draws the y-axis labels to the screen
    open override func renderAxisLabels(context: CGContext)
    {
        guard
            let axis = self.axis,
            let polarTransformer = transformer as? PolarTransformer
            else { return }
        
        if !axis.isEnabled
        {
            return
        }
        
        var entries = [Int:Double]()
        
        for entryEnum in axis.entries.enumerated() {
            entries[entryEnum.offset] = entryEnum.element
        }
        
        let isEmptyEntries = axis.entries.isEmpty
        
        if !axis.drawLabelsEnabled || !axis.visible {
            
            var flag = true
            
            entries = [:]
           
            if axis.isDrawBottomYLabelEntryEnabled
            {
                entries[0] = axis.axisMinimum
                if !isEmptyEntries && axis.entries[safe:0] != nil {
                    axis.entries[0] = axis.axisMinimum
                }
                else {
                    axis.entries.append(axis.axisMinimum)
                }
                flag = false
            }
            
            if axis.isDrawTopYLabelEntryEnabled
            {
                if !isEmptyEntries && axis.entries[safe:axis.entries.count - 1] != nil {
                    axis.entries[axis.entries.count - 1] = axis.axisMaximum
                }
                else {
                    axis.entries.append(axis.axisMaximum)
                }
                entries[axis.entries.count - 1] = axis.axisMaximum
                flag = false
            }
            
            if flag
            {
                return
            }
        }

        let labelFont = axis.labelFont
        let labelTextColor = axis.labelTextColor
        
        let from = axis.isDrawBottomYLabelEntryEnabled ? 0 : 1
        let to = axis.isDrawTopYLabelEntryEnabled ? entries.count : (entries.count - 1)
        
        let labelAttrs = [NSAttributedString.Key.font: labelFont, NSAttributedString.Key.foregroundColor: labelTextColor]
        
        var totalOffset:CGFloat = 0
        
        if axis.drawAxisLineEnabled
        {
            totalOffset += axis.axisLineWidth
        }
        
        totalOffset = totalOffset + axis.xOffset
        
        if axis.drawTickMarksEnabled
        {
            totalOffset += axis.axisTickMarkSize
        }
        
        let keys = entries.keys.sorted()
        
        for i in stride(from: from, to: to, by: 1)
        {
            var value = (i >= 0 && i < entries.count) ? entries[keys[i]] ?? 0 : 0
            
            value = value < axis.axisMinimum ? axis.axisMinimum : value
            
            value = value > axis.axisMaximum ? axis.axisMaximum : value
            
            let text = axis.getFormattedLabel(keys[i])
            
            let textSize = text.size(withAttributes: [NSAttributedString.Key.font: labelFont])
            
            let constrainedToSize = CGSize(width: axis.maxLabelWidth, height: textSize.height)
            
            let pixelPosition = polarTransformer.angleAxisDependency == .yAxis ? polarTransformer.pixelForPolarValues(x: value, y: 0) : polarTransformer.pixelForPolarValues(x: 0, y: value)

            drawLabelTruncated(context: context, formattedLabel: text, x: pixelPosition.x + totalOffset, y: pixelPosition.y, attributes: labelAttrs, constrainedToSize: constrainedToSize, anchor: CGPoint(x: 0, y: 0.5), angleRadians: (0 * ChartUtils.Math.FDEG2RAD))
            
            let tickLabel = TickLabel()
            
            tickLabel.label = text
            
            tickLabel.value = entries[keys[i]] ?? 0.0
            
            tickLabel.point = CGPoint(x: pixelPosition.x + totalOffset, y: pixelPosition.y)
            
            tickLabel.constrainedSize = constrainedToSize
            
            tickLabel.angleInRadians = (0 * ChartUtils.Math.FDEG2RAD)
            
            tickLabel.anchorPoint = CGPoint(x: 0, y: 0.5)
            
            tickLabel.attributes = labelAttrs
            
            tickLabel.stringDrawingOption = .truncatesLastVisibleLine
           
            tickLabel.updateTickBounds()
            
            tickLabels.append(tickLabel)
            
            if axis.drawTickMarksEnabled && axis.visible
            {
                context.saveGState()
                
                context.setStrokeColor(axis.axisTickMarkColor.cgColor)
                context.setLineWidth(axis.axisTickMarkLineWidth)
                context.beginPath()
                context.move(to: pixelPosition )
                context.addLine(to: CGPoint(x: pixelPosition.x + axis.axisTickMarkSize , y: pixelPosition.y))
                context.strokePath()
                
                context.restoreGState()
            }

        }
        
    }
    
    override open func renderLimitLines(context: CGContext) {
        
    }
    
    override open func renderBaseLine() {
        
    }
    
    override open func drawGridLine(context: CGContext, position: CGPoint)
    {
        guard
            let chart = chartViewBase,
            let polarTransformer = transformer as? PolarTransformer,
            let entries = self.axis?.entries,
            (entries.count > 1)
            else { return }
        
        guard let isXaxis = (self.axis?.isKind(of: XAxis.self))
        else { return }
        
        let referenceAxis = isXaxis ? chart.yAxisArray[0]: chart.xAxis
        
        let gridPath = CGMutablePath()
        
        let radius = isXaxis ? position.x : position.y
        
        let angleValues = polarTransformer.pixelForValues(x: referenceAxis.entries[0], y: referenceAxis.entries[0])
        
        var angle = isXaxis ? angleValues.y : angleValues.x
        
        angle = polarTransformer.getAbsoluteAngleForGivenAngle(angle: angle)
        
        let entryPosition = ChartUtils.getPosition(center: polarTransformer.centerPoint, dist: radius, angle: angle)
        
        gridPath.move(to: entryPosition)
        
        for axisValue in referenceAxis.entries
        {
            let angleValues = polarTransformer.pixelForValues(x: axisValue, y: axisValue)
            
            var angle = isXaxis ? angleValues.y : angleValues.x
            
            angle = polarTransformer.getAbsoluteAngleForGivenAngle(angle: angle)
            
            let entryPosition = ChartUtils.getPosition(center: polarTransformer.centerPoint, dist: radius, angle: angle)
            
            gridPath.addLine(to: entryPosition)
        }
        gridPath.closeSubpath()
        
        context.beginPath()
        context.addPath(gridPath)
        context.strokePath()
    }
}
