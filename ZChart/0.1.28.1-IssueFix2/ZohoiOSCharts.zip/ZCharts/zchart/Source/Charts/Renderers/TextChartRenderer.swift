//
//  TextChartRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 04/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//


import Foundation
import CoreGraphics

#if !os(OSX)
    import UIKit
#endif


open class TextChartRenderer: DataRenderer
{
    open override func drawData(context: CGContext) {
     
        guard let chart = chart,
              let data = chart.data,
              let processor = chart.getProcessor(type: .WordCloud) as? WordCloudPreprocessor,
              let viewPort = viewPortHandler
        else { return }
        
        WordCloudTextLayer.removeAllWordLayer(chart: chart)
        
        for i in 0..<processor._buffers.count
        {
            var dict = processor._buffers[i]
            
            guard let setIndex = dict["setIndex"] as? Int,
                  let entryIndex = dict["entryIndex"] as? Int
            else { continue }
            
            let set = data.dataSets[setIndex]
            
            guard let entry = set.entryForIndex(entryIndex),
                  let xValue = dict["x"] as? CGFloat,
                  let yValue = dict["y"] as? CGFloat,
                  let size = dict["fontSize"] as? CGFloat
            else { continue }
            
            
            
            if xValue == 0 && yValue == 0 && size == 0
            {
                continue
            }
            
            var point = CGPoint(x:xValue, y :yValue)
            
            chart.plotTransformer.pointValueToPixel(&point)
            
            dict["x"] = point.x
            dict["y"] = point.y
            
            dict["fontSize"] = size * chart.plotTransformer.valueToPixelMatrix.a
            
            guard let valueText:String = dict["text"] as? String,
                  let fontSizeValue = dict["fontSize"] as? CGFloat
            else { continue }
            var valueFont = set.valueFont
            if #available(macOS 10.15, *) {
                 valueFont = set.valueFont.withSize(fontSizeValue)
            } else {
                // Fallback on earlier versions
            }
            
            
            let valueAttributes = [NSAttributedString.Key.font: valueFont ]
            let textSize = valueText.size(withAttributes: valueAttributes)
            
            let maxSize = max(textSize.width,textSize.height)
            
            if point.y > viewPort.contentBottom + maxSize || point.y < viewPort.contentTop - maxSize || point.x > viewPort.contentRight + maxSize || point.x < viewPort.contentLeft - maxSize
            {
                continue
            }
            
            _ = WordCloudTextLayer(chartView: chart, chartEntry: entry, dataSet: set, valueDict: dict)
        }
    }
    
    open override func drawValues(context: CGContext) {
        return
    }
    
    override open func drawExtras(context: CGContext) {
        return
    }
}
