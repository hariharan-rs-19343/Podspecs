//
//  RadarChartRenderer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 28/06/20.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

class RadarChartRenderer:PieChartRenderer
{
    open override func drawData(context: CGContext)
    {
        guard let chart = chart,
            let chartData = chart.data,
            let radarOption = chart.getPlotOptions(type: .Radar) as? DialPlotOptions
            else { return }
        
    
        /// For Marker Points to be visible above other layers
        let dataSets = radarOption.isStacked ? chartData.dataSets.reversed() : chartData.dataSets
        for set in dataSets
        {
            if set.isVisible && set.entryCount > 0
            {
                drawDataSet(context: context, dataSet: set)
            }
        }
        
    }
    
    open override func drawDataSet(context: CGContext, dataSet: IChartDataSet)
    {
        guard
            let chart = chart,
            let dataOption = (dataSet.dataSetOptions as? LineDataSetOptions),
            let radarOption = chart.getPlotOptions(type: .Radar) as? DialPlotOptions,
            let animator = animator
                else {return }
        
        context.saveGState()
        
        var (datasetPath,strokePath):(CGPath,CGPath)
        
        switch  dataOption.mode {
        case .linear:
            (datasetPath,strokePath) = radarOption.isStacked ?
                LineHelperFunctions.getWebLinearStackedPathWithNAN(barLineChart: chart, dataSet: dataSet, fromIndex: 0, toIndex: dataSet.entryCount-1, animator: animator, lineRenderer: self, isStepped: false)
                : LineHelperFunctions.getWebLinearPathWithNAN(barLineChart: chart, fromIndex: 0, toIndex: dataSet.entryCount-1, dataSet: dataSet, animator: animator, lineRenderer: self, isStepped: false)
            break
            
        case .montonic:
            (datasetPath,strokePath) = radarOption.isStacked ?
                LineHelperFunctions.getWebMonotoneStackedDataSetPathWithNAN(barLineChart: chart, fromIndex: 0, toIndex: dataSet.entryCount-1, dataSet: dataSet, animator: animator, lineRenderer: self)
                : LineHelperFunctions.getWebMonotoneDataSetPathWithNAN(barLineChart: chart, fromIndex: 0, toIndex: dataSet.entryCount-1, dataSet: dataSet, animator: animator, lineRenderer: self)
            break
                
            
        default:
            (datasetPath,strokePath) = LineHelperFunctions.getWebLinearPathWithNAN(barLineChart: chart, fromIndex: 0, toIndex: dataSet.entryCount-1, dataSet: dataSet, animator: animator, lineRenderer: self, isStepped: false)
        }
       
        (datasetPath as! CGMutablePath).closeSubpath()
        (strokePath as! CGMutablePath).closeSubpath()
        
        guard let firstEntry = dataSet.entryForIndex(0)
        else { return }
        
        let layer = LineLayer(chartView: chart, chartEntry: firstEntry, dataSet: dataSet, path: datasetPath)
        
        if let entry = dataSet.entryForIndex(0){
            if customOpacity{
                layer.opacity = entry.opacityChanged
            }
        }
        
        if dataOption.isDrawFilledEnabled
        {
            LineHelperFunctions.createLineStrokeLayer(lineLayer: layer, dataSet: dataSet, strokePath:strokePath)
        }
        
        context.restoreGState()
    }
    
    open override func drawValues(context: CGContext)
    {
        guard
        let chart = chart,
        let scatterData = chart.data
        else { return }
        
        let dataSets = scatterData.dataSets
        
        for i in 0 ..< scatterData.dataSetCount
        {
            let dataSet = dataSets[i]
            
            guard (dataSet.plotType == .Radar) ,
                let labelRectsforDataSet = chart.labelRectIndexMap[i],
                let formatter = dataSet.valueFormatter,
                  shouldDrawValues(forDataSet: dataSet)
                else { continue }
            
            for j in stride(from: 0, through: dataSet.entryCount, by: 1)
            {
                guard let e = dataSet.entryForIndex(j) else { break }
                
                guard var labelRect = labelRectsforDataSet[j]?["y"],
                      let setInstance = dataSet as? ChartDataSet, !e.filterEnabled || !e.x.isNaN || !e.y.isNaN
                else { continue }

                let text = formatter.stringForValue(
                    e.y,
                    entry: e,
                    dataSetIndex: i,
                    viewPortHandler: viewPortHandler)
                
                labelRect.origin = CommonHelperFunctions.getPixelForValues(x: labelRect.origin.x, y: labelRect.origin.y, dataSet: setInstance , chart: chart)
                    
                drawLabel(chart: chart, label: text, labelAttributes: [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColorAt(j)], labelRect: labelRect)
            }
        }
    }
    
    override func drawExtras(context: CGContext) {
        
        drawMarkerLayers(context: context)
    }
    
    fileprivate func drawMarkerLayers(context:CGContext)
    {
        guard let chart = chart,
            let lineData = chart.data,
            let animator = animator,
            let viewPortHandler = chart.viewPortHandler,
            let radarProcessor = chart.getProcessor(type: .Radar) as? RadarPreprocessor,
            let radarOption = chart.getPlotOptions(type: .Radar) as? DialPlotOptions
            else { return }
        
        if chart.interactionAnimationInProgress
        {
            return
        }
        
        let phaseY = animator.phaseY
        
        let dataSets = lineData.dataSets
        
        let entriesStackedYValue = radarProcessor.entriesStackedYValue
        
        var pt = CGPoint()
        
         context.saveGState()
        
        for i in 0 ..< dataSets.count
        {
            guard let dataSet = lineData.getDataSetByIndex(i) as? ChartDataSet,
                let lineDataSetOptions = dataSet.dataSetOptions as? LineDataSetOptions
            else { continue }
            
            if !dataSet.isVisible ||  !lineDataSetOptions.drawShapeEnabled || dataSet.entryCount == 0
            {
                continue
            }
            
            for j in stride(from: 0, through: dataSet.entryCount, by: 1)
            {
                guard let e = dataSet.entryForIndex(j) else { break }
                
                if e.y.isNaN || e.x.isNaN || e.filterEnabled {
                    continue
                }
                
                pt.x = CGFloat(e.x)
                pt.y = CGFloat(e.y * phaseY)
                
                if radarOption.isStacked
                {
                    pt.y = CGFloat(entriesStackedYValue[i]?[j] ?? 0)
                }
                
                pt = CommonHelperFunctions.getPixelForValues(x: Double(pt.x), y: Double(pt.y), dataSet: dataSet, chart: chart)
                
                if useForcedValue
                {
                    if e.centerChanged != nil
                    {
                        pt = e.centerChanged!
                    }
                }
                
                if (chart.xAxis.isInverted) {
                    if (!viewPortHandler.isInBoundsLeft(pt.x))
                    {
                        break
                    }
                }else {
                    if (!viewPortHandler.isInBoundsRight(pt.x))
                    {
                        break
                    }
                }
                
                // make sure the circles don't do shitty things outside bounds
                if (!viewPortHandler.isInBoundsLeft(pt.x) || !viewPortHandler.isInBoundsRight(pt.x) || !viewPortHandler.isInBoundsY(pt.y))
                {
                    continue
                }
                
                let markerLayer = CAShapeLayer()
                
                let shapePath:CGPath
                
                if lineDataSetOptions.markerInstance.shapeType == .custom
                {
                    shapePath = ((lineDataSetOptions.markerInstance.customPathDataSource?.shapePath?(point: pt, shapeInstance: lineDataSetOptions.markerInstance, shapeLayer: markerLayer))) ?? ShapeFactory.getPath(point: pt, shapeInstance: lineDataSetOptions.markerInstance)
                }
                else{
                    shapePath = ShapeFactory.getPath(point: pt, shapeInstance: lineDataSetOptions.markerInstance)
                }
                
                let shapeStrokeSize = lineDataSetOptions.markerInstance.lineWidth
                
                
                if (chart.includeLayer)
                {
                    markerLayer.path = shapePath
                    markerLayer.fillColor = lineDataSetOptions.markerInstance.holeColor?.cgColor
                    markerLayer.strokeColor = lineDataSetOptions.getShapeColor(atIndex: j)?.cgColor ?? NSUIColor.black.cgColor
                    markerLayer.lineWidth = CGFloat(shapeStrokeSize)
                    markerLayer.lineCap =  .round   //  convertToCAShapeLayerLineCap("round")
                        
                    if (chart.customAnimationInProgress)
                    {
                        markerLayer.opacity = 0
                    }
                    
                    let lineLayer = LineLayer.getLayerForDataset(chart: chart, lineChartDataSet: dataSet)
                    
                    if lineLayer == nil {
                        continue
                    }
                    
                    lineLayer!.addSublayer(markerLayer)
                    
                    lineLayer!.markerShapeLayerIndex[j] = (((lineLayer!.sublayers?.count) ?? 1) - 1)
                    
                }
                else{
                context.setLineWidth(shapeStrokeSize)
                context.setLineCap(lineDataSetOptions.markerInstance.lineCapType)
                context.beginPath()
                context.addPath(shapePath)
                    context.setFillColor((lineDataSetOptions.markerInstance.holeColor)?.cgColor ?? NSUIColor.clear.cgColor)
                context.fillPath()
                context.addPath(shapePath)
                    context.setStrokeColor(lineDataSetOptions.getShapeColor(atIndex: j)?.cgColor ?? NSUIColor.black.cgColor)
                context.strokePath()
                    
                }
                
            }
        }
        
        context.restoreGState()
    }
    
}
