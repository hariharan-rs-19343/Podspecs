//
//  BarDataSetOptions.swift
//  zchart
//
//  Created by Aravinth T on 06/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class BarDataSetOptions : AxisChartDataSetOptions
{
      // MARK: - Level and Target marker
    
      /// All the colors that are used for this DataSet.
      /// Colors are reused as soon as the number of levelMarkers in the Entries is higher than the size of the colors array.
      open var levelMarkerColors = [[NSUIColor]]()
      
      // Holds all the shape properties
      open var targetMarkerShapeProperties:ShapeProperties = ShapeProperties(type: LineShapes.line)
    
      // MARK: - Styling functions and accessors
      
      /// the color used for drawing the bar-shadows. The bar shadows is a surface behind the bar that indicates the maximum value
      open var barShadowColor = NSUIColor(red: 215.0/255.0, green: 215.0/255.0, blue: 215.0/255.0, alpha: 1.0)

      /// the width used for drawing borders around the bars. If borderWidth == 0, no border will be drawn.
      open var barBorderWidth : CGFloat = 0.0

      /// the color drawing borders around the bars.
      open var barBorderColor = NSUIColor.black

      /// the alpha value (transparency) that is used for drawing the highlight indicator bar. min = 0.0 (fully transparent), max = 1.0 (fully opaque)
      open var highlightAlpha = CGFloat(120.0 / 255.0)
      
    // MARK: - NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! BarDataSetOptions
        
        copy.levelMarkerColors = [[NSUIColor]]()
        copy.targetMarkerShapeProperties = targetMarkerShapeProperties
        copy.barShadowColor = barShadowColor
        copy.barBorderWidth = barBorderWidth
        copy.barBorderColor = barBorderColor
        copy.highlightAlpha = highlightAlpha
        
        return copy
    }
    
    // MARK: - Codable
    enum barDataSetOptionsCodingKeys: CodingKey {
               case levelMarkerColors
               case targetMarkerProperties
               
           }
    
    required public  init(from decoder: Decoder) throws {
       
        try super.init(from: decoder)
        
        let container = try decoder.container(keyedBy: barDataSetOptionsCodingKeys.self)
        
        let levelMarkerColorsCode = container.contains(.levelMarkerColors) ? try container.decode([Int].self, forKey: .levelMarkerColors) : []
        
        levelMarkerColors.removeAll()
        
        var colorsArray:[NSUIColor] = []
        
        for code in levelMarkerColorsCode
        {
            colorsArray.append(NSUIColor(rgb:code))
        }
        
        levelMarkerColors = [colorsArray]
        
        targetMarkerShapeProperties = container.contains(.targetMarkerProperties) ? try container.decode(ShapeProperties.self, forKey: .targetMarkerProperties) : targetMarkerShapeProperties
        
    }
    
    public required init() {
        super.init()
    }
    
    public override func encode(to encoder: Encoder) throws {
        
    }
     
}
