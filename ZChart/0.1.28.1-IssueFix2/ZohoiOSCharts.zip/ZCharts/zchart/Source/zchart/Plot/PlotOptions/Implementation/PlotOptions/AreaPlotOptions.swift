//
//  AreaPlotOptions.swift
//  zchart
//
//  Created by Keerthivass B S on 09/05/24.
//

import Foundation

open class AreaPlotOptions: LinePlotOptions {
    
}
