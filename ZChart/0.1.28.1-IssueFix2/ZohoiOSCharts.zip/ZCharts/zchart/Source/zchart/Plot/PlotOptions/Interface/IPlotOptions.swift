//
//  IPlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 30/09/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

public protocol IPlotOptions
{
    
}

public protocol IDialPlotOptions : IPlotOptions
{
    // MARK: - Data functions and accessors
    
    /// - returns: The start angle of the pie.
    var startAngle: CGFloat { get set}
    
    /// - returns: The angle at which the pie ends.
    var maxAngle: CGFloat { get set}
    
    /// - returns: The angle at which the pie ends.
    var direction: SliceDirection { get set}
    
    /// - returns: The angle at which the pie ends.
    var innerRadiusPercent: CGFloat { get set}
    
    /// - returns: The bandwidth of the dial in percentage.
    var bandWidth: CGFloat { get set}
    
    /// Colors are reused as soon as the number of Entries the DataSet represents is higher than the size of the colors array.
    var levelMarkerColors: [[NSUIColor]] { get set}
    
    // Holds targetMarker shape properties
    var targetMarkerShapeProperties: ShapeProperties { get }
    
    // Holds targetMarker padding properties
    var targetMarkerPadding: CGFloat? { get set}
    
    // Holds needle show properties
    var needleEnabled: Bool { get set}
    
    // Holds needle shape properties
    var needleShapeProperties: ShapeProperties { get set}
}

