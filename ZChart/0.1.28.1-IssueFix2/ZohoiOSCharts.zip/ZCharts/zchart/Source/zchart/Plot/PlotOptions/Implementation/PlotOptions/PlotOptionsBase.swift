//
//  PlotOptionsBase.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 05/02/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class PlotOptionsBase: NSObject, IPlotOptions, Codable
{
    open weak var chartView:ChartViewBase? = nil
    
    fileprivate var _stacked:Bool = false
    
    open var barGroupSelectionEnabled:Bool = false
    
    open var dataValuesTrancateMode: CATextLayerTruncationMode = .end
    
    open var isStacked:Bool
    {
       get {
           return _stacked
       }
       set {
           _stacked = newValue
       }
    }
    
    public required override init() {
           super.init()
       }
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
         let copy = type(of: self).init()
        
         copy._stacked = _stacked
        
         copy.barGroupSelectionEnabled = barGroupSelectionEnabled
        
         return copy
    }
    
    // MARK: - Codable
    
        enum CodingKeys: CodingKey {
                case isStack
           }
    
        required public  init(from decoder: Decoder) throws {
            super.init()
            
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            isStacked = container.contains(.isStack) ?  try container.decode(Bool.self, forKey: .isStack) : isStacked
        }
    
        public  func encode(to encoder: Encoder) throws {
  
        }
}
