//
//  WordCloudPlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 09/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import Foundation

open class WordCloudPlotOptions : PlotOptionsBase
{
       open var isCustomFontUsed = false
    
       open var customFontsList:[String] = []
    
       open var outerPadding = CGFloat(0.0)
       
       open var interPadding = CGFloat(2)
       
       open var minFontSize = CGFloat(2)
       
       open var maxFontSize = CGFloat(20)
    
       open var maxFontToRestrict:CGFloat = CGFloat(10)
    
       open var rotation = [0]

    
     // MARK: - NSCopying
     
     @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
     {
         let copy = super.copyWithZone(zone) as! WordCloudPlotOptions
         
         copy.outerPadding = outerPadding
         copy.interPadding = interPadding
         copy.minFontSize = minFontSize
         copy.maxFontSize = maxFontSize
         
         return copy
     }
    
    // MARK: - Codable
    
        enum wordCloudPlotOptionsCodingKeys: CodingKey {
            
            case interPaddingInDp
            case outerPaddingInDp
            
            case minSizePercentage
            case maxSizePercentage
            
            case rotation
        }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            let container = try decoder.container(keyedBy: wordCloudPlotOptionsCodingKeys.self)
            
            outerPadding = container.contains(.outerPaddingInDp) ? try container.decode(CGFloat.self, forKey: .outerPaddingInDp) : outerPadding
            
            interPadding = container.contains(.interPaddingInDp) ? try container.decode(CGFloat.self, forKey: .interPaddingInDp) : interPadding
            
            minFontSize = container.contains(.minSizePercentage) ? try container.decode(CGFloat.self, forKey: .minSizePercentage) : minFontSize
            
            maxFontSize = container.contains(.maxSizePercentage) ? try container.decode(CGFloat.self, forKey: .maxSizePercentage) : maxFontSize
            
            rotation = container.contains(.rotation) ? try container.decode([Int].self, forKey: .rotation) : rotation
            
        }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
   
    }
}

