//
//  HeatMapPlotOptions.swift
//  Pods
//
//  Created by Keerthivass B S on 26/11/24.
//

import Foundation

open class HeatMapPlotOptions: AxisChartPlotOptions {
    
    open var roundedCorners: Bool = false

    open var roundedRadii: CGFloat = 5.0
    
    open var dataLabelTruncateToOnePointWidth = false

    #if os(iOS) || os(tvOS)
    open var byRoundingCorners: UIRectCorner = .allCorners
    #endif
}
