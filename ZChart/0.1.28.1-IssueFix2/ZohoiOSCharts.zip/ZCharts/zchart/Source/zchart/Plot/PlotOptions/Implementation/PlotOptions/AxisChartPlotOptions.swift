//
//  AxisChartPlotOptions.swift
//  zchart
//
//  Created by Aravinth T on 06/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class AxisChartPlotOptions : PlotOptionsBase
{
    open var resizeAxisOnScrollEnabled:Bool = true
    
    open var sortInteractionCalled:Bool = false
    
    open var sortAscendingEnabled:Bool = true
    
    /// the color for the background of the chart-drawing area (everything behind the grid lines).
    open var gridBackgroundColor = NSUIColor(red: 240/255.0, green: 240/255.0, blue: 240/255.0, alpha: 1.0)
    
    open var borderColor = NSUIColor.black
    open var borderLineWidth: CGFloat = 1.0
    
    /// flag indicating if the grid background should be drawn or not
    open var drawGridBackgroundEnabled = false
    
    /// When enabled, the borders rectangle will be rendered.
    /// If this is enabled, there is no point drawing the axis-lines of x- and y-axis.
    open var drawBordersEnabled = false
    
    /// Sets the minimum offset (padding) around the chart, defaults to 10
    open var minOffset = CGFloat(10.0)
    
    /// Sets whether the chart should keep its position (zoom / scroll) after a rotation (orientation change)
    /// **default**: false
    open var keepPositionOnRotation: Bool = false
    
     open var minimumShapeSizeInPixel = CGFloat(0)
     
     open var maximumShapeSizeInPixel = CGFloat(0)

     open var maxWidthZoomRestrictionPixel = CGFloat.greatestFiniteMagnitude
    
    
    /// **default**: true
    /// - returns: `true` if drawing the grid background is enabled, `false` ifnot.
    open var isDrawGridBackgroundEnabled: Bool
    {
        return drawGridBackgroundEnabled
    }
    
    /// **default**: false
    /// - returns: `true` if drawing the borders rectangle is enabled, `false` ifnot.
    open var isDrawBordersEnabled: Bool
    {
        return drawBordersEnabled
    }
    
    // MARK: - BarLineScatterCandleBubbleChartDataProvider Properties
    
    fileprivate var _autoScaleLastLowestVisibleX: Double?
    fileprivate var _autoScaleLastHighestVisibleX: Double?
    
    
    // MARK: - NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! AxisChartPlotOptions
        
        copy.resizeAxisOnScrollEnabled = resizeAxisOnScrollEnabled
        copy.gridBackgroundColor = gridBackgroundColor
        copy.borderColor = borderColor
        copy.borderLineWidth = borderLineWidth
        copy.drawGridBackgroundEnabled = drawGridBackgroundEnabled
        copy.drawBordersEnabled = drawBordersEnabled
        copy.minimumShapeSizeInPixel = minimumShapeSizeInPixel
        copy.maximumShapeSizeInPixel = maximumShapeSizeInPixel
        copy.maxWidthZoomRestrictionPixel = maxWidthZoomRestrictionPixel
        
        return copy
    }
    
    // MARK: - Codable
    
        enum axisChartPlotOptionsCodingKeys: CodingKey {
            case maxWidthZoomRestrictionPixel
            case minimumShapeSizeInPixel
            case maximumShapeSizeInPixel
            
           }
    
    public  required  init(from decoder: Decoder) throws {
        try super.init(from: decoder)
        
        let container = try decoder.container(keyedBy: axisChartPlotOptionsCodingKeys.self)
        maxWidthZoomRestrictionPixel = container.contains(.maxWidthZoomRestrictionPixel) ? try container.decode(CGFloat.self, forKey: .maxWidthZoomRestrictionPixel) : maxWidthZoomRestrictionPixel
        minimumShapeSizeInPixel = container.contains(.minimumShapeSizeInPixel) ? try container.decode(CGFloat.self, forKey: .minimumShapeSizeInPixel) : minimumShapeSizeInPixel
        maximumShapeSizeInPixel = container.contains(.maximumShapeSizeInPixel) ? try container.decode(CGFloat.self, forKey: .maximumShapeSizeInPixel) : maximumShapeSizeInPixel
    }
    
    public  required init() {
        super.init()
    }

    public  override func encode(to encoder: Encoder) throws {

        }
}

