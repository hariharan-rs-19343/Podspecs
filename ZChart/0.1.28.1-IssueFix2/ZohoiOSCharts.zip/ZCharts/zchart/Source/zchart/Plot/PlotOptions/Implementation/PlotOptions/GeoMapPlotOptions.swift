//
//  GeoMapPlotOptions.swift
//  zchart
//
//  Created by Aravinth T on 26/11/21.
//

import Foundation

open class GeoMapPlotOptions : PlotOptionsBase
{
    open var scope:String = ""
    
    open var allAreas:Bool = true
    
    open var excludeAreas:[AnyObject] = []
    
    open var includeAreas:[AnyObject] = []
    
    open var strokeWidth:CGFloat = 0.5
    
    open var strokeColor:NSUIColor = NSUIColor.white
    
    open var fillColor:NSUIColor = NSUIColor.lightGray
    
    open var mapKey:GeoMapKey = .ZCKEY
    
    open var outerPadding:CGFloat = 10
    
    open var projection:String? = nil
             
    // MARK: - Codable
    
    enum geoMapPlotOptionsCodingKeys: CodingKey {
        case allAreas
        case fillColor
        case mapKey
        case scope
        case strokeColor
        case strokeWidth
       }
    
    public  required  init(from decoder: Decoder) throws {
        try super.init(from: decoder)
        
        let container = try decoder.container(keyedBy: geoMapPlotOptionsCodingKeys.self)
        
        allAreas = container.contains(.allAreas) ? try container.decode(Bool.self, forKey: .allAreas) : allAreas
        
        let colorsCode =  container.contains(.fillColor) ? try container.decode(Int.self, forKey: .fillColor) : nil
        fillColor = colorsCode == nil ? fillColor : NSUIColor(rgb:colorsCode!)
        
        let mapKeyString = container.contains(.mapKey) ? try container.decode(String.self, forKey: .mapKey) : "ZCKEY"
        
        switch  mapKeyString {
        case "NAME":
            mapKey = .NAME
        case "ZCKEY":
            mapKey = .ZCKEY
        case "ZCA2":
            mapKey = .ZCA2
        case "ZCA3":
            mapKey = .ZCA3
        case "LATLONG":
            mapKey = .LATLONG
        case "LONGLAT":
            mapKey = .LONGLAT
        default:
            mapKey = .ZCKEY
        }
        scope = container.contains(.scope) ? try container.decode(String.self, forKey: .scope) : scope
        
        let colorsCode1 = container.contains(.strokeColor) ? try container.decode(Int.self, forKey: .strokeColor) : nil
        strokeColor = colorsCode1 == nil ? strokeColor : NSUIColor(rgb:colorsCode1!)
        
        strokeWidth = container.contains(.strokeWidth) ? try container.decode(CGFloat.self, forKey: .strokeWidth) : strokeWidth
    }
    
    public  required init() {
        super.init()
    }

    public  override func encode(to encoder: Encoder) throws {

    }
}

public enum GeoMapKey: String, Codable
{
    case NAME = "name"
    case ZCKEY = "zc-key"
    case ZCA2 = "zc-a2"
    case ZCA3 = "zc-a3"
    case LATLONG = "lat-long"
    case LONGLAT = "long-lat"
}
