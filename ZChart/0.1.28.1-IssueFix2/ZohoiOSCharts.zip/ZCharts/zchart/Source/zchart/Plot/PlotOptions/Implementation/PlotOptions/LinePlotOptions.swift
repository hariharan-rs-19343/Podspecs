//
//  LinePlotOptions.swift
//  zchart
//
//  Created by Aravinth T on 20/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class LinePlotOptions : AxisChartPlotOptions
{
    
}
