//
//  DialPlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 30/09/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class DialPlotOptions: PiePlotOptions, IDialPlotOptions
{
    // MARK: - Data functions and accessors
    
    /// - returns: The center of the circlebox
    open override var centerCircleBox: CGPoint
    {
        return PieHelperFunctions.updateCenterPointValue(centerPoint: CGPoint(x: circleBox.midX, y: circleBox.midY), startAngle: startAngle, maxAngle: maxAngle, direction: direction, radius: radius)
    }
    
    fileprivate var _startDialAngle:CGFloat = 180
    
    /// the radius of the hole in the center of the piechart in percent of the maximum radius (max = the radius of the whole chart)
      ///
      /// **default**: 0.5 (50%) (half the pie)
    open var innerRadiusPercent: CGFloat = 0.5
    
    open var dialInnerPaddingPercent: CGFloat = 0.0
    
    open var dialOuterPaddingPercent: CGFloat = 0.0
       
    /// Colors are reused as soon as the number of Entries the DataSet represents is higher than the size of the colors array.
    open var levelMarkerColors: [[NSUIColor]] = [[NSUIColor]]()
   
    // Holds targetMarker shape properties
    open var targetMarkerShapeProperties: ShapeProperties = ShapeProperties()
    
    // Holds targetMarker padding properties
    open var targetMarkerPadding:CGFloat? = nil

    /// - returns: rendering direction of slice
    open var direction: SliceDirection = .clockwise
    
    @available(*, deprecated, message: "bandWidth is calculated automatically based on innerRadiusPercent.")
    /// - returns: The bandwidth of the dial in percentage.
    open var bandWidth: CGFloat = 0
    
    /// - returns: The bandwidth of the dial in percentage.
    open var roundedCorners: Bool = false
    
    /// - returns: needled enabled or disabled
    open var needleEnabled:Bool = true

    // Holds needle shape properties
    open var needleShapeProperties: ShapeProperties = ShapeProperties(type: LineShapes.needleClock)
    
    open var centerLabelPadding: CGFloat = 0.0
    
    open var centerLabelTrancate: Bool = false
    
    /// - returns: The start angle of the pie.
    open var startAngle: CGFloat
    {
        get
        {
            return _startDialAngle
        }
        set(newValue)
        {
            _startDialAngle = newValue
                       
            if _startDialAngle > 360.0
            {
                _startDialAngle = 360.0
            }
           
            if _startDialAngle < 0
            {
                _startDialAngle = 0
            }
        }
    }
    
    open var minMaxLabelConfig: ZCTextModel = ZCTextModel()
    
    open var targetLabelConfig: ZCTextModel = ZCTextModel()
    
    open var minimumSpacingBetweenDataLabel: CGFloat = 5.0
    
    open var targetIndicatorLineConfiguration: ZCLineCongifuration = ZCLineCongifuration()
    
    // MARK: - NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! DialPlotOptions
        
        copy._startDialAngle = _startDialAngle
        copy._startAngle = _startAngle
        copy.innerRadiusPercent = innerRadiusPercent
        copy.levelMarkerColors = levelMarkerColors
        copy.targetMarkerShapeProperties = targetMarkerShapeProperties
        copy.targetMarkerPadding = targetMarkerPadding
        copy.direction = direction
        copy.roundedCorners = roundedCorners
        copy.needleEnabled = needleEnabled
        copy.needleShapeProperties = needleShapeProperties
        copy.dialInnerPaddingPercent = dialInnerPaddingPercent
        copy.dialOuterPaddingPercent = dialOuterPaddingPercent
        copy.targetLabelConfig = targetLabelConfig
        
        return copy
    }
    
    // MARK: - Codable
    
        enum dialPlotOptionsCodingKeys: CodingKey {
            
            case innerRadiusPercent
            case isClockWiseDirection
            case levelMarkerColors
            case dialInnerPaddingPercent
            case dialOuterPaddingPercent
            case targetShapeProperty
           }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            let container = try decoder.container(keyedBy: dialPlotOptionsCodingKeys.self)
            
            innerRadiusPercent = container.contains(.innerRadiusPercent) ? try container.decode(CGFloat.self, forKey: .innerRadiusPercent) : innerRadiusPercent
            
            dialInnerPaddingPercent = container.contains(.dialInnerPaddingPercent) ? try container.decode(CGFloat.self, forKey: .dialInnerPaddingPercent) : 0
            
            dialOuterPaddingPercent = container.contains(.dialOuterPaddingPercent) ? try container.decode(CGFloat.self, forKey: .dialOuterPaddingPercent) : 0
            
            
            let isClockWiseDirection = try container.decode(Bool.self, forKey: .isClockWiseDirection)
            direction = isClockWiseDirection ? .clockwise : .counterClockwise
            
            startAngle = rotationAngle
            
            let colorsCode = container.contains(.levelMarkerColors) ? try container.decode([Int].self, forKey: .levelMarkerColors) : []
            
            var colorsArray = [NSUIColor]()
            for code in colorsCode
            {
                colorsArray.append(NSUIColor(rgb:code))
            }
            
            levelMarkerColors = [colorsArray]
            
            targetMarkerShapeProperties = container.contains(.levelMarkerColors) ? try container.decode(ShapeProperties.self, forKey: .targetShapeProperty) : targetMarkerShapeProperties
        }
    
    public  required init() {
        super.init()
        selectionShift = 0.0
        minOffset = 10.0
    }
    
    public  override func encode(to encoder: Encoder) throws {
    
        }
    
}
