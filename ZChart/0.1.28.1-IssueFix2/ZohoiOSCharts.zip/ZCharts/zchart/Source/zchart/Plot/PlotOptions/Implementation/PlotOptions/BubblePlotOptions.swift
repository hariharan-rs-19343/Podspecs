//
//  BubblePlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 25/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation


open class BubblePiePlotOptions: BubblePlotOptions
{
    open var piePlotoptions:PiePlotOptions = PiePlotOptions()
    
    // MARK: - Codable
    
        enum bubblePiePlotOptionsCodingKeys: CodingKey {
            case pie
        }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            
            let pieOptions = try PiePlotOptions(from: decoder)
            
            piePlotoptions = pieOptions
        }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
   
    }
}

open class BubblePlotOptions : AxisChartPlotOptions
{
    public enum BubbleMode: Int
    {
        case Pack
        case Flat
    }
       // MARK: - Data functions and accessors
        open var outerPadding:CGFloat = 10
       open var normalizeSizeEnabled: Bool = true
       open var isNormalizeSizeEnabled: Bool { return normalizeSizeEnabled }
    
        open var mode = BubbleMode.Pack
       
       // MARK: - Styling functions and accessors
       
       /// Sets/gets the width of the circle that surrounds the bubble when highlighted
       open var highlightCircleWidth: CGFloat = 2.5
       
        // MARK: - NSCopying
        
        @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
        {
            let copy = super.copyWithZone(zone) as! BubblePlotOptions
            
            copy.normalizeSizeEnabled = normalizeSizeEnabled
            copy.highlightCircleWidth = highlightCircleWidth
            
            return copy
        }
    
    // MARK: - Codable
    
        enum bubblePlotOptionsCodingKeys: CodingKey {
            case packMode
        }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            let container = try decoder.container(keyedBy: bubblePlotOptionsCodingKeys.self)
            
            let modeString = container.contains(.packMode) ? try container.decode(String.self, forKey: .packMode) : "FLAT"
            
            switch modeString
            {
                case "FLAT":
                    mode = .Flat
                    break
        
                default:
                    mode = .Pack
                    break
            }
        }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
   
    }
    
        
}

