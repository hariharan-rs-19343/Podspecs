//
//  SankeyPlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 16/09/22.
//


import Foundation

public enum nodeAlignOption : String
{
    case left
    case right
    case justify
    case center
}

open class SankeyPlotOptions : PlotOptionsBase
{
       // MARK: - Funnel Specific Properties
    
        open var outerPadding = CGFloat(0.0)
       
        open var nodePadding = CGFloat(8.0)
    
        open var nodeWidthInterpolateStartPercent = 30.0
    
        open var nodeWidthInterpolateEndPercent = 70.0
       
        open var maxNodeWidth = CGFloat(24.0)
    
        open var minNodeWidth = CGFloat(5.0)
    
        open var nodeAlign = nodeAlignOption.justify
       
        open var linkPadding = CGFloat(0.0)
    
    open var linkOpacity = CGFloat(0.4)
    
    open var drawDataLabelCenteredEnabled = false

    
     // MARK: - NSCopying
     
     @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
     {
         let copy = super.copyWithZone(zone) as! SankeyPlotOptions
         
         copy.outerPadding = outerPadding
         copy.nodePadding = nodePadding
         copy.maxNodeWidth = maxNodeWidth
         copy.linkPadding = linkPadding
         copy.linkOpacity = linkOpacity
         
         return copy
     }
    
    // MARK: - Codable
    
    enum SankeyPlotOptionsCodingKeys: CodingKey {
        
        case alignOption
        case linkOpacity
        case linkPaddingInDp
        case nodePaddingInDp
        case nodeWidthInDp
        case outerPaddingInDp
        
    }
    
    required public init(from decoder: Decoder) throws {
        try super.init(from: decoder)
        
        let container = try decoder.container(keyedBy: SankeyPlotOptionsCodingKeys.self)
        
        outerPadding = try container.decode(Double.self, forKey: .outerPaddingInDp)
        
        nodePadding = try container.decode(Double.self, forKey: .nodeWidthInDp)
        
        maxNodeWidth = try container.decode(Double.self, forKey: .nodeWidthInDp)
        
        linkPadding = try container.decode(Double.self, forKey: .linkPaddingInDp)
        
        linkOpacity = try container.decode(Double.self, forKey: .linkOpacity)
        
        let nodeAlignment = container.contains(.alignOption) ? try container.decode(String.self, forKey: .alignOption) : "JUSTIFY"
        
        switch nodeAlignment {
            case "JUSTIFY":
                nodeAlign = .justify
                break
                
            case "LEFT":
                nodeAlign = .left
                break
                
            case "RIGHT":
                nodeAlign = .right
                break
                
            default:
                nodeAlign = .center
                break
        }
    }
    
    public required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
        
    }

}


