//
//  BoxPlotPlotOptions.swift
//  zchart
//
//  Created by keerthi-pt4274 on 04/08/22.
//

import Foundation

open class BoxPlotPlotOptions: BarPlotOptions {
    
    open var medianIndex: Int = -1
    
    open var minWhiskersIndex: Int = -1
    
    open var maxWhiskersIndex: Int = -1
    
    open var medianEnabled: Bool = true
    
    open var drawMedianValueEnabled: Bool = true
    
    open var medianColor: NSUIColor = NSUIColor.black
    
    open var medianStrokeWidth: Double = 1.0
    
    /// the font for the stack sum value-text labels
    open var medianValueFont: NSUIFont = NSUIFont.systemFont(ofSize: 7.0)
    
    open var medianValueTextColor: NSUIColor = NSUIColor.black

    open var medianValueFormatter: IValueFormatter = DefaultValueFormatter(decimals: 1)
    
    open var whiskersEnabled: Bool = true
    
    open var drawWhiskersValueEnabled: Bool = true
    
    //length of the whiskers
    /// **default**: 0.5 (50%)
    open var whiskersBandWidth: Double = 0.50
    
    open var whiskersColor: NSUIColor = NSUIColor.black
    
    open var whiskersStrokeWidth: Double = 1.0
    
    open var whiskersDashPhase = CGFloat(0.0)
    
    open var whiskersDashLengths: [CGFloat]?
    
    open var whiskersOn: ShowType = .edges
    
    /// the font for the stack sum value-text labels
    open var whiskersValueFont: NSUIFont = NSUIFont.systemFont(ofSize: 7.0)
    
    open var whiskersValueTextColor: NSUIColor = NSUIColor.black

    open var whiskersValueFormatter: IValueFormatter = DefaultValueFormatter(decimals: 1)
    
    public enum ShowType {
        case edges
        case overLay
    }
    
    enum boxPlotOptionsCodingKeys: CodingKey {
        
        case drawMedianValueEnabled
        case drawWhiskersValueEnabled
        
        case isMedianEnabled
        case isWhiskersEnabled
        
        case maxWhiskersDataIndex
        case minWhiskersDataIndex
        case medianDataIndex
        
        case medianColor
        case medianStrokeWidth
        
        case whiskerShowOn
        case whiskersBandWidth
        case whiskersColor
        case whiskersStrokeWidth
    }
    
    required public  init(from decoder: Decoder) throws {
        try super.init(from: decoder)
        
        let container = try decoder.container(keyedBy: boxPlotOptionsCodingKeys.self)
        
        drawMedianValueEnabled = try container.decode(Bool.self, forKey: .drawMedianValueEnabled)
        drawWhiskersValueEnabled = try container.decode(Bool.self, forKey: .drawWhiskersValueEnabled)
        
        medianEnabled = try container.decode(Bool.self, forKey: .isMedianEnabled)
        whiskersEnabled = try container.decode(Bool.self, forKey: .isWhiskersEnabled)
        
        maxWhiskersIndex = try container.decode(Int.self, forKey: .maxWhiskersDataIndex)
        minWhiskersIndex = try container.decode(Int.self, forKey: .minWhiskersDataIndex)
        medianIndex = try container.decode(Int.self, forKey: .medianDataIndex)
        
        var colorVal = try container.decode(Int.self, forKey: .medianColor)
        if colorVal != -1 {
            medianColor = NSUIColor(rgb: colorVal)
        }
        medianStrokeWidth = try container.decode(Double.self, forKey: .medianStrokeWidth)
        
        whiskersOn = try container.decode(String.self, forKey: .whiskerShowOn) == "EDGES" ? ShowType.edges : ShowType.overLay
        whiskersBandWidth = try container.decode(Double.self, forKey: .whiskersBandWidth)
        colorVal = try container.decode(Int.self, forKey: .whiskersColor)
        if colorVal != -1 {
            whiskersColor = NSUIColor(rgb: colorVal)
        }
        whiskersStrokeWidth = try container.decode(Double.self, forKey: .whiskersStrokeWidth)
    }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
    }
}
