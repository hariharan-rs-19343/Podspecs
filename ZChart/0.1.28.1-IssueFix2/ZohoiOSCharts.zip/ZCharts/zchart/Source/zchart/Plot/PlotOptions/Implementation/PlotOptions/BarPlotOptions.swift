//
//  BarPlotOptions.swift
//  zchart
//
//  Created by Aravinth T on 06/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class BarPlotOptions : AxisChartPlotOptions
{
    // MARK:Properties
       
       /// No. of visible bars
       open var barCount:Int = 6
       
       fileprivate var _stackedPercentEnabled:Bool = false
       
       /// Adds half of the bar width to each side of the x-axis range in order to allow the bars of the barchart to be fully displayed.
       /// **default**: false
       open var fitBars = true
       
       /// To hold group space
       open var groupSpace:Double = 0
       
       /// To hold bar space
       open var barSpace:Double = 0
       
       // To hold highlight Color
       open var highlightColor:NSUIColor? = nil
    
       open var nonHighlightColor:NSUIColor? = nil
       
       open var highlightGradient:BaseGradient? = nil
    
       open var nonHighlightGradient:BaseGradient? = nil
       
       /// The width of the bars on the x-axis, in values (not pixels)
       ///
       /// **default**: 0.85
       open var barWidth = Double(0.85)
       
       open var levelMarkerWidth = Double(0)
       
       open var minimumBarPixel = Double(0)
       
       open var maximumBarPixel = Double(0)
       
       open var barSpacePixel = Double(0)
       
       open var groupSpacePixel = Double(0)
       
       open var barWidthPixel = Double(0)
       
       open var levelMarkerWidthPixel = Double(0)
       
       open var adjustViewToLevelWidth = false
       
       open var stackSpacing:CGFloat = 0
    
       open var segmentSpacing: CGFloat = 0
    
        /// the font for the stack sum value-text labels
        open var stackSumValueFont: NSUIFont = NSUIFont.systemFont(ofSize: 7.0)
        
        open var stackSumValueTextColor: NSUIColor = NSUIColor.black
    
        open var stackSumValueFormatter: IValueFormatter = DefaultValueFormatter(decimals: 1)
    
        /// if set to true, all values are drawn above their bars, instead of below their top
        fileprivate var _drawValueAboveBarEnabled = true

        /// if set to true, a grey area is drawn behind each bar that indicates the maximum value
        fileprivate var _drawBarShadowEnabled = false
        
        open var minPadding:Double = 0.0
        
        open var maxPadding:Double = 0
    
        open var targetLabelConfig: ZCTextModel = ZCTextModel()
    
        /// Set this to `true` to make the highlight operation full-bar oriented, `false` to make it highlight single values (relevant only for stacked).
       /// If enabled, highlighting operations will highlight the whole bar, even if only a single stack entry was tapped.
       open var highlightFullBarEnabled: Bool = false
       
       /// - returns: `true` the highlight is be full-bar oriented, `false` ifsingle-value
       open var isHighlightFullBarEnabled: Bool { return highlightFullBarEnabled }
    
        // MARK: Accessors
    
    @available(*, deprecated, message: "Instead use label position proprety")
        /// if set to true, all values are drawn above their bars, instead of below their top
        open var drawValueAboveBarEnabled: Bool
        {
            get { return _drawValueAboveBarEnabled }
            set
            {
                _drawValueAboveBarEnabled = newValue
            }
        }
    
    @available(*, deprecated, message: "Instead use label position proprety")
        open var drawValueCenteredEnabled:Bool = false
    
        open var isdrawLabelsEnabled:Bool = false
        
        /// if set to true, a grey area is drawn behind each bar that indicates the maximum value
        open var drawBarShadowEnabled: Bool
        {
            get { return _drawBarShadowEnabled }
            set
            {
                _drawBarShadowEnabled = newValue
            }
        }
    
        /// - returns: `true` if drawing values above bars is enabled, `false` ifnot
        open var isDrawValueAboveBarEnabled: Bool { return drawValueAboveBarEnabled }
    
        /// - returns: `true` if drawing shadows (maxvalue) for each bar is enabled, `false` ifnot
        open var isDrawBarShadowEnabled: Bool { return drawBarShadowEnabled }
    
        /// Stacked Percentage
        open var stackedPercentEnabled:Bool
        {
            get{
                return _stackedPercentEnabled
            }
            set{
                _stackedPercentEnabled = newValue
            }
        }
    
        //To check stacked sum enable
        internal var isStackedSumEnabled: Bool = false
    
        fileprivate var _stackedSumEnabled: Bool = false
    
        ////enable / disable stacked sum - initial value
        open var stackedSumEnabled: Bool
        {
            get{
                return _stackedSumEnabled
            }
            set{
                _stackedSumEnabled = newValue
                isStackedSumEnabled = newValue
            }
        }
    
    open var labelPosition: LabelPosition = .top
    
    @objc(BarPlotOptionsLabelPosition)
    public enum LabelPosition: Int
    {
        case top
        case bottom
        case center
    }
        
        // rounded corner Propertie
        open var roundedCorners: Bool = false
    
        open var roundedRadii: CGFloat = 5.0
    
        open var adjustmentLevel: Int = 2
    
#if os(iOS) || os(tvOS)
        open var byRoundingCorners: UIRectCorner = .allCorners
#endif
       
        // MARK: - NSCopying
           
           @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
           {
               let copy = super.copyWithZone(zone) as! BarPlotOptions
               
               copy.barCount = barCount
               copy._stackedPercentEnabled = _stackedPercentEnabled
               copy.fitBars = fitBars
               copy.groupSpace = groupSpace
               copy.barSpace = barSpace
               copy.highlightColor = highlightColor
               copy.nonHighlightColor = nonHighlightColor
               copy.highlightGradient = highlightGradient
               copy.nonHighlightGradient = nonHighlightGradient
               copy.barWidth = barWidth
               copy.levelMarkerWidth = levelMarkerWidth
               copy.minimumBarPixel = minimumBarPixel
               copy.maximumBarPixel = maximumBarPixel
               copy.barSpacePixel = barSpacePixel
               copy.groupSpacePixel = groupSpacePixel
               copy.barWidthPixel = barWidthPixel
               copy.levelMarkerWidthPixel = levelMarkerWidthPixel
               copy.adjustViewToLevelWidth = adjustViewToLevelWidth
               copy.stackSpacing = stackSpacing
               copy.roundedCorners = roundedCorners
               copy.roundedRadii = roundedRadii
               copy.labelPosition = labelPosition
               copy.targetLabelConfig = targetLabelConfig
                          
               return copy
           }
    
    
    // MARK: - Codable
    
        enum barPlotOptionsCodingKeys: CodingKey {
           
            case barMinWidPx
            case barMaxWidPx
            
            case barSpacePx
            case groupSpacePx
            
            
            case levelMarkerWidth
            case levelMarkerWidthPixel
            
            case mDrawBarShadow
            case mDrawValueAboveBar
            
            case mFitBars
            case restrictViewPortToLevelMarkerWidth
            
            case isPercentStack
            case segmentSpacePx
            
            case showStackSumValue
            
            case labelPosition
           }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            let container = try decoder.container(keyedBy: barPlotOptionsCodingKeys.self)
            
            let barWidPx = try container.decode(Double.self, forKey: .barMinWidPx)
            
            barWidthPixel = barWidPx != 0 ? barWidPx : 20.0
            
            minimumBarPixel = barWidthPixel
            maximumBarPixel = try container.decode(Double.self, forKey: .barMaxWidPx)
            
            barSpacePixel = try container.decode(Double.self, forKey: .barSpacePx)
            groupSpacePixel = isStacked || chartView?.data?.datasetsGroupArray?.count == 1 ? 0 : try container.decode(Double.self, forKey: .groupSpacePx)
            
            levelMarkerWidth = try container.decode(Double.self, forKey: .levelMarkerWidth)
            levelMarkerWidthPixel = try container.decode(Double.self, forKey: .levelMarkerWidthPixel)
            
            drawBarShadowEnabled = container.contains(.mDrawBarShadow) ? try container.decode(Bool.self, forKey: .mDrawBarShadow) : drawBarShadowEnabled
            drawValueAboveBarEnabled = try container.decode(Bool.self, forKey: .mDrawValueAboveBar)
            
//            fitBars = container.contains(.mFitBars) ? try container.decode(Bool.self, forKey: .mFitBars) : fitBars
            adjustViewToLevelWidth = try container.decode(Bool.self, forKey: .restrictViewPortToLevelMarkerWidth)
    
            stackedPercentEnabled = try container.decode(Bool.self, forKey: .isPercentStack)
            
            stackSpacing = container.contains(.segmentSpacePx) ? try container.decode(CGFloat.self, forKey: .segmentSpacePx) : stackSpacing
            
            stackedSumEnabled = try container.decode(Bool.self, forKey: .showStackSumValue)
            
            let labelPosition = container.contains(.labelPosition) ? try container.decode(String.self, forKey: .labelPosition)  : "TOP"
            
            switch labelPosition {
                case "TOP":
                    self.labelPosition = .top
                break
                case "BOTTOM":
                    self.labelPosition = .bottom
                break
                case "CENTER":
                    self.labelPosition = .center
                break
                default:
                    break
            }
            
        }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
        }
}
