//
//  FunnelPlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 03/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

public enum FunnelWeightedType
{
     case Height
     case Width
     case none
}

open class FunnelPlotOptions : PlotOptionsBase
{
       //Following properties {outerPadding, interSliceSpacing, stemWidth, stemHeight} to be specifed in pixel point units
       
       // MARK: - Funnel Specific Properties
    
       open var outerPadding = CGFloat(10.0)
       
       open var interSliceSpacing = CGFloat(10.0)
       
       open var stemWidth = CGFloat(30.0)
       
       open var stemHeight = CGFloat(0.0)
       
       open var maxSliceHeight = CGFloat(0.0)
       
       open var funnelWeightedType:FunnelWeightedType = .Height
       
       open var strokeColor:NSUIColor? = nil
       
       open var strokeWidth = CGFloat(1.0)
       
       public enum DataToShow
       {
           case showValue
           case showLabel
           case showPercent
       }
          
       open var dataToShow:DataToShow = .showLabel
       /*
        
       //TO BE ADDED LATER
       internal var reverseDirection:Bool = false
       
       //PERCENT TO BE ADDED LATER
       open var stemWidthPercent:CGFloat = 30
    
       open var interSpacePercent:CGFloat = 2
    
       open var stemHeightPercent:CGFloat = 10
    
       open var paddingInPercent:CGFloat = 3
        
       */
    
     // MARK: - NSCopying
     
     @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
     {
         let copy = super.copyWithZone(zone) as! FunnelPlotOptions
         
         copy.outerPadding = outerPadding
         copy.interSliceSpacing = interSliceSpacing
         copy.stemWidth = stemWidth
         copy.stemHeight = stemHeight
         copy.maxSliceHeight = maxSliceHeight
         copy.funnelWeightedType = funnelWeightedType
         copy.strokeColor = strokeColor
         copy.strokeWidth = strokeWidth
         copy.dataToShow = dataToShow
         
         return copy
     }
    
    // MARK: - Codable
    
        enum funnelPlotOptionsCodingKeys: CodingKey {
           
//            case autoInterSliceSpacing
            case dataToShow
            
            case funnelType
            case interSliceSpacing
            
            
            case maxSliceHeight
            case outerPadding
            
            case stemHeight
            case stemWidth
            
            case strokeColor
            case strokeWidth
        }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            let container = try decoder.container(keyedBy: funnelPlotOptionsCodingKeys.self)
            
//            inter = try container.decode(Double.self, forKey: .barMinWidPx)
            let dataToShowString = container.contains(.dataToShow) ? try container.decode(String.self, forKey: .dataToShow) : "showLabel"
            switch dataToShowString
            {
                case "showLabel":
                    dataToShow = .showLabel
                    break
                    
                case "showValue":
                    dataToShow = .showValue
                    break
                    
                case "showPercent":
                    dataToShow = .showPercent
                    break
            
                default:
                    dataToShow = .showLabel
                    break
            }
            let funnelWeightedTypeString = container.contains(.funnelType) ? try container.decode(String.self, forKey: .funnelType) : "Width"
            funnelWeightedType = funnelWeightedTypeString == "Width" ? .Width : .Height
            
            interSliceSpacing = container.contains(.interSliceSpacing) ? try container.decode(CGFloat.self, forKey: .interSliceSpacing) : interSliceSpacing
            
            maxSliceHeight = container.contains(.maxSliceHeight) ? try container.decode(CGFloat.self, forKey: .maxSliceHeight) : maxSliceHeight
            
            outerPadding = container.contains(.outerPadding) ? try container.decode(CGFloat.self, forKey: .outerPadding) : outerPadding
            
            stemHeight = container.contains(.stemHeight) ? try (container.decode(CGFloat.self, forKey: .stemHeight)) : stemHeight
            
            stemWidth = container.contains(.stemWidth) ? try (container.decode(CGFloat.self, forKey: .stemWidth)) : stemWidth
            
            let strokeColorCode = container.contains(.strokeColor) ? try container.decode(Int.self, forKey: .strokeColor) : -1
            strokeColor = strokeColorCode == -1 ? strokeColor : NSUIColor(rgb: strokeColorCode)
            
            strokeWidth = container.contains(.strokeWidth) ? try container.decode(CGFloat.self, forKey: .strokeWidth) : strokeWidth
            
        }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
   
    }
}
