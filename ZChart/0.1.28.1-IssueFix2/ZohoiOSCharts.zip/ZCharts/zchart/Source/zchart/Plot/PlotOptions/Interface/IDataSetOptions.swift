//
//  IDataSetPlotOptions.swift
//  zchart
//
//  Created by Aravinth T on 06/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

@objc
public protocol IDataSetOptions
{
    var nonHighlightFillcolor: NSUIColor? { get set }
    var nonHighlightStrokecolor: NSUIColor? { get set }
}
