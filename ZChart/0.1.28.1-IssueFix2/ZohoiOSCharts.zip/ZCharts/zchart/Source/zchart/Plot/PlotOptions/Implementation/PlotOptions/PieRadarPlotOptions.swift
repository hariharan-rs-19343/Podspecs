//
//  PieRadarPlotOptions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 17/01/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation


///To declare Pie Types
public enum PieType
{
    case PieSpinWheel
    case Type2
}

open class PieRadarPlotOptions : PlotOptionsBase
{
       weak var prevSelectedEntry:ChartDataEntry?
       
       open var pieComponents:Components = Components()
       
       /// check pattern enabled or not
       open var patternEnabled:Bool = true
       
       // To check rotation
       var spinning = false
       
       open var changedRadius:CGFloat = 0
       
       open var filterProgress:Bool = false
       
       open var fadeSlice:Bool = false
       
       // Holds opacity value for slice fades
       open var fadeFactor:CGFloat = 1.0
       
       /// holds the normalized version of the current rotation angle of the chart
       fileprivate var _rotationAngle = CGFloat(270.0)
       
       /// holds the raw version of the current rotation angle of the chart
       fileprivate var _rawRotationAngle = CGFloat(270.0)
       
       /// flag that indicates if rotation is enabled or not
       open var rotationEnabled = true
       
       /// Sets the minimum offset (padding) around the chart, defaults to 0.0
       open var minOffset = CGFloat(0.0)
       
       /// current rotation angle of the pie chart
       ///
       /// **default**: 270 --> top (NORTH)
       /// - returns: Will always return a normalized value, which will be between 0.0 < 360.0
       open var rotationAngle: CGFloat
           {
           get
           {
               return _rotationAngle
           }
           set
           {
               _rawRotationAngle = newValue
               _rotationAngle = ChartUtils.normalizedAngleFromAngle(newValue)
           }
       }
       
       /// gets the raw version of the current rotation angle of the pie chart the returned value could be any value, negative or positive, outside of the 360 degrees.
       /// this is used when working with rotation direction, mainly by gestures and animations.
       open var rawRotationAngle: CGFloat
       {
           return _rawRotationAngle
       }
       
       /// - returns: The radius of the chart in pixels.
       open var radius: CGFloat
       {
           fatalError("radius cannot be called on PieRadarChartViewBase")
       }
       
       /// - returns: The required offset for the chart legend.
       internal var requiredLegendOffset: CGFloat
       {
           fatalError("requiredLegendOffset cannot be called on PieRadarChartViewBase")
       }
    
       
       open var isRotationEnabled: Bool { return rotationEnabled }
       
       
       /// reference to the last highlighted object
       fileprivate var _lastHighlight: Highlight!
    
       open var _spinAnimator: Animator!
    
       // MARK: - Gestures
       
       internal var _rotationGestureStartPoint: CGPoint!
       open var _isRotating = false
       internal var _startAngle = CGFloat(0.0)
       
       internal struct AngularVelocitySample
       {
           var time: TimeInterval
           var angle: CGFloat
       }
       
       internal var _velocitySamples = [AngularVelocitySample]()
    
    
    // MARK: - NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! PieRadarPlotOptions
        
        copy.patternEnabled = patternEnabled
        
        copy.spinning = spinning
        
        copy.fadeSlice = fadeSlice
        
        copy.fadeFactor = fadeFactor
        
        copy._rotationAngle = _rotationAngle
        
        copy._rawRotationAngle = _rawRotationAngle
        
        copy.rotationEnabled = rotationEnabled
        
        copy.minOffset = minOffset
        
        copy._isRotating = _isRotating
        
        copy._startAngle = _startAngle
        
        return copy
    }
    
    // MARK: - Codable
    
        enum pieRadarPlotOptionsCodingKeys: CodingKey {
                case mRotationAngle
           }
    
    public  required  init(from decoder: Decoder) throws {
        try super.init(from: decoder)
        
        let container = try decoder.container(keyedBy: pieRadarPlotOptionsCodingKeys.self)
        
        rotationAngle = try container.decode(CGFloat.self, forKey: .mRotationAngle)
        }
    
    public  required init() {
        super.init()
    }
    
    
    public  override func encode(to encoder: Encoder) throws {

        }
        
}
