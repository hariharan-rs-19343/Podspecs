//
//  WaterFallPlotOptions.swift
//  zchart
//
//  Created by keerthi-pt4274 on 27/06/22.
//

import Foundation

open class WaterFallPlotOptions: BarPlotOptions {

    fileprivate var _connectorEnabled: Bool = true
    
    internal var isConnectorEnabled: Bool = true
    
    open var connectorEnabled: Bool {
        get{
            return _connectorEnabled
        }
        set{
            _connectorEnabled = newValue
            isConnectorEnabled = newValue
        }
    }
    
    open var connectorStrokecolor: NSUIColor = NSUIColor.black
    
    open var connectorLineWidth: Double = 1.0
    
    open var connectorDashPhase = CGFloat(0.0)
    
    open var connectorDashLengths: [CGFloat]?
    
    open var connectorCapType: CAShapeLayerLineCap = .round
    
    open var isconnectorLineEnabledForZeroAndNan: Bool = false
    
    public required init() {
        super.init()
    }
    
    // MARK: - Codable
    
    enum WaterFallPlotOptionsCodingKeys: CodingKey {
           
        case isConnectorLineEnabled
        case connectorLineColor
        case connectorLineStrokeWidth
        case isZeroLineEnabled
                
    }
    
    required public init(from decoder: Decoder) throws {
        try super.init(from: decoder)
        let container = try decoder.container(keyedBy: WaterFallPlotOptionsCodingKeys.self)
                
        connectorEnabled = try container.decode(Bool.self, forKey: .isConnectorLineEnabled)
        
        let colorCode = try container.decode(Int.self, forKey: .connectorLineColor)
        
        connectorStrokecolor = NSUIColor(rgb: colorCode)
        
        connectorLineWidth = Double(try container.decode(Int.self, forKey: .connectorLineStrokeWidth))
        
        isconnectorLineEnabledForZeroAndNan = try container.decode(Bool.self, forKey: .isZeroLineEnabled)
    }
    
    public  override func encode(to encoder: Encoder) throws {
        
    }
}
