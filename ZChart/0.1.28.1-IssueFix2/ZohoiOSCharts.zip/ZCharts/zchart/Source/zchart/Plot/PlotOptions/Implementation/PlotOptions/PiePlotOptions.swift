//
//  PiePlotOptions.swift
//  zchart
//
//  Created by Aravinth T on 01/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

public enum SliceDirection
{
    case clockwise
    case counterClockwise
}

open class PiePlotOptions : PieRadarPlotOptions
{
      /// Spinwheel type Enable/Disable
        open var arrowShow = false
        
        var centerTextFormatter:ICenterTextFormatter = DefaultCenterTextFormatter()
        
    //TODO FOR OSX
    #if os(iOS)
        var centerTextInstance = CenterText()
        
        var centerLabel:UILabel
        {
            get{
               return centerTextInstance.plabel!
            }
        }
    #endif
         open var innerCircleEnabled:Bool = true
        
         open var outerCircleEnabled:Bool = true
        
         open var centerLabelEnabled:Bool = true
        
        open var sliceDirection:SliceDirection = .clockwise
        
        /// rect object that represents the bounds of the piechart, needed for drawing the circle
        internal var _circleBox = CGRect()
        
        /// flag indicating if entry labels should be drawn or not
        fileprivate var _drawEntryLabelsEnabled = true
        
        /// array that holds the width of each pie-slice in degrees
        fileprivate var _drawAngles = [CGFloat]()
        
        /// array that holds the absolute angle in degrees of each slice
        fileprivate var _absoluteAngles = [CGFloat]()
        
        /// if true, the hole inside the chart will be drawn
        fileprivate var _drawHoleEnabled = true
        
        fileprivate var _holeColor: NSUIColor? = NSUIColor.white
        
        /// Sets the color the entry labels are drawn with.
        fileprivate var _entryLabelColor: NSUIColor? = NSUIColor.white
        
        /// Sets the font the entry labels are drawn with.
        fileprivate var _entryLabelFont: NSUIFont? = NSUIFont(name: "HelveticaNeue", size: 13.0)
        
        /// if true, the hole will see-through to the inner tips of the slices
        fileprivate var _drawSlicesUnderHoleEnabled = false
        
        /// if true, the values inside the piechart are drawn as percent values
        fileprivate var _usePercentValuesEnabled = false
        
        /// variable for the text that is drawn in the center of the pie-chart
        fileprivate var _centerAttributedText: NSAttributedString?
        
        /// the offset on the x- and y-axis the center text has in dp.
        fileprivate var _centerTextOffset: CGPoint = CGPoint()
        
        /// indicates the size of the hole in the center of the piechart
        ///
        /// **default**: `0.5`
        fileprivate var _holeRadiusPercent = CGFloat(0.5)
        
        fileprivate var _transparentCircleColor: NSUIColor? = NSUIColor(white: 1.0, alpha: 105.0/255.0)
        
        /// the radius of the transparent circle next to the chart-hole in the center
        fileprivate var _transparentCircleRadiusPercent = CGFloat(0.55)
        
        /// if enabled, centertext is drawn
        fileprivate var _drawCenterTextEnabled = true
        
        fileprivate var _centerTextRadiusPercent: CGFloat = 1.0
        
        /// maximum angle for this pie
        fileprivate var _maxAngle: CGFloat = 360.0
        
        /// - returns: An integer array of all the different angles the chart slices
        /// have the angles in the returned array determine how much space (of 360°)
        /// each slice takes
        open var drawAngles: [CGFloat]
        {
            get{
                return _drawAngles
            }
            set(newValue)
            {
                _drawAngles = newValue
            }
        }

        /// - returns: The absolute angles of the different chart slices (where the
        /// slices end)
        open var absoluteAngles: [CGFloat]
        {
            get{
                return _absoluteAngles
            }
            set(newValue)
            {
                _absoluteAngles = newValue
            }
        }
        
        /// The color for the hole that is drawn in the center of the PieChart (if enabled).
        ///
        /// - note: Use holeTransparent with holeColor = nil to make the hole transparent.*
        open var holeColor: NSUIColor?
        {
            get
            {
                return _holeColor
            }
            set
            {
                _holeColor = newValue
//                setNeedsDisplay()
            }
        }
        
        /// if true, the hole will see-through to the inner tips of the slices
        ///
        /// **default**: `false`
        open var drawSlicesUnderHoleEnabled: Bool
        {
            get
            {
                return _drawSlicesUnderHoleEnabled
            }
            set
            {
                _drawSlicesUnderHoleEnabled = newValue
//                setNeedsDisplay()
            }
        }
        
        /// - returns: `true` if the inner tips of the slices are visible behind the hole, `false` if not.
        open var isDrawSlicesUnderHoleEnabled: Bool
        {
            return drawSlicesUnderHoleEnabled
        }
        
        /// `true` if the hole in the center of the pie-chart is set to be visible, `false` ifnot
        open var drawHoleEnabled: Bool
        {
            get
            {
                return _drawHoleEnabled
            }
            set
            {
                _drawHoleEnabled = newValue
                innerCircleEnabled = !newValue
//                setNeedsDisplay()
            }
        }
        
        /// - returns: `true` if the hole in the center of the pie-chart is set to be visible, `false` ifnot
        open var isDrawHoleEnabled: Bool
        {
            get
            {
                return drawHoleEnabled
            }
        }
        
        /// the text that is displayed in the center of the pie-chart
        open var centerText: String?
        {
            get
            {
                return self.centerAttributedText?.string
            }
            set
            {
                var attrString: NSMutableAttributedString?
                if newValue == nil
                {
                    attrString = nil
                }
                else
                {
                    #if os(OSX)
                        let paragraphStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
                    #else
                        let paragraphStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
                    #endif
                    if centerTextWordWrapEnabled
                    {
                        paragraphStyle.lineBreakMode = NSLineBreakMode.byWordWrapping
                    }
                    else{
                        paragraphStyle.lineBreakMode = NSLineBreakMode.byTruncatingTail
                    }
                    paragraphStyle.alignment = .center
                    
                    attrString = NSMutableAttributedString(string: newValue!)
                    attrString?.setAttributes([
                        NSAttributedString.Key.foregroundColor: centerTextColor,
                        NSAttributedString.Key.font: centerTextFont,
                        NSAttributedString.Key.paragraphStyle: paragraphStyle
                        ], range: NSMakeRange(0, attrString!.length))
                }
                self.centerAttributedText = attrString
            }
        }
    
        open var centerTextWordWrapEnabled:Bool = true
            
        open var centerTextFont = NSUIFont.systemFont(ofSize: 12.0)
    
        open var centerTextColor = NSUIColor.black
        
        /// the text that is displayed in the center of the pie-chart
        open var centerAttributedText: NSAttributedString?
        {
            get
            {
                return _centerAttributedText
            }
            set
            {
                _centerAttributedText = newValue
//                setNeedsDisplay()
            }
        }
        
        /// Sets the offset the center text should have from it's original position in dp. Default x = 0, y = 0
        open var centerTextOffset: CGPoint
        {
            get
            {
                return _centerTextOffset
            }
            set
            {
                _centerTextOffset = newValue
//                setNeedsDisplay()
            }
        }
        
        /// `true` if drawing the center text is enabled
        open var drawCenterTextEnabled: Bool
        {
            get
            {
                return _drawCenterTextEnabled
            }
            set
            {
                _drawCenterTextEnabled = newValue
//                setNeedsDisplay()
            }
        }
        
        /// - returns: `true` if drawing the center text is enabled
        open var isDrawCenterTextEnabled: Bool
        {
            get
            {
                return drawCenterTextEnabled
            }
        }
        
        
        
        internal var requiredBaseOffset: CGFloat = 0
        
        internal var internalRadius:CGFloat = 0.0
        
        open override var radius: CGFloat    {
            set  {
                internalRadius = newValue
//                if newValue < 20
//                {
//                    internalRadius = 20
//                }
//                setNeedsDisplay()
            }
            get  {
                if internalRadius != 0
                {
                    return internalRadius
                }
                return _circleBox.width / 2
            }
        }
        
        /// - returns: The circlebox, the boundingbox of the pie-chart slices
        open var circleBox: CGRect
        {
            return _circleBox
        }
        
        /// - returns: The center of the circlebox
        open var centerCircleBox: CGPoint
        {
            return PieHelperFunctions.updateCenterPointValue(centerPoint: CGPoint(x: _circleBox.midX, y: _circleBox.midY), startAngle: self.rotationAngle, maxAngle: self.maxAngle, direction: self.sliceDirection, radius: radius)
    //        return CGPoint(x: _circleBox.midX, y: _circleBox.midY)
        }
        
        /// the radius of the hole in the center of the piechart in percent of the maximum radius (max = the radius of the whole chart)
        ///
        /// **default**: 0.5 (50%) (half the pie)
        open var holeRadiusPercent: CGFloat
        {
            get
            {
                return _holeRadiusPercent
            }
            set
            {
                var percent = newValue
                
                if newValue > 1 || newValue < 0
                {
                    percent = 0.5
                }
                
                _holeRadiusPercent = percent
            }
        }
        
        /// The color that the transparent-circle should have.
        ///
        /// **default**: `nil`
        open var transparentCircleColor: NSUIColor?
        {
            get
            {
                return _transparentCircleColor
            }
            set
            {
                _transparentCircleColor = newValue
            }
        }
        
        /// the radius of the transparent circle that is drawn next to the hole in the piechart in percent of the maximum radius (max = the radius of the whole chart)
        ///
        /// **default**: 0.55 (55%) -> means 5% larger than the center-hole by default
        open var transparentCircleRadiusPercent: CGFloat
        {
            get
            {
                return _transparentCircleRadiusPercent
            }
            set
            {
                _transparentCircleRadiusPercent = newValue
            }
        }
        
        /// The color the entry labels are drawn with.
        open var entryLabelColor: NSUIColor?
        {
            get { return _entryLabelColor }
            set
            {
                _entryLabelColor = newValue
            }
        }
        
        /// The font the entry labels are drawn with.
        open var entryLabelFont: NSUIFont?
        {
            get { return _entryLabelFont }
            set
            {
                _entryLabelFont = newValue
            }
        }
        
        /// To maintain given label state
        internal var labelsEnabled:Bool = true
        
        /// One Time allow Property
        fileprivate var allowed:Bool = true
        
        /// Set this to true to draw the enrty labels into the pie slices
        open var drawEntryLabelsEnabled: Bool
        {
            get
            {
                return _drawEntryLabelsEnabled
            }
            set
            {
                _drawEntryLabelsEnabled = newValue
                
                if allowed
                {
                    labelsEnabled = newValue
                    allowed = false
                }
            }
        }
        
        /// - returns: `true` if drawing entry labels is enabled, `false` ifnot
        open var isDrawEntryLabelsEnabled: Bool
        {
            get
            {
                return drawEntryLabelsEnabled
            }
        }
        
        /// If this is enabled, values inside the PieChart are drawn in percent and not with their original value. Values provided for the ValueFormatter to format are then provided in percent.
        open var usePercentValuesEnabled: Bool
        {
            get
            {
                return _usePercentValuesEnabled
            }
            set
            {
                _usePercentValuesEnabled = newValue
            }
        }
        
        /// - returns: `true` if drawing x-values is enabled, `false` ifnot
        open var isUsePercentValuesEnabled: Bool
        {
            get
            {
                return usePercentValuesEnabled
            }
        }
        
        /// the rectangular radius of the bounding box for the center text, as a percentage of the pie hole
        open var centerTextRadiusPercent: CGFloat
        {
            get
            {
                return _centerTextRadiusPercent
            }
            set
            {
                _centerTextRadiusPercent = newValue
            }
        }
        
        /// The max angle that is used for calculating the pie-circle.
        /// 360 means it's a full pie-chart, 180 results in a half-pie-chart.
        /// **default**: 360.0
        open var maxAngle: CGFloat
        {
            get
            {
                return _maxAngle
            }
            set
            {
                _maxAngle = newValue
                
                if _maxAngle > 360.0
                {
                    _maxAngle = 360.0
                }
                
                if _maxAngle <= 0
                {
                    _maxAngle = 5
                }
            }
        }
        
        var spinAnimator: Animator!
        
        
        @objc(PieChartValuePosition)
        public enum ValuePosition: Int
        {
            case insideSlice
            case outsideSlice
        }
               
        // MARK: - Styling functions and accessors
        
        fileprivate var _sliceSpace = CGFloat(0.0)
        
        /// the space in pixels between the pie-slices
        /// **default**: 0
        /// **maximum**: 20
        open var sliceSpace: CGFloat
        {
            get
            {
                return _sliceSpace
            }
            set
            {
                var space = newValue
                if space > 20.0
                {
                    space = 20.0
                }
                if space < 0.0
                {
                    space = 0.0
                }
                _sliceSpace = space
            }
        }

        /// When enabled, slice spacing will be 0.0 when the smallest value is going to be smaller than the slice spacing itself.
        open var automaticallyDisableSliceSpacing: Bool = false
        
        /// indicates the selection distance of a pie slice
        open var selectionShift = CGFloat(18.0)
        
        open var xValuePosition: ValuePosition = .insideSlice
    
        open var yValuePosition: ValuePosition = .insideSlice
        
        open var drawLargeValue:Bool = true
        
        /// When valuePosition is OutsideSlice, indicates line color
        open var valueLineColor: NSUIColor? = NSUIColor.black
        
        /// When valuePosition is OutsideSlice, indicates line width
        open var valueLineWidth: CGFloat = 1.0
        
        /// When valuePosition is OutsideSlice, indicates offset as percentage out of the slice size
        open var valueLinePart1OffsetPercentage: CGFloat = 0.75
        
        /// When valuePosition is OutsideSlice, indicates length of first half of the line
        open var valueLinePart1Length: CGFloat = 0.3
        
        /// When valuePosition is OutsideSlice, indicates length of second half of the line
        open var valueLinePart2Length: CGFloat = 0.4
        
        /// When valuePosition is OutsideSlice, this allows variable line length
        open var valueLineVariableLength: Bool = true
   
        open var outerCircleColor:NSUIColor = NSUIColor.gray.withAlphaComponent(0.3)
    
        open var outerCircleLineWidth:CGFloat?
        
    
    // MARK: - NSCopying
    
    @objc open override func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
        let copy = super.copyWithZone(zone) as! PiePlotOptions
        
        copy.arrowShow = false
        
        #if os(iOS)
        copy.centerTextInstance = CenterText()
        #endif
    
        copy.innerCircleEnabled = innerCircleEnabled
        
        copy.outerCircleEnabled = outerCircleEnabled
        
        copy.centerLabelEnabled = centerLabelEnabled
        
        copy.sliceDirection = sliceDirection
        
        copy._drawEntryLabelsEnabled = _drawEntryLabelsEnabled
        
        copy._drawHoleEnabled = _drawHoleEnabled
        
        copy._holeColor = _holeColor
        
        copy._entryLabelColor = _entryLabelColor
        
        copy._entryLabelFont = _entryLabelFont
        
        copy._drawSlicesUnderHoleEnabled = _drawSlicesUnderHoleEnabled
        
        copy._usePercentValuesEnabled = _usePercentValuesEnabled
        
        copy._centerAttributedText = _centerAttributedText
        
        copy._holeRadiusPercent = _holeRadiusPercent
        
        copy._transparentCircleColor = _transparentCircleColor
        
        copy._transparentCircleRadiusPercent = _transparentCircleRadiusPercent
        
        copy._drawCenterTextEnabled = _drawCenterTextEnabled
        
        copy._centerTextRadiusPercent = _centerTextRadiusPercent
        
        copy._maxAngle = _maxAngle
        
        copy.requiredBaseOffset = requiredBaseOffset
        
        copy.internalRadius = internalRadius
        
        copy.labelsEnabled = labelsEnabled
        
        copy._sliceSpace = _sliceSpace
        copy.automaticallyDisableSliceSpacing = automaticallyDisableSliceSpacing
        copy.selectionShift = selectionShift
        copy.xValuePosition = xValuePosition
        copy.yValuePosition = yValuePosition
        copy.drawLargeValue = drawLargeValue
        copy.valueLineColor = valueLineColor
        copy.valueLineWidth = valueLineWidth
        copy.valueLinePart1OffsetPercentage = valueLinePart1OffsetPercentage
        copy.valueLinePart1Length = valueLinePart1Length
        copy.valueLinePart2Length = valueLinePart2Length
        copy.valueLineVariableLength = valueLineVariableLength
        copy.entryLabelFont = entryLabelFont
        copy.entryLabelColor = entryLabelColor
        
        return copy
    }
    
    // MARK: - Codable
    
        enum piePlotOptionsCodingKeys: CodingKey {
           
            case isCenterCircleEnabled
            case isInnerRingEnabled
            case isOuterRingEnabled
            case mCenterTextRadiusPercent
            case mDrawHole
            case mHoleRadiusPercent
            case mTransparentCircleRadiusPercent
            case mUsePercentValues
            case mValueLineColor
            case mValueLinePart1Length
            case mValueLinePart2Length
            case mValueLinePart1OffsetPercentage
            case mValueLineVariableLength
            case mValueLineWidth
            case mXValuePosition
            case mYValuePosition
            case isClockWiseDirection
            case mDrawCenterText
            case mMaxAngle
           }
    
        required public  init(from decoder: Decoder) throws {
            try super.init(from: decoder)
            let container = try decoder.container(keyedBy: piePlotOptionsCodingKeys.self)
            
            innerCircleEnabled = container.contains(.isCenterCircleEnabled) ? try container.decode(Bool.self, forKey: .isCenterCircleEnabled) : innerCircleEnabled
            
            let innerRingEnabled = container.contains(.isInnerRingEnabled) ? try container.decode(Bool.self, forKey: .isInnerRingEnabled) : false
            transparentCircleColor = innerRingEnabled ? transparentCircleColor : NSUIColor.clear
            
            outerCircleEnabled = container.contains(.isOuterRingEnabled) ? try container.decode(Bool.self, forKey: .isOuterRingEnabled) : outerCircleEnabled
            
            centerTextRadiusPercent = container.contains(.mCenterTextRadiusPercent) ? (try container.decode(CGFloat.self, forKey: .mCenterTextRadiusPercent))/100 : centerTextRadiusPercent
            
            drawHoleEnabled = container.contains(.mDrawHole) ? try container.decode(Bool.self, forKey: .mDrawHole) : drawHoleEnabled
            
            holeRadiusPercent = container.contains(.mHoleRadiusPercent) ? try container.decode(CGFloat.self, forKey: .mHoleRadiusPercent) : holeRadiusPercent
            
            transparentCircleRadiusPercent = container.contains(.mTransparentCircleRadiusPercent) ? (try container.decode(CGFloat.self, forKey: .mTransparentCircleRadiusPercent))/100 : transparentCircleRadiusPercent
            
            usePercentValuesEnabled = container.contains(.mUsePercentValues) ? try container.decode(Bool.self, forKey: .mUsePercentValues) : usePercentValuesEnabled
            
            let colorsCode = container.contains(.mValueLineColor) ? try container.decode(Int.self, forKey: .mValueLineColor) : -1
            valueLineColor = colorsCode == -1 ? valueLineColor : NSUIColor(rgb:colorsCode)
            
            valueLinePart1Length = container.contains(.mValueLinePart1Length) ? try container.decode(CGFloat.self, forKey: .mValueLinePart1Length) : valueLinePart1Length
            
            valueLinePart2Length = container.contains(.mValueLinePart2Length) ? try container.decode(CGFloat.self, forKey: .mValueLinePart2Length) : valueLinePart2Length
            
            valueLinePart1OffsetPercentage = container.contains(.mValueLinePart1OffsetPercentage) ? (try container.decode(CGFloat.self, forKey: .mValueLinePart1OffsetPercentage))/100 : valueLinePart1OffsetPercentage
            
            valueLineVariableLength = container.contains(.mValueLineVariableLength) ? try container.decode(Bool.self, forKey: .mValueLineVariableLength) : valueLineVariableLength
            
            valueLineWidth = container.contains(.mValueLineWidth) ? try container.decode(CGFloat.self, forKey: .mValueLineWidth) : valueLineWidth
            
            let xValuePositionString = container.contains(.mXValuePosition) ? try container.decode(String.self, forKey: .mXValuePosition) : "INSIDE_SLICE"
            xValuePosition = xValuePositionString == "INSIDE_SLICE" ? .insideSlice : .outsideSlice
            
            let yValuePositionString = container.contains(.mYValuePosition) ? try container.decode(String.self, forKey: .mYValuePosition) : "INSIDE_SLICE"
            yValuePosition = yValuePositionString == "INSIDE_SLICE" ? .insideSlice : .outsideSlice
            
            let isClockWiseDirection = container.contains(.isClockWiseDirection) ? try container.decode(Bool.self, forKey: .isClockWiseDirection) : true
            sliceDirection = isClockWiseDirection ? .clockwise : .counterClockwise
            
            drawCenterTextEnabled = container.contains(.mDrawCenterText) ? try container.decode(Bool.self, forKey: .mDrawCenterText) : drawCenterTextEnabled
            
            maxAngle = container.contains(.mMaxAngle) ? try container.decode(CGFloat.self, forKey: .mMaxAngle) : maxAngle
        }
    
    public  required init() {
        super.init()
    }
    
    public  override func encode(to encoder: Encoder) throws {
    //        var container = encoder.container(keyedBy: CodingKeys.self)
    //        try container.encode(x, forKey: .x)
        }
           
}
