//
//  AxisChartDataSetOptions.swift
//  zchart
//
//  Created by Aravinth T on 06/11/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class AxisChartDataSetOptions : NSObject, IDataSetOptions, Codable
{
    // MARK: - Data functions and accessors
    
    // Holds all the shape properties
    open var shapeProperties = ShapeProperties()
    
    open var drawShapeEnabled: Bool = true
    
    // MARK: - Styling functions and accessors
    
    open var highlightColor = NSUIColor(red: 255.0/255.0, green: 187.0/255.0, blue: 115.0/255.0, alpha: 1.0)
    open var highlightLineWidth = CGFloat(0.5)
    open var highlightLineDashPhase = CGFloat(0.0)
    open var highlightLineDashLengths: [CGFloat]?
    
    open var nonHighlightFillcolor: NSUIColor?
    open var nonHighlightStrokecolor: NSUIColor?
    
    public required override init() {
        super.init()
    }
    
    // MARK: - NSCopying
    
    @objc open func copyWithZone(_ zone: NSZone?) -> AnyObject
    {
         let copy = type(of: self).init()
        
         copy.shapeProperties = shapeProperties
         copy.drawShapeEnabled = drawShapeEnabled
         copy.highlightColor = highlightColor
         copy.highlightLineWidth = highlightLineWidth
         copy.highlightLineDashPhase = highlightLineDashPhase
         copy.highlightLineDashLengths = highlightLineDashLengths
        
        copy.nonHighlightFillcolor = nonHighlightFillcolor
        copy.nonHighlightStrokecolor = nonHighlightStrokecolor
        
         return copy
    }
    
    // MARK: - Codable
    
        enum CodingKeys: CodingKey {
                case shapeProperties
                case drawShapeEnabled
           }
    
        required public  init(from decoder: Decoder) throws {
            super.init()
            
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            shapeProperties = try container.decode(ShapeProperties.self, forKey: .shapeProperties)
            drawShapeEnabled = try container.decode(Bool.self, forKey: .drawShapeEnabled)
           
        }
    
        public  func encode(to encoder: Encoder) throws {
  
        }
    
    
    
}
