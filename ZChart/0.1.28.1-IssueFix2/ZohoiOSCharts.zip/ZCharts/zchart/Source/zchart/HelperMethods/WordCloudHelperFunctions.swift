//
//  WordCloudHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 18/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import Foundation

open class WordCloudHelperFunctions {
    
    
    public static func getDictOfInvisibleWord(chart:ChartViewBase, setIndex:Int, entryIndex:Int) -> [String:Any]?
    {
        guard let processor = (chart.getProcessor(type: .WordCloud) as? WordCloudPreprocessor)
        else { return nil}
        for i in 0..<processor._buffers.count
        {
            let dict = processor._buffers[i]
            
            guard (dict["setIndex"] as? Int) != nil,
                  (dict["entryIndex"] as? Int) != nil
            else { continue }
            
            if (dict["setIndex"] as! Int) == setIndex
            {
                if (dict["entryIndex"] as! Int) == entryIndex
                {
                    return dict
                }
            }
        }
        return nil
    }
    
    // MARK:  WordCloud Filter In/Out Handling
    
    public static func removeWorldCloudEntriesWithAnimation(entries: [ChartDataEntry], chart:ChartViewBase, duration:TimeInterval) {
        
        guard let data = chart.data,
              let processor = chart.getProcessor(type: .WordCloud) as? WordCloudPreprocessor
            else { return }
        
        chart.interactionAnimationInProgress = true
        chart.lastSelected = nil
        
        for plotOption in (chart.plotOptions.values)
        {
            guard let plot = plotOption as? PlotOptionsBase
            else { continue }
            plot.barGroupSelectionEnabled = false
        }
        
        for entry in entries
        {
            entry.filterEnabled = true
        }
        
        var layersToHide:[CALayer] = []
        
        for e in entries
        {
            guard let text = WordCloudTextLayer.getWordTextLayerForEntry(chart: chart, entry: e)
            else { continue }
            layersToHide.append(text)
        }
        
        let opacAnimator = Animator()
        
        let opacInterpolator = Interpolator.interpolate(a: Double(1), b: Double(0))
        
        opacAnimator.updateBlock = {
                        
         layersToHide.forEach({ layer in
             layer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
         })
         
        }
        
        opacAnimator.stopBlock = { [unowned opacAnimator] in
            
            opacAnimator.updateBlock = nil
        
            let fromBuffer = processor._buffers
            
            processor.isWebViewLoadAllowed = false
            
            chart.notifyDataSetChanged(redrawRequired: false)
            
            let completionBlock = {
                let toBuffer = processor._buffers
                
                let newBlock = {
                processor._buffers = fromBuffer
                
                var xInterpolateArray:[((CGFloat) -> CGFloat)] = []
                var yInterpolateArray:[((CGFloat) -> CGFloat)] = []
                var sizeInterpolateArray:[((CGFloat) -> CGFloat)] = []
                var rotationInterpolateArray:[((CGFloat) -> CGFloat)] = []
                
                var toBufferIndex = -1
                for i in 0..<fromBuffer.count
                {
                    let fromDict = fromBuffer[i]
                    
                    guard (fromDict["setIndex"] as? Int) != nil,
                          (fromDict["entryIndex"] as? Int) != nil
                    else { continue }
                    
                    let set = data.dataSets[(fromDict["setIndex"] as? Int)!]
                    
                    guard let entry = set.entryForIndex((fromDict["entryIndex"] as? Int)!)
                    else { continue }
                    
                    if !(entry.filterEnabled)
                    {
                        toBufferIndex += 1
                        
                        let toDict = toBuffer[toBufferIndex]
                        
                        guard (fromDict["x"] as? CGFloat) != nil,
                              (fromDict["y"] as? CGFloat) != nil,
                              (fromDict["fontSize"] as? CGFloat) != nil,
                              (fromDict["rotation"] as? CGFloat) != nil,
                              
                              (toDict["x"] as? CGFloat) != nil,
                              (toDict["y"] as? CGFloat) != nil,
                              (toDict["fontSize"] as? CGFloat) != nil,
                              (toDict["rotation"] as? CGFloat) != nil
                        else { continue }
                        
                        let xValInterpolate = Interpolator.interpolate(a: fromDict["x"] as! CGFloat, b: toDict["x"] as! CGFloat)
                        let yValInterpolate = Interpolator.interpolate(a: fromDict["y"] as! CGFloat, b: toDict["y"] as! CGFloat)
                        let sizeValInterpolate = Interpolator.interpolate(a: fromDict["fontSize"] as! CGFloat, b: toDict["fontSize"] as! CGFloat)
                        let rotationInterpolate = Interpolator.interpolate(a: fromDict["rotation"] as! CGFloat, b: toDict["rotation"] as! CGFloat)
                        
                        xInterpolateArray.append(xValInterpolate)
                        yInterpolateArray.append(yValInterpolate)
                        sizeInterpolateArray.append(sizeValInterpolate)
                        rotationInterpolateArray.append(rotationInterpolate)
                        
                    }
                }
                
                let textAnimation = Animator()
                
                textAnimation.updateBlock = {
                    
                    toBufferIndex = -1
                    
                    for i in 0..<fromBuffer.count
                    {
                        let fromDict = fromBuffer[i]
                        
                        let set = data.dataSets[fromDict["setIndex"] as! Int]
                        guard let entry = set.entryForIndex(fromDict["entryIndex"] as! Int)
                        else { continue }
                        
                        if !(entry.filterEnabled)
                        {
                            toBufferIndex += 1
                    
                            processor._buffers[i]["x"] = xInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                            processor._buffers[i]["y"] = yInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                            processor._buffers[i]["fontSize"] = sizeInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                            processor._buffers[i]["rotation"] = rotationInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                        }
                    }
                    chart.calculateOffsets()
                    chart.setNeedsDisplay()
                    
                }
                
                textAnimation.stopBlock = { [unowned textAnimation] in
                    
                    textAnimation.updateBlock = nil
                   
                    chart.interactionAnimationInProgress = false
                    
                    chart.lastSelected = nil
                    
                    processor._buffers = toBuffer
                    
                    processor.isWebViewLoadAllowed = true
                    
                    chart.delegateToContainer?.chartValueRemoved?(chart, entries: entries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
                }
                
                textAnimation.animate(xAxisDuration: duration * 0.7)
               
            }
                newBlock()
            }
            
            processor.prepareDataAndBuffer(redraw: false, completionBlock:completionBlock)
        }
        
        opacAnimator.animate(xAxisDuration: duration * 0.3)
    }
    
    public static func includeWordCloudEntriesWithAnimations(entries:[ChartDataEntry], chart:ChartViewBase, duration:TimeInterval)
    {
        guard let data = chart.data,
              let processor = chart.getProcessor(type: .WordCloud) as? WordCloudPreprocessor
        else { return }
        
        chart.interactionAnimationInProgress = true
        chart.lastSelected = nil
        
        for plotOption in (chart.plotOptions.values)
        {
            guard let plot = plotOption as? PlotOptionsBase
            else { continue }
            plot.barGroupSelectionEnabled = false
        }
        
        let fromBuffer = processor._buffers
        
        for e in entries
        {
            e.filterEnabled = false
        }
        
        data.notifyDataChanged()
        
        processor.isWebViewLoadAllowed = false
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        let completionBlock = {
            
            let toBuffer = processor._buffers
            
            processor._buffers = fromBuffer
            
            for e in entries
            {
                e.filterEnabled = true
            }
            
            var xInterpolateArray:[((CGFloat) -> CGFloat)] = []
            var yInterpolateArray:[((CGFloat) -> CGFloat)] = []
            var sizeInterpolateArray:[((CGFloat) -> CGFloat)] = []
            var rotationInterpolateArray:[((CGFloat) -> CGFloat)] = []
            
            var fromBufferIndex = -1
            for i in 0..<toBuffer.count
            {
                let toDict = toBuffer[i]
                
                guard (toDict["setIndex"] as? Int) != nil,
                      (toDict["entryIndex"] as? Int) != nil
                else { continue }
                let set = data.dataSets[toDict["setIndex"] as! Int]
                guard let entry = set.entryForIndex(toDict["entryIndex"] as! Int)
                else { continue }
                
                if entry.filterEnabled
                {
                    continue
                }
                
                fromBufferIndex += 1
                let fromDict = fromBuffer[fromBufferIndex]
                
                guard (fromDict["x"] as? CGFloat) != nil,
                      (fromDict["y"] as? CGFloat) != nil,
                      (fromDict["fontSize"] as? CGFloat) != nil,
                      (fromDict["rotation"] as? CGFloat) != nil,
                      
                      (toDict["x"] as? CGFloat) != nil,
                      (toDict["y"] as? CGFloat) != nil,
                      (toDict["fontSize"] as? CGFloat) != nil,
                      (toDict["rotation"] as? CGFloat) != nil
                else { continue }
                
                let xValInterpolate = Interpolator.interpolate(a: fromDict["x"] as! CGFloat, b: toDict["x"] as! CGFloat)
                let yValInterpolate = Interpolator.interpolate(a: fromDict["y"] as! CGFloat, b: toDict["y"] as! CGFloat)
                let sizeValInterpolate = Interpolator.interpolate(a: fromDict["fontSize"] as! CGFloat, b: toDict["fontSize"] as! CGFloat)
                let rotationInterpolate = Interpolator.interpolate(a: fromDict["rotation"] as! CGFloat, b: toDict["rotation"] as! CGFloat)
                
                xInterpolateArray.append(xValInterpolate)
                yInterpolateArray.append(yValInterpolate)
                sizeInterpolateArray.append(sizeValInterpolate)
                rotationInterpolateArray.append(rotationInterpolate)
                    
                
            }
            
            let textAnimation = Animator()
            
            textAnimation.updateBlock = {
                
                fromBufferIndex = -1
                
                for i in 0..<toBuffer.count
                {
                    let toDict = toBuffer[i]
                    
                    let set = data.dataSets[toDict["setIndex"] as! Int]
                    guard let entry = set.entryForIndex(toDict["entryIndex"] as! Int)
                    else { continue }
                    
                    if entry.filterEnabled
                    {
                        continue
                    }
                    
                    fromBufferIndex += 1
                    
                    processor._buffers[fromBufferIndex]["x"] = xInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    processor._buffers[fromBufferIndex]["y"] = yInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    processor._buffers[fromBufferIndex]["fontSize"] = sizeInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    processor._buffers[fromBufferIndex]["rotation"] = rotationInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    
                }
                chart.calculateOffsets()
                chart.setNeedsDisplay()
                
            }
            
            textAnimation.stopBlock = { [unowned textAnimation] in
                
                textAnimation.updateBlock = nil
        
                processor._buffers = toBuffer
                
                var layersToShow:[CALayer] = []
                
                for e in entries
                {
                    e.filterEnabled = true
                }
                
                var oneTimeAllowed = true
                
                let opacAnimator = Animator()
                
                let opacInterpolator = Interpolator.interpolate(a: Double(0), b: Double(1))
                
                opacAnimator.updateBlock = {
                           
                    if oneTimeAllowed
                    {
                        for e in entries
                        {
                            e.filterEnabled = false
                            
                            guard let layer = WordCloudTextLayer.getWordTextLayerForEntry(chart: chart, entry: e)
                            else { continue }
                            
                            layersToShow.append(layer)
                        }
                        oneTimeAllowed = false
                    }
                    
                    layersToShow.forEach({ layer in
                        layer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
                    })
                 
                }
                
                opacAnimator.stopBlock = { [unowned opacAnimator] in
                    
                    opacAnimator.updateBlock = nil
                    
                    chart.interactionAnimationInProgress = false
                    
                    processor.isWebViewLoadAllowed = true
                    
                    processor._buffers = toBuffer
                    
                   // chart.notifyDataSetChanged(redrawRequired: true)
                    
                    chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entries, dataSets: nil, dataSetAdded: false)

                }
                
                opacAnimator.animate(xAxisDuration: duration * 0.2)
                
                
            }
            
            textAnimation.animate(xAxisDuration: duration * 0.8)
        }
        
        processor.prepareDataAndBuffer(redraw: false, completionBlock:completionBlock)
    }
    
    // MARK:  WordCloud Series Filter Handling
    public static func hideDataset(dataSets:[ChartDataSet], chart:ChartViewBase, duration:TimeInterval)
    {
        guard let data = chart.data
        else { return }
        
        for set in dataSets
        {
            set.visible = false
        }
        
        data.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        chart.delegateToContainer?.chartValueRemoved?(chart, entries: nil, dataSets: dataSets, dataSetRemoved: true,showTrackerView: false )
    }
    
    public static func includeDataset(dataSets:[ChartDataSet], chart:ChartViewBase, duration:TimeInterval)
    {
        guard let data = chart.data
        else { return }
        
        for set in dataSets
        {
            set.visible = true
        }
        
        data.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: nil, dataSets: dataSets, dataSetAdded: true)
    }
    
    public static func highlightSeries(setIndex:Int, chart:ChartViewBase)
    {
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            guard let textLayer = layer.sublayers?[0] as? CATextLayer else {
                continue
            }
            
            guard let currentSetIndex = layer.valueDict["setIndex"] as? Int
            else { continue }
            
            if currentSetIndex == setIndex
            {
                guard (layer.valueDict["entryIndex"] as? Int) != nil
                else { continue }
                textLayer.foregroundColor = layer.chartDataSet?.color(atIndex: layer.valueDict["entryIndex"] as! Int).cgColor
                textLayer.opacity = 1
            }
            else{
                textLayer.foregroundColor = NSUIColor.gray.cgColor
                textLayer.opacity = 0.5
            }
            
        }
    }
    
    public static func highLightWordEntry(chart:ChartViewBase,entry:ChartDataEntry?)
    {
        let barLineChart = chart
        
        guard (chart.data) != nil
        else { return }
        
        if chart.data!.dataSetCount > 1
        {
            let highlightedLayer:WordCloudTextLayer? = entry == nil ? nil : WordCloudTextLayer.getWordLayerForEntry(chart: chart, entry: entry!) //getWordLayerInPoint(chart: chart, loc: touchLocation)
            
            if highlightedLayer == nil
            {
                chart.resetHighlight()
                chart.lastSelected = nil
                chart.callDelegateToContainer(highlight: nil, entry: nil)
                chart.setNeedsDisplay()
            }
            else{
                guard (highlightedLayer?.chartEntry) != nil
                else { return }
                chart.lastSelected = [(highlightedLayer?.chartEntry)!]
                
                guard let highlightedSetIndex = highlightedLayer!.valueDict["setIndex"] as? Int
                else { return }
                
                WordCloudHelperFunctions.highlightSeries(setIndex: highlightedSetIndex, chart: chart)
                
                chart.callDelegateToContainer(highlight: chart.getHighlightByEntry((highlightedLayer?.chartEntry)!), entry: entry)
                
                chart.datasetSelected = true
            }
            
            return
        }
        
        let range = barLineChart.legend.legendRange
        
        if barLineChart.colorAxis.enabled && entry != nil
        {
            if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: entry!, minimum: floor(range.0), maximum: floor(range.1))) {
                return
            }
        }
        
        barLineChart.lastSelected = nil
        
        for layer in WordCloudTextLayer.getAllWordLayer(chart: barLineChart)
        {
            guard let textLayer = layer.sublayers?[0] as? CATextLayer else {
                continue
            }
            
            if barLineChart.colorAxis.enabled
            {
                guard (layer.chartEntry) != nil
                else { continue }
                if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: layer.chartEntry!, minimum: floor(range.0), maximum: floor(range.1)))
                {
                    textLayer.foregroundColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
                    continue
                }
            
                textLayer.foregroundColor = barLineChart.colorAxis.getColor(entry: layer.chartEntry!)?.cgColor
                
                if layer.chartEntry === entry || entry == nil
                {
                    textLayer.opacity = 1
                    barLineChart.updateLastSelectedEntry(entry: entry)

                }
                else{
                    textLayer.opacity = 0.5
                }
            }
            else{
                if layer.chartEntry === entry || entry == nil
                {
                    guard (layer.valueDict["entryIndex"] as? Int) != nil
                    else { continue }
                    textLayer.foregroundColor = layer.chartDataSet?.color(atIndex: layer.valueDict["entryIndex"] as! Int).cgColor
                    barLineChart.updateLastSelectedEntry(entry: entry)
                }
                else{
                    textLayer.foregroundColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
                }
            }
            
        }
        
        let high = (barLineChart.lastSelected != nil && barLineChart.lastSelected!.count > 0) ? chart.getHighlightByEntry(barLineChart.lastSelected![0]) : nil
        
        barLineChart.highlightValue(high, callDelegate: false, redrawRequired: false)
    }
    
    /*public static func highLightWordEntry(chart:ChartViewBase)
    {
        let range = chart.legend.legendRange
        
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            guard let textLayer = layer.sublayers?[0] as? CATextLayer else {
                continue
            }
            
            if !(chart.colorAxis.isEntryAllowed(chartEntry: layer.chartEntry!, minimum: floor(range.0), maximum: floor(range.1)))
            {
                textLayer.foregroundColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
                continue
            }
            
            textLayer.foregroundColor = chart.colorAxis.getColor(entry: layer.chartEntry!)?.cgColor
        }
    }*/
    
    public static func hideSeries(setIndex:Int, chart:ChartViewBase, duration:TimeInterval)
    {
        var allLayers:[CALayer] = []
        
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            guard let textLayer = layer.sublayers?[0] as? CATextLayer else {
                continue
            }
            
            guard let currentSetIndex = layer.valueDict["setIndex"] as? Int
            else { continue }
            
            if currentSetIndex == setIndex
            {
                allLayers.append(textLayer)//   textLayer.opacity = 0
            }
        }
        
        CommonHelperFunctions.performOpacityAnim(targetLayers: allLayers, fromOpacity: 1, toOpacity: 0, duration: duration)
        
    }
    
    public static func hideDatasetWithAnimations(dataSets:[ChartDataSet], chart:ChartViewBase, duration:TimeInterval)
    {
        guard let data = chart.data,
              let processor = chart.getProcessor(type: .WordCloud) as? WordCloudPreprocessor
        else { return }
        
        
        var layersToHide:[CALayer] = []
        
        for set in dataSets
        {
            let setIndex = data.indexOfDataSet(set)
            set.visible = false
            layersToHide.append(contentsOf: WordCloudTextLayer.getAllSeriesWordTextLayers(chart: chart, setIndex: setIndex))
        }
        
        let opacAnimator = Animator()
        
        let opacInterpolator = Interpolator.interpolate(a: Double(1), b: Double(0))
        
        opacAnimator.updateBlock = {
                        
         layersToHide.forEach({ layer in
             layer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
         })
         
        }
        
        opacAnimator.stopBlock = { [unowned opacAnimator] in
            
            opacAnimator.updateBlock = nil
        
            let fromBuffer = processor._buffers
            
            data.notifyDataChanged()
            
            processor.isWebViewLoadAllowed = false
            
            chart.notifyDataSetChanged(redrawRequired: false)
            
            let completionBlock = {
                let toBuffer = processor._buffers
                
                processor._buffers = fromBuffer
                
                var xInterpolateArray:[((CGFloat) -> CGFloat)] = []
                var yInterpolateArray:[((CGFloat) -> CGFloat)] = []
                var sizeInterpolateArray:[((CGFloat) -> CGFloat)] = []
                var rotationInterpolateArray:[((CGFloat) -> CGFloat)] = []
                
                var toBufferIndex = -1
                for i in 0..<fromBuffer.count
                {
                    let fromDict = fromBuffer[i]
                    
                    guard (fromDict["setIndex"] as? Int) != nil
                    else { continue }
                    let set = data.dataSets[fromDict["setIndex"] as! Int]
                    
                    if set.isVisible
                    {
                        toBufferIndex += 1
                        
                        if toBufferIndex >= toBuffer.count
                        {
                            break
                        }
                        
                        let toDict = toBuffer[toBufferIndex]
                        
                        guard (fromDict["x"] as? CGFloat) != nil,
                              (fromDict["y"] as? CGFloat) != nil,
                              (fromDict["fontSize"] as? CGFloat) != nil,
                              (fromDict["rotation"] as? CGFloat) != nil,
                              
                              (toDict["x"] as? CGFloat) != nil,
                              (toDict["y"] as? CGFloat) != nil,
                              (toDict["fontSize"] as? CGFloat) != nil,
                              (toDict["rotation"] as? CGFloat) != nil
                        else { continue }
                        
                        let xValInterpolate = Interpolator.interpolate(a: fromDict["x"] as! CGFloat, b: toDict["x"] as! CGFloat)
                        let yValInterpolate = Interpolator.interpolate(a: fromDict["y"] as! CGFloat, b: toDict["y"] as! CGFloat)
                        let sizeValInterpolate = Interpolator.interpolate(a: fromDict["fontSize"] as! CGFloat, b: toDict["fontSize"] as! CGFloat)
                        let rotationInterpolate = Interpolator.interpolate(a: fromDict["rotation"] as! CGFloat, b: toDict["rotation"] as! CGFloat)
                        
                        xInterpolateArray.append(xValInterpolate)
                        yInterpolateArray.append(yValInterpolate)
                        sizeInterpolateArray.append(sizeValInterpolate)
                        rotationInterpolateArray.append(rotationInterpolate)
                        
                    }
                }
                
                let textAnimation = Animator()
                
                textAnimation.updateBlock = {
                    
                    if processor._buffers.count == 0
                    {
                        return
                    }
                    
                    toBufferIndex = -1
                    
                    for i in 0..<fromBuffer.count
                    {
                        let fromDict = fromBuffer[i]
                        
                        guard (fromDict["setIndex"] as? Int) != nil
                        else { continue }
                        let set = data.dataSets[fromDict["setIndex"] as! Int]
                        
                        if set.isVisible
                        {
                            toBufferIndex += 1
                            if toBufferIndex >= xInterpolateArray.count || i >= processor._buffers.count
                            {
                                break
                            }
                            processor._buffers[i]["x"] = xInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                            processor._buffers[i]["y"] = yInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                            processor._buffers[i]["fontSize"] = sizeInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                            processor._buffers[i]["rotation"] = rotationInterpolateArray[toBufferIndex](CGFloat(textAnimation.phaseX))
                        }
                    }
                    chart.calculateOffsets()
                    chart.setNeedsDisplay()
                    
                }
                
                textAnimation.stopBlock = { [unowned textAnimation] in
                    
                    textAnimation.updateBlock = nil
                    
                    processor._buffers = toBuffer
                    
                    processor.isWebViewLoadAllowed = true
                    
//                    chart.notifyDataSetChanged(redrawRequired: true)
                    
                    chart.delegateToContainer?.chartValueRemoved?(chart, entries: nil, dataSets: dataSets, dataSetRemoved: true,showTrackerView: false )
                }
                
                textAnimation.animate(xAxisDuration: duration * 0.7)
               
            }
            
            processor.prepareDataAndBuffer(redraw: false, completionBlock:completionBlock)
        }
        
        opacAnimator.animate(xAxisDuration: duration * 0.3)
    }
    
    public static func includeDatasetWithAnimations(dataSets:[ChartDataSet], chart:ChartViewBase, duration:TimeInterval)
    {
        guard let data = chart.data,
              let processor = chart.getProcessor(type: .WordCloud) as? WordCloudPreprocessor
        else { return }
        
        
        let fromBuffer = processor._buffers
        
        for set in dataSets
        {
            set.visible = true
        }
        
        data.notifyDataChanged()
        
        processor.isWebViewLoadAllowed = false
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        let completionBlock = {
            
            let toBuffer = processor._buffers
            
            processor._buffers = fromBuffer
            
            var xInterpolateArray:[((CGFloat) -> CGFloat)] = []
            var yInterpolateArray:[((CGFloat) -> CGFloat)] = []
            var sizeInterpolateArray:[((CGFloat) -> CGFloat)] = []
            var rotationInterpolateArray:[((CGFloat) -> CGFloat)] = []
            
            var fromBufferIndex = -1
            for i in 0..<toBuffer.count
            {
                let toDict = toBuffer[i]
                
                guard (toDict["setIndex"] as? Int) != nil
                else { continue }
                let set = data.dataSets[toDict["setIndex"] as! Int]
                
                if dataSets.contains(set as! ChartDataSet)
                {
                    continue
                }
                
                fromBufferIndex += 1
                if fromBufferIndex >= fromBuffer.count
                {
                    break
                }
                let fromDict = fromBuffer[fromBufferIndex]
                
                guard (fromDict["x"] as? CGFloat) != nil,
                      (fromDict["y"] as? CGFloat) != nil,
                      (fromDict["fontSize"] as? CGFloat) != nil,
                      (fromDict["rotation"] as? CGFloat) != nil,
                      
                      (toDict["x"] as? CGFloat) != nil,
                      (toDict["y"] as? CGFloat) != nil,
                      (toDict["fontSize"] as? CGFloat) != nil,
                      (toDict["rotation"] as? CGFloat) != nil
                else { continue }
                
                let xValInterpolate = Interpolator.interpolate(a: fromDict["x"] as! CGFloat, b: toDict["x"] as! CGFloat)
                let yValInterpolate = Interpolator.interpolate(a: fromDict["y"] as! CGFloat, b: toDict["y"] as! CGFloat)
                let sizeValInterpolate = Interpolator.interpolate(a: fromDict["fontSize"] as! CGFloat, b: toDict["fontSize"] as! CGFloat)
                let rotationInterpolate = Interpolator.interpolate(a: fromDict["rotation"] as! CGFloat, b: toDict["rotation"] as! CGFloat)
                
                xInterpolateArray.append(xValInterpolate)
                yInterpolateArray.append(yValInterpolate)
                sizeInterpolateArray.append(sizeValInterpolate)
                rotationInterpolateArray.append(rotationInterpolate)
                    
                
            }
            
            let textAnimation = Animator()
            
            textAnimation.updateBlock = {
                
                if processor._buffers.count == 0
                {
                    return
                }
                
                fromBufferIndex = -1
                
                for i in 0..<toBuffer.count
                {
                    let toDict = toBuffer[i]
                    
                    guard (toDict["setIndex"] as? Int) != nil
                    else { continue }
                    let set = data.dataSets[toDict["setIndex"] as! Int]
                    
                    if dataSets.contains(set as! ChartDataSet)
                    {
                        continue
                    }
                    
                    fromBufferIndex += 1
                    
                    if fromBufferIndex >= xInterpolateArray.count || fromBufferIndex >= processor._buffers.count
                    {
                        break
                    }
                    
                    processor._buffers[fromBufferIndex]["x"] = xInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    processor._buffers[fromBufferIndex]["y"] = yInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    processor._buffers[fromBufferIndex]["fontSize"] = sizeInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    processor._buffers[fromBufferIndex]["rotation"] = rotationInterpolateArray[fromBufferIndex](CGFloat(textAnimation.phaseX))
                    
                }
                chart.calculateOffsets()
                chart.setNeedsDisplay()
                
            }
            
            textAnimation.stopBlock = { [unowned textAnimation] in
                
                textAnimation.updateBlock = nil
        
                processor._buffers = toBuffer
                
                var layersToShow:[CALayer] = []
                
                for set in dataSets
                {
                    set.visible = false
                }
                
                var oneTimeAllowed = true
                
                let opacAnimator = Animator()
                
                let opacInterpolator = Interpolator.interpolate(a: Double(0), b: Double(1))
                
                opacAnimator.updateBlock = {
                           
                    if oneTimeAllowed
                    {
                        for set in dataSets
                        {
                            let setIndex = data.indexOfDataSet(set)
                            set.visible = true
                            layersToShow.append(contentsOf: WordCloudTextLayer.getAllSeriesWordTextLayers(chart: chart, setIndex: setIndex))
                        }
                        oneTimeAllowed = false
                    }
                    
                    layersToShow.forEach({ layer in
                        layer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
                    })
                 
                }
                
                opacAnimator.stopBlock = { [unowned opacAnimator] in
                    
                    opacAnimator.updateBlock = nil
                    
                    chart.notifyDataSetChanged(redrawRequired: false)
                    
                    processor.isWebViewLoadAllowed = true
                    
                    chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: nil, dataSets: dataSets, dataSetAdded: true)
                }
                
                opacAnimator.animate(xAxisDuration: duration * 0.2)
                
                
            }
            
            textAnimation.animate(xAxisDuration: duration * 0.8)
        }
        
        processor.prepareDataAndBuffer(redraw: false, completionBlock:completionBlock)
    }
    

}
