//
//  PackedBubbleHelperFunctions.swift
//  zchart
//
//  Created by Aravinth T on 15/01/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import Foundation

open class PackedBubbleHelperFunctions
{
    
    public static func removeEntries(entries: [ChartDataEntry],chart:ChartViewBase,duration: TimeInterval)
    {
        guard let processor = chart.getProcessor(type: .PackedBubble) as? PackedBubblePreprocessor,
            let chartData = chart.data,
            let dataSets = chart.data?.dataSets as? [ChartDataSet]
            else { return }
        
        let oldValues = processor.dataValues

        for entry in entries
        {
            entry.filterEnabled = true
            BubbleLayer.getBubbleLayerForEntry(chart: chart, entry: entry)?.opacity = 0
        }

        processor.doBubblePackLayout()
        
        let newValues = processor.dataValues
        
        let allLayers = BubbleLayer.getAllBubbleLayer(chart: chart)
        
        let entryAnimator = Animator()
        
        for text in BubbleLayer.getAllBubbleValueLayer(chart: chart)
        {
            text.opacity = 0
        }
                  
        entryAnimator.updateBlock = {
            
                var newIndex = -1
                
                for  oldIndex in 0..<oldValues.count
                {
                    guard let oldObject = oldValues[oldIndex] as? NSDictionary,
                    let oldXPosition = oldObject["x"] as? CGFloat,
                    let oldYPosition = oldObject["y"] as? CGFloat,
                    let oldRadius = oldObject["radius"] as? CGFloat,
                    let name = oldObject["name"] as? String,
                    let setIndex = (oldObject["setIndex"] as? Int)
                    else { continue }
                    let set = chartData.dataSets[setIndex]
                   
                    if name == "root"
                    {
                        newIndex += 1
                        continue
                    }
                    
                    if set.isVisible && allLayers[safe: oldIndex] != nil && allLayers[safe: oldIndex]?.opacity != 0
                    {
                        newIndex += 1
                        
                        guard let newObject = newValues[safe:newIndex] as? NSDictionary,
                              let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
                            else { continue }
                        /*for value in newValues where (value as! NSDictionary)["setIndex"] as! Int == setIndex && (value as! NSDictionary)["name"] as! String == name
                        {
                            newObject = value as! NSDictionary
                            break
                        }*/
                        
                        guard let newXPosition = newObject["x"] as? CGFloat,
                        let newYPosition = newObject["y"] as? CGFloat,
                        let newRadius = newObject["radius"] as? CGFloat,
                        let name = newObject["name"] as? String
                        else { return }
                        if name == "root"
                        {
                            newIndex += 1
                            continue
                        }
                        
                        var oldRect = CGRect(x: oldXPosition-oldRadius, y: oldYPosition-oldRadius, width: oldRadius * 2 , height: oldRadius * 2)
                        chart.plotTransformer.rectValueToPixel(&oldRect)
                       
                       var newRect = CGRect(x: newXPosition-newRadius, y: newYPosition-newRadius, width: newRadius * 2 , height: newRadius * 2)
                       chart.plotTransformer.rectValueToPixel(&newRect)
                       
                       let lineWidthHalf = dataOption.shapeProperties.lineWidth / 2.0
                       let xInterpolator = Interpolator.interpolate(a: oldRect.midX, b: newRect.midX)
                       let yInterpolator = Interpolator.interpolate(a: oldRect.midY, b: newRect.midY)
                       let radiusInterpolator = Interpolator.interpolate(a: oldRect.width - lineWidthHalf, b: newRect.width - lineWidthHalf)
                        
//                        let xInterpolator = Interpolator.interpolate(a: oldXPosition, b: newXPosition)
//                        let yInterpolator = Interpolator.interpolate(a: oldYPosition, b: newYPosition)
//                        let radiusInterpolator = Interpolator.interpolate(a: oldRadius, b: newRadius)
                        
                        
                        let pointX = xInterpolator(CGFloat(entryAnimator.phaseX))
                        let pointY = yInterpolator(CGFloat(entryAnimator.phaseX))
                        let shapeHalf = radiusInterpolator(CGFloat(entryAnimator.phaseX)) / 2.0 //shapeSize / 2.0
                        
//                        let circlePath = UIBezierPath(arcCenter: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat.pi * 2,  clockwise: true)
                        let circlePath = CGMutablePath()
                        circlePath.addArc(center: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle: CGFloat.pi * 2, clockwise: true)
                        
                        if let bubbleLayer = allLayers[safe:oldIndex]
                        {
                            bubbleLayer.path = circlePath//.cgPath
                        }
                        
                    }
                    else{
                        if let bubbleLayer = allLayers[safe:oldIndex]
                        {
                            bubbleLayer.opacity = 0
                        }
                    }
                }
              
        }
        
        entryAnimator.stopBlock = {
            chart.interactionAnimationInProgress = false
            
            chart.notifyDataSetChanged(redrawRequired: true)
            
            chart.delegateToContainer?.chartValueRemoved?(chart, entries: entries, dataSets: nil, dataSetRemoved: false,showTrackerView: false )
                
        }
      
        entryAnimator.animate(xAxisDuration: duration, easingOption: .linear)
    }
        
    public static func addEntries(entries: [ChartDataEntry], chart:ChartViewBase, duration:TimeInterval)
    {
            guard let processor = chart.getProcessor(type: .PackedBubble) as? PackedBubblePreprocessor,
                let chartData = chart.data,
                let dataSets = chart.data?.dataSets as? [ChartDataSet]
                else { return }
        
            let oldValues = processor.dataValues
            
            for entry in entries
            {
                entry.filterEnabled = false
            }
        
            processor.doBubblePackLayout()
            
            let newValues = processor.dataValues
            
            let allLayers = BubbleLayer.getAllBubbleLayer(chart: chart)
        
            for text in BubbleLayer.getAllBubbleValueLayer(chart: chart)
            {
                text.opacity = 0
            }
            
            let entryAnimator = Animator()
                      
            entryAnimator.updateBlock = {
                
                    var oldIndex = -1
                
                    for newIndex in 0..<newValues.count
                    {
                        guard let newObject = newValues[newIndex] as? NSDictionary,
                        let newXPosition = newObject["x"] as? CGFloat,
                        let newYPosition = newObject["y"] as? CGFloat,
                        let newRadius = newObject["radius"] as? CGFloat,
                        let newName = newObject["name"] as? String,
                        let setIndex = (newObject["setIndex"] as? Int)
                        else { continue }
                        let set = chartData.dataSets[setIndex]
                       
                        if newName == "root"
                        {
                            oldIndex += 1
                            continue
                        }
                        
                        if ((oldIndex + 1) >= oldValues.count) {
                            continue
                        }
                        
                        guard ((oldValues[oldIndex+1] as? NSDictionary)?["name"] as? String) != nil
                        else { continue }
                        
                        if ((oldValues[oldIndex+1] as! NSDictionary)["name"] as? String) != newName
                        {
                            continue
                        }
                        
                        oldIndex += 1
                        
                        guard let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
                            else { continue }
                        
                        guard let oldObject = oldValues[oldIndex] as? NSDictionary,
                        
                        let oldXPosition = oldObject["x"] as? CGFloat,
                        let oldYPosition = oldObject["y"] as? CGFloat,
                        let oldRadius = oldObject["radius"] as? CGFloat,
                        let oldName = oldObject["name"] as? String
                        else { continue }
                        
                        if oldName == "root"
                        {
                            oldIndex += 1
                            continue
                        }
                        
                        var oldRect = CGRect(x: oldXPosition-oldRadius, y: oldYPosition-oldRadius, width: oldRadius * 2 , height: oldRadius * 2)
                         chart.plotTransformer.rectValueToPixel(&oldRect)
                        
                        var newRect = CGRect(x: newXPosition-newRadius, y: newYPosition-newRadius, width: newRadius * 2 , height: newRadius * 2)
                        chart.plotTransformer.rectValueToPixel(&newRect)
                        
                        let lineWidthHalf = dataOption.shapeProperties.lineWidth / 2.0
                        let xInterpolator = Interpolator.interpolate(a: oldRect.midX, b: newRect.midX)
                        let yInterpolator = Interpolator.interpolate(a: oldRect.midY, b: newRect.midY)
                        let radiusInterpolator = Interpolator.interpolate(a: oldRect.width - lineWidthHalf, b: newRect.width - lineWidthHalf)

//                        let xInterpolator = Interpolator.interpolate(a: oldXPosition, b: newXPosition)
//                        let yInterpolator = Interpolator.interpolate(a: oldYPosition, b: newYPosition)
//                        let radiusInterpolator = Interpolator.interpolate(a: oldRadius, b: newRadius)
                        
                        
                        let pointX = xInterpolator(CGFloat(entryAnimator.phaseX))
                        let pointY = yInterpolator(CGFloat(entryAnimator.phaseX))
                        
                        let shapeHalf = radiusInterpolator(CGFloat(entryAnimator.phaseX)) / 2.0
                        
//                        let circlePath = UIBezierPath(arcCenter: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat.pi * 2,  clockwise: true)
                        let circlePath = CGMutablePath()
                        circlePath.addArc(center: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle: CGFloat.pi * 2, clockwise: true)
                        
                        if let bubbleLayer = allLayers[safe:oldIndex]
                        {
                            bubbleLayer.path = circlePath//.cgPath
                        }
                        
                    }
                  
            }
            
            entryAnimator.stopBlock = {
                
                chart.interactionAnimationInProgress = false
                
                chart.notifyDataSetChanged(redrawRequired: true)
                
                chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entries, dataSets: nil, dataSetAdded: false)
            }
          
            entryAnimator.animate(xAxisDuration: duration, easingOption: .linear)
        }

    public static func moveViewToEntry(entry:ChartDataEntry, chart:ChartViewBase, duration:Double) {
        
        var layerPoint:CGPoint? = nil
                       
        for layer in BubbleLayer.getAllBubbleLayer(chart: chart)
        {
            if (layer.chartEntry == entry)
            {
                layerPoint = layer.shapePoint
                break
            }
        }

        guard let toPoint = layerPoint else {
            return
        }
            
        let transX = chart.viewPortHandler.transX
        let transY = chart.viewPortHandler.transY
        
        let xDist = chart.viewPortHandler.contentRect.midX - toPoint.x
        let yDist = chart.viewPortHandler.contentRect.midY - toPoint.y
        
        let xInterpolator = Interpolator.interpolate(a: transX, b: transX+xDist)
        let yInterpolator = Interpolator.interpolate(a: transY, b: transY+yDist)
        
        var translation = CGPoint(x: transX, y: transY)
        
        let entryAnimator = Animator()
                  
        entryAnimator.updateBlock = {
            
            let newTX = xInterpolator(CGFloat(entryAnimator.phaseX))
            let newTY = yInterpolator(CGFloat(entryAnimator.phaseX))
            
            translation.x = newTX - translation.x
            translation.y = newTY - translation.y
            
            let _ = CommonHelperFunctions.performPanChangeforPlot(translation: translation, chart: chart)
            translation.x = xInterpolator(CGFloat(entryAnimator.phaseX))
            translation.y = yInterpolator(CGFloat(entryAnimator.phaseX))
        }
        
        entryAnimator.animate(xAxisDuration: duration, easingOption: .linear)

    }
}
