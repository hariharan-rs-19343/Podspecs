//
//  sankeyHelperFunctions.swift
//  Pods-ZCharts
//
//  Created by keerthi-pt4274 on 21/10/22.
//

import Foundation

open class SankeyHelperFunctions {
    
    // MARK: - Animation Methods
    
    public static func hideDataset(dataset: ChartDataSet, nodeNames: [String], disabledEntries: [ChartDataEntry], chart:ChartViewBase, duration:TimeInterval)
    {
        
        guard let preprocessor = chart.getProcessor(type: .Sanky) as? SankeyPreprocessor else {
                return
            }
        
        let oldDataValues = preprocessor.dataValues
        
        let nodeLayers = SankyLayers.getAllNodeLayer(chart: chart)
        let linkLayers = SankyLayers.getAllLinkLayer(chart: chart)
                
        filterEnabled(dataSet: dataset, selctedEntries: disabledEntries, isEnabled: true)
        
        preprocessor.isWebViewLoadAllowed = false
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        let completionBlock = {
            
            let newDataValues = preprocessor.dataValues
            
            filterEnabled(dataSet: dataset, selctedEntries: disabledEntries, isEnabled: false)
            
            preprocessor.dataValues = oldDataValues
            
            for textLayer in getAllSankeyValue(chart: chart) {
                textLayer.opacity = 0.0
            }
            
            let (nodeInterpolator,linkInterpolator) = SankeyInterpolator(chart: chart, oldDataValues: oldDataValues, newDataValues: newDataValues,dataset: dataset)
            
            let hideAnimation = Animator()
            
            hideAnimation.updateBlock = {
                
                var nodeLayerIndex = 0
                
                for fromLayer in nodeLayers {
                    
                    guard let node = nodeInterpolator[safe:nodeLayerIndex],
                          fromLayer.nodeName == node.nodeName else {
                        
                        fromLayer.opacity = 0.0
                        continue
                    }
                    
                    if let newPath = constructPathForNode(node: node, phaseValue: hideAnimation.phaseX) {
                        
                        fromLayer.path = newPath
                    }
                    
                    nodeLayerIndex += 1
                }
                
                var layerIndex = 0
                
                for fromLayer in linkLayers {
                    
                    guard let entry = fromLayer.chartEntry,
                          let link = linkInterpolator[safe:layerIndex],
                          dataset.entryIndex(entry: entry) == link.entryIndex
                    else {
                        fromLayer.opacity = 0.0
                        continue
                    }
                    
                    if fromLayer.type == .Link {
                        
                        if let newPath = constructPathForLink(layer: fromLayer, link: link, phaseValue: hideAnimation.phaseX) {
                            fromLayer.path = newPath
                        }
                    }
                    else {
                        fromLayer.opacity = 0.0
                    }
                    
                    layerIndex += 1
                }
                
            }
            
            hideAnimation.stopBlock = { [unowned hideAnimation] in
                hideAnimation.updateBlock = nil
                preprocessor.isWebViewLoadAllowed = true
                hideEntries(chartView: chart, dataset: dataset, entries: disabledEntries)
            }
            
            hideAnimation.animate(xAxisDuration: duration, easingOption: .linear)
        }
        
        preprocessor.prepareDataAndBuffer(redraw: false, completionBlock:completionBlock)
    }
    
    public static func includeDataset(chart:ChartViewBase, dataset: ChartDataSet, enabledEntries: [ChartDataEntry], duration:TimeInterval)
    {
        
        guard let preprocessor = chart.getProcessor(type: .Sanky) as? SankeyPreprocessor,
              let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions else {
                return
            }
        
        let oldDataValues = preprocessor.dataValues
        
        let nodeLayers = SankyLayers.getAllNodeLayer(chart: chart)
        let linkLayers = SankyLayers.getAllLinkLayer(chart: chart)
        
        filterEnabled(dataSet: dataset, selctedEntries: enabledEntries, isEnabled: false)
        
        preprocessor.isWebViewLoadAllowed = false
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        let completionBlock = {
            
            let newDataValues = preprocessor.dataValues
            
            preprocessor.dataValues = oldDataValues
            
            for textLayer in getAllSankeyValue(chart: chart) {
                textLayer.opacity = 0.0
            }
            
            let (nodeInterpolator,linkInterpolator) = SankeyInterpolator(chart: chart, oldDataValues: oldDataValues, newDataValues: newDataValues,dataset: dataset)
            
            var includedNodeNames = [String]()
            
            let alignAnimation = Animator()
            
            alignAnimation.updateBlock = {
                
                var nodeLayerIndex = 0
                
                for fromLayer in nodeLayers {
                    
                    guard let node = nodeInterpolator[safe:nodeLayerIndex] else {
                        continue
                    }
                    
                    if !includedNodeNames.contains(fromLayer.nodeName) {
                        includedNodeNames.append(fromLayer.nodeName)
                    }
                    
                    if let newPath = constructPathForNode(node: node, phaseValue: alignAnimation.phaseX) {
                        
                        fromLayer.path = newPath
                    }
                    
                    nodeLayerIndex += 1
                }
                
                var layerIndex = 0
                
                for fromLayer in linkLayers {
                    
                    guard let link = linkInterpolator[safe:layerIndex]
                    else {
                        continue
                    }
                    
                    if fromLayer.type == .Link {
                        if let newPath = constructPathForLink(layer: fromLayer, link: link, phaseValue: alignAnimation.phaseX) {
                            fromLayer.path = newPath
                        }
                    }
                    else {
                        fromLayer.opacity = 0.0
                    }
                    
                    layerIndex += 1
                }
                
            }
            
            alignAnimation.stopBlock = { [unowned alignAnimation] in
                
                alignAnimation.updateBlock = nil
                
                preprocessor.dataValues = newDataValues
                
                let includeAnimation = Animator()
                
                let opacityInterpolator = Interpolator.interpolate(a: 0.0, b: plotOption.linkOpacity)
                
                ChartInteractionHelperFunction.setForcedValue(axisChartBase: chart, enable: true)
                
                includeAnimation.updateBlock = {
                    
                    for entryIndex in 0..<dataset.entryCount {
                        
                        guard let entry = dataset.entryForIndex(entryIndex) else {
                            continue
                        }
                        
                        if enabledEntries.contains(entry) {
                            entry.opacityChanged = Float(opacityInterpolator(includeAnimation.phaseX))
                        }
                        else {
                            entry.opacityChanged = Float(plotOption.linkOpacity)
                        }
                    }
                    
                    chart.setNeedsDisplay()
                }
                
                includeAnimation.stopBlock = { [unowned includeAnimation] in
                    
                    includeAnimation.updateBlock = nil
                    
                    ChartInteractionHelperFunction.setForcedOpacityValue(axisChartBase: chart, enable: false)
                    
                    preprocessor.isWebViewLoadAllowed = true
                    
                    includeEntries(chartView: chart, dataset: dataset, entries: enabledEntries)
                }
                
                includeAnimation.animate(xAxisDuration: (duration / 2.0), easingOption: .linear)
            }
            
            alignAnimation.animate(xAxisDuration: (duration / 2.0), easingOption: .linear)
        }
        
        preprocessor.prepareDataAndBuffer(redraw: false, completionBlock: completionBlock)
    }
    
    // MARK: - Helper Methods
    
    private static func constructPathForNode(node: RectPointsInterpolatorForNode, phaseValue: CGFloat) -> CGPath? {
        
        guard let minXInterpolator = node.rectPoints[.topLeft],
              let minYInterpolator = node.rectPoints[.bottomLeft],
              let maxXInterpolator = node.rectPoints[.topRight],
              let maxYInterpolator = node.rectPoints[.bottomRight]
        else { return nil }
        
        let minX = minXInterpolator(phaseValue)
        let maxX = maxXInterpolator(phaseValue)
        let minY = minYInterpolator(phaseValue)
        let maxY = maxYInterpolator(phaseValue)
        
        let width = maxX - minX
        let height =  maxY - minY
        
//        let newPath = UIBezierPath(rect: CGRect(x: minX, y: minY, width: width, height: height))
        let newPath = CGMutablePath(rect: CGRect(x: minX, y: minY, width: width, height: height), transform: nil)
        return newPath//.cgPath
    }
    
    private static func constructPathForLink(layer: SankyLayers, link: RectPointsInterpolatorForLink, phaseValue: CGFloat) -> CGPath? {
        
        guard let minXInterpolator = link.rectPoints[.topLeft],
              let minYInterpolator = link.rectPoints[.bottomLeft],
              let maxXInterpolator = link.rectPoints[.topRight],
              let maxYInterpolator = link.rectPoints[.bottomRight]
        else { return nil }
        
        let minX = minXInterpolator(phaseValue)
        let maxX = maxXInterpolator(phaseValue)
        let minY = minYInterpolator(phaseValue)
        let maxY = maxYInterpolator(phaseValue)
        let linkWidth = link.lineWidth(phaseValue)
        
        var newRect:[RectPoints:CGPoint] = [:]
        newRect[.topLeft] = CGPoint(x: minX, y: minY)
        newRect[.bottomLeft] = CGPoint(x: minX, y: minY+linkWidth)
        newRect[.topRight] = CGPoint(x: maxX, y: maxY)
        newRect[.bottomRight] = CGPoint(x: maxX, y: maxY+linkWidth)
        
        return constructLink(layer: layer, newRect: newRect)
    }
    
    private static func constructLink(layer: SankyLayers,newRect: [RectPoints:CGPoint]) -> CGPath? {
        
        let newPath = CGMutablePath()
        
        guard let sourceX =  newRect[.topLeft]?.x,
              let sourceY0 = newRect[.topLeft]?.y,
              let sourceY1 = newRect[.bottomLeft]?.y,
              let targetX = newRect[.topRight]?.x,
              let targetY0 = newRect[.topRight]?.y,
              let targetx1 = newRect[.bottomRight]?.x,
              let targetY1 = newRect[.bottomRight]?.y
        else { return nil }
        
        let (c1,c2) = layer.getControlX(rectPoints: newRect)
                
        newPath.move(to: CGPoint(x: sourceX, y: sourceY0))
        
//        newPath.addCurve(to: CGPoint(x: targetX, y: targetY0), controlPoint1: CGPoint(x: c1, y: sourceY0) , controlPoint2: CGPoint(x: c1, y: targetY0 ))
        newPath.addCurve(to: CGPoint(x: targetX, y: targetY0), control1: CGPoint(x: c1, y: sourceY0) , control2: CGPoint(x: c1, y: targetY0 ))
        
        newPath.addLine(to: CGPoint(x: targetx1, y: targetY1))

//        newPath.addCurve(to: CGPoint(x: sourceX, y: sourceY1), controlPoint1: CGPoint(x: c2, y: targetY1), controlPoint2: CGPoint(x: c2, y: sourceY1))
        newPath.addCurve(to: CGPoint(x: sourceX, y: sourceY1), control1: CGPoint(x: c2, y: targetY1), control2: CGPoint(x: c2, y: sourceY1))

        newPath.closeSubpath()//.close()
        
        return newPath//.cgPath
    }
    
    public static func constructCircularLink(chart: ChartViewBase, circularType: String, pathDict: NSDictionary, linkWidth: CGFloat, linkPadding: CGFloat,firstLinkX:CGFloat,lastLinkX:CGFloat,toAdjustHalf:CGFloat, firstNodeX:CGFloat, lastNodeX:CGFloat) -> CGPath? {
        
        var newPath = CGMutablePath()
        
        guard let sourceXOriginal = pathDict["sourceX"] as? CGFloat,
              let targetXOriginal = pathDict["targetX"] as? CGFloat,
              var sourceX = pathDict["sourceX"] as? CGFloat,
              var sourceY = pathDict["sourceY"] as? CGFloat,
              
              var targetX = pathDict["targetX"] as? CGFloat,
              var targetY = pathDict["targetY"] as? CGFloat,
            
              var leftInnerExtent = pathDict["leftInnerExtent"] as? CGFloat,
              var leftInnerExtent1 = pathDict["leftInnerExtent1"] as? CGFloat,
              var leftFullExtent = pathDict["leftFullExtent"] as? CGFloat,
              var leftFullExtent1 = pathDict["leftFullExtent1"] as? CGFloat,
              var leftLargeArcRadius1 = pathDict["leftLargeArcRadius1"] as? CGFloat,
              var leftSmallArcRadius = pathDict["leftSmallArcRadius"] as? CGFloat,
              var leftSmallArcRadius1 = pathDict["leftSmallArcRadius1"] as? CGFloat,
              
              var rightInnerExtent = pathDict["rightInnerExtent"] as? CGFloat,
              var rightInnerExtent1 = pathDict["rightInnerExtent1"] as? CGFloat,
              var rightFullExtent = pathDict["rightFullExtent"] as? CGFloat,
              var rightFullExtent1 = pathDict["rightFullExtent1"] as? CGFloat,
              var rightLargeArcRadius1 = pathDict["rightLargeArcRadius1"] as? CGFloat,
              var rightSmallArcRadius = pathDict["rightSmallArcRadius"] as? CGFloat,
              var rightSmallArcRadius1 = pathDict["rightSmallArcRadius1"] as? CGFloat,
              
              var verticalLeftInnerExtent = pathDict["verticalLeftInnerExtent"] as? CGFloat,
              var verticalLeftInnerExtent1 = pathDict["verticalLeftInnerExtent1"] as? CGFloat,
              var verticalRightInnerExtent = pathDict["verticalRightInnerExtent"] as? CGFloat,
              var verticalRightInnerExtent1 = pathDict["verticalRightInnerExtent1"] as? CGFloat,
              var verticalFullExtent = pathDict["verticalFullExtent"] as? CGFloat,
              var verticalFullExtent1 = pathDict["verticalFullExtent1"] as? CGFloat
              
              
        else { return nil }
        
        chart.plotTransformer.xPointValueToPixel(&sourceX)
        chart.plotTransformer.yPointValueToPixel(&sourceY)
              
        chart.plotTransformer.xPointValueToPixel(&targetX)
        chart.plotTransformer.yPointValueToPixel(&targetY)
            
        chart.plotTransformer.xPointValueToPixel(&leftInnerExtent)
        chart.plotTransformer.xPointValueToPixel(&leftInnerExtent1)
        chart.plotTransformer.xPointValueToPixel(&leftFullExtent)
        chart.plotTransformer.xPointValueToPixel(&leftFullExtent1)
        chart.plotTransformer.yPointValueToPixel(&leftLargeArcRadius1)
        chart.plotTransformer.yPointValueToPixel(&leftSmallArcRadius)
        chart.plotTransformer.yPointValueToPixel(&leftSmallArcRadius1)
              
        chart.plotTransformer.xPointValueToPixel(&rightInnerExtent)
        chart.plotTransformer.xPointValueToPixel(&rightInnerExtent1)
        chart.plotTransformer.xPointValueToPixel(&rightFullExtent)
        chart.plotTransformer.xPointValueToPixel(&rightFullExtent1)
        chart.plotTransformer.yPointValueToPixel(&rightLargeArcRadius1)
        chart.plotTransformer.yPointValueToPixel(&rightSmallArcRadius)
        chart.plotTransformer.yPointValueToPixel(&rightSmallArcRadius1)
              
        chart.plotTransformer.yPointValueToPixel(&verticalLeftInnerExtent)
        chart.plotTransformer.yPointValueToPixel(&verticalLeftInnerExtent1)
        chart.plotTransformer.yPointValueToPixel(&verticalRightInnerExtent)
        chart.plotTransformer.yPointValueToPixel(&verticalRightInnerExtent1)
        chart.plotTransformer.yPointValueToPixel(&verticalFullExtent)
        chart.plotTransformer.yPointValueToPixel(&verticalFullExtent1)
        
        
        
        if (firstLinkX != CGFloat.greatestFiniteMagnitude && firstLinkX == sourceXOriginal) && (lastLinkX != CGFloat.greatestFiniteMagnitude && lastLinkX == targetXOriginal)
        {
            sourceX += linkPadding - (toAdjustHalf*2)
            targetX -= linkPadding - (toAdjustHalf*2)
        }
        else if firstLinkX != CGFloat.greatestFiniteMagnitude && firstLinkX == sourceXOriginal
        {
            sourceX += linkPadding - (toAdjustHalf*2)
            targetX -= linkPadding - toAdjustHalf
            
        }
        else if lastLinkX != CGFloat.greatestFiniteMagnitude && lastLinkX == targetXOriginal
        {
            sourceX += linkPadding - toAdjustHalf
            targetX -= linkPadding - (toAdjustHalf*2)

        }
        else{
            sourceX += linkPadding - toAdjustHalf
            targetX -= linkPadding - toAdjustHalf
        }
        
        if targetXOriginal <= sourceXOriginal && sourceXOriginal == lastNodeX
        {
            var tempSource = sourceXOriginal
            chart.plotTransformer.xPointValueToPixel(&tempSource)
            sourceX = tempSource + linkPadding
        }
         if targetXOriginal <= sourceXOriginal && targetXOriginal == firstNodeX
        {
             var tempTarget = targetXOriginal
             chart.plotTransformer.xPointValueToPixel(&tempTarget)
             targetX = tempTarget - linkPadding
        }
    
            
        if (circularType == "top") {
            
            newPath.move(to: CGPoint(x: sourceX, y: sourceY))
            
            newPath.addLine(to: CGPoint(x: leftInnerExtent, y: sourceY))

            addArcp(pathValue: &newPath, from: CGPoint(x: leftInnerExtent, y: sourceY), to: CGPoint(x: leftFullExtent, y: sourceY-leftSmallArcRadius), inverted: true)
            
            newPath.addLine(to: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent), to: CGPoint(x: leftInnerExtent, y: verticalFullExtent), inverted: true)
            
            newPath.addLine(to: CGPoint(x: rightInnerExtent, y: verticalFullExtent))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: rightInnerExtent, y: verticalFullExtent), to: CGPoint(x: rightFullExtent, y: verticalRightInnerExtent), inverted: true)
            
            newPath.addLine(to: CGPoint(x: rightFullExtent, y: targetY-rightSmallArcRadius))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: rightFullExtent, y: targetY-rightSmallArcRadius), to: CGPoint(x: rightInnerExtent, y: targetY), inverted: true)
            
            newPath.addLine(to: CGPoint(x: targetX, y: targetY))
            
            newPath.addLine(to: CGPoint(x: targetX, y: targetY-linkWidth))
            
            newPath.addLine(to: CGPoint(x: rightInnerExtent1, y: targetY-linkWidth))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: rightInnerExtent1, y: targetY-linkWidth), to: CGPoint(x: rightFullExtent1, y: targetY-linkWidth-rightSmallArcRadius1), inverted: false)
            
            newPath.addLine(to: CGPoint(x: rightFullExtent1, y: verticalRightInnerExtent1+rightLargeArcRadius1))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: rightFullExtent1, y: verticalRightInnerExtent1+rightLargeArcRadius1), to: CGPoint(x: rightInnerExtent1, y: verticalFullExtent1), inverted: false)
            
            newPath.addLine(to: CGPoint(x: leftInnerExtent1, y: verticalFullExtent1))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: leftInnerExtent1, y: verticalFullExtent1), to: CGPoint(x: leftFullExtent1, y: verticalLeftInnerExtent1 + leftLargeArcRadius1), inverted: false)
            
            newPath.addLine(to: CGPoint(x: leftFullExtent1, y: sourceY-linkWidth-leftSmallArcRadius1))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: leftFullExtent1, y: sourceY-linkWidth-leftSmallArcRadius1), to: CGPoint(x: leftInnerExtent1, y: sourceY - linkWidth), inverted: false)
            
            newPath.addLine(to: CGPoint(x: sourceX, y: sourceY-linkWidth))

            newPath.closeSubpath()//.close()
            
        } else {
            
            newPath.move(to: CGPoint(x: sourceX, y: sourceY))
                
            newPath.addLine(to: CGPoint(x: leftInnerExtent, y: sourceY))

            addArcp(pathValue: &newPath, from: CGPoint(x: leftInnerExtent, y: sourceY), to: CGPoint(x: leftFullExtent, y: sourceY+leftSmallArcRadius), inverted: false)
                
            newPath.addLine(to: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent), to: CGPoint(x: leftInnerExtent, y: verticalFullExtent), inverted: false)
                
            newPath.addLine(to: CGPoint(x: rightInnerExtent, y: verticalFullExtent))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: rightInnerExtent, y: verticalFullExtent), to: CGPoint(x: rightFullExtent, y: verticalRightInnerExtent), inverted: false)
                
            newPath.addLine(to: CGPoint(x: rightFullExtent, y: targetY+rightSmallArcRadius))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: rightFullExtent, y: targetY+rightSmallArcRadius), to: CGPoint(x: rightInnerExtent, y: targetY), inverted: false)
                
            newPath.addLine(to: CGPoint(x: targetX, y: targetY))
                
            newPath.addLine(to: CGPoint(x: targetX, y: targetY+linkWidth))
                
            newPath.addLine(to: CGPoint(x: rightInnerExtent1, y: targetY+linkWidth))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: rightInnerExtent1, y: targetY+linkWidth), to: CGPoint(x: rightFullExtent1, y: targetY+linkWidth+rightSmallArcRadius1), inverted: true)
                
            newPath.addLine(to: CGPoint(x: rightFullExtent1, y: verticalRightInnerExtent1-rightLargeArcRadius1))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: rightFullExtent1, y: verticalRightInnerExtent1-rightLargeArcRadius1), to: CGPoint(x: rightInnerExtent1, y: verticalFullExtent1), inverted: true)
                
            newPath.addLine(to: CGPoint(x: leftInnerExtent1, y: verticalFullExtent1))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: leftInnerExtent1, y: verticalFullExtent1), to: CGPoint(x: leftFullExtent1, y: verticalLeftInnerExtent1 - leftLargeArcRadius1), inverted: true)
                
            newPath.addLine(to: CGPoint(x: leftFullExtent1, y: sourceY+linkWidth+leftSmallArcRadius1))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: leftFullExtent1, y: sourceY+linkWidth+leftSmallArcRadius1), to: CGPoint(x: leftInnerExtent1, y: sourceY + linkWidth), inverted: true)
                
            newPath.addLine(to: CGPoint(x: sourceX, y: sourceY+linkWidth))

            newPath.closeSubpath()//.close()
        }
        
        return newPath//.cgPath
    }
    
    private static func addArcp(pathValue:inout CGMutablePath, from:CGPoint, to:CGPoint, inverted:Bool)
    {
        if (to.x > from.x) && (to.y > from.y) || (to.x < from.x) && (to.y < from.y)
        {
//            inverted ? pathValue.addQuadCurve(to: to, controlPoint: CGPoint(x: from.x, y: to.y)) : pathValue.addQuadCurve(to: to, controlPoint: CGPoint(x: to.x, y: from.y))
            inverted ? pathValue.addQuadCurve(to: to, control: CGPoint(x: from.x, y: to.y)) : pathValue.addQuadCurve(to: to, control: CGPoint(x: to.x, y: from.y))
        }
        else if (to.x < from.x) && (to.y > from.y) || (to.x > from.x) && (to.y < from.y)
        {
//            inverted ? pathValue.addQuadCurve(to: to, controlPoint: CGPoint(x: to.x, y: from.y)) : pathValue.addQuadCurve(to: to, controlPoint: CGPoint(x: from.x, y: to.y))
            inverted ? pathValue.addQuadCurve(to: to, control: CGPoint(x: to.x, y: from.y)) : pathValue.addQuadCurve(to: to, control: CGPoint(x: from.x, y: to.y))
        }
        
        return
    }
    
    private static func filterEnabled(dataSet: ChartDataSet, selctedEntries: [ChartDataEntry], isEnabled: Bool) {
        
        for entryIndex in 0..<dataSet.entryCount {
            
            guard let entry = dataSet.entryForIndex(entryIndex) else {
                continue
            }
            
            if selctedEntries.contains(entry) {
                entry.filterEnabled = isEnabled
            }
            
        }
    }
    
    public static func hideEntries(chartView: ChartViewBase, dataset:  ChartDataSet, entries: [ChartDataEntry]) {
        
        filterEnabled(dataSet: dataset, selctedEntries: entries, isEnabled: true)
        
        chartView.interactionAnimationInProgress = false
        
        updateMatrix(chartView: chartView, redrawRequired: true)
        
        chartView.delegateToContainer?.chartValueRemoved?(chartView, entries: entries, dataSets: [dataset], dataSetRemoved: false , showTrackerView: false)
    }
    
    public static func includeEntries(chartView: ChartViewBase, dataset: ChartDataSet, entries: [ChartDataEntry]) {
        
        filterEnabled(dataSet: dataset, selctedEntries: entries, isEnabled: false)
        
        chartView.interactionAnimationInProgress = false
        
        updateMatrix(chartView: chartView, redrawRequired: true)
        
        chartView.delegateToContainer?.chartValueAdded?(chartView: chartView, entries: entries, dataSets: nil, dataSetAdded: false)
    }
    
    private static func updateMatrix(chartView: ChartViewBase, redrawRequired: Bool) {
        
        chartView.data?.updateXYValues()
       
        chartView.data?.notifyDataChanged()
        
        chartView.notifyDataSetChanged(redrawRequired: redrawRequired)
        
    }
    
    public static func getNodeLayerForNodeName(layers: [SankyLayers], nodeName: String) -> SankyLayers? {
        
        for layer in layers {
            
            if layer.nodeName == nodeName {
                return layer
            }
        }
        
        return nil
    }
    
    public static func getEntriesFornodeName(dataset: ChartDataSet,nodeName: String) -> [ChartDataEntry] {
        
        var entries = [ChartDataEntry]()
        
        for entryIndex in 0..<dataset.entryCount {
            
            guard let entry = dataset.entryForIndex(entryIndex) else {
                continue
            }
            
            if entry.xString == nodeName || entry.yString == nodeName {
                entries.append(entry)
            }
        }
        
        return entries
    }
    
    public static func getInteractedEntriesForDisable(dataSet: ChartDataSet, entryString: String, isEnabled: Bool) -> [ChartDataEntry] {
        
        var entries = [ChartDataEntry]()
        
        var enabledEntries = false
        
        for entryIndex in 0..<dataSet.entryCount {
            
            guard let entry = dataSet.entryForIndex(entryIndex), (!entry.enabled && isEnabled) || (entry.enabled && !isEnabled) else {
                continue
            }
            
            if entry.xString == entryString || entry.yString == entryString {
                entry.enabled = isEnabled
                entries.append(entry)
            }
            
            if entry.enabled {
                enabledEntries = true
            }
        }
        
        if !enabledEntries {
            
            for entry in entries {
                entry.enabled = true
            }
            
            entries.removeAll()
        }
        
        return entries
    }
    
    public static func getInteractedEntriesForEnable(dataset: ChartDataSet, entryString: String) -> [ChartDataEntry] {
        
        var entries = getInteractedEntriesForDisable(dataSet: dataset, entryString: entryString, isEnabled: true)
        
        let enabledNodes = getEnabledNodeNames(dataset: dataset)
        
        for entryIndex in 0..<dataset.entryCount {
            
            guard let entry = dataset.entryForIndex(entryIndex),
                  let xString = entry.xString,
                  let yString = entry.yString,
                  !entry.enabled else {
                continue
            }
            
            if enabledNodes.contains(xString) && enabledNodes.contains(yString) {
                entry.enabled = true
                entries.append(entry)
            }
        }
        
        return entries
    }
    
    private static func getEnabledNodeNames(dataset: ChartDataSet) -> Set<String> {
        
        var enabledNodeNames = Set<String>()
        
        for entryIndex in 0..<dataset.entryCount {
            
            guard let entry = dataset.entryForIndex(entryIndex),
                  let xString = entry.xString,
                  let yString = entry.yString,
                  entry.enabled,
                  !(enabledNodeNames.contains(xString) && enabledNodeNames.contains(yString)) else {
                continue
            }
            
            enabledNodeNames.insert(xString)
            enabledNodeNames.insert(yString)
        }
        
        return enabledNodeNames
    }
    
    public static func getEntriesForYString(dataSet: ChartDataSet, yString: String) -> [ChartDataEntry] {
        
        var entries = [ChartDataEntry]()
        
        for entryIndex in 0..<dataSet.entryCount {
            
            guard let entry = dataSet.entryForIndex(entryIndex), !entry.filterEnabled
            else {
                continue
            }
            
            if entry.yString == yString {
                entries.append(entry)
            }
        }
        
        return entries
    }
    
    public static func getEntryForEnabledNodename(data: ChartData, nameNode: String) -> ChartDataEntry? {
        
        guard let dataset = data.dataSets[0] as? ChartDataSet,
              let yStringArray = data.yString,
              let yString = yStringArray[dataset.axisIndex] else {
            return nil
        }
        
        var enableFlag = false
        
        var enabledEntries = [ChartDataEntry]()
        
        if let entry = dataset.entryForString(nameNode) {
            
            let entries = dataset.entriesForXValue(entry.x)
            
            for entry in entries {
                
                if entry.enabled {
                    enableFlag = true
                    break
                }
            }
            enabledEntries.append(contentsOf: entries)
        }
        
        if yString.contains(nameNode) && !enableFlag {
            
            let yStringentries = SankeyHelperFunctions.getEntriesForYString(dataSet: dataset, yString: nameNode)
            
            for entry in yStringentries {
                
                if entry.enabled {
                    enableFlag = true
                    break
                }
            }
            enabledEntries.append(contentsOf: yStringentries)
        }
        
        if enableFlag == false && enabledEntries.count > 0 {
            return enabledEntries[0]
        }
        
        return nil
    }
    
    public static func getColorIndexForNodeName(chartData: ChartData,nodeName: String) -> Int? {
        
        return arrayOfNodeNames(chartData: chartData).firstIndex(of: nodeName)
    }
    
    public static func getCategorisedNodeByX(chartview: ChartViewBase) -> [Double:[SankyLayers]] {
        
        let layers = SankyLayers.getAllNodeLayer(chart: chartview)
            
        var categorisedLayers = [Double:[SankyLayers]]()
            
        for layer in layers {
                
            if let leftX = layer.rectPoints[.topLeft]?.x {
                    
                if categorisedLayers[leftX] == nil
                {
                    categorisedLayers[leftX] = [layer]
                }
                else{
                    categorisedLayers[leftX]?.append(layer)
                }
            }
        }
            
        return categorisedLayers
    }
    
    public static func arrayOfNodeNames(chartData: ChartData) -> [String] {
        
        var nodeStringArray = [String]()
        
        guard let dataset = chartData.dataSets[safe:0],
              let xString = chartData.xString,
              let yStringArr = chartData.yString,
              let yString = yStringArr[dataset.axisIndex] else {
            return nodeStringArray
        }
        
        nodeStringArray.append(contentsOf: xString)
        
        for nodeName in yString {
            if !nodeStringArray.contains(nodeName) {
                nodeStringArray.append(nodeName)
            }
        }
        
        return nodeStringArray
    }
    
    struct RectPointsInterpolatorForNode {
        var nodeName: String
        var rectPoints: [RectPoints:((CGFloat) -> CGFloat)]
    }
    
    struct RectPointsInterpolatorForLink {
        var entryIndex: Int
        var lineWidth: ((CGFloat) -> CGFloat)
        var rectPoints: [RectPoints:((CGFloat) -> CGFloat)]
    }
    
    static func SankeyInterpolator(chart: ChartViewBase,oldDataValues: [Any],newDataValues: [Any],dataset:ChartDataSet) -> ([RectPointsInterpolatorForNode],[RectPointsInterpolatorForLink]) {
        
        var nodeInterpolatorArr = [RectPointsInterpolatorForNode]()
        
        var linkInterpolatorArr = [RectPointsInterpolatorForLink]()
        
        guard let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions else {
            return (nodeInterpolatorArr,linkInterpolatorArr)
        }
        
        for (oldArrayVal,newArrayVal) in zip(oldDataValues, newDataValues) {
                    
            guard let oldParentObject = oldArrayVal as? NSDictionary,
                  let oldNodeObject = oldParentObject["nodes"] as? [NSDictionary],
                  let oldLinkObject = oldParentObject["links"] as? [NSDictionary],
                  
                  let newParentObject = newArrayVal as? NSDictionary,
                  let newNodeObject = newParentObject["nodes"] as? [NSDictionary],
                  let newLinkObject = newParentObject["links"] as? [NSDictionary]
            else { continue }
                        
            for nodeObject in oldNodeObject
            {
                guard let oldNodeName = nodeObject["name"] as? String,
                      let oldx0Value = nodeObject["x0"] as? CGFloat,
                      let oldx1Value = nodeObject["x1"] as? CGFloat,
                      let oldy0Value = nodeObject["y0"] as? CGFloat,
                      let oldy1Value = nodeObject["y1"] as? CGFloat
                else { continue }
                
                
                for newObject in newNodeObject {
                    
                    guard let newNodeName = newObject["name"] as? String else {
                        continue
                    }
                    
                    if newNodeName == oldNodeName {
                        
                        guard let newx0Value = newObject["x0"] as? CGFloat,
                              let newx1Value = newObject["x1"] as? CGFloat,
                              let newy0Value = newObject["y0"] as? CGFloat,
                              let newy1Value = newObject["y1"] as? CGFloat
                        else { break }
                        
                        let x0Interpolator = Interpolator.interpolate(a: oldx0Value, b: newx0Value)
                        
                        let x1Interpolator = Interpolator.interpolate(a: oldx1Value, b: newx1Value)
                        
                        let y0Interpolator = Interpolator.interpolate(a: oldy0Value, b: newy0Value)
                        
                        let y1Interpolator = Interpolator.interpolate(a: oldy1Value, b: newy1Value)
                        
                        var rectPoints = [RectPoints:((CGFloat) -> CGFloat)]()
                        
                        rectPoints[.topLeft] = x0Interpolator
                        rectPoints[.topRight] = x1Interpolator
                        rectPoints[.bottomLeft] = y0Interpolator
                        rectPoints[.bottomRight] = y1Interpolator
                        
                        nodeInterpolatorArr.append(RectPointsInterpolatorForNode(nodeName: newNodeName, rectPoints: rectPoints))
                        
                        break
                    }
                }
            }
            
            for linkObject in oldLinkObject {
                
                guard let sourceX = (linkObject["source"] as? NSDictionary)?["x1"] as? CGFloat,
                      let oldLinkIndex = linkObject["entryIndex"] as? Int,
                      let oldEntry = dataset.entryForIndex(oldLinkIndex),
                      !oldEntry.filterEnabled,
                      let linkTopLeft = (linkObject["y0"] as? CGFloat),
                      let linkTopRight = (linkObject["y1"] as? CGFloat),
                      let targetX = (linkObject["target"] as? NSDictionary)?["x0"] as? CGFloat,
                      let oldLinkWidth = (linkObject["width"] as? CGFloat)
                else { continue }
                
                let halfWidth = oldLinkWidth/2
                let oldx0Value = sourceX + plotOption.linkPadding
                let oldy0Value = linkTopLeft - halfWidth
                let oldx1Value = targetX - plotOption.linkPadding
                let oldy1Value = linkTopRight - halfWidth
                
                for newObject in newLinkObject {
                    
                    guard let newLinkIndex = newObject["entryIndex"] as? Int else {
                        continue
                    }
                    
                    if newLinkIndex == oldLinkIndex {
                        
                        guard let sourceX = (newObject["source"] as? NSDictionary)?["x1"] as? CGFloat,
                              let linkTopLeft = (newObject["y0"] as? CGFloat),
                              let linkTopRight = (newObject["y1"] as? CGFloat),
                              let targetX = (newObject["target"] as? NSDictionary)?["x0"] as? CGFloat,
                              let newLinkWidth = (newObject["width"] as? CGFloat)
                        else { continue }
                        
                        let halfWidth = newLinkWidth/2
                        let newx0Value = sourceX + plotOption.linkPadding
                        let newy0Value = linkTopLeft - halfWidth
                        let newx1Value = targetX - plotOption.linkPadding
                        let newy1Value = linkTopRight - halfWidth
                        
                        let x0Interpolator = Interpolator.interpolate(a: oldx0Value, b: newx0Value)
                        
                        let x1Interpolator = Interpolator.interpolate(a: oldx1Value, b: newx1Value)
                        
                        let y0Interpolator = Interpolator.interpolate(a: oldy0Value, b: newy0Value)
                        
                        let y1Interpolator = Interpolator.interpolate(a: oldy1Value, b: newy1Value)
                        
                        let linkWidth = Interpolator.interpolate(a: oldLinkWidth, b: newLinkWidth)
                        
                        var rectPoints = [RectPoints:((CGFloat) -> CGFloat)]()
                        
                        rectPoints[.topLeft] = x0Interpolator
                        rectPoints[.topRight] = x1Interpolator
                        rectPoints[.bottomLeft] = y0Interpolator
                        rectPoints[.bottomRight] = y1Interpolator
                        
                        linkInterpolatorArr.append(RectPointsInterpolatorForLink( entryIndex: newLinkIndex, lineWidth: linkWidth, rectPoints: rectPoints))
                        
                        break
                    }
                }
            }
            
            
        }
        
        return (nodeInterpolatorArr,linkInterpolatorArr)
    }
    
    public static func getAllSankeyValue(chart: ChartViewBase) -> [CALayer] {
        
        var layerArray:[CALayer] = []
        
        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: ValueTextLayer.self)
                {
                    layerArray.append((caLayer))
                }
            }
        }
        
        return layerArray
    }
    
    public static func linkStokePathFor(sankeyLayer: SankyLayers, chart:ChartViewBase) -> (CGMutablePath,CGFloat) {
        
        let newMaskPath = CGMutablePath()
        var linkLineWidth = sankeyLayer.lineWidth
        
        let rectPoints = sankeyLayer.rectPoints
        
        if sankeyLayer.type == .Link {
            
            guard let sourceX =  rectPoints[.topLeft]?.x,
                  let sourceY0 = rectPoints[.topLeft]?.y,
                  let sourceY1 = rectPoints[.bottomLeft]?.y,
                  let targetX = rectPoints[.topRight]?.x,
                  let targetY0 = rectPoints[.topRight]?.y,
                  let targetY1 = rectPoints[.bottomRight]?.y
            else { return  (newMaskPath,linkLineWidth)}
            
            let (c1,_) = sankeyLayer.getControlX(rectPoints: rectPoints)
            
            newMaskPath.move(to: CGPoint(x: sourceX, y: (sourceY0+sourceY1)/2))
            
            newMaskPath.addCurve(to: CGPoint(x: targetX, y: (targetY0+targetY1)/2), control1: CGPoint(x: c1, y: (sourceY0+sourceY1)/2) , control2: CGPoint(x: c1, y: (targetY0+targetY1)/2 ))
            
            linkLineWidth = (sourceY1 - sourceY0)+((sourceY1 - sourceY0)*0.2)
        }
        else if sankeyLayer.type == .CircularLink {
            
            guard let finalArray = (chart.getProcessor(type: .Sanky) as? SankeyPreprocessor)?.dataValues, let chartData = chart.data else {
                return (newMaskPath,linkLineWidth)
            }
        
            for arrayVal in finalArray {
            
                guard let parentObject = arrayVal as? NSDictionary,
                      let linkObject = parentObject["links"] as? [NSDictionary]
                else { continue }
                
                for link in linkObject
                {
                    guard let linkWidth = (link["width"] as? CGFloat),
                          let isCircular = (link["circular"] as? Bool)
                    else { continue }
                    
                    if isCircular
                    {
                        guard 
                            let linkIndex = link["entryIndex"] as? Int,
                            let entry = chartData.dataSets[0].entryForIndex(linkIndex),
                            entry === sankeyLayer.chartEntry,
                            let circularType = (link["circularLinkType"] as? String),
                            let pathDict = (link["circularPathData"] as? NSDictionary) else {
                            continue
                        }
                        
                        newMaskPath.addPath(constructCircularLinkStrokePath(chart: chart, circularType: circularType, pathDict: pathDict, linkWidth: linkWidth, linkPadding: 0.0)!)
                        
                        linkLineWidth = linkWidth * 2.0
                        break
                    }
                }
            }
        }
        
        return (newMaskPath,linkLineWidth)
    }
    
    public static func constructCircularLinkStrokePath(chart: ChartViewBase, circularType: String, pathDict: NSDictionary, linkWidth: CGFloat, linkPadding: CGFloat) -> CGPath? {
        
        var newPath = CGMutablePath()
        
        guard var sourceX = pathDict["sourceX"] as? CGFloat,
              var sourceY = pathDict["sourceY"] as? CGFloat,
              
              var targetX = pathDict["targetX"] as? CGFloat,
              var targetY = pathDict["targetY"] as? CGFloat,
            
              var leftInnerExtent = pathDict["leftInnerExtent"] as? CGFloat,
              var leftFullExtent = pathDict["leftFullExtent"] as? CGFloat,
              var leftSmallArcRadius = pathDict["leftSmallArcRadius"] as? CGFloat,
              
              var rightInnerExtent = pathDict["rightInnerExtent"] as? CGFloat,
              var rightFullExtent = pathDict["rightFullExtent"] as? CGFloat,
              var rightSmallArcRadius = pathDict["rightSmallArcRadius"] as? CGFloat,
              
              var verticalLeftInnerExtent = pathDict["verticalLeftInnerExtent"] as? CGFloat,
              var verticalRightInnerExtent = pathDict["verticalRightInnerExtent"] as? CGFloat,
              var verticalFullExtent = pathDict["verticalFullExtent"] as? CGFloat
        else { return nil }
        
        sourceY += (linkWidth/2.0)
        targetY += (linkWidth/2.0)
        
        chart.plotTransformer.xPointValueToPixel(&sourceX)
        chart.plotTransformer.yPointValueToPixel(&sourceY)
              
        chart.plotTransformer.xPointValueToPixel(&targetX)
        chart.plotTransformer.yPointValueToPixel(&targetY)
            
        chart.plotTransformer.xPointValueToPixel(&leftInnerExtent)
        chart.plotTransformer.xPointValueToPixel(&leftFullExtent)
        chart.plotTransformer.yPointValueToPixel(&leftSmallArcRadius)
              
        chart.plotTransformer.xPointValueToPixel(&rightInnerExtent)
        chart.plotTransformer.xPointValueToPixel(&rightFullExtent)
        chart.plotTransformer.yPointValueToPixel(&rightSmallArcRadius)

              
        chart.plotTransformer.yPointValueToPixel(&verticalLeftInnerExtent)
        chart.plotTransformer.yPointValueToPixel(&verticalRightInnerExtent)
        chart.plotTransformer.yPointValueToPixel(&verticalFullExtent)
        
        sourceX += linkPadding
        targetX -= linkPadding
            
        if (circularType == "top") {
            
            newPath.move(to: CGPoint(x: sourceX, y: sourceY))
            
            newPath.addLine(to: CGPoint(x: leftInnerExtent, y: sourceY))

            addArcp(pathValue: &newPath, from: CGPoint(x: leftInnerExtent, y: sourceY), to: CGPoint(x: leftFullExtent, y: sourceY-leftSmallArcRadius), inverted: true)
            
            newPath.addLine(to: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent), to: CGPoint(x: leftInnerExtent, y: verticalFullExtent), inverted: true)
            
            newPath.addLine(to: CGPoint(x: rightInnerExtent, y: verticalFullExtent))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: rightInnerExtent, y: verticalFullExtent), to: CGPoint(x: rightFullExtent, y: verticalRightInnerExtent), inverted: true)
            
            newPath.addLine(to: CGPoint(x: rightFullExtent, y: targetY-rightSmallArcRadius))
            
            addArcp(pathValue: &newPath, from: CGPoint(x: rightFullExtent, y: targetY-rightSmallArcRadius), to: CGPoint(x: rightInnerExtent, y: targetY), inverted: true)
            
            newPath.addLine(to: CGPoint(x: targetX, y: targetY))

            newPath.closeSubpath()
            
        } else {
            
            newPath.move(to: CGPoint(x: sourceX, y: sourceY))
                
            newPath.addLine(to: CGPoint(x: leftInnerExtent, y: sourceY))

            addArcp(pathValue: &newPath, from: CGPoint(x: leftInnerExtent, y: sourceY), to: CGPoint(x: leftFullExtent, y: sourceY+leftSmallArcRadius), inverted: false)
                
            newPath.addLine(to: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: leftFullExtent, y: verticalLeftInnerExtent), to: CGPoint(x: leftInnerExtent, y: verticalFullExtent), inverted: false)
                
            newPath.addLine(to: CGPoint(x: rightInnerExtent, y: verticalFullExtent))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: rightInnerExtent, y: verticalFullExtent), to: CGPoint(x: rightFullExtent, y: verticalRightInnerExtent), inverted: false)
                
            newPath.addLine(to: CGPoint(x: rightFullExtent, y: targetY+rightSmallArcRadius))
                
            addArcp(pathValue: &newPath, from: CGPoint(x: rightFullExtent, y: targetY+rightSmallArcRadius), to: CGPoint(x: rightInnerExtent, y: targetY), inverted: false)
                
            newPath.addLine(to: CGPoint(x: targetX, y: targetY))

            newPath.closeSubpath()
        }
        
        return newPath//.cgPath
    }
}

extension SankeyHelperFunctions {
    
    fileprivate static func performPathAnim(targetLayer:CAShapeLayer,newPath:CGPath,duration:TimeInterval)
    {
        let anim = CABasicAnimation(keyPath: "path")
        
        targetLayer.opacity = 1.0
        
        anim.fromValue = targetLayer.path
        
        anim.toValue = newPath
        
        anim.duration = duration
        
        anim.timingFunction =  CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        anim.fillMode = .forwards
        anim.isRemovedOnCompletion = false
        
        targetLayer.add(anim, forKey: "path")
    }
    
    fileprivate static func getAllLinkPath(chart: ChartViewBase, newDataValues: [Any]) -> [CGPath] {
        
        var arrCGPath = [CGPath]()
        
        guard let plotOption = chart.getPlotOptions(type: .Sanky) as? SankeyPlotOptions else {
            return arrCGPath
        }
        
        for newArrayVal in newDataValues {
            
            guard let newParentObject = newArrayVal as? NSDictionary,
                  let newLinkObject = newParentObject["links"] as? [NSDictionary]
            else { continue }
            
            for newObject in newLinkObject {
                
                guard let sourceX = (newObject["source"] as? NSDictionary)?["x1"] as? CGFloat,
                      let linkTopLeft = (newObject["y0"] as? CGFloat),
                      let linkTopRight = (newObject["y1"] as? CGFloat),
                      let targetX = (newObject["target"] as? NSDictionary)?["x0"] as? CGFloat,
                      let newLinkWidth = (newObject["width"] as? CGFloat),
                      let isCircular = (newObject["circular"] as? Bool)
                    else { continue }
                
                if isCircular {
                    
                    guard let circularType = (newObject["circularLinkType"] as? String),
                          let pathDict = (newObject["circularPathData"] as? NSDictionary) else {
                        continue
                    }
                    
                        // Need to check
                    if let circularLinkPath = constructCircularLink(chart: chart, circularType: circularType, pathDict: pathDict, linkWidth: newLinkWidth, linkPadding: plotOption.linkPadding,firstLinkX: 0,lastLinkX: 0, toAdjustHalf: 0, firstNodeX:0, lastNodeX:0) {
                        
                        arrCGPath.append(circularLinkPath)
                    }
                }
                else {
                    let halfWidth = newLinkWidth/2
                    var x0 = sourceX + plotOption.linkPadding
                    let y0 = linkTopLeft - halfWidth
                    var x1 = targetX - plotOption.linkPadding
                    let y1 = linkTopRight - halfWidth
                    
                    var newRect:[RectPoints:CGPoint] = [:]
                    newRect[.topLeft] = CGPoint(x: x0, y: y0)
                    newRect[.bottomLeft] = CGPoint(x: x0, y: y0+newLinkWidth)
                    newRect[.topRight] = CGPoint(x: x1, y: y1)
                    newRect[.bottomRight] = CGPoint(x: x1, y: y1+newLinkWidth)
                    
                    if let linkPath = constructLink(layer: SankyLayers.getAllNodeLayer(chart: chart)[0], newRect: newRect) {
                        arrCGPath.append(linkPath)
                    }
                }
            }
        }
        
        return arrCGPath
    }
}
