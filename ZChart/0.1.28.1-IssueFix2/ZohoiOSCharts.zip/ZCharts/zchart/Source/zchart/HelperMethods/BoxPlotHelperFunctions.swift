//
//  BoxPlotHelperFunctions.swift
//  zchart
//
//  Created by keerthi-pt4274 on 18/08/22.
//

import Foundation

class BoxPlotHelperFunctions {
    
    static func getPlotValues(chart: ChartViewBase, entry: ChartDataEntry) -> (CGPoint?,CGPoint?,CGPoint?){
        
        guard
            let data = chart.data,
            let boxPlotPlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.BoxPlot]) as? BoxPlotPlotOptions
            else { return (nil,nil,nil)}
        
        if let valArr = entry.plotData as? [Double] {

            let minWhiskers = valArr[safe:boxPlotPlotOption.minWhiskersIndex]

            let maxWhiskers = valArr[safe: boxPlotPlotOption.maxWhiskersIndex]
            
            let medianVal = valArr[safe: boxPlotPlotOption.medianIndex]
            
            var minWhiskersPoint: CGPoint? = nil
            
            var maxWhiskersPoint: CGPoint? = nil
            
            var medianPoint: CGPoint? = nil
            
            if medianVal != nil {
                
                medianPoint = CGPoint(x: entry.x, y: medianVal!)
                
                medianPoint = chart.pixelForValues(point: medianPoint!, axisIndex: data.dataSets[0].axisIndex)
            }

            if minWhiskers != nil {

                minWhiskersPoint = CGPoint(x: entry.x, y: minWhiskers!)

                minWhiskersPoint = chart.pixelForValues(point: minWhiskersPoint!, axisIndex: data.dataSets[0].axisIndex)
            }

            if maxWhiskers != nil {

                maxWhiskersPoint = CGPoint(x: entry.x, y: maxWhiskers!)

                maxWhiskersPoint = chart.pixelForValues(point: maxWhiskersPoint!, axisIndex: data.dataSets[0].axisIndex)

            }
            
            return (minWhiskersPoint,maxWhiskersPoint,medianPoint)
        }
        return (nil,nil,nil)
    }
    
    static func prepareArrayOfPlotValues(chart: ChartViewBase,dataset: IChartDataSet) -> [[CGRect?]]{
        
        var plotValues = [[CGRect?]]()
        
        for entryIndex in 0..<dataset.entryCount {
            
            guard let entry = dataset.entryForIndex(entryIndex) else {
                plotValues.append([CGRect?]())
                continue
            }
            
            let (minWhiskersPoint,maxWhiskersPoint,medianPoint) = getPlotValues(chart: chart, entry: entry)
            
            var entryRect = [CGRect?]()
            
            if let minWhiskersPoint = minWhiskersPoint {
                entryRect.append(CGRect(origin: minWhiskersPoint, size: CGSize()))
            }
            else {
                entryRect.append(nil)
            }
            
            if let maxWhiskersPoint = maxWhiskersPoint {
                entryRect.append(CGRect(origin: maxWhiskersPoint, size: CGSize()))
            }
            else {
                entryRect.append(nil)
            }
            
            if let medianPoint = medianPoint {
                entryRect.append(CGRect(origin: medianPoint, size: CGSize()))
            }
            else {
                entryRect.append(nil)
            }
            
            plotValues.append(entryRect)
        }
        
        return plotValues
    }
}
