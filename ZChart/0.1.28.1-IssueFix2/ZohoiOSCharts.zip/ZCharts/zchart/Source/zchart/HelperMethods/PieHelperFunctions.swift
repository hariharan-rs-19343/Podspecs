//
//  PieHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 31/10/18.
//  Copyright © 2018 zoho. All rights reserved.
//


import Foundation

import AVFoundation

open class PieHelperFunctions
{
    
    /// SpinWheel Highlight
    public static func rotateAndHighlight(location:CGPoint,chart:ChartViewBase)
    {
        let pieChart = chart
        
        let high = pieChart.getHighlightByTouchPoint(location)
        
        if high != nil {
            taprotate(chart: chart, high: high!,location: location,rotation: false,addangle:0, duration: 1.5)
        }
    }
    
    /// Enable Pie Slice
    public static func enableSlice(chartEntry: ChartDataEntry, chart:ChartViewBase, duration: TimeInterval,animation: ChartEasingOption)
    {
        let pieChart = chart
        
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        chartEntry.enabled = true
        
        
        if piePlot.spinAnimator != nil
        {
            piePlot.spinAnimator.stop()
        }
        
        guard (chartEntry.oldValue) != nil
        else { return }
        
        let originalVal:CGFloat = CGFloat((chartEntry.oldValue)!)
        
        let yValue = Interpolator.interpolate(a: 0, b: Double(originalVal))
        
        piePlot.spinAnimator = Animator()
        piePlot.spinAnimator.delegate = pieChart
        
        piePlot.spinAnimator.updateBlock = {
            chartEntry.y = yValue(piePlot.spinAnimator.phaseX)
            pieChart.data?.setDrawValues(false)
            pieChart.highlightValue(nil, callDelegate: true)
            
        }
        piePlot.spinAnimator.stopBlock = {
            piePlot.spinAnimator = nil
            pieChart.calcMinMax()
            pieChart.setNeedsDisplay()
            guard ((pieChart.data?.valuesEnabled) != nil)
            else { return }
            pieChart.data?.setDrawValues((pieChart.data?.valuesEnabled)!)
            if piePlot.arrowShow
            {
                pieChart.data?.setDrawValues(false)
                PieHelperFunctions.positionMid(chart: pieChart, duration: 1.5)
            }
            var entryToAdd:[ChartDataEntry] = []
            entryToAdd.append(chartEntry)
            chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entryToAdd, dataSets: nil, dataSetAdded: false)
            
        }
        
        piePlot.spinAnimator.animate(xAxisDuration: duration, easingOption: animation)
    }
    
    /// Disable Pie Slice
    public static func disableSlice(chartEntry: ChartDataEntry,chart:ChartViewBase,duration: TimeInterval,animation: ChartEasingOption)
    {
        let pieChart = chart
        
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        chartEntry.enabled = false
        
        
        if piePlot.spinAnimator != nil
        {
            piePlot.spinAnimator.stop()
        }
        
        let originalVal:CGFloat = CGFloat(chartEntry.y)
        
        let yValue = Interpolator.interpolate(a: Double(originalVal), b: 0 )
        
        piePlot.spinAnimator = Animator()
        piePlot.spinAnimator.delegate = pieChart
        
        
        piePlot.spinAnimator.updateBlock = {
            chartEntry.y = yValue(piePlot.spinAnimator.phaseX)  // Double(originalVal - (originalVal * CGFloat(pieChart.spinAnimator.phaseX)))
            pieChart.highlightValue(nil, callDelegate: true)
            pieChart.data?.setDrawValues(false)
            
        }
        
        piePlot.spinAnimator.stopBlock = {
            piePlot.spinAnimator = nil
            pieChart.calcMinMax()
            pieChart.setNeedsDisplay()
            guard ((pieChart.data?.valuesEnabled) != nil)
            else { return }
            pieChart.data?.setDrawValues((pieChart.data?.valuesEnabled)!)
            chartEntry.layerEnabled = false
            
            var removedEntries:[ChartDataEntry] = []
            removedEntries.append(chartEntry)
            
            chart.delegateToContainer?.chartValueRemoved?(chart, entries: removedEntries, dataSets: nil, dataSetRemoved: false, showTrackerView: false)
            
            if piePlot.arrowShow
            {
                pieChart.data?.setDrawValues(false)
                PieHelperFunctions.positionMid(chart: pieChart, duration:1.5)
            }
            
        }
        
        piePlot.spinAnimator.animate(xAxisDuration: duration, easingOption: animation)
    }
    
    /// Disable Pie Slice
    public static func removeEntries(entries: [ChartDataEntry],chart:ChartViewBase,duration: TimeInterval,animation: ChartEasingOption)
    {

        guard let chartData = chart.data,
            let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        var yInterpolator:[((Double) -> Double)] = []
        
        for chartEntry in entries
        {
            chartEntry.enabled = false
            let interpolator = Interpolator.interpolate(a: Double(chartEntry.y), b: 0 )
            yInterpolator.append(interpolator)
        }
        
        if piePlot.spinAnimator != nil
        {
            piePlot.spinAnimator.stop()
        }
        
        piePlot.spinAnimator = Animator()
        
        piePlot.spinAnimator.delegate = chart
        
        piePlot.spinAnimator.updateBlock = {
            
            for index in 0..<entries.count
            {
                let chartEntry = entries[index]
                chartEntry.y = yInterpolator[index](piePlot.spinAnimator.phaseX)
            }
            chart.highlightValue(nil, callDelegate: true)
            chartData.setDrawValues(false)
        }
        
        piePlot.spinAnimator.stopBlock = {
           
            piePlot.spinAnimator = nil
            
            chart.calcMinMax()
            
            chart.setNeedsDisplay()
            
            guard ((chartData.valuesEnabled) != nil)
            else { return }
            chartData.setDrawValues((chartData.valuesEnabled)!)
            
            for chartEntry in entries
            {
                chartEntry.layerEnabled = false
            }
            
            chart.delegateToContainer?.chartValueRemoved?(chart, entries: entries, dataSets: nil, dataSetRemoved: false, showTrackerView: false)
            
            if piePlot.arrowShow
            {
                chartData.setDrawValues(false)
                PieHelperFunctions.positionMid(chart: chart, duration:1.5)
            }
            
        }
        
        piePlot.spinAnimator.animate(xAxisDuration: duration, easingOption: animation)
    }
    
    /// Enable Pie Slice
    public static func includeEntries(entries: [ChartDataEntry], chart:ChartViewBase, duration: TimeInterval,animation: ChartEasingOption)
    {
        let pieChart = chart
        
        guard let chartData = chart.data,
        let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        var yInterpolator:[((Double) -> Double)] = []
        
        for chartEntry in entries
        {
            guard let oldValue = chartEntry.oldValue
            else { continue }
            chartEntry.enabled = true
            let interpolator = Interpolator.interpolate(a: 0, b: oldValue )
            yInterpolator.append(interpolator)
        }
        
        
        
        if piePlot.spinAnimator != nil
        {
            piePlot.spinAnimator.stop()
        }
        
        piePlot.spinAnimator = Animator()
        
        piePlot.spinAnimator.delegate = pieChart
        
        piePlot.spinAnimator.updateBlock = {
            
            for index in 0..<entries.count
            {
                let chartEntry = entries[index]
                chartEntry.y = yInterpolator[index](piePlot.spinAnimator.phaseX)
            }
            chart.highlightValue(nil, callDelegate: true)
            chartData.setDrawValues(false)
            
        }
        piePlot.spinAnimator.stopBlock = {
            piePlot.spinAnimator = nil
            
            guard ((chartData.valuesEnabled) != nil)
            else { return }
            chartData.setDrawValues((chartData.valuesEnabled)!)
            
            if piePlot.arrowShow
            {
                chartData.setDrawValues(false)
                PieHelperFunctions.positionMid(chart: pieChart, duration: 1.5)
            }
            
            chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entries, dataSets: nil, dataSetAdded: false)
            
        }
        
        piePlot.spinAnimator.animate(xAxisDuration: duration, easingOption: animation)
    }
    
    /// Remove Pie Slice in Hidden State
    public static func deleteSliceWithNoFill(sliceLayer:PieLayer,high:Highlight,chart:ChartViewBase,duration: TimeInterval,animation: ChartEasingOption)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        let selectedEntry = chart.entryForHighlight(high)
        
        selectedEntry?.enabled = true
        
        selectedEntry?.layerEnabled = true
        
        piePlot.filterProgress = true
        
        selectedEntry?.filterEnabled = true
        
        selectedEntry?.centerChanged = piePlot.centerCircleBox
        
        guard (selectedEntry != nil)
        else { return }
        
        let originalVal:CGFloat = CGFloat((selectedEntry?.y)!)
        
        
        let yInterpolate = Interpolator.interpolate(a: Double(originalVal), b: Double(0))
        
        let sliceAnimator1 = Animator()
        sliceAnimator1.delegate = chart
        
        guard let dataInd = (chart.data?.dataSets[0].entryIndex(entry: selectedEntry!))
        else { return }
        
        sliceAnimator1.updateBlock = {
            selectedEntry?.y = yInterpolate(sliceAnimator1.phaseX)
            
            chart.data?.setDrawValues(false)
            
            chart.setNeedsDisplay()
            
        }
        
        sliceAnimator1.stopBlock = {
            
            var removedEntries:[ChartDataEntry] = []
            removedEntries.append(selectedEntry!)
            
            chart.delegateToContainer?.chartValueRemoved?(chart, entries: removedEntries, dataSets: nil, dataSetRemoved: false,  showTrackerView: false  )
            
            guard ((chart.data?.valuesEnabled) != nil)
            else { return }
            chart.data?.setDrawValues((chart.data?.valuesEnabled)!)
            selectedEntry?.filterEnabled = false
            piePlot.filterProgress = false
            chart.calcMinMax()
            chart.setNeedsDisplay()
            
            
        }
        
        sliceAnimator1.animate(xAxisDuration: duration, easingOption: .linear)
        
        
    }
    
    //----------------- Rotation ---------------------//
    
    /// Begin SpinWheel Rotation
    static func beginRotation(_ touches: Set<NSUITouch>,withEvent event: NSUIEvent?,chart:ChartViewBase)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        let touch = touches.first
        
        guard let touchLocation = touch?.location(in: chart)
        else { return }
        
        let  high = chart.getHighlightByTouchPoint(touchLocation)
        
        if high != nil
        {
            // To hide highlight
            chart.highlightValue(nil, callDelegate: true)
            
            //self.highlightValue(high)
            
            if piePlot.spinning
            {
                piePlot._spinAnimator.stop()
            }
            
            // To hide value during rotation
            let pieChart = chart
            pieChart.data?.setDrawValues(false)
            
            // chart.sliceOutAnimate(high: high!)
        }
        
        
        
        
        // if rotation by touch is enabled
        if piePlot.rotationEnabled
        {
            if high != nil{
                chart.stopDeceleration()
            }
            
            if !chart.rotationWithTwoFingers
            {
                //                let touch = touches.first as NSUITouch!
                //
                //                let touchLocation = touch?.location(in: self)
                
                PieHelperFunctions.processRotationGestureBegan(chart: chart, location: touchLocation)
            }
        }
        
        if !piePlot._isRotating && !chart._interceptTouchEvents
        {
            chart.superTouchBegan(touches, withEvent: event)
            
            // chart.super.nsuiTouchesBegan(touches, withEvent: event)
        }
    }
    
    
    /// Rotate SpinWheel
    static func moveRotation(_ touches: Set<NSUITouch>,withEvent event: NSUIEvent?,chart:ChartViewBase)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        let touch = touches.first
        
        guard let touchLocation = touch?.location(in: chart)
        else { return }
        
        let high = chart.getHighlightByTouchPoint(touchLocation)
        
        if high != nil
        {
            
            if piePlot.rotationEnabled && !chart.rotationWithTwoFingers
            {
                PieHelperFunctions.processRotationGestureMoved(chart: chart, location: touchLocation)
            }
            
            if !piePlot._isRotating && !chart._interceptTouchEvents
            {
                chart.superTouchMoved(touches, withEvent: event)
            }
        }
    }
    
    /// End SpinWheel Rotation
    static func endRotation(_ touches: Set<NSUITouch>,withEvent event: NSUIEvent?,chart:ChartViewBase)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        if !piePlot._isRotating
        {
            chart.superTouchEnd(touches, withEvent: event)
        }
        
        if piePlot.rotationEnabled && !chart.rotationWithTwoFingers
        {
            let touch = touches.first
            
            guard let touchLocation = touch?.location(in: chart)
            else { return }
            
            PieHelperFunctions.processRotationGestureEnded(chart: chart, location: touchLocation)
        }
        
        if piePlot._isRotating
        {
            piePlot._isRotating = false
        }
    }
    
    /// SpinWheel:- Position Arrow to Current Slice Mid Position
    public static func positionMid(chart:ChartViewBase, duration:TimeInterval)
    {
        positionMid(chart: chart, rotation: true, duration: duration)
    }
    
    /// SpinWheel:- Position Arrow to Current Slice Mid Position with One Rotation
    public static func rotateAndPositionMid(chart:ChartViewBase)
    {
        positionMid(chart: chart, rotation: false, duration:1.5)
    }
    
    /// Inner Circle Tap Action
    public static func getEntryForInnerCircleTap(pieChart: ChartViewBase) -> ChartDataEntry? {
        
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return nil }
        
        var finalEntry:ChartDataEntry? = nil
        
        if piePlot.arrowShow {
            let (_,entry) = getHighAndEntryForCurrentPoint(pieChart: pieChart)
            finalEntry = entry
        }
        else {
            finalEntry = pieChart.lastSelected?[0]
        }
        
        return finalEntry
    }
    
    
    /// Logic entracted from PositionMID method
    /// returns Current Entry Pointed By Arrow
    public static func getHighAndEntryForCurrentPoint(pieChart: ChartViewBase) -> (high:Highlight?, entry:ChartDataEntry?) {
        
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return (nil,nil) }
        
        let chartcenter = piePlot.centerCircleBox
        
        let chartradius = (piePlot.radius)/2
        
        var location:CGPoint? = nil
        
        if pieChart.isVertical
        {
            location = CGPoint(x:chartcenter.x , y: (chartcenter.y - chartradius))
        }
        else{
            location = CGPoint(x:(chartcenter.x - chartradius) , y: chartcenter.y)
        }
        
        guard (location != nil)
        else { return (nil,nil)}
        
        guard let high = pieChart.getHighlightByTouchPoint(location!)
        else { return (nil,nil)}
        
        let entry = pieChart.entryForHighlight(high)
        
        return (high, entry)
    }
    
    // SpinWheel:- Position Arrow to Current Slice Mid Position
    static func positionMid(chart:ChartViewBase,rotation:Bool,duration:TimeInterval)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return  }
        
        var toggle:Bool = false
        
        let pieChart = chart
        
        let chartcenter = piePlot.centerCircleBox
        
        let chartradius = (piePlot.radius)/2
        
        var location:CGPoint? = nil
        
        if pieChart.isVertical
        {
            toggle = false
        }
        else{
            toggle = true
        }
        
        
        if !rotation
        {
            if toggle
            {
                location = CGPoint(x:chartcenter.x , y: (chartcenter.y - chartradius))
            }
            else{
                location = CGPoint(x:(chartcenter.x - chartradius) , y: chartcenter.y)
            }
        }
        else{
            
            if pieChart.isVertical
            {
                location = CGPoint(x:chartcenter.x , y: (chartcenter.y - chartradius))
            }
            else{
                location = CGPoint(x:(chartcenter.x - chartradius) , y: chartcenter.y)
            }
        }
        
        guard (location != nil)
        else { return }
        
        let high = pieChart.getHighlightByTouchPoint(location!)
        
        if high != nil{
            taprotate(chart:chart,high: high!, location: location!, rotation: rotation, addangle: CGFloat(360), duration: duration)
        }
    }
    
    /// SpinWheel :- Perform Rotation to Given Slice
    public static func taprotate(chart:ChartViewBase,high:Highlight,location:CGPoint, rotation:Bool,addangle: CGFloat?,duration:TimeInterval)
    {
        let chartview = chart
        
        guard let piePlot = chartview.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        if piePlot.arrowShow
        {
            chart.highlightValue(high, callDelegate: true)
        }
        
        var angle =  PieHelperFunctions.angleForPoint(x: high.xPx, y: high.yPx, center: piePlot.centerCircleBox)
        
        let xIndex =  ChartUtils.doubleToIntSafeCast(value:(high.x))
        
        /*let drawAngles = pieChart.drawAngles
        
        let absAngles = pieChart.absoluteAngles
        
        if chartview is PieChartView
        {
            angle /= CGFloat(chartview.chartAnimator.phaseY)
        }
        
        let angleLength = drawAngles[xIndex]
        let absAngle = absAngles[xIndex]
        
        let totAngle = chartview.rotationAngle + absAngle
        
        let startAngle = (totAngle - angleLength)
        
        var midAngle = (startAngle + totAngle ) / 2
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }*/
        
        guard let chartEntry = chart.data?.dataSets[0].entryForIndex(xIndex)
        else { return }
        
        let midAngle = PieHelperFunctions.getMidAngle(chart: chart, entry: chartEntry)
        
        angle = midAngle
        
        //mid at 270
        
        var mydiff:CGFloat = 0.0
        
        if chartview.isVertical
        {
            if angle > 90 && angle < 270
            {
                mydiff = CGFloat(270)-angle+piePlot.rotationAngle
            }
            else
            {
                if angle > 0 && angle <= 90
                {
                    mydiff = (piePlot.rotationAngle-(angle+CGFloat(90)))
                    
                }
                else{
                    mydiff = piePlot.rotationAngle-(angle - CGFloat(270))
                    
                }
                
            }
        }
        else
        {
            if angle > 0 && angle < 180
            {
                mydiff = CGFloat(180)-angle+piePlot.rotationAngle
            }
            else
            {
                
                mydiff = piePlot.rotationAngle-(angle - CGFloat(180))
            }
        }
        
        //pieChart.data?.setDrawValues(false)
        
        
        if rotation
        {
            PieHelperFunctions.spin(pieChart:chart, duration: duration, fromAngle: piePlot.rotationAngle, toAngle: mydiff, easingOption: .easeOutBack)
        }
        else
        {
            guard (addangle != nil)
            else { return }
            PieHelperFunctions.spin(pieChart:chart, duration: duration, fromAngle: piePlot.rotationAngle, toAngle: mydiff+addangle!, easingOption: .easeOutBack)
        }
        
        
        
        
    }
    
    
    /// returns Entry and High Object for index
    public static func getHighAndEntryForEntryIndex(pieChart: ChartViewBase, entryIndex:Int) -> (high: Highlight?, entry: ChartDataEntry?)
    {
        
        let location = getLocationForEntryIndex(pieChart: pieChart, entryIndex: entryIndex)
        
        return CommonHelperFunctions.getHighAndEntryForPoint(chart: pieChart, location: location)
    }
    
    /// returns  mid Location for entryIndex
    public static func getLocationForEntryIndex(pieChart: ChartViewBase, entryIndex:Int) -> CGPoint
    {
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return CGPoint() }
        
       /* let rotAngle = pieChart.rotationAngle
        
        let drawAngle = pieChart.drawAngles[entryIndex]
        
        let absAngle = pieChart.absoluteAngles[entryIndex]
        
        let endAngle = rotAngle + absAngle
        
        let startAngle = (endAngle - drawAngle)
        
        var midAngle:CGFloat =  ((startAngle + endAngle) / 2.0)
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }*/
        
        guard let chartEntry = pieChart.data?.dataSets[0].entryForIndex(entryIndex)
        else { return CGPoint() }
        
        let midAngle = getMidAngle(chart: pieChart, entry: chartEntry)
        
        let location = PieHelperFunctions.getPosition(center: piePlot.centerCircleBox, dist: piePlot.radius/2, angle: midAngle)
        
        return location
    }
    
    public static func  getMidAngle(chart:ChartViewBase, entry:ChartDataEntry) -> CGFloat
    {
        guard  let data = chart.data,
                let piePlotOption = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else {
                    return 0
            }
        
        let xIndex = data.dataSets[0].entryIndex(entry: entry)
        
        var drawAngles = piePlotOption.drawAngles
        
        var absAngles = piePlotOption.absoluteAngles
        
        let dataSet = data.dataSets[0]
        
        var sliceSpaceAngle:CGFloat = 0.0
        
        if (piePlotOption.sliceSpace > 0) {
            
              var visibleAngleCount = 0
            
            for j in 0 ..<  dataSet.entryCount
             {
                guard let e = dataSet.entryForIndex(j) else { continue }
                if ((abs(e.y) > Double.ulpOfOne))
                {
                    visibleAngleCount += 1
                }
             }
            
//             let sliceSpaceAngle = visibleAngleCount == 1 ?
//             0.0 :
//                piePlotOption.sliceSpace / (ChartUtils.Math.FDEG2RAD * piePlotOption.radius)
//             (drawAngles, absAngles) = getDrawAbsoluteAngles(chart: chart, sliceSpaceAngle: sliceSpaceAngle)
            sliceSpaceAngle = visibleAngleCount == 1 ?
                        0.0 :
                           piePlotOption.sliceSpace / (ChartUtils.Math.FDEG2RAD * piePlotOption.radius)
        }
        
        let angleLength = drawAngles[xIndex] - sliceSpaceAngle
        let absAngle = absAngles[xIndex] - sliceSpaceAngle / 2.0
        
//        let totAngle = self.rotationAngle + absAngle
        
        var totAngle = piePlotOption.rotationAngle + absAngle
        
        if (piePlotOption.sliceDirection == .counterClockwise) {
            totAngle = piePlotOption.rotationAngle - absAngle
        }
        
//        let startAngle = (totAngle - angleLength)
        var startAngle = (totAngle - angleLength)
        if (piePlotOption.sliceDirection == .counterClockwise) {
            startAngle = (totAngle + angleLength)
        }
        
        var midAngle = (startAngle + totAngle ) / 2
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        if midAngle < 0 {
            midAngle = midAngle + 360
        }
        
        return midAngle
    }
    
    public static func getDrawAbsoluteAngles(chart:ChartViewBase, sliceSpaceAngle:CGFloat) -> (drawAngles:[CGFloat], absoluteAngles:[CGFloat]) {
        
        var drawAngles = [CGFloat]()
        var absoluteAngles = [CGFloat]()
        
        guard  let data = chart.data,
                    let piePlotOption = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
                else {
                        return (drawAngles,absoluteAngles)
                }
        
        let entryCount = data.entryCount
        
        piePlotOption.drawAngles.reserveCapacity(entryCount)
        piePlotOption.absoluteAngles.reserveCapacity(entryCount)
        
        let yValueSum = getYValueSum(chart: chart)
        
        let dataSets = data.dataSets
        
        var cnt = 0
        
        for i in 0 ..< data.dataSetCount
        {
            let set = dataSets[i]
            let entryCount = set.entryCount
            
            let nonZeroEntryCount = getNonZeroEntriesCount(set: set as! ChartDataSet)
            
            let newMaxAngle = piePlotOption.maxAngle - (sliceSpaceAngle * CGFloat(nonZeroEntryCount))
            
            for j in 0 ..< entryCount
            {
                guard let e = set.entryForIndex(j) else { continue }
                
                var y = e.y
                if y.isNaN {
                    y = 0
                }
                
                drawAngles.append(calcAngle(value: abs(y), yValueSum: yValueSum, maxAngle: newMaxAngle))
                
                if cnt == 0
                {
                    absoluteAngles.append(drawAngles[cnt])
                }
                else
                {
                    absoluteAngles.append(absoluteAngles[cnt - 1] + drawAngles[cnt])
                }
                
//                if y != 0 {
//                    absoluteAngles[absoluteAngles.count - 1] = absoluteAngles[absoluteAngles.count - 1] + sliceSpaceAngle
//                }
                
                cnt += 1
            }
        }
        
        return (drawAngles, absoluteAngles)
    }
    
    fileprivate static func getNonZeroEntriesCount(set: ChartDataSet) -> Int {
        
        let entries = set.values
        
        let validEntries =  entries.filter( { !($0.y.isNaN) && !($0.y.isZero) })
        
        return validEntries.count
    }
    
    fileprivate static func calcAngle(value: Double, yValueSum: Double, maxAngle:CGFloat) -> CGFloat
    {
        return CGFloat(value) / CGFloat(yValueSum) * maxAngle
    }
    
    /// Perform SliceINOUT Opertions
    public static func sliceInOut(sliceLayer:PieLayer,chart:ChartViewBase,duration:TimeInterval,animation:ChartEasingOption)
    {
        guard let entry = sliceLayer.chartEntry
            else { return }
        
        let pieChart = chart
        
        if pieChart.lastSelected != nil && pieChart.lastSelected!.count > 0
        {
            guard let lastSelectedLayer = PieLayer.getPieLayerForEntry(chart: chart, entry: pieChart.lastSelected![0])
                else { return }
            
            sliceIn(sliceLayer: lastSelectedLayer, chart: chart, duration: duration, completionBlock: nil)
            
            if !chart.IsEntrySelected(entry: entry) //entry != pieChart.lastSelected
            {
//                pieChart.lastSelected = entry
                pieChart.updateLastSelectedEntry(entry: entry)
                sliceOut(sliceLayer: sliceLayer, chart: pieChart, duration: duration, completionBlock: nil)
            }
            else
            {
                pieChart.lastSelected = nil
                
                guard (pieChart.data?.valuesEnabled) != nil
                else { return }
                if (pieChart.data?.valuesEnabled)!
                {
                    pieChart.data?.setDrawValues(true)
                }
            }
            
        }
        else
        {
//            pieChart.lastSelected = entry
            pieChart.updateLastSelectedEntry(entry: entry)
            sliceOut(sliceLayer: sliceLayer, chart: pieChart, duration: duration, completionBlock: nil)
            
        }
    }
    
    
    /// Performs SliceOut Operation
    public static func sliceOut(sliceLayer:PieLayer,chart:ChartViewBase,duration:TimeInterval, completionBlock: (() -> Void)?)
    {
        guard let piePlotOption = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
              (sliceLayer.chartEntry != nil)
          else {
                  return
          }
        
        let pieChart = chart
        
        let endPath = sliceLayer.getEndPath(pieChart: pieChart, entry: sliceLayer.chartEntry!, radius: piePlotOption.radius)
        
        CommonHelperFunctions.performPathAnim(targetLayer: sliceLayer, newPath: endPath, duration: duration, completionBlock: completionBlock)
        
    }
    
    /// Performs SliceIn Operation
    public static func sliceIn(sliceLayer:PieLayer, chart:ChartViewBase, duration:TimeInterval, completionBlock: (() -> Void)?)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
              (sliceLayer.chartEntry != nil)
            else { return }
        
        let startPath =  sliceLayer.getInitialPath(pieChart: chart, entry: sliceLayer.chartEntry!, radius: piePlot.radius)
        
        CommonHelperFunctions.performPathAnim(targetLayer: sliceLayer, newPath: startPath, duration: duration, completionBlock: completionBlock)
        
    }
    
    /// Animate Slice to Given Center
    public static func sliceMove(sliceLayer:PieLayer,high:Highlight,chart:ChartViewBase,duration:TimeInterval,nx:CGFloat, ny:CGFloat, completionBlock: (() -> Void)?)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
              (sliceLayer.chartEntry != nil)
        else { return }
        
        let pieChart = chart
        
        let newCenter = CGPoint(x: nx, y: ny)
        
        let endPath =  sliceLayer.getSlicePath(pieChart: pieChart, entry: sliceLayer.chartEntry!, pieCenter: newCenter, radius: piePlot.radius)
        
        CommonHelperFunctions.performPathAnim(targetLayer: sliceLayer, newPath: endPath, duration: duration, completionBlock: completionBlock)
    }
    
    /// Animate Slice to Given Radius
    public static func changeRadiusAnimator(sliceLayer:PieLayer,chart:ChartViewBase,duration:TimeInterval, fromRadius: CGFloat,toRadius: CGFloat, pieCenter:CGPoint,completionBlock: (() -> Void)?)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions,
              (sliceLayer.chartEntry != nil)
        else { return }
        
        if abs(toRadius-fromRadius) < (piePlot.radius/2) || duration == 0
        {
            let pieChart = chart
            
            let endPath = sliceLayer.getSlicePath(pieChart: pieChart, entry: sliceLayer.chartEntry!, pieCenter: pieCenter, radius: toRadius)
            
            CommonHelperFunctions.performPathAnim(targetLayer: sliceLayer, newPath: endPath, duration: duration, completionBlock: completionBlock)
        }
        else{
            
            let pieChart = chart
            
            let pieRadiusInterpolator = Interpolator.interpolate(a: Double(fromRadius), b: Double(toRadius))
            
            let sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = { [unowned pieChart] in
                
                let path = sliceLayer.getSlicePath(pieChart: pieChart, entry: sliceLayer.chartEntry!, pieCenter: pieCenter, radius: CGFloat(pieRadiusInterpolator(sliceAnimator.phaseX)))
                
                sliceLayer.path = path//.cgPath
                
                GradientLayerRenderer.performGradientLayerPathAnimation(targetLayer: sliceLayer, newPath: path, duration: 0)
                
                
                //            GradientLayerRenderer.updateGradientLayerPath(targetLayer: sliceLayer, newPath: path) Will check
                
            }
            
            sliceAnimator.stopBlock = { [unowned sliceAnimator] in
                sliceAnimator.updateBlock = nil
                if completionBlock != nil {
                    completionBlock!()
                }
            }
            
            
            sliceAnimator.animate(xAxisDuration: duration, easingOption: .linear)
        }
        
    }
    
    //-------------------************* UNUSED ****************----------------------//
    public static func deleteSlice(high:Highlight,chart:ChartViewBase,duration: TimeInterval,animation: ChartEasingOption)
    {
        guard let chartEntry = chart.entryForHighlight(high),
              let dataInd = (chart.data?.dataSets[0].entryIndex(entry: chartEntry))
        else { return }
        
        
        
        disableSlice(chartEntry:chartEntry, chart: chart,duration: duration,animation: animation)
        
        var removedEntries:[ChartDataEntry] = []
        removedEntries.append(chartEntry)
        
        chart.delegateToContainer?.chartValueRemoved?(chart, entries: removedEntries, dataSets: nil, dataSetRemoved: false,  showTrackerView: false  )
    }
    
    public static func changeOuterCircleLayer(pieRadChart:ChartViewBase,radius:CGFloat)
    {
        guard let piePlot = pieRadChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
    
        //        pieChart.outerCircleEnabled = false
        //        pieRadChart.pieComponents?.outerCircle()
        //
        
        //pieRadChart.setNeedsDisplay()
        
        let outerLayer = piePlot.pieComponents.getOuterLayer()
        
        if outerLayer != nil{
            
//            let endPath = UIBezierPath(arcCenter: piePlot.centerCircleBox, radius: (piePlot.radius+radius)+(4.5), startAngle: CGFloat(0), endAngle:CGFloat(360), clockwise:true)
            let endPath = CGMutablePath()
            endPath.addArc(center: piePlot.centerCircleBox, radius: (piePlot.radius+radius)+(4.5), startAngle: CGFloat(0), endAngle: CGFloat(360), clockwise: true)
            CATransaction.begin()
            
            let anim = CABasicAnimation(keyPath: "path")
            
            anim.fromValue = outerLayer?.path
            anim.toValue = endPath//.cgPath
            anim.duration = 0.2
            anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            //        CATransaction.setCompletionBlock(completionBlock)
            outerLayer?.add(anim, forKey: "changeRadius")
            
            CATransaction.commit()
            
            outerLayer?.path = endPath//.cgPath
        }
        
    }
    
    public static func removeOuterCircleLayer(pieChart:ChartViewBase)
    {
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        piePlot.pieComponents.removeOuterLayer()
        piePlot.outerCircleEnabled = true
    }
    
    // MARK: - Plot Options
    
    public static func getPiePlotOptions(chart:ChartViewBase) -> PiePlotOptions?
    {
            if let plot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            {
                return plot
            }
            if let plot = chart.getPlotOptions(type: .Dial) as? PiePlotOptions
            {
                return plot
            }
            return nil
    }
    
    
    // MARK: - Chart Filter In/Out Handled
       
    public static func chartEntryEnabled(chart:ChartViewBase, entry: [ChartDataEntry],duration:TimeInterval) {
       
       let entry = entry[0]
       
       if chart._tapEventListener?.handler?.getEventHandlerType() == EventHandlerType.sliceout
       {
           if chart.lastSelected != nil && chart.lastSelected!.count > 0
           {
               guard let lastSelectedLayer = PieLayer.getPieLayerForEntry(chart: chart, entry: chart.lastSelected![0])
               else { return }
               PieHelperFunctions.sliceIn(sliceLayer: lastSelectedLayer, chart: chart, duration: (0.9*duration), completionBlock: nil)
               chart.lastSelected = nil
           }
       }
       
        chart.removedCount -= 1
       
       PieHelperFunctions.enableSlice(chartEntry: entry, chart: chart, duration: duration,animation: .linear)
       
   }
    
    
    public static func isInnerCircleTouched(chart:ChartViewBase, location:CGPoint) -> Bool {
           
           var isTouched:Bool = false
        
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
               else { return false }
           
           if piePlot.innerCircleEnabled
           {
               guard let innerLayer = piePlot.pieComponents.innerLayer,
                        (innerLayer.path != nil)
                   else { return false }
               if (innerLayer.path?.contains(location))!
               {
                   isTouched = true
               }
           }
           return isTouched
    }
   
   
   
    public static func removeEntry(chart:ChartViewBase, entry: ChartDataEntry) {
       
       if chart._tapEventListener?.handler?.getEventHandlerType() == EventHandlerType.sliceout
       {
           if chart.lastSelected != nil && chart.lastSelected!.count > 0
           {
               guard let lastSelectedLayer = PieLayer.getPieLayerForEntry(chart: chart, entry: chart.lastSelected![0])
               else { return }
               PieHelperFunctions.sliceIn(sliceLayer: lastSelectedLayer, chart: chart, duration: (0.3), completionBlock: nil)
               chart.lastSelected = nil
           }
       }
       
       guard let dataSet = chart.data?.dataSets[0]
        else { return }
       
        if ((dataSet.entryCount) - chart.removedCount) > 1
       {
            chart.removedCount += 1
           
           PieHelperFunctions.disableSlice(chartEntry: entry, chart: chart, duration: 0.4,animation: .linear)
       }
       
       
   }
    
    // MARK: - Dial
    
    public static func prepareLevelValues(chart:ChartViewBase, dataset: IChartDataSet,levelMarker: [Double]) -> [Double]{
        
        var tempLevelArray:[Double] = []
        
        for level in levelMarker where !(level.isNaN)
        {
            tempLevelArray.append(level)
        }
        
        tempLevelArray.append(0)
        
        tempLevelArray = tempLevelArray.sorted(by: {
            $0 < $1
        })
        
        return tempLevelArray
    }
    
    public static func getLevelMarkerPath(chart:ChartViewBase, dataset: IChartDataSet, entryIndex: Int, fromVal: inout Double, toVal: inout Double, innerRadius: CGFloat, outerRadius: CGFloat, phaseY:Double) -> CGMutablePath {
        
        guard let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              let transformer = chart.getTransformer(axisIndex: dataset.axisIndex) as? PolarTransformer,
              let yAxis = chart.getYAxis(atIndex: dataset.axisIndex)
              else {return CGMutablePath()}
        
        if fromVal > yAxis.axisMaximum
        {
            fromVal = yAxis.axisMaximum
        }

        if fromVal < yAxis.axisMinimum
        {
            fromVal = yAxis.axisMinimum
        }
        
        let startAngle = transformer.absoluteAngleForValue(value: fromVal)
          
        if toVal > yAxis.axisMaximum
        {
            toVal = yAxis.axisMaximum
        }

        if toVal < yAxis.axisMinimum
        {
            toVal = yAxis.axisMinimum
        }
        
        let rect = CGRect(x: 0, y: 0, width: abs(abs(fromVal - toVal)), height: abs(abs(fromVal - toVal)))
        
        var endAngle = rect.applying(transformer.valueToPixelMatrix).height
        
        endAngle = endAngle > dialOption.maxAngle ? dialOption.maxAngle : endAngle
    
        return getSlicePath(chart:chart, dataSet: dataset, entryIndex: entryIndex, visibleAngleCount: dataset.entryCount, startAngle: startAngle, sliceAngle: endAngle, innerRadius: innerRadius, outerRadius: outerRadius, animate: false, phaseY: phaseY)
    }
    
    public static func getSlicePath(chart:ChartViewBase, dataSet:IChartDataSet,entryIndex:Int,visibleAngleCount:Int,startAngle:CGFloat,sliceAngle:CGFloat,innerRadius:CGFloat,outerRadius:CGFloat,animate:Bool, phaseY:Double) -> CGMutablePath
    {
        let path = CGMutablePath()
        
        guard
            let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
        let entry = dataSet.entryForIndex(entryIndex)
        else { return path }
        
        let angle: CGFloat = 0.0
        let phaseY = animate ? phaseY : 1
        let center = entry.filterEnabled ? (entry.centerChanged ?? dialOption.centerCircleBox) : dialOption.centerCircleBox
        let radius = outerRadius
        let drawInnerArc = true
        let clockwiseDirection = dialOption.direction == .clockwise
        let isFullDial = sliceAngle == 360.0
        let angleDifference = isFullDial ? 0.0 : computeAngleDifferenceForRoundedCorners(chart: chart, innerRadius: innerRadius, outerRadius: outerRadius)
        let startAngle = clockwiseDirection ? startAngle + angleDifference : startAngle - angleDifference
        let sliceAngle = sliceAngle - (angleDifference * 2.0)

        
        let sliceSpace = visibleAngleCount <= 1 ? 0.0 : getSliceSpace(chart: chart, dataSet: dataSet)
        let accountForSliceSpacing = sliceSpace > 0.0 && sliceAngle <= 180.0
        let sliceSpaceAngleOuter = visibleAngleCount == 1 ? 0.0 : sliceSpace / (ChartUtils.Math.FDEG2RAD * radius)
        
        var startAngleOuter = startAngle + (angle + sliceSpaceAngleOuter / 2.0) * CGFloat(phaseY)
        
        if (!clockwiseDirection) {
            startAngleOuter = startAngle + (angle - sliceSpaceAngleOuter / 2.0) * CGFloat(phaseY)
        }
        
        var sweepAngleOuter = (sliceAngle - sliceSpaceAngleOuter) * CGFloat(phaseY)
        
//        if sweepAngleOuter < 0.0
//        {
//            sweepAngleOuter = 0.0
//        }
        if (!clockwiseDirection) {
            sweepAngleOuter = -sweepAngleOuter
        }
        
        let arcStartPointX = center.x + radius * cos(startAngleOuter * ChartUtils.Math.FDEG2RAD)
        let arcStartPointY = center.y + radius * sin(startAngleOuter * ChartUtils.Math.FDEG2RAD)
        
        path.move(to: CGPoint(x: arcStartPointX, y: arcStartPointY))
            
        path.addRelativeArc(center: center, radius: radius, startAngle: startAngleOuter * ChartUtils.Math.FDEG2RAD, delta: sweepAngleOuter * ChartUtils.Math.FDEG2RAD)

        if drawInnerArc && (innerRadius > 0.0 || accountForSliceSpacing)
        {
            if accountForSliceSpacing
            {
            }
                
            let sliceSpaceAngleInner = visibleAngleCount == 1 || innerRadius == 0.0 ?
                    0.0 :
                    sliceSpace / (ChartUtils.Math.FDEG2RAD * innerRadius)
            
            var startAngleInner = startAngle + (angle + sliceSpaceAngleInner / 2.0) * CGFloat(phaseY)
            
            if (!clockwiseDirection) {
                startAngleInner = startAngle + (angle - sliceSpaceAngleInner / 2.0) * CGFloat(phaseY)
            }
                
            var sweepAngleInner = (sliceAngle - sliceSpaceAngleInner) * CGFloat(phaseY)
            
//            if sweepAngleInner < 0.0
//            {
//                sweepAngleInner = 0.0
//            }
            
            if (!clockwiseDirection) {
                sweepAngleInner = -sweepAngleInner
            }
            
            let endAngleInner = startAngleInner + sweepAngleInner
            
            let angleForRoundedCorners = dialOption.direction == .clockwise ? 180 * ChartUtils.Math.FDEG2RAD : -180 * ChartUtils.Math.FDEG2RAD
            
            if dialOption.roundedCorners && !isFullDial
            {
                let midRadius = (radius + innerRadius)/2
                let midEndCenter = CGPoint(
                                   x: center.x + midRadius * cos(endAngleInner * ChartUtils.Math.FDEG2RAD),
                                   y: center.y + midRadius * sin(endAngleInner * ChartUtils.Math.FDEG2RAD))
                       
                path.addRelativeArc(center: midEndCenter, radius: (radius - innerRadius)/2, startAngle: endAngleInner * ChartUtils.Math.FDEG2RAD, delta: angleForRoundedCorners)
            }
            else{
                path.addLine(
                        to: CGPoint(
                            x: center.x + innerRadius * cos(endAngleInner * ChartUtils.Math.FDEG2RAD),
                            y: center.y + innerRadius * sin(endAngleInner * ChartUtils.Math.FDEG2RAD)))
            }
            
            path.addRelativeArc(center: center, radius: innerRadius, startAngle: endAngleInner * ChartUtils.Math.FDEG2RAD, delta: -sweepAngleInner * ChartUtils.Math.FDEG2RAD)
            
            if dialOption.roundedCorners && !isFullDial
            {
                let midRadius = (radius + innerRadius)/2
                let midStartCenter = CGPoint(
                                    x: center.x + midRadius * cos(startAngleOuter * ChartUtils.Math.FDEG2RAD),
                                    y: center.y + midRadius * sin(startAngleOuter * ChartUtils.Math.FDEG2RAD))
                        
                let startAngleOuterCalculated = (startAngleOuter + 180) > 360 ? ((startAngleOuter + 180)-360) : (startAngleOuter + 180)
                path.addRelativeArc(center: midStartCenter, radius: (radius - innerRadius)/2, startAngle: startAngleOuterCalculated * ChartUtils.Math.FDEG2RAD, delta: angleForRoundedCorners)
           }
        }
        else
        {
            if accountForSliceSpacing
            {
                path.addLine(to: center)
            }
            else
            {
                path.addLine(to: center)
            }
        }
            
        path.closeSubpath()
        
        return path
    }
    
    static func computeAngleDifferenceForRoundedCorners(chart: ChartViewBase, innerRadius: Double,outerRadius: Double) -> Double {
        
        guard let dialPlotOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              dialPlotOption.roundedCorners,
              let yAxis = chart.yAxisArray.first,
                let transformer = chart.getTransformer(axisIndex: yAxis.axisIndex) as? PolarTransformer
        else {
            return 0.0
        }
                    
        let radius = outerRadius
        let bandWidth =  abs(radius - innerRadius)
        
        let midRadius = (radius + innerRadius)/2
        let center = dialPlotOption.centerCircleBox
                    
        var angle = yAxis.axisRange == 0 ? 1 : transformer.rangeForValue(yValue: yAxis.axisMaximum)
                    
        if dialPlotOption.direction != .clockwise {
            angle = -angle
        }
            
        let endAngle = dialPlotOption.startAngle + angle
            
        let angleForRoundedCorners = dialPlotOption.direction == .clockwise ? endAngle + 90 : endAngle - 90
            
        let bandWidthHalf = bandWidth / 2.0
            
        let midEndCenter = CGPoint(
                x: center.x + midRadius * cos(endAngle * ChartUtils.Math.FDEG2RAD),
                y: center.y + midRadius * sin(endAngle * ChartUtils.Math.FDEG2RAD))
            
        let arcPoint = ChartUtils.getPosition(center: midEndCenter, dist: bandWidthHalf, angle: angleForRoundedCorners)
        
        var midAngle = ceil(PieHelperFunctions.angleForPoint(x: midEndCenter.x, y: midEndCenter.y, center: center))
            
        var arcAngle = ceil(PieHelperFunctions.angleForPoint(x: arcPoint.x, y: arcPoint.y, center: center))
        
        midAngle = transformer.getAbsoluteAngleForGivenAngle(angle: midAngle)
        arcAngle = transformer.getAbsoluteAngleForGivenAngle(angle: arcAngle)
        
        return arcAngle - midAngle
    }
    
    public static func getSliceSpace(chart:ChartViewBase, dataSet: IChartDataSet) -> CGFloat
    {
        guard let piePlotOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
            piePlotOption.automaticallyDisableSliceSpacing,
              let viewPortHandler = chart.viewPortHandler
            else { return 0 }
        
        
        let spaceSizeRatio = piePlotOption.sliceSpace / min(viewPortHandler.contentWidth, viewPortHandler.contentHeight)
        let minValueRatio = dataSet.yMin / PieHelperFunctions.getYValueSum(chart: chart) * 2.0
        
        let sliceSpace = spaceSizeRatio > CGFloat(minValueRatio)
            ? 0.0
            : piePlotOption.sliceSpace
        
        return sliceSpace
    }
    
    // MARK: - Radius
    
    public static func getInnerOuterLevelRadius(chart:ChartViewBase) -> (inner:Double,outer:Double)
    {
        guard let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions
            else { return (0.0,0.0) }
        
        
        for renderer in chart.renderers {
            
            if let dialRenderer = renderer as? DialChartRenderer {
                return (dialRenderer.innerRadius - dialRenderer.innerLevelpading,dialOption.radius - dialRenderer.outerLevelpading)
            }
        }
        
        return (0.0,0.0)
    }
    
    public static func getDataInnerOuterRadius(chart:ChartViewBase) -> (inner:Double,outer:Double)
    {
        guard let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions
              else {return (0.0,0.0)}
        
        for renderer in chart.renderers {
            
            if let dialRenderer = renderer as? DialChartRenderer {
                return (dialRenderer.innerRadius + dialRenderer.innerpading,dialOption.radius + dialRenderer.outerpading)
            }
        }
        
        return (0.0,0.0)
    }
    
    // MARK: - Animation
       
   /// Applys a spin animation to the Chart.
    public static func spin(pieChart:ChartViewBase, duration: TimeInterval, fromAngle: CGFloat, toAngle: CGFloat, easing: ChartEasingFunctionBlock?)
   {
       /*        if _spinAnimator != nil
        {
        _spinAnimator.stop()
        }
        
        _spinAnimator = Animator()
        _spinAnimator.updateBlock = {
        self.rotationAngle = (toAngle - fromAngle) * CGFloat(self._spinAnimator.phaseX) + fromAngle
        }
        _spinAnimator.stopBlock = { self._spinAnimator = nil }
        
        _spinAnimator.animate(xAxisDuration: duration, easing: easing) */
    
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
       
        if piePlot._spinAnimator != nil
       {
        piePlot._spinAnimator.stopMiddle()
       }
       
        piePlot._spinAnimator = Animator()
        piePlot._spinAnimator.updateBlock = {
            piePlot.spinning = true
            if let spinAnimation = piePlot._spinAnimator {
                piePlot.rotationAngle = (toAngle - fromAngle) * CGFloat(spinAnimation.phaseX) + fromAngle
            }
            pieChart.setNeedsDisplay()
           
           //Update Tooltip
           //self.pieType.updatetooltip()
           
           
           if piePlot.arrowShow
           {
            self.checkForTickSound(chart: pieChart)
           }
           
           pieChart.data?.setDrawValues(false)
           
       }
      
        piePlot._spinAnimator.stopBlock = {
            
            piePlot._spinAnimator = nil
           
           //display value
           piePlot.spinning = false
           
            guard (pieChart.data?.valuesEnabled) != nil
            else { return }
           if (pieChart.data?.valuesEnabled)!
           {
               pieChart.data?.setDrawValues(true)
           }
       }
       
       piePlot._spinAnimator.animate(xAxisDuration: duration, easing: easing)
   }
   
    public static func spin(pieChart:ChartViewBase, duration: TimeInterval, fromAngle: CGFloat, toAngle: CGFloat, easingOption: ChartEasingOption)
   {
        spin(pieChart:pieChart, duration: duration, fromAngle: fromAngle, toAngle: toAngle, easing: easingFunctionFromOption(easingOption))
   }
   
   public static func spin(pieChart:ChartViewBase, duration: TimeInterval, fromAngle: CGFloat, toAngle: CGFloat)
   {
        spin(pieChart:pieChart, duration: duration, fromAngle: fromAngle, toAngle: toAngle, easing: nil)
   }
   
    public static func stopSpinAnimation(chart:ChartViewBase)
   {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
      
        if piePlot._spinAnimator != nil
        {
            piePlot._spinAnimator.stop()
        }
   }
   
   // MARK: - Gestures
   
   
    internal static func processRotationGestureBegan(chart:ChartViewBase, location: CGPoint)
   {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
    
        self.resetVelocity(chart: chart)
       
        if piePlot.rotationEnabled
       {
           self.sampleVelocity(chart: chart, touchLocation: location)
       }
       
        self.setGestureStartAngle(chart:chart, x: location.x, y: location.y)
       
        piePlot._rotationGestureStartPoint = location
   }
   
   internal  static func processRotationGestureMoved(chart:ChartViewBase, location: CGPoint)
   {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
    
        if chart.isDragDecelerationEnabled
       {
           sampleVelocity(chart:chart, touchLocation: location)
       }
       
        if !piePlot._isRotating &&
           distance(
               eventX: location.x,
               startX: piePlot._rotationGestureStartPoint.x,
               eventY: location.y,
               startY: piePlot._rotationGestureStartPoint.y) > CGFloat(1.0)
       {
          piePlot._isRotating = true
       }
       else
       {
        self.updateGestureRotation(x: location.x, y: location.y, chart: chart)
            chart.setNeedsDisplay()
       }
   }
   
   internal  static func processRotationGestureEnded(chart:ChartViewBase, location: CGPoint)
   {
        guard
            let processor = chart.getProcessor(type: .Pie) as? PieRadarPreprocessor
            else { return }
    
        if chart.isDragDecelerationEnabled
       {
            chart.stopDeceleration()
           
           sampleVelocity(chart: chart, touchLocation: location)
           
            chart._decelerationAngularVelocity = calculateVelocity(chart: chart)
           
            if chart._decelerationAngularVelocity != 0.0
           {

                chart._decelerationLastTime = CACurrentMediaTime()
                chart._decelerationDisplayLink = NSUIDisplayLink(target: processor.self, selector: #selector(PieRadarPreprocessor.decelerationLoop))
                chart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
           }
       }
   }
   
   internal  static func processRotationGestureCancelled(chart:ChartViewBase)
   {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        if piePlot._isRotating
       {
            piePlot._isRotating = false
       }
   }
    
    // MARK: - Supports
    
    public static func setPieRadarDecelerationLoop( displayLink:inout NSUIDisplayLink, chart:ChartViewBase)
    {
        guard let processor = chart.getProcessor(type: .Pie) as? PieRadarPreprocessor
        else { return }
        
        displayLink = NSUIDisplayLink(target: processor.self, selector: #selector(PieRadarPreprocessor.decelerationLoop))
    }
    
    
    internal static func tapHighlight(chart:ChartViewBase, location: CGPoint) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        var entry:ChartDataEntry? = nil
        
        let high = chart.getHighlightByTouchPoint(location)

        let sliceLayer = PieLayer.getPieLayerInPoint(chart: chart, loc: location)
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
        
       return (entry,sliceLayer)
        
    }
    
    /// updates the view rotation depending on the given touch position, also takes the starting angle into consideration
    internal static func updateGestureRotation(x: CGFloat, y: CGFloat, chart: ChartViewBase)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        piePlot.rotationAngle = self.angleForPoint(x: x, y: y, center: piePlot.centerCircleBox)  - piePlot._startAngle
        
        chart.setNeedsDisplay()
        
        //update tool tip
      //  pieType.updatetooltip()
      
        
        if piePlot.arrowShow
        {
            checkForTickSound(chart: chart)
        }
    }
    
    internal static func checkForTickSound(chart:ChartViewBase)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        var location:CGPoint? = nil
        let chartcenter = piePlot.centerCircleBox
        
        let chartradius = (piePlot.radius)/2
        
        if chart.isVertical
        {
            location = CGPoint(x:chartcenter.x , y: (chartcenter.y - chartradius))
        }
        else{
            location = CGPoint(x:(chartcenter.x - chartradius) , y: chartcenter.y)
        }
        
        guard (location != nil)
        else { return }
        
        let high = chart.getHighlightByTouchPoint(location!)
        
      //  self.highlightValue(high)
        
        if high == nil {
            return
        }
        
        let entry = chart.entryForHighlight(high!)
        
        if piePlot.prevSelectedEntry != nil && piePlot.prevSelectedEntry != entry {
            AudioServicesPlaySystemSound(1103)
        }
        piePlot.prevSelectedEntry = entry
    }
    
    /// - returns: The distance between two points
    public static func distance(eventX: CGFloat, startX: CGFloat, eventY: CGFloat, startY: CGFloat) -> CGFloat
    {
        let dx = eventX - startX
        let dy = eventY - startY
        return sqrt(dx * dx + dy * dy)
    }
    
    /// - returns: The distance between two points
    public static func distance(from: CGPoint, to: CGPoint) -> CGFloat
    {
        let dx = from.x - to.x
        let dy = from.y - to.y
        return sqrt(dx * dx + dy * dy)
    }
    
    public static func angleForPoint(x: CGFloat, y: CGFloat, center: CGPoint) -> CGFloat {
        
        let c = center
        
        let tx = Double(x - c.x)
        let ty = Double(y - c.y)
        let length = sqrt(tx * tx + ty * ty)
        let r = acos(ty / length)
        
        var angle = r * ChartUtils.Math.RAD2DEG
        
        if x > c.x
        {
            angle = 360.0 - angle
        }
        
        // add 90° because chart starts EAST
        angle = angle + 90.0
        
        // neutralize overflow
        if angle > 360.0
        {
            angle = angle - 360.0
        }
        
        return CGFloat(angle)
    }
    
    /// Calculates the position around a center point, depending on the distance
    /// from the center, and the angle of the position around the center.
    public static func getPosition(center: CGPoint, dist: CGFloat, angle: CGFloat) -> CGPoint
    {
        return CGPoint(x: center.x + dist * cos(angle * ChartUtils.Math.FDEG2RAD),
                       y: center.y + dist * sin(angle * ChartUtils.Math.FDEG2RAD))
    }
    
    internal static func updateRadius(chart:ChartViewBase, dialPlot:DialPlotOptions) -> CGFloat {
        
        let startAngle:CGFloat = dialPlot.startAngle
        let maxAngle:CGFloat = dialPlot.maxAngle
        let direction: SliceDirection = dialPlot.direction
        let radius: CGFloat = dialPlot.radius
        
        if maxAngle > 180 {
            return radius
        }
        
        var endAngle = startAngle + maxAngle
        
        let isClockwise = direction == .clockwise
        
        if !isClockwise {
            endAngle = startAngle - maxAngle
        }
        
        if endAngle >= 360 {
            endAngle = endAngle - 360
        }
        
        if endAngle < 0 {
            endAngle = 360 + endAngle
        }
        
        var radiusChanged: CGFloat = radius
        
        let width = chart.viewPortHandler.contentWidth
        let height = chart.viewPortHandler.contentHeight
        
        //RIGHT
        if (startAngle >= 270 && endAngle <= 90 && isClockwise) || (startAngle <= 90 && endAngle >= 270 && !isClockwise) {
            
            if height < width
            {
                radiusChanged = height/2
            }
            else{
                radiusChanged = min(height/2,width)
            }
            
        }
            //LEFT
        else if (startAngle >= 90 && endAngle >= startAngle && endAngle <= 270 && isClockwise) || (startAngle <= 270 && endAngle >= 90 && startAngle >= endAngle && !isClockwise) {
            if height < width
            {
                radiusChanged = height/2
            }
            else{
                radiusChanged = min(height/2,width)
            }
        }
            //TOP
        else if (startAngle == 0 && endAngle == 180 && !isClockwise) || (startAngle >= 0 && endAngle >= 180 && !isClockwise)
            || (startAngle == 180 && endAngle == 0 && isClockwise) {
            
            if width < height
            {
                radiusChanged = width/2
            }
            else{
                radiusChanged = min(width/2,height)
            }
        }
            //BOTTOM
        else  if (startAngle == 180 && endAngle == 0 && !isClockwise) || (startAngle >= 0 && startAngle <= endAngle && endAngle <= 180 && isClockwise) {
            if width < height
            {
                radiusChanged = width/2
            }
            else{
                radiusChanged = min(width/2,height)
            }
        }
        
        
        return radiusChanged
    }
    
    
    internal static func updateCenterPointValue(centerPoint:CGPoint, startAngle:CGFloat, maxAngle:CGFloat, direction: SliceDirection, radius: CGFloat) -> CGPoint {
        
        if maxAngle > 180 {
            return centerPoint
        }
        var centerPoint = centerPoint
        
        let startAngle = startAngle
        var endAngle = startAngle + maxAngle
        
        let isClockwise = direction == .clockwise
        
        if !isClockwise {
            endAngle = startAngle - maxAngle
        }
        
        if endAngle >= 360 {
            endAngle = endAngle - 360
        }
        
        if endAngle < 0 {
            endAngle = 360 + endAngle
        }
        
        var topOffset: CGFloat = 0.0
        var rightOffset: CGFloat = 0.0
        var bottomOffset: CGFloat = 0.0
        var leftOffset: CGFloat = 0.0
        
        
        //RIGHT
        if (startAngle >= 270 && endAngle <= 90 && isClockwise) || (startAngle <= 90 && endAngle >= 270 && !isClockwise) {
            rightOffset = radius / 2
        }
            //LEFT
        else if (startAngle >= 90 && endAngle >= startAngle && endAngle <= 270 && isClockwise) || (startAngle <= 270 && endAngle >= 90 && startAngle >= endAngle && !isClockwise) {
            leftOffset = radius / 2
        }
            //TOP
        else if (startAngle == 0 && endAngle == 180 && !isClockwise) || (startAngle >= 0 && endAngle >= 180 && !isClockwise)
            || (startAngle == 180 && endAngle == 0 && isClockwise) {
            topOffset = radius / 2
        }
            //BOTTOM
        else  if (startAngle == 180 && endAngle == 0 && !isClockwise) || (startAngle >= 0 && startAngle <= endAngle && endAngle <= 180 && isClockwise) {
            bottomOffset = radius / 2
        }
        
        
        if topOffset != 0 {
            centerPoint.y += topOffset
        }
        
        if bottomOffset != 0 {
            centerPoint.y -= bottomOffset
        }
        
        if leftOffset != 0 {
            centerPoint.x += leftOffset
        }
        
        if rightOffset != 0 {
            centerPoint.x -= rightOffset
        }
        
        return centerPoint
    }
    
    /// - returns: The diameter of the pie- or radar-chart
    public static func getDiameter(chart:ChartViewBase) -> CGFloat
    {
        var content = chart._viewPortHandler.contentRect
//        content.origin.x += chart.extraLeftOffset
//        content.origin.y += chart.extraTopOffset
//        content.size.width -= chart.extraLeftOffset + chart.extraRightOffset
//        content.size.height -= chart.extraTopOffset + chart.extraBottomOffset
        return min(content.width, content.height)
    }
    
    /// - returns: The total y-value sum across all DataSet objects the this object represents.
    public static func getYValueSum(chart:ChartViewBase) -> Double
    {
      
      guard let data = chart.data,
          data.dataSets.count > 0
          else { return 0.0 }
      
        let dataSet = data.dataSets[0]
      
        var yValueSum: Double = 0.0
        
        for i in 0..<dataSet.entryCount
        {
            guard let entry = dataSet.entryForIndex(i)
                else { continue }
            
            var y = entry.y
            
            if y.isNaN {
                y = 0
            }
            
            yValueSum += abs(y)
        }
        
        return yValueSum
    }
    
    public static func midAngle(startAngle: CGFloat, delta: CGFloat) -> CGFloat {
        
        var midAngle = startAngle + delta / 2.0
        
        if midAngle > 360 {
            midAngle -= 360
        }
        
        if midAngle < 0 {
            midAngle = midAngle + 360
        }
        
        return midAngle
    }
    
    // MARK: -  Rotations
    
    static func calculateVelocity(chart:ChartViewBase) -> CGFloat
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return 0 }
        
        if piePlot._velocitySamples.isEmpty
        {
            return 0.0
        }
        
        var firstSample = piePlot._velocitySamples[0]
        var lastSample = piePlot._velocitySamples[piePlot._velocitySamples.count - 1]
        
        // Look for a sample that's closest to the latest sample, but not the same, so we can deduce the direction
        var beforeLastSample = firstSample
        for i in stride(from: (piePlot._velocitySamples.count - 1), through: 0, by: -1)
        {
            beforeLastSample = piePlot._velocitySamples[i]
            if beforeLastSample.angle != lastSample.angle
            {
                break
            }
        }
        
        // Calculate the sampling time
        var timeDelta = lastSample.time - firstSample.time
        if timeDelta == 0.0
        {
            timeDelta = 0.1
        }
        
        // Calculate clockwise/ccw by choosing two values that should be closest to each other,
        // so if the angles are two far from each other we know they are inverted "for sure"
        var clockwise = lastSample.angle >= beforeLastSample.angle
        if (abs(lastSample.angle - beforeLastSample.angle) > 270.0)
        {
            clockwise = !clockwise
        }
        
        // Now if the "gesture" is over a too big of an angle - then we know the angles are inverted, and we need to move them closer to each other from both sides of the 360.0 wrapping point
        if lastSample.angle - firstSample.angle > 180.0
        {
            firstSample.angle += 360.0
        }
        else if firstSample.angle - lastSample.angle > 180.0
        {
            lastSample.angle += 360.0
        }
        
        // The velocity
        var velocity = abs((lastSample.angle - firstSample.angle) / CGFloat(timeDelta))
        
        // Direction?
        if !clockwise
        {
            velocity = -velocity
        }
        
        return velocity
    }
    
    static func resetVelocity(chart:ChartViewBase)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        piePlot._velocitySamples.removeAll(keepingCapacity: false)
    }
      
    public static func sampleVelocity(chart:ChartViewBase, touchLocation: CGPoint)
    {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
          let currentTime = CACurrentMediaTime()
          
          piePlot._velocitySamples.append(PieRadarPlotOptions.AngularVelocitySample(time: currentTime, angle: PieHelperFunctions.angleForPoint(x: touchLocation.x, y: touchLocation.y, center: piePlot.centerCircleBox)))
          
          // Remove samples older than our sample time - 1 seconds
            var i = 0, count = piePlot._velocitySamples.count
          while (i < count - 2)
          {
            if currentTime - piePlot._velocitySamples[i].time > 1.0
              {
                  piePlot._velocitySamples.remove(at: 0)
                  i -= 1
                  count -= 1
              }
              else
              {
                  break
              }
              
              i += 1
          }
    }
    
    /// sets the starting angle of the rotation, this is only used by the touch listener, x and y is the touch position
    public static func setGestureStartAngle(chart:ChartViewBase, x: CGFloat, y: CGFloat)
   {
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
    
        piePlot._startAngle = angleForPoint(x: x, y: y, center: piePlot.centerCircleBox)
       
       // take the current angle into consideration when starting a new drag
        piePlot._startAngle -=  piePlot.rotationAngle
   }
    
    public static func constrainedWidthForDataLabel(chart: ChartViewBase, point: CGPoint, align: NSTextAlignment, size: CGSize) -> CGFloat {
        
        var constrainedWidth = 0.0
        
        let contentRect = chart.viewPortHandler.contentRect
        
        if align == .left {
            
            let textMinX = point.x - size.width
            
            if textMinX < contentRect.minX {
                constrainedWidth = point.x - contentRect.minX
            }
            else {
                constrainedWidth = point.x - textMinX
            }
        }
        else {
            
            let textMaxX = point.x + size.width
            
            if textMaxX > contentRect.maxX {
                constrainedWidth = contentRect.maxX - point.x
            }
            else {
                constrainedWidth = textMaxX - point.x
            }
        }
        
        return constrainedWidth
    }
    
}

