//
//  LineHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 24/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

import Foundation

open class LineHelperFunctions
{
    
    internal static let typeAllowed:[ChartType] = [.Line,.Radar,.Area]

    /// Line :- Highlights Entries in All Dataset with Given Entry X Value
    /// Vertical Line and Circle added
    public static func highlightAllDatasetEntry(entry:ChartDataEntry, chart: ChartViewBase, includeVerticalLine:Bool)
    {
        CommonHelperFunctions.removeHighlightLayer(chart: chart)
        
        let otherEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry, includeNan: false, chart: chart)
        
        let highlightLayer = HighlightLayer()
        
        var screenPosition = CGPoint()
        
        for i in 0 ..< otherEntries.count
        {
            let otherEntry = otherEntries[i]
            
            guard let set = (chart.data?.getDataSetForEntry(otherEntry)) else {
                continue
            }
            
            guard let setIndex = (chart.data?.indexOfDataSet(set)) else {
                continue
            }
            
            if !set.isHighlightEnabled {
                continue
            }
            
            let entryIndex = set.entryIndex(entry: otherEntry)
            
            var yValue = otherEntry.y
            
            if chart.plotTypes.contains(.Line)  &&  (chart.getPlotOptions(type: .Line) as! LinePlotOptions).isStacked || chart.plotTypes.contains(.Area)  &&  (chart.getPlotOptions(type: .Area) as! AreaPlotOptions).isStacked
            {
                guard (getLineEntryStackedValue(chartViewBase: chart, plotType: set.plotType)[setIndex]?[entryIndex] != nil)
                else { continue }
                yValue = getLineEntryStackedValue(chartViewBase: chart, plotType: set.plotType)[setIndex]![entryIndex]!
            }
            
            screenPosition = chart.pixelForValues(point: CGPoint(x: otherEntry.x, y: yValue), axisIndex: set.axisIndex)
            
            let color = (set.colors[0])
            
            highlightLayer.addSublayer( getCircleLayer(point: screenPosition, color: color, fillEnabled: false) )
            
            if set.plotType == .LineRange && !(otherEntry.y0.isNaN)
            {
                screenPosition = chart.pixelForValues(point: CGPoint(x: otherEntry.x, y: otherEntry.y0), axisIndex: set.axisIndex)
                
                highlightLayer.addSublayer( getCircleLayer(point: screenPosition, color: color, fillEnabled: false) )
            }
            
        }
        
        
        if includeVerticalLine
        {
            let path = CGMutablePath() // UIBezierPath()
            if chart.isRotated {
                path.move(to: CGPoint(x:chart.viewPortHandler.contentRect.origin.x,y:screenPosition.y))
                path.addLine(to: CGPoint(x: chart.viewPortHandler.contentRect.origin.x + chart.viewPortHandler.contentWidth, y: screenPosition.y))
            }
            else {
                path.move(to: CGPoint(x:screenPosition.x,y:0))
                path.addLine(to: CGPoint(x: screenPosition.x, y: chart.viewPortHandler.contentHeight))
            }
            path.closeSubpath()//.close()
            
            highlightLayer.path = path//.cgPath
            highlightLayer.lineDashPattern = [4,8]
            highlightLayer.lineWidth = 0.5
            highlightLayer.strokeColor = NSUIColor.black.cgColor
        }
        
        CommonHelperFunctions.addHighlightLayer(chart: chart, layer: highlightLayer)
        
    }
    
    /// Line :- Highlights Given Entry Alone
    /// Vertical Line, Horizontal Line and Circle added
    public static func highlightCurrentDatasetEntry(entry:ChartDataEntry, chart: ChartViewBase)
    {
        CommonHelperFunctions.removeHighlightLayer(chart: chart)
        
        guard let set = chart.data?.getDataSetForEntry(entry)
        else { return }
        
        if (set.visible) && (set.isHighlightEnabled)
        {
            let highlightLayer = HighlightLayer()
            
            let trans = chart.getTransformer(axisIndex: (set.axisIndex))
            
            let valueToPixelMatrix = trans.valueToPixelMatrix
            
            let location = trans.pixelForValues(x: entry.x, y: entry.y)//CGPoint(x: entry.x, y: entry.y).applying(valueToPixelMatrix)
            
            let color = (set.colors[0])
            
            highlightLayer.addSublayer( getCircleLayer(point: location, color: color, fillEnabled: false) )
            
            // Vertical Path
            let path = CGMutablePath()
            path.move(to: CGPoint(x:location.x,y:0))
            path.addLine(to: CGPoint(x: location.x, y: chart.viewPortHandler.contentHeight))
            path.closeSubpath()
            
            // HorizontalPath
            path.move(to: CGPoint(x:chart.viewPortHandler.contentLeft,y:location.y))
            path.addLine(to: CGPoint(x: chart.viewPortHandler.contentRight, y: location.y))
            path.closeSubpath()
            
            highlightLayer.path = path
            highlightLayer.lineDashPattern = [4,8]
            highlightLayer.lineWidth = 0.5
            highlightLayer.strokeColor = NSUIColor.black.cgColor
            
            
            CommonHelperFunctions.addHighlightLayer(chart: chart, layer: highlightLayer)
        }
        
    }
    
    /// Line :- Highlight Given Dataset
    /// LineWidth Increased
    public static func magnifyDataSet(chart:ChartViewBase, dataSetIndex:Int)
    {
        guard let set = chart.data?.dataSets[dataSetIndex]
            else { return }
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: set)
        
        for line in LineLayer.getAllDataSetLayer(chart: chart)
        {
            if line.lineDataSet === set
            {
                line.lineWidth = 5
                line.strokeColor = set.colors[0].cgColor
                
                let markerLayers = LineLayer.getMarkerLayers(lineLayer: line)
                
                for markerLayer in markerLayers
                {
                    guard (lineDataSetOptions.getShapeColor(atIndex: 0) != nil),
                          (lineDataSetOptions.markerInstance.holeColor) != nil
                    else { continue }
                    markerLayer.strokeColor = lineDataSetOptions.getShapeColor(atIndex: 0)!.cgColor
                    markerLayer.fillColor = lineDataSetOptions.markerInstance.holeColor?.cgColor
                    
                }
                
            }
            else{
                line.lineWidth = lineDataSetOptions.lineWidth
                line.strokeColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                
                let markerLayers = LineLayer.getMarkerLayers(lineLayer: line)
                
                for markerLayer in markerLayers
                {
                    markerLayer.strokeColor = NSUIColor.gray.cgColor
                    
                    guard (line.lineDataSet) != nil
                    else { continue }
                    if getLineDataSetOptions(dataSet: line.lineDataSet!).markerInstance.holeColor != NSUIColor.white
                    {
                        markerLayer.fillColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                    }
                    
                }
                
            }
        }
        
    }
    
    /// Line :- Highlight Given Dataset
    /// Stroke and Fill Color Changed
    public static func highlightDataSet(dataSet:IChartDataSet, chart: ChartViewBase)
    {
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            if layer.lineDataSet === dataSet
            {
                layer.strokeColor = layer.lineDataSet?.color(atIndex: 0).cgColor
                layer.fillColor = layer.lineDataSet?.color(atIndex: 0).withAlphaComponent(0.7).cgColor
            }
            else{
                layer.fillColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                layer.strokeColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
            }
        }
        
    }
    
    /// Removes Magnified Effect
    public static func removeMagnifyEffect(chart:ChartViewBase)
    {
        guard  let sublayers = (chart.plotView?.nsuiLayer?.sublayers) else {
            chart.lastSelectedHigh = nil
            chart.datasetSelected = false
            return }
        for layer in sublayers
        {
            let caLayer:CALayer = layer
            if caLayer.isKind(of: LineLayer.self)
            {
                let line = (layer as! LineLayer)
                
                guard let set = line.lineDataSet
                    else { return }
                let lineDataSetOptions = getLineDataSetOptions(dataSet: set)
                line.strokeColor = set.colors[0].cgColor
                
                if !(lineDataSetOptions.isDrawFilledEnabled)
                {
                    line.lineWidth = lineDataSetOptions.lineWidth
                }
                
                let markerLayers = LineLayer.getMarkerLayers(lineLayer: line)
                
                for markerLayer in markerLayers
                {
                    guard (lineDataSetOptions.getShapeColor(atIndex: 0) != nil),
                          (lineDataSetOptions.markerInstance.holeColor) != nil
                    else { continue }
                    markerLayer.strokeColor = lineDataSetOptions.getShapeColor(atIndex: 0)!.cgColor
                    markerLayer.fillColor = lineDataSetOptions.markerInstance.holeColor?.cgColor
                }
                
            }
            
        }
        
        chart.lastSelectedHigh = nil
        chart.datasetSelected = false
    }
    
    
    /// Line :- returns Circle Layer with Given Point as Center
    public static func getCircleLayer(point:CGPoint,color:NSUIColor,fillEnabled:Bool) -> CAShapeLayer
    {
        let radius:CGFloat = 5.0
        let circleLayer = CAShapeLayer()
        circleLayer.strokeColor = color.cgColor
        circleLayer.fillColor = NSUIColor.white.cgColor
        if fillEnabled{
            circleLayer.fillColor = color.cgColor
        }
        
        let rect = CGRect(x: point.x - radius, y: point.y - radius, width: radius * 2, height: radius * 2)
        
        let path = CGMutablePath(ellipseIn: rect, transform: nil) //UIBezierPath(ovalIn: rect)
        
        circleLayer.path = path//.cgPath
        circleLayer.lineWidth = 1.5
        return circleLayer
    }
    
    
    // MARK :- UNUSED
    
    /// Area :- Highlights Given Area
    public static func highlightArea(chart:ChartViewBase,entryLayer:ChartEntryLayer,entry:ChartDataEntry?)
    {
        guard let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Line]) as? LineChartRenderer,
              let set = (chart.data?.getDataSetForEntry(entry)),
                (entry != nil)
            else { return }
        
        
        
        let trans = chart.getTransformer(axisIndex: set.axisIndex)
        
        let pt = trans.pixelForValues(x: (entry?.x)!, y: (entry?.y)!)
        
        let childLayer = HighlightLayer()
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: set)
        
        if lineDataSetOptions.mode == .cubicBezier
        {
            childLayer.path = LineHelperFunctions.getCubicDataSetPathWithNAN(barLineChart: chart, dataSet: set, animator: nil, lineRenderer: renderer).0
        }
        else{
            childLayer.path =  LineHelperFunctions.getLinearPathWithNAN(barLineChart: chart , dataSet: set, animator: nil, lineRenderer: renderer).0
        }
        
        
        childLayer.fillColor = lineDataSetOptions.fillColor.cgColor
        childLayer.opacity = Float(lineDataSetOptions.fillAlpha)
        
        let color = NSUIColor(patternImage: #imageLiteral(resourceName: "ch"))
        let patternLayer = CAShapeLayer()
        patternLayer.path = childLayer.path
        patternLayer.fillColor = color.cgColor
        
        childLayer.addSublayer(patternLayer)
        
        let curIndex = set.entryIndex(entry: entry!)
        
        var prevEntry = set.entryForIndex(curIndex - 1)
        
        var nextEntry = set.entryForIndex(curIndex + 1)
        
        var prevPoint:CGPoint!
        var nextPoint:CGPoint!
        
        if prevEntry == nil{
            prevEntry = set.entryForIndex(0)
            
            prevPoint = trans.pixelForValues(x: (entry?.x)!, y: (entry?.y)!)
        }
        else{
            
            prevPoint = trans.pixelForValues(x: (prevEntry?.x)!, y: (prevEntry?.y)!)
            
            prevPoint.x = (prevPoint.x + CGFloat(pt.x)) / 2
            
        }
        
        if nextEntry == nil
        {
            nextEntry = set.entryForIndex(set.entryCount-1)
            
            nextPoint = trans.pixelForValues(x: (entry?.x)!, y: (entry?.y)!)
        }
        else{
            nextPoint = trans.pixelForValues(x: (nextEntry?.x)!, y: (nextEntry?.y)!)
            
            nextPoint.x = (nextPoint.x + CGFloat(pt.x)) / 2
        }
        
        guard (renderer.viewPortHandler) != nil
        else { return }
        
        let startPoint = CGPoint(x: prevPoint.x, y: (renderer.viewPortHandler?.contentTop)!)
        let secondPoint = CGPoint(x: nextPoint.x, y: (renderer.viewPortHandler?.contentTop)!)
        
        let path = CGMutablePath() //UIBezierPath()
        path.move(to: startPoint)
        path.addLine(to: secondPoint)
        path.addLine(to: CGPoint(x: nextPoint.x, y: (renderer.viewPortHandler?.contentBottom)!))
        path.addLine(to: CGPoint(x: prevPoint.x, y: (renderer.viewPortHandler?.contentBottom)!))
        path.closeSubpath() //.close()
        
        let maskLayer = CAShapeLayer()
        maskLayer.backgroundColor = NSUIColor.clear.cgColor
        maskLayer.path = path//.cgPath
        
        childLayer.mask = maskLayer
        
        CommonHelperFunctions.addHighlightLayer(chart: chart, layer: childLayer)
    }
    
    // MARK: - Gesture Handled
        
    public static func tapHighlight(location: CGPoint, _ recognizer: NSUIGestureRecognizer? , chart: ChartViewBase) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
    {
        
        var entry:ChartDataEntry? = nil
        
        let high = chart.getHighlightByTouchPoint(location)
        
        var lineLayer:LineLayer? = nil
    
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
        
        lineLayer = LineLayer.getDataSetLayerInPoint(chart: chart, loc: location)
        
        return (entry,lineLayer)
        
    }
    
    
    // MARK: - Path Generation Methods
    
    // MARK: - Linear
    
    /// returns dataSetPath and strokePath
    public static func getLinearPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath){
            
        let _xBounds = lineRenderer._xBounds
        
        _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let from = lineRenderer.useForcedValue ? 0 : _xBounds.min
        let to = lineRenderer.useForcedValue ? dataSet.entryCount : _xBounds.range + _xBounds.min
        
        return  getLinearPathWithNAN(barLineChart: barLineChart, fromIndex: from, toIndex: to, dataSet: dataSet, animator: animator, lineRenderer: lineRenderer)
    }
    
    public static func getLinearPathWithNAN(barLineChart:ChartViewBase, fromIndex:Int, toIndex:Int, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath) {
        
        let finalPath = CGMutablePath()
        let strokePath = CGMutablePath()

        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        var path = CGMutablePath()
        
        
        var pathArray:[CGMutablePath] = []
        var strokePathArray:[CGMutablePath] = []
        
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        let isDrawSteppedEnabled = lineDataSetOptions.mode == .stepped
        //        let pointsPerEntryPair = isDrawSteppedEnabled ? 4 : 2
        
        let phaseY =  (animator == nil) ? 1 : animator!.phaseY
        
        var e1: ChartDataEntry!
        var e2: ChartDataEntry!
        
        var startEntry:ChartDataEntry!
        var endEntry:ChartDataEntry!
        
        e1 = dataSet.entryForIndex(fromIndex)
        
        
        
        if e1 != nil
        {
            var firstPoint = true
            
            for x in stride(from: fromIndex, through: toIndex, by: 1)
            {
                e1 = dataSet.entryForIndex(x == 0 ? 0 : (x - 1))
                e2 = dataSet.entryForIndex(x)
                
                if e1 == nil || e2 == nil { continue }
                
                let (e1XVal,e1YVal) = getXYValue(entry: e1, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                let (e2XVal,e2YVal) = getXYValue(entry: e2, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                if e1XVal.isNaN || e1YVal.isNaN || e2XVal.isNaN || e2YVal.isNaN
                {
                    if firstPoint
                    {
                        continue
                    }
                    else{
                        
                        if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                        {
                            strokePathArray.append(path.mutableCopy()!)
                            
                            if dataSet.plotType == .LineRange
                            {
                                let lowerStrokePath = CGMutablePath()
                                closeAreaRangeLinearPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path, lowerStrokePath: lowerStrokePath)
                                strokePathArray.append(lowerStrokePath)
                            }
                            else{
                                closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path)
                            }
                        }
                        
                        pathArray.append(path.mutableCopy()!)
                        
                        firstPoint = true
                        path = CGMutablePath()
                        continue
                    }
                }
                
                
                var pt = CGPoint(
                    x: CGFloat(e1XVal),
                    y: CGFloat(e1YVal * phaseY)
                    )
                
                pt = barLineChart.pixelForValues(point: pt, isOriginal: false, axisIndex: dataSet.axisIndex)
                
                if firstPoint
                {
                    startEntry = e1
                    endEntry = e1
                    path.move(to: pt)
                    firstPoint = false
                }
                else
                {
                    path.addLine(to: pt)
                    endEntry = e2
                }
                
                if isDrawSteppedEnabled
                {
                    let point = CGPoint(
                        x: CGFloat(e2XVal),
                        y: CGFloat(e1YVal * phaseY)
                        )
                    path.addLine(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                }
                
                let point = CGPoint(
                    x: CGFloat(e2XVal),
                    y: CGFloat(e2YVal * phaseY)
                    )
                
                path.addLine(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                
                endEntry = e2
            }
            
            
            if !firstPoint {
                
                if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                {
                    strokePathArray.append(path.mutableCopy()!)
                    
                    if dataSet.plotType == .LineRange
                    {
                        let lowerStrokePath = CGMutablePath()
                        closeAreaRangeLinearPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path, lowerStrokePath: lowerStrokePath)
                        strokePathArray.append(lowerStrokePath)

                    }
                    else{
                        closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path)
                    }
                }
                
                pathArray.append(path)
            }
        }
        
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            finalPath.addPath(path)
        }
        
        return (finalPath,strokePath)
    }
    
    /// Stacked
    public static func getLinearStackedPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath) {
        
        let finalPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        guard
            let lineChartData = barLineChart.data
            else { return (finalPath,strokePath) }
        
        let lineChartView = barLineChart
        
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: lineChartView, plotType: dataSet.plotType)
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let path = CGMutablePath()
        let curStrokePath = CGMutablePath()
        
        var pathArray:[CGMutablePath] = []
        var strokePathArray:[CGMutablePath] = []
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        let isDrawSteppedEnabled = lineDataSetOptions.mode == .stepped
        //        let pointsPerEntryPair = isDrawSteppedEnabled ? 4 : 2
        
        let phaseY = (animator == nil) ? 1 : animator!.phaseY
        
        let _xBounds = lineRenderer._xBounds
        
        _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        
        var e1: ChartDataEntry!
        var e2: ChartDataEntry!
        
        var startEntry:ChartDataEntry!
        var endEntry:ChartDataEntry!
        
        e1 = dataSet.entryForIndex(_xBounds.min)
        
        if e1 != nil
        {
            var firstPoint = true
            
            for x in stride(from: _xBounds.min, through: _xBounds.range + _xBounds.min, by: 1)
            {
                let e1Index = x == 0 ? 0 : (x - 1)
                var e2Index = x
                
                e1 = dataSet.entryForIndex(e1Index)
                e2 = dataSet.entryForIndex(e2Index)
                
                if e1 == nil || e2 == nil || (e1.x.isNaN && e2.x.isNaN) || e1.x.isNaN { continue }
                
                
                if e2.x.isNaN
                {
                    var tempIndex = x
                    var tempEntry = dataSet.entryForIndex(tempIndex)
                    
                    guard (tempEntry != nil)
                    else { continue }
                    
                    while (tempIndex+1) < dataSet.entryCount && (tempEntry?.x.isNaN)!
                    {
                        tempIndex += 1
                        tempEntry = dataSet.entryForIndex(tempIndex)
                    }
                    
                    if (tempEntry?.x.isNaN)!
                    {
                        continue
                    }
                    else{
                        e2 = tempEntry
                        e2Index = tempIndex
                    }
                }
                
                let (startX,_) = getXYValue(entry: e1, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)

                let (endX,_) = getXYValue(entry: e2, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                guard (entriesStackedYValue[setIndex]?[e1Index]) != nil,
                      (entriesStackedYValue[setIndex]?[e2Index]) != nil
                else { continue }
                var e1YValue = e1.filterEnabled ? (entriesStackedYValue[setIndex]![e1Index])! + Double(e1.barYValue) : (entriesStackedYValue[setIndex]![e1Index])!
                var e2YValue = e2.filterEnabled ? (entriesStackedYValue[setIndex]![e2Index])! + Double(e2.barYValue) : (entriesStackedYValue[setIndex]![e2Index])!
                
                e1YValue = getXYValue(entry: e1, stackedYValue: e1YValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
                e2YValue = getXYValue(entry: e2, stackedYValue: e2YValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
                
                var pt = CGPoint(x: startX, y: e1YValue * phaseY)
                
                pt = barLineChart.pixelForValues(isRotated: barLineChart.isRotated, x: pt.x, y: pt.y, isOriginal: false, axisIndex: dataSet.axisIndex)
                /*CGPoint(
                    x: CGFloat(startX),
                    y: CGFloat(e1YValue * phaseY)
                    ).applying(valueToPixelMatrix)*/
                
                if firstPoint
                {
                    startEntry = e1
                    endEntry = e1
                    path.move(to: pt)
                    curStrokePath.move(to: pt)
                    firstPoint = false
                }
                else
                {
                    path.addLine(to: pt)
                    endEntry = e2
                }
                
                let e1IsDummy = (e1.data as? [String:Bool])?["isDummy"] ?? false
                let e2IsDummy = (e2.data as? [String:Bool])?["isDummy"] ?? false
                
                if isDrawSteppedEnabled
                {
                    let point = CGPoint(
                        x: CGFloat(endX),
                        y: CGFloat(e1YValue * phaseY)
                        )
                    
                    if e1IsDummy || e2IsDummy {
                        curStrokePath.move(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                    }
                    else {
                        curStrokePath.addLine(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                    }
                    
                    path.addLine(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                }
                
                let point = CGPoint(
                    x: CGFloat(endX),
                    y: CGFloat(e2YValue * phaseY)
                )
                
                if e1IsDummy || e2IsDummy {
                    curStrokePath.move(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                }
                else {
                    curStrokePath.addLine(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                }
                
                path.addLine(to: barLineChart.pixelForValues(point: point, isOriginal: false, axisIndex: dataSet.axisIndex))
                
                endEntry = e2
            }
            
            
            if !firstPoint {
                
                if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                {
                    strokePathArray.append(curStrokePath)
                    
                    if isDrawSteppedEnabled
                    {
                        closeStackedSteppedPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path, phaseY: phaseY)
                    }
                    else{
                        closeStackedLinearPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path, phaseY: phaseY)
                    }
                    
                }
                
                pathArray.append(path)
            }
        }
        
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            finalPath.addPath(path)
        }
        
        return (finalPath,strokePath)
    }
    
    // MARK: - Cubic
    
    public static func getCubicDataSetPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath)
    {
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let phaseY = (animator == nil) ? 1 : animator!.phaseY
        
        let _xBounds = lineRenderer._xBounds
        
        _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let intensity = lineDataSetOptions.cubicIntensity
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        var pathArray:[CGMutablePath] = []
        
        var strokePathArray:[CGMutablePath] = []
        
        if _xBounds.range >= 1
        {
            // Take an extra point from the left, and an extra from the right.
            // That's because we need 4 points for a cubic bezier (cubic=4), otherwise we get lines moving and doing weird stuff on the edges of the chart.
            // So in the starting `prev` and `cur`, go -2, -1
            // And in the `lastIndex`, add +1
            
            var firstIndex = lineRenderer.useForcedValue ? 0 : _xBounds.min + 1
            let lastIndex = lineRenderer.useForcedValue ? (dataSet.entryCount - 1) : _xBounds.min + _xBounds.range
            
            var prevPrev: ChartDataEntry! = nil
            
            if dataSet.entryForIndex(max(firstIndex - 1, 0)) == nil {
                return (cubicPath,strokePath)
            }
            
            var cur: ChartDataEntry! = dataSet.entryForIndex(max(firstIndex - 1, 0))
            var next: ChartDataEntry! = cur
            var nextIndex: Int = -1
            
            var myPath = CGMutablePath()
            var firstPoint:Bool = true
            var allowedToadd:Bool = false
            
            
            var (curXValue,curYValue) =  getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            
            if curYValue.isNaN || curXValue.isNaN {
                
                while (curYValue.isNaN || curXValue.isNaN)
                {
                    firstIndex = firstIndex + 1
                    
                    if let curEntry = dataSet.entryForIndex(max(firstIndex-1, 0)) {
                        cur = curEntry
                    }
                    else {
                        return (cubicPath,strokePath)
                    }
                    
                    (curXValue,curYValue) =  getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                }
                
                next = cur
            }
            
            var prev: ChartDataEntry! = dataSet.entryForIndex(max(firstIndex - 2, 0))
            
            var startEntry:ChartDataEntry! = cur
            var endEntry:ChartDataEntry! = cur
            
            let curValue = CGPoint(x: CGFloat(curXValue),y: CGFloat(curYValue))
            
            // let the spline start
            myPath.move(to: barLineChart.pixelForValues(point: CGPoint(x: curValue.x, y: curValue.y * CGFloat(phaseY)), isOriginal: false, axisIndex: dataSet.axisIndex))
            firstPoint = false
            
            for j in stride(from: firstIndex, through: lastIndex, by: 1)
            {
                prevPrev = prev
                prev = cur
                cur = nextIndex == j ? next : dataSet.entryForIndex(j)
                
                nextIndex = j + 1 < dataSet.entryCount ? j + 1 : j
                next = dataSet.entryForIndex(nextIndex)
                
                (curXValue,curYValue) =  getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                var (prevPrevXValue,prevPrevYValue) = getXYValue(entry: prevPrev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                var (prevXValue,prevYValue) = getXYValue(entry: prev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                var (nextXValue,nextYValue) = getXYValue(entry: next, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                if curYValue.isNaN || curXValue.isNaN {
                    if allowedToadd {
                        
                        if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                        {
                            
                            strokePathArray.append(myPath.mutableCopy()!)
                            //                            updateStrokePath(dataSet: dataSet, pathArray: pathArray, path: myPath)
                            
                            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                        }
                        
                        pathArray.append(myPath.mutableCopy()!)
                        allowedToadd = false
                    }
                    myPath = CGMutablePath()
                    firstPoint = true
                    continue
                }
                
                
                if prev.y.isNaN || prev.x.isNaN{
                    prevPrev = cur
                    prev = cur
                }
                
                if prevPrev.y.isNaN || prevPrev.x.isNaN {
                    prevPrev = prev
                }
                
                if firstPoint {
                    
                    let curValue = CGPoint(x: CGFloat(curXValue),y: CGFloat(curYValue))
                    startEntry = cur
                    myPath.move(to: CGPoint(x: curValue.x, y: curValue.y * CGFloat(phaseY)), transform: valueToPixelMatrix)
                    prev = cur
                    firstPoint = false
                    continue
                }
                
                if next == nil { break }
                
                if next.y.isNaN || next.x.isNaN {
                    next = cur
                    nextIndex = nextIndex - 1
                }
                
                (prevPrevXValue,prevPrevYValue) = getXYValue(entry: prevPrev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                (prevXValue,prevYValue) = getXYValue(entry: prev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                (nextXValue,nextYValue) = getXYValue(entry: next, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                var points = [String:(Double,Double)]()
                points["prevPrev"] = (prevPrevXValue,prevPrevYValue)
                points["prev"] = (prevXValue,prevYValue)
                points["cur"] = (curXValue,curYValue)
                points["next"] = (nextXValue,nextYValue)
                               
                let (curPoint,control1,control2) = constructCubicPoints(barLineChart: barLineChart, points: points, dataSet: dataSet, intensity: intensity, phaseY: phaseY)
                
                myPath.addCurve(
                    to: curPoint,
                    control1: control1,
                    control2: control2)
                
                allowedToadd = true
                
                endEntry = cur
            }
            
            if !firstPoint && allowedToadd {
                
                if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                {
                    //                    updateStrokePath(dataSet: dataSet, pathArray: pathArray, path: myPath)
                    
                    strokePathArray.append(myPath.mutableCopy()!)
                    
                    closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                }
                
                pathArray.append(myPath)
            }
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            cubicPath.addPath(path)
        }
        
        return (cubicPath,strokePath)
    }
    
    public static func getCubicStackedDataSetPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath)
    {
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        guard
            let lineChartData = barLineChart.data
            else { return (cubicPath,strokePath) }
        
        let lineChartView = barLineChart
        
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: lineChartView, plotType: dataSet.plotType)
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let phaseY = (animator == nil) ? 1 : animator!.phaseY
        
        let _xBounds = lineRenderer._xBounds
        
        _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let intensity = lineDataSetOptions.cubicIntensity
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        
        var pathArray:[CGMutablePath] = []
        
        var strokePathArray:[CGMutablePath] = []
        
        if _xBounds.range >= 1
        {
            // Take an extra point from the left, and an extra from the right.
            // That's because we need 4 points for a cubic bezier (cubic=4), otherwise we get lines moving and doing weird stuff on the edges of the chart.
            // So in the starting `prev` and `cur`, go -2, -1
            // And in the `lastIndex`, add +1
            
            var firstIndex = _xBounds.min + 1
            let lastIndex = _xBounds.min + _xBounds.range
            
            var curIndex = max(firstIndex - 1, 0)
            var prevIndex = max(firstIndex - 2, 0)
            var prevprevIndex = -1
            var nextIndex: Int = -1
            
            
            var prevPrev: ChartDataEntry! = nil
            var cur: ChartDataEntry! = dataSet.entryForIndex(curIndex)
            var next: ChartDataEntry! = cur
            
            
            let myPath = CGMutablePath()
            let curStrokePath = CGMutablePath()
            var firstPoint:Bool = true
            var allowedToadd:Bool = false
            
            if cur == nil { return (cubicPath,strokePath) }
            
            if  cur.x.isNaN {
                
                while cur != nil && (cur.x.isNaN) && (firstIndex+1) < dataSet.entryCount
                {
                    firstIndex = firstIndex + 1
                    cur = dataSet.entryForIndex(max(firstIndex-1, 0))
                }
                
                if cur == nil || cur.x.isNaN { return (cubicPath,strokePath) }
                
                next = cur
                
                curIndex = max(firstIndex - 1, 0)
                
                prevIndex = max(firstIndex - 2, 0)
                
            }
            
            var prev: ChartDataEntry! = dataSet.entryForIndex(prevIndex)
            
            if  prev.x.isNaN {
                
                while prev != nil && (prev.x.isNaN) && (prevIndex-1) >= 0
                {
                    prevIndex = prevIndex - 1
                    prev = dataSet.entryForIndex(prevIndex)
                }
                
                if prev.x.isNaN
                {
                    prev = cur
                    prevIndex = curIndex
                }
                
            }
            
            var startEntry:ChartDataEntry! = cur
            var endEntry:ChartDataEntry! = cur
            
            guard (entriesStackedYValue[setIndex]?[curIndex]) != nil,
                  (entriesStackedYValue[setIndex]?[prevIndex]) != nil
            else { return (cubicPath,strokePath)}
                  
            
            var curYValue =  (entriesStackedYValue[setIndex]![curIndex])!
            var prevYValue = (entriesStackedYValue[setIndex]![prevIndex])! //  Need not given value
            var nextYValue = (entriesStackedYValue[setIndex]![curIndex])! //  Need not given value
            
            var (curX,curY) = getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            
            curYValue = getXYValue(entry: cur, stackedYValue: curYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            
            let curPoint = CGPoint(x: CGFloat(curX), y: CGFloat(curYValue * phaseY))
            
            // let the spline start
            myPath.move(to: barLineChart.pixelForValues(point: curPoint, isOriginal: false, axisIndex: dataSet.axisIndex))
            curStrokePath.move(to: barLineChart.pixelForValues(point: curPoint, isOriginal: false, axisIndex: dataSet.axisIndex))
            
            firstPoint = false
            
            for j in stride(from: firstIndex, through: lastIndex, by: 1)
            {
                
                if curIndex == nextIndex
                {
                    break
                }
                
                prevPrev = prev
                prevprevIndex = prevIndex
                
                prev = cur
                prevIndex = curIndex
                
                cur =  nextIndex == -1 ? dataSet.entryForIndex(j) : next
                curIndex = nextIndex == -1 ? j : nextIndex
                
                
                
                if  cur.x.isNaN {
                    
                    while cur != nil && (cur.x.isNaN) && (curIndex+1) < dataSet.entryCount
                    {
                        curIndex = curIndex + 1
                        cur = dataSet.entryForIndex(curIndex)
                    }
                    
                    if cur.x.isNaN
                    {
                        continue
                    }
                }
                
                
                nextIndex = curIndex + 1 < dataSet.entryCount ? curIndex + 1 : curIndex
                next = dataSet.entryForIndex(nextIndex)
                
                // Sure j+1 case
                if next.x.isNaN
                {
                    while next != nil && (next.x.isNaN) && (nextIndex+1) < dataSet.entryCount
                    {
                        nextIndex = nextIndex + 1
                        next = dataSet.entryForIndex(nextIndex)
                    }
                    
                    if next.x.isNaN
                    {
                        next = cur
                        nextIndex = curIndex
                    }
                }
                
                (curX,curY) = getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                let (prevX,_) = getXYValue(entry: prev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                let (prevPrevX,_) = getXYValue(entry: prevPrev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                let (nextX,_) = getXYValue(entry: next, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                guard (entriesStackedYValue[setIndex]![curIndex]) != nil,
                      (entriesStackedYValue[setIndex]![prevIndex]) != nil,
                      (entriesStackedYValue[setIndex]![prevprevIndex]) != nil,
                      (entriesStackedYValue[setIndex]![nextIndex]) != nil
                else { continue }
                
                curYValue = (entriesStackedYValue[setIndex]![curIndex])!
                prevYValue = (entriesStackedYValue[setIndex]![prevIndex])!
                var prevprevYValue = (entriesStackedYValue[setIndex]![prevprevIndex])!
                nextYValue = (entriesStackedYValue[setIndex]![nextIndex])!
                
                curYValue = getXYValue(entry: cur, stackedYValue: curYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
                prevYValue = getXYValue(entry: prev, stackedYValue: prevYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
                prevprevYValue = getXYValue(entry: prevPrev, stackedYValue: prevprevYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
                nextYValue = getXYValue(entry: next, stackedYValue: nextYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
                
                if firstPoint {
                    startEntry = cur
                    let curPoint = CGPoint(x: CGFloat(curX), y: CGFloat(curYValue * phaseY))
                    myPath.move(to: barLineChart.pixelForValues(point: curPoint, isOriginal: false, axisIndex: dataSet.axisIndex))
                    curStrokePath.move(to: barLineChart.pixelForValues(point: curPoint, isOriginal: false, axisIndex: dataSet.axisIndex))
                    prev = cur
                    prevIndex = curIndex
                    firstPoint = false
                    continue
                }
                
                if next == nil { break }
                
                var points = [String:(Double,Double)]()
                points["prevPrev"] = (prevPrevX,prevprevYValue)
                points["prev"] = (prevX,prevYValue)
                points["cur"] = (curX,curYValue)
                points["next"] = (nextX,nextYValue)
                
                let (curPoint,control1,control2) = constructCubicPoints(barLineChart: barLineChart, points: points, dataSet: dataSet, intensity: intensity, phaseY: phaseY)
                
                let isDummy = (cur.data as? [String:Bool])?["isDummy"] ?? false || (prev.data as? [String:Bool])?["isDummy"] ?? false
                
                if isDummy {
                    curStrokePath.move(to: curPoint)
                }
                else {
                    curStrokePath.addCurve(
                        to: curPoint,
                        control1: control1 ,
                        control2: control2)
                }
                
                myPath.addCurve(
                    to: curPoint,
                    control1: control1 ,
                    control2: control2)
                
                allowedToadd = true
                
                endEntry = cur
            }
            
            if !firstPoint && allowedToadd {
                
                if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                {
                    //                    updateStrokePath(dataSet: dataSet, pathArray: pathArray, path: myPath)
                    strokePathArray.append(curStrokePath)
                    closeStackedCubicPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath, phaseY: phaseY)
                }
                
                pathArray.append(myPath)
            }
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            cubicPath.addPath(path)
        }
        
        return (cubicPath,strokePath)
    }
    
    static func constructCubicPoints(barLineChart: ChartViewBase, points: [String:(Double,Double)], dataSet: IChartDataSet, intensity: CGFloat, phaseY: CGFloat) -> (CGPoint,CGPoint,CGPoint) {
        
        let (prevPrevXValue,prevPrevYValue) = points["prevPrev"] ?? (0.0,0.0)
        let (prevXValue,prevYValue) = points["prev"] ?? (0.0,0.0)
        let (curXValue,curYValue) = points["cur"] ?? (0.0,0.0)
        let (nextXValue,nextYValue) = points["next"] ?? (0.0,0.0)
        
        let prevDx = CGFloat(curXValue - prevPrevXValue) * intensity
        let prevDy = CGFloat(curYValue - prevPrevYValue) * intensity
        let curDx = CGFloat(nextXValue - prevXValue) * intensity
        let curDy = CGFloat(nextYValue - prevYValue) * intensity
        
        var (toPoint,control1,control2): (CGPoint,CGPoint,CGPoint)
        
        if curYValue == prevYValue
        {
            toPoint = CGPoint(x: CGFloat(curXValue),y: CGFloat(curYValue * phaseY))
            control1 = CGPoint(x: CGFloat(prevXValue) + prevDx, y: (CGFloat(curYValue * phaseY)))
            control2 = CGPoint(x: CGFloat(curXValue) - curDx,y: (CGFloat(curYValue * phaseY)))
        }
        else{
            toPoint = CGPoint(x: CGFloat(curXValue),y: CGFloat(curYValue * phaseY))
            control1 = CGPoint(x: CGFloat(prevXValue) + prevDx, y: (CGFloat(prevYValue) + prevDy) * CGFloat(phaseY))
            control2 = CGPoint(x: CGFloat(curXValue) - curDx,y: (CGFloat(curYValue) - curDy) * CGFloat(phaseY))
        }
        
        toPoint = barLineChart.pixelForValues(point: toPoint, isOriginal: false, axisIndex: dataSet.axisIndex)
        control1 = barLineChart.pixelForValues(point: control1, isOriginal: false, axisIndex: dataSet.axisIndex)
        control2 = barLineChart.pixelForValues(point: control2, isOriginal: false, axisIndex: dataSet.axisIndex)
        
        return (toPoint,control1,control2)
    }
    
    // MARK: - Monotone
    
    public static func getMonotoneDataSetPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath)
    {
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let phaseY = (animator == nil) ? 1 : animator!.phaseY
        
        let _xBounds = lineRenderer._xBounds
        
        _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        var pathArray:[CGMutablePath] = []
        
        var strokePathArray:[CGMutablePath] = []
        
        if _xBounds.range >= 1
        {
            let firstIndex = lineRenderer.useForcedValue ? 0 :
                (_xBounds.min - 1) >= 0 ? (_xBounds.min - 1) : _xBounds.min
            let lastIndex = lineRenderer.useForcedValue ? dataSet.entryCount - 1 :
                (_xBounds.min + _xBounds.range + 1) <= dataSet.entryCount - 1 ? (_xBounds.min + _xBounds.range + 1) : _xBounds.min + _xBounds.range
            
            let monotoneObject = MonoTone()
            
            var myPath = CGMutablePath()
            
            var startEntry:ChartDataEntry!
            
            var endEntry:ChartDataEntry!

            var defined0 = false
            
            var curXY = CGPoint()
            
            for j in stride(from: firstIndex, through: lastIndex+1, by: 1)
            {
                let entry = dataSet.entryForIndex(j)
                
                if j <= lastIndex  && entry != nil
                {
                    let cur = entry!
                    
                    let (curXValue,curYValue) = getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                    curXY.x = CGFloat(curXValue)
                    curXY.y = CGFloat(curYValue)
                    
                    if curXY.x.isNaN || curXY.y.isNaN
                    {
                        // Line Breaks
                        monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(myPath.mutableCopy()!)
                        
                            if dataSet.plotType == .LineRange
                            {
                                let lowerStrokePath = CGMutablePath()
                                closeAreaRangeMonotonePathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, dataSetPath: myPath, lowerStrokePath: lowerStrokePath)
                                strokePathArray.append(lowerStrokePath)
                            }
                            else{
                                closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                            }
                        }
                        
                        pathArray.append(myPath)
                        myPath = CGMutablePath()
                        monotoneObject.reset()
                        continue
                    }
                    
                    endEntry = cur
                }
                
                if (!(j <= lastIndex) == defined0)
                {
                    defined0 = (!defined0)
                    // Line Start
                  if defined0
                  {
                        monotoneObject.switchOption = 0
                        startEntry = entry
                        endEntry = entry
                  }
                  else
                  {
                    // Line Ends
                        monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(myPath.mutableCopy()!)
                            
                            if dataSet.plotType == .LineRange
                            {
                                let lowerStrokePath = CGMutablePath()
                                closeAreaRangeMonotonePathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, dataSetPath: myPath, lowerStrokePath: lowerStrokePath)
                                strokePathArray.append(lowerStrokePath)
                            }
                            else{
                                closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                            }
                            
                        }
                  }
                }
                if (defined0){
                    if monotoneObject.switchOption == 0
                    {
                        startEntry = entry
                    }
                    pointToAdd(x: curXY.x, y: curXY.y, monotoneObject: monotoneObject, myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                }
            }
            pathArray.append(myPath)
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            cubicPath.addPath(path)
        }
        
        return (cubicPath,strokePath)
    }
    
    public static func getMonotoneStackedDataSetPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, animator:Animator?, lineRenderer:LineChartRenderer) -> (CGPath,CGPath){
            
        let _xBounds = lineRenderer._xBounds
        
        _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let from = lineRenderer.useForcedValue ? 0 :
            (_xBounds.min - 1) >= 0 ? (_xBounds.min - 1) : _xBounds.min
        let to = lineRenderer.useForcedValue ? dataSet.entryCount - 1 :
            (_xBounds.min + _xBounds.range + 1) <= dataSet.entryCount - 1 ? (_xBounds.min + _xBounds.range + 1) : _xBounds.min + _xBounds.range
        
        return  getMonotoneStackedDataSetPathWithNAN(barLineChart: barLineChart, fromIndex: from, toIndex: to, dataSet: dataSet, animator: animator, lineRenderer: lineRenderer)
    }
    
    public static func getMonotoneStackedDataSetPathWithNAN(barLineChart:ChartViewBase,fromIndex:Int, toIndex:Int, dataSet:IChartDataSet, animator:Animator?, lineRenderer:DataRenderer) -> (CGPath,CGPath)
    {
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        guard
            let lineChartData = barLineChart.data
            else { return (cubicPath,strokePath) }
        
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: barLineChart, plotType: dataSet.plotType)
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        let phaseY = animator?.phaseY ?? 1.0
        
        var pathArray:[CGMutablePath] = []
        
        var strokePathArray:[CGMutablePath] = []
        
        if (toIndex - fromIndex) >= 0
        {
            let firstIndex = fromIndex
            let lastIndex = toIndex
            
            let monotoneObject = MonoTone()
            let monotoneStrokeObject = MonoTone()
            
            var myPath = CGMutablePath()
            var curStrokePath = CGMutablePath()
            
            var startEntry:ChartDataEntry!
            
            var endEntry:ChartDataEntry!

            var defined0 = false
            
            var curXY = CGPoint()
            
            for j in stride(from: firstIndex, through: lastIndex+1, by: 1)
            {
                let entry = dataSet.entryForIndex(j)
                
                let curIsDummy = ((dataSet.entryForIndex(j - 1)?.data as? [String:Bool])?["isDummy"]) ?? false || ((dataSet.entryForIndex(j - 2)?.data as? [String:Bool])?["isDummy"]) ?? false
                
                if j <= lastIndex  && entry != nil
                {
                    let cur = entry!
                    
                    if cur.x.isNaN || (entriesStackedYValue[setIndex]?[j] == nil)
                    {
                        continue
                    }
                    
                    curXY.x = CGFloat(getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).0)
                    curXY.y = CGFloat(getXYValue(entry: cur, stackedYValue: (entriesStackedYValue[setIndex]![j])!, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1)
                    
                    if curXY.x.isNaN || curXY.y.isNaN
                    {
                        // Line Breaks
                        monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        monotoneStrokeObject.lineEnds(myPath: curStrokePath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(curStrokePath)
                        
                            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                        }
                        
                        pathArray.append(myPath)
                        myPath = CGMutablePath()
                        strokePathArray.append(curStrokePath)
                        curStrokePath = CGMutablePath()
                        monotoneObject.reset()
                        monotoneStrokeObject.reset()
                        continue
                    }
                    
                    endEntry = cur
                }
                
                if (!(j <= lastIndex) == defined0)
                {
                    defined0 = (!defined0)
                    // Line Start
                  if defined0
                  {
                        monotoneObject.switchOption = 0
                        monotoneStrokeObject.switchOption = 0
                        startEntry = entry
                        endEntry = entry
                  }
                  else
                  {
                    // Line Ends
                    monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                    monotoneStrokeObject.lineEnds(myPath: curStrokePath, dataSet: dataSet as! ChartDataSet, chart: barLineChart, isMoveTo: curIsDummy)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(curStrokePath)
                           // myPath.closeSubpath()
                            
                            closeStackedMonotonePathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, dataSetPath: myPath, phaseY: phaseY)
                        }
                  }
                }
                if (defined0){
                    if monotoneObject.switchOption == 0 && monotoneStrokeObject.switchOption == 0
                    {
                        startEntry = entry
                    }
                    
                    pointToAdd(x: curXY.x, y: curXY.y * phaseY, monotoneObject: monotoneObject, myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                    
                    if curIsDummy {
                        pointToAdd(x: curXY.x, y: curXY.y * phaseY, monotoneObject: monotoneStrokeObject, myPath: curStrokePath, dataSet: dataSet as! ChartDataSet, chart: barLineChart, isMoveTo: curIsDummy)
                    }
                    else {
                        pointToAdd(x: curXY.x, y: curXY.y * phaseY, monotoneObject: monotoneStrokeObject, myPath: curStrokePath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                    }
                }
            }
            pathArray.append(myPath)
            strokePathArray.append(curStrokePath)
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            cubicPath.addPath(path)
        }
        
        return (cubicPath,strokePath)
    }
    
    // MARK: - Monotone Helper class and Methods
    
    public class MonoTone
    {
        var t0:CGFloat = CGFloat.nan
        var switchOption:Int = 0
        var prevPrevXY:CGPoint = CGPoint(x: CGFloat.nan, y: CGFloat.nan)
        var prevXY:CGPoint = CGPoint(x: CGFloat.nan, y: CGFloat.nan)
        
        func reset()
        {
            t0 = CGFloat.nan
            switchOption = 0
            prevPrevXY = CGPoint()
            prevXY = CGPoint()
        }
        
        func lineEnds(myPath:CGMutablePath, dataSet:ChartDataSet, chart:ChartViewBase, isMoveTo: Bool = false)
        {
            switch (switchOption) {
            case 2:
                myPath.addLine(to: CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: Double(prevXY.x), y: Double(prevXY.y), isOriginal: false, dataset: dataSet, chart: chart))
                   break
               
               case 3:
                   let t1 = slope2(prevPrev: prevPrevXY, prev: prevXY, t: t0)
                   addCurveToPath(prevPrev: prevPrevXY, prev: prevXY, t0: t0, t1: t1, path: myPath, dataSet: dataSet, chart: chart, isMoveTo: isMoveTo)
                   break
               default : break
           }
           if switchOption == 1
           {
               myPath.closeSubpath()
           }
        }
    }
    
    public static func pointToAdd(x:CGFloat, y:CGFloat,monotoneObject:MonoTone,myPath:CGMutablePath,dataSet:ChartDataSet, chart:ChartViewBase, isMoveTo: Bool = false) {
        
        var t1 = CGFloat.nan
        
        let prev = monotoneObject.prevXY
        let prevPrev = monotoneObject.prevPrevXY

        if (x == prev.x && y == prev.y)
        {
            return // Ignore coincident points.
        }
        switch (monotoneObject.switchOption) {
            case 0: monotoneObject.switchOption = 1
                    myPath.move(to: CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: x, y: y, isOriginal: false, dataset: dataSet, chart: chart))
                    break
            case 1: monotoneObject.switchOption = 2
                    break
            case 2: monotoneObject.switchOption = 3
                    t1 = slope3(prevPrev: prevPrev, prev: prev, curX: x, curY: y)
                    if t1.isInfinite || t1.isNaN {
                        t1 = 0
                    }
                    var t0 = slope2(prevPrev: prevPrev, prev: prev, t: t1)
                    if t0.isInfinite || t0.isNaN {
                        t0 = 0
                    }
                    addCurveToPath(prevPrev: prevPrev, prev: prev, t0: t0, t1: t1, path: myPath, dataSet: dataSet, chart: chart, isMoveTo: isMoveTo)
                    break
            default: t1 = slope3(prevPrev: prevPrev, prev: prev, curX: x, curY: y)
                     if t1.isInfinite || t1.isNaN {
                         t1 = 0
                     }
                    addCurveToPath(prevPrev: prevPrev, prev: prev, t0: monotoneObject.t0, t1: t1, path: myPath, dataSet: dataSet, chart: chart, isMoveTo: isMoveTo)
                    break
       }
        
        monotoneObject.prevPrevXY = monotoneObject.prevXY
        monotoneObject.prevXY = CGPoint(x: x, y: y)
        monotoneObject.t0 = t1
     }
    
    // "you can express cubic Hermite interpolation in terms of cubic Bézier curves
    // with respect to the four values p0, p0 + m0 / 3, p1 - m1 / 3, p1".
    public static func addCurveToPath(prevPrev:CGPoint,prev:CGPoint, t0:CGFloat, t1:CGFloat, path:CGMutablePath, dataSet: IChartDataSet, chart: ChartViewBase, isMoveTo: Bool = false) {
        let x0 = prevPrev.x,
            y0 = prevPrev.y,
            x1 = prev.x,
            y1 = prev.y,
          dx = (x1 - x0) / 3;
        
        let c1 = CGPoint(x:x0 + dx, y:y0 + dx * t0)
        let c2 = CGPoint(x:x1 - dx, y:y1 - dx * t1)
        let toPoint = CGPoint(x: x1, y: y1)
        
        let c1Pixel = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: Double(c1.x), y: Double(c1.y), isOriginal: false, dataset: dataSet as! ChartDataSet, chart: chart)
        let c2Pixel = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: Double(c2.x), y: Double(c2.y), isOriginal: false, dataset: dataSet as! ChartDataSet, chart: chart)
        let toPixel = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: Double(toPoint.x), y: Double(toPoint.y), isOriginal: false, dataset: dataSet as! ChartDataSet, chart: chart)
        
        if isMoveTo {
            path.move(to: toPixel)
        }
        else {
            path.addCurve(to: toPixel , control1: c1Pixel, control2: c2Pixel)
        }
    }
   
    // Calculate the slopes of the tangents (Hermite-type interpolation) based on
    // the following paper: Steffen, M. 1990. A Simple Method for Monotonic
    // Interpolation in One Dimension.
    
    public static func slope3(prevPrev:CGPoint,prev:CGPoint, curX:CGFloat, curY:CGFloat) -> CGFloat {
        let h0 = prev.x - prevPrev.x,
            h1 = curX - prev.x,
            s0 = (prev.y - prevPrev.y) / h0,        //(h0 || h0 == 0 || h1 < 0 && -0),
            s1 = (curY - prev.y) / h1,             //(h1 || h0 < 0 && -0),
            p = (s0 * h1 + s1 * h0) / (h0 + h1),
            signS0:CGFloat = s0 < 0 ? -1 : 1,
            signS1:CGFloat = s1 < 0 ? -1 : 1
        
        let slope = (signS0 + signS1) * min(abs(s0), abs(s1), 0.5 * abs(p))
        
        return slope
    }
    
    // Calculate a one-sided slope.
    public static func slope2(prevPrev:CGPoint,prev:CGPoint, t:CGFloat) -> CGFloat {
        let h = prev.x - prevPrev.x;
        return h != 0 ? (( ( (3 * (prev.y - prevPrev.y)) / h ) - t) ) / 2 : t;
    }
    
    // MARK: - Close Path Methods
    
    public static func closePathForFill(dataProvider:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,matrix:CGAffineTransform,dataSetPath:CGMutablePath)
    {
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        let fillMin = lineDataSetOptions.fillFormatter?.getFillLinePosition(dataSet: dataSet, chart: dataProvider) ?? 0.0
        
        var pt1 = CGPoint(x: CGFloat(endEntry.x), y: fillMin)
        var pt2 = CGPoint(x: CGFloat(startEntry.x), y: fillMin)
        
        pt1 = dataProvider.pixelForValues(isRotated: dataProvider.isRotated, x: pt1.x, y: pt1.y, axisIndex: dataSet.axisIndex)//pt1.applying(matrix)
        pt2 = dataProvider.pixelForValues(isRotated: dataProvider.isRotated, x: pt2.x, y: pt2.y, axisIndex: dataSet.axisIndex)//pt2.applying(matrix)
        
        if let val = forcedFillValue(chartView: dataProvider, plotType: dataSet.plotType, entry: endEntry) {
            pt1 = val
        }
        
        if let val = forcedFillValue(chartView: dataProvider, plotType: dataSet.plotType, entry: startEntry) {
            pt2 = val
        }
        
        dataSetPath.addLine(to: pt1)
        dataSetPath.addLine(to: pt2)
        
        dataSetPath.closeSubpath()
    }
    
    // MARK: - Stacked Linear
    
    public static func closeStackedLinearPathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,matrix:CGAffineTransform,dataSetPath:CGMutablePath, phaseY: Double)
    {
        // Start from:
        guard let lineChartData = barLineChart.data
            else { return }
        
        let lineChart = barLineChart
        
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: lineChart, plotType: dataSet.plotType)
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        var endIndex = dataSet.entryIndex(entry: endEntry)
        var startIndex = dataSet.entryIndex(entry: startEntry)
        
        var tempSetIndex  = setIndex - 1
        
        var flag = true
        
        let positive = dataSet.yMax > 0
        
        while tempSetIndex >= 0
        {
            let tempSet = lineChartData.dataSets[tempSetIndex]
            
            if !tempSet.isVisible || dataSet.plotType != tempSet.plotType {
                tempSetIndex -= 1
                continue
            }
            
            if (tempSet.yMax > 0 && positive) || (tempSet.yMax < 0 && !positive)
            {
                flag = false
                break
            }
            else{
                tempSetIndex -= 1
            }
        }
        
        if  flag
        {
            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: matrix, dataSetPath: dataSetPath)
            return
        }
        
        
        let set = (lineChartData.dataSets[tempSetIndex])
        let entriesAtStartX = set.entriesForXValue(startEntry.x)
        let entriesAtEndX = set.entriesForXValue(endEntry.x)
        
        let prevDataSetStartEntry:ChartDataEntry = entriesAtStartX[0]
        let prevDataSetEndEntry:ChartDataEntry = entriesAtEndX[entriesAtEndX.count-1]
        
        endIndex = set.entryIndex(entry: prevDataSetEndEntry)
        startIndex = set.entryIndex(entry: prevDataSetStartEntry)
        
        // END: Till here - common for 3 types.. Need to refactor
        
        for index in (startIndex...endIndex).reversed()
        {
            guard let entry = set.entryForIndex(index)
            else { continue }
            
            let bottomY:Double
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                guard (entriesStackedYValue[tempSetIndex]?[index]) != nil
                else { continue }
                bottomY = (entriesStackedYValue[tempSetIndex]![index])! //- entry.y
            }
            
            var bottomPoint = CGPoint(x: entry.x, y: bottomY * phaseY)
            
            bottomPoint = barLineChart.pixelForValues(isRotated: barLineChart.isRotated, x: bottomPoint.x, y: bottomPoint.y, axisIndex: dataSet.axisIndex)
            
            if let val = forcedValue(chartView: barLineChart, plotType: dataSet.plotType, entry: entry) {
                bottomPoint = val
            }
            
            dataSetPath.addLine(to: bottomPoint)
        }
        
        dataSetPath.closeSubpath()
    }
    
    
    // MARK: - Stacked Stepped
    
    public static func closeStackedSteppedPathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,matrix:CGAffineTransform,dataSetPath:CGMutablePath, phaseY: Double)
    {
        guard let lineChartData = barLineChart.data
            else { return }
        
        let lineChartView = barLineChart
        
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: lineChartView, plotType: dataSet.plotType)
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        var endIndex = dataSet.entryIndex(entry: endEntry)
        var startIndex = dataSet.entryIndex(entry: startEntry)
        
        var tempSetIndex  = setIndex - 1
        
        var flag = true
        
        let positive = dataSet.yMax > 0
        
        while tempSetIndex >= 0
        {
            let tempSet = lineChartData.dataSets[tempSetIndex]
            
            if !tempSet.isVisible || dataSet.plotType != tempSet.plotType {
                tempSetIndex -= 1
                continue
            }
            
            if (tempSet.yMax > 0 && positive) || (tempSet.yMax < 0 && !positive)
            {
                flag = false
                break
            }
            else{
                tempSetIndex -= 1
            }
        }
        
        if  flag
        {
            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: matrix, dataSetPath: dataSetPath)
            return
        }
        
        
        let set = (lineChartData.dataSets[tempSetIndex])
        let entriesAtStartX = set.entriesForXValue(startEntry.x)
        let entriesAtEndX = set.entriesForXValue(endEntry.x)
        
        let prevDataSetStartEntry:ChartDataEntry = entriesAtStartX[0]
        let prevDataSetEndEntry:ChartDataEntry = entriesAtEndX[entriesAtEndX.count-1]
        
        
        endIndex = set.entryIndex(entry: prevDataSetEndEntry)
        startIndex = set.entryIndex(entry: prevDataSetStartEntry)
        
        
        for index in (startIndex...endIndex).reversed()
        {
            guard let curEntry = set.entryForIndex(index)
            else { continue }
            
            if curEntry.x.isNaN
            {
                continue
            }
            
            guard var prevEntry = set.entryForIndex(max(index-1,0))
            else { continue }
            
            var tempIndex = max(index-1,0)
            
            while (tempIndex-1) >= 0 && (prevEntry.x.isNaN)
            {
                tempIndex -= 1
                
                guard set.entryForIndex(tempIndex) != nil
                else { break }
                prevEntry = set.entryForIndex(tempIndex)!
            }
            
            if (prevEntry.x.isNaN)
            {
                continue
            }
            
            guard (entriesStackedYValue[tempSetIndex]?[tempIndex]) != nil
            else { continue }
            
            var prevEntryY = (entriesStackedYValue[tempSetIndex]![tempIndex])! //- (prevEntry.y.isNaN ? 0 : prevEntry.y)
            
            var bottomPoint = CGPoint(x: curEntry.x, y: prevEntryY * phaseY)
            
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint, axisIndex: dataSet.axisIndex)
            
            if let val = forcedValue(chartView: barLineChart, plotType: dataSet.plotType, entry: prevEntry) {
                prevEntryY = barLineChart.isRotated ? val.x : val.y
            }
            
            if let val = forcedValue(chartView: barLineChart, plotType: dataSet.plotType, entry: curEntry) {
                bottomPoint = val
                if barLineChart.isRotated {
                    bottomPoint.x = prevEntryY
                }
                else {
                    bottomPoint.y = prevEntryY
                }
            }
            
            dataSetPath.addLine(to: bottomPoint)
            
            bottomPoint = CGPoint(x: prevEntry.x, y: prevEntryY * phaseY)
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint, axisIndex: dataSet.axisIndex)
            
            if let val = forcedValue(chartView: barLineChart, plotType: dataSet.plotType, entry: prevEntry) {
                bottomPoint = val
            }
            
            dataSetPath.addLine(to: bottomPoint)
        }
        
        dataSetPath.closeSubpath()
    }
    
    // MARK: - Stacked Cubic
    
    public static func closeStackedCubicPathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,matrix:CGAffineTransform,dataSetPath:CGMutablePath, phaseY: Double)
    {
        guard let lineChartData = barLineChart.data,
              let lineRenderer =  CommonHelperFunctions.getRenderer(chart: barLineChart, types: [dataSet.plotType]) as? LineChartRenderer
            else { return }
        
        let lineChartView = barLineChart
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: lineChartView, plotType: dataSet.plotType)
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        var endIndex = dataSet.entryIndex(entry: endEntry)
        var startIndex = dataSet.entryIndex(entry: startEntry)
        
//        let phaseY = 1
        let intensity = getLineDataSetOptions(dataSet: dataSet).cubicIntensity
        
        var tempSetIndex  = setIndex - 1
        
        var flag = true
        
        let positive = dataSet.yMax > 0
        
        while tempSetIndex >= 0
        {
            let tempSet = lineChartData.dataSets[tempSetIndex]
            
            if !tempSet.isVisible || dataSet.plotType != tempSet.plotType
            {
                tempSetIndex -= 1
                continue
            }
            
            if (tempSet.yMax > 0 && positive) || (tempSet.yMax < 0 && !positive)
            {
                flag = false
                break
            }
            else{
                tempSetIndex -= 1
            }
        }
        
        if  flag
        {
            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: matrix, dataSetPath: dataSetPath)
            return
        }
        
        
        
        let set = (lineChartData.dataSets[tempSetIndex])
        let entriesAtStartX = set.entriesForXValue(startEntry.x)
        let entriesAtEndX = set.entriesForXValue(endEntry.x)
        
        var prevDataSetStartEntry:ChartDataEntry! = entriesAtStartX[0]
        var prevDataSetEndEntry:ChartDataEntry! = entriesAtEndX[entriesAtEndX.count - 1]
        
        
        endIndex = set.entryIndex(entry: prevDataSetEndEntry)
        
        let (prevX,prevY) = getXYValue(entry: prevDataSetEndEntry, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
        
        guard (entriesStackedYValue[tempSetIndex]?[endIndex]) != nil
        else { return }
        var prevEntryYValue = (entriesStackedYValue[tempSetIndex]![endIndex])!
        
        prevEntryYValue = getXYValue(entry: prevDataSetEndEntry, stackedYValue: prevEntryYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
        
        // Connect to bottom
        //dataSetPath.addLine(to:  CGPoint(x: prevDataSetEndEntry.x, y: (entriesStackedYValue[tempSetIndex]![endIndex])!).applying(matrix))
        var prevPoint = CGPoint(x: CGFloat(prevX),y: CGFloat(prevEntryYValue) * phaseY)
        
        dataSetPath.addLine(to:  barLineChart.pixelForValues(point: prevPoint, isOriginal: false, axisIndex: dataSet.axisIndex))
        
        // Needed extra one point from left and right
        var tempIndex = endIndex + 1
        while tempIndex  < set.entryCount
        {
            guard let tempEntry = set.entryForIndex(tempIndex)
            else { break }
            
            if !(tempEntry.x.isNaN) && tempEntry.x != prevDataSetEndEntry.x
            {
                endIndex = tempIndex
                prevDataSetEndEntry = tempEntry
                break
            }
            else{
                tempIndex += 1
            }
        }
        
        startIndex = max(set.entryIndex(entry: prevDataSetStartEntry)-1,0)
        
        tempIndex = startIndex - 1
        
        while tempIndex  >= 0
        {
            guard let tempEntry = set.entryForIndex(tempIndex)
            else { break }
            
            if !(tempEntry.x.isNaN) && tempEntry.x != prevDataSetStartEntry.x
            {
                startIndex = tempIndex
                
                prevDataSetStartEntry = tempEntry
                break
            }
            else{
                tempIndex -= 1
            }
        }
        
        var tempArray:[Int] = []
        
        for index in ((startIndex)...(endIndex)).reversed()
        {
            guard let cur = set.entryForIndex(index)
            else { continue }
            if cur.x.isNaN
            {
                continue
            }
            tempArray.append(index)
        }
        
        for index in 1..<tempArray.count
        {
            
            let curIndex = tempArray[index]
            
            guard let cur = set.entryForIndex(curIndex)
            else { continue }
            
            
            
            let prevIndex = tempArray[min(index + 1 , tempArray.count-1)]
            guard let prev = set.entryForIndex(prevIndex)
            else { continue }
            
            
            
            let nextIndex = tempArray[max(index - 1 , 0)]
            guard let next = set.entryForIndex(nextIndex)
            else { continue }
            
            
            
            let nextnextIndex = tempArray[max(index - 2 , 0)]
            guard let nextNext = set.entryForIndex(nextnextIndex)
            else { continue }
            
            let (curX,_) = getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            
            let (prevX,_) = getXYValue(entry: prev, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            
            let (nextX,_) = getXYValue(entry: next, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            
            let (nextNextX,_) = getXYValue(entry: nextNext, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            
            
            guard (entriesStackedYValue[tempSetIndex]?[curIndex]) != nil,
                  (entriesStackedYValue[tempSetIndex]?[prevIndex]) != nil,
                  (entriesStackedYValue[tempSetIndex]?[nextIndex]) != nil,
                  (entriesStackedYValue[tempSetIndex]?[nextnextIndex]) != nil
            else { continue }
            
            var curYValue = (entriesStackedYValue[tempSetIndex]![curIndex])!
            var prevYValue = (entriesStackedYValue[tempSetIndex]![prevIndex])!
            var nextYValue = (entriesStackedYValue[tempSetIndex]![nextIndex])!
            var nextNextYValue = (entriesStackedYValue[tempSetIndex]![nextnextIndex])!
            
            curYValue = getXYValue(entry: cur, stackedYValue: curYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            prevYValue = getXYValue(entry: prev, stackedYValue: prevYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            nextYValue = getXYValue(entry: next, stackedYValue: nextYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            nextNextYValue = getXYValue(entry: nextNext, stackedYValue: nextNextYValue, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            
            
            let prevDx = CGFloat(nextNextX - curX) * intensity
            let prevDy = CGFloat(nextNextYValue - curYValue) * intensity
            let curDx = CGFloat(nextX - prevX) * intensity
            let curDy = CGFloat(nextYValue - prevYValue) * intensity
            
            var cp1 = CGPoint(x: CGFloat(nextX) - prevDx,y: (CGFloat(nextYValue) - prevDy) * CGFloat(phaseY))
            
            var cp2 = CGPoint(x: CGFloat(curX) + curDx,y: (CGFloat(curYValue) + curDy) * CGFloat(phaseY))
            
            var toPoint = CGPoint(x: CGFloat(curX),y: CGFloat(curYValue) * CGFloat(phaseY))
            
            cp1 = barLineChart.pixelForValues(point: cp1, isOriginal: false, axisIndex: dataSet.axisIndex)
            cp2 = barLineChart.pixelForValues(point: cp2, isOriginal: false, axisIndex: dataSet.axisIndex)
            toPoint = barLineChart.pixelForValues(point: toPoint, isOriginal: false, axisIndex: dataSet.axisIndex)
            
            dataSetPath.addCurve(
                to: toPoint,
                control1: cp1,
                control2: cp2)
            
        }
        
        dataSetPath.closeSubpath()
    }
    
    public static func getLineDataSetOptions(dataSet: IChartDataSet) -> LineDataSetOptions {
        
           return (dataSet.dataSetOptions as! LineDataSetOptions)
       }
    
    public static func getLineEntryStackedValue(chartViewBase:ChartViewBase, plotType: ChartType) -> [Int:[Int:Double]] {
        guard let processor = chartViewBase.getProcessor(type: plotType) as? AxisChartPreprocessor
            else { return [:] }
        
           return processor.entriesStackedYValue
       }
    
    // MARK: - Stacked Monotone
    public static func closeStackedMonotonePathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,dataSetPath:CGMutablePath, phaseY: Double)
    {
        // Start from:
        guard let chartData = barLineChart.data,
              let lineRenderer = CommonHelperFunctions.getRenderer(chart: barLineChart, types: [dataSet.plotType])
            else { return }
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        let entriesStackedYValue = getLineEntryStackedValue(chartViewBase: barLineChart, plotType: dataSet.plotType)
        
        let setIndex = chartData.indexOfDataSet(dataSet)
        var endIndex = dataSet.entryIndex(entry: endEntry)
        var startIndex = dataSet.entryIndex(entry: startEntry)
        
        let startIndexCopy = startIndex

        var tempSetIndex  = setIndex - 1
        
        var flag = true
        
        let positive = dataSet.yMax > 0
        
        while tempSetIndex >= 0
        {
            let tempSet = chartData.dataSets[tempSetIndex]
            
            if !tempSet.isVisible || dataSet.plotType != tempSet.plotType {
                tempSetIndex -= 1
                continue
            }
            
            if (tempSet.yMax > 0 && positive) || (tempSet.yMax < 0 && !positive)
            {
                flag = false
                break
            }
            else{
                tempSetIndex -= 1
            }
        }
        
        if  flag
        {
            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: dataSetPath)
            return
        }
        
        
        let set = (chartData.dataSets[tempSetIndex])
        let entriesAtStartX = set.entriesForXValue(startEntry.x)
        let entriesAtEndX = set.entriesForXValue(endEntry.x)
        
        let prevDataSetStartEntry:ChartDataEntry = entriesAtStartX[0]
        let prevDataSetEndEntry:ChartDataEntry = entriesAtEndX[entriesAtEndX.count-1]
        
        endIndex = set.entryIndex(entry: prevDataSetEndEntry)
        startIndex = set.entryIndex(entry: prevDataSetStartEntry)
        
        // END: Till here - common for 3 types.. Need to refactor
        
        for index in (endIndex...endIndex)
        {
            guard let entry = set.entryForIndex(index)
            else { continue }
            
            let bottomY:Double
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                guard (entriesStackedYValue[tempSetIndex]?[index]) != nil
                else { continue }
                bottomY = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: (entriesStackedYValue[tempSetIndex]![index])!, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            }
            
            var bottomPoint = CGPoint(x: entry.x, y: bottomY * phaseY)
            
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint, isOriginal: false, axisIndex: dataSet.axisIndex)
            
            dataSetPath.addLine(to: bottomPoint)
            
            break
        }
        
        var tempArray:[Int] = []
        
        for index in ((startIndex)...(endIndex)).reversed()
        {
            guard let cur = set.entryForIndex(index)
            else { continue }
            if cur.x.isNaN
            {
                continue
            }
            tempArray.append(index)
        }
        
        let lastIndex = tempArray.count - 1
        
        let monotoneObject = MonoTone()
        
        var startEntry:ChartDataEntry!
        
        var endEntry:ChartDataEntry!

        var defined0 = false
        
        var curXY = CGPoint()
        
        for j in stride(from: 0, through: lastIndex+1, by: 1)
        {
            let entryIndex = j <= lastIndex ? tempArray[j] : -1
            let entry = set.entryForIndex(entryIndex)
            
            if j <= lastIndex  && entry != nil
            {
                let cur = entry!
                
                if cur.x.isNaN
                {
                    continue
                }
                
                guard (entriesStackedYValue[tempSetIndex]?[entryIndex]) != nil
                else { continue }
                
                curXY.x = CGFloat(getXYValue(entry: cur, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).0)
                curXY.y = CGFloat(getXYValue(entry: cur, stackedYValue: (entriesStackedYValue[tempSetIndex]![entryIndex])!, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1)
                
                endEntry = cur
            }
            
            if (!(j <= lastIndex) == defined0)
            {
                defined0 = (!defined0)
                // Line Start
              if defined0
              {
                    monotoneObject.switchOption = 0
                    startEntry = entry
                    endEntry = entry
              }
              else
              {
                // Line Ends
                monotoneObject.lineEnds(myPath: dataSetPath, dataSet: set as! ChartDataSet, chart: barLineChart)
              }
            }
            if (defined0){
                if monotoneObject.switchOption == 0
                {
                    startEntry = entry
                }
                pointToAdd(x: curXY.x, y: curXY.y * phaseY, monotoneObject: monotoneObject, myPath: dataSetPath, dataSet: set as! ChartDataSet, chart: barLineChart)
            }
        }
        
        for index in (startIndexCopy...startIndexCopy)
        {
            guard let entry = dataSet.entryForIndex(index)
            else { continue }
            
            let bottomY:Double
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                guard (entriesStackedYValue[setIndex]?[index]) != nil
                else { continue }
                bottomY = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: (entriesStackedYValue[setIndex]![index])!, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1
            }
            
            var bottomPoint = CGPoint(x: entry.x, y: bottomY * phaseY)
            
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint, isOriginal: false, axisIndex: dataSet.axisIndex)
            
            dataSetPath.addLine(to: bottomPoint)
            
            break
        }
        
        dataSetPath.closeSubpath()
    }
    
    // MARK: - Area Range Monotone
    public static func closeAreaRangeMonotonePathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,dataSetPath:CGMutablePath, lowerStrokePath:CGMutablePath)
    {
        // Start from:
        guard let lineRenderer = CommonHelperFunctions.getRenderer(chart: barLineChart, types: [.LineRange])
            else { return }
        
        let endIndex = dataSet.entryIndex(entry: endEntry)
        let startIndex = dataSet.entryIndex(entry: startEntry)
 
        // END: Till here - common for 3 types.. Need to refactor
        
        for index in (endIndex...endIndex)
        {
            guard let entry = dataSet.entryForIndex(index)
            else { continue }
            
            let bottomVal:(Double,Double)
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                bottomVal = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: entry.y0, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            }
            
            var bottomPoint = CGPoint(x: bottomVal.0, y: bottomVal.1)
            
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint,isOriginal: false,axisIndex: dataSet.axisIndex)
            
            if let val = forcedFillValue(chartView: barLineChart, plotType: dataSet.plotType, entry: entry) {
                bottomPoint = val
            }
            
            dataSetPath.addLine(to: bottomPoint)
            lowerStrokePath.move(to: bottomPoint)
            
            break
        }
        
        var tempArray:[Int] = []
        
        for index in ((startIndex)...(endIndex)).reversed()
        {
            guard let cur = dataSet.entryForIndex(index)
            else { continue }
            if cur.x.isNaN
            {
                continue
            }
            tempArray.append(index)
        }
        
        let lastIndex = tempArray.count - 1
        
        let monotoneObject = MonoTone()

        var defined0 = false
        
        var curXY = CGPoint()
        
        let lowerStroke = CGMutablePath()
        
        for j in stride(from: 0, through: lastIndex+1, by: 1)
        {
            let entryIndex = j <= lastIndex ? tempArray[j] : -1
            let entry = dataSet.entryForIndex(entryIndex)
            
            if j <= lastIndex  && entry != nil
            {
                let cur = entry!
                
                if cur.x.isNaN || cur.y0.isNaN
                {
                    continue
                }
                
                curXY.x = CGFloat(getXYValueForLineRange(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).0)
                curXY.y = CGFloat(getXYValueForLineRange(entry: cur, stackedYValue: entry!.y0, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1)
                
            }
            
            if (!(j <= lastIndex) == defined0)
            {
                defined0 = (!defined0)
                // Line Start
              if defined0
              {
                    monotoneObject.switchOption = 0
              }
              else
              {
                // Line Ends
                monotoneObject.lineEnds(myPath: lowerStroke, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
              }
            }
            if (defined0){
                if monotoneObject.switchOption == 0
                {
                }
                pointToAdd(x: curXY.x, y: curXY.y, monotoneObject: monotoneObject, myPath: lowerStroke, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
            }
        }
        
        lowerStrokePath.addPath(lowerStroke)
        dataSetPath.addPath(lowerStroke)
        
        for index in (startIndex...startIndex)
        {
            guard let entry = dataSet.entryForIndex(index)
            else { continue }
            
            let bottomY:Double
            
            let xValue:Double
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                (xValue,bottomY) = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: entry.y, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            }
            
            var bottomPoint = CGPoint(x: xValue, y: bottomY)
            
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint, isOriginal: false, axisIndex: dataSet.axisIndex)
            
            dataSetPath.addLine(to: bottomPoint)
            
            break
        }
        
//        dataSetPath.closeSubpath()
    }
    
    public static func closeAreaRangeLinearPathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,matrix:CGAffineTransform,dataSetPath:CGMutablePath, lowerStrokePath: CGMutablePath)
    {
        // Start from:
        guard let lineRenderer = CommonHelperFunctions.getRenderer(chart: barLineChart, types: [.LineRange])
            else { return }
        
        let endIndex = dataSet.entryIndex(entry: endEntry)
        let startIndex = dataSet.entryIndex(entry: startEntry)
 
        // END: Till here - common for 3 types.. Need to refactor
        
        for index in (startIndex...endIndex).reversed()
        {
            guard let entry = dataSet.entryForIndex(index)
            else { continue }
            
            let bottomY:Double
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                bottomY = entry.y0
            }
            
            var bottomPoint = CGPoint(x: entry.x, y: bottomY )
            
            bottomPoint = barLineChart.pixelForValues(point: bottomPoint, axisIndex: dataSet.axisIndex)
            
            if let val = forcedFillValue(chartView: barLineChart, plotType: dataSet.plotType, entry: entry) {
                bottomPoint = val
            }
            
            dataSetPath.addLine(to: bottomPoint)
            if index == endIndex
            {
                lowerStrokePath.move(to: bottomPoint)
            }
            else{
                lowerStrokePath.addLine(to: bottomPoint)
            }
        }
        
        dataSetPath.closeSubpath()
    }
    
     
      // MARK: - Supporting Methods
    
    internal static func getXYValue(entry:ChartDataEntry, axisIndex:Int, lineRenderer: DataRenderer ,chart:ChartViewBase) -> (Double,Double)
    {
        var curXValue = entry.x
        var curYValue =  entry.filterEnabled ? entry.y + Double(entry.barYValue) : entry.y
        
        if lineRenderer.useForcedValue
        {
            if entry.centerChanged != nil
            {
                let curVal = chart.valueForTouchPoint(point: entry.centerChanged!, axisIndex: axisIndex)
                
                if chart.isRotated {
                    curXValue = Double(curVal.y)
                    curYValue = Double(curVal.x)
                }
                else {
                    curXValue = Double(curVal.x)
                    curYValue = Double(curVal.y)
                }
            }
        }
        
        let curVal = CommonHelperFunctions.convertValue(chart: chart, axisIndex: axisIndex, point: CGPoint(x: curXValue, y: curYValue))
        
        return (curVal.x,curVal.y)
    }
    
    internal static func getXYValueForLineRange(entry:ChartDataEntry, axisIndex:Int, lineRenderer: DataRenderer ,chart:ChartViewBase) -> (Double,Double)
    {
        var curXValue = entry.x
        var curYValue =  entry.filterEnabled ? entry.y + Double(entry.barYValue) : entry.y
        
        if lineRenderer.useForcedValue
        {
            if entry.lineCenterChanged != nil
            {
                let curVal = chart.valueForTouchPoint(point: entry.lineCenterChanged!, axisIndex: axisIndex)
                
                if chart.isRotated {
                    curXValue = Double(curVal.y)
                    curYValue = Double(curVal.x)
                }
                else {
                    curXValue = Double(curVal.x)
                    curYValue = Double(curVal.y)
                }
            }
        }
        
        let curVal = CommonHelperFunctions.convertValue(chart: chart, axisIndex: axisIndex, point: CGPoint(x: curXValue, y: curYValue))
        
        return (curVal.x,curVal.y)
    }
    
    internal static func getXYValue(entry:ChartDataEntry, stackedYValue:Double, axisIndex:Int, lineRenderer: DataRenderer ,chart:ChartViewBase) -> (Double,Double)
    {
        var curXValue = entry.x
        var curYValue =  entry.filterEnabled ? stackedYValue + Double(entry.barYValue) : stackedYValue
        
        if lineRenderer.useForcedValue
        {
            if entry.centerChanged != nil
            {
                let curVal = chart.valueForTouchPoint(point: entry.centerChanged!, axisIndex: axisIndex)
                if chart.isRotated {
                    curXValue = Double(curVal.y)
                    curYValue = Double(curVal.x)
                }
                else {
                    curXValue = Double(curVal.x)
                    curYValue = Double(curVal.y)
                }
            }
        }
        
        let curVal = CommonHelperFunctions.convertValue(chart: chart, axisIndex: axisIndex, point: CGPoint(x: curXValue, y: curYValue))
        
        return (curVal.x,curVal.y)
    }
    
    internal static func getXYValueForLineRange(entry:ChartDataEntry, stackedYValue:Double, axisIndex:Int, lineRenderer: DataRenderer ,chart:ChartViewBase) -> (Double,Double)
    {
        var curXValue = entry.x
        var curYValue =  entry.filterEnabled ? stackedYValue + Double(entry.barYValue) : stackedYValue
        
        if lineRenderer.useForcedValue
        {
            if entry.lineCenterChanged != nil
            {
                let curVal = chart.valueForTouchPoint(point: entry.lineCenterChanged!, axisIndex: axisIndex)
                if chart.isRotated {
                    curXValue = Double(curVal.y)
                    curYValue = Double(curVal.x)
                }
                else {
                    curXValue = Double(curVal.x)
                    curYValue = Double(curVal.y)
                }
            }
        }
        
        let curVal = CommonHelperFunctions.convertValue(chart: chart, axisIndex: axisIndex, point: CGPoint(x: curXValue, y: curYValue))
        
        return (curVal.x,curVal.y)
    }
     
    public static func performHighlight(newEntry:ChartDataEntry, chart:ChartViewBase)
     {
         guard let entryLocation = CommonHelperFunctions.getEntryLocation(chart: chart, entry: newEntry)
         else { return }
         
         LineHelperFunctions.highlightAllDatasetEntry(entry: newEntry, chart: chart, includeVerticalLine: true)
         
         // Tooltip delegate
         chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(entryLocation), entry: newEntry)
     }
    
    
       // MARK: - Line Filter Methods
    
    public static func removeLineEntry(entry:ChartDataEntry, chart:ChartViewBase, duration:TimeInterval)
    {
        let completionBlock:(() -> Void)? =
        {
            let typeAllowed = [ChartType.Line]
            guard let chartData = chart.data,
                let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: typeAllowed) as? LinePlotOptions,
                let lineRenderer = (CommonHelperFunctions.getRenderer(chart: chart, types: typeAllowed) as? LineChartRenderer)
                else { return }
            
            chart.lastSelected = nil
            plotOptions.barGroupSelectionEnabled = false
            
            let isLinear = (chart.xAxis.scaleType != .Ordinal)
            
            let xToRemove =  entry.x
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            for set in chartData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                        else { return }
                    
                    if entry.x == xToRemove
                    {
                        entry.filterEnabled = true
                    }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            
            
            for set in chartData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i),
                    let finalEntry = entry.copy() as? ChartDataEntry
                        else { return }
                    
                    if (finalEntry.x == Double.leastNormalMagnitude && finalEntry.origX == entry.origX) || finalEntry.x == xToRemove
                    {
                        continue
                    }
                    if !isLinear && finalEntry.x != Double.leastNormalMagnitude && finalEntry.x > xToRemove
                    {
                        finalEntry.x = Double(finalEntry.x-1)
                    }
                    
                    
                    setEntries.append(finalEntry)
                }
                newEntries.append(setEntries)
            }
            
            let oldPositionArray:[[CGPoint]] = preparePositionArrayforAllDataset(chart: chart)
            
            // reset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
            
            let newPositionArray:[[CGPoint]] = preparePositionArrayforAllDataset(chart: chart)
            
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
            
            var xyInterpolateArray:[[((Double) -> Double)]] = []
            var xRemovedEntryInterpolateArray:[[((Double) -> Double)]] = []
            var yRemovedEntryInterpolateArray:[[((Double) -> Double)]] = []
            
            for dataSetIndex in 0..<chartData.dataSetCount
            {
                guard let set = chartData.dataSets[dataSetIndex] as? ChartDataSet
                    else{ return }
                
                if !(set.isVisible)
                {
                    xyInterpolateArray.append([((Double) -> Double)]())
                    xRemovedEntryInterpolateArray.append([((Double) -> Double)]())
                    yRemovedEntryInterpolateArray.append([((Double) -> Double)]())
                    continue
                }
                
                var setEntriesXYInterpolator:[((Double) -> Double)] = []
                
                var setRemovedEntriesXInterpolator:[((Double) -> Double)] = []
                var setRemovedEntriesYInterpolator:[((Double) -> Double)] = []
                
                var entryIndex = -1
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let entry =  set.entryForIndex(index)
                    else { continue }
                    
                    if entry.x == xToRemove
                    {
                        guard let oldDatasetPoints = oldPositionArray[safe:dataSetIndex],
                            let oldEntryPosition = oldDatasetPoints[safe:index],
                            let newDatasetPoints = newPositionArray[safe:dataSetIndex],
                            let newEntryPosition = (entryIndex) >= 0 ? newDatasetPoints[safe:entryIndex] : newDatasetPoints[safe:0],
                            let newEntryPosition1 = (entryIndex+1) >= newDatasetPoints.count ? newDatasetPoints[safe:entryIndex] : newDatasetPoints[safe:entryIndex+1]
                            else { continue }
                        
                        let oldXValue = oldEntryPosition.x
                        let oldYValue = chart.pixelForValues(x: entry.x, y: entry.y + Double(entry.barYValue) , axisIndex: set.axisIndex).y
                        
                        var newXValue = newEntryPosition.x + ((newEntryPosition1.x - newEntryPosition.x)/2)
                        var newYValue = newEntryPosition.y + ((newEntryPosition1.y - newEntryPosition.y)/2)
                        
                        if (set.dataSetOptions as! LineDataSetOptions).mode == .stepped
                        {
                            newXValue = newEntryPosition1.x
                            newYValue = newEntryPosition.y
                        }
                        
                        let xDiff = Interpolator.interpolate(a: Double(oldXValue), b: (Double(newXValue)))
                        let yDiff = Interpolator.interpolate(a: Double(oldYValue), b: (Double(newYValue)))
                        
                        setRemovedEntriesXInterpolator.append(xDiff)
                        setRemovedEntriesYInterpolator.append(yDiff)
                        continue
                    }
                    
                    entryIndex += 1
                    
                    var oldValue = CGFloat(0)
                    
                    var newValue = CGFloat(0)
                    
                    guard let oldDatasetPoints = oldPositionArray[safe:dataSetIndex],
                        let oldEntryPosition = oldDatasetPoints[safe:index],
                        let newDatasetPoints = newPositionArray[safe:dataSetIndex],
                        let newEntryPosition = newDatasetPoints[safe:entryIndex]
                        else { continue }
                    
                    if chart.isRotated
                    {
                        oldValue = oldEntryPosition.y
                        
                        newValue = newEntryPosition.y
                        
                    }
                    else{
                        oldValue = oldEntryPosition.x
                        
                        newValue = newEntryPosition.x
                        
                    }
                    
                    
                    let radiusDiff = Interpolator.interpolate(a: Double(oldValue), b: (Double(newValue)))
                    
                    setEntriesXYInterpolator.append(radiusDiff)
                    
                }
                xyInterpolateArray.append(setEntriesXYInterpolator)
                xRemovedEntryInterpolateArray.append(setRemovedEntriesXInterpolator)
                yRemovedEntryInterpolateArray.append(setRemovedEntriesYInterpolator)
            }
            
            var sliceAnimator:Animator! = Animator()
            
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
//                barData.setDrawValues(false)
                
                lineRenderer.useForcedValue = true
                
                var interpolatorIndex:Int = 0
                
                var interpolatorRemovedEntryIndex:Int = 0
                
                for dataSetIndex in 0..<chartData.dataSetCount
                {
                    guard let set = chartData.dataSets[dataSetIndex] as? ChartDataSet
                        else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    interpolatorRemovedEntryIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        guard let entry = set.entryForIndex(index)
                        else { continue }
                        
                        if entry.x == xToRemove
                        {
                            guard let valXInterpolator = xRemovedEntryInterpolateArray[safe:dataSetIndex],
                                   let valXInterpolatorfn = valXInterpolator[safe:interpolatorRemovedEntryIndex],
                                    let valYInterpolator = yRemovedEntryInterpolateArray[safe:dataSetIndex],
                                    let valYInterpolatorfn = valYInterpolator[safe:interpolatorRemovedEntryIndex]
                            else { continue }
                            
                            interpolatorRemovedEntryIndex += 1
                            let xValue = valXInterpolatorfn(sliceAnimator.phaseX)
                            let yValue = valYInterpolatorfn(sliceAnimator.phaseX)
                            
                            entry.centerChanged = CGPoint(x: xValue, y: yValue)
                            
                            continue
                        }
                        guard let oldDataset = oldEntries[safe:dataSetIndex],
                            let oldDatasetEntry = oldDataset[safe:index],
                            let oldDatasetPoints = oldPositionArray[safe:dataSetIndex],
                            let oldDatasetEntryPoint = oldDatasetPoints[safe:index],
                            let valInterpolator = xyInterpolateArray[safe:dataSetIndex],
                            let valInterpolatorfn = valInterpolator[safe:interpolatorIndex]
                            else { return }
                        
                        let newEntry = oldDatasetEntry
                        
                        let oldPoint = oldDatasetEntryPoint
                        
                        var newCenter = CGPoint(x: oldPoint.x, y: oldPoint.y)
                        
                        let newVal = valInterpolatorfn(sliceAnimator.phaseX)
                        
                        interpolatorIndex = interpolatorIndex + 1
                        
            
                        if chart.isRotated
                        {
                            newCenter.y = CGFloat(newVal)
                        }
                        else{
                            newCenter.x = CGFloat(newVal)
                        }
                        
        
                        newEntry.centerChanged = newCenter
                        
                    }
                }
                        chart.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                lineRenderer.useForcedValue = false
                
                sliceAnimator = nil
                
                chart.setNeedsDisplay()
                
                var removedEntries:[ChartDataEntry] = []
                
                /*for set in barData.dataSets
                {
                    for entryToRemove in (set.entriesForXValue(xToRemove))
                    {
                        removedEntries.append(entryToRemove)
                    }
                }*/
                
                for set in chartData.dataSets
                {
                    for entryToRemove in  (set as! ChartDataSet).values where entryToRemove.origX == entry.origX
                    {
                        removedEntries.append(entryToRemove)
                    }
                }
                
                ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
                 
                ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
                
               /* CommonHelperFunctions.resetData(newEntries: newEntries, chart: barChart)
                
//                barChart.resizeAxisIfNeeded()
                
                barData.updateXYValues()
                
                for set in barData.dataSets
                {
                    set.calcMinMax()
                }
                
                barData.notifyDataChanged()
                
                processor.calcPosNegSum()
                
                //Should be called before calling chart.notifyDataSetChanged()
                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: barChart)
                
                barChart.notifyDataSetChanged(redrawRequired: true)*/
                
                CommonHelperFunctions.enableIncludeLayer(chart: chart)
                
                chart.interactionAnimationInProgress = false
                
                chart.lastSelected = nil
                plotOptions.barGroupSelectionEnabled = false
                
                chart.callDelegateToContainer(highlight: nil, entry: nil)
                
                chart.delegateToContainer?.chartValueRemoved?(chart, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
                
            }
            
            sliceAnimator.animate(xAxisDuration: duration, easingOption: .linear)
            
        }
        
        completionBlock!()
    }
    
    public static func includeLineEntry(entries:[ChartDataEntry], newXPosition:Double,duration:TimeInterval, chart:ChartViewBase)
    {
            guard
                let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line]) as? LinePlotOptions,
                let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Line]) as? LineChartRenderer
                else { return }
            
            chart.lastSelected = nil
            plotOptions.barGroupSelectionEnabled = false
            chart.callDelegateToContainer(highlight: nil, entry: nil)
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            guard let eOrigX = entries[0].origX
            else { return }
            let xIndexDict = chart.originalMap[eOrigX]
        
            let isLinear = chart.xAxis.scaleType != .Ordinal
            
            guard (chart.data?._dataSets) != nil
            else { return }
            for set in (chart.data?._dataSets)!
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                    else { continue }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            // To track index to includeEntry
            var trackIndex:Int = 0
            
            for setIndex in 0..<(chart.data?._dataSets.count)!
            {
                guard let set = (chart.data?.dataSets[setIndex])
                else { continue }
                var setEntries:[ChartDataEntry] = []
                var entryToAddCount = 0
                if xIndexDict?[setIndex] != nil
                {
                    entryToAddCount = (xIndexDict![setIndex]?.count)!
                }
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                    else { continue }
                    
                    while  entryToAddCount > 0 && entry.x >= newXPosition   //(entry.origIndex)! > (barEntries[trackIndex].origIndex)!
                    {
                        setEntries.append(entries[trackIndex])
                        trackIndex += 1
                        entryToAddCount -= 1
                    }
                    
                    
                    guard let finalEntry = entry.copy() as? ChartDataEntry
                    else { continue }
                    
                    if !isLinear
                    {
                        let isEntryAfterFilterEntry = entry.x >= newXPosition //isStacked() ? entry.x >= newXIndex : i >=  ChartUtils.doubleToIntSafeCast(value:newXIndex)
                        if  isEntryAfterFilterEntry
                        {
                            finalEntry.x = Double(entry.x+1)
                        }
                    }
                    
                    setEntries.append(finalEntry)
                }
                
                while entryToAddCount > 0
                {
                    setEntries.append(entries[trackIndex])
                    trackIndex += 1
                    entryToAddCount -= 1
                }
                
                newEntries.append(setEntries)
            }
            
            let oldPositionArray:[[CGPoint]] = preparePositionArrayforAllDataset(chart: chart)
            
            // reset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
            
            let newPositionArray:[[CGPoint]] = preparePositionArrayforAllDataset(chart: chart)
            
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
            
            var xyInterpolateArray:[[((Double) -> Double)]] = []
            var xAddedEntryInterpolateArray:[[((Double) -> Double)]] = []
            var yAddedEntryInterpolateArray:[[((Double) -> Double)]] = []
            
            trackIndex = 0
        
            for dataSetIndex in 0..<(chart.data?.dataSetCount)!
            {
                guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
                else { continue }
                
                var entryToAddCount = 0
                if xIndexDict?[dataSetIndex] != nil
                {
                    entryToAddCount = (xIndexDict![dataSetIndex]?.count)!
                }
                
                if !(set.isVisible)
                {
                    xyInterpolateArray.append([((Double) -> Double)]())
                    xAddedEntryInterpolateArray.append([((Double) -> Double)]())
                    yAddedEntryInterpolateArray.append([((Double) -> Double)]())
                    trackIndex += entryToAddCount
                    continue
                }
                
                var setEntriesXYInterpolator:[((Double) -> Double)] = []
                
                var setAddedEntriesXInterpolator:[((Double) -> Double)] = []
                var setAddedEntriesYInterpolator:[((Double) -> Double)] = []
                
                
                
                var addedEntryCenterUpdated:Bool = false
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let currentEntry = set.entryForIndex(index)
                    else { continue }
                    
                    var oldValue = CGFloat(0)
                    
                    var newValue = CGFloat(0)
                    
                    var entryIndex = index
                    
                    if currentEntry.x >= newXPosition && !(addedEntryCenterUpdated)
                    {
                        for addedEntryIndex in index..<(index+entryToAddCount)
                        {
                            let positionArray = newPositionArray[dataSetIndex]
                            let addedEntry = entries[trackIndex]
                            trackIndex += 1
                            
                            let prevPosition = (index - 1) >= 0 ? newPositionArray[dataSetIndex][index-1] : newPositionArray[dataSetIndex][1]
                            let nextPosition = (index + entryToAddCount) >= positionArray.count ?  newPositionArray[dataSetIndex][positionArray.count - 1] :
                            newPositionArray[dataSetIndex][index + entryToAddCount]
                            
                            var fromXValue = prevPosition.x + ((nextPosition.x - prevPosition.x)/2)
                            var fromYValue = prevPosition.y + ((nextPosition.y - prevPosition.y)/2)
                            
                            let toValue = newPositionArray[dataSetIndex][addedEntryIndex]
                            
                            if (set.dataSetOptions as! LineDataSetOptions).mode == .stepped
                            {
                                fromXValue = nextPosition.x
                                fromYValue = prevPosition.y
                            }
                            
                            let xDiff = Interpolator.interpolate(a: Double(fromXValue), b: (Double(toValue.x)))
                            let yDiff = Interpolator.interpolate(a: Double(fromYValue), b: (Double(toValue.y)))
                            
                            setAddedEntriesXInterpolator.append(xDiff)
                            setAddedEntriesYInterpolator.append(yDiff)
                            
                            addedEntry.centerChanged = CGPoint(x: fromXValue, y: fromYValue)
                        }
                        
                        addedEntryCenterUpdated = true
                    }
                    
                    let isEntryAfterFilterEntry = currentEntry.x >= newXPosition //isStacked() ? currentEntry.x >= newXIndex : index >=  ChartUtils.doubleToIntSafeCast(value:newXIndex)
                    
                    if  isEntryAfterFilterEntry
                    {
                          entryIndex = index + entryToAddCount
                    }
                        
                    if chart.isRotated
                    {
                        oldValue = oldPositionArray[dataSetIndex][index].y
                        
                        newValue = newPositionArray[dataSetIndex][entryIndex].y
                        
                    }
                    else{
                        oldValue = oldPositionArray[dataSetIndex][index].x
                        
                        newValue = newPositionArray[dataSetIndex][entryIndex].x
                        
                    }
                    
                    
                    let radiusDiff = Interpolator.interpolate(a: Double(oldValue), b: (Double(newValue)))
                    
                    setEntriesXYInterpolator.append(radiusDiff)
                    
                }
                
                if !(addedEntryCenterUpdated) && entryToAddCount > 0
                {
                    for addedEntryIndex in 0..<(entryToAddCount)
                    {
                        let positionArray = newPositionArray[dataSetIndex]
                        let addedEntry = entries[trackIndex]
                        trackIndex += 1
                        
                        let lastEntryIndex = positionArray.count - 1 - entryToAddCount
                        
                        let prevPosition = newPositionArray[dataSetIndex][lastEntryIndex]
                        let nextPosition = newPositionArray[dataSetIndex][lastEntryIndex]
                        
                        let fromXValue = prevPosition.x + ((nextPosition.x - prevPosition.x)/2)
                        let fromYValue = prevPosition.y + ((nextPosition.y - prevPosition.y)/2)
                        
                        let toValue = newPositionArray[dataSetIndex][lastEntryIndex+addedEntryIndex+1]
                        
                        let xDiff = Interpolator.interpolate(a: Double(fromXValue), b: (Double(toValue.x)))
                        let yDiff = Interpolator.interpolate(a: Double(fromYValue), b: (Double(toValue.y)))
                        
                        setAddedEntriesXInterpolator.append(xDiff)
                        setAddedEntriesYInterpolator.append(yDiff)
                        
                        addedEntry.centerChanged = CGPoint(x: fromXValue, y: fromYValue)
                    }
                }
                
                xyInterpolateArray.append(setEntriesXYInterpolator)
                xAddedEntryInterpolateArray.append(setAddedEntriesXInterpolator)
                yAddedEntryInterpolateArray.append(setAddedEntriesYInterpolator)
                
            }
            
            var sliceAnimator:Animator! = Animator()
            
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                renderer.useForcedValue = true
                
//                chart.data?.setDrawValues(false)
                chart.interactionAnimationInProgress = true
                
                var interpolatorIndex:Int = 0
                
                guard (chart.data) != nil
                else { return }
                
                for dataSetIndex in 0..<(chart.data?.dataSetCount)!
                {
                    guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
                    else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        let newEntry = oldEntries[dataSetIndex][index]
                        
                        let oldRect = oldPositionArray[dataSetIndex][index]
                        
                        var newCenter = CGPoint(x: oldRect.x, y: oldRect.y)
                        
                        let newVal = xyInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                        
                        interpolatorIndex = interpolatorIndex + 1
                        
                        if chart.isRotated
                        {
                            newCenter.y = CGFloat(newVal)
                        }
                        else{
                            newCenter.x = CGFloat(newVal)
                        }
                        
                        newEntry.centerChanged = newCenter
                    }
                }
                
                chart.setNeedsDisplay()
                
            }
            
                    sliceAnimator.stopBlock = {
              
                        /*CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)

                        chart.data?.updateXYValues()
                        
                        for set in (chart.data?._dataSets)!
                        {
                            set.calcMinMax()
                        }
                        
                        chart.data?.notifyDataChanged()
                        
                        chart.notifyDataSetChanged(redrawRequired: true)*/
                        
                        ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
                        
                        ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: chart)

                        
                        // To make percentage rise animation
                      /*  var stackInterpolateArray:[((Double) -> Double)] = []

                        for entry in entries
                        {
                            let yInterpolator = Interpolator.interpolate(a: 0, b: entry.y)
                            stackInterpolateArray.append(yInterpolator)
                            entry.y = 0
                        }
                        processor.updateEntriesStackValue()*/
                        
                        let entryAnimator = Animator()
                        
                        entryAnimator.updateBlock = {
                            
                            trackIndex = 0
                            for setInterPolatorIndex in 0..<xAddedEntryInterpolateArray.count
                            {
                                guard (chart.data) != nil
                                else { continue }
                                if !((chart.data?.dataSets[setInterPolatorIndex].isVisible)!)
                                {
                                    var entryToAddCount = 0
                                    
                                    if xIndexDict?[setInterPolatorIndex] != nil
                                    {
                                        entryToAddCount = (xIndexDict![setInterPolatorIndex]?.count)!
                                    }
                                
                                    trackIndex += entryToAddCount
                                    continue
                                }
                                
                                let setXInterPolator = xAddedEntryInterpolateArray[setInterPolatorIndex]
                                let setYInterPolator = yAddedEntryInterpolateArray[setInterPolatorIndex]
                                
                                for entryInterpolatorIndex in 0..<setXInterPolator.count
                                {
                                    let entryXInterPolator = setXInterPolator[entryInterpolatorIndex]
                                    let entryYInterPolator = setYInterPolator[entryInterpolatorIndex]
                                    
                                    let xValue = entryXInterPolator(entryAnimator.phaseX)
                                    let yValue = entryYInterPolator(entryAnimator.phaseX)
                                    
                                    entries[trackIndex].centerChanged = CGPoint(x: xValue, y: yValue)
                                    trackIndex += 1
                                }
                            }
                
                            
                            chart.setNeedsDisplay()
                        }
                        
                        entryAnimator.stopBlock = {
                            
                            renderer.useForcedValue = false
                            
                            chart.interactionAnimationInProgress = false
                            
            //                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
                            ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
                            
//                            chart.enableDrawValues()
                            
                            CommonHelperFunctions.enableIncludeLayer(chart: chart)
                            
                            sliceAnimator = nil
                            
                            chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entries, dataSets: nil, dataSetAdded: false)
                        }
                        
                        entryAnimator.animate(xAxisDuration: duration * 0.3, easingOption: .linear)
                    }
            
        sliceAnimator.animate(xAxisDuration: duration * 0.7, easingOption: .linear)
    }
    
    public static func preparePositionArrayforAllDataset(chart:ChartViewBase) -> [[CGPoint]]
    {
        var tempDatasetArray:[[CGPoint]] = []
        
        guard (chart.data) != nil
        else { return tempDatasetArray }
        for dataset in (chart.data?._dataSets)!
        {
            if !(dataset.isVisible)
            {
                tempDatasetArray.append([CGPoint]())
                continue
            }
            
            let trans = chart.getTransformer(axisIndex: dataset.axisIndex)
            
            let valueToPixelMatrix = trans.valueToPixelMatrix
            
            var positionArray:[CGPoint] = []
            
            for i in 0..<(dataset.entryCount)
            {
                guard let entry = (dataset.entryForIndex(i))
                else { continue }
                positionArray.append(trans.pixelForValues(x: entry.x, y: entry.y))
            }
            
            tempDatasetArray.append(positionArray)
        }
        
        return tempDatasetArray
    }
    
    public static func prepareDataSetArray(selectedDataset:IChartDataSet, chart:ChartViewBase ) -> [CGRect]
    {
        var positionArray:[CGRect] = []
        
        guard let plotOption = chart.getPlotOptions(type: selectedDataset.plotType) as? PlotOptionsBase,
            let processor =  chart.getProcessor(type: selectedDataset.plotType)
            else { return  positionArray }
        
         guard let setIndex = (chart.data?.indexOfDataSet(selectedDataset))
        else { return positionArray}
         
         for i in 0..<(selectedDataset.entryCount)
         {
             guard let entry = (selectedDataset.entryForIndex(i))
             else { continue }
            
             let eYValues = plotOption.isStacked ? (entry.x.isNaN ? Double.nan : (processor.entriesStackedYValue[setIndex]?[i] ?? Double.nan))
                : entry.y
            
             let position = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated ,x: entry.x, y: eYValues, dataset: selectedDataset as! ChartDataSet, chart: chart)
            
            var shapeSize = CGSize()
            if selectedDataset.plotType == .BubblePie || selectedDataset.plotType == .Bubble
            {
                guard let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.BubblePie,.Bubble]) as? BubbleChartRenderer,
                      (chart.data) != nil
                else { continue}
                
                let scale = renderer.getBubbleSizeScale(bubbleData: chart.data!, plotOptions: plotOption as! BubblePlotOptions)
                
                let shapeSizeWidth = renderer.getBubbleSize(sizeValue: entry.size ?? 0.0, scale: scale, plotOptions: plotOption as! BubblePlotOptions, bubbleData: chart.data!)
                shapeSize = CGSize(width: shapeSizeWidth, height: shapeSizeWidth)
            
            }
             
            if selectedDataset.plotType == .LineRange {
                let posY0 = CommonHelperFunctions.getPixelForValues(x: entry.x, y: entry.y0, dataSet: selectedDataset as! ChartDataSet, chart: chart)
                 
                shapeSize = CGSize(width: posY0.y, height: posY0.y)
            }
            
            positionArray.append(CGRect(origin: position, size: shapeSize))
         }
     
        return positionArray
     }
    
    
    
    // MARK: - Web Linear
    public static func getWebLinearPathWithNAN(barLineChart:ChartViewBase, fromIndex:Int, toIndex:Int, dataSet:IChartDataSet, animator:Animator?, lineRenderer:DataRenderer, isStepped:Bool) -> (CGPath,CGPath) {
        
        let finalPath = CGMutablePath()
        let strokePath = CGMutablePath()

        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
        
        let path = CGMutablePath()
        
        var pathArray:[CGMutablePath] = []
        var strokePathArray:[CGMutablePath] = []
        
        let isDrawSteppedEnabled = isStepped
        
        let phaseY =  (animator == nil) ? 1 : animator!.phaseY
        
        var e1: ChartDataEntry!
        var e2: ChartDataEntry!
       
        e1 = dataSet.entryForIndex(fromIndex)
        
        if e1 != nil
        {
            var firstPoint = true
            
            for x in stride(from: fromIndex, through: toIndex, by: 1)
            {
                e1 = dataSet.entryForIndex(x == 0 ? 0 : (x - 1))
                e2 = dataSet.entryForIndex(x)
                
                if e1 == nil || e2 == nil || (e1.x.isNaN && e2.x.isNaN) || e1.x.isNaN { continue }
                
                if e2.x.isNaN
                {
                    var tempIndex = x
                    guard var tempEntry = dataSet.entryForIndex(tempIndex)
                    else { continue}
                    
                    while (tempIndex+1) < dataSet.entryCount && (tempEntry.x.isNaN)
                    {
                        tempIndex += 1
                        tempEntry = dataSet.entryForIndex(tempIndex) ?? tempEntry
                    }
                    
                    if (tempEntry.x.isNaN)
                    {
                        continue
                    }
                    else{
                        e2 = tempEntry
                    }
                }
                
                var (e1XVal,e1YVal) = getXYValue(entry: e1, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                var (e2XVal,e2YVal) = getXYValue(entry: e2, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                 
                let replaceValue = barLineChart.getYAxis(atIndex: dataSet.axisIndex)?._axisMinimum ?? 0
                
                if e1YVal.isNaN
                {
                    e1YVal = replaceValue
                }
                if e2YVal.isNaN
                {
                    e2YVal = replaceValue
                }
                
                let e1Val = CGPoint(x: e1XVal, y: e1YVal)
                let e2Val = CGPoint(x: e2XVal, y: e2YVal)
                
                (e1XVal,e1YVal) = (Double(e1Val.x),Double(e1Val.y))
                (e2XVal,e2YVal) = (Double(e2Val.x),Double(e2Val.y))
                
                let pt = CommonHelperFunctions.getPixelForValues(x: e1XVal, y: e1YVal * phaseY, isOriginal: false, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                
                if firstPoint
                {
                    path.move(to: pt)
                    firstPoint = false
                }
                else
                {
                    path.addLine(to: pt)
                }
                
                if isDrawSteppedEnabled
                {
                    path.addLine(to: CommonHelperFunctions.getPixelForValues(x: e2XVal, y: e1YVal * phaseY, isOriginal: false, dataSet: dataSet as! ChartDataSet, chart: barLineChart))
                        
                }
                
                path.addLine(to: CommonHelperFunctions.getPixelForValues(x: e2XVal, y: e2YVal * phaseY, isOriginal: false, dataSet: dataSet as! ChartDataSet, chart: barLineChart))
            }
            
            
            if !firstPoint {
                
                if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled //&& !(barLineChart.plotTypes.contains(.Radar))
                {
                    path.closeSubpath()
                    strokePathArray.append(path.mutableCopy()!)
                }
                pathArray.append(path)
            }
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            finalPath.addPath(path)
        }
        
        return (finalPath,strokePath)
    }
    
    /// Stacked
    public static func getWebLinearStackedPathWithNAN(barLineChart:ChartViewBase, dataSet:IChartDataSet, fromIndex:Int, toIndex:Int, animator:Animator?, lineRenderer:DataRenderer, isStepped:Bool) -> (CGPath,CGPath) {
        
        let finalPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        guard
            let lineChartData = barLineChart.data,
            let radarProcessor = barLineChart.getProcessor(type: .Radar) as? RadarPreprocessor
            else { return (finalPath,strokePath) }
        
        
        let entriesStackedYValue = radarProcessor.entriesStackedYValue
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let path = CGMutablePath()
        
        var pathArray:[CGMutablePath] = []
        var strokePathArray:[CGMutablePath] = []
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        let isDrawSteppedEnabled = lineDataSetOptions.mode == .stepped
        
        let phaseY = (animator == nil) ? 1 : animator!.phaseY
       
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        
        var e1: ChartDataEntry!
        var e2: ChartDataEntry!
        
        var startEntry:ChartDataEntry!
        var endEntry:ChartDataEntry!
        
        e1 = dataSet.entryForIndex(fromIndex)
        
        if e1 != nil
        {
            var firstPoint = true
            
            for x in stride(from: fromIndex, through: toIndex, by: 1)
            {
                let e1Index = x == 0 ? 0 : (x - 1)
                var e2Index = x
                
                e1 = dataSet.entryForIndex(e1Index)
                e2 = dataSet.entryForIndex(e2Index)
                
                if e1 == nil || e2 == nil || (e1.x.isNaN && e2.x.isNaN) || e1.x.isNaN { continue }
                
                let e1XVal = e1.x
                
                if e2.x.isNaN
                {
                    var tempIndex = x
                    guard var tempEntry = dataSet.entryForIndex(tempIndex)
                    else { continue }
                    
                    while (tempIndex+1) < dataSet.entryCount && (tempEntry.x.isNaN)
                    {
                        tempIndex += 1
                        tempEntry = dataSet.entryForIndex(tempIndex) ?? tempEntry
                    }
                    
                    if (tempEntry.x.isNaN)
                    {
                        continue
                    }
                    else{
                        e2 = tempEntry
                        e2Index = tempIndex
                    }
                }
                
                let e2XVal = e2.x
                
                guard (entriesStackedYValue[setIndex]?[e1Index]) != nil,
                      (entriesStackedYValue[setIndex]?[e2Index]) != nil
                else { continue }
                let e1Value =  getXYValue(entry: e1, stackedYValue: (entriesStackedYValue[setIndex]![e1Index])!, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                let e2Value =  getXYValue(entry: e2, stackedYValue: (entriesStackedYValue[setIndex]![e2Index])!, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                
                let e1Point = CGPoint(x: e1Value.0, y: e1Value.1)
                let e2Point = CGPoint(x: e2Value.0, y: e2Value.1)
                
            
                let pt = CommonHelperFunctions.getPixelForValues(x: e1XVal, y: e1Point.y * phaseY, isOriginal: false, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                
                if firstPoint
                {
                    startEntry = e1
                    endEntry = e1
                    path.move(to: pt)
                    firstPoint = false
                }
                else
                {
                    path.addLine(to: pt)
                    endEntry = e2
                }
                
                if isDrawSteppedEnabled
                {
                    path.addLine(to: CommonHelperFunctions.getPixelForValues(x: e2XVal, y: e1Point.y * phaseY, isOriginal: false, dataSet: dataSet as! ChartDataSet, chart: barLineChart))

                }
                
                path.addLine(to: CommonHelperFunctions.getPixelForValues(x: e2XVal, y: e2Point.y * phaseY, isOriginal: false, dataSet: dataSet as! ChartDataSet, chart: barLineChart))

                endEntry = e2
            }
            
            
            if !firstPoint {
                
                if (barLineChart.includeLayer) && lineDataSetOptions.isDrawFilledEnabled
                {
                    strokePathArray.append(path.mutableCopy()!)
                    
                    path.closeSubpath()
                    if isDrawSteppedEnabled
                    {
                        closeStackedSteppedPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: path, phaseY: phaseY)
                    }
                    else{
                        closeWebStackedLinearPathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, dataSetPath: path, phaseY: phaseY)
                    }
                    
                }
                
                pathArray.append(path)
            }
        }
        
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            finalPath.addPath(path)
        }
        
        return (finalPath,strokePath)
    }
    
    // MARK: - Web Monotone
    
    public static func getWebMonotoneDataSetPathWithNAN(barLineChart:ChartViewBase,fromIndex:Int, toIndex:Int, dataSet:IChartDataSet, animator:Animator?, lineRenderer:DataRenderer) -> (CGPath,CGPath)
    {
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
       // let _xBounds = lineRenderer._xBounds
        
      //  _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        var pathArray:[CGMutablePath] = []
        
        var strokePathArray:[CGMutablePath] = []
        
        if (toIndex - fromIndex) >= 0
        {
            let firstIndex = fromIndex
            let lastIndex = toIndex
            
            let monotoneObject = MonoTone()
            
            var myPath = CGMutablePath()
            
            var startEntry:ChartDataEntry!
            
            var endEntry:ChartDataEntry!

            var defined0 = false
            
            var curXY = CGPoint()
            
            let replaceValue = barLineChart.getYAxis(atIndex: dataSet.axisIndex)?._axisMinimum ?? 0
            
            for j in stride(from: firstIndex, through: lastIndex+1, by: 1)
            {
                let entry = dataSet.entryForIndex(j)
                
                if j <= lastIndex  && entry != nil
                {
                    let cur = entry!
                    
                    if cur.x.isNaN
                    {
                        continue
                    }
                    
                    let (curXValue,curYValue) = getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
                    curXY.x = curXValue.isNaN ?  CGFloat(0) : CGFloat(curXValue)
                    curXY.y = curYValue.isNaN ?  CGFloat(replaceValue) : CGFloat(curYValue)
                    
                    if curXY.x.isNaN || curXY.y.isNaN
                    {
                        // Line Breaks
                        monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(myPath.mutableCopy()!)
                        
                            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                        }
                        
                        pathArray.append(myPath)
                        myPath = CGMutablePath()
                        monotoneObject.reset()
                        continue
                    }
                    
                    endEntry = cur
                }
                
                if (!(j <= lastIndex) == defined0)
                {
                    defined0 = (!defined0)
                    // Line Start
                  if defined0
                  {
                        monotoneObject.switchOption = 0
                        startEntry = entry
                        endEntry = entry
                  }
                  else
                  {
                    // Line Ends
                    monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            myPath.closeSubpath()
                            strokePathArray.append(myPath.mutableCopy()!)
                        }
                  }
                }
                if (defined0){
                    if monotoneObject.switchOption == 0
                    {
                        startEntry = entry
                    }
                    pointToAdd(x: curXY.x, y: curXY.y, monotoneObject: monotoneObject, myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                }
            }
            pathArray.append(myPath)
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            cubicPath.addPath(path)
        }
        
        return (cubicPath,strokePath)
    }
    
    public static func getWebMonotoneStackedDataSetPathWithNAN(barLineChart:ChartViewBase,fromIndex:Int, toIndex:Int, dataSet:IChartDataSet, animator:Animator?, lineRenderer:DataRenderer) -> (CGPath,CGPath)
    {
        // the path for the cubic-spline
        let cubicPath = CGMutablePath()
        let strokePath = CGMutablePath()
        
        guard
            let lineChartData = barLineChart.data,
            let radarProcessor = barLineChart.getProcessor(type: .Radar) as? RadarPreprocessor
            else { return (cubicPath,strokePath) }
        
        let entriesStackedYValue = radarProcessor.entriesStackedYValue
        
        let lineDataSetOptions = getLineDataSetOptions(dataSet: dataSet)
        
        let trans = barLineChart.getTransformer(axisIndex: dataSet.axisIndex)
        
        let setIndex = lineChartData.indexOfDataSet(dataSet)
        
       // let _xBounds = lineRenderer._xBounds
        
      //  _xBounds.set(chart: barLineChart, dataSet: dataSet, animator: animator)
        
        let valueToPixelMatrix = trans.valueToPixelMatrix
        
        var pathArray:[CGMutablePath] = []
        
        var strokePathArray:[CGMutablePath] = []
        
        if (toIndex - fromIndex) >= 0
        {
            let firstIndex = fromIndex
            let lastIndex = toIndex
            
            let monotoneObject = MonoTone()
            
            var myPath = CGMutablePath()
            
            var startEntry:ChartDataEntry!
            
            var endEntry:ChartDataEntry!

            var defined0 = false
            
            var curXY = CGPoint()
            
            for j in stride(from: firstIndex, through: lastIndex+1, by: 1)
            {
                let entry = dataSet.entryForIndex(j)
                
                if j <= lastIndex  && entry != nil
                {
                    let cur = entry!
                    
                    if cur.x.isNaN
                    {
                        continue
                    }
                    
                    guard (entriesStackedYValue[setIndex]?[j]) != nil
                    else { continue }
                    
                    curXY.x = CGFloat(getXYValue(entry: cur, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).0)
                    curXY.y = CGFloat(getXYValue(entry: cur, stackedYValue: (entriesStackedYValue[setIndex]![j])!, axisIndex: dataSet.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1)
                    
                    if curXY.x.isNaN || curXY.y.isNaN
                    {
                        // Line Breaks
                        monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(myPath.mutableCopy()!)
                        
                            closePathForFill(dataProvider: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, matrix: valueToPixelMatrix, dataSetPath: myPath)
                        }
                        
                        pathArray.append(myPath)
                        myPath = CGMutablePath()
                        monotoneObject.reset()
                        continue
                    }
                    
                    endEntry = cur
                }
                
                if (!(j <= lastIndex) == defined0)
                {
                    defined0 = (!defined0)
                    // Line Start
                  if defined0
                  {
                        monotoneObject.switchOption = 0
                        startEntry = entry
                        endEntry = entry
                  }
                  else
                  {
                    // Line Ends
                    monotoneObject.lineEnds(myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                        if lineDataSetOptions.isDrawFilledEnabled && startEntry != nil && endEntry != nil
                        {
                            strokePathArray.append(myPath.mutableCopy()!)
                            myPath.closeSubpath()
                            
                            closeWebStackedMonotonePathForFill(barLineChart: barLineChart, dataSet: dataSet, startEntry: startEntry, endEntry: endEntry, dataSetPath: myPath)
                        }
                  }
                }
                if (defined0){
                    if monotoneObject.switchOption == 0
                    {
                        startEntry = entry
                    }
                    pointToAdd(x: curXY.x, y: curXY.y, monotoneObject: monotoneObject, myPath: myPath, dataSet: dataSet as! ChartDataSet, chart: barLineChart)
                }
            }
            pathArray.append(myPath)
        }
        
        for path in strokePathArray {
            strokePath.addPath(path)
        }
        
        for path in pathArray {
            cubicPath.addPath(path)
        }
        
        return (cubicPath,strokePath)
    }
    
    
    // MARK: - Web Close Path
    
    // MARK: Stacked Linear
    public static func closeWebStackedLinearPathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,dataSetPath:CGMutablePath, phaseY: Double)
    {
        // Start from:
        guard let chartData = barLineChart.data,
            let radarProcessor = barLineChart.getProcessor(type: .Radar) as? RadarPreprocessor,
            let lineRenderer = CommonHelperFunctions.getRenderer(chart: barLineChart, types: [.Radar])
            else { return }
        
        let entriesStackedYValue = radarProcessor.entriesStackedYValue
        
        let setIndex = chartData.indexOfDataSet(dataSet)
        var endIndex = dataSet.entryIndex(entry: endEntry)
        var startIndex = dataSet.entryIndex(entry: startEntry)
        
        var tempSetIndex  = setIndex - 1
        
        var flag = true
        
        let positive = dataSet.yMax > 0
        
        while tempSetIndex >= 0
        {
            let tempSet = chartData.dataSets[tempSetIndex]
            
            if !tempSet.isVisible || dataSet.plotType != tempSet.plotType {
                tempSetIndex -= 1
                continue
            }
            
            if (tempSet.yMax > 0 && positive) || (tempSet.yMax < 0 && !positive)
            {
                flag = false
                break
            }
            else{
                tempSetIndex -= 1
            }
        }
        
        if  flag
        {
            return
        }
        
        
        let set = (chartData.dataSets[tempSetIndex])
        let entriesAtStartX = set.entriesForXValue(startEntry.x)
        let entriesAtEndX = set.entriesForXValue(endEntry.x)
        
        let prevDataSetStartEntry:ChartDataEntry = entriesAtStartX[0]
        let prevDataSetEndEntry:ChartDataEntry = entriesAtEndX[entriesAtEndX.count-1]
        
        endIndex = set.entryIndex(entry: prevDataSetEndEntry)
        startIndex = set.entryIndex(entry: prevDataSetStartEntry)
        
        // END: Till here - common for 3 types.. Need to refactor
        
        for index in (startIndex...endIndex)
        {
            guard let entry = set.entryForIndex(index)
            else { continue }
            
            var bottomVal:(Double,Double)
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                guard (entriesStackedYValue[tempSetIndex]?[index]) != nil
                else { continue }
                bottomVal = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: (entriesStackedYValue[tempSetIndex]![index])!, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            }
            
            var bottomPoint = CGPoint(x: bottomVal.0, y: bottomVal.1)
            
            bottomPoint = CommonHelperFunctions.getPixelForValues(x: bottomPoint.x, y: bottomPoint.y, isOriginal: false, dataSet: set as! ChartDataSet, chart: barLineChart)
            
            dataSetPath.addLine(to: bottomPoint)
            break
        }
        
        for index in (startIndex...endIndex).reversed()
        {
            guard let entry = set.entryForIndex(index)
            else { continue }
            
            var bottomVal:(Double,Double)
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                guard (entriesStackedYValue[tempSetIndex]?[index]) != nil
                else { continue }
                bottomVal = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: (entriesStackedYValue[tempSetIndex]![index])!, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            }
            
            var bottomPoint = CGPoint(x: bottomVal.0, y: bottomVal.1)
            
            bottomPoint = CommonHelperFunctions.getPixelForValues(x: bottomPoint.x, y: bottomPoint.y * phaseY, isOriginal: false, dataSet: set as! ChartDataSet, chart: barLineChart)
            
            dataSetPath.addLine(to: bottomPoint)
        }
        
        dataSetPath.closeSubpath()
    }
    
    
    // MARK: Stacked Monotone
    public static func closeWebStackedMonotonePathForFill(barLineChart:ChartViewBase, dataSet:IChartDataSet,startEntry:ChartDataEntry, endEntry:ChartDataEntry,dataSetPath:CGMutablePath)
    {
        // Start from:
        guard let chartData = barLineChart.data,
            let radarProcessor = barLineChart.getProcessor(type: .Radar) as? RadarPreprocessor,
            let lineRenderer = CommonHelperFunctions.getRenderer(chart: barLineChart, types: [.Radar])
            else { return }
        
        let entriesStackedYValue = radarProcessor.entriesStackedYValue
        
        let setIndex = chartData.indexOfDataSet(dataSet)
        var endIndex = dataSet.entryIndex(entry: endEntry)
        var startIndex = dataSet.entryIndex(entry: startEntry)

        var tempSetIndex  = setIndex - 1
        
        var flag = true
        
        let positive = dataSet.yMax > 0
        
        while tempSetIndex >= 0
        {
            let tempSet = chartData.dataSets[tempSetIndex]
            
            if !tempSet.isVisible || dataSet.plotType != tempSet.plotType {
                tempSetIndex -= 1
                continue
            }
            
            if (tempSet.yMax > 0 && positive) || (tempSet.yMax < 0 && !positive)
            {
                flag = false
                break
            }
            else{
                tempSetIndex -= 1
            }
        }
        
        if  flag
        {
            return
        }
        
        
        let set = (chartData.dataSets[tempSetIndex])
        let entriesAtStartX = set.entriesForXValue(startEntry.x)
        let entriesAtEndX = set.entriesForXValue(endEntry.x)
        
        let prevDataSetStartEntry:ChartDataEntry = entriesAtStartX[0]
        let prevDataSetEndEntry:ChartDataEntry = entriesAtEndX[entriesAtEndX.count-1]
        
        endIndex = set.entryIndex(entry: prevDataSetEndEntry)
        startIndex = set.entryIndex(entry: prevDataSetStartEntry)
        
        // END: Till here - common for 3 types.. Need to refactor
        
        for index in (startIndex...endIndex)
        {
            guard let entry = set.entryForIndex(index)
            else { continue }
            
            var bottomVal:(Double,Double)
            
            if entry.x.isNaN
            {
                continue
            }
            else{
                guard (entriesStackedYValue[tempSetIndex]?[index]) != nil
                else { continue }
                bottomVal = LineHelperFunctions.getXYValue(entry: entry, stackedYValue: (entriesStackedYValue[tempSetIndex]![index])!, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart)
            }
            
            var bottomPoint = CGPoint(x: bottomVal.0, y: bottomVal.1)
            
            bottomPoint = CommonHelperFunctions.getPixelForValues(x: entry.x, y: bottomPoint.y, isOriginal: false, dataSet: set as! ChartDataSet, chart: barLineChart)
            
            dataSetPath.addLine(to: bottomPoint)
            
            break
        }
        
        var tempArray:[Int] = []
        
        for index in ((startIndex)...(endIndex)).reversed()
        {
            guard let cur = set.entryForIndex(index)
            else { continue }
            if cur.x.isNaN
            {
                continue
            }
            tempArray.append(index)
        }
        
        let lastIndex = tempArray.count - 1
        
        let monotoneObject = MonoTone()
        
        var startEntry:ChartDataEntry!
        
        var endEntry:ChartDataEntry!

        var defined0 = false
        
        var curXY = CGPoint()
        
        for j in stride(from: 0, through: lastIndex+1, by: 1)
        {
            let entryIndex = j <= lastIndex ? tempArray[j] : -1
            let entry = set.entryForIndex(entryIndex)
            
            if j <= lastIndex  && entry != nil
            {
                let cur = entry!
                
                if cur.x.isNaN
                {
                    continue
                }
                guard (entriesStackedYValue[tempSetIndex]?[entryIndex]) != nil
                else { continue }
                
                curXY.x = CGFloat(getXYValue(entry: cur, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).0)
                curXY.y = CGFloat(getXYValue(entry: cur, stackedYValue: (entriesStackedYValue[tempSetIndex]![entryIndex])!, axisIndex: set.axisIndex, lineRenderer: lineRenderer, chart: barLineChart).1)
                
                endEntry = cur
            }
            
            if (!(j <= lastIndex) == defined0)
            {
                defined0 = (!defined0)
                // Line Start
              if defined0
              {
                    monotoneObject.switchOption = 0
                    startEntry = entry
                    endEntry = entry
              }
              else
              {
                // Line Ends
                monotoneObject.lineEnds(myPath: dataSetPath, dataSet: set as! ChartDataSet, chart: barLineChart)
              }
            }
            if (defined0){
                if monotoneObject.switchOption == 0
                {
                    startEntry = entry
                }
                pointToAdd(x: curXY.x, y: curXY.y, monotoneObject: monotoneObject, myPath: dataSetPath, dataSet: set as! ChartDataSet, chart: barLineChart)
            }
        }
        
        dataSetPath.closeSubpath()
    }
    
    // MARK: - Support
    
    public static func createLineStrokeLayer(lineLayer: LineLayer, dataSet: IChartDataSet, strokePath: CGPath)
    {
        lineLayer.lineWidth = 0
        let shapeLayer = LineStrokeLayer()
        shapeLayer.strokeColor = dataSet.colors[0].cgColor
        shapeLayer.path = strokePath
        shapeLayer.lineWidth = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet).lineWidth
        shapeLayer.fillColor = NSUIColor.clear.cgColor
        lineLayer.addSublayer(shapeLayer)
        
    }
    
}

extension LineHelperFunctions {
    
    static func forcedValue(chartView: ChartViewBase, plotType: ChartType, entry: ChartDataEntry) -> CGPoint?{
        
        guard let lineRenderer = CommonHelperFunctions.getRenderer(chart: chartView, types: [plotType])
        else {
            return nil
        }
        
        if lineRenderer.useForcedValue {
            if entry.centerChanged != nil {
                return entry.centerChanged
            }
        }
        
        return nil
    }
    
    static func forcedFillValue(chartView: ChartViewBase, plotType: ChartType, entry: ChartDataEntry) -> CGPoint? {
        
        guard let lineRenderer = CommonHelperFunctions.getRenderer(chart: chartView, types: [plotType])
        else {
            return nil
        }
        
        if lineRenderer.useForcedValue {
            
            if entry.lineCenterChanged != nil {
                return entry.lineCenterChanged!
            }
            
        }
        
        return nil
    }
}
