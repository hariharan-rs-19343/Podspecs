//
//  WaterFallHelperFunctions.swift
//  zchart
//
//  Created by keerthi-pt4274 on 05/07/22.
//

import Foundation



open class WaterFallHelperFunction{
    
    public static func createConnectorLayer(chart: ChartViewBase) -> ConnectorLayer {
        
        guard let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.WaterFall]) as? WaterFallPlotOptions else {
            return ConnectorLayer()
        }
        
        let layer = ConnectorLayer()
        
        layer.strokeColor = plotOption.connectorStrokecolor.cgColor

        layer.fillColor = plotOption.connectorStrokecolor.cgColor
        
        layer.lineWidth = plotOption.connectorLineWidth
        
        layer.lineCap = plotOption.connectorCapType
        
        layer.lineDashPhase = plotOption.connectorDashPhase
        
        if plotOption.connectorDashLengths != nil
        {
            if let dashLength = plotOption.connectorDashLengths as? [NSNumber] {
                layer.lineDashPattern = dashLength
            }
        }
        else
        {
            layer.lineDashPhase = 0.0
            layer.lineDashPattern = nil
        }
        
        return layer
    }
    
    public static func getMaxYValueForX(chart: ChartViewBase, xVal: Double, BaseValue: Double) -> Double {
        
        guard let processor = CommonHelperFunctions.getProcessor(chart: chart, types: [.WaterFall]) as? WaterFallPreprocessor else {
            return 0.0
        }
        
        var val = 0.0
        
        if processor.positiveSum[xVal] != nil && processor.negativeSum[xVal] == nil {
            val = processor.positiveSum[xVal]!
        }
        else if processor.positiveSum[xVal] == nil && processor.negativeSum[xVal] != nil {
            val = processor.negativeSum[xVal]!
        }
        else {
            
            if let positiveSum = processor.positiveSum[xVal], let negativeSum = processor.negativeSum[xVal] {
                
                let posVal = abs(BaseValue - positiveSum)
            
                let negVal = abs(BaseValue - negativeSum)
            
                if posVal > negVal {
                    val = processor.positiveSum[xVal]!
                }
                else {
                    val = processor.negativeSum[xVal]!
                }
            }
        }
        
        return val
    }
    
    public static func sumForStackedWaterFall(chart: ChartViewBase, xPositiveDict: inout [Double:(Double,Double)], xNegativeDict: inout [Double:(Double,Double)]) {
        
        guard
        let data = chart.data,
        let processor = CommonHelperFunctions.getProcessor(chart: chart, types: [.WaterFall]) as? WaterFallPreprocessor
        else {
            return
        }
        
        var baseValue = 0.0
        
        guard (data.xString) != nil
        else { return }
        
        for xIndex in 1..<data.xString!.count {
            
            let xVal = Double(xIndex)
            
            var prevBaseValue = WaterFallHelperFunction.getMaxYValueForX(chart: chart, xVal: Double(xIndex - 1), BaseValue: baseValue)
            
            if processor.cascadeIndex.contains(xIndex) {
                
                prevBaseValue = 0.0
            }
            
            if (xPositiveDict[xVal] != nil) {
                xPositiveDict[xVal] = ((xPositiveDict[xVal]!.0 - prevBaseValue),xPositiveDict[xVal]!.1)
            }
            
            if (xNegativeDict[xVal] != nil) {
                xNegativeDict[xVal] = ((xNegativeDict[xVal]!.0 - prevBaseValue),xNegativeDict[xVal]!.1)
            }
            
            baseValue = prevBaseValue
        }
    }
    
    public static func getConnecterLayer(chart: ChartViewBase) -> [ConnectorLayer] {
        var connectorLayers:[ConnectorLayer] = []
        
        guard  let sublayers = (chart.plotView?.nsuiLayer?.sublayers) else { return connectorLayers }
        
        for layer in sublayers
        {
            let caLayer:CALayer = layer
            if caLayer.isKind(of: ConnectorLayer.self)
            {
                connectorLayers.append((caLayer as! ConnectorLayer))
            }
        }
        return connectorLayers
    }
    
    public static func prepareDataSetArray(selectedDataset:IChartDataSet, chart:ChartViewBase ) -> [CGRect]
    {
         var datasetEntries:[ChartDataEntry] = []
         
         for i in 0..<(selectedDataset.entryCount)
         {
             guard let entry = (selectedDataset.entryForIndex(i))
             else { continue }
             datasetEntries.append(entry)
             
         }
         
         let barPositionArray:[CGRect]
         
//         if chart.isRotated
//         {
//             barPositionArray = HorizontalWaterFallChartRenderer.getHorizontalWaterFallRectArray(entries: datasetEntries, animator: ((chart)._animator), dataSet: selectedDataset, chart: chart)
//         }
//         else{
             barPositionArray = WaterFallChartRenderer.getWaterFallRectArray(entries: datasetEntries, animator: ((chart)._animator), dataSet: selectedDataset, chart: chart)
//         }
     
         return barPositionArray
     
     }
    
    public static func disableConnectorLine(chart: ChartViewBase) {
        
        let connectorLayers = getConnecterLayer(chart: chart)
        
        if connectorLayers.count > 0 {
            connectorLayers[0].opacity = 0.0
        }
    }
    
    public static func enableConnectorLine(chart: ChartViewBase) {
        
        let connectorLayers = getConnecterLayer(chart: chart)
        
        if connectorLayers.count > 0 {
            connectorLayers[0].opacity = 1.0
        }
    }
    
    public static func isCascade(entry: ChartDataEntry) -> Bool {
        return ((entry.plotData as? Int) != nil && (entry.plotData as! Int) == 1)
    }
    
    public static func getBaseYvalueForCascade(chart: ChartViewBase, value: Double, setIndex: Int, entryIndex: Int) -> Double {
        
            guard
                let data = chart.data,
                let processor = CommonHelperFunctions.getProcessor(chart: chart, types: [.WaterFall]) as? WaterFallPreprocessor
            else {
                return 0.0
            }
        
            var yStart = 0.0
            
            let datasets = data.dataSets
            
            let positiveVal = value > 0 ? true : false
            
            let negativeVal = value < 0 ? true : false
        
            if setIndex > 0 {
            
                for index in stride(from: (setIndex - 1), to: -1, by: -1) {
                
                    if !datasets[index].isVisible {
                        continue
                    }
                
                    if let val = processor.entriesStackedYValue[index]?[entryIndex] {
                
                        if val > 0 && positiveVal || val < 0 && negativeVal {
                            yStart = val
                            break
                        }
                    }
                }
            }
        
            return yStart
        }
    
    public static func getBaseValue(chart: ChartViewBase, entry: ChartDataEntry) -> Double {
        
        var currentYvalue = 0.0
        
        guard let xString = chart.data?.xString,
              let processor = CommonHelperFunctions.getProcessor(chart: chart, types: [.WaterFall]) as? WaterFallPreprocessor
            else {
            return currentYvalue
        }
        
        var basevalue = 0.0
        
        for xIndex in 0..<xString.count {
            
            if processor.cascadeIndex.contains(xIndex) {
                
                currentYvalue = 0.0
                basevalue = 0.0
            }
            
            if entry.xString == xString[xIndex] {
                break
            }
            
            currentYvalue = WaterFallHelperFunction.getMaxYValueForX(chart: chart, xVal: Double(xIndex), BaseValue: basevalue)
            
            basevalue = currentYvalue
        }
        
        return currentYvalue
    }
    
    static func getNextEntry(dataset: IChartDataSet, index: Int) -> ChartDataEntry? {
        
        var counterIndex = index
        
        var nextEntry = dataset.entryForIndex(counterIndex)
        
        while nextEntry != nil && (nextEntry?.x.isNaN)!
        {
            counterIndex += 1
            nextEntry = dataset.entryForIndex(counterIndex)
        }
        
        return nextEntry
    }
    
    static func isZeroOrNan(entriesStackedYValue: [Int:[Int:Double]], datasets: [IChartDataSet], xIndex: Int, CurrentBaseValue: Double) -> Bool {
        
        var allowed = true
        
        for setIndex in 0..<datasets.count {
            
            if let yVal = entriesStackedYValue[setIndex]?[xIndex] {
                
                if CurrentBaseValue != yVal {
                    allowed = false
                    break
                }
            }
        }
        
        return allowed
    }
}
