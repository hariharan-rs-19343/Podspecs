//
//  FunnelHelperFunctions.swift
//  zchart
//
//  Created by Aravinth T on 11/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class FunnelHelperFunctions {
    
    // MARK:- Funnel Interaction Methods
    // MARK:  Funnel Filter In/Out Handling
        
    static func includeFunnelLayerEntry(entries: [ChartDataEntry], funnelSlicePoints:[FunnelSlicePoint],entryPointMap:[ChartDataEntry:FunnelSlicePoint], funnelChart:ChartViewBase) {
        
            guard let funnelPlotOptions = funnelChart.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
                let dataSet = funnelChart.data?.dataSets[0]
            else { return }
        
            for entryIndex in 0..<entries.count
            {
                let entry = entries[entryIndex]
                
                let index = dataSet.entryIndex(entry: entry)
                
                let finalPoints = funnelSlicePoints[entryIndex].points
            
                var newPoints:[CGPoint] = []
            
                let point4X = (finalPoints[1].x + finalPoints[2].x ) / 2
                var point4y = (finalPoints[1].y + finalPoints[2].y ) / 2
                
                let point1X = (finalPoints[0].x + finalPoints[3].x ) / 2
                var point1y = (finalPoints[0].y + finalPoints[3].y ) / 2
                
                let yDiff = getNewYValue(entryPointMap: entryPointMap, index: index, funnelChart: funnelChart)
                
                if yDiff != 0 {
                    point4y = yDiff
                    point1y = yDiff
                }
                
    //            let midPoint = ( point1X + point4X ) / 2
    //            let point2X = ( point1X + midPoint ) / 2
    //            let point3X = ( midPoint + point4X ) / 2
                
                newPoints.append(CGPoint(x: point1X, y: point1y))
                newPoints.append(CGPoint(x: point4X, y: point4y))
                newPoints.append(CGPoint(x: point4X, y: point4y))
                newPoints.append(CGPoint(x: point1X, y: point1y))
                
                if funnelPlotOptions.funnelWeightedType == .Height {
                    
                    let (x1, x2) = getNewXEnds(entryPointMap: entryPointMap, index: index, funnelChart: funnelChart)
                    
                    if (x1 != 0 && x2 != 0) {
                        newPoints.removeAll()
                        if finalPoints.count == 6 {
                            newPoints.append(CGPoint(x: x1, y: point1y))
                            newPoints.append(CGPoint(x: x2, y: point4y))
                            newPoints.append(CGPoint(x: x2, y: point4y))
                            newPoints.append(CGPoint(x: x2, y: point4y))
                            newPoints.append(CGPoint(x: x1, y: point1y))
                            newPoints.append(CGPoint(x: x1, y: point1y))
                        } else {
                            newPoints.append(CGPoint(x: x1, y: point1y))
                            newPoints.append(CGPoint(x: x2, y: point4y))
                            newPoints.append(CGPoint(x: x2, y: point4y))
                            newPoints.append(CGPoint(x: x1, y: point1y))
                        }
                    }
                }
                
                
                let newFunnelPoint = FunnelSlicePoint()
                newFunnelPoint.points = newPoints
                
                guard let newLayer = FunnelLayer.createFunnelLayerForEntry(chart: funnelChart, entry: entry, funnelSlicePoint: newFunnelPoint)
                else { return }
                
                
                
                let newPath = FunnelHelperFunctions.getBezeirPath(cgPoints: finalPoints)

                CommonHelperFunctions.performPathAnim(targetLayer: newLayer, newPath: newPath, duration: 0.2, completionBlock: nil)
            }
            
        for entry in entries
        {
            entry.enabled = true
        }
            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int((0.2) * 1000)), execute: {
                
                funnelChart.delegateToContainer?.chartValueAdded?(chartView: funnelChart, entries: entries, dataSets: nil, dataSetAdded:false)
            })
    }

    
    static func removeFunnelLayer(layersToRemove:[FunnelLayer], newOtherLayers:[FunnelLayer],entryPointMap:[ChartDataEntry : FunnelSlicePoint], funnelChart:ChartViewBase){
        
        guard let funnelPlotOptions = funnelChart.getPlotOptions(type: .Funnel) as? FunnelPlotOptions
        else { return }
        
        for layerToRemove in layersToRemove
        {
            guard (layerToRemove.chartEntry) != nil,
                  let index = funnelChart.data?.dataSets[0].entryIndex(entry: layerToRemove.chartEntry!),
                  let oldPoints = (layerToRemove.funnelSlicePoint?.points)
            else { continue }
            
            var newPoints:[CGPoint] = []
            
            let point4X = (oldPoints[1].x + oldPoints[2].x ) / 2
            
            var point4y = (oldPoints[1].y + oldPoints[2].y ) / 2
            
            let point1X = (oldPoints[0].x + oldPoints[3].x ) / 2
            
            var point1y = (oldPoints[0].y + oldPoints[3].y ) / 2
            
            let yDiff = getNewYValue(entryPointMap: entryPointMap, index: index, funnelChart: funnelChart)
            
            if yDiff != 0 {
                point4y = yDiff
                point1y = yDiff
            }
            
            newPoints.append(CGPoint(x: point1X, y: point1y))
            newPoints.append(CGPoint(x: point4X, y: point4y))
            newPoints.append(CGPoint(x: point4X, y: point4y))
            newPoints.append(CGPoint(x: point1X, y: point1y))
            
            if funnelPlotOptions.funnelWeightedType == .Height {
                
                let (x1, x2) = getNewXEnds(entryPointMap: entryPointMap, index: index, funnelChart: funnelChart)
                
                if (x1 != 0 && x2 != 0) {
                    
                    newPoints.removeAll()
                    
                    if oldPoints.count == 6 {
                        newPoints.append(CGPoint(x: x1, y: point1y))
                        newPoints.append(CGPoint(x: x2, y: point4y))
                        newPoints.append(CGPoint(x: x2, y: point4y))
                        newPoints.append(CGPoint(x: x2, y: point4y))
                        newPoints.append(CGPoint(x: x1, y: point1y))
                        newPoints.append(CGPoint(x: x1, y: point1y))
                    }
                    else if oldPoints.count == 4 {
                        
                        newPoints.append(CGPoint(x: x1, y: point1y))
                        newPoints.append(CGPoint(x: x2, y: point4y))
                        newPoints.append(CGPoint(x: x2, y: point4y))
                        newPoints.append(CGPoint(x: x1, y: point1y))
                    }
                    
                }
            }
            
            let newPath = FunnelHelperFunctions.getBezeirPath(cgPoints: newPoints)
            
            CommonHelperFunctions.performPathAnim(targetLayer: layerToRemove, newPath: newPath, duration: 0.2)
            
            let textLayer = FunnelLayer.getFunnelValueLayerForIndex(chart: funnelChart, index: layerToRemove.getEntryIndex())
            if textLayer != nil {
//                UIView.animate(withDuration: 0.2, animations: {
//                    textLayer?.opacity = 0.0
//                })
//                CommonHelperFunctions.performOpacityAnim(targetLayers: [textLayer!], fromOpacity: CGFloat(textLayer!.opacity), toOpacity: 0.0, duration: 0.2)//ERROR ON MACOS
                textLayer?.opacity = 0.0
            }
        }
    }
    
    // MARK: - HighLight Methods
    public static func highlightFunnelLayerForEntry(entry: ChartDataEntry, funnelChart:ChartViewBase) {

        let funnelLayer = FunnelLayer.getFunnelLayerForEntry(chart: funnelChart, entry: entry)
        
        if funnelLayer == nil {
            return
        }
        
        guard let points = (funnelLayer?.funnelSlicePoint?.points)
        else { return }
        
        let startPoint = points[0]
        
        let (entry,layer) = FunnelHelperFunctions.tapHighlight(location: startPoint, recognizer: funnelChart.tapEventListener, chart: funnelChart)
        
        funnelChart._tapEventListener?.handler?.execute(funnelChart, entry: entry, entryLayer: layer, funnelChart.tapEventListener, startPoint)
        
//        if chartActionListener != nil
//        {
//            chartActionListener?.tapEventCalled?(chartView: self, selectedEntry: entry, selectedLayer: funnelLayer)
//        }
    }
       
    public static func tapHighlight(location: CGPoint, recognizer: NSUIGestureRecognizer?, chart:ChartViewBase) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?) {
           
        var entry:ChartDataEntry? = nil
           
        var funnelLayer:FunnelLayer? = nil
           
        funnelLayer = FunnelLayer.getFunnelLayerInPoint(chart: chart, loc: location)
           
        if funnelLayer != nil
        {
            entry = funnelLayer?.getFunnelChartEntry()
        }
          
        return (entry,funnelLayer)
    }

    
    // MARK: - Supporting Methods
    
    /// Funnel :- Animates All Funnel Layer and Text Layer After Filtering Given Funnel Layer
    public static func removeEntryAndAnimateOtherLayers(layersToRemove:[FunnelLayer], funnelChart:ChartViewBase) {
        
        var removedEntries:[ChartDataEntry] = []
        
        for layerToRemove in layersToRemove
        {
            layerToRemove.getFunnelChartEntry().enabled = false
            removedEntries.append(layerToRemove.getFunnelChartEntry())
        }
        
        let newOtherLayers:[FunnelLayer] = FunnelHelperFunctions.getEnabledLayersInIndexOrder(chart: funnelChart)
        
        guard let dataSet = (funnelChart.data?.dataSets[0]) as? ChartDataSet
        else { return }
        
        let newValues = FunnelChartRenderer.getEntryPointMap(dataSet: dataSet, chart: funnelChart)
        
        FunnelHelperFunctions.performFilterAnimationForOtherLayers(funnelChart: funnelChart, newOtherLayers: newOtherLayers,entryToPointMap: newValues, duration: 0.2)
        
        FunnelHelperFunctions.performFilterAnimationForTextLayers(funnelChart: funnelChart, newOtherLayers: newOtherLayers,entryToPointMap: newValues, duration: 0.2)
        
        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int((0.2) * 1000)), execute: {
            
            funnelChart.interactionAnimationInProgress = false
            
            funnelChart.delegateToContainer?.chartValueRemoved?(funnelChart, entries: removedEntries, dataSets: nil, dataSetRemoved: false,  showTrackerView: false  )
            
        })
    }
    
    /// Disable given entires
    public static func removeEntries(entries: [ChartDataEntry],chart:ChartViewBase,duration: TimeInterval)
    {
        guard
            let dataSet = (chart.data?.dataSets[0]) as? ChartDataSet
            else { return }
        
        for entry in entries
        {
            entry.enabled = false
        }
        
        let removedLayers:[FunnelLayer] = FunnelHelperFunctions.getDisabledLayersInIndexOrder(chart: chart)
            
        let newOtherLayers:[FunnelLayer] = FunnelHelperFunctions.getEnabledLayersInIndexOrder(chart: chart)
            
        let newValues = FunnelChartRenderer.getEntryPointMap(dataSet: dataSet, chart: chart)
        
        FunnelHelperFunctions.removeFunnelLayer(layersToRemove: removedLayers, newOtherLayers: newOtherLayers, entryPointMap: newValues, funnelChart: chart)
        
        FunnelHelperFunctions.removeEntryAndAnimateOtherLayers(layersToRemove: removedLayers, funnelChart: chart)
    }
    
    /// Enable Given Entries
    public static func includeEntries(entries: [ChartDataEntry], chart:ChartViewBase, duration: TimeInterval)
    {
        guard let dataSet = (chart.data?.dataSets[0]) as? ChartDataSet
        else { return }
        
        
        for entry in entries
        {
            entry.enabled = true
        }
        
        let entryPointMap = FunnelChartRenderer.getEntryPointMap(dataSet: dataSet, chart: chart)
        
        let existingLayers = FunnelLayer.getAllFunnelLayer(chart: chart)
        
        var existingEntryToPointMap:[ChartDataEntry:FunnelSlicePoint] = [:]
        
        for layer in existingLayers {
            guard ((layer.funnelSlicePoint) != nil)
            else { continue }
            existingEntryToPointMap[layer.getFunnelChartEntry()] = (layer.funnelSlicePoint)!
        }
        
        FunnelHelperFunctions.performFilterAnimationForTextLayers(funnelChart: chart, newOtherLayers: existingLayers,entryToPointMap: entryPointMap, duration: 0.2)
        
        FunnelHelperFunctions.performFilterAnimationForOtherLayers(funnelChart: chart, newOtherLayers: existingLayers, entryToPointMap: entryPointMap, duration: 0.2)
        
        var funnelSlicePoints:[FunnelSlicePoint] = []
        
        for entry in entries
        {
            guard (entryPointMap[entry] != nil)
            else { continue }
            funnelSlicePoints.append(entryPointMap[entry]!)
        }
        
        for entry in entries
        {
            entry.enabled = false
        }
        FunnelHelperFunctions.includeFunnelLayerEntry(entries: entries, funnelSlicePoints: funnelSlicePoints, entryPointMap: existingEntryToPointMap, funnelChart: chart)
    }
    
    /// returns All Funnel Layer Except Given Layer
    public static func getEnabledLayersInIndexOrder(chart:ChartViewBase) -> [FunnelLayer] {
        
        var newOtherLayers:[FunnelLayer] = []
        
        let funnelLayers = FunnelLayer.getAllFunnelLayer(chart: chart)
        
        for funnelLayer in funnelLayers {
            
            guard (funnelLayer.chartEntry) != nil
            else { continue }
            if funnelLayer.chartEntry!.enabled {
                newOtherLayers.append(funnelLayer)
            }
        }
        
        newOtherLayers = newOtherLayers.sorted(by: {$0.getEntryIndex() < $1.getEntryIndex() })
        
        return newOtherLayers
    }
    
    /// returns All Funnel Layer Except Given Layer
    public static func getDisabledLayersInIndexOrder(chart:ChartViewBase) -> [FunnelLayer] {
        
        var newOtherLayers:[FunnelLayer] = []
        
        let funnelLayers = FunnelLayer.getAllFunnelLayer(chart: chart)
        
        for funnelLayer in funnelLayers {
            
            guard (funnelLayer.chartEntry) != nil
            else { continue }
            
            if !(funnelLayer.chartEntry!.enabled) {
                newOtherLayers.append(funnelLayer)
            }
        }
        
        newOtherLayers = newOtherLayers.sorted(by: {$0.getEntryIndex() < $1.getEntryIndex() })
        
        return newOtherLayers
    }
     
    internal static func getNewYValue(entryPointMap:[ChartDataEntry:FunnelSlicePoint], index:Int, funnelChart: ChartViewBase) -> CGFloat {
         
        guard let dataSet = funnelChart.data?.dataSets[0] as? ChartDataSet
            else { return 0}
        
         var yDiff:CGFloat = 0.0
         
         var prevLastPoint:CGPoint = CGPoint.zero
         var nextFirstPoint:CGPoint = CGPoint.zero
         
        let prevIndex = getPrevValidIndex(currentIndex: index, funnelChart: funnelChart)
         
         if prevIndex != -1 {
             guard let prevEntry = dataSet.entryForIndex(prevIndex),
             let prevFunnelPoint = entryPointMap[prevEntry]
             else { return 0 }
             prevLastPoint = (prevFunnelPoint.points[0])
         }
         
         let nextIndex = getNextValidIndex(currentIndex: index, funnelChart: funnelChart)
         
         if nextIndex != -1 {
             guard let nextEntry = dataSet.entryForIndex(nextIndex),
             let nextFunnelPoint = entryPointMap[nextEntry]
             else { return 0}
             nextFirstPoint = (nextFunnelPoint.points[3])
         }
         
         if prevLastPoint != CGPoint.zero && nextFirstPoint != CGPoint.zero {
              yDiff = (nextFirstPoint.y + prevLastPoint.y) / 2
         }else if prevLastPoint != CGPoint.zero && nextFirstPoint == CGPoint.zero {
             yDiff = (prevLastPoint.y)
         } else if prevLastPoint == CGPoint.zero && nextFirstPoint != CGPoint.zero {
             yDiff = (nextFirstPoint.y)
         }
         
         return yDiff
     }
     
    static func getNewXEnds(entryPointMap:[ChartDataEntry:FunnelSlicePoint], index:Int, funnelChart:ChartViewBase) -> (CGFloat,CGFloat) {
         
         guard let dataSet = funnelChart.data?.dataSets[0] as? ChartDataSet
         else { return (0,0) }
         
         var x1:CGFloat = 0.0, x2:CGFloat = 0.0
         
         var prevLeftPoint:CGPoint = CGPoint.zero, prevRightPoint:CGPoint = CGPoint.zero
         var nextLeftPoint:CGPoint = CGPoint.zero, nextRightPoint:CGPoint = CGPoint.zero
         
         let prevIndex = getPrevValidIndex(currentIndex: index, funnelChart: funnelChart)
         
         if prevIndex != -1 {
             guard let prevEntry = dataSet.entryForIndex(prevIndex),
             let prevFunnelPoint = entryPointMap[prevEntry]
             else { return (0,0)}
             prevLeftPoint = (prevFunnelPoint.points[0])
             prevRightPoint = (prevFunnelPoint.points[1])
         }
         
         let nextIndex = getNextValidIndex(currentIndex: index, funnelChart: funnelChart)
         
         if nextIndex != -1 {
             guard let nextEntry = dataSet.entryForIndex(nextIndex),
             let nextFunnelPoint = entryPointMap[nextEntry]
             else { return (0,0)}
             nextLeftPoint = (nextFunnelPoint.points[3])
             nextRightPoint = (nextFunnelPoint.points[2])
             
             if nextFunnelPoint.points.count == 6 {
                 nextLeftPoint = (nextFunnelPoint.points[4])
                 nextRightPoint = (nextFunnelPoint.points[3])
             }
         }
         
         if prevLeftPoint != CGPoint.zero && nextLeftPoint != CGPoint.zero  && prevRightPoint != CGPoint.zero && nextRightPoint != CGPoint.zero {
             x1 = (prevLeftPoint.x + nextLeftPoint.x) / 2
             x2 = (prevRightPoint.x + nextRightPoint.x) / 2
         } else if prevLeftPoint == CGPoint.zero && prevRightPoint == CGPoint.zero && nextLeftPoint != CGPoint.zero && nextRightPoint != CGPoint.zero {
             x1 = nextLeftPoint.x
             x2 = nextRightPoint.x
         } else if prevLeftPoint != CGPoint.zero && prevRightPoint != CGPoint.zero && nextLeftPoint == CGPoint.zero && nextRightPoint == CGPoint.zero {
             x1 = prevLeftPoint.x
             x2 = prevRightPoint.x
         }
         
         return (x1,x2)
     }
     
    static func getPrevValidIndex(currentIndex:Int, funnelChart:ChartViewBase) -> Int
     {
        guard let dataSet = funnelChart.data?.dataSets[0] as? ChartDataSet
        else { return 0}
        
        var index = currentIndex
        var entry:ChartDataEntry? = nil
         
        var finalIndex:Int = -1
         
        repeat {
            index = index - 1
            entry = dataSet.entryForIndex(index)
        } while ((entry != nil && !(entry?.enabled)!))
         
        if entry != nil {
            finalIndex = index
        }
        return finalIndex
     }
     
     static func  getNextValidIndex(currentIndex:Int, funnelChart:ChartViewBase) -> Int
     {
         guard let dataSet = funnelChart.data?.dataSets[0] as? ChartDataSet
         else { return 0}
        
         var index = currentIndex
         var entry:ChartDataEntry? = nil
         
         var finalIndex:Int = -1
         
         repeat {
             index = index + 1
             entry = dataSet.entryForIndex(index)
         } while ((entry != nil && !(entry?.enabled)!))
         
         if entry != nil {
             finalIndex = index
         }
         
         return finalIndex
     }
     
     
     public static func getBezeirPath(cgPoints:[CGPoint]) -> CGMutablePath {
         
         var index = 0
         
         let path = CGMutablePath()
         
         for point in cgPoints {
             
             if index == 0 {
                 path.move(to: point)
             } else {
                 path.addLine(to: point)
             }
             index = index + 1
         }
         
        // path.close()
         
         return path
     }
     
     
     /////====================== ****************************** ====================== /////
     
    
    /// Funnel :- Animates Given Funnel Layer to After Filter Path
    public static func performFilterAnimationForOtherLayers(funnelChart: ChartViewBase, newOtherLayers:[FunnelLayer],entryToPointMap: [ChartDataEntry:FunnelSlicePoint], duration: TimeInterval){
        
        for layer in newOtherLayers {
            
            let funnelPoint = entryToPointMap[layer.getFunnelChartEntry()]
            
            if funnelPoint == nil {
                Log.info("Funnel Entry not available  \(layer.getFunnelChartEntry())")
                continue
            }
            
            let points = funnelPoint?.points
            
            if points?.count == 6 && layer.funnelSlicePoint?.points.count == 4 {
                
                var tempPoints:[CGPoint] = []
                
                guard let oldPoints = layer.funnelSlicePoint?.points
                else { continue }
                
                let point3X = (oldPoints[1].x + oldPoints[2].x ) / 2
                let point3y = (oldPoints[1].y + oldPoints[2].y ) / 2
                
                let point6X = (oldPoints[0].x + oldPoints[3].x ) / 2
                let point6y = (oldPoints[0].y + oldPoints[3].y ) / 2
                
                tempPoints.append(oldPoints[0])
                tempPoints.append(oldPoints[1])
                tempPoints.append(CGPoint(x: point3X, y: point3y))
                tempPoints.append(oldPoints[2])
                tempPoints.append(oldPoints[3])
                tempPoints.append(CGPoint(x: point6X, y: point6y))
                
                let updatePath = FunnelLayer.getBezeirPath(cgPoints: tempPoints)
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: updatePath, duration: 0)
                
                let completionBlock = {
                    funnelChart.interactionAnimationInProgress = false
                    funnelChart.setNeedsDisplay()
                }
                
                guard (points != nil)
                else { continue}
                let newPath = FunnelLayer.getBezeirPath(cgPoints: points!)
                
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: duration, completionBlock: completionBlock)
                
            } else if points?.count == 4 && layer.funnelSlicePoint?.points.count == 6 {
                
                guard let oldPoints = layer.funnelSlicePoint?.points,
                      (points != nil)
                else { continue }
                
                let updatePath = FunnelLayer.getBezeirPath(cgPoints: oldPoints)
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: updatePath, duration: 0)
                
                let completionBlock = {
                    funnelChart.interactionAnimationInProgress = false
                    funnelChart.setNeedsDisplay()
                }
                
                var finalPoints:[CGPoint] = []
                
                let point3X = (points![1].x + points![2].x ) / 2
                let point3y = (points![1].y + points![2].y ) / 2
                
                let point6X = (points![0].x + points![3].x ) / 2
                let point6y = (points![0].y + points![3].y ) / 2
                
                finalPoints.append(points![0])
                finalPoints.append(points![1])
                finalPoints.append(CGPoint(x: point3X, y: point3y))
                finalPoints.append(points![2])
                finalPoints.append(points![3])
                finalPoints.append(CGPoint(x: point6X, y: point6y))
                
                let newPath = FunnelLayer.getBezeirPath(cgPoints: finalPoints)

                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: duration, completionBlock: completionBlock)
            }
            else {
                
                let completionBlock = {
                    funnelChart.interactionAnimationInProgress = false
                    funnelChart.setNeedsDisplay()
                }
                
                guard (points != nil)
                else { continue }
                let newPath = FunnelLayer.getBezeirPath(cgPoints: points!)
                
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: duration, completionBlock: completionBlock)
            }
            
        }
        
    }
    
    /// Funnel :- Animates Given Funnel Text Layers to After Filter Path
    public static func performFilterAnimationForTextLayers(funnelChart: ChartViewBase, newOtherLayers:[FunnelLayer],entryToPointMap: [ChartDataEntry:FunnelSlicePoint], duration: TimeInterval){
        
        let entryIndexFunnelValueLayerMap = FunnelLayer.getFunnelValueLayerMap(chart: funnelChart)
        
        for layer in newOtherLayers {
            
            let entryIndex = layer.getEntryIndex()
            
            let textLayer = entryIndexFunnelValueLayerMap[entryIndex]
            
            if textLayer == nil {
                continue
            }
            
            let funnelPoint = entryToPointMap[layer.getFunnelChartEntry()]
            
            if funnelPoint == nil {
                Log.info("Funnel Entry not available \(layer.getFunnelChartEntry())")
                continue
            }
            
            
            guard (funnelPoint != nil),
                  (textLayer != nil)
            else { continue }
            let position = FunnelChartRenderer.getCenterPoint(funnelSlicePoint: funnelPoint!)
            
            CommonHelperFunctions.performPositionAnim(textLayer: textLayer!, position: position, duration: duration, completionBlock: nil)
            
        }
        
    }
    
    /// Funnel :- Updates Funnel Layer Path with Given Points
    static func updateFunnelLayerWithNewPoints(funnelLayer:FunnelLayer, cgPoints:[CGPoint]){
        
        let newPath = FunnelLayer.getBezeirPath(cgPoints: cgPoints)
        
        funnelLayer.path = newPath//newPath.cgPath
        
        funnelLayer.opacity = 1
    }
    

}
