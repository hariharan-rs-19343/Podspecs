//
//  ChartInteractionHelperFunction.swift
//  zchart
//
//  Created by Aravinth T on 11/01/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation

open class ChartInteractionHelperFunction
{
    // MARK: - Filter Methods
    // MARK: Line Filter
    public static func removeOrdinalEntry(lineChart:ChartViewBase, entry:ChartDataEntry, duration:TimeInterval) {
        
        guard let lineRenderer = (CommonHelperFunctions.getRenderer(chart: lineChart, types: [.Line]) as? LineChartRenderer),
            let lineData = lineChart.data,
            let lineDataSets = lineData.dataSets as? [ChartDataSet],
            let linePlotOptions = lineChart.getPlotOptions(type: .Line) as? LinePlotOptions
            else {
                lineChart.setNeedsDisplay()
                return
            }
        
        let axisChartBase = lineChart
        let xToRemove =  entry.x
        
        var yValue:[Double] = []
        var xOffset:[Double] = []

        for dataSet in lineDataSets
        {
            let nextEntry = CommonHelperFunctions.getNextGreaterXEntry(set: dataSet, xValue: entry.x, includeYNan: false, chart: lineChart)
            let prevEntry = CommonHelperFunctions.getPrevLesserXEntry(set: dataSet, xValue: entry.x, includeYNan: false, chart: lineChart)
             
             if nextEntry == nil && prevEntry == nil {
                 continue
             }
                
            if nextEntry != nil && prevEntry != nil {
                yValue.append((nextEntry!.y + prevEntry!.y)/2)
                xOffset.append(-0.5)

            } else if nextEntry != nil {
                yValue.append(nextEntry!.y)
                xOffset.append(0)
            }
            else if prevEntry != nil {
                yValue.append(prevEntry!.y)
                xOffset.append(-1)
            }
        }
        
        if yValue.count == 0 && xOffset.count == 0
        {
            axisChartBase.setNeedsDisplay()
            return
        }
        
        
        var alteredEntries:[[ChartDataEntry]] = []
        var newEntries:[[ChartDataEntry]] = []
    
        var removedEntries:[ChartDataEntry] = []
        
        for set in lineDataSets
        {
            var setEntries:[ChartDataEntry] = []
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i),
                      let finalEntry = entry.copy() as? ChartDataEntry
                else { continue }
                
                
                if finalEntry.x == xToRemove {
                    removedEntries.append(entry)
                    continue
                }
                if finalEntry.x > xToRemove
                {
                    finalEntry.x = finalEntry.x - 1
                }
                setEntries.append(finalEntry)
            }
            newEntries.append(setEntries)
        }
        
        var setIndex = -1
        
        for set in lineDataSets
        {
            var setEntries:[ChartDataEntry] = []
            
            setIndex += 1
            
            let yValue = yValue[setIndex]
            let xOffset = xOffset[setIndex]
            
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                if entry.x == xToRemove
                {
                    entry.filterEnabled = true
                    entry.barYValue = CGFloat(yValue - entry.y )
                    entry.x +=  xOffset
                }
                if entry.x > xToRemove
                {
                    entry.x = entry.x - 1
                }
                
                setEntries.append(entry)
            }
            alteredEntries.append(setEntries)
        }

        ChartInteractionHelperFunction.resetDataWithGivenXY(newEntries: alteredEntries, chart: axisChartBase)
        
        let completionBlock =
        { [unowned axisChartBase] in
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
           
            if !(CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase))
            {
                axisChartBase.setNeedsDisplay()
            }
           
            axisChartBase.interactionAnimationInProgress = false
           
            axisChartBase.delegateToContainer?.chartValueRemoved?(axisChartBase, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
        }
        
        setIndex = -1
        
        for dataSet in lineDataSets
        {
            guard let lineLayer = LineLayer.getLayerForDataset(chart: axisChartBase, lineChartDataSet: dataSet),
                    let dataOptions = dataSet.dataSetOptions as? LineDataSetOptions
                else { continue }
            
            setIndex += 1
            let xOffset = xOffset[setIndex]
            
            let newPath:(CGPath,CGPath)
            
            switch dataOptions.mode
            {
                case .linear: fallthrough
                case .stepped:
                    if linePlotOptions.isStacked
                    {
                        newPath = LineHelperFunctions.getLinearStackedPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                    }
                    else
                    {
                        let _xBounds = lineRenderer._xBounds
                        
//                      _xBounds.set(chart: lineRenderer.dataProvider!, dataSet: dataSet, animator: animator)
                        
                        newPath = LineHelperFunctions.getLinearPathWithNAN(barLineChart: axisChartBase, fromIndex:_xBounds.min, toIndex:_xBounds.range + _xBounds.min, dataSet: dataSet  , animator: nil, lineRenderer: lineRenderer)

                    }
                    
                case .cubicBezier:
                    if linePlotOptions.isStacked
                    {
                        newPath = LineHelperFunctions.getCubicStackedDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                    }
                    else{
                        newPath = LineHelperFunctions.getCubicDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                    }
                
                case .horizontalBezier:
                    newPath = LineHelperFunctions.getLinearPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet  , animator: nil, lineRenderer: lineRenderer)
                
                case .montonic:
                    if linePlotOptions.isStacked
                    {
                        newPath = LineHelperFunctions.getMonotoneStackedDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                    }
                    else
                    {
                        newPath = LineHelperFunctions.getMonotoneDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                    }
                
            }

//            CommonHelperFunctions.performPathAnim(targetLayer: lineLayer, newPath: UIBezierPath(cgPath: newPath.0), duration: duration, completionBlock: nil)
            CommonHelperFunctions.performPathAnim(targetLayer: lineLayer, newPath: newPath.0 as! CGMutablePath, duration: duration, completionBlock: nil)
            
            for i in stride(from: lineRenderer._xBounds.min, through: lineRenderer._xBounds.range + lineRenderer._xBounds.min, by: 1)
            {
                guard let markEntry = dataSet.entryForIndex(i) else { continue }

                guard let markLayer = lineLayer.getMarkerLayerforEntryIndex(entryIndex: i) else { continue }
                
                if removedEntries.contains(markEntry)
                {
                    markLayer.opacity = 0
                    continue
                }

                let point  = lineChart.pixelForValues(x: markEntry.x, y: markEntry.y, axisIndex: dataSet.axisIndex)

                let path = ShapeFactory.getPath(point: point, shapeInstance: dataOptions.markerInstance)

                CATransaction.begin()

                let anim = CABasicAnimation(keyPath: "path")

                anim.fromValue = markLayer.path

                anim.toValue = path

                anim.duration = 2.0

                anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)

                markLayer.add(anim, forKey: "path")

                CATransaction.commit()

                markLayer.path = path
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(1000 * duration)), execute: {
            completionBlock()
        })

    }
    
    // MARK: Scatter,Bubble Inclusion/Exclusion Helper Function
    
     static func callResizeAxis(axisChartBase:ChartViewBase) {
        if !(CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase))
        {
            axisChartBase.notifyDataSetChanged(redrawRequired: true)
        }
    }
    
     static func resetEntriesAndNotifyData(axisChartBase:ChartViewBase,newEntries:[[ChartDataEntry]]) {
        
        axisChartBase.xAxis.longestLabel = ""
         
         guard let setCount = (axisChartBase.data?.dataSetCount)
         else { return }
        
        for i in 0..<setCount
         {
             guard let set = axisChartBase.data?._dataSets[i] as? ChartDataSet
            else { continue }
             
             set.clear()
             
             set._values = newEntries[i]
             
             set.calcMinMax()
         }
         
         axisChartBase.data?.updateXYValues()
        
        axisChartBase.data?.notifyDataChanged()
    }
    
     static func calculateCurrentDataAndSetOldMinMax(axisChartBase:ChartViewBase) {
        
         guard let sets = axisChartBase.data?.dataSets
         else { return }
        var visibleUniqueIndices = Set<Int>()
        for dataSet in sets where dataSet.visible {
                visibleUniqueIndices.insert(dataSet.axisIndex)
        }
                
        var oldAxisIndexToMinMax:[Int:(Double,Double)] = [:]
        
        for axisIndex in visibleUniqueIndices {
            guard let yAxis = axisChartBase.getYAxis(atIndex: axisIndex)
            else { continue }
            oldAxisIndexToMinMax[axisIndex] = (yAxis.axisMinimum,yAxis.axisMaximum)
        }
        
        axisChartBase.notifyDataSetChanged(redrawRequired: false)
        
        for axisIndex in visibleUniqueIndices {
            guard let yAxis = axisChartBase.getYAxis(atIndex: axisIndex),
            let (oldMin,oldMax) = oldAxisIndexToMinMax[axisIndex]
            else { continue }
//            yAxis.axisMinimum = oldMin
//            yAxis.axisMaximum = oldMax
            yAxis.setAxis(minimum: oldMin)
            yAxis.setAxis(maximum: oldMax)
        }
                
        /*if !(axisChartBase.resizeAxisIfNeeded()) //RESIZE AXIS BEFORE ANIMATION OF NEW ENTRIES
        {
            axisChartBase.calculateCurrentData()
            axisChartBase.setNeedsDisplay()
        }*/
    }
    
    //================================= SCATTER/BUBBLE ENTRY REMOVE FUNCTION START HERE =============================//
    
    // MARK: Scatter/Bubble Filter
    
    public static func removeScatterBubbleEntry(axisChartBase:ChartViewBase, chartEntry:ChartDataEntry, type:ChartType) {
        
        axisChartBase.updateDataOrigIndex()
        
        let executionBlock = { [unowned axisChartBase] in
//            ChartInteractionHelperFunction.alignScatterBubble(axisChartBase: axisChartBase, chartEntry: chartEntry, type: type)
            axisChartBase.interactionAnimationInProgress = true
            ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: chartEntry, chart: axisChartBase, duration: 0.5)
        }
        
        CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:chartEntry.x,y: chartEntry.y, duration: 0.5, executionBlock: executionBlock, alignCenter: true, chart: axisChartBase)
        
    }
    
    // MARK: - Inclusion Methods - Scatter,Bubble and Line
    
    /*public static func chartEntryEnabled(axisChartBase: ChartViewBase, entry: [ChartDataEntry]?,duration:TimeInterval,type: ChartType) {
        
        guard let entry = entry
            else {  return  }
        
        var chartEntry = entry[0]
        
        // Entry with No Nan in X
        for entryWithoutNan in entry where !(entryWithoutNan.x.isNaN) && (entryWithoutNan.x != Double.leastNormalMagnitude)
        {
            chartEntry = entryWithoutNan
            break
        }
        
        let setIndex = getSetIndex(axisChartBase: axisChartBase,chartEntry: chartEntry)
        
        let set = (axisChartBase.data?.dataSets[setIndex])!
        
        let isLinear = axisChartBase.xAxis.scaleType != .Ordinal
        
        var newXIndex = chartEntry.x
        
        if !isLinear
        {
            newXIndex = getNewXPositionToInsertForEntry(axisChartBase: axisChartBase, chartEntry: chartEntry, dataset: set)
        }
        
        let barTypes = [ChartType.Bar, ChartType.HorizontalBar, ChartType.Bullet, ChartType.HorizontalBullet]
        //After sorting, entry index is based on entry Y value
        if let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: axisChartBase, types: barTypes) as? BarPlotOptions
        {
            if barPlotOptions.sortInteractionCalled
            {
                newXIndex = BarHelperFunctions.getNewIndexInCaseOfSortedEntries(entry: chartEntry, chart: axisChartBase)
            }
        }
        
        guard  newXIndex != -1 else {
            return
        }
        
        var executionBlock:(() -> Void)? = nil
        
        for dataEntry in entry {
            dataEntry.x = Double(newXIndex)
        }
     
        executionBlock = {
            for dataEntry in entry {
                dataEntry.filterEnabled = false
            }
            
            if true //axisChartBase.isCombined
            {
                includeEntriesAtXWithAnimations(entries: entry, newXPosition: newXIndex, duration: duration, chart: axisChartBase)
                return
            }
            
            if type == .Line
            {
//                includeLineOrdinalEntry(axisChartBase: axisChartBase, chartEntry: entry, newXPosition: newXIndex, duration: duration)
                LineHelperFunctions.includeLineEntry(entries: entry, newXPosition: newXIndex, duration: duration, chart: axisChartBase)
                return
            }
            
            if isLinear
            {
                includeScatterBubbleLinear(axisChartBase: axisChartBase, chartEntry: entry , newXPosition: newXIndex,duration: duration, type: type)
            }
            else{
                includeScatterBubble(axisChartBase: axisChartBase, chartEntry: entry , newXPosition: newXIndex,duration: duration, type: type)
            }
            
        }
        
        var diff:Double = 0
        if (axisChartBase.xAxis.scaleType == .Ordinal && axisChartBase.xAxis.inverted) {
            diff = 1
        }
        CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:(newXIndex - diff), y:0, duration:0.5, executionBlock: executionBlock, alignCenter: true, chart: axisChartBase)
    }*/
    
    public static func chartEntriesEnabled(axisChartBase: ChartViewBase, entries: [ChartDataEntry]?,duration:TimeInterval) {
            
            guard let entries = entries
                else {  return  }
            
            var chartEntry = entries[0]
            
            // Entry with No Nan in X
            for entryWithoutNan in entries where !(entryWithoutNan.x.isNaN) && (entryWithoutNan.x != Double.leastNormalMagnitude)
            {
                chartEntry = entryWithoutNan
                break
            }
            
            let setIndex = getSetIndex(axisChartBase: axisChartBase,chartEntry: chartEntry)
            
            guard let set = (axisChartBase.data?.dataSets[setIndex])
            else { return }
            
            let isLinear = axisChartBase.xAxis.scaleType != .Ordinal
            
            var newXIndex = chartEntry.x
            
            if !isLinear
            {
                newXIndex = getNewXPositionToInsertForEntry(axisChartBase: axisChartBase, chartEntry: chartEntry, dataset: set)
            }
            
        let barTypes = [ChartType.Bar, ChartType.Bullet, ChartType.WaterFall]
            //After sorting, entry index is based on entry Y value
            if let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: axisChartBase, types: barTypes) as? BarPlotOptions
            {
                if barPlotOptions.sortInteractionCalled
                {
                    newXIndex = BarHelperFunctions.getNewIndexInCaseOfSortedEntries(entry: chartEntry, chart: axisChartBase)
                }
            }
            
            guard  newXIndex != -1 else {
                return
            }
            
            var executionBlock:(() -> Void)? = nil
            
            for dataEntry in entries {
//                dataEntry.x = Double(newXIndex)
            }
         
            executionBlock = { [unowned axisChartBase,entries] in
                
                for dataEntry in entries {
                    dataEntry.filterEnabled = false
                }
                
                axisChartBase.interactionAnimationInProgress = true
                
                includeEntriesWithAnimations(entries: entries, newXPosition: newXIndex, duration: duration, chart: axisChartBase)
            }
            
            var diff:Double = 0
        
            if (axisChartBase.xAxis.scaleType == .Ordinal && axisChartBase.xAxis.inverted) {
                diff = 1
            }
        
            CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:(newXIndex - diff), y:0, duration:0.5, executionBlock: executionBlock, alignCenter: true, chart: axisChartBase)
        
        }
    
    // MARK: Scatter,Bubble Inclusion
    
    public static func alignScatterBubble(axisChartBase:ChartViewBase, chartEntry:ChartDataEntry, type:ChartType)
    {
        let completionBlock:(() -> Void)? =
        {
            guard let plotOption = axisChartBase.getPlotOptions() as? AxisChartPlotOptions
                else { return }
            
            axisChartBase.lastSelected = nil
            plotOption.barGroupSelectionEnabled = false
            
            axisChartBase.callDelegateToContainer(highlight: nil, entry: nil)
            
            let xToRemove =  chartEntry.x
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            guard let sets = (axisChartBase.data?._dataSets)
                else { return }
            
            for set in sets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    
                    guard let entry = set.entryForIndex(i)
                    else { continue }
                    
                    if entry.x == xToRemove
                    {
                        entry.filterEnabled = true
                    }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            
            
            for set in sets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i),
                          let finalEntry = entry.copy() as? ChartDataEntry
                    else { continue }
                    
                    
                    if (finalEntry.x == Double.leastNormalMagnitude && finalEntry.origX == chartEntry.origX) || finalEntry.x == xToRemove
                    {
                        continue
                    }
                    if finalEntry.x != Double.leastNormalMagnitude && finalEntry.x > xToRemove
                    {
                        finalEntry.x = Double(finalEntry.x-1)
                    }
                    
                    
                    setEntries.append(finalEntry)
                }
                newEntries.append(setEntries)
            }
            
            
            var oldPoints:[[CGPoint]]
            
            var newPoints:[[CGPoint]]
            
            oldPoints = getScatterPoints(chart: axisChartBase)
            
            
            // reset dataset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
            
            
            newPoints = getScatterPoints(chart: axisChartBase)
            
            
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: axisChartBase)
            
            
            
            var xInterpolateArray:[[((Double) -> Double)]] = []
            
            
            for dataSetIndex in 0..<sets.count
            {
                guard let set = axisChartBase.data?._dataSets[dataSetIndex] as? ChartDataSet
                else { continue }
                
                if !(set.isVisible)
                {
                    xInterpolateArray.append([((Double) -> Double)]())
                    continue
                }
                
                var setEntriesXInterpolator:[((Double) -> Double)] = []
                
                var entryIndex = -1
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let entry =  set.entryForIndex(index)
                    else { continue }
                    
                    if entry.x == xToRemove
                    {
                        continue
                    }
                    
                    entryIndex += 1
                    
                    var oldX:CGFloat
                    let newX:CGFloat
                    
                    oldX = oldPoints[dataSetIndex][index].x
                    
                    
                    if entry.x < xToRemove{
                        newX = newPoints[dataSetIndex][entryIndex].x
                    }
                    else{
                        newX = newPoints[dataSetIndex][entryIndex].x
                    }
                    
                    
                    let xDiff = Interpolator.interpolate(a: Double(oldX), b: (Double(newX)))
                    
                    setEntriesXInterpolator.append(xDiff)
                }
                
                xInterpolateArray.append(setEntriesXInterpolator)
            }
            
            var sliceAnimator:Animator! = Animator()
            
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                setEntryDeleted(axisChartBase: axisChartBase, entryDeleted: true, type: type)
                
                var interpolatorIndex:Int = 0
                
                for dataSetIndex in 0..<sets.count
                {
                    guard let set = axisChartBase.data?._dataSets[dataSetIndex] as? ChartDataSet
                    else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        guard let entry = set.entryForIndex(index)
                        else { continue }
                        
                        if entry.x == xToRemove
                        {
                            continue
                        }
                        
                        let newEntry = oldEntries[dataSetIndex][index]
                        
                        let oldCenter = oldPoints[dataSetIndex][index]
                        
                        var newCenter = CGPoint(x: oldCenter.x, y: oldCenter.y)
                        
                        let newVal = xInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                        
                        interpolatorIndex = interpolatorIndex + 1
                        
                        newCenter.x = CGFloat(newVal)
                        
                        newEntry.centerChanged = newCenter
                        
                    }
                }
                
                axisChartBase.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                setEntryDeleted(axisChartBase: axisChartBase, entryDeleted: false, type: type)
                
                sliceAnimator = nil
                
                //                s.data?.setDrawValues(true)
//                axisChartBase.enableDrawValues()
                axisChartBase.interactionAnimationInProgress = false
                
                axisChartBase.setNeedsDisplay()
                
                var removedEntries:[ChartDataEntry] = []
                
                /*for set in (axisChartBase.data?._dataSets)!
                {
                    for entryToRemove in (set.entriesForXValue(xToRemove))
                    {
                        removedEntries.append(entryToRemove)
                    }
                }*/
                
                for set in sets
                {
                    guard let castedSet = set as? ChartDataSet
                    else { continue }
                    for entryToRemove in  castedSet.values where entryToRemove.origX == chartEntry.origX
                    {
                        removedEntries.append(entryToRemove)
                    }
                }
                
                resetEntriesAndNotifyData(axisChartBase: axisChartBase, newEntries: newEntries)
                
                callResizeAxis(axisChartBase: axisChartBase)
                
                /*CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
                
                
                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)
                
                axisChartBase.data?.updateXYValues()
                
                for set in (axisChartBase.data?._dataSets)!
                {
                    set.calcMinMax()
                }
                
                axisChartBase.data?.notifyDataChanged()
                
                axisChartBase.notifyDataSetChanged(redrawRequired: true)
                
                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)*/
                
                axisChartBase.delegateToContainer?.chartValueRemoved?(axisChartBase, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
            }
            
            sliceAnimator.animate(xAxisDuration: 0.5, easingOption: .linear)
            
        }
        
        let isLinear = axisChartBase.xAxis.scaleType != .Ordinal
        
        if isLinear
        {
            alignScatterBubbleForLinear(axisChartBase:axisChartBase, chartEntry: chartEntry)
        }
        else{
            completionBlock!()
        }
        
    }
    
    fileprivate static func alignScatterBubbleForLinear(axisChartBase:ChartViewBase,chartEntry:ChartDataEntry)
    {
        let completionBlock:(() -> Void)? =
        {
            guard let plotOption = axisChartBase.getPlotOptions() as? AxisChartPlotOptions
            else { return }
            
            axisChartBase.lastSelected = nil
            plotOption.barGroupSelectionEnabled = false
            
            axisChartBase.callDelegateToContainer(highlight: nil, entry: nil)
            
            let xToRemove =  chartEntry.x
            
            var newEntries:[[ChartDataEntry]] = []
            
            guard let sets = (axisChartBase.data?._dataSets)
            else { return }
            
            for set in sets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i),
                          let finalEntry = entry.copy() as? ChartDataEntry
                    else { continue }
                    
                    
                    if finalEntry.x == xToRemove
                    {
                        continue
                    }
                    
                    setEntries.append(finalEntry)
                }
                newEntries.append(setEntries)
            }
            
            
            axisChartBase.setNeedsDisplay()
            
            var removedEntries:[ChartDataEntry] = []
            
            for set in sets
            {
                for entryToRemove in (set.entriesForXValue(xToRemove))
                {
                    removedEntries.append(entryToRemove)
                }
            }
            
            resetEntriesAndNotifyData(axisChartBase: axisChartBase, newEntries: newEntries)
                      
            callResizeAxis(axisChartBase: axisChartBase)
            
    /*        CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
            
            
            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)
            
            axisChartBase.data?.updateXYValues()
            
            for set in (axisChartBase.data?._dataSets)!
            {
                set.calcMinMax()
            }
            
            axisChartBase.data?.notifyDataChanged()
            
            axisChartBase.notifyDataSetChanged(redrawRequired: true)
            
            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)*/
            
            axisChartBase.interactionAnimationInProgress = false
            
            axisChartBase.delegateToContainer?.chartValueRemoved?(axisChartBase, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
            
        }
        
        completionBlock!()
        
    }
    
    // MARK: Line Inclusion
    
    public static func includeLineOrdinalEntry(axisChartBase:ChartViewBase, chartEntry:[ChartDataEntry], newXPosition:Double, duration:TimeInterval) {
        
        guard let lineRenderer =  CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [.Line]) as? LineChartRenderer,
            let lineData = axisChartBase.data,
            let lineDataSets = axisChartBase.data?.dataSets as? [ChartDataSet] else {
            axisChartBase.setNeedsDisplay()
            return
        }
    
        let xToAdd = chartEntry[0].x
    
        var xOffset:[Double] = []

        for dataSet in lineDataSets
        {
            let nextEntry = CommonHelperFunctions.getNextGreaterXEntry(set: dataSet, xValue: xToAdd, includeYNan: false, chart: axisChartBase)
            let prevEntry = CommonHelperFunctions.getPrevLesserXEntry(set: dataSet, xValue: xToAdd, includeYNan: false, chart: axisChartBase)
           
            if nextEntry == nil && prevEntry == nil {
                continue
            }
                
            if nextEntry != nil && prevEntry != nil {
                xOffset.append(-0.5)

            } else if nextEntry != nil {
                xOffset.append(0)
            }
            else if prevEntry != nil {
                xOffset.append(-1)
            }
        }
          
        if xOffset.count == 0
        {
            axisChartBase.setNeedsDisplay()
            return
        }
    
        guard let eOrigX = chartEntry[0].origX
        else { return }
        let xIndexDict = axisChartBase.originalMap[eOrigX]
        
        var alteredEntries:[[ChartDataEntry]] = []
        var newEntries:[[ChartDataEntry]] = []
    
        // To track index to includeEntry
        var trackIndex:Int = 0
        
        guard let setsCount = (axisChartBase.data?._dataSets.count)
        else{ return }
        
        for setIndex in 0..<setsCount
        {
            guard let set = (axisChartBase.data?.dataSets[setIndex])
            else { continue }
            var setEntries:[ChartDataEntry] = []
            var entryToAddCount = 0
            
            if xIndexDict?[setIndex] != nil
            {
                entryToAddCount = (xIndexDict![setIndex]?.count)!
            }
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                while  entryToAddCount > 0 && (entry.origIndex) != nil && (chartEntry[trackIndex].origIndex) != nil && (entry.origIndex)! > (chartEntry[trackIndex].origIndex)!
                {
                    setEntries.append(chartEntry[trackIndex])
                    trackIndex += 1
                    entryToAddCount -= 1
                }
                
                guard let finalEntry = entry.copy() as? ChartDataEntry
                else { continue }
                
                if entry.x >= newXPosition
                {
                    finalEntry.x = Double(entry.x+1)
                }
                
                setEntries.append(finalEntry)
            }
            
            while entryToAddCount > 0
            {
                setEntries.append(chartEntry[trackIndex])
                trackIndex += 1
                entryToAddCount -= 1
            }
            
            newEntries.append(setEntries)
        }
    
        var setIndex = -1
        
        guard let sets = (axisChartBase.data?.dataSets)
        else { return }
    
        for set in sets
        {
            var setEntries:[ChartDataEntry] = []
            var prevYValue:Double = 0
            
            setIndex += 1
            
            let xOffset = xOffset[setIndex]
            
            var flag = true
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                if entry.x == newXPosition && flag
                {
                    flag = false
                    
                    var entryToAddCount = 0
                    
                    if xIndexDict?[setIndex] != nil
                    {
                        entryToAddCount = (xIndexDict![setIndex]?.count)!
                    }
                    
                    for _ in 0..<entryToAddCount
                    {
                        guard let finalEntry = entry.copy() as? ChartDataEntry
                        else { continue }
                        finalEntry.x = entry.x + xOffset
                        finalEntry.y = prevYValue == 0 ? entry.y : (prevYValue + entry.y)/2

                        setEntries.append(finalEntry)
                    }
                }
                
                prevYValue = entry.y
                setEntries.append(entry)
            }
            alteredEntries.append(setEntries)
        }

        resetDataWithGivenXY(newEntries: alteredEntries, chart: axisChartBase)
    
        let completionBlock =
        {
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
            
            if !(CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase))
            {
                axisChartBase.setNeedsDisplay()
            }
            
            axisChartBase.interactionAnimationInProgress = false
            
            axisChartBase.delegateToContainer?.chartValueAdded?(chartView: axisChartBase, entries: chartEntry, dataSets: nil, dataSetAdded: false)
        }
    
        var fromPath:[(CGPath,CGPath)] = []
        var newPath:[(CGPath,CGPath)] = []
    
        for dataSet in lineDataSets
        {
            guard LineLayer.getLayerForDataset(chart: axisChartBase, lineChartDataSet: dataSet) != nil
                else { continue }
            
            fromPath.append(getLinePathForDatasetMode(axisChartBase: axisChartBase, lineRenderer: lineRenderer, dataSet: dataSet, lineData: lineData))
        }
    
        resetDataWithGivenXY(newEntries: newEntries, chart: axisChartBase)
    
        for dataSet in lineDataSets
        {
            guard LineLayer.getLayerForDataset(chart: axisChartBase, lineChartDataSet: dataSet) != nil
                else { continue }
            
            newPath.append(getLinePathForDatasetMode(axisChartBase: axisChartBase, lineRenderer: lineRenderer, dataSet: dataSet, lineData: lineData))
        }
    
        var pathIndex = -1
           
        for dataSet in lineDataSets
        {
            guard let lineLayer = LineLayer.getLayerForDataset(chart: axisChartBase, lineChartDataSet: dataSet),
                let dataOptions = dataSet.dataSetOptions as? LineDataSetOptions
                else { continue }
            pathIndex += 1
            
            lineLayer.path = fromPath[pathIndex].0
            
//            CommonHelperFunctions.performPathAnim(targetLayer: lineLayer, newPath: UIBezierPath(cgPath: newPath[pathIndex].0), duration: duration, completionBlock: nil)
            CommonHelperFunctions.performPathAnim(targetLayer: lineLayer, newPath: newPath[pathIndex].0 as! CGMutablePath, duration: duration, completionBlock: nil)
            
            
            var flag = 0
            for i in 0 ..< dataSet.entryCount {

                    guard let markEntry = dataSet.entryForIndex(i)
                    else { continue }

                    let markLayer = lineLayer.getMarkerLayerforEntryIndex(entryIndex: i+flag)

                    if markEntry.x == (newXPosition )
                    {
                       // markLayer?.opacity = 0
                        flag = -1
                        continue
                    }

                    if markLayer == nil {
                        continue
                    }

                    let point  = axisChartBase.pixelForValues(x: markEntry.x, y: markEntry.y, axisIndex: dataSet.axisIndex)

                    let path = ShapeFactory.getPath(point: point, shapeInstance: dataOptions.markerInstance)

                    CATransaction.begin()

                    let anim = CABasicAnimation(keyPath: "path")

                    anim.fromValue = markLayer!.path

                    anim.toValue = path

                    anim.duration = duration

                    anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)

                    markLayer!.add(anim, forKey: "path")

                    CATransaction.commit()

                    markLayer!.path = path
                }
        }
    
        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(1000 * duration)), execute: {
            completionBlock()
        })

    }
    
    fileprivate static func setEntryDeleted(axisChartBase: ChartViewBase, entryDeleted:Bool, type:ChartType) {
        
        if type == .Scatter
        {
            guard let renderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [.Scatter]) as? ScatterChartRenderer
            else { return }
            
            renderer.entryDeleted = entryDeleted
        }
        
        if type == . Bubble || type == .BubblePie
        {
            guard let renderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [.Bubble]) as? BubbleChartRenderer
            else { return }
            
            renderer.entryDeleted = entryDeleted
        }
        
    }
    
    public static func getScatterPoints(chart:ChartViewBase) -> [[CGPoint]]
    {
        var scatterPoints:[[CGPoint]] = []
        
        guard let sets = (chart.data?._dataSets)
        else { return  scatterPoints}
        for set in sets
        {
            var setEntries:[CGPoint] = []
            
            if !(set.isVisible)
            {
                scatterPoints.append(setEntries)
                continue
            }
            
            let valueToPixel = chart.getTransformer(axisIndex: set.axisIndex).valueToPixelMatrix
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                var point = CGPoint(x: entry.x, y: entry.y)
                point = point.applying(valueToPixel)
                
                setEntries.append(point)
            }
            scatterPoints.append(setEntries)
        }
        
        return scatterPoints
    }
    
    public static func prepareBarRectArrayforAllDataset(barChart:ChartViewBase) -> [[CGRect]]
    {
        var tempDatasetArray:[[CGRect]] = []
        
        guard let sets = (barChart.data?._dataSets)
        else { return  tempDatasetArray}
        for dataset in sets
        {
            if !(dataset.isVisible)
            {
                tempDatasetArray.append([CGRect]())
                continue
            }
            
            var datasetEntries:[ChartDataEntry] = []
            
            for i in 0..<(dataset.entryCount)
            {
                guard let entry = (dataset.entryForIndex(i))
                else { continue }
                datasetEntries.append(entry)
                
            }
            
            let barPositionArray:[CGRect]
            
            if barChart.isRotated
            {
                barPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: datasetEntries, animator: ((barChart)._animator), dataSet: dataset, chart: barChart)
            }
            else{
                barPositionArray = BarChartRenderer.getBarRectArray(entries: datasetEntries, animator: ((barChart)._animator), dataSet: dataset, chart: barChart)
            }
            
            
            tempDatasetArray.append(barPositionArray)
        }
        
        return tempDatasetArray
    }
    
    public static func prepareRectArrayforAllDataset(chart:ChartViewBase) -> [[CGRect]]
    {
        var tempDatasetArray:[[CGRect]] = []
        
        guard let sets = (chart.data?._dataSets)
        else { return tempDatasetArray}
        
        for dataset in sets
        {
            if !(dataset.isVisible)
            {
                tempDatasetArray.append([CGRect]())
                continue
            }
            
            switch dataset.plotType
            {
            case .Bar, .BoxPlot, .Mekko:
                    tempDatasetArray.append(BarHelperFunctions.prepareDataSetArray(selectedDataset: dataset, chart: chart))
                
            case .Line, .Scatter, .Bubble, .BubblePie, .Radar, .LineRange, .Area:
                    tempDatasetArray.append(LineHelperFunctions.prepareDataSetArray(selectedDataset: dataset, chart: chart))
                
            case .WaterFall:
                tempDatasetArray.append(WaterFallHelperFunction.prepareDataSetArray(selectedDataset: dataset, chart: chart))
                
                default:
                    break
            }
        }
        
        return tempDatasetArray
    }

    //================================= SCATTER/BUBBLE ENTRY REMOVE FUNCTION ENDS HERE =============================//
    
    //================================= SCATTER/BUBBLE ENTRY INCLUDE FUNCTION START HERE =============================//
    
    
    
    public static func resetDataWithGivenXY(newEntries:[[ChartDataEntry]],chart:ChartViewBase)
    {
        guard let setsCount = (chart.data?.dataSetCount)
        else { return }
        
            for i in 0..<setsCount
            {
                guard let set = chart.data?._dataSets[i] as? ChartDataSet
                else { continue }
                
                set.clear()
                
                set._values = newEntries[i]
                
                set.calcMinMax()
            }
            
    //        chart.data?.updateXYValues()
            
             chart.data?.notifyDataChanged()
             
             chart.notifyDataSetChanged(redrawRequired: false)
    }
    
    public static func getLinePathForDatasetMode(axisChartBase:ChartViewBase, lineRenderer:LineChartRenderer, dataSet:ChartDataSet, lineData:ChartData) -> (CGPath,CGPath)
    {
        let newPath:(CGPath,CGPath)
        
        guard let linePlotOptions = axisChartBase.getPlotOptions(type: dataSet.plotType) as? LinePlotOptions,
            let dataOptions = dataSet.dataSetOptions as? LineDataSetOptions
//            else { return (UIBezierPath().cgPath,UIBezierPath().cgPath) }
            else { return (CGMutablePath(),CGMutablePath()) }
        
        switch dataOptions.mode
        {
            case .linear: fallthrough
            case .stepped:
                if linePlotOptions.isStacked
                {
                    newPath = LineHelperFunctions.getLinearStackedPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                }
                else
                {
                    newPath = LineHelperFunctions.getLinearPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet  , animator: nil, lineRenderer: lineRenderer)
                }
                
            case .cubicBezier:
                if linePlotOptions.isStacked
                {
                    newPath = LineHelperFunctions.getCubicStackedDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                }
                else{
                    newPath = LineHelperFunctions.getCubicDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                }
            
            case .horizontalBezier:
                newPath = LineHelperFunctions.getLinearPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet  , animator: nil, lineRenderer: lineRenderer)
            case .montonic:
                if linePlotOptions.isStacked
                {
                    newPath = LineHelperFunctions.getMonotoneStackedDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                }
                else{
                    newPath = LineHelperFunctions.getMonotoneDataSetPathWithNAN(barLineChart: axisChartBase, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                }
        }
        
        return newPath
    }
    
    public static func getSetIndex(axisChartBase: ChartViewBase, chartEntry:ChartDataEntry) -> Int
    {
        var setIndex = 0
        
        guard let eOrigX = chartEntry.origX,
              let dict = axisChartBase.originalMap[eOrigX]
        else { return setIndex }
        
        
        
        for innerDict in (dict.sorted(by: {$0.0 < $1.0})) where ((axisChartBase.data?.getDataSetByIndex(innerDict.key)?.isVisible) != nil) && (axisChartBase.data?.getDataSetByIndex(innerDict.key)!.isVisible)!
        {
            setIndex = innerDict.key
            break
        }
        
        return setIndex
    }
    
    public static func getXStringInOrder(currentXValues:Set<String>, xStringOrder:[String]?) ->[String]
    {
        var xGivenSet = Set<String>()
        
        guard let xStrOrder = xStringOrder
        else { return [] }
        
        for x in  xStrOrder
        {
            xGivenSet.insert(x)
        }
        
        let xValuesMissing = xGivenSet.subtracting(currentXValues)
        
        var xString = xStringOrder
        
        for setValue in xValuesMissing
        {
            guard let index = (xString?.firstIndex(of:setValue))
            else { continue }
            xString?.remove(at: index )
        }
        
        return xString ?? []
    }
    
    public static func getNewXPositionToInsertForEntry(axisChartBase: ChartViewBase,chartEntry:ChartDataEntry,dataset:IChartDataSet) -> Double
    {
        
        var flag:Bool = false
        
        var newXIndex:Double? = nil
        
        let entryCount = dataset.entryCount
        
        guard let barLineData = axisChartBase.data
            else { return -1}
        
        let dataSets = barLineData.dataSets
        
        if barLineData.xOrdinal && barLineData.xStringOrder != nil
        {
            var stringIndexMapping:[String:Int] = [:]
            if axisChartBase.xAxis.categoryOrder == nil
            {
                return -1
            }
            
            for categoryIndex in 0..<(axisChartBase.xAxis.categoryOrder!.count)
            {
                stringIndexMapping[axisChartBase.xAxis.categoryOrder![categoryIndex]] = categoryIndex
            }
            
            guard let finalStringArray:[String] = (barLineData.xStringOrder)
            else { return -1}

            for categoryIndex in 0..<finalStringArray.count
            {
                if stringIndexMapping[finalStringArray[categoryIndex]] == nil || chartEntry.xString == nil || stringIndexMapping[chartEntry.xString!] == nil
                {
                    continue
                }
                if stringIndexMapping[finalStringArray[categoryIndex]]! >= stringIndexMapping[chartEntry.xString!]! && !(finalStringArray.contains(chartEntry.xString!))
                {
                    return Double(categoryIndex)
                }
            }
            return Double(finalStringArray.count)
        }
        
        if entryCount == 0
        {
            var xStringTemp = [String]()
            
            if barLineData.xStringOrder != nil
            {
                var xUniqueValues = Set<String>()
                
                for set in dataSets where set.isVisible
                {
                    for entryIndex in 0..<set.entryCount
                    {
                        guard let entry = set.entryForIndex(entryIndex)
                        else { continue }
                        if entry.xString == nil || barLineData.yOrdinal[set.axisIndex] == nil || (barLineData.yOrdinal[set.axisIndex]! && entry.yString == nil)
                        {
                            continue
                        }
                        xUniqueValues.insert((entry.xString)!)
                    }
                }
                if chartEntry.xString == nil
                {
                    return -1
                }
                xUniqueValues.insert(chartEntry.xString!)
                
                xStringTemp = ChartInteractionHelperFunction.getXStringInOrder(currentXValues: xUniqueValues, xStringOrder: barLineData.xStringOrder)
                
            }
            
            var count = Double(-1)
            //        var setDependency = YAxis.AxisDependency.left
            for set in dataSets where set.isVisible
            {
                if set === dataset
                {
                    if chartEntry.xString == nil
                    {
                        return -1
                    }
                    if !(xStringTemp.contains(chartEntry.xString!))
                    {
                        count += 1
                        
                        return count
                    }
                    else{
                        return Double(xStringTemp.firstIndex(of: chartEntry.xString!) ?? -1)
                    }
                }
                
                for entryIndex in 0..<set.entryCount
                {
                    guard let entry = set.entryForIndex(entryIndex)
                    else { continue }
                    
                    if entry.xString == nil || barLineData.yOrdinal[set.axisIndex] == nil || (barLineData.yOrdinal[set.axisIndex]! && entry.yString == nil){
                        continue
                    }
                    if !(xStringTemp.contains(entry.xString!))
                    {
                        count += 1
                        xStringTemp.append(entry.xString!)
                    }
                    else{
                        
                    }
                }
                
            }
            return 0
        }
        
        for i in 0 ..< entryCount
        {
            var currentEntry = dataset.entryForIndex(i)
            
            if chartEntry.origIndex == nil || currentEntry?.origIndex == nil
            {
                continue
            }
            
            if (chartEntry.origIndex)! > (currentEntry?.origIndex)!
            {
                continue
            }
            else if (chartEntry.origIndex)! < (currentEntry?.origIndex)!
            {
                if (currentEntry?.x.isNaN)!
                {
                    guard let indexPosition = (dataset as? ChartDataSet)?.getClosestEntryandIndex(currentIndex: i, closestToIndex: i, closestToX: nil)
                    else { continue }
                    
                    guard indexPosition != -1
                        else { return 0 }
                    
                    currentEntry = dataset.entryForIndex(indexPosition)
                    
                    if indexPosition < i{
                        newXIndex = (currentEntry?.x)! + 1
                    }
                    else{
                        newXIndex = (currentEntry?.x)!
                    }
                }
                else{
                    newXIndex = (currentEntry?.x)!
                }
                flag = true
                break
            }
        }
        
        if !flag
        {
            let indexCount = entryCount-1
            guard var tempEntry = dataset.entryForIndex(indexCount)
            else { return 0}
            
            if tempEntry.x.isNaN
            {
                guard let indexPosition = (dataset as? ChartDataSet)?.getClosestEntryandIndex(currentIndex: indexCount, closestToIndex: indexCount, closestToX: nil)
                else { return 0}
                
                guard indexPosition != -1
                    else { return 0}
                
                tempEntry = dataset.entryForIndex(indexPosition) ?? tempEntry
            }
            newXIndex = tempEntry.x + 1
            flag = true
            
        }
        
        return newXIndex ?? 0
    }
    
    static func translateViewIfNeeded(axisChartBase: ChartViewBase,set:IChartDataSet, newXIndex:Double) -> Bool
    {
        var moved:Bool = false
        guard let viewPortHandler = axisChartBase.viewPortHandler
        else { return moved }
        
        let leftX = axisChartBase.valueForTouchPoint(point: CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop) , axisIndex: set.axisIndex).x
        let rightX = axisChartBase.valueForTouchPoint(point: CGPoint(x: viewPortHandler.contentRight, y: viewPortHandler.contentTop) ,  axisIndex: set.axisIndex).x
        
        let leftXIndex =   Double(leftX)
        
        let rightXIndex = Double(rightX)
        
        if (newXIndex < leftXIndex) || (newXIndex > rightXIndex)
        {
            let onePointWidth = axisChartBase.getTransformer(axisIndex: set.axisIndex).valueToPixelMatrix.a
            
            let midX = axisChartBase.valueForTouchPoint(point: CGPoint(x: (viewPortHandler.contentRight - viewPortHandler.contentLeft)/2, y: viewPortHandler.contentTop) , axisIndex: set.axisIndex).x
            
            let difference = midX - CGFloat(newXIndex)
            
            let distToMove =  difference * onePointWidth
            
            if axisChartBase.xAxis.isInverted //x-axis inverted
            {
                CommonHelperFunctions.translateView(distance: -distToMove, duration: 1, chart: axisChartBase)
            }
            else
            {
                CommonHelperFunctions.translateView(distance: distToMove, duration: 1, chart: axisChartBase)
            }
            
            moved = true
            
        }
        
        return moved
        
    }
    
    
    static func includeScatterBubble(axisChartBase: ChartViewBase,chartEntry:[ChartDataEntry], newXPosition:Double,duration:TimeInterval, type:ChartType)
    {
        
        guard let bubbleScatterData = (axisChartBase.data),
            let plotOptions = (axisChartBase.getPlotOptions(type: type) as? AxisChartPlotOptions)
              else { return }
        
        let currentShapeSize:CGFloat = plotOptions.maximumShapeSizeInPixel != 0 ? plotOptions.maximumShapeSizeInPixel :  (bubbleScatterData.dataSets[0].dataSetOptions as? AxisChartDataSetOptions)?.shapeProperties.size.width ?? 0
        
        axisChartBase.lastSelected = nil
        plotOptions.barGroupSelectionEnabled = false
        axisChartBase.callDelegateToContainer(highlight: nil, entry: nil)
        
        var oldEntries:[[ChartDataEntry]] = []
        var newEntries:[[ChartDataEntry]] = []
        
        guard let eOrigX = chartEntry[0].origX,
              let sets = (axisChartBase.data?._dataSets)
        else { return }
        
        let xIndexDict = axisChartBase.originalMap[eOrigX]
        
        for set in sets
        {
            var setEntries:[ChartDataEntry] = []
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                setEntries.append(entry)
            }
            oldEntries.append(setEntries)
        }
        
        // To track index to includeEntry
        var trackIndex:Int = 0
        
        for setIndex in 0..<sets.count
        {
            guard let set = (axisChartBase.data?.dataSets[setIndex])
            else { continue }
            var setEntries:[ChartDataEntry] = []
            var entryToAddCount = 0
            if xIndexDict?[setIndex] != nil
            {
                entryToAddCount = (xIndexDict![setIndex]?.count)!
            }
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                while  entryToAddCount > 0  && entry.x >= newXPosition // (entry.origIndex)! > (chartEntry[trackIndex].origIndex)!
                {
                    setEntries.append(chartEntry[trackIndex])
                    trackIndex += 1
                    entryToAddCount -= 1
                }
                
                
                guard let finalEntry = entry.copy() as? ChartDataEntry
                else { continue }
                
                if entry.x >= newXPosition
                {
                    finalEntry.x = Double(entry.x+1)
                }
                
                setEntries.append(finalEntry)
            }
            
            while entryToAddCount > 0
            {
                setEntries.append(chartEntry[trackIndex])
                trackIndex += 1
                entryToAddCount -= 1
            }
            
            newEntries.append(setEntries)
        }
        
        
        
        var oldPoints:[[CGPoint]]
        
        var newPoints:[[CGPoint]]
        
        oldPoints = getScatterPoints(chart: axisChartBase)
        
        // reset dataset with newEntries
        CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
        
        
        newPoints = getScatterPoints(chart: axisChartBase)
        
        
        // reset back with oldEntries
        CommonHelperFunctions.resetData(newEntries: oldEntries, chart: axisChartBase)
        
        
        var xInterpolateArray:[[((Double) -> Double)]] = []
        
        guard (axisChartBase.data?.dataSetCount) != nil
        else { return }
        
        for dataSetIndex in 0..<(axisChartBase.data?.dataSetCount)!
        {
            guard let set = axisChartBase.data?._dataSets[dataSetIndex] as? ChartDataSet
            else { continue }
            
            if !(set.isVisible)
            {
                xInterpolateArray.append([((Double) -> Double)]())
                continue
            }
            
            var setEntriesXInterpolator:[((Double) -> Double)] = []
            
            var entryToAddCount = 0
            if xIndexDict?[dataSetIndex] != nil
            {
                entryToAddCount = (xIndexDict![dataSetIndex]?.count)!
            }
            
            for index in stride(from: 0, to: set.entryCount, by: 1)
            {
                guard let currentEntry = set.entryForIndex(index)
                else { continue }
                
                var oldX:CGFloat
                let newX:CGFloat
                
                oldX = oldPoints[dataSetIndex][index].x
                
                
                if currentEntry.x < newXPosition{
                    newX = newPoints[dataSetIndex][index].x
                }
                else{
                    newX = newPoints[dataSetIndex][index+entryToAddCount].x
                }
                
                
                let xDiff = Interpolator.interpolate(a: Double(oldX), b: (Double(newX)))
                
                setEntriesXInterpolator.append(xDiff)
            }
            
            xInterpolateArray.append(setEntriesXInterpolator)
        }
        
        var sliceAnimator:Animator! = Animator()
        
        if sliceAnimator != nil
        {
            sliceAnimator.stop()
        }
        
        sliceAnimator = Animator()
        
        sliceAnimator.updateBlock = {
            
            setEntryDeleted(axisChartBase: axisChartBase, entryDeleted: true, type: type)
            
            var interpolatorIndex:Int = 0
            
            guard (axisChartBase.data?.dataSetCount) != nil
            else { return }
            
            for dataSetIndex in 0..<(axisChartBase.data?.dataSetCount)!
            {
                guard let set = axisChartBase.data?._dataSets[dataSetIndex] as? ChartDataSet
                else { continue }
                
                if !(set.isVisible)
                {
                    continue
                }
                
                interpolatorIndex = 0
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    let newEntry = oldEntries[dataSetIndex][index]
                    
                    let oldCenter = oldPoints[dataSetIndex][index]
                    
                    var newCenter = CGPoint(x: oldCenter.x, y: oldCenter.y)
                    
                    let newVal = xInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                    
                    interpolatorIndex = interpolatorIndex + 1
                    
                    newCenter.x = CGFloat(newVal)
                    
                    newEntry.centerChanged = newCenter
                    
                }
            }
            
            axisChartBase.setNeedsDisplay()
            
        }
        
        sliceAnimator.stopBlock = {
            
            for entry in chartEntry
            {
                entry.isIncluded = true
                entry.barYValue = axisChartBase.viewPortHandler.contentBottom + currentShapeSize
            }
            
            setEntryDeleted(axisChartBase: axisChartBase, entryDeleted: false, type: type)
            
            resetEntriesAndNotifyData(axisChartBase: axisChartBase, newEntries: newEntries)
                           
            calculateCurrentDataAndSetOldMinMax(axisChartBase: axisChartBase)
            
            /*axisChartBase.setNeedsDisplay()
            
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)
            
            axisChartBase.data?.updateXYValues()
            
            for set in (axisChartBase.data?._dataSets)!
            {
                set.calcMinMax()
            }
            
            axisChartBase.data?.notifyDataChanged()
            
            axisChartBase.notifyDataSetChanged(redrawRequired: true)
            
            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)*/
            
            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(300), execute: {
                
                var visibleDataSetCount:Double = 0
                
                var entryLocation:[CGPoint] = []
                
                var allEntryAtIndex:[ChartDataEntry] = []
                
                guard (axisChartBase.data?.dataSets) != nil
                else { return }
                
                for set in (axisChartBase.data?._dataSets)!
                {
                    if set.isVisible
                    {
                        for setEntry in set.entriesForXValue(newXPosition)
                        {
                            if setEntry.y.isNaN
                            {
                                continue
                            }
                            allEntryAtIndex.append(setEntry)
                        }
                        visibleDataSetCount += 1
                    }
                }
                
                allEntryAtIndex.sort(by: { $0.y < $1.y})
                
                let totalDuration = duration/2
                
                let duration:Double = totalDuration/Double(allEntryAtIndex.count)
                
                for entry in allEntryAtIndex
                {
                    guard let loc = CommonHelperFunctions.getEntryLocation(chart: axisChartBase, entry: entry)
                    else { continue }
                    entryLocation.append(loc)
                }
                
                
                let barEntryAnimator = Animator()
                
                barEntryAnimator.updateBlock = {
                    
                    for entryIndex in 0..<allEntryAtIndex.count
                    {
                        let entry = allEntryAtIndex[entryIndex]
                        let endTime = (duration * Double(entryIndex+1))
                        let startTime = endTime - duration
                        let currentTime = (barEntryAnimator.phaseX) * totalDuration
                        
                        if currentTime > endTime{
                            entry.barYValue = entryLocation[entryIndex].y
                        }
                        else if currentTime < startTime
                        {
                            entry.barYValue = axisChartBase.viewPortHandler.contentBottom + currentShapeSize
                        }
                        else{
                            let difference = currentTime - startTime
                            var percent = CGFloat(difference/duration)
                            if percent > 1
                            {
                                percent = 1
                            }
                            
                            let yToDecrease = percent * ((axisChartBase.viewPortHandler.contentBottom + currentShapeSize) - entryLocation[entryIndex].y)
                            entry.barYValue =  (axisChartBase.viewPortHandler.contentBottom + currentShapeSize) - yToDecrease
                            
                        }
                    }
                    
                    axisChartBase.setNeedsDisplay()
                    
                }
                
                barEntryAnimator.stopBlock = {
                    
//                    axisChartBase.enableDrawValues()
                    axisChartBase.interactionAnimationInProgress = false
                    
                    for entry in chartEntry
                    {
                        entry.isIncluded = false
                    }
                    //                self.resizeAxisIfNeeded()
                    axisChartBase.setNeedsDisplay()
                    callResizeAxis(axisChartBase: axisChartBase)
                    
                    axisChartBase.delegateToContainer?.chartValueAdded?(chartView: axisChartBase, entries: chartEntry, dataSets: nil, dataSetAdded: false)
                    
                }
                
                barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
            })
            
        }
        
        sliceAnimator.animate(xAxisDuration: duration/2, easingOption: .linear)
        
        
    }
    
    static func includeScatterBubbleLinear(axisChartBase: ChartViewBase,chartEntry:[ChartDataEntry], newXPosition:Double,duration:TimeInterval, type:ChartType)
    {
        guard let bubbleScatterData = (axisChartBase.data),
              let plotOptions = (axisChartBase.getPlotOptions(type: type) as? AxisChartPlotOptions)
              else { return }
        
        let currentShapeSize:CGFloat = plotOptions.maximumShapeSizeInPixel != 0 ? plotOptions.maximumShapeSizeInPixel :  (bubbleScatterData.dataSets[0].dataSetOptions as? LineDataSetOptions)?.shapeProperties.size.width ?? 0
        
        axisChartBase.lastSelected = nil
        plotOptions.barGroupSelectionEnabled = false
        axisChartBase.callDelegateToContainer(highlight: nil, entry: nil)
        
        var newEntries:[[ChartDataEntry]] = []
        
        guard let eOrigX = chartEntry[0].origX
        else { return }
        let xIndexDict = axisChartBase.originalMap[eOrigX]
        
        
        
        // To track index to includeEntry
        var trackIndex:Int = 0
        
        guard (axisChartBase.data?._dataSets.count) != nil
        else { return }
        for setIndex in 0..<(axisChartBase.data?._dataSets.count)!
        {
            guard let set = (axisChartBase.data?.dataSets[setIndex])
            else { continue }
            var setEntries:[ChartDataEntry] = []
            var entryToAddCount = 0
            if xIndexDict?[setIndex] != nil
            {
                entryToAddCount = (xIndexDict![setIndex]?.count)!
            }
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                while  entryToAddCount > 0 && (entry.origIndex) != nil && (chartEntry[trackIndex].origIndex) != nil && (entry.origIndex)! > (chartEntry[trackIndex].origIndex)!
                {
                    setEntries.append(chartEntry[trackIndex])
                    trackIndex += 1
                    entryToAddCount -= 1
                }
                
                guard let finalEntry = entry.copy() as? ChartDataEntry
                else { continue }
                
                setEntries.append(finalEntry)
            }
            
            while entryToAddCount > 0
            {
                setEntries.append(chartEntry[trackIndex])
                trackIndex += 1
                entryToAddCount -= 1
            }
            
            newEntries.append(setEntries)
        }
        
        
        for entry in chartEntry
        {
            entry.isIncluded = true
            entry.barYValue = axisChartBase.viewPortHandler.contentBottom + currentShapeSize
        }
        
        
        setEntryDeleted(axisChartBase: axisChartBase, entryDeleted: false, type: type)
        
        resetEntriesAndNotifyData(axisChartBase: axisChartBase, newEntries: newEntries)
                      
        calculateCurrentDataAndSetOldMinMax(axisChartBase: axisChartBase)
        
      /*  axisChartBase.setNeedsDisplay()
        
        CommonHelperFunctions.resetData(newEntries: newEntries, chart: axisChartBase)
        _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)
        
        axisChartBase.data?.updateXYValues()
        
        for set in (axisChartBase.data?._dataSets)!
        {
            set.calcMinMax()
        }
        
        axisChartBase.data?.notifyDataChanged()
        
        axisChartBase.notifyDataSetChanged(redrawRequired: true)
        
        _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)*/
        
        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(300), execute: {
            
            var visibleDataSetCount:Double = 0
            
            var entryLocation:[CGPoint] = []
            
            var allEntryAtIndex:[ChartDataEntry] = []
            
            guard (axisChartBase.data?._dataSets) != nil
            else{ return }
            for set in (axisChartBase.data?._dataSets)!
            {
                if set.isVisible
                {
                    for setEntry in set.entriesForXValue(newXPosition)
                    {
                        if setEntry.y.isNaN
                        {
                            continue
                        }
                        allEntryAtIndex.append(setEntry)
                    }
                    visibleDataSetCount += 1
                }
            }
            
            allEntryAtIndex.sort(by: { $0.y < $1.y})
            
            let totalDuration = duration/2
            
            let duration:Double = totalDuration/Double(allEntryAtIndex.count)
            
            for entry in allEntryAtIndex
            {
                guard let loc = CommonHelperFunctions.getEntryLocation(chart: axisChartBase, entry: entry)
                else { return }
                entryLocation.append(loc)
            }
            
            
            let barEntryAnimator = Animator()
            
            barEntryAnimator.updateBlock = {
                
                for entryIndex in 0..<allEntryAtIndex.count
                {
                    let entry = allEntryAtIndex[entryIndex]
                    let endTime = (duration * Double(entryIndex+1))
                    let startTime = endTime - duration
                    let currentTime = (barEntryAnimator.phaseX) * totalDuration
                    
                    if currentTime > endTime{
                        entry.barYValue = entryLocation[entryIndex].y
                    }
                    else if currentTime < startTime
                    {
                        entry.barYValue = axisChartBase.viewPortHandler.contentBottom + currentShapeSize
                    }
                    else{
                        let difference = currentTime - startTime
                        var percent = CGFloat(difference/duration)
                        if percent > 1
                        {
                            percent = 1
                        }
                        
                        let yToDecrease = percent * ((axisChartBase.viewPortHandler.contentBottom + currentShapeSize) - entryLocation[entryIndex].y)
                        entry.barYValue =  (axisChartBase.viewPortHandler.contentBottom + currentShapeSize) - yToDecrease
                        
                    }
                }
                
                axisChartBase.setNeedsDisplay()
                
            }
            
            barEntryAnimator.stopBlock = {
                
//                axisChartBase.enableDrawValues()
                axisChartBase.interactionAnimationInProgress = false
                
                for entry in chartEntry
                {
                    entry.isIncluded = false
                }
                //                self.resizeAxisIfNeeded()
                axisChartBase.setNeedsDisplay()
                callResizeAxis(axisChartBase: axisChartBase)
                
                axisChartBase.delegateToContainer?.chartValueAdded?(chartView: axisChartBase, entries: chartEntry, dataSets: nil, dataSetAdded: false)
                
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        })
    }
    
    //================================= SCATTER/BUBBLE ENTRY INCLUDE FUNCTION ENDS HERE =============================//
    
    //================================= SCATTER/BUBBLE ENTRY LEGEND INTERACTION DELEGATE START HERE =============================//
    
    static func legendEnabled(axisChartBase: ChartViewBase,indexPath: IndexPath, entry: LegendEntry) {
        
        Log.info("Container::LegendEnabled ")
        
        axisChartBase.removedCount -= 1
        
        guard let set = datasetForIndexPath(chart: axisChartBase, indexPath: indexPath)
        else { return }
        
        ChartInteractionHelperFunction.includeDataSetWithAnimation(barChart: axisChartBase, selectedDataset: [set], animationDuration: 0.3)
        
//        _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)
        
    }
    
    
    static func legendDisabled(axisChartBase: ChartViewBase,indexPath: IndexPath, entry: LegendEntry) {
        
        
        Log.info("Container::LegendDisabled ")
        
        guard  (axisChartBase.data?.dataSetCount) != nil
        else{ return }
        
        if ((axisChartBase.data?.dataSetCount)! - axisChartBase.removedCount) > 1
        {
            
            axisChartBase.removedCount += 1
            
            guard let set = datasetForIndexPath(chart: axisChartBase, indexPath: indexPath)
            else { return }
            
            ChartInteractionHelperFunction.hideDataSetWithAnimation(barChart: axisChartBase, selectedDataset: [set], animationOptions: .hideAndAlign, animationDuration: 0.3)
//            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: axisChartBase)
        }
        
    }
    
    //================================= SCATTER/BUBBLE ENTRY LEGEND INTERACTION DELEGATE ENDS HERE =============================//
    
    //MARK: - COMBINED CHART SERIES REMOVAL / ADDITION API WITH ANIMATION
        
        //================================= COMBINED CHART SERIES REMOVAL / ADDITION API STARTS HERE =============================//
    
        public enum animationOptions {
            case hideAndAlign
            case StackedBaralign
            case align
        }
        
    public static func hideDataSetWithAnimation(barChart : ChartViewBase ,selectedDataset:[IChartDataSet], animationOptions: animationOptions, animationDuration: Double)
            {
                
                guard !selectedDataset.isEmpty else {
                    return
                }
                
               barChart.updateDataOrigIndex()
                
               var uniqPlotType:Set<ChartType> = []
                           
               var plotSetMap:[ChartType:[IChartDataSet]] = [:]
               
               selectedDataset.forEach { dataset in
                   
                   uniqPlotType.insert(dataset.plotType)
                   
                   if plotSetMap[dataset.plotType] == nil {
                       plotSetMap[dataset.plotType] = []
                   }
                   plotSetMap[dataset.plotType]!.append(dataset)
               }
                
                barChart.interactionAnimationInProgress = true
                
                let partDuration:Double = animationDuration // / 2
                
                let durationForAlignAnimation = partDuration / 2
                
                let duration = animationOptions == .align ? durationForAlignAnimation : partDuration
                
                let partDurationInMillis:Double = (duration * 1000) + 100
                
                let finalResetBlock = {
                    CommonHelperFunctions.hideDataSet(selectedDataset: selectedDataset, chart: barChart)
                }
                
                /*let alignRequired = false //isAlignRequired(barChart: barChart, selectedDataset: selectedDataset)
                if  alignRequired {
                    partDuration = animationDuration / 3
                }
                
                let partDurationInMillis:Double = partDuration * 1000
                
                let alignAnimationBlock = {
                    for set in selectedDataset {
                          set.visible = false
                    }
                    alignMultiBar(barLineChart: barChart, selectedDataset: plotSetMap[.Bar] != nil ? plotSetMap[.Bar]! : [] )
                    DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(partDurationInMillis)), execute: {
                        finalResetBlock()
                    })
                }*/
                
                let exitEndAnimationBlock = {
                    DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(partDurationInMillis)), execute: {
                       /* if alignRequired {
                          alignAnimationBlock()
                        } else {
                          finalResetBlock()
                        }*/
                        
                        setForcedValue(axisChartBase: barChart, enable:false)
                        
//                        barChart.enableDrawValues()
                        
                        finalResetBlock()
                    })
                }
                
                let exitAnimationBlock = {
//                    getNewExitAnimationBlock(barChart: barChart, selectedDataset: selectedDataset, exitDuration: partDuration)!()
                    
                    hideAndAlignDataSet(chart: barChart, selectedDataset: selectedDataset,animationOptions: animationOptions, exitDuration: partDuration)
                    
                    exitEndAnimationBlock()
                }
                
                exitAnimationBlock()
                
            }
            
        public static func includeDataSetWithAnimation(barChart : ChartViewBase ,selectedDataset:[IChartDataSet], animationDuration:Double)
        {
            
            guard !selectedDataset.isEmpty else {
                return
            }
        
            var uniqPlotType:Set<ChartType> = []
                   
            var plotSetMap:[ChartType:[IChartDataSet]] = [:]
       
            selectedDataset.forEach { dataset in
           
                uniqPlotType.insert(dataset.plotType)
           
                if plotSetMap[dataset.plotType] == nil {
                    plotSetMap[dataset.plotType] = []
                }
                plotSetMap[dataset.plotType]!.append(dataset)
            }
        
            barChart.interactionAnimationInProgress = true
        
            let partDuration:Double = animationDuration
            /*
             if barChart.data?.yMin == Double.greatestFiniteMagnitude
             {
             performDefaultNoDataToDataFadeEntryAnimation(barChart: barChart, selectedDataset: selectedDataset, exitDuration: partDuration)
             }
             else {
                //performNewIncludeAnimationBlock(barChart: barChart, selectedDataset: selectedDataset, exitDuration: partDuration)
             IncludeAndAlignDataSet(chart: barChart, selectedDataset: selectedDataset, exitDuration: partDuration)
             }*/
        
            let partDurationInMillis:Double = (partDuration * 1000) + 100
        
            let finalResetBlock = {
                CommonHelperFunctions.includeDataset(selectedDataset: selectedDataset, chart: barChart)
            }
        
            let exitEndAnimationBlock = {
                DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(partDurationInMillis)), execute: {
                
                    setForcedValue(axisChartBase: barChart, enable:false)
                
//                    barChart.enableDrawValues()
                
                    finalResetBlock()
                })
            }
        
            let exitAnimationBlock = {
            
                IncludeAndAlignDataSet(chart: barChart, selectedDataset: selectedDataset, exitDuration: partDuration)
            
                exitEndAnimationBlock()
            }
        
            exitAnimationBlock()
        }
    
            
            static func performNewIncludeAnimationBlock(barChart : ChartViewBase ,selectedDataset:[IChartDataSet], exitDuration:Double) {
              
                let exitBlock:(() -> Void)? = {
                
                    var uniqPlotType:Set<ChartType> = []
                    
                    var plotSetMap:[ChartType:[IChartDataSet]] = [:]
                    
                    selectedDataset.forEach { dataset in
                        
                        uniqPlotType.insert(dataset.plotType)
                        
                        if plotSetMap[dataset.plotType] == nil {
                            plotSetMap[dataset.plotType] = []
                        }
                        plotSetMap[dataset.plotType]!.append(dataset)
                    }
                       
                    plotSetMap.forEach{ (plotType,dataSets) in
                        
                        switch (plotType)
                        {
                        case .Bubble, .Line, .LineRange, .Scatter:
                                CommonHelperFunctions.includeDataset(selectedDataset: selectedDataset, chart: barChart)
                                break
                            case .BubblePie:
                                performBubblePieSeriesEntryAnimation(barLineChart: barChart, dataSets: selectedDataset, animationDuration: exitDuration)
                                break
                            case .Radar:
                                performRadarSeriesEntryAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                break
                            default:
                                performDefaultEntryAnimation(barChart: barChart, selectedDataset: dataSets, exitDuration: exitDuration)
                                break
                        }
                    }
                }
                
                exitBlock!()
              
          }
    
            static func performBubblePieSeriesEntryAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                
                var eArray:[ChartDataEntry] = []
                for set in dataSets
                {
                    for eIndex in 0..<set.entryCount
                    {
                        guard let e = set.entryForIndex(eIndex)
                        else { continue }
                        eArray.append(e)
                    }
                }
                BubbleHelperFunctions.enableSlice(chartEntry: eArray, chart: barLineChart, duration: animationDuration)
                
                DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(animationDuration)), execute: {
                    CommonHelperFunctions.includeDataset(selectedDataset: dataSets, chart: barLineChart)
                })
                                
            }
    
          static func performDefaultEntryAnimation(barChart:ChartViewBase,selectedDataset:[IChartDataSet], exitDuration:Double) {
                           
                var uniqPlotType:Set<ChartType> = []
                
                var plotSetMap:[ChartType:[IChartDataSet]] = [:]
                
                selectedDataset.forEach { dataset in
                    
                    uniqPlotType.insert(dataset.plotType)
                    
                    if plotSetMap[dataset.plotType] == nil {
                        plotSetMap[dataset.plotType] = []
                    }
                    plotSetMap[dataset.plotType]!.append(dataset)
                }
                
                selectedDataset.forEach({ dataset in
                    dataset.visible = true
                })
                
                barChart.data?.updateXYValues()
                
                barChart.data?.notifyDataChanged()
                
                var yInterpolators:[[((Double) -> Double)]] = []
                
                selectedDataset.forEach({ dataset in
                    
                  let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barChart, dataSet: dataset)
                    
                     var yInterpolator:[((Double) -> Double)] = []
                    
                     for i in 0..<(dataset.entryCount)
                     {
                         guard let entry = dataset.entryForIndex(i)
                         else { continue }
                          
                         yInterpolator.append(Interpolator.interpolate(a: baseLineValue, b: (entry.y)))
                          
                         entry.y = baseLineValue
                     }
                    
                    yInterpolators.append(yInterpolator)
                    
                })
                
                ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: barChart)
                
                let barEntryAnimator = Animator()
                
                barEntryAnimator.updateBlock = {
                    
                    for index in 0..<(selectedDataset.count)
                    {
                    let dataSet = selectedDataset[index]
                        
                    let yInterpolator:[((Double) -> Double)] = yInterpolators[index]
                        
                      for i in 0..<(dataSet.entryCount)
                      {
                          let entry = dataSet.entryForIndex(i)
                          
                          entry?.y = yInterpolator[i](barEntryAnimator.phaseX)
                      }
                    }
                     
                    if plotSetMap[.Bar] != nil {
                        if let barPreProcessor = getBarPreprocessor(barChart: barChart) {
                            barPreProcessor.calcPosNegSum()
                        }
                    }
                    
                    if plotSetMap[.Line] != nil {
                        if let linePreProcessor = getLinePreprocessor(barChart: barChart) {
                            linePreProcessor.calcPosNegSum()
                        }
                    }
                                    
                    barChart.setNeedsDisplay()
                }
            
                barEntryAnimator.stopBlock = {
                     CommonHelperFunctions.includeDataset(selectedDataset: selectedDataset, chart: barChart)
                }
                
                 barEntryAnimator.animate(xAxisDuration: exitDuration, easingOption: .linear)
            }
    
    static func performDefaultNoDataToDataFadeEntryAnimation(barChart:ChartViewBase,selectedDataset:[IChartDataSet], exitDuration:Double) {
                     
          var uniqPlotType:Set<ChartType> = []
          
          var plotSetMap:[ChartType:[IChartDataSet]] = [:]
          
          selectedDataset.forEach { dataset in
              
              uniqPlotType.insert(dataset.plotType)
              
              if plotSetMap[dataset.plotType] == nil {
                  plotSetMap[dataset.plotType] = []
              }
              plotSetMap[dataset.plotType]!.append(dataset)
          }
          
          selectedDataset.forEach({ dataset in
              dataset.visible = true
          })
          
          barChart.data?.updateXYValues()
          
          barChart.data?.notifyDataChanged()

        barChart.customAnimationInProgress = true
        
        barChart.notifyDataSetChanged(redrawRequired: true)

        let opacAnimator = Animator()
        
        let opacInterpolator = Interpolator.interpolate(a: Double(0), b: Double(1))
        
        opacAnimator.updateBlock = {
                        
            barChart.customAnimationInProgress = false
            
            if let layers = barChart.plotView?.nsuiLayer?.sublayers
            {
              for layer in layers
              {
                  let caLayer:CALayer = layer
                  if caLayer.isKind(of: ChartEntryLayer.self)
                  {
                      layer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
                  }
              }
            }
        }
        
        opacAnimator.stopBlock = {
             CommonHelperFunctions.includeDataset(selectedDataset: selectedDataset, chart: barChart)
        }
        
        opacAnimator.animate(xAxisDuration: exitDuration)
      }
    
        static func performRadarSeriesEntryAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                                                     
                guard let allDatasets = barLineChart.data?.dataSets as? [ChartDataSet],
                    let chartData = barLineChart.data
                    else {
                    return
                    }
                
                var toBeDeletedLayers:[CALayer] = []
                
                let fromPoints:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: barLineChart)
                
                for set in dataSets
                {
                    guard (set as? ChartDataSet) != nil
                    else { continue }
                    if let layer = LineLayer.getLayerForDataset(chart: barLineChart, lineChartDataSet: set as! ChartDataSet)
                    {
                        toBeDeletedLayers.append(layer)
                    }
                    set.visible = true
                }

                CommonHelperFunctions.updateMatrix(chart: barLineChart)
                
                let toPoints:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: barLineChart)
                
                for set in dataSets
                {
                    set.visible = false
                }
                
                CommonHelperFunctions.updateMatrix(chart: barLineChart)
                
                let (xInterpolateArray, yInterpolateArray) = getXYInterpolator(dataSets: allDatasets, fromPoints: fromPoints, toPoints: toPoints)
                
                var sliceAnimator:Animator! = Animator()
                
                sliceAnimator.updateBlock = getXYUpdateBlock(barLineChart: barLineChart, dataSets: allDatasets, xInterpolateArray: xInterpolateArray, yInterpolateArray: yInterpolateArray, animator: sliceAnimator)
                
                sliceAnimator.stopBlock = {
                    
                    guard let radarPlot = barLineChart.getPlotOptions(type: .Radar) as? DialPlotOptions
                    else { return }
                    
                    var fromCenter:[[CGRect]] = []
                    
                    for set in dataSets
                    {
                        set.visible = true
                        
                        var points:[CGRect] = []
                        
                        for entryIndex in 0..<set.entryCount
                        {
                            guard let entry = set.entryForIndex(entryIndex)
                            else { continue }
                            entry.centerChanged = radarPlot.centerCircleBox
                            
                            var point = CGRect()
                            point.origin = radarPlot.centerCircleBox
                            points.append(point)
                        }
                        fromCenter.append(points)
                    }
                    
                    CommonHelperFunctions.updateMatrix(chart: barLineChart)
                    
                    let toPoints = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: barLineChart)
                    
                    var toCenter:[[CGRect]] = []
                    
                    for set in dataSets
                    {
                        let index = chartData.indexOfDataSet(set)
                        toCenter.append(toPoints[index])
                    }
                    
                    guard (dataSets as? [ChartDataSet]) != nil
                    else { return }
                    
                    let datasetXYInterpolator = getXYInterpolator(dataSets: dataSets as! [ChartDataSet], fromPoints: fromCenter, toPoints: toCenter)
                    
                    let radarAnimator = Animator()
                    
                    radarAnimator.updateBlock = getXYUpdateBlock(barLineChart: barLineChart, dataSets: dataSets as! [ChartDataSet], xInterpolateArray: datasetXYInterpolator.xInterpolateArray, yInterpolateArray: datasetXYInterpolator.yInterpolateArray, animator: radarAnimator)
                    
                    radarAnimator.stopBlock = {
                        
                        setForcedValue(axisChartBase: barLineChart, enable: false)

                        sliceAnimator = nil

//                        barLineChart.enableDrawValues()

                        barLineChart.setNeedsDisplay()
                       
                        CommonHelperFunctions.enableIncludeLayer(chart: barLineChart)
                        
                        CommonHelperFunctions.includeDataset(selectedDataset: dataSets, chart: barLineChart)
                    }
                    
                    radarAnimator.animate(xAxisDuration: animationDuration/2, easingOption: .linear)
                    
                }
                
                sliceAnimator.animate(xAxisDuration: animationDuration/2, easingOption: .linear)
                        
        }
          
          static func getLinePreprocessor(barChart: ChartViewBase) -> LineChartPreprocessor? {
           
            return (barChart.getProcessor(type: .Line) as? LineChartPreprocessor)
    
          }
          
          static func getBarPreprocessor(barChart: ChartViewBase) -> BarPreprocessor? {
            
            let typeAllowed:[ChartType] = [.Bar,.Bullet]
            
            return (CommonHelperFunctions.getProcessor(chart: barChart, types: typeAllowed) as? BarPreprocessor)
            
          }
          
          static func isAlignRequired(barChart : ChartViewBase ,selectedDataset:[IChartDataSet]) -> Bool {
              
              var alignRequired = false

              if isMultiBarPresent(barLineChart: barChart, selectedDataset: selectedDataset) {
                  alignRequired = true
              }
              else {
                  //TODO
                  //Compare the xString order in before & after series removal
              }
              
              return alignRequired
          }
          
          static func isMultiBarPresent(barLineChart : ChartViewBase ,selectedDataset:[IChartDataSet]) -> Bool {
              
              var isGroupedBar = false
              
              guard  let data = barLineChart.data else {
                  return isGroupedBar
              }
              
              let isBarSeriesDeleted = selectedDataset.filter({ $0.plotType == .Bar}).count > 0
              
              if !isBarSeriesDeleted {
                  return isGroupedBar
              }
              
              guard let barPlotOptions = barLineChart.plotOptions[.Bar] as? BarPlotOptions
              else { return isGroupedBar }
              
              if barPlotOptions.isStacked {
                  return isGroupedBar
              }
              
              let availableBarDataSets = data.dataSets.filter( { $0.plotType == .Bar })
                              
              if availableBarDataSets.count > 1 &&  isBarSeriesDeleted && ( barPlotOptions.groupSpacePixel != 0 || barPlotOptions.groupSpace != 0 ) {
                  isGroupedBar = true
              }
                              
              return isGroupedBar
          }
          
        static func getNewExitAnimationBlock(barChart : ChartViewBase ,selectedDataset:[IChartDataSet], exitDuration:Double) -> (() -> Void)? {
                
                let exitBlock:(() -> Void)? = {
                
                    var uniqPlotType:Set<ChartType> = []
                    
                    var plotSetMap:[ChartType:[IChartDataSet]] = [:]
                    
                    selectedDataset.forEach { dataset in
                        
                        uniqPlotType.insert(dataset.plotType)
                        
                        if plotSetMap[dataset.plotType] == nil {
                            plotSetMap[dataset.plotType] = []
                        }
                        plotSetMap[dataset.plotType]!.append(dataset)
                    }
                                
                    plotSetMap.forEach{ (plotType,dataSets) in
                        
                        switch (plotType)
                        {
                            case .Bar:
                                if barChart.isRotated {
                                    performHorizontalBarSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                }
                                else {
                                    performBarSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                }
                                break
                            case .Bubble:
                                performBubbleSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                break
                            case .BubblePie:
                                performBubblePieSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                break
                            case .Scatter:
                                performScatterSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                break
                            case .Line:
                                performLineSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                break
                            case .Radar:
                                performRadarSeriesExitAnimation(barLineChart: barChart, dataSets: dataSets, animationDuration: exitDuration)
                                break
                            default:
                                print("Unhandled data type ", plotType)
                        }
                    }
                }
                return exitBlock
            }
            
            static func performBarSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                
        //        guard  let data = barLineChart.data else {
        //            return
        //        }
                let allowedTypes:[ChartType] = [.Bar]
                
                var plotOptions:BarPlotOptions? = nil
                
                barLineChart.plotOptions.forEach({ (plotType,options) in
                    if allowedTypes.contains(plotType) {
                        plotOptions = (options as? BarPlotOptions)
                    }
                })
                
                guard let barPlotOptions = plotOptions else {
                    return
                }
                
        //        let barPlotOptions = barLineChart.plotOptions[.Bar] as! BarPlotOptions
                
                var dictionary:[Double : [BarLayer]] = [:]
                for layer in BarLayer.getAllBarLayer(chart: barLineChart)
                  {
                    if isDataSetPresentInLayer(barLayer: layer, selectedDataset: dataSets) {
                        guard (layer.chartEntry != nil)
                        else { continue }
                        if dictionary[layer.chartEntry!.x] == nil {
                            dictionary[layer.chartEntry!.x] = []
                        }
                        dictionary[(layer.chartEntry?.x)!]?.append(layer)
                    }
                  }
                
                let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barLineChart, dataSet: dataSets[0])
                
                for layer in BarLayer.getAllBarLayer(chart: barLineChart)
                   {
                    guard (layer.chartEntry) != nil
                    else { continue }
        //              let currentDataSetIndex = data.indexOfDataSet(layer.barDataSet!)
                       
                       let aboveBaseLine = (layer.chartEntry?.y)! > baseLineValue
                                                                                  
                       if  isDataSetPresentInLayer(barLayer: layer, selectedDataset: dataSets)
                       {
                           let layerHeight = layer.barRect?.size.height
                           
                           if layerHeight == 0
                           {
                               continue
                           }
                           
                        guard let newTransY =  (layerHeight)
                           else { continue }
                        
                        var totalPositiveHeight:CGFloat = 0
                        var totalNegativeHeight:CGFloat = 0
                        
                           if barPlotOptions.isStacked {
                            
                                let filterLayers = dictionary[layer.chartEntry!.x] != nil ? dictionary[layer.chartEntry!.x]! : []
                            
                               for filterLayer in filterLayers where filterLayer != layer && filterLayer.chartEntry != nil && filterLayer.barRect != nil && layer.barRect != nil {
                                    
                                    let filteredLayerAboveBaseLine = (filterLayer.chartEntry!.y) > baseLineValue
                                    
                                    if filteredLayerAboveBaseLine && (filterLayer.barRect!.minY > layer.barRect!.minY) {
                                        totalPositiveHeight += (filterLayer.barRect?.size.height)!
                                    }
                                    else if !filteredLayerAboveBaseLine && (filterLayer.barRect!.minY < layer.barRect!.minY) {
                                        totalNegativeHeight += (filterLayer.barRect?.size.height)!
                                    }
                                }
                            }


                           if aboveBaseLine
                           {
        //                    BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: newTransY, chart: barLineChart, duration: animationDuration )
                            BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: totalPositiveHeight + newTransY, changeHeight: -newTransY, chart: barLineChart, duration: animationDuration)
                           }
                           else{
                               BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: -totalNegativeHeight, changeHeight: -newTransY, chart: barLineChart, duration: animationDuration)
                           }

                       }
                       else{
                        
                        guard  barPlotOptions.isStacked,
                            let filterLayers = dictionary[layer.chartEntry!.x] else {
                            continue
                        }
                       
                        var totalPositiveHeight:CGFloat = 0
                        var totalNegativeHeight:CGFloat = 0
                        
                        for filterlayer in filterLayers {
                            if filterlayer.chartEntry == nil ||  filterlayer.barRect == nil ||  layer.barRect == nil
                            {
                                continue
                            }
                            let filteredLayerAboveBaseLine = (filterlayer.chartEntry!.y) > baseLineValue
                            
                            if filteredLayerAboveBaseLine && (filterlayer.barRect!.minY > layer.barRect!.minY) {
                                totalPositiveHeight += (filterlayer.barRect?.size.height)!
                            }else if !filteredLayerAboveBaseLine && (filterlayer.barRect!.minY < layer.barRect!.minY) {
                                totalNegativeHeight += (filterlayer.barRect?.size.height)!
                            }
                            
                        }
                        
                        if aboveBaseLine
                        {
                            BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: totalPositiveHeight, chart: barLineChart, duration: animationDuration)
                        }
                        else{
                            BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: -totalNegativeHeight, chart: barLineChart, duration: animationDuration)
                        }
        //                   let barPath = UIBezierPath(rect:layer.barRect!)
        //                   CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                       }
                   }
            }
            
            

                static func performHorizontalBarSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                    
            //        guard  let data = barLineChart.data else {
            //            return
            //        }
                    let allowedTypes:[ChartType] = [.Bar]
                    
                    var plotOptions:BarPlotOptions? = nil
                    
                    barLineChart.plotOptions.forEach({ (plotType,options) in
                        if allowedTypes.contains(plotType) {
                            plotOptions = (options as? BarPlotOptions) ?? nil
                        }
                    })
                    
                    guard let barPlotOptions = plotOptions else {
                        return
                    }
                    
            //        let barPlotOptions = barLineChart.plotOptions[.Bar] as! BarPlotOptions
                    
                    var dictionary:[Double : [BarLayer]] = [:]
                    for layer in BarLayer.getAllBarLayer(chart: barLineChart)
                      {
                        if isDataSetPresentInLayer(barLayer: layer, selectedDataset: dataSets) {
                            guard (layer.chartEntry) != nil
                            else { continue }
                            if dictionary[layer.chartEntry!.x] == nil {
                                dictionary[layer.chartEntry!.x] = []
                            }
                            dictionary[(layer.chartEntry?.x)!]?.append(layer)
                        }
                      }
                    
                    let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barLineChart, dataSet: dataSets[0])
                    
                    for layer in BarLayer.getAllBarLayer(chart: barLineChart)
                       {
                        guard (layer.chartEntry) != nil
                        else { continue }
            //              let currentDataSetIndex = data.indexOfDataSet(layer.barDataSet!)
                           
                           let aboveBaseLine = (layer.chartEntry?.y)! > baseLineValue
                                                                                      
                           if  isDataSetPresentInLayer(barLayer: layer, selectedDataset: dataSets)
                           {
                               let layerWidth = layer.barRect?.size.width
                               
                               if layerWidth == 0
                               {
                                   continue
                               }
                               
                            guard let newTransY =  (layerWidth)
                               else { continue }
                            
                            var totalPositiveWidth:CGFloat = 0
                            var totalNegativeWidth:CGFloat = 0
                            
                               if barPlotOptions.isStacked {
                                
                                    let filterLayers = dictionary[layer.chartEntry!.x] != nil ? dictionary[layer.chartEntry!.x]! : []
                                
                                    for filterLayer in filterLayers where filterLayer != layer && filterLayer.chartEntry != nil && filterLayer.barRect != nil && layer.barRect != nil {
                                        
                                        let filteredLayerAboveBaseLine = (filterLayer.chartEntry!.y) > baseLineValue
                                        
                                        if filteredLayerAboveBaseLine && (layer.barRect!.minX > filterLayer.barRect!.minX) {
                                            totalPositiveWidth += (filterLayer.barRect?.size.width)!
                                        }
                                        else if !filteredLayerAboveBaseLine && (layer.barRect!.minX < filterLayer.barRect!.minX) {
                                            totalNegativeWidth += (filterLayer.barRect?.size.width)!
                                        }
                                    }
                                }


                               if aboveBaseLine
                               {
            //                    BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: newTransY, chart: barLineChart, duration: animationDuration )
        //                        BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: totalPositiveWidth + newTransY, changeHeight: -newTransY, chart: barLineChart, duration: animationDuration)
                                
                                BarHelperFunctions.changeBarXPositionAndWidth(barLayer: layer, changeXValue: -totalPositiveWidth, changeWidth: -newTransY, chart: barLineChart, duration: animationDuration)
                               }
                               else{
        //                           BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: 0, changeHeight: -(newTransY+totalNegativeWidth), chart: barLineChart, duration: animationDuration)
                                BarHelperFunctions.changeBarXPositionAndWidth(barLayer: layer, changeXValue: newTransY + totalPositiveWidth, changeWidth: -newTransY, chart: barLineChart, duration: animationDuration)

                               }

                           }
                           else{
                            
                            guard  barPlotOptions.isStacked,
                                let filterLayers = dictionary[layer.chartEntry!.x] else {
                                continue
                            }
                           
                            var totalPositiveWidth:CGFloat = 0
                            var totalNegativeWidth:CGFloat = 0
                            
                            for filterLayer in filterLayers {
                                
                                if filterLayer.chartEntry == nil ||  filterLayer.barRect == nil ||  layer.barRect == nil
                                {
                                    continue
                                }
                                
                                let filteredLayerAboveBaseLine = (filterLayer.chartEntry!.y) > baseLineValue
                                
                                if filteredLayerAboveBaseLine && (layer.barRect!.minX > filterLayer.barRect!.minX) {
                                    totalPositiveWidth += (filterLayer.barRect?.size.width)!
                                }
                                else if !filteredLayerAboveBaseLine && (layer.barRect!.minX < filterLayer.barRect!.minX) {
                                    totalNegativeWidth += (filterLayer.barRect?.size.width)!
                                }
                                
                            }
                            
                            if aboveBaseLine
                            {
                                if totalPositiveWidth != 0 {
        //                        BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: totalPositiveWidth, chart: barLineChart, duration: animationDuration)
                                BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: -totalPositiveWidth, chart: barLineChart, duration: animationDuration)
                                }
                            }
                            else{
        //                        BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: -totalNegativeWidth, chart: barLineChart, duration: animationDuration)
                                BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: totalNegativeWidth, chart: barLineChart, duration: animationDuration)
                            }
            //                   let barPath = UIBezierPath(rect:layer.barRect!)
            //                   CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                           }
                       }
                }
            
            
            static func performBubbleSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                
                let layers = BubbleLayer.getAllBubbleLayer(chart: barLineChart).filter({ isDataSetPresent(dataSet: $0.bubbleDataSet!, selectedDataset: dataSets)})
                CommonHelperFunctions.performOpacityAnim(targetLayers: layers, fromOpacity: 1,toOpacity: 0, duration: animationDuration)
                                
            }
    
            static func performBubblePieSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                
                var eArray:[ChartDataEntry] = []
                for set in dataSets
                {
                    for eIndex in 0..<set.entryCount
                    {
                        guard let e = set.entryForIndex(eIndex)
                        else { continue }
                        eArray.append(e)
                    }
                }
                BubbleHelperFunctions.disableSlice(chartEntry: eArray, chart: barLineChart, duration: animationDuration)
                                
            }
            
            static func performScatterSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                                    
                    let layers = ScatterLayer.getAllScatterLayer(chart: barLineChart).filter({ isDataSetPresent(dataSet: $0.scatterDataSet!, selectedDataset: dataSets)})
                CommonHelperFunctions.performOpacityAnim(targetLayers: layers, fromOpacity: 1,toOpacity: 0, duration: animationDuration)
                                    
            }
            
            static func performLineSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                                             
                var toBeDeletedLayers:[CALayer] = []
                        
                LineLayer.getAllDataSetLayer(chart: barLineChart).filter({ isDataSetPresent(dataSet: $0.lineDataSet!, selectedDataset: dataSets)})
                    .forEach({ lineLayer in
                    
                    toBeDeletedLayers.append(lineLayer)
                    
                    let strokeLayer = LineLayer.getLineStrokeLayer(lineLayer: lineLayer)
                    if strokeLayer != nil {
                        toBeDeletedLayers.append(strokeLayer!)
                     }
                    
                    toBeDeletedLayers.append(contentsOf: LineLayer.getMarkerLayers(lineLayer: lineLayer))
                })
                
                CommonHelperFunctions.performOpacityAnim(targetLayers: toBeDeletedLayers, fromOpacity: 1,toOpacity: 0, duration: animationDuration)
            }
            
            static func performRadarSeriesExitAnimation(barLineChart:ChartViewBase,dataSets:[IChartDataSet], animationDuration:Double) {
                                             
                guard let allDatasets = barLineChart.data?.dataSets as? [ChartDataSet],
                    let chartData = barLineChart.data
                    else {
                    return
                    }
                
                var toBeDeletedLayers:[CALayer] = []
                
                let fromPoints:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: barLineChart)
                
                for set in dataSets
                {
                    guard (set as? ChartDataSet) != nil
                    else { continue }
                    if let layer = LineLayer.getLayerForDataset(chart: barLineChart, lineChartDataSet: set as! ChartDataSet)
                    {
                        toBeDeletedLayers.append(layer)
                    }
                    set.visible = false
                }
                
//                CommonHelperFunctions.performOpacityAnim(targetLayers: toBeDeletedLayers, fromOpacity: 1,toOpacity: 0, duration: animationDuration/4)
                
                CommonHelperFunctions.updateMatrix(chart: barLineChart)
                
                let toPoints:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: barLineChart)
                
                for set in dataSets
                {
                    set.visible = true
                }
                
                CommonHelperFunctions.updateMatrix(chart: barLineChart)
                
                for set in dataSets
                {
                    set.visible = false
                }
                
                let (xInterpolateArray,yInterpolateArray) = getXYInterpolator(dataSets: allDatasets, fromPoints: fromPoints, toPoints: toPoints)
                
                var sliceAnimator:Animator! = Animator()
                
                sliceAnimator.updateBlock = getXYUpdateBlock(barLineChart: barLineChart, dataSets: allDatasets, xInterpolateArray: xInterpolateArray, yInterpolateArray: yInterpolateArray, animator: sliceAnimator)
                
                sliceAnimator.stopBlock = {
                    
                    CommonHelperFunctions.updateMatrix(chart: barLineChart)
                    
                    setForcedValue(axisChartBase: barLineChart, enable: false)
//
                    sliceAnimator = nil

//                    barLineChart.enableDrawValues()
                    barLineChart.interactionAnimationInProgress = false

                    barLineChart.setNeedsDisplay()
                    
                    CommonHelperFunctions.enableIncludeLayer(chart: barLineChart)
                    
                }
                
                sliceAnimator.animate(xAxisDuration: animationDuration, easingOption: .linear)
                
            }
    
    
            public static func getXYInterpolator(dataSets:[ChartDataSet], fromPoints:[[CGRect]], toPoints:[[CGRect]]) -> (xInterpolateArray:[[((Double) -> Double)]],yInterpolateArray:[[((Double) -> Double)]])
            {
                var xInterpolateArray:[[((Double) -> Double)]] = []
                var yInterpolateArray:[[((Double) -> Double)]] = []
                
                for dataSetIndex in 0..<dataSets.count
                {
                    let set = dataSets[dataSetIndex]
                    
                    if !(set.isVisible)
                    {
                        xInterpolateArray.append([((Double) -> Double)]())
                        yInterpolateArray.append([((Double) -> Double)]())
                        continue
                    }
                    
                    var setEntriesXInterpolator:[((Double) -> Double)] = []
                    
                    var setEntriesYInterpolator:[((Double) -> Double)] = []
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        var oldXValue = CGFloat(0)
                        var oldYValue = CGFloat(0)
                        
                        var newXValue = CGFloat(0)
                        var newYValue = CGFloat(0)
                        
                        guard let oldDatasetRect = fromPoints[safe:dataSetIndex],
                            let oldEntryRect = oldDatasetRect[safe:index],
                            let newDatasetRect = toPoints[safe:dataSetIndex],
                            let newEntryRect = newDatasetRect[safe:index]
                            else { continue }
                        
                        oldXValue = oldEntryRect.origin.x
                        oldYValue = oldEntryRect.origin.y
                            
                        newXValue = newEntryRect.origin.x
                        newYValue = newEntryRect.origin.y
                    
                        let xDiff = Interpolator.interpolate(a: Double(oldXValue), b: (Double(newXValue)))
                        let yDiff = Interpolator.interpolate(a: Double(oldYValue), b: (Double(newYValue)))
                        
                        setEntriesXInterpolator.append(xDiff)
                        
                        setEntriesYInterpolator.append(yDiff)
                    }
                    xInterpolateArray.append(setEntriesXInterpolator)
                    yInterpolateArray.append(setEntriesYInterpolator)
                }
                
                return (xInterpolateArray,yInterpolateArray)
            }
    
    public static func getXYUpdateBlock(barLineChart:ChartViewBase, dataSets:[ChartDataSet], xInterpolateArray:[[((Double) -> Double)]], yInterpolateArray:[[((Double) -> Double)]],animator:Animator) -> (() -> Void)?
            {
                let updateBlock = { [unowned barLineChart, dataSets, animator] in
                    
                    setForcedValue(axisChartBase: barLineChart, enable: true)
                    
                    barLineChart.interactionAnimationInProgress = true
                    
                    var interpolatorIndex:Int = 0
                    
                    for dataSetIndex in 0..<dataSets.count
                    {
                        let set = dataSets[dataSetIndex]
                            
                        if !(set.isVisible)
                        {
                            continue
                        }
                        
                        interpolatorIndex = 0
                        
                        for index in stride(from: 0, to: set.entryCount, by: 1)
                        {
                            guard let entry = set.entryForIndex(index)
                            else { continue }
                            
                            guard
                                let xValInterpolator = xInterpolateArray[safe:dataSetIndex],
                                let xValInterpolatorfn = xValInterpolator[safe:interpolatorIndex],
                                let yValInterpolator = yInterpolateArray[safe:dataSetIndex],
                                let yValInterpolatorfn = yValInterpolator[safe:interpolatorIndex]
                                else {
                                    return
                                    
                            }
                            
                            var newCenter = CGPoint()
                            
                            let newXVal = xValInterpolatorfn(animator.phaseX)
                            let newYVal = yValInterpolatorfn(animator.phaseX)
                            
                            interpolatorIndex = interpolatorIndex + 1
                            
                            newCenter.x = CGFloat(newXVal)
                            newCenter.y = CGFloat(newYVal)
                            
                            entry.centerChanged = newCenter
                           
                        }
                    }
                    barLineChart.setNeedsDisplay()
                }
                
                return updateBlock
            }
    
            static func isDataSetPresentInLayer(barLayer:BarLayer, selectedDataset:[IChartDataSet]) -> Bool
            {
                guard let barDataSet = barLayer.barDataSet else {
                    return false
                }
                return isDataSetPresent(dataSet: barDataSet, selectedDataset: selectedDataset)
            }
            
            static func isDataSetPresent(dataSet:IChartDataSet, selectedDataset:[IChartDataSet]) -> Bool
               {
                   var isPresent = false
                    
                   for ds in selectedDataset where ds === dataSet {
                       isPresent = true
                       break
                   }
                   
                   return isPresent
               }
        
        //================================= COMBINED CHART SERIES REMOVAL / ADDITION API ENDS HERE =============================//
    
    // MARK: - Combined Filter
    
    public static func removeEntriesAtXWithAnimation(entry:ChartDataEntry, chart:ChartViewBase, duration:TimeInterval)
    {
        let completionBlock:(() -> Void)? =
        {
            guard let chartData = chart.data
                else { return }
            
            chart.lastSelected = nil
            
            for plotOption in (chart.plotOptions.values)
            {
                guard let plot = plotOption as? AxisChartPlotOptions
                else { continue }
                plot.barGroupSelectionEnabled = false
            }
            
            let isLinear = (chart.xAxis.scaleType != .Ordinal)
            
            let xToRemove =  entry.x
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            for set in chartData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                        else { return }
                    
                    if entry.x == xToRemove
                    {
                        entry.filterEnabled = true
                    }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            
            
            for set in chartData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let currentEntry = set.entryForIndex(i),
                    let finalEntry = currentEntry.copy() as? ChartDataEntry
                        else { return }
                    
                    if (finalEntry.x == Double.leastNormalMagnitude && finalEntry.origX == entry.origX) || finalEntry.x == xToRemove
                    {
                        continue
                    }
                    if !isLinear && finalEntry.x != Double.leastNormalMagnitude && finalEntry.x > xToRemove
                    {
                        finalEntry.x = Double(finalEntry.x-1)
                    }
                    
                    
                    setEntries.append(finalEntry)
                }
                newEntries.append(setEntries)
            }
            
            let oldRectArray:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: chart)
            
            // reset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
            
            let newRectArray:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: chart)
            
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
            
            var xyInterpolateArray:[[((Double) -> Double)]] = []
            
            var sizeInterpolateArray:[[((Double) -> Double)]] = []
            
            var xRemovedEntryInterpolateArray:[[((Double) -> Double)]] = []
            var yRemovedEntryInterpolateArray:[[((Double) -> Double)]] = []
            
            for dataSetIndex in 0..<chartData.dataSetCount
            {
                guard let set = chartData.dataSets[dataSetIndex] as? ChartDataSet
                    else{ return }
                
                if !(set.isVisible)
                {
                    xyInterpolateArray.append([((Double) -> Double)]())
                    sizeInterpolateArray.append([((Double) -> Double)]())
                    
                    xRemovedEntryInterpolateArray.append([((Double) -> Double)]())
                    yRemovedEntryInterpolateArray.append([((Double) -> Double)]())
                    
                    continue
                }
                
                var setEntriesXYInterpolator:[((Double) -> Double)] = []
                
                var setEntriesSizeInterpolator:[((Double) -> Double)] = []
                
                var setRemovedEntriesXInterpolator:[((Double) -> Double)] = []
                var setRemovedEntriesYInterpolator:[((Double) -> Double)] = []
                
                var entryIndex = -1
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let entry =  set.entryForIndex(index)
                    else { continue }
                    
                    if entry.x == xToRemove
                    {
                        guard let oldDatasetPoints = oldRectArray[safe:dataSetIndex],
                            let oldEntryPosition = oldDatasetPoints[safe:index],
                            let newDatasetPoints = newRectArray[safe:dataSetIndex],
                            let newEntryPosition = (entryIndex) >= 0 ? newDatasetPoints[safe:entryIndex] : newDatasetPoints[safe:0],
                            let newEntryPosition1 = (entryIndex+1) >= newDatasetPoints.count ? newDatasetPoints[safe:entryIndex] : newDatasetPoints[safe:entryIndex+1]
                            else { continue }
                        
                        let oldXValue = oldEntryPosition.origin.x
                        let oldYValue = chart.pixelForValues(x: entry.x, y: entry.y + Double(entry.barYValue) , axisIndex: set.axisIndex).y
                        
                        var newXValue = newEntryPosition.origin.x + ((newEntryPosition1.origin.x - newEntryPosition.origin.x)/2)
                        var newYValue = newEntryPosition.origin.y + ((newEntryPosition1.origin.y - newEntryPosition.origin.y)/2)
                        
                        guard (set.dataSetOptions as? LineDataSetOptions) != nil
                        else { continue}
                        if set.plotType == .Line || set.plotType == .Area && (set.dataSetOptions as! LineDataSetOptions).mode == .stepped
                        {
                            newXValue = newEntryPosition1.origin.x
                            newYValue = newEntryPosition.origin.y
                        }
                        
                        let xDiff = Interpolator.interpolate(a: Double(oldXValue), b: (Double(newXValue)))
                        let yDiff = Interpolator.interpolate(a: Double(oldYValue), b: (Double(newYValue)))
                        
                        setRemovedEntriesXInterpolator.append(xDiff)
                        setRemovedEntriesYInterpolator.append(yDiff)
                        
                        continue
                    }
                    
                    entryIndex += 1
                    
                    var oldValue = CGFloat(0)
                    var oldSize = CGFloat(0)
                    
                    var newValue = CGFloat(0)
                    var newSize = CGFloat(0)
                    
                    guard let oldDatasetRect = oldRectArray[safe:dataSetIndex],
                        let oldEntryRect = oldDatasetRect[safe:index],
                        let newDatasetRect = newRectArray[safe:dataSetIndex],
                        let newEntryRect = newDatasetRect[safe:entryIndex]
                        else { continue }
                    
                    if chart.isRotated
                    {
                        oldValue = oldEntryRect.origin.y
                        oldSize = oldEntryRect.size.height
                        
                        newValue = newEntryRect.origin.y
                        newSize = newEntryRect.size.height
                    }
                    else{
                        oldValue = oldEntryRect.origin.x
                        oldSize = oldEntryRect.size.width
                        
                        newValue = newEntryRect.origin.x
                        newSize = newEntryRect.size.width
                    }
                    
                    
                    let radiusDiff = Interpolator.interpolate(a: Double(oldValue), b: (Double(newValue)))
                    let widthDiff = Interpolator.interpolate(a: Double(oldSize), b: (Double(newSize)))
                    
                    setEntriesXYInterpolator.append(radiusDiff)
                    
                    setEntriesSizeInterpolator.append(widthDiff)
                }
                xyInterpolateArray.append(setEntriesXYInterpolator)
                sizeInterpolateArray.append(setEntriesSizeInterpolator)
                xRemovedEntryInterpolateArray.append(setRemovedEntriesXInterpolator)
                yRemovedEntryInterpolateArray.append(setRemovedEntriesYInterpolator)
            }
            
            var sliceAnimator:Animator! = Animator()
                        
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                setForcedValue(axisChartBase: chart, enable: true)
                
                var interpolatorIndex:Int = 0
                
                var interpolatorRemovedEntryIndex:Int = 0
                
                for dataSetIndex in 0..<chartData.dataSetCount
                {
                    guard let set = chartData.dataSets[dataSetIndex] as? ChartDataSet
                        else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    interpolatorRemovedEntryIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        guard let entry = set.entryForIndex(index)
                        else { continue }
                        
                        if entry.x == xToRemove
                        {
                            guard let valXInterpolator = xRemovedEntryInterpolateArray[safe:dataSetIndex],
                                   let valXInterpolatorfn = valXInterpolator[safe:interpolatorRemovedEntryIndex],
                                    let valYInterpolator = yRemovedEntryInterpolateArray[safe:dataSetIndex],
                                    let valYInterpolatorfn = valYInterpolator[safe:interpolatorRemovedEntryIndex]
                            else { continue }
                            
                            interpolatorRemovedEntryIndex += 1
                            let xValue = valXInterpolatorfn(sliceAnimator.phaseX)
                            let yValue = valYInterpolatorfn(sliceAnimator.phaseX)
                            
                            entry.centerChanged = CGPoint(x: xValue, y: yValue)
                            
                            continue
                        }
                        guard let oldDataset = oldEntries[safe:dataSetIndex],
                            let oldDatasetEntry = oldDataset[safe:index],
                            let oldDatasetRect = oldRectArray[safe:dataSetIndex],
                            let oldDatasetEntryRect = oldDatasetRect[safe:index],
                            let valInterpolator = xyInterpolateArray[safe:dataSetIndex],
                            let valInterpolatorfn = valInterpolator[safe:interpolatorIndex],
                            let widthInterpolator = sizeInterpolateArray[safe:dataSetIndex],
                            let widthInterpolatorfn = widthInterpolator[safe:interpolatorIndex]
                            else { return }
                        
                        let newEntry = oldDatasetEntry
                        
                        let oldRect = oldDatasetEntryRect
                        
                        var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                        
                        var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                        
                        let newVal = valInterpolatorfn(sliceAnimator.phaseX)
                        let newWidth = widthInterpolatorfn(sliceAnimator.phaseX)
                        interpolatorIndex = interpolatorIndex + 1
                        
                        if chart.isRotated
                        {
                            newCenter.y = CGFloat(newVal)
                            newSize.height = CGFloat(newWidth)
                        }
                        else{
                            newCenter.x = CGFloat(newVal)
                            newSize.width = CGFloat(newWidth)
                        }
                        
                        
                        newEntry.centerChanged = newCenter
                        
                        newEntry.sizeChanged = newSize
                    }
                }
                chart.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                setForcedValue(axisChartBase: chart, enable: false)
                
                sliceAnimator = nil
                
//                chart.enableDrawValues()
                
                chart.setNeedsDisplay()
                
                var removedEntries:[ChartDataEntry] = []
                
                for set in chartData.dataSets
                {
                    guard (set as? ChartDataSet) != nil
                    else { continue }
                    for entryToRemove in  (set as! ChartDataSet).values where entryToRemove.origX == entry.origX
                    {
                        removedEntries.append(entryToRemove)
                    }
                }
                
                ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
                 
                ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
                
                CommonHelperFunctions.enableIncludeLayer(chart: chart)
                
                chart.interactionAnimationInProgress = false
                
                chart.lastSelected = nil
                
                chart.callDelegateToContainer(highlight: nil, entry: nil)
                
                chart.delegateToContainer?.chartValueRemoved?(chart, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
                
            }
            
            sliceAnimator.animate(xAxisDuration: duration, easingOption: .linear)
            
        }
        
        completionBlock!()
    }
    
    public struct CustomRectInterpolator
    {
        let x:((Double) -> Double)
        let y:((Double) -> Double)
        let width:((Double) -> Double)
        let height:((Double) -> Double)
    }
    
    public static func removeEntriesWithAnimation(entries:[ChartDataEntry], chart:ChartViewBase, duration:TimeInterval)
    {
        let completionBlock:(() -> Void)? =
        {
            guard let chartData = chart.data
                else { return }
            chart.interactionAnimationInProgress = true
            chart.lastSelected = nil
            
            for plotOption in (chart.plotOptions.values)
            {
                guard let plot = plotOption as? PlotOptionsBase
                else { continue }
                plot.barGroupSelectionEnabled = false
            }
            
            for entry in entries
            {
                entry.filterEnabled = true
            }
            
            if let notes = chart.notes {
                setNoteEntriesFilterEnabledValue(notes: notes, entries: entries, enable: true)
            }
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            for set in chartData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                        else { return }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            for set in chartData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i),
                    let finalEntry = entry.copy() as? ChartDataEntry
                        else { return }
                    
                    if (set.plotType == .WaterFall) && WaterFallHelperFunction.isCascade(entry: entry) && entry.origY != nil && (entry.origY! as Double) == 0 {
                        entry.y = 0
                    }
                    
                    if entry.filterEnabled
                    {
                        continue
                    }
                
                    setEntries.append(finalEntry)
                }
                newEntries.append(setEntries)
            }
            
            // Since new entries may adjust touch matrix when last entry filtered
            let lastTouchMatrix = chart.viewPortHandler._touchMatrix
            
            let fromStringOrder:[String]? = chartData.xStringOrder //chartData.xStringOrder == nil ? [] : chartData.xStringOrder!
            var toStringOrder:[String]? = nil
            
            let oldRectArray:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: chart)
            
            let oldFilterArray = prepareArrayForFilterValues(chart: chart)
            
            let oldTicklabelModels = prepareTickLabelModels(chart: chart)
            
            let fromViewPortRect = chart.viewPortHandler.contentRect
            let fromChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
            
            if chartData.xOrdinal && chartData.xStringOrder != nil
            {
                var finalStringArray:[String] = (chartData.xStringOrder!)
                for entry in entries where entry.xString != nil
                {
                    finalStringArray.removeAll(where: {$0 == entry.xString!})
                }
                toStringOrder = finalStringArray
            }
            
            chartData.xStringOrder = toStringOrder
            
            
            // reset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
            
            let newRectArray:[[CGRect]] = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: chart)
            
            let newFilterArray = prepareArrayForFilterValues(chart: chart)
            
            let oldTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: oldTicklabelModels)
            
            let newTicklabelModels = prepareTickLabelModels(chart: chart)
            
            let toViewPortRect = chart.viewPortHandler.contentRect
            let toChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
            
            chartData.xStringOrder = fromStringOrder
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
            
            chart.viewPortHandler._touchMatrix = lastTouchMatrix
            
            mergeTickLabelModel(chart: chart, ticklabelModelObject: newTicklabelModels)
            
            let newTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: newTicklabelModels)
            
            var rectInterpolateArray:[[CustomRectInterpolator]] = []
            
            var xRemovedEntryInterpolateArray:[[((Double) -> Double)]] = []
            var yRemovedEntryInterpolateArray:[[((Double) -> Double)]] = []
            
            var extraInterpolatateArray:[[[CustomRectInterpolator]]] = []
            
            for dataSetIndex in 0..<chartData.dataSetCount
            {
                guard let set = chartData.dataSets[dataSetIndex] as? ChartDataSet
                    else{ return }
                
                if !(set.isVisible)
                {
                    rectInterpolateArray.append([CustomRectInterpolator]())
                    
                    xRemovedEntryInterpolateArray.append([((Double) -> Double)]())
                    yRemovedEntryInterpolateArray.append([((Double) -> Double)]())
                    extraInterpolatateArray.append([[CustomRectInterpolator]]())
                    continue
                }
                
                var setEntriesRectInterpolator:[CustomRectInterpolator] = []
                
                var setRemovedEntriesXInterpolator:[((Double) -> Double)] = []
                var setRemovedEntriesYInterpolator:[((Double) -> Double)] = []
                
                var setEntriesRectInterpolatorForExtras: [[CustomRectInterpolator]] = []
                
                let oldExtraDataSetArray = oldFilterArray[safe:dataSetIndex]
                
                let newExtraDataSetArray = newFilterArray[safe:dataSetIndex]
                
                var entryIndex = -1
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let entry =  set.entryForIndex(index)
                    else { continue }
                    
                    if entry.filterEnabled
                    {
                        guard let oldDatasetPoints = oldRectArray[safe:dataSetIndex],
                            let oldEntryPosition = oldDatasetPoints[safe:index],
                            let newDatasetPoints = newRectArray[safe:dataSetIndex],
                            let newEntryPosition = (entryIndex) >= 0 ? newDatasetPoints[safe:entryIndex] : newDatasetPoints[safe:0],
                            let newEntryPosition1 = (entryIndex+1) >= newDatasetPoints.count ? newDatasetPoints[safe:entryIndex] : newDatasetPoints[safe:entryIndex+1]
                            else { continue }
                        
                        let oldXValue = oldEntryPosition.origin.x
                        
                        var yVal = entry.y
                        
                        if CommonHelperFunctions.isStacked(chart: chart) {
                            
                            if LineHelperFunctions.typeAllowed.contains(set.plotType) {
                                yVal = LineHelperFunctions.getLineEntryStackedValue(chartViewBase: chart, plotType: set.plotType)[dataSetIndex]?[index] ?? yVal
                            }
                            
                            if BarHelperFunctions.typeAllowed.contains(set.plotType) {
                                yVal = BarHelperFunctions.getBarEntryStackedValue(chartViewBase: chart)?[dataSetIndex]?[index] ?? yVal
                            }
                        }
                        
                        let oldYValue = CommonHelperFunctions.getPixelForValues(isRotated: chart.isRotated, x: entry.x, y: yVal + Double(entry.barYValue), dataset: set, chart: chart).y
                           
                        var newXValue = newEntryPosition.origin.x + ((newEntryPosition1.origin.x - newEntryPosition.origin.x)/2)
                        var newYValue = newEntryPosition.origin.y + ((newEntryPosition1.origin.y - newEntryPosition.origin.y)/2)
                        
                        if set.plotType == .Line || set.plotType == .Area
                        {
                            if let lineDataSetOptions = set.dataSetOptions as? LineDataSetOptions {
                                
                                if lineDataSetOptions.mode == .stepped {
                                    newXValue = newEntryPosition1.origin.x
                                    newYValue = newEntryPosition.origin.y
                                }
                            }
                        }
                        
                        let xDiff = Interpolator.interpolate(a: Double(oldXValue), b: (Double(newXValue)))
                        let yDiff = Interpolator.interpolate(a: Double(oldYValue), b: (Double(newYValue)))
                        
                        setRemovedEntriesXInterpolator.append(xDiff)
                        setRemovedEntriesYInterpolator.append(yDiff)
                        
                        continue
                    }
                    
                    entryIndex += 1
                    
                    guard let oldDatasetRect = oldRectArray[safe:dataSetIndex],
                        let oldEntryRect = oldDatasetRect[safe:index],
                        let newDatasetRect = newRectArray[safe:dataSetIndex],
                        let newEntryRect = newDatasetRect[safe:entryIndex]
                        else { continue }

                    let xDiff = Interpolator.interpolate(a: Double(oldEntryRect.origin.x), b: (Double(newEntryRect.origin.x)))
                    let yDiff = Interpolator.interpolate(a: Double(oldEntryRect.origin.y), b: (Double(newEntryRect.origin.y)))
                    let widthDiff = Interpolator.interpolate(a: Double(oldEntryRect.size.width), b: (Double(newEntryRect.size.width)))
                    let heightDiff = Interpolator.interpolate(a: Double(oldEntryRect.size.height), b: (Double(newEntryRect.size.height)))
                    
                    let valuDiff = CustomRectInterpolator(x: xDiff, y: yDiff, width: widthDiff, height: heightDiff)
                    
                    setEntriesRectInterpolator.append(valuDiff)
                    
                    if let oldDataSetArray = oldExtraDataSetArray, let newDataSetArray = newExtraDataSetArray {
                        
                        if let oldEntryRectArray = oldDataSetArray[safe:index], let newEntryRectArray = newDataSetArray[safe: entryIndex] {
                            setEntriesRectInterpolatorForExtras.append(getRectInterPolatorForEntry(oldEntryRect: oldEntryRectArray, newEntryRect: newEntryRectArray))
                        }
                    }
                }
                rectInterpolateArray.append(setEntriesRectInterpolator)
                xRemovedEntryInterpolateArray.append(setRemovedEntriesXInterpolator)
                yRemovedEntryInterpolateArray.append(setRemovedEntriesYInterpolator)
                extraInterpolatateArray.append(setEntriesRectInterpolatorForExtras)
            }
            
            var sliceAnimator:Animator! = Animator()
                        
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                setForcedValue(axisChartBase: chart, enable: true)
                
                var interpolatorIndex:Int = 0
                
                var interpolatorRemovedEntryIndex:Int = 0
                
                for dataSetIndex in 0..<chartData.dataSetCount
                {
                    guard let set = chartData.dataSets[dataSetIndex] as? ChartDataSet
                        else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    interpolatorRemovedEntryIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        guard let entry = set.entryForIndex(index)
                        else { continue }
                        
                        if entry.filterEnabled
                        {
                            guard let valXInterpolator = xRemovedEntryInterpolateArray[safe:dataSetIndex],
                                   let valXInterpolatorfn = valXInterpolator[safe:interpolatorRemovedEntryIndex],
                                    let valYInterpolator = yRemovedEntryInterpolateArray[safe:dataSetIndex],
                                    let valYInterpolatorfn = valYInterpolator[safe:interpolatorRemovedEntryIndex]
                            else { continue }
                            
                            interpolatorRemovedEntryIndex += 1
                            let xValue = valXInterpolatorfn(sliceAnimator.phaseX)
                            let yValue = valYInterpolatorfn(sliceAnimator.phaseX)
                            
                            entry.centerChanged = CGPoint(x: xValue, y: yValue)
                            
                            if chart.plotTypes.contains(.BoxPlot) {
                                entry.opacityChanged = 0
                                entry.filterChanged = nil
                            }
                            
                            continue
                        }
                        guard let oldDataset = oldEntries[safe:dataSetIndex],
                            let oldDatasetEntry = oldDataset[safe:index],
                            let oldDatasetRect = oldRectArray[safe:dataSetIndex],
                            let oldDatasetEntryRect = oldDatasetRect[safe:index],
                            let valInterpolator = rectInterpolateArray[safe:dataSetIndex],
                            let valInterpolatorfn = valInterpolator[safe:interpolatorIndex]
                            else { return }
                        
                        let newEntry = oldDatasetEntry
                        
                        let oldRect = oldDatasetEntryRect
                        
                        var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                        
                        var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                        
                        let newXVal = valInterpolatorfn.x(sliceAnimator.phaseX)
                        let newYVal = valInterpolatorfn.y(sliceAnimator.phaseX)
                        let newWidth = valInterpolatorfn.width(sliceAnimator.phaseX)
                        let newHeight = valInterpolatorfn.height(sliceAnimator.phaseX)
                        
                        newCenter.x = CGFloat(newXVal)
                        newCenter.y = CGFloat(newYVal)
                        newSize.width = CGFloat(newWidth)
                        newSize.height = CGFloat(newHeight)
                    
                        newEntry.centerChanged = newCenter
                        newEntry.sizeChanged = newSize
                        
                        if let extraInterpolator = extraInterpolatateArray[safe:dataSetIndex], let extraEntryInterpolatorArray = extraInterpolator[safe:interpolatorIndex] {
                            newEntry.filterChanged = filterChangedInterpolatedValues(interpolationArray: extraEntryInterpolatorArray, animator: sliceAnimator)
                        }
                        
                        interpolatorIndex = interpolatorIndex + 1
                        
                    }
                }
                
                if let notes = chart.notes {
                    opacityAnimationForNoteEntries(notes: notes, entries: entries,isHide: true, animation: sliceAnimator)
                }
                
                animateTickLabelModel(chart: chart, phaseX: sliceAnimator.phaseX, oldAxisTickLabelMobelObject: oldTicklabelModels, newAxisTickLabelMobelObject: newTicklabelModels, oldAxisTickLabelPositionsObject: oldTicklabelPositionArray, newAxisTickLabelPositionsObject: newTicklabelPositionArray)
                
                animateViewPort(chart: chart, fromViewPortRect: fromViewPortRect, toViewPortRect: toViewPortRect, fromChartSize: fromChartSize, toChartSize: toChartSize, phaseX: sliceAnimator.phaseX)
                
                chart.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                setForcedValue(axisChartBase: chart, enable: false)
                
                sliceAnimator = nil
                
                chart.setNeedsDisplay()
                
                var removedEntries:[ChartDataEntry] = []
                
                for set in chartData.dataSets
                {
                    guard (set as? ChartDataSet) != nil
                    else { continue }
                    for entryToRemove in  (set as! ChartDataSet).values where entryToRemove.filterEnabled
                    {
                        removedEntries.append(entryToRemove)
                    }
                }
                
                if chart.plotTypes.contains(.BoxPlot) {
                    
                    for entry in removedEntries {
                        entry.opacityChanged = 1.0
                    }
                }
                
                chartData.xStringOrder = toStringOrder
                ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
                
                chart.updateNoteEntries()
                 
                chart.notifyDataSetChanged(redrawRequired: true)
                
                CommonHelperFunctions.enableIncludeLayer(chart: chart)
                
                chart.interactionAnimationInProgress = false
                
                chart.lastSelected = nil
                
                //chart.callDelegateToContainer(highlight: nil, entry: nil)
                
                chart.delegateToContainer?.chartValueRemoved?(chart, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
                
            }
            
            sliceAnimator.animate(xAxisDuration: duration, easingOption: .linear)
            
        }
        
        completionBlock!()
    }
    
    public static func includeEntriesAtXWithAnimations(entries:[ChartDataEntry], newXPosition:Double,duration:TimeInterval, chart:ChartViewBase)
    {
            chart.lastSelected = nil
        
            for plotOption in (chart.plotOptions.values)
            {
                guard let plot = plotOption as? PlotOptionsBase
                else { continue }
                plot.barGroupSelectionEnabled = false
            }
        
            chart.callDelegateToContainer(highlight: nil, entry: nil)
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            guard let eOrigX = entries[0].origX,
                  (chart.data?._dataSets) != nil
            else { return }
            let xIndexDict = chart.originalMap[eOrigX]
        
            let isLinear = chart.xAxis.scaleType != .Ordinal
            
            for set in (chart.data?._dataSets)!
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                    else { continue }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            // To track index to includeEntry
            var trackIndex:Int = 0
            
            for setIndex in 0..<(chart.data?._dataSets.count)!
            {
                guard let set = (chart.data?.dataSets[setIndex])
                else { continue }
                var setEntries:[ChartDataEntry] = []
                var entryToAddCount = 0
                if xIndexDict?[setIndex] != nil
                {
                    entryToAddCount = (xIndexDict![setIndex]?.count)!
                }
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                    else { continue }
                    
                    while  entryToAddCount > 0 && entry.x >= newXPosition   //(entry.origIndex)! > (barEntries[trackIndex].origIndex)!
                    {
                        setEntries.append(entries[trackIndex])
                        trackIndex += 1
                        entryToAddCount -= 1
                    }
                    
                    
                    guard let finalEntry = entry.copy() as? ChartDataEntry
                    else { continue }
                    
                    if !isLinear
                    {
                        let isEntryAfterFilterEntry = entry.x >= newXPosition //isStacked() ? entry.x >= newXIndex : i >=  ChartUtils.doubleToIntSafeCast(value:newXIndex)
                        if  isEntryAfterFilterEntry
                        {
                            finalEntry.x = Double(entry.x+1)
                        }
                    }
                    
                    setEntries.append(finalEntry)
                }
                
                while entryToAddCount > 0
                {
                    setEntries.append(entries[trackIndex])
                    trackIndex += 1
                    entryToAddCount -= 1
                }
                
                newEntries.append(setEntries)
            }
            
            let oldRectArray:[[CGRect]] = prepareRectArrayforAllDataset(chart: chart)
            
            // reset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
            
            let newRectArray:[[CGRect]] = prepareRectArrayforAllDataset(chart: chart)
            
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
            
        
            var xyInterpolateArray:[[((Double) -> Double)]] = []
            
            var sizeInterpolateArray:[[((Double) -> Double)]] = []
        
            var xAddedEntryInterpolateArray:[[((Double) -> Double)]] = []
        
            var yAddedEntryInterpolateArray:[[((Double) -> Double)]] = []
            
            trackIndex = 0
        
            guard (chart.data?.dataSetCount) != nil
            else { return }
            
            for dataSetIndex in 0..<(chart.data?.dataSetCount)!
            {
                guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
                else { continue }
                
                var entryToAddCount = 0
                if xIndexDict?[dataSetIndex] != nil
                {
                    entryToAddCount = (xIndexDict![dataSetIndex]?.count)!
                }
                
                if !(set.isVisible)
                {
                    xyInterpolateArray.append([((Double) -> Double)]())
                    sizeInterpolateArray.append([((Double) -> Double)]())
                    xAddedEntryInterpolateArray.append([((Double) -> Double)]())
                    yAddedEntryInterpolateArray.append([((Double) -> Double)]())
                    
                    trackIndex += entryToAddCount
                    
                    continue
                }
                
                var setEntriesXYInterpolator:[((Double) -> Double)] = []
                
                var setEntriesSizeInterpolator:[((Double) -> Double)] = []
                
                var setAddedEntriesXInterpolator:[((Double) -> Double)] = []
                var setAddedEntriesYInterpolator:[((Double) -> Double)] = []
            
                var addedEntryCenterUpdated:Bool = false
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let currentEntry = set.entryForIndex(index)
                    else { continue }
                    
                    var oldValue = CGFloat(0)
                    var oldSize = CGFloat(0)
                    
                    var newValue = CGFloat(0)
                    var newSize = CGFloat(0)
                 
                    var entryIndex = index
                    
                    if currentEntry.x >= newXPosition && !(addedEntryCenterUpdated)
                    {
                        for addedEntryIndex in index..<(index+entryToAddCount)
                        {
                            let positionArray = newRectArray[dataSetIndex]
                            let addedEntry = entries[trackIndex]
                            trackIndex += 1
                            
                            let prevPosition = (index - 1) >= 0 ? newRectArray[dataSetIndex][index-1] : newRectArray[dataSetIndex][1]
                            let nextPosition = (index + entryToAddCount) >= positionArray.count ?  newRectArray[dataSetIndex][positionArray.count - 1] :
                            newRectArray[dataSetIndex][index + entryToAddCount]
                            
                            var fromXValue = prevPosition.origin.x + ((nextPosition.origin.x - prevPosition.origin.x)/2)
                            var fromYValue = prevPosition.origin.y + ((nextPosition.origin.y - prevPosition.origin.y)/2)
                            
                            let toValue = newRectArray[dataSetIndex][addedEntryIndex]
                            
                            guard (set.dataSetOptions as? LineDataSetOptions) != nil
                            else { continue }
                            if set.plotType == .Line || set.plotType == .Area && (set.dataSetOptions as! LineDataSetOptions).mode == .stepped
                            {
                                fromXValue = nextPosition.origin.x
                                fromYValue = prevPosition.origin.y
                            }
                            
                            let xDiff = Interpolator.interpolate(a: Double(fromXValue), b: (Double(toValue.origin.x)))
                            let yDiff = Interpolator.interpolate(a: Double(fromYValue), b: (Double(toValue.origin.y)))
                            
                            setAddedEntriesXInterpolator.append(xDiff)
                            setAddedEntriesYInterpolator.append(yDiff)
                            
                            addedEntry.centerChanged = CGPoint(x: fromXValue, y: fromYValue)
                        }
                        
                        addedEntryCenterUpdated = true
                    }
                    
                    let isEntryAfterFilterEntry = currentEntry.x >= newXPosition //isStacked() ? currentEntry.x >= newXIndex : index >=  ChartUtils.doubleToIntSafeCast(value:newXIndex)
                    
                    if  isEntryAfterFilterEntry
                    {
                          entryIndex = index + entryToAddCount
                    }
                        
                    if chart.isRotated
                    {
                        oldValue = oldRectArray[dataSetIndex][index].origin.y
                        oldSize = oldRectArray[dataSetIndex][index].size.height
                        
                        newValue = newRectArray[dataSetIndex][entryIndex].origin.y
                        newSize = newRectArray[dataSetIndex][entryIndex].size.height
                    }
                    else{
                        oldValue = oldRectArray[dataSetIndex][index].origin.x
                        oldSize = oldRectArray[dataSetIndex][index].size.width
                        
                        newValue = newRectArray[dataSetIndex][entryIndex].origin.x
                        newSize = newRectArray[dataSetIndex][entryIndex].size.width
                    }
                    
                    
                    let radiusDiff = Interpolator.interpolate(a: Double(oldValue), b: (Double(newValue)))
                    let widthDiff = Interpolator.interpolate(a: Double(oldSize), b: (Double(newSize)))
                    
                    setEntriesXYInterpolator.append(radiusDiff)
                    
                    setEntriesSizeInterpolator.append(widthDiff)
                }
                
                if !(addedEntryCenterUpdated) && entryToAddCount > 0
                {
                    for addedEntryIndex in 0..<(entryToAddCount)
                    {
                        let positionArray = newRectArray[dataSetIndex]
                        let addedEntry = entries[trackIndex]
                        trackIndex += 1
                        
                        let lastEntryIndex = positionArray.count - 1 - entryToAddCount
                        
                        let prevPosition = newRectArray[dataSetIndex][lastEntryIndex]
                        let nextPosition = newRectArray[dataSetIndex][lastEntryIndex]
                        
                        let fromXValue = prevPosition.origin.x + ((nextPosition.origin.x - prevPosition.origin.x)/2)
                        let fromYValue = prevPosition.origin.y + ((nextPosition.origin.y - prevPosition.origin.y)/2)
                        
                        let toValue = newRectArray[dataSetIndex][lastEntryIndex+addedEntryIndex+1]
                        
                        let xDiff = Interpolator.interpolate(a: Double(fromXValue), b: (Double(toValue.origin.x)))
                        let yDiff = Interpolator.interpolate(a: Double(fromYValue), b: (Double(toValue.origin.y)))
                        
                        setAddedEntriesXInterpolator.append(xDiff)
                        setAddedEntriesYInterpolator.append(yDiff)
                        
                        addedEntry.centerChanged = CGPoint(x: fromXValue, y: fromYValue)
                    }
                }
                
                xyInterpolateArray.append(setEntriesXYInterpolator)
                sizeInterpolateArray.append(setEntriesSizeInterpolator)
                xAddedEntryInterpolateArray.append(setAddedEntriesXInterpolator)
                yAddedEntryInterpolateArray.append(setAddedEntriesYInterpolator)
            }
        
            var sliceAnimator:Animator! = Animator()
                
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                setForcedValue(axisChartBase: chart, enable: true)
                
                var interpolatorIndex:Int = 0
                
                guard (chart.data?.dataSetCount) != nil
                else { return }
                for dataSetIndex in 0..<(chart.data?.dataSetCount)!
                {
                    guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
                    else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        let newEntry = oldEntries[dataSetIndex][index]
                        
                        let oldRect = oldRectArray[dataSetIndex][index]
                        
                        var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                        
                        var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                        
                        let newVal = xyInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                        
                        let newWidth = sizeInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                        
                        interpolatorIndex = interpolatorIndex + 1
                        
                        if chart.isRotated
                        {
                            newCenter.y = CGFloat(newVal)
                            
                            newSize.height = CGFloat(newWidth)
                        }
                        else{
                            newCenter.x = CGFloat(newVal)
                            
                            newSize.width = CGFloat(newWidth)
                        }
                        
                        newEntry.centerChanged = newCenter
                        
                        newEntry.sizeChanged = newSize
                    }
                }
                
                chart.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                let animDuration = duration * 0.3
                
                var typeAllowed:[ChartType] = []
                
                for plot in chart.plotTypes
                {
                    if plot != .Line || plot != .Area
                    {
                        typeAllowed.append(plot)
                    }
                }
                
                setForcedOpacityValue(axisChartBase: chart, enable: false)
 
                setForcedValue(axisChartBase: chart, types: typeAllowed, enable: false)
      
                ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
                
                ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: chart)

                
                // BAR
                // To make percentage rise animation
                let processor = ChartInteractionHelperFunction.getBarPreprocessor(barChart: chart)
                
                var stackInterpolateArray:[((Double) -> Double)] = []
                
                var currentShapeSize:CGFloat = 0

                for entry in entries
                {
                    let set =  chart.data?.getDataSetForEntry(entry)
                    if set?.plotType == .Bar || set?.plotType == .Bullet
                    {
                        let yInterpolator = Interpolator.interpolate(a: 0, b: entry.y)
                        stackInterpolateArray.append(yInterpolator)
                        entry.y = 0
                    }
                    else if set?.plotType == .Bubble || set?.plotType == .Scatter
                    {
                        guard let plotOptions = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
                        else { continue }
                        
                        currentShapeSize = plotOptions.maximumShapeSizeInPixel != 0 ? plotOptions.maximumShapeSizeInPixel :  (set?.dataSetOptions as? AxisChartDataSetOptions)?.shapeProperties.size.width ?? 0
                        
                        entry.isIncluded = true
                        entry.barYValue = chart.viewPortHandler.contentBottom + currentShapeSize
                    }
                }
                processor?.updateEntriesStackValue()
                
                
                // Scatter Bubble
                
                var visibleDataSetCount:Double = 0
                
                var entryLocation:[CGPoint] = []
                
                var allEntryAtIndex:[ChartDataEntry] = []
                
                guard (chart.data?._dataSets) != nil
                else { return }
                for set in (chart.data?._dataSets)!
                {
                    if set.isVisible && (set.plotType == .Scatter || set.plotType == .Bubble)
                    {
                        for setEntry in set.entriesForXValue(newXPosition)
                        {
                            if setEntry.y.isNaN
                            {
                                continue
                            }
                            allEntryAtIndex.append(setEntry)
                        }
                        visibleDataSetCount += 1
                    }
                }
                
                allEntryAtIndex.sort(by: { $0.y < $1.y})
                
                let totalDuration = duration/2
                
                let duration:Double = totalDuration/Double(allEntryAtIndex.count)
                
                for entry in allEntryAtIndex
                {
                    guard let loc = CommonHelperFunctions.getEntryLocation(chart: chart, entry: entry)
                    else { continue }
                    entryLocation.append(loc)
                }
                
                let entryAnimator = Animator()
                
                entryAnimator.updateBlock = {
                    
                    // BAR
                    var stackIndex = -1
                    for entry in entries
                    {
                        let set =  chart.data?.getDataSetForEntry(entry)
                        if set?.plotType == .Bar || set?.plotType == .Bullet
                        {
                            stackIndex += 1
                            entry.y = stackInterpolateArray[stackIndex](entryAnimator.phaseX)
                        }
                    }
                    processor?.updateEntriesStackValue()
                    
                    
                    // LINE
                    
                    trackIndex = 0
                    for setInterPolatorIndex in 0..<xAddedEntryInterpolateArray.count
                    {
                       guard (chart.data?.dataSets[setInterPolatorIndex].isVisible) != nil
                        else { continue }
                       if !((chart.data?.dataSets[setInterPolatorIndex].isVisible)!)
                       {
                           var entryToAddCount = 0
                           
                           if xIndexDict?[setInterPolatorIndex] != nil
                           {
                               entryToAddCount = (xIndexDict![setInterPolatorIndex]?.count)!
                           }
                       
                           trackIndex += entryToAddCount
                           continue
                       }
                       
                       let setXInterPolator = xAddedEntryInterpolateArray[setInterPolatorIndex]
                       let setYInterPolator = yAddedEntryInterpolateArray[setInterPolatorIndex]
                       
                       for entryInterpolatorIndex in 0..<setXInterPolator.count
                       {
                           let entryXInterPolator = setXInterPolator[entryInterpolatorIndex]
                           let entryYInterPolator = setYInterPolator[entryInterpolatorIndex]
                           
                           let xValue = entryXInterPolator(entryAnimator.phaseX)
                           let yValue = entryYInterPolator(entryAnimator.phaseX)
                           
                           entries[trackIndex].centerChanged = CGPoint(x: xValue, y: yValue)
                           trackIndex += 1
                       }
                    }
                    
                    
                    // Scatter Bubble
                    for entryIndex in 0..<allEntryAtIndex.count
                    {
                        let entry = allEntryAtIndex[entryIndex]
                        let endTime = (duration * Double(entryIndex+1))
                        let startTime = endTime - duration
                        let currentTime = (entryAnimator.phaseX) * totalDuration
                        
                        if currentTime > endTime{
                            entry.barYValue = entryLocation[entryIndex].y
                        }
                        else if currentTime < startTime
                        {
                            entry.barYValue = chart.viewPortHandler.contentBottom + currentShapeSize
                        }
                        else{
                            let difference = currentTime - startTime
                            var percent = CGFloat(difference/duration)
                            if percent > 1
                            {
                                percent = 1
                            }
                            
                            let yToDecrease = percent * ((chart.viewPortHandler.contentBottom + currentShapeSize) - entryLocation[entryIndex].y)
                            entry.barYValue =  (chart.viewPortHandler.contentBottom + currentShapeSize) - yToDecrease
                            
                        }
                    }
                           
                                       
                    chart.setNeedsDisplay()
                }
                
                entryAnimator.stopBlock = {
                    
                    // Line forced value needs to be falsed
                    setForcedValue(axisChartBase: chart, enable: false)
                    
                    chart.interactionAnimationInProgress = false
                    
                    for entry in entries
                    {
                        entry.isIncluded = false
                    }
                    
    //                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
//                    ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
                    
//                    chart.enableDrawValues()
                    
                    CommonHelperFunctions.enableIncludeLayer(chart: chart)
                    
                    sliceAnimator = nil
                    
                    chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entries, dataSets: nil, dataSetAdded: false)

                }
                
                entryAnimator.animate(xAxisDuration: animDuration, easingOption: .linear)
            }
            
            sliceAnimator.animate(xAxisDuration: duration * 0.7, easingOption: .linear)
    }
    
    public static func includeEntriesWithAnimations(entries:[ChartDataEntry], newXPosition:Double,duration:TimeInterval, chart:ChartViewBase)
    {
                guard let chartData = chart.data
                    else { return }
        
               var entries = entries

               chart.lastSelected = nil
           
            let barPlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar,.WaterFall,.BoxPlot,.Mekko]) as? AxisChartPlotOptions
              
               let isSorted = (barPlot != nil) && barPlot!.sortInteractionCalled
        
                // Need to sort within dataset instead of across dataset.. Will do Later..
               if isSorted
               {
                    if barPlot!.sortAscendingEnabled
                    {
                       entries =  entries.sorted(by: {
                            $0.y < $1.y
                        })
                    }
                    else{
                        entries =  entries.sorted(by: {
                            $0.y > $1.y
                        })
                    }
               }

               for plotOption in (chart.plotOptions.values)
               {
                   guard let plot = plotOption as? PlotOptionsBase
                   else { continue }
                   plot.barGroupSelectionEnabled = false
               }
           
               //chart.callDelegateToContainer(highlight: nil, entry: nil)
               
               var oldEntries:[[ChartDataEntry]] = []
               var newEntries:[[ChartDataEntry]] = []
           
                guard (chart.data?._dataSets) != nil
                else { return }
        
               for set in (chart.data?._dataSets)!
               {
                   var setEntries:[ChartDataEntry] = []
                   for i in 0..<(set.entryCount)
                   {
                       guard let entry = set.entryForIndex(i)
                       else { continue }
                       
                       setEntries.append(entry)
                   }
                   oldEntries.append(setEntries)
               }
               
               // To track index to includeEntry
               var trackIndex:Int = 0
        
               var uniqueXValues = Set<Double>()
        
               for addEntry in entries
               {
                   guard addEntry.origX != nil
                   else { continue }
                    uniqueXValues.insert(addEntry.origX!)
               }
        
               var setIndexToEntryToAddCount:[Int:Int] = [:]
        
               for xValue in uniqueXValues
               {
                    let xIndexDict = chart.originalMap[xValue]
                
                   guard (chart.data?._dataSets.count) != nil
                   else { continue }
                    for setIndex in 0..<(chart.data?._dataSets.count)!
                    {
                        var entryToAddCount = 0
                        if xIndexDict != nil && xIndexDict![setIndex] != nil
                        {
                            entryToAddCount = (xIndexDict![setIndex]?.count)!
                        }
                        
                        if xIndexDict == nil {
                            entryToAddCount += 1
                        }
                        
                        if setIndexToEntryToAddCount[setIndex] != nil
                        {
                            setIndexToEntryToAddCount[setIndex] = setIndexToEntryToAddCount[setIndex]! + entryToAddCount
                        }
                        else{
                            setIndexToEntryToAddCount[setIndex] = entryToAddCount
                        }
                    }
               }
        
                guard (chart.data?._dataSets.count) != nil
                else { return }
               for setIndex in 0..<(chart.data?._dataSets.count)!
               {
                   guard let set = (chart.data?.dataSets[setIndex])
                   else { continue }
                   var setEntries:[ChartDataEntry] = []
                   guard var entryToAddCount = setIndexToEntryToAddCount[setIndex]
                   else { continue }
                
                   for i in 0..<(set.entryCount)
                   {
                       guard let entry = set.entryForIndex(i)
                       else { continue }
                       
                       while entryToAddCount > 0  //(entry.origIndex)! > (entries[trackIndex].origIndex)! //entry.x >= newXPosition
                       {
                           if entry.origIndex == nil || entries[trackIndex].origIndex == nil
                           { continue }
                            let allowedToAppend = isSorted ?
                                (barPlot!.sortAscendingEnabled ? entry.y >= entries[trackIndex].y : entry.y <= entries[trackIndex].y)
                                : (entry.origIndex)! > (entries[trackIndex].origIndex)!
                        
                            if allowedToAppend
                            {
                               setEntries.append(entries[trackIndex])
                               trackIndex += 1
                               entryToAddCount -= 1
                            }
                            else {
                                break
                            }
                       }
                       
                       guard let finalEntry = entry.copy() as? ChartDataEntry
                       else { continue}
                       
                       setEntries.append(finalEntry)
                   }
                   
                   while entryToAddCount > 0
                   {
                       setEntries.append(entries[trackIndex])
                       trackIndex += 1
                       entryToAddCount -= 1
                   }
                   
                   newEntries.append(setEntries)
               }
               
        
                let fromStringOrder:[String]? = chartData.xStringOrder //chartData.xStringOrder == nil ? [] : chartData.xStringOrder!
                var toStringOrder:[String]? = nil
                
                if chartData.xOrdinal && chartData.xStringOrder != nil
                {
                    guard (chart.xAxis.categoryOrder?.count) != nil
                    else { return }
                    var stringIndexMapping:[String:Int] = [:]
                    for categoryIndex in 0..<(chart.xAxis.categoryOrder!.count)
                    {
                        stringIndexMapping[chart.xAxis.categoryOrder![categoryIndex]] = categoryIndex
                    }
                    
                    var finalStringArray:[String] = (chartData.xStringOrder!)
                    for entry in entries where entry.xString != nil
                    {
                        var inserted = false
                        for categoryIndex in 0..<finalStringArray.count
                        {
                            if stringIndexMapping[finalStringArray[categoryIndex]] == nil || stringIndexMapping[entry.xString!] == nil
                            { continue }
                            if stringIndexMapping[finalStringArray[categoryIndex]]! >= stringIndexMapping[entry.xString!]! && !(finalStringArray.contains(entry.xString!))
                            {
                                inserted = true
                                finalStringArray.insert(entry.xString!, at: categoryIndex)
                                break
                            }
                        }
                        if !(inserted) && !(finalStringArray.contains(entry.xString!))
                        {
                            finalStringArray.append(entry.xString!)
                        }
                        
                    }
                    toStringOrder = finalStringArray
                }
        
               let oldRectArray:[[CGRect]] = prepareRectArrayforAllDataset(chart: chart)
        
               let oldFilterArray = prepareArrayForFilterValues(chart: chart)
        
               let oldTicklabelModels = prepareTickLabelModels(chart: chart)
        
               let fromViewPortRect = chart.viewPortHandler.contentRect
               let fromChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
               
               chartData.xStringOrder = toStringOrder
        
               // reset with newEntries
               CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
               
               let newRectArray:[[CGRect]] = prepareRectArrayforAllDataset(chart: chart)
        
               let newFilterArray = prepareArrayForFilterValues(chart: chart)
               
               let oldTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: oldTicklabelModels)
               
               let newTicklabelModels = prepareTickLabelModels(chart: chart)
        
               let toViewPortRect = chart.viewPortHandler.contentRect
               let toChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
               
               chartData.xStringOrder = fromStringOrder
               // reset back with oldEntries
               CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
               
           
            mergeTickLabelModel(chart: chart, ticklabelModelObject: newTicklabelModels)
        
               let newTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: newTicklabelModels)
        
               var rectInterpolateArray:[[CustomRectInterpolator]] = []
               
               var xAddedEntryInterpolateArray:[[((Double) -> Double)]] = []
           
               var yAddedEntryInterpolateArray:[[((Double) -> Double)]] = []
        
               var extraInterpolatateArray:[[[CustomRectInterpolator]]] = []
               
               trackIndex = 0
           
        guard (chart.data?.dataSetCount) != nil
        else { return }
               for dataSetIndex in 0..<(chart.data?.dataSetCount)!
               {
                   guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet,
                         var entryToAddCount = setIndexToEntryToAddCount[dataSetIndex]
                   else { continue }
                   
                   
                   
                   if !(set.isVisible)
                   {
                       rectInterpolateArray.append([CustomRectInterpolator]())
                       xAddedEntryInterpolateArray.append([((Double) -> Double)]())
                       yAddedEntryInterpolateArray.append([((Double) -> Double)]())
                       extraInterpolatateArray.append([[CustomRectInterpolator]]())
                       
                       trackIndex += entryToAddCount
                       
                       continue
                   }
                   
                   var setEntriesRectInterpolator:[CustomRectInterpolator] = []
                   
                   var setAddedEntriesXInterpolator:[((Double) -> Double)] = []
                   var setAddedEntriesYInterpolator:[((Double) -> Double)] = []
                   
                   var setEntriesRectInterpolatorForExtras: [[CustomRectInterpolator]] = []
                   
                   let oldExtraDataSetArray = oldFilterArray[safe:dataSetIndex]
                   
                   let newExtraDataSetArray = newFilterArray[safe:dataSetIndex]
                   
                   for index in stride(from: 0, to: set.entryCount, by: 1)
                   {
                       guard let currentEntry = set.entryForIndex(index)
                       else { continue }
                       
                       var entryIndex = index
                       
                       while entryToAddCount > 0  // (currentEntry.origIndex)! > (entries[trackIndex].origIndex)! //entry.x >= newXPosition
                       {
                           if currentEntry.origIndex == nil || entries[trackIndex].origIndex == nil
                           {
                               continue
                           }
                            let allowedToAppend = isSorted ?
                                (barPlot!.sortAscendingEnabled ? currentEntry.y >= entries[trackIndex].y : currentEntry.y <= entries[trackIndex].y)
                                : (currentEntry.origIndex)! > (entries[trackIndex].origIndex)!
                        
                            if allowedToAppend
                            {
                                var entryToAddCountCopy = entryToAddCount
                                var trackIndexCopy = trackIndex
                                
                                var entryAddedSoFarCount = 0
                                guard setIndexToEntryToAddCount[dataSetIndex] != nil
                                else { continue }
                                let indexEquivalentToNewRect = index + (setIndexToEntryToAddCount[dataSetIndex]! - entryToAddCount)
                            
                                
                            
                                while entryToAddCountCopy > 0 //(currentEntry.origIndex)! > (entries[trackIndexCopy].origIndex)! //entry.x >= newXPosition
                                {
                                    if currentEntry.origIndex == nil || entries[trackIndexCopy].origIndex == nil
                                    {
                                        continue
                                    }
                                    let allowedToAppend = isSorted ?
                                        (barPlot!.sortAscendingEnabled ? currentEntry.y >= entries[trackIndexCopy].y : currentEntry.y <= entries[trackIndexCopy].y)
                                        : (currentEntry.origIndex)! > (entries[trackIndexCopy].origIndex)!
                                    
                                     if allowedToAppend
                                     {
                                         trackIndexCopy += 1
                                         entryToAddCountCopy -= 1
                                         entryAddedSoFarCount += 1
                                     }
                                     else {
                                        break
                                    }
                                }
                            
                                let positionArray = newRectArray[dataSetIndex]
                                let addedEntry = entries[trackIndex]
                                trackIndex += 1
                                entryToAddCount -= 1
                                
                                let prevPosition = (indexEquivalentToNewRect - 1) >= 0 ? newRectArray[dataSetIndex][indexEquivalentToNewRect-1] : newRectArray[dataSetIndex][1]
                            
                                let nextPosition = (indexEquivalentToNewRect + entryAddedSoFarCount) >= positionArray.count ?  newRectArray[dataSetIndex][positionArray.count - 1] :  newRectArray[dataSetIndex][indexEquivalentToNewRect + entryAddedSoFarCount]
                                
                                var fromXValue = prevPosition.origin.x + ((nextPosition.origin.x - prevPosition.origin.x)/2)
                                var fromYValue = prevPosition.origin.y + ((nextPosition.origin.y - prevPosition.origin.y)/2)
                                
                                let toValue = newRectArray[dataSetIndex][indexEquivalentToNewRect]
                                
                                if set.plotType == .Line || set.plotType == .Area && (set.dataSetOptions as? LineDataSetOptions) != nil && (set.dataSetOptions as! LineDataSetOptions).mode == .stepped
                                {
                                    fromXValue = nextPosition.origin.x
                                    fromYValue = prevPosition.origin.y
                                }
                                
                                let xDiff = Interpolator.interpolate(a: Double(fromXValue), b: (Double(toValue.origin.x)))
                                let yDiff = Interpolator.interpolate(a: Double(fromYValue), b: (Double(toValue.origin.y)))
                                
                                setAddedEntriesXInterpolator.append(xDiff)
                                setAddedEntriesYInterpolator.append(yDiff)
                                
                                addedEntry.centerChanged = CGPoint(x: fromXValue, y: fromYValue)
                                
                                addedEntry.filterChanged = nil
                            }
                            else {
                                break
                            }
                       }
                    
                       guard setIndexToEntryToAddCount[dataSetIndex] != nil
                       else { continue }
                       entryIndex = index + (setIndexToEntryToAddCount[dataSetIndex]! - entryToAddCount)

                       let xDiff = Interpolator.interpolate(a: Double(oldRectArray[dataSetIndex][index].origin.x), b: (Double(newRectArray[dataSetIndex][entryIndex].origin.x)))
                       let yDiff = Interpolator.interpolate(a: Double(oldRectArray[dataSetIndex][index].origin.y), b: (Double(newRectArray[dataSetIndex][entryIndex].origin.y)))
                       let widthDiff = Interpolator.interpolate(a: Double(oldRectArray[dataSetIndex][index].size.width), b: (Double(newRectArray[dataSetIndex][entryIndex].size.width)))
                       let heightDiff = Interpolator.interpolate(a: Double(oldRectArray[dataSetIndex][index].size.height), b: (Double(newRectArray[dataSetIndex][entryIndex].size.height)))
                    
                       let valDiff = CustomRectInterpolator(x: xDiff, y: yDiff, width: widthDiff, height: heightDiff)
                       
                       if let oldDataSetArray = oldExtraDataSetArray, let newDataSetArray = newExtraDataSetArray {
                           
                           if let oldEntryRectArray = oldDataSetArray[safe:index], let newEntryRectArray = newDataSetArray[safe: entryIndex] {
                               setEntriesRectInterpolatorForExtras.append(getRectInterPolatorForEntry(oldEntryRect: oldEntryRectArray, newEntryRect: newEntryRectArray))
                           }
                       }
                       
                       setEntriesRectInterpolator.append(valDiff)
                   }
                   
                   if  entryToAddCount > 0
                   {
                       for addedEntryIndex in 0..<(entryToAddCount)
                       {
                           let positionArray = newRectArray[dataSetIndex]
                           let addedEntry = entries[trackIndex]
                           trackIndex += 1
                           
                           let lastEntryIndex = (positionArray.count - 1 - entryToAddCount) >= 0 ? (positionArray.count - 1 - entryToAddCount) : 0
                           
                           let prevPosition = newRectArray[dataSetIndex][lastEntryIndex]
                           let nextPosition = newRectArray[dataSetIndex][lastEntryIndex]
                           
                           let fromXValue = prevPosition.origin.x + ((nextPosition.origin.x - prevPosition.origin.x)/2)
                           let fromYValue = prevPosition.origin.y + ((nextPosition.origin.y - prevPosition.origin.y)/2)
                           
                           let toEntryIndex = (lastEntryIndex+addedEntryIndex+1) > (positionArray.count-1) ? (positionArray.count-1) : (lastEntryIndex+addedEntryIndex+1)
                           let toValue = newRectArray[dataSetIndex][toEntryIndex]
                           
                           let xDiff = Interpolator.interpolate(a: Double(fromXValue), b: (Double(toValue.origin.x)))
                           let yDiff = Interpolator.interpolate(a: Double(fromYValue), b: (Double(toValue.origin.y)))
                           
                           setAddedEntriesXInterpolator.append(xDiff)
                           setAddedEntriesYInterpolator.append(yDiff)
                           
                           addedEntry.centerChanged = CGPoint(x: fromXValue, y: fromYValue)
                           
                           addedEntry.filterChanged = nil
                       }
                   }
                   
                   rectInterpolateArray.append(setEntriesRectInterpolator)
                   xAddedEntryInterpolateArray.append(setAddedEntriesXInterpolator)
                   yAddedEntryInterpolateArray.append(setAddedEntriesYInterpolator)
                   extraInterpolatateArray.append(setEntriesRectInterpolatorForExtras)
               }
           
               var sliceAnimator:Animator! = Animator()
                   
               if sliceAnimator != nil
               {
                   sliceAnimator.stop()
               }
               
               sliceAnimator = Animator()
               
               sliceAnimator.updateBlock = {
                   
                   setForcedValue(axisChartBase: chart, enable: true)
                   
                   var interpolatorIndex:Int = 0
                   
                   guard (chart.data?.dataSetCount) != nil
                   else { return }
                   for dataSetIndex in 0..<(chart.data?.dataSetCount)!
                   {
                       guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
                       else { continue }
                       
                       if !(set.isVisible)
                       {
                           continue
                       }
                       
                       interpolatorIndex = 0
                       
                       for index in stride(from: 0, to: set.entryCount, by: 1)
                       {
                           let newEntry = oldEntries[dataSetIndex][index]
                           
                           let oldRect = oldRectArray[dataSetIndex][index]
                           
                           var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                           
                           var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                           
                           let newXVal = rectInterpolateArray[dataSetIndex][interpolatorIndex].x(sliceAnimator.phaseX)
                           let newYVal = rectInterpolateArray[dataSetIndex][interpolatorIndex].y(sliceAnimator.phaseX)
                           let newWidth = rectInterpolateArray[dataSetIndex][interpolatorIndex].width(sliceAnimator.phaseX)
                           let newHeight = rectInterpolateArray[dataSetIndex][interpolatorIndex].height(sliceAnimator.phaseX)
                           
                           newCenter.x = CGFloat(newXVal)
                           newCenter.y = CGFloat(newYVal)
                           newSize.width = CGFloat(newWidth)
                           newSize.height = CGFloat(newHeight)
                       
                           newEntry.centerChanged = newCenter
                           
                           newEntry.sizeChanged = newSize
                           
                           if let extraInterpolator = extraInterpolatateArray[safe:dataSetIndex], let extraEntryInterpolatorArray = extraInterpolator[safe:interpolatorIndex] {
                               newEntry.filterChanged = filterChangedInterpolatedValues(interpolationArray: extraEntryInterpolatorArray, animator: sliceAnimator)
                           }
                           
                           interpolatorIndex = interpolatorIndex + 1
                       }
                   }
                   
                   animateTickLabelModel(chart: chart, phaseX: sliceAnimator.phaseX, oldAxisTickLabelMobelObject: oldTicklabelModels, newAxisTickLabelMobelObject: newTicklabelModels, oldAxisTickLabelPositionsObject: oldTicklabelPositionArray, newAxisTickLabelPositionsObject: newTicklabelPositionArray)
                   
                   animateViewPort(chart: chart, fromViewPortRect: fromViewPortRect, toViewPortRect: toViewPortRect, fromChartSize: fromChartSize, toChartSize: toChartSize, phaseX: sliceAnimator.phaseX)
                   
                   chart.setNeedsDisplay()
                   
               }
               
               sliceAnimator.stopBlock = { [weak sliceAnimator] in
                   
                   sliceAnimator?.updateBlock = nil
                   
                   let animDuration = duration * 0.3
                   
                   var allowed = true
                   
                   var typeAllowed:[ChartType] = []
                   
                   for plot in chart.plotTypes
                   {
                       if plot != .Line && plot != .Area && plot != .Radar && plot != .WaterFall && plot != .BoxPlot
                       {
                           typeAllowed.append(plot)
                       }
                   }
                   
                   setForcedOpacityValue(axisChartBase: chart, enable: false)
    
                   setForcedValue(axisChartBase: chart, types: typeAllowed, enable: false)
                
                   chartData.xStringOrder = toStringOrder
                
                   ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
                   
                 //  ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: chart)

                   chart.notifyDataSetChanged(redrawRequired: false)
                
                   // BAR
                   // To make percentage rise animation
                   var processor = ChartInteractionHelperFunction.getBarPreprocessor(barChart: chart)
                   
                   var stackInterpolateArray:[((Double) -> Double)] = []
                   
                   var stackedSizeInterpolator:[((Double) -> Double)] = []
                   
                   var currentShapeSize:CGFloat = 0

                   for entry in entries
                   {
                       let set =  chart.data?.getDataSetForEntry(entry)
                       if set?.plotType == .Bar || set?.plotType == .Bullet || set?.plotType == .Mekko
                       {
                           let yInterpolator = Interpolator.interpolate(a: 0, b: entry.y)
                           stackInterpolateArray.append(yInterpolator)
                           entry.y = 0
                       }
                       else if set?.plotType == .Bubble || set?.plotType == .Scatter || set?.plotType == .BubblePie
                       {
                            guard let plotOptions = chart.getPlotOptions(type: set!.plotType) as? AxisChartPlotOptions
                           else { continue }
                           
                           currentShapeSize = plotOptions.maximumShapeSizeInPixel != 0 ? plotOptions.maximumShapeSizeInPixel :  (set?.dataSetOptions as? AxisChartDataSetOptions)?.shapeProperties.size.width ?? 0
                           
                           entry.isIncluded = true
                           entry.barYValue = chart.isRotated ? chart.viewPortHandler.contentLeft - currentShapeSize : chart.viewPortHandler.contentBottom + currentShapeSize
                       }
                       else if set?.plotType == .WaterFall {
                           
                           if set == nil || !set!.isVisible  {
                               continue
                           }
                           
                           processor = CommonHelperFunctions.getProcessor(chart: chart, types: [.WaterFall]) as? WaterFallPreprocessor
                           
                           allowed = false
                           
                           guard let plotOptions = chart.getPlotOptions(type: set!.plotType) as? AxisChartPlotOptions
                           else { continue }
                           
                           guard let setIndex = chart.data?.indexOfDataSet(set!),
                           
                           let entryIndex = chart.data?.dataSets[setIndex].entryIndex(entry: entry)
                           else { continue }
                           
                           var yInterpolator: ((Double) -> Double)
                           
                           var sizeInterpolator: ((Double) -> Double)
                           
                           var currentYvalue = 0.0
                           
                           let transformer = chart.getTransformer(axisIndex: set!.axisIndex)
                           
                           if plotOptions.isStacked {
                               
                               currentYvalue = WaterFallHelperFunction.getBaseValue(chart: chart, entry: entry)
                           }
                           
                           if chart.isRotated {
                               
                               sizeInterpolator = Interpolator.interpolate(a: Double(0.0), b: Double(newRectArray[setIndex][entryIndex].width))
                               
                               if plotOptions.isStacked {
                                   
                                   var basePoint = CGPoint(x: currentYvalue, y: 0.0)
                                   
                                   transformer.pointValueToPixel(&basePoint)
                                   
                                   yInterpolator = Interpolator.interpolate(a: basePoint.x, b: Double(newRectArray[setIndex][entryIndex].minX))
                                   
                               }
                               else {
                                   
                                   yInterpolator = Interpolator.interpolate(a: Double(newRectArray[setIndex][entryIndex].minX), b: Double(newRectArray[setIndex][entryIndex].minX))
                               
                                   if entry.y < 0 {
                                       yInterpolator = Interpolator.interpolate(a: Double(newRectArray[setIndex][entryIndex].maxX), b: Double(newRectArray[setIndex][entryIndex].minX))
                                   }
                               }
                               
                           }
                           else {
                               
                               sizeInterpolator = Interpolator.interpolate(a: Double(0.0), b: Double(newRectArray[setIndex][entryIndex].height))
                               
                               
                               if plotOptions.isStacked {
                                   
                                   var basePoint = CGPoint(x: 0.0, y: currentYvalue)
                                   
                                   transformer.pointValueToPixel(&basePoint)
                                   
                                   yInterpolator = Interpolator.interpolate(a: basePoint.y, b: Double(newRectArray[setIndex][entryIndex].minY))
                                   
                               }
                               else {
                                   yInterpolator = Interpolator.interpolate(a: Double(newRectArray[setIndex][entryIndex].maxY), b: Double(newRectArray[setIndex][entryIndex].minY))
                               
                                   if entry.y < 0 {
                                       yInterpolator = Interpolator.interpolate(a: Double(newRectArray[setIndex][entryIndex].minY), b: Double(newRectArray[setIndex][entryIndex].minY))
                                   }
                               }
                           }
                           
                           stackInterpolateArray.append(yInterpolator)
                           
                           entry.centerChanged = CGPoint(x: 0.0, y: 0.0)
                           
                           entry.sizeChanged = CGSize(width: 0.0, height: 0.0)
                           
                           stackedSizeInterpolator.append(sizeInterpolator)
                           
                       }
                       else if set?.plotType == .BoxPlot {
                           
                           if set == nil || !set!.isVisible  {
                               continue
                           }
                           
                           processor = CommonHelperFunctions.getProcessor(chart: chart, types: [.BoxPlot]) as? BoxPlotPreprocessor
                           
                           allowed = false
                           
                           guard let setIndex = chart.data?.indexOfDataSet(set!),
                           
                           let entryIndex = chart.data?.dataSets[setIndex].entryIndex(entry: entry)
                           else { continue }
                           
                           var yInterpolator: ((Double) -> Double)
                           
                           var sizeInterpolator: ((Double) -> Double)
                           
                           if chart.isRotated {
                               
                               sizeInterpolator = Interpolator.interpolate(a: Double(0.0), b: Double(newRectArray[setIndex][entryIndex].width))
                               
                                   
                               yInterpolator = Interpolator.interpolate(a: Double(newRectArray[setIndex][entryIndex].minX), b: Double(newRectArray[setIndex][entryIndex].minX))
                           }
                           else {
                               
                               sizeInterpolator = Interpolator.interpolate(a: Double(0.0), b: Double(newRectArray[setIndex][entryIndex].height))
                               
                                yInterpolator = Interpolator.interpolate(a: Double(newRectArray[setIndex][entryIndex].maxY), b: Double(newRectArray[setIndex][entryIndex].minY))
                           }
                           
                           stackInterpolateArray.append(yInterpolator)
                           
                           entry.centerChanged = CGPoint(x: 0.0, y: 0.0)

                           entry.sizeChanged = CGSize(width: 0.0, height: 0.0)
                           
                           entry.filterChanged = [CGRect(),CGRect(),CGRect()] as AnyObject
                           
                           stackedSizeInterpolator.append(sizeInterpolator)
                       }
                   }
                   
                   processor?.updateEntriesStackValue()
                   
                   
                   // Scatter Bubble
                   
                   var visibleDataSetCount:Double = 0
                   
                   var entryLocation:[CGPoint] = []
                   
                   var allEntryAtIndex:[ChartDataEntry] = []
                   
                   guard (chart.data?._dataSets) != nil
                   else { return }
                   for set in (chart.data?._dataSets)!
                   {
                       if set.isVisible && (set.plotType == .Scatter || set.plotType == .Bubble || set.plotType == .BubblePie)
                       {
                           for setEntry in (set as! ChartDataSet).values where setEntry.origX != nil && uniqueXValues.contains(setEntry.origX!) // .entriesForXValue(newXPosition)
                           {
                               if setEntry.y.isNaN
                               {
                                   continue
                               }
                               allEntryAtIndex.append(setEntry)
                           }
                           visibleDataSetCount += 1
                       }
                   }
                   
                   allEntryAtIndex.sort(by: { $0.y < $1.y})
                   
                   let totalDuration = duration/2
                   
                   let duration:Double = totalDuration/Double(allEntryAtIndex.count)
                   
                   for entry in allEntryAtIndex
                   {
                       guard let loc = CommonHelperFunctions.getEntryLocation(chart: chart, entry: entry)
                       else { continue }
                       entryLocation.append(loc)
                   }
                   
                   if let notes = chart.notes {
                       setNoteEntriesFilterEnabledValue(notes: notes, entries: entries, enable: false)
                   }
                   
                   chart.updateNoteEntries()
                   
                   let entryAnimator = Animator()
                   
                   entryAnimator.updateBlock = { [unowned chart] in
                       
                       // BAR
                       var stackIndex = -1
                       for entry in entries
                       {
                           let set =  chart.data?.getDataSetForEntry(entry)
                           if set?.plotType == .Bar || set?.plotType == .Bullet || set?.plotType == .Mekko
                           {
                               stackIndex += 1
                               entry.y = stackInterpolateArray[stackIndex](entryAnimator.phaseX)
                           }
                           
                           if set?.plotType == .WaterFall || set?.plotType == .BoxPlot {
                               
                               if !set!.isVisible {
                                   continue
                               }
                               
                               stackIndex += 1
                               
                               guard let setIndex = chart.data?.indexOfDataSet(set!),
                               
                               let entryIndex = chart.data?.dataSets[setIndex].entryIndex(entry: entry)
                               else { continue }
                               
                               if chart.isRotated {
                                   entry.centerChanged = CGPoint(x: stackInterpolateArray[stackIndex](entryAnimator.phaseX), y: newRectArray[setIndex][entryIndex].origin.y)
                               
                                   entry.sizeChanged = CGSize(width: stackedSizeInterpolator[stackIndex](entryAnimator.phaseX) , height: newRectArray[setIndex][entryIndex].height)
                               }
                               else {
                                   entry.centerChanged = CGPoint(x: newRectArray[setIndex][entryIndex].origin.x, y: stackInterpolateArray[stackIndex](entryAnimator.phaseX))
                               
                                   entry.sizeChanged = CGSize(width: newRectArray[setIndex][entryIndex].width, height: stackedSizeInterpolator[stackIndex](entryAnimator.phaseX))
                               }
                               
                               if set?.plotType == .BoxPlot {
                                   let entryInterpolator = getRectInterPolatorForIncludeEntry(chart: chart, oldEntryRect: newFilterArray[setIndex][entryIndex], filterRect: newRectArray[setIndex][entryIndex])
                                   
                                   entry.filterChanged = filterChangedInterpolatedValues(interpolationArray: entryInterpolator, animator: entryAnimator)
                               }
                           }
                       }
                       
                       
                       processor?.updateEntriesStackValue()
                       
                       // LINE
                       if allowed {
                       
                           trackIndex = 0
                           for setInterPolatorIndex in 0..<xAddedEntryInterpolateArray.count
                           {
                               if (chart.data?.dataSets[setInterPolatorIndex].isVisible) == nil
                               {
                                   continue
                               }
                               if !((chart.data?.dataSets[setInterPolatorIndex].isVisible)!)
                               {
                                   guard let entryToAddCount = setIndexToEntryToAddCount[setInterPolatorIndex]
                                   else { continue }
                              
                                   trackIndex += entryToAddCount
                                   continue
                               }
                          
                               let setXInterPolator = xAddedEntryInterpolateArray[setInterPolatorIndex]
                               let setYInterPolator = yAddedEntryInterpolateArray[setInterPolatorIndex]
                          
                               for entryInterpolatorIndex in 0..<setXInterPolator.count
                               {
                                   let entryXInterPolator = setXInterPolator[entryInterpolatorIndex]
                                   let entryYInterPolator = setYInterPolator[entryInterpolatorIndex]
                              
                                   let xValue = entryXInterPolator(entryAnimator.phaseX)
                                   let yValue = entryYInterPolator(entryAnimator.phaseX)
                              
                                   entries[trackIndex].centerChanged = CGPoint(x: xValue, y: yValue)
                                   trackIndex += 1
                               }
                           }
                       
                       
                           // Scatter Bubble
                           for entryIndex in 0..<allEntryAtIndex.count
                           {
                               let entry = allEntryAtIndex[entryIndex]
                               let endTime = (duration * Double(entryIndex+1))
                               let startTime = endTime - duration
                               let currentTime = (entryAnimator.phaseX) * totalDuration
                               
                               if currentTime > endTime{
                                   entry.barYValue = chart.isRotated ? entryLocation[entryIndex].x : entryLocation[entryIndex].y
                               }
                               else if currentTime < startTime
                               {
                                   entry.barYValue = chart.isRotated ? chart.viewPortHandler.contentLeft - currentShapeSize : chart.viewPortHandler.contentBottom + currentShapeSize
                               }
                               else{
                                   let difference = currentTime - startTime
                                   var percent = CGFloat(difference/duration)
                                   if percent > 1
                                   {
                                       percent = 1
                                   }
                                   
                                   let yToDecrease = chart.isRotated ? percent * (entryLocation[entryIndex].x - (chart.viewPortHandler.contentLeft - currentShapeSize)) : percent * ((chart.viewPortHandler.contentBottom + currentShapeSize) - entryLocation[entryIndex].y)
                                   entry.barYValue = chart.isRotated ? (chart.viewPortHandler.contentLeft - currentShapeSize) + yToDecrease : (chart.viewPortHandler.contentBottom + currentShapeSize) - yToDecrease
                                   
                               }
                           }
                       }
                       
                       if let notes = chart.notes {
                           
                           opacityAnimationForNoteEntries(notes: notes, entries: entries,isHide: false, animation: entryAnimator)
                       }
                         
                       chart.setNeedsDisplay()
                   }
                   
                   entryAnimator.stopBlock = { [unowned entryAnimator] in
                       
                       entryAnimator.updateBlock = nil
                       
                       // Line forced value needs to be falsed
                       setForcedValue(axisChartBase: chart, enable: false)
                       
                       chart.interactionAnimationInProgress = false
                       
                       for entry in entries
                       {
                           entry.isIncluded = false
                       }
                       
       //                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
                     //  ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
                       chart.notifyDataSetChanged(redrawRequired: true)
                       
//                       chart.enableDrawValues()
                       
                       CommonHelperFunctions.enableIncludeLayer(chart: chart)
                       
                       sliceAnimator = nil
                       
//                       chart.updateNoteEntries()
//
//                       if let notes = chart.notes {
//                           setNoteEntriesFilterEnabledValue(notes: notes, entries: entries, enable: true)
//                       }
                       
                       chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: entries, dataSets: nil, dataSetAdded: false)

                   }
                   
                   entryAnimator.animate(xAxisDuration: animDuration, easingOption: .linear)
               }
               
               sliceAnimator.animate(xAxisDuration: duration * 0.7, easingOption: .linear)
   }
    
    public static func opacityAnimationForNoteEntries(notes: Notes, entries: [ChartDataEntry], isHide: Bool, animation: Animator) {
        
        for noteEntry in notes.noteEntries {
            
            guard let entry = noteEntry.noteEntryData else {
                continue
            }
            
            if entries.contains(entry) {
                noteEntry.opacityChanged = isHide ? Interpolator.interpolate(a: 1.0, b: 0.0)(animation.phaseX) : Interpolator.interpolate(a: 0.0, b: 1.0)(animation.phaseX)
            }
        }
    }
    
    internal static func setNoteEntriesFilterEnabledValue(notes: Notes, entries: [ChartDataEntry], enable: Bool) {
        
        for noteEntry in notes.noteEntries {
            
            guard let entry = noteEntry.noteEntryData else {
                continue
            }
            
            if entries.contains(entry) {
                noteEntry.notesFilterEnabled = enable
            }
        }
    }
    
    public static func setForcedValue(axisChartBase: ChartViewBase, enable:Bool) {
        
        setForcedValue(axisChartBase: axisChartBase, types: axisChartBase.plotTypes, enable: enable)
        
        setForcedOpacityValue(axisChartBase: axisChartBase, enable: enable)

    }
    
    static func setForcedOpacityValue(axisChartBase: ChartViewBase, enable: Bool) {
        
        for chart in axisChartBase.renderers{
            chart.customOpacity = enable
        }
        
    }
    
    static func SetFoucedStackedSumValue(axisChartBase: ChartViewBase,enable: Bool) {
        
        if let plotOption = CommonHelperFunctions.getPlotOption(chart: axisChartBase, types: [.Bar,.WaterFall]) as? BarPlotOptions {
        
            if plotOption.stackedSumEnabled {
                plotOption.isStackedSumEnabled = enable
            }
        }
    }
    
    public static func setForcedValue(axisChartBase: ChartViewBase, types:[ChartType], enable:Bool) {
        
        for plotType in types
        {
            switch plotType {
                case .Bar,.WaterFall,.Mekko,.BoxPlot:
                    let barRenderer = (CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [plotType]) as? BarChartRenderer)
                
                    SetFoucedStackedSumValue(axisChartBase: axisChartBase,enable: !enable)
                    
                    barRenderer?.barDeleted = enable
                    break
                
                case .Line, .Radar, .LineRange:
                    let lineRenderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [plotType])
                    lineRenderer?.useForcedValue = enable
                    break
                
                case .Area:
                    let areaRenderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [plotType]) as? AreaChartRenderer
                    areaRenderer?.useForcedValue = enable
                    break
                
                case .Scatter:
                    let renderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [.Scatter]) as? ScatterChartRenderer
                    renderer?.entryDeleted = enable
                
                
                case .Bubble:
                    let renderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [.Bubble]) as? BubbleChartRenderer
                    renderer?.entryDeleted = enable
                    
                case .BubblePie:
                    let renderer = CommonHelperFunctions.getRenderer(chart: axisChartBase, types: [.BubblePie]) as? BubblePieChartRenderer
                    renderer?.entryDeleted = enable
                
                default:
                    break
            }
        }
    }
    
    public static func combinedLegendDisabled(chart:ChartViewBase, indexPath: IndexPath, entry: LegendEntry) {
        Log.info("Container::LegendDisabled ")
        
        guard (chart.data?.dataSetCount) != nil
        else { return }
        if ((chart.data?.dataSetCount)! - chart.removedCount) > 1
        {
              chart.interactionAnimationInProgress = true
              chart.removedCount += 1
            
              guard let set = (chart.data?.dataSets[indexPath.item])
            else { return }
            
              CommonHelperFunctions.hideDataSet(selectedDataset: [set], chart: chart)
            
            //            self.resizeAxisIfNeeded()
        }
    }
}

extension ChartInteractionHelperFunction {
    
    
    // MARK: - Hide and align animation
    
    public static func
    hideAndAlignDataSet(chart: ChartViewBase, selectedDataset: [IChartDataSet], animationOptions: animationOptions, exitDuration: Double) {
        
        guard let chartData = chart.data else {
            return
        }
        
        let dataSets = chartData.dataSets
        
        // Since new entries may adjust touch matrix when last entry filtered
        let lastTouchMatrix = chart.viewPortHandler._touchMatrix
        
        var originalVal:[Double] = []
        
        if selectedDataset.contains(where: { $0.plotType == .BubblePie }){
            
            for setIndex in 0..<selectedDataset.count{
                
                if selectedDataset[setIndex].plotType == .BubblePie{
                    
                    for entryIndex in 0..<selectedDataset[setIndex].entryCount{
                        
                        guard let entry = selectedDataset[setIndex].entryForIndex(entryIndex),
                              (entry.plotData as? Double) != nil
                        else {
                            continue
                        }
                        
                        originalVal.append(CGFloat(entry.plotData as! Double))
                        
                    }
                }
                
            }
        }
        
        var initialAlignRectArray: [[CGRect]] = Array(repeating: [CGRect](), count: dataSets.count)
        
        var entryForSet: [Int:[ChartDataEntry]] = [Int:[ChartDataEntry]]()
        
        if animationOptions == .StackedBaralign {
        
            let barLayer = BarLayer.getAllBarLayer(chart: chart)
            
            var tempSet: [Int] = [Int]()
        
            for layer in barLayer {
            
                guard layer.barDataSet != nil
                else { continue }
                let dataSetIndex = chartData.indexOfDataSet(layer.barDataSet!)
            
                if !tempSet.contains(where: {$0 == dataSetIndex}) {
                    tempSet.append(dataSetIndex)
                }
            
                if let path = layer.path{
                    initialAlignRectArray[dataSetIndex].append(path.boundingBox)
                }
                
                if let entry = layer.chartEntry {
                    if entryForSet[dataSetIndex] == nil {
                        entryForSet[dataSetIndex] = [entry]
                    }
                    else{
                        entryForSet[dataSetIndex]?.append(entry)
                    }
                }
            }
        }
        
        let oldBaseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: selectedDataset[0])
        
        let oldPosition = chart.pixelForValues(point: CGPoint(x: 0.0, y: oldBaseLineValue), axisIndex: selectedDataset[0].axisIndex)
        
        let oldBaseValue = chart.isRotated ? oldPosition.x : oldPosition.y
        
        let oldRectArray = prepareRectArrayforAllDataset(chart: chart)
        
        let oldFilterArray = prepareArrayForFilterValues(chart: chart)
        
        let oldTicklabelModels = prepareTickLabelModels(chart: chart)
        
        let fromViewPortRect = chart.viewPortHandler.contentRect
        let fromChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
        
        for set in selectedDataset
        {
            set.visible = false
        }

        chart.lastSelected = nil
        
        chart.includeLayer = true

        CommonHelperFunctions.updateMatrix(chart: chart)
        
        var barRectArray: [[CGRect]] = [[CGRect]]()
        var lineRectArray: [[CGRect]] = [[CGRect]]()
        var areaRectArray: [[CGRect]] = [[CGRect]]()
        
        if BarHelperFunctions.isStacked(chart: chart) {
        
            let barDataSets:[IChartDataSet] = chartData.dataSets.filter({
                ($0.plotType == .Bar || $0.plotType == .WaterFall || $0.plotType == .Mekko) && ($0.isVisible) && $0.entryCount > 0
                      })
        
            barDataSets.forEach({
                
                if $0.plotType == .Bar || $0.plotType == .Mekko {
                    barRectArray.append(BarHelperFunctions.prepareDataSetArray(selectedDataset: $0, chart: chart))
                }
                else{
                    barRectArray.append(WaterFallHelperFunction.prepareDataSetArray(selectedDataset: $0, chart: chart))
                }
                
            })
        }
        
        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: selectedDataset[0])
        
        var position = chart.pixelForValues(point: CGPoint(x: 0.0, y: baseLineValue), axisIndex: selectedDataset[0].axisIndex)
        
        var newBaseValue = chart.isRotated ? position.x : position.y
        
        if chart.plotTypes.contains(.Radar) {
            
            if let plotOption = chart.getPlotOptions(type: .Radar) as? DialPlotOptions {
                position = plotOption.centerCircleBox
                newBaseValue = position.y
            }
        
        }
        
        var (initalDatasetForStackedLine,initalInterpolatorForStackedLine) = ([IChartDataSet](),[[CustomRectInterpolator]]())
        var (initalDatasetForStackedArea,initalInterpolatorForStackedArea) = ([IChartDataSet](),[[CustomRectInterpolator]]())
        var initialInterpolatorForArea = [[CustomRectInterpolator]]()
        
        if chart.plotTypes.contains(.Line) || chart.plotTypes.contains(.Radar) {
            
            if let linePlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line,.Radar]) as? PlotOptionsBase
            {
                
                let lineDataSets:[IChartDataSet] = chartData.dataSets.filter({
                    ($0.plotType == .Line || $0.plotType == .Radar ) && ($0.isVisible) && $0.entryCount > 0
                          })
            
                lineDataSets.forEach({
                    lineRectArray.append(LineHelperFunctions.prepareDataSetArray(selectedDataset: $0, chart: chart))
                })
                
                if linePlot.isStacked {
                    (initalDatasetForStackedLine,initalInterpolatorForStackedLine) = prepareInitialRectForLineFillPath(isRotated: chart.isRotated, lineDataSet: lineDataSets, lineRect: lineRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
                }
//                else {
//                    initialInterpolatorForArea = prepareInitialRectForAreaFillPath(isRotated: chart.isRotated,lineDataSet: lineDataSets, lineRect: lineRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
//                }
            }
        }
        
        if chart.plotTypes.contains(.Area) {
            
            if let areaPlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Area]) as? PlotOptionsBase
            {
                
                let areaDataSets:[IChartDataSet] = chartData.dataSets.filter({
                    ($0.plotType == .Area) && ($0.isVisible) && $0.entryCount > 0
                          })
            
                areaDataSets.forEach({
                    areaRectArray.append(LineHelperFunctions.prepareDataSetArray(selectedDataset: $0, chart: chart))
                })
                
                if areaPlot.isStacked {
                    (initalDatasetForStackedArea,initalInterpolatorForStackedArea) = prepareInitialRectForLineFillPath(isRotated: chart.isRotated, lineDataSet: areaDataSets, lineRect: areaRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
                }
                else {
                    initialInterpolatorForArea = prepareInitialRectForAreaFillPath(isRotated: chart.isRotated,lineDataSet: areaDataSets, lineRect: areaRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
                }
            }
        }
        
        let newRectArray = prepareRectArrayforAllDataset(chart: chart).filter( {$0.count > 0})
        
        let newFilterArray = prepareArrayForFilterValues(chart: chart).filter( {$0.count > 0})
        
        let oldTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: oldTicklabelModels)
        
        let newTicklabelModels = prepareTickLabelModels(chart: chart)
        
        let toViewPortRect = chart.viewPortHandler.contentRect
        let toChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
        
        for set in selectedDataset
        {
            set.visible = true
        }
        
        chart.includeLayer = true
        
        let xDataNil = chart.data?.xMin == Double.greatestFiniteMagnitude
        
        let yDataNil = chart.data?.yMin == Double.greatestFiniteMagnitude
        
        if !(xDataNil && yDataNil) {
            chart.viewPortHandler._touchMatrix = lastTouchMatrix
        }
        CommonHelperFunctions.updateMatrix(chart: chart)
        
        if (xDataNil && yDataNil) {
            chart.viewPortHandler._touchMatrix = lastTouchMatrix
            chart.notifyDataSetChanged(redrawRequired: false)
        }
        
        
        let newTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: newTicklabelModels)
        
        if animationOptions == .StackedBaralign {
            
            var newSetIndex = 0
            
            for setIndex in entryForSet.keys {
                
                var fromEntryIndex = 0
                
                if !dataSets[setIndex].isVisible || entryForSet[setIndex] == nil {
                    continue
                }
                
                for entry in entryForSet[setIndex]! {
                    
                    if initialAlignRectArray[newSetIndex].count <= fromEntryIndex{
                        break
                    }
                    /*
                    guard let entry = dataSets[setIndex].entryForIndex(entryIndex) else {
                        continue
                    }
                    */
                    if (entry.x.isNaN && entry.y.isNaN) || entry.y.isNaN {
                        
                        entry.sizeChanged = nil
                        
                        entry.centerChanged = nil
                        
                        continue
                    }
                    
                    entry.centerChanged = initialAlignRectArray[newSetIndex][fromEntryIndex].origin
                    
                    entry.sizeChanged = initialAlignRectArray[newSetIndex][fromEntryIndex].size
                    
                    fromEntryIndex += 1
                }
                
                newSetIndex += 1
            }
        }
        
        if chart.plotTypes.contains(.LineRange) {
            initalInterpolatorForStackedLine = prepareHideInterpolationForLineRange(dataSets: dataSets,  selectedDataset: selectedDataset, oldRect: oldRectArray, newRect: newRectArray)
        }
        
        guard let (rectInterpolator,opacityInterpolator,stackedBarInterpolator,bubblePieInterpolator) = prepareInterpolationForHideAnimation(oldDataSetArray: oldRectArray, newDataSetArray: newRectArray, chart: chart, selectedDataset: selectedDataset, barRectArray: barRectArray, lineRectArray: lineRectArray, areaRectArray: areaRectArray, baseLineValue: position) else {
            return
        }
        
        let extraInterpolator = prepareHideInterpolationForExtras(chart: chart, oldRect: oldFilterArray, newRect: newFilterArray, oldFinalRect: oldRectArray, selectedDataset: selectedDataset)
        
        //MARK: align animation
        
        let alignBlock = {
               
               let alignAnimator = Animator()

               alignAnimator.updateBlock = {

                   setForcedValue(axisChartBase: chart, enable:true)

                   var rectInterpolatorIndex = 0
                   
                   var newRectIndex = 0
                   
                   var stackedInterpolatorIndex = 0
                   
                   var areaDatasetIndex = 0
                   
                   var lineRangeDatasetIndex = 0

                   for setIndex in 0..<dataSets.count {

                       if !dataSets[setIndex].visible || dataSets[setIndex].entryCount <= 0 || oldRectArray[setIndex].isEmpty {
                           continue
                       }
                       
                       if selectedDataset.contains(where: { $0 === dataSets[setIndex] }){
                           
                           if dataSets[setIndex].plotType == .Line || dataSets[setIndex].plotType == .Radar || dataSets[setIndex].plotType == .Area {
                           
                               if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? PlotOptionsBase {
                      
                                   if plotOption.isStacked {
                                       positionAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator,originVal: 2)
                                   }
                               }
                           }
                           
                           if BarHelperFunctions.typeAllowed.contains(dataSets[setIndex].plotType) {
                               for entryIndex in 0..<dataSets[setIndex].entryCount {
                                   
                                   guard let entry = dataSets[setIndex].entryForIndex(entryIndex) else {
                                       continue
                                   }
                                   
                                   entry.opacityChanged = 0.0
                               }
                           }
                           
                           rectInterpolatorIndex += 1
                           continue
                       }
                       
                       var isStacked = false

                       switch dataSets[setIndex].plotType {

                        case .Bar,.WaterFall,.Mekko:
                           
                                if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {
                                   
                           
                                   if plotOption.isStacked{
                                   
                                       let initialRectArray = prepareinitialRectForHideAnim(chart: chart,oldDataSetArray: oldRectArray[setIndex] ,newDataSetArray: newRectArray[newRectIndex])
                               
                                       barAnimation(oldDatasetRectArray: initialRectArray, interpolation: stackedBarInterpolator[stackedInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                   
                                       isStacked = true
                                   
                                   }
                                   else{
                                       barAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                   }
                               }

                               break

                        case .Line,.Scatter,.BubblePie,.Radar,.LineRange,.Area:

                                positionAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator,originVal: 2)
                           
                                if dataSets[setIndex].plotType == .LineRange {
                               
                                    if let interpolator = initalInterpolatorForStackedLine[safe:lineRangeDatasetIndex] {
                                        positionAnimationForLine(oldDatasetRectArray: oldRectArray[setIndex],interpolation: interpolator, chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                    }
                                    lineRangeDatasetIndex += 1
                                }
                           
                                if dataSets[setIndex].plotType == .Line {
                           
                                    if let linePlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? LinePlotOptions {
                      
                                        if linePlotOption.isStacked {
                                        
                                            var index = -1
                                            
                                            for lineDatasetIndex in 0..<initalDatasetForStackedLine.count {
                                                
                                                if initalDatasetForStackedLine[lineDatasetIndex] === dataSets[setIndex] {
                                                    index = lineDatasetIndex
                                                }
                                            }
                                            
                                            if index > -1{
                                                
                                                let oldRect = getInitialRectForLineFillPath(isRotated: chart.isRotated, oldRect: oldRectArray[setIndex], BaseValue: oldBaseValue)
                                                
                                                positionAnimationForLine(oldDatasetRectArray: oldRect, interpolation: initalInterpolatorForStackedLine[index], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                            }
                                        
                                        }
                                    }
                                }
                           
                            if dataSets[setIndex].plotType == .Area {
                      
                               if let areaPlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? LinePlotOptions {
                 
                                   if areaPlotOption.isStacked {
                                   
                                       var index = -1
                                       
                                       for lineDatasetIndex in 0..<initalDatasetForStackedArea.count {
                                           
                                           if initalDatasetForStackedArea[lineDatasetIndex] === dataSets[setIndex] {
                                               index = lineDatasetIndex
                                           }
                                       }
                                       
                                       if index > -1{
                                           
                                           let oldRect = getInitialRectForLineFillPath(isRotated: chart.isRotated, oldRect: oldRectArray[setIndex], BaseValue: oldBaseValue)
                                           
                                           positionAnimationForLine(oldDatasetRectArray: oldRect, interpolation: initalInterpolatorForStackedArea[index], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                       }
                                   
                                   }
                                   else {
                                       if let lineDatasetOption = dataSets[setIndex].dataSetOptions as? LineDataSetOptions {
                                           
                                           if lineDatasetOption.isDrawFilledEnabled {
                                               
                                               let oldRect = getInitialRectForLineFillPath(isRotated: chart.isRotated, oldRect: oldRectArray[setIndex], BaseValue: oldBaseValue)
                                               
                                               if let interpolator = initialInterpolatorForArea[safe:areaDatasetIndex] {
                                                   positionAnimationForLine(oldDatasetRectArray: oldRect, interpolation: interpolator, chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                               }
                                               areaDatasetIndex += 1
                                           }
                                       }
                                   }
                               }
                           }

                               break

                            case .Bubble,.PackedBubble:
                           
                               barAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)

                               break
                           
                            case .BoxPlot:
                      
                                barAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                      
                                whiskersAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: extraInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)

                                break

                        default:
                            break
                       }

                       rectInterpolatorIndex += 1
                       
                       newRectIndex += 1
                       
                       if isStacked {
                           stackedInterpolatorIndex += 1
                       }
                       
                   }
                   
                   mergeTickLabelModel(chart: chart, ticklabelModelObject: newTicklabelModels)
                   
                   animateTickLabelModel(chart: chart, phaseX: alignAnimator.phaseX, oldAxisTickLabelMobelObject: oldTicklabelModels, newAxisTickLabelMobelObject: newTicklabelModels, oldAxisTickLabelPositionsObject: oldTicklabelPositionArray, newAxisTickLabelPositionsObject: newTicklabelPositionArray)
                   
                   animateViewPort(chart: chart, fromViewPortRect: fromViewPortRect, toViewPortRect: toViewPortRect, fromChartSize: fromChartSize, toChartSize: toChartSize, phaseX: alignAnimator.phaseX)

                   chart.setNeedsDisplay()

               }
            
            alignAnimator.stopBlock = { [unowned alignAnimator] in
                alignAnimator.updateBlock = nil
            }

               alignAnimator.animate(xAxisDuration: exitDuration / 2)
        }
        
        //MARK: hide and align animation
        
        let hideBlock = {
            
            let hideAnimator = Animator()
            
            hideAnimator.updateBlock = {
                
                var rectInterpolatorIndex = 0
                
                var bubblePieIndex = 0

                setForcedValue(axisChartBase: chart, enable:true)

                for setIndex in 0..<dataSets.count {

                    if !dataSets[setIndex].visible || dataSets[setIndex].entryCount <= 0 || oldRectArray[setIndex].isEmpty {
                        continue
                    }

                // remove animation

                    if selectedDataset.contains(where: { $0 ===  dataSets[setIndex]}) {
                        
                        if let notes = chart.notes, let opacityInterpolator = opacityInterpolator {
                            performOpacityAnimationForNotes(notes: notes, datasetIndex: chartData.indexOfDataSet(dataSets[setIndex]),opacInterpolator: opacityInterpolator, animation: hideAnimator)
                        }

                        switch dataSets[setIndex].plotType {

                            case .Bar,.WaterFall,.BoxPlot,.Mekko:
                                
                            if CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) is BarPlotOptions {
                                    performBarFilterAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: hideAnimator,isMagnification: false)
                                }

                                break

                            case .Bubble,.Scatter,.PackedBubble:

                                if let opacityInterpolator = opacityInterpolator {

                                    performOpacityAnimation( opacInterpolator: opacityInterpolator, dataSet: dataSets[setIndex], newDataSetRect: oldRectArray[setIndex], animator: hideAnimator,isCenterChanged: true)
                                }

                                break
                            
                            case .Line,.LineRange,.Radar,.Area:
                        
                                if let opacityInterpolator = opacityInterpolator
                                {
                    
                                    performOpacityAnimation( opacInterpolator: opacityInterpolator, dataSet: dataSets[setIndex], newDataSetRect: oldRectArray[setIndex], animator: hideAnimator,isCenterChanged: false)
                                }
                        
                                break
                        
                            case .BubblePie:
                                
                                performBubblePieAnimation(chart: chart, dataSet: dataSets[setIndex], Interpolation: bubblePieInterpolator[bubblePieIndex], animation: hideAnimator)
                            
                                bubblePieIndex += 1
                                
                                break
                            
                            default:
                                break
                        }

                        rectInterpolatorIndex += 1

                        continue
                    }
                    else{
                        
                        if dataSets[setIndex].plotType == .Bar || dataSets[setIndex].plotType == .WaterFall ||
                            dataSets[setIndex].plotType == .Mekko {

                            if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {

                                if plotOption.isStacked {
                                    
                                    performBarFilterAnimation(oldDatasetRectArray: oldRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: hideAnimator,isMagnification: false)
                                    
                                    rectInterpolatorIndex += 1

                                    continue
                                }
                            }
                            
                        }
                        
                        if LineHelperFunctions.typeAllowed.contains(dataSets[setIndex].plotType) {
                            
                            if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? PlotOptionsBase {
                                
                                if plotOption.isStacked {
                                    
                                    for entryIndex in 0..<dataSets[setIndex].entryCount{
                                        
                                        let entry = dataSets[setIndex].entryForIndex(entryIndex)
                                        
                                        entry?.centerChanged = oldRectArray[setIndex][safe: entryIndex]?.origin
                                        
                                        entry?.opacityChanged = 1.0
                                        
                                    }
                                    
                                    rectInterpolatorIndex += 1

                                    continue
                                }
                            }
                        }
                        
                        
                        for entryIndex in 0..<dataSets[setIndex].entryCount{
                            
                            let entry = dataSets[setIndex].entryForIndex(entryIndex)
                            
                            entry?.centerChanged = nil
                            
                            entry?.sizeChanged = nil
                            
                            entry?.opacityChanged = 1.0
                            
                            entry?.filterChanged = nil
                            
                        }
                    }

                    rectInterpolatorIndex += 1
                    
                }
                
                chart.setNeedsDisplay()
                
            }
            
            hideAnimator.stopBlock =
            { [unowned hideAnimator] in
                
                if selectedDataset.contains(where: { $0.plotType == .BubblePie }){
                    
                    resetPlotData(selectedDataset: selectedDataset,originalVal: originalVal)
                }
                
                hideAnimator.updateBlock = nil
                
                alignBlock()
            }
            
            hideAnimator.animate(xAxisDuration: exitDuration / 2,easingOption: .linear)
            
        }
        
        //MARK: interaction align animation
        
        let interactionAlign = {
            
            let interactionAlignInterpolator = prepareInterpolationForAlignInteraction(dataSet: dataSets, selectedDataset: selectedDataset,fromArray: initialAlignRectArray,toArray: newRectArray, entryForSet: entryForSet)
            
            
            let interactionAlignAnimation = Animator()
            
            interactionAlignAnimation.updateBlock = {

                setForcedValue(axisChartBase: chart, enable:true)
                
                var toSetIndex = 0
                
                for setIndex in 0..<dataSets.count {
                    
                    var fromEntryIndex = 0
                    
                    if !dataSets[setIndex].visible || dataSets[setIndex].entryCount <= 0 {
                        continue
                    }
                    
                    if selectedDataset.contains(where: { $0 === dataSets[setIndex]}) {
                        continue
                    }
                    
                    for entryIndex in 0..<dataSets[setIndex].entryCount {
                        
                        guard let entry = dataSets[setIndex].entryForIndex(entryIndex) else {
                            continue
                        }
                        
                        if entry.x.isNaN && entry.y.isNaN {
                            
                            entry.sizeChanged = nil
                            
                            entry.centerChanged = nil
                            
                            continue
                        }
                        guard entryForSet[setIndex] != nil
                        else { break }
                        
                        if !entryForSet[setIndex]!.contains(entry) {

                            entry.centerChanged = newRectArray[toSetIndex][entryIndex].origin

                            entry.sizeChanged = newRectArray[toSetIndex][entryIndex].size

                            continue
                        }
                        
                        var origin = CGPoint(x: initialAlignRectArray[setIndex][fromEntryIndex].minX, y: initialAlignRectArray[setIndex][fromEntryIndex].minY)
                        
                        var sizeChanged = CGSize(width: initialAlignRectArray[setIndex][fromEntryIndex].width, height: initialAlignRectArray[setIndex][fromEntryIndex].height)
                        
                        if chart.isRotated {
                            
                            origin.x = interactionAlignInterpolator[toSetIndex][fromEntryIndex].x(interactionAlignAnimation.phaseX)
                            
                            sizeChanged.width = interactionAlignInterpolator[toSetIndex][fromEntryIndex].width(interactionAlignAnimation.phaseX)
                            
                        }
                        else{
                            
                            origin.y = CGFloat(interactionAlignInterpolator[toSetIndex][fromEntryIndex].y(interactionAlignAnimation.phaseX))
                            
                            sizeChanged.height = interactionAlignInterpolator[toSetIndex][fromEntryIndex].height(interactionAlignAnimation.phaseX)
                        }
                        
                        entry.centerChanged = origin
                        
                        entry.sizeChanged = sizeChanged
                        
                        fromEntryIndex += 1
                        
                    }
                    
                    toSetIndex += 1
                }
                
                chart.setNeedsDisplay()
                
            }
            
            interactionAlignAnimation.stopBlock =
            { [unowned interactionAlignAnimation] in
                interactionAlignAnimation.updateBlock = nil
                alignBlock()
            }
            
            interactionAlignAnimation.animate(xAxisDuration: exitDuration / 2,easingOption: .linear)
        }
        
        switch animationOptions {
            
            case .hideAndAlign:
                hideBlock()
                break
            
            case .StackedBaralign:
            
                setOpacityForSelectedDataSet(chart: chart,selectedDataset: selectedDataset)
            
                interactionAlign()
                break
            
            case .align:
            
                setOpacityForSelectedDataSet(chart: chart,selectedDataset: selectedDataset)
            
                alignBlock()
                break
        }
        
    }
    
    static func setOpacityForSelectedDataSet(chart: ChartViewBase,selectedDataset: [IChartDataSet])  {
        
        setForcedValue(axisChartBase: chart, enable:true)
    
        chart.lastSelected = nil
    
        for setIndex in 0..<selectedDataset.count {
        
            for entryIndex in 0..<selectedDataset[setIndex].entryCount {
            
                guard let entry = selectedDataset[setIndex].entryForIndex(entryIndex) else {
                    continue
                }
                
                entry.opacityChanged = 0.0
                
            }
        }
    }
    
    // MARK: - Hide and align interpoltion functions
    
    static func
    prepareInterpolationForHideAnimation
    (oldDataSetArray: [[CGRect]],
     newDataSetArray: [[CGRect]],
     chart: ChartViewBase,
     selectedDataset: [IChartDataSet],
     barRectArray: [[CGRect]],
     lineRectArray: [[CGRect]],
     areaRectArray: [[CGRect]],
     baseLineValue: CGPoint) -> ([[CustomRectInterpolator]], ((Double) -> Double)?, [[CustomRectInterpolator]], [[((Double) -> Double)]])? {
        
        guard let dataSets = chart.data?.dataSets else{
            return nil
        }
        
        if oldDataSetArray.count <= 0 || newDataSetArray.count <= 0{
            return nil
        }
        
        var rectInterpolateArray: [[CustomRectInterpolator]] = []
        
        var stackedBarInterpolateArray: [[CustomRectInterpolator]] = []
        
        var opacityInterpolator: ((Double) -> Double)?
        
        var bubblePieInterpolatorArray: [[((Double) -> Double)]] = []
        
        var newRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if !dataSets[setIndex].visible || oldDataSetArray[setIndex].count <= 0 {
                continue
            }
            
            if selectedDataset.contains(where: { $0 === dataSets[setIndex] }) {
                
                opacityInterpolator = Interpolator.interpolate(a: Double(1), b: Double(0))
                
                var setEntriesRectInterpolator: [CustomRectInterpolator] = [CustomRectInterpolator]()
                
                
                if dataSets[setIndex].plotType == .Bar || dataSets[setIndex].plotType == .WaterFall || dataSets[setIndex].plotType == .BoxPlot || dataSets[setIndex].plotType == .Mekko {
                    
                    var filterDataSetArray: [CGRect] = [CGRect]()
                    
                    
                    if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {
                        
                        if plotOption.isStacked {
                            
                            filterDataSetArray = prepareStackedBarRect(chart: chart, selectedDataSetIndex: setIndex, selectedDatasetRect: oldDataSetArray[setIndex], barRectArray: barRectArray,selectedDataSets: selectedDataset, baseLineValue: baseLineValue.y)//prepareStackedBarRect(chart: chart, dataSets: dataSets, selectedDataSet: dataSets[setIndex], selectedDatasetRect: oldDataSetArray[setIndex], barRectArray: barRectArray,selectedDataSets: selectedDataset, baseLineValue: baseLineValue.y)
                            
                        }
                        else {
                            filterDataSetArray = prepareRectForBarHideAnimation(dataSetRectArray: oldDataSetArray[setIndex],dataset: dataSets[setIndex], baseLineValue: CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSets[setIndex]), isRotated: chart.isRotated)
                        }
                    }
                    
                    setEntriesRectInterpolator = getRectInterpolatorArray(dataSet: dataSets[setIndex], oldDataSetArray: oldDataSetArray[setIndex], newDataSetArray: filterDataSetArray)
                    
                }
                
                if LineHelperFunctions.typeAllowed.contains(dataSets[setIndex].plotType) {
                    if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? PlotOptionsBase {
                        
                        if plotOption.isStacked {
                            
                            let (filterDataSetArray,previousDataset) = prepareStackedLineRect(isRotated: chart.isRotated, dataSets: dataSets, selectedDataSets: selectedDataset, selectedDatasetIndex: setIndex, selectedDatasetRect: oldDataSetArray[setIndex], LineRectArray: dataSets[setIndex].plotType == .Area ? areaRectArray : lineRectArray, baseLineValue: baseLineValue)
                            
                            setEntriesRectInterpolator = getRectInterpolatorArray(currentDataset: dataSets[setIndex],previousDataset: previousDataset,oldDataSetArray: oldDataSetArray[setIndex],newDataSetArray: filterDataSetArray, isInclude: false)
                            
                        }
                    }
                }
                
                rectInterpolateArray.append(setEntriesRectInterpolator)
                
                if dataSets[setIndex].plotType == .BubblePie {
                    
                    bubblePieInterpolatorArray.append(prepareBubblePieInterpolationForHide(selectedDataSet: dataSets[setIndex]))
                }
                
                continue
            }
            
            let setEntriesRectInterpolator = getRectInterpolatorArray(dataSet: dataSets[setIndex], oldDataSetArray: oldDataSetArray[setIndex], newDataSetArray: newDataSetArray[newRectIndex])
            
            if dataSets[setIndex].plotType == .Bar || dataSets[setIndex].plotType == .WaterFall || dataSets[setIndex].plotType == .Mekko {
                
                if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions{
                
                    if plotOption.isStacked {
                    
                        let initialRectArray: [CGRect] = prepareinitialRectForHideAnim(chart: chart,oldDataSetArray: oldDataSetArray[setIndex] ,newDataSetArray: newDataSetArray[newRectIndex])
                    
                        let setEntriesRectInterpolator = getRectInterpolatorArray(dataSet: dataSets[setIndex], oldDataSetArray: initialRectArray, newDataSetArray: newDataSetArray[newRectIndex])
                    
                        stackedBarInterpolateArray.append(setEntriesRectInterpolator)
                    }
                }
            }
            
            rectInterpolateArray.append(setEntriesRectInterpolator)
            
            newRectIndex += 1
            
        }
        
        return (rectInterpolateArray,opacityInterpolator,stackedBarInterpolateArray,bubblePieInterpolatorArray)
    }
    
    static func getRectInterpolatorArray(currentDataset: IChartDataSet,previousDataset: IChartDataSet,oldDataSetArray: [CGRect],newDataSetArray: [CGRect], isInclude: Bool) -> [CustomRectInterpolator] {
        
        var setEntriesRectInterpolator:[CustomRectInterpolator] = []
        
        for entryIndex in 0..<currentDataset.entryCount{
            
            var interpolateXValue: ((Double) -> Double)
            
            var interpolateYValue: ((Double) -> Double)
            
            var interpolateWidth: ((Double) -> Double)
            
            var interpolateHeigth: ((Double) -> Double)
            
            guard let entry = currentDataset.entryForIndex(entryIndex)
            else { continue }
            
            if entry.x.isNaN {
                
                let initialInterpolator = Interpolator.interpolate(a: 0.0, b: 0.0)

                setEntriesRectInterpolator.append(CustomRectInterpolator(x: initialInterpolator, y: initialInterpolator, width: initialInterpolator, height: initialInterpolator))
                
                continue
            }
            
            let previousEntry = previousDataset.entryForXValue(entry.x, closestToY: entry.y)
            
            if previousEntry == nil {
                continue
            }
            
            let previousEntryIndex = previousDataset.entryIndex(entry: previousEntry!)
            
            if newDataSetArray.count <= previousEntryIndex || oldDataSetArray.count <= entryIndex {
                continue
            }
            
            if !isInclude {
            
                interpolateXValue = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].origin.x), b: Double(newDataSetArray[previousEntryIndex].origin.x))
                
                interpolateWidth = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].width), b: Double(newDataSetArray[previousEntryIndex].width))
                
                interpolateYValue = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].origin.y), b: Double(newDataSetArray[previousEntryIndex].origin.y))
               
                interpolateHeigth = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].height), b: Double(newDataSetArray[previousEntryIndex].height))
            }
            else{
                interpolateXValue = Interpolator.interpolate(a: Double(newDataSetArray[previousEntryIndex].origin.x), b: Double(oldDataSetArray[entryIndex].origin.x))
                    
                interpolateWidth = Interpolator.interpolate(a: Double(newDataSetArray[previousEntryIndex].width), b: Double(oldDataSetArray[entryIndex].width))
                    
                interpolateYValue = Interpolator.interpolate(a: Double(newDataSetArray[previousEntryIndex].origin.y), b: Double(oldDataSetArray[entryIndex].origin.y))
                   
                interpolateHeigth = Interpolator.interpolate(a: Double(newDataSetArray[previousEntryIndex].height), b: Double(oldDataSetArray[entryIndex].height))
            }
            
            setEntriesRectInterpolator.append(CustomRectInterpolator(x: interpolateXValue, y: interpolateYValue, width: interpolateWidth, height: interpolateHeigth))
        }
        
        return setEntriesRectInterpolator
    }
    
    static func getRectInterpolatorArray(dataSet: IChartDataSet,oldDataSetArray: [CGRect],newDataSetArray: [CGRect]) -> [CustomRectInterpolator] {
        
        var setEntriesRectInterpolator:[CustomRectInterpolator] = []
        
        if !(oldDataSetArray.count == newDataSetArray.count){
            return setEntriesRectInterpolator
        }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            var interpolateXValue: ((Double) -> Double)
            
            var interpolateYValue: ((Double) -> Double)
            
            var interpolateWidth: ((Double) -> Double)
            
            var interpolateHeigth: ((Double) -> Double)
            
            interpolateXValue = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].origin.x), b: Double(newDataSetArray[entryIndex].origin.x))
                
            interpolateWidth = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].width), b: Double(newDataSetArray[entryIndex].width))
                
            interpolateYValue = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].origin.y), b: Double(newDataSetArray[entryIndex].origin.y))
               
            interpolateHeigth = Interpolator.interpolate(a: Double(oldDataSetArray[entryIndex].height), b: Double(newDataSetArray[entryIndex].height))
            
            setEntriesRectInterpolator.append(CustomRectInterpolator(x: interpolateXValue, y: interpolateYValue, width: interpolateWidth, height: interpolateHeigth))
        }
        
        return setEntriesRectInterpolator
    }
    
    static func prepareRectForBarMagnification(dataSetRectArray: [CGRect]) -> [CGRect] {
        var newRect: [CGRect] = [CGRect]()
        
        for rect in dataSetRectArray {
            newRect.append(CGRect(x: rect.midX, y: rect.midY, width: 0.0, height: 0.0))
        }
        
        return newRect
    }
    
    static func prepareRectForBarHideAnimation(dataSetRectArray: [CGRect], dataset: IChartDataSet, baseLineValue: CGFloat, isRotated: Bool) -> [CGRect] {
            var newRects: [CGRect] = [CGRect]()
            
            if dataset.entryCount != dataSetRectArray.count {
                return newRects
            }
            
            for entryIndex in 0..<dataset.entryCount {
                
                guard let entry = dataset.entryForIndex(entryIndex) else{
                    continue
                }
                
                let rect = dataSetRectArray[entryIndex]
                
                if entry.y > baseLineValue {
                    
                    let newRect = isRotated ? CGRect(x: rect.minX, y: rect.minY, width: 0.0, height: rect.height) : CGRect(x: rect.minX, y: rect.maxY, width: rect.width, height: 0.0)
                    newRects.append(newRect)
                }
                else {
                    let newRect = isRotated ? CGRect(x: rect.maxX, y: rect.minY, width: 0.0, height: rect.height) : CGRect(x: rect.minX, y: rect.minY, width: rect.width, height: 0.0)
                    newRects.append(newRect)
                }
                
            }
            
            return newRects
        }
    
    static func prepareStackedBarRect(chart: ChartViewBase, selectedDataSetIndex: Int,selectedDatasetRect: [CGRect],barRectArray: [[CGRect]],selectedDataSets: [IChartDataSet], baseLineValue: CGFloat) -> [CGRect] {
        
        var toRect: [CGRect] = [CGRect]()
        
        guard let data = chart.data, selectedDatasetRect.count > 0 else {
            return toRect
        }
        
        let selectedDataset = data.dataSets[selectedDataSetIndex]
        
        var barDataSets:[IChartDataSet] = data.dataSets.filter({
            ($0.plotType == .Bar || $0.plotType == .WaterFall || $0.plotType == .Mekko)
                      })
        
        var barIndex = 0
        
        for setIndex in 0..<barDataSets.count{
            if selectedDataset === barDataSets[setIndex]{
                barIndex = setIndex
                break
            }
        }
        
        var stackgroup = data.getStackGroupArrayFor(setIndex: barIndex)
        
        for dataSetIndex in 0..<barDataSets.count {
            if barDataSets[dataSetIndex] === selectedDataset {
                continue
            }
            
            if selectedDataSets.contains(where: {$0 === barDataSets[dataSetIndex]}) && stackgroup[safe:dataSetIndex] != nil {
                stackgroup.remove(at: dataSetIndex)
            }
        }
        
        var filterDatasets = barDataSets.filter({ $0.isVisible && $0.entryCount > 0 })
        
        for barDataSet in barDataSets {
            if selectedDataSets.contains(where: {$0 === barDataSet}){
                filterDatasets = filterDatasets.filter( {!($0 === barDataSet)})
            }
        }
    
        let selectedDatasetIndexInGroup = CommonHelperFunctions.getLastDatasetIndexSoFor(stackedGroup: stackgroup, setIndex: barIndex)
        
        let isInverted = chart.getYAxis(atIndex: selectedDataset.axisIndex)?.isInverted ?? false
        
        for entryIndex in 0..<selectedDataset.entryCount {
            
            guard let entry = selectedDataset.entryForIndex(entryIndex) else{
                continue
            }
            
            let prev = getPreviousRectForBar(isRotated: chart.isRotated, entry: entry, barDataSets: barDataSets, stackGroup: stackgroup, selectedDatasetIndexInGroup: selectedDatasetIndexInGroup, barRectArray: barRectArray, isInverted: isInverted, selectedDatasetRect: selectedDatasetRect[entryIndex], baseLinevalue: baseLineValue, filterDatasets: filterDatasets)
            
            toRect.append(prev)
        }
        
        return toRect
    }
    
    static func getPreviousRectForBar( isRotated: Bool, entry: ChartDataEntry, barDataSets: [IChartDataSet], stackGroup: [Int], selectedDatasetIndexInGroup: Int, barRectArray: [[CGRect]], isInverted: Bool, selectedDatasetRect: CGRect, baseLinevalue: Double, filterDatasets: [IChartDataSet]) -> CGRect {
        
//        let filterDatasets = barDataSets.filter({ $0.isVisible && $0.entryCount > 0 && !($0 === selectedDataset) })
        
        let selectedYValueIsPositive = entry.y>=0
        
        for stackGroupIndex in (0...selectedDatasetIndexInGroup).reversed() {
            
            if let datasetIndex = stackGroup[safe:stackGroupIndex], let prevDataset = barDataSets[safe:datasetIndex] {
                
                if !(prevDataset.isVisible && prevDataset.entryCount > 0) {
                    continue
                }
                
                let entries = prevDataset.entriesForXValue(entry.x)
                
                if entries.count == 0 {
                    continue
                }
                
                let entryIndex = getRectForEntries( entries: entries, ispositive: selectedYValueIsPositive, isNan: entry.y.isNaN)
                
                if entryIndex > -1 {
                    
                    let eIndex = prevDataset.entryIndex(entry: entries[entryIndex])
                    
                    if eIndex > -1 {
                    
                        if  let dIndex = filterDatasets.firstIndex(where: {$0 === prevDataset}), let rect = barRectArray[safe:dIndex]?[safe:eIndex] {
                            
                            if isRotated {
                                let xOrigin = selectedYValueIsPositive ? isInverted ? rect.minX : rect.maxX : isInverted ? rect.maxX : rect.minX
                                
                                return CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                            }
                            else {
                                let yOrigin = selectedYValueIsPositive ? isInverted ? rect.maxY : rect.minY : isInverted ? rect.minY : rect.maxY
                                
                                return CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                            }
                        }
                    }
                }
            }
        }
        
        var toRect: CGRect?
        var isBaseDataset: Bool = true
        
        for stackGroupIndex in 0..<stackGroup.count {
            
//            if selectedDatasetIndexInGroup == stackGroupIndex {
//                isBaseDataset = false
//                continue
//            }
            
            if let datasetIndex = stackGroup[safe:stackGroupIndex], let prevDataset = barDataSets[safe:datasetIndex] {
                
                if !(prevDataset.isVisible && prevDataset.entryCount > 0) {
                    continue
                }
                
                let entries = prevDataset.entriesForXValue(entry.x)
                
                if entries.count == 0 {
                    continue
                }
                
                let currentEntryYvalueIsPositive = entries[0].y>=0
                
                if selectedYValueIsPositive && !currentEntryYvalueIsPositive || !selectedYValueIsPositive && currentEntryYvalueIsPositive {
                    if let rect = prepareToRectForBaseDataset(isRotated: isRotated, isInverted: isInverted, filterDatasets: filterDatasets, barRectArray: barRectArray, entries: entries, selectedYValueIsPositive: currentEntryYvalueIsPositive, isNan: entries[0].y.isNaN,baseDataset: prevDataset) {
                        return rect
                    }
                }
                else if isBaseDataset {
                    if let rect = prepareToRectForBaseDataset(isRotated: isRotated, isInverted: isInverted, filterDatasets: filterDatasets, barRectArray: barRectArray, entries: entries, selectedYValueIsPositive: currentEntryYvalueIsPositive, isNan: entries[0].y.isNaN,baseDataset: prevDataset) {
                        toRect = rect
                        isBaseDataset = false
                    }
                }
            }
        }
        
        if toRect == nil {
            
            if isRotated {
                toRect = CGRect(x: baseLinevalue, y: selectedDatasetRect.minY, width: 0.0, height: selectedDatasetRect.height)
            }
            else {
                toRect = CGRect(x: selectedDatasetRect.minX, y: baseLinevalue, width: selectedDatasetRect.width, height: 0.0)
            }
        }
        
        return toRect ?? CGRect()
    }
    
    internal static func prepareToRectForBaseDataset(isRotated: Bool, isInverted: Bool, filterDatasets: [IChartDataSet], barRectArray: [[CGRect]], entries: [ChartDataEntry], selectedYValueIsPositive: Bool, isNan: Bool = false, baseDataset: IChartDataSet) -> CGRect? {
        
        let entryIndex = getRectForEntries( entries: entries, ispositive: selectedYValueIsPositive, isNan: isNan, isBaseDataset: true)
        
        if entryIndex > -1 {
            
            let eIndex = baseDataset.entryIndex(entry: entries[entryIndex])
            
            if eIndex > -1 {
            
                if  let dIndex = filterDatasets.firstIndex(where: {$0 === baseDataset}), let rect = barRectArray[safe:dIndex]?[safe:eIndex] {
                    
                    if isRotated {
                        let xOrigin = selectedYValueIsPositive ? isInverted ? rect.maxX : rect.minX : isInverted ? rect.minX : rect.maxX
                        
                        return CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                    }
                    else {
                        let yOrigin = selectedYValueIsPositive ? isInverted ? rect.minY : rect.maxY : isInverted ? rect.maxY : rect.minY
                        
                        return CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                    }
                }
            }
        }
        
        return nil
    }
    
    /*
    static func prepareStackedBarRect(chart: ChartViewBase, dataSets: [IChartDataSet],selectedDataSet: IChartDataSet,selectedDatasetRect: [CGRect],barRectArray: [[CGRect]],selectedDataSets: [IChartDataSet], baseLineValue: CGFloat) -> [CGRect] {
        
        var toRect: [CGRect] = [CGRect]()
        
        if selectedDatasetRect.count <= 0 {
            return toRect
        }
        
        var barDataSets:[IChartDataSet] = dataSets.filter({
            ($0.plotType == .Bar || $0.plotType == .WaterFall || $0.plotType == .Mekko) && ($0.isVisible) && $0.entryCount > 0
                      })
        
        for dataSet in barDataSets {
            if dataSet === selectedDataSet {
                continue
            }
            
            if selectedDataSets.contains(where: {$0 === dataSet}){
                barDataSets = barDataSets.filter( {!($0 === dataSet)})
            }
        }
        
        var barIndex = 0
        
        for setIndex in 0..<barDataSets.count{
            if selectedDataSet === barDataSets[setIndex]{
                barIndex = setIndex - 1
                break
            }
        }
        
        barDataSets = barDataSets.filter({
            !($0 === selectedDataSet)
        })
        
        var isSingleBarPlot = false
        
        if barDataSets.count <= 0 {
            isSingleBarPlot = true
        }
        
        let isInverted = chart.getYAxis(atIndex: selectedDataSet.axisIndex)?.isInverted ?? false
        
        for entryIndex in 0..<selectedDataSet.entryCount {
            
            guard let entry = selectedDataSet.entryForIndex(entryIndex) else{
                continue
            }
            
            if !chart.isRotated {
                
                let prev = getPreviousRectForBar( selectedEntry: entry, setIndex: barIndex, barDataSets: barDataSets, selectedDatasetRect: selectedDatasetRect[entryIndex], barRectArray: barRectArray,isSingleDataSet: isSingleBarPlot, baseLineValue: baseLineValue, isInverted: isInverted)
                
                toRect.append(prev)
                
            }
            else{
                
                let prev = getPreviousRectForHorizontalBar(selectedEntry: entry, setIndex: barIndex, barDataSets: barDataSets, selectedDatasetRect: selectedDatasetRect[entryIndex], barRectArray: barRectArray,isSingleDataSet: isSingleBarPlot, baseLineValue: baseLineValue, isInverted: isInverted)
                
                toRect.append(prev)
            }
        }
        
        return toRect
    }
    
    static func getPreviousRectForBar( selectedEntry: ChartDataEntry, setIndex: Int, barDataSets: [IChartDataSet], selectedDatasetRect: CGRect, barRectArray: [[CGRect]],isSingleDataSet: Bool,baseLineValue: CGFloat, isInverted: Bool) -> CGRect {
        
        var toRect: CGRect = CGRect()
        
        var barIndex = setIndex
        
        let selectedYval = selectedEntry.y
        
        outerLoop: while true{
        
            var NanFlag = true
            
            if barRectArray.count <= setIndex {
                return CGRect()
            }
            
            if barIndex < 0 {
                
                if selectedYval < 0 {
                    
                    if isSingleDataSet {
                        
                        let yOrigin = isInverted ? selectedDatasetRect.maxY : selectedDatasetRect.minY
                        
                        toRect = CGRect(x: selectedDatasetRect.minX, y: yOrigin, width: selectedDatasetRect.width, height: 0.0)
                        
                        break outerLoop
                    }
                    
                    for setIndex in 0..<barDataSets.count{
                        
                        if barRectArray.count <= setIndex {
                            return CGRect()
                        }
                        
                        let entries = barDataSets[setIndex].entriesForXValue(selectedEntry.x)
                        
                        if entries.count == 0{
                            continue
                        }
                        
                        let entry = entries[0]
                        
                        let eIndex = barDataSets[setIndex].entryIndex(entry: entry)
                        
                        if let rect = barRectArray[setIndex][safe:eIndex] {
                            
                            if entry.y > 0 {
                                
                                let yOrigin = isInverted ? rect.minY : rect.maxY
                                
                                toRect = CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                                
                                break outerLoop
                            }
                            
                            if entry.y <= 0 && NanFlag {
                                
                                let yOrigin = isInverted ? rect.maxY : rect.minY
                                
                                toRect = CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                                
                                NanFlag = false
                            }
                        }
                    }
                }
                else {
                    
                    for setIndex in 0..<barDataSets.count{
                        
                        if barRectArray.count <= setIndex {
                            return CGRect()
                        }
                        
                        let entries = barDataSets[setIndex].entriesForXValue(selectedEntry.x)
                        
                        if entries.count == 0{
                            continue
                        }
                        
                        let entry = entries[0]
                        
                        let eIndex = barDataSets[setIndex].entryIndex(entry: entry)
                        
                        if let rect = barRectArray[setIndex][safe:eIndex] {
                            
                            if entry.y <= 0 {
                                
                                let yOrigin = isInverted ? rect.maxY : rect.minY
                                
                                toRect = CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                                
                                break outerLoop
                            }
                            
                            if entry.y > 0 && NanFlag {
                                
                                let yOrigin = isInverted ? rect.minY : rect.maxY
                                
                                toRect = CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                                
                                NanFlag = false
                            }
                        }
                    }
                    
                }
                
                if NanFlag {
                    toRect = CGRect(x: selectedDatasetRect.minX, y: baseLineValue, width: selectedDatasetRect.width, height: 0.0)
                }
                
                break
            }
            
            let entries = barDataSets[barIndex].entriesForXValue(selectedEntry.x)
            
            if entries.count == 0{
                barIndex -= 1
                continue
            }
            
            if selectedYval > 0 {
                
                let entryIndex = getRectForEntries( entries: entries, ispositive: true)
                
                if entryIndex > -1 {
                    
                    let eIndex = barDataSets[barIndex].entryIndex(entry: entries[entryIndex])
                    
                    if eIndex > -1 {
                    
                        if let rect = barRectArray[barIndex][safe:eIndex] {
                            
                            let yOrigin = isInverted ? rect.maxY : rect.minY
                            
                            toRect = CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                            
                            break
                        }
                    }
                }
            }
            
            if selectedYval < 0 {
                
                let entryIndex = getRectForEntries( entries: entries, ispositive: false)
                
                if entryIndex > -1 {
                    
                    let eIndex = barDataSets[barIndex].entryIndex(entry: entries[entryIndex])
                    
                    if eIndex > -1 {
                        
                        if let rect = barRectArray[barIndex][safe:eIndex] {
                            
                            let yOrigin = isInverted ? rect.minY : rect.maxY
                            
                            toRect = CGRect(x: rect.minX, y: yOrigin, width: rect.width, height: 0.0)
                            
                            break
                        }
                    }
                }
            }
            
            barIndex -= 1
        }
        
        return toRect
    }
    */
    static func getRectForEntries( entries: [ChartDataEntry], ispositive: Bool, isNan: Bool = false, isBaseDataset: Bool = false) -> Int {
        
        //        var range = isBaseDataset ? entries.count : 0 // any Sequence<Int> = isBaseDataset ? (0...(entries.count - 1)) : (0...(entries.count - 1)).reversed()
                
                if isNan {
                    return entries.count - 1
                }
                else if ispositive {
                    if isBaseDataset
                    {
                        for index in 0...(entries.count - 1) {
                            
                            if entries[index].y >= 0 {
                                
                                return index
                            }
                        }
                    }
                    else{
                        for index in (0...(entries.count - 1)).reversed() {
                            if entries[index].y >= 0 {
                                
                                return index
                            }
                        }
                    }
                }
                else {
                    if isBaseDataset
                    {
                        for index in 0...(entries.count - 1) {
                            
                            if entries[index].y < 0 {
                                
                                return index
                            }
                        }
                    }
                    else {
                        for index in (0...(entries.count - 1)).reversed() {
                            
                            if entries[index].y < 0 {
                                
                                return index
                            }
                        }
                    }
                }
                
                return -1
            }
    
    /*
    static func getPreviousRectForHorizontalBar(selectedEntry: ChartDataEntry, setIndex: Int, barDataSets: [IChartDataSet], selectedDatasetRect: CGRect, barRectArray: [[CGRect]],isSingleDataSet: Bool, baseLineValue: CGFloat, isInverted: Bool) -> CGRect {
        
        var toRect: CGRect = CGRect()
        
        var barIndex = setIndex
        
        let selectedYval = selectedEntry.y
        
        outerLoop: while true{
            
            var NanFlag = true
            
            if barRectArray.count <= setIndex {
                return CGRect()
            }
            
            if barIndex < 0{
                
                if selectedYval < 0 {
                    
                    if isSingleDataSet {
                        
                        let xOrigin = isInverted ? selectedDatasetRect.minX : selectedDatasetRect.maxX
                        
                        toRect = CGRect(x: xOrigin, y: selectedDatasetRect.minY, width: 0.0, height: selectedDatasetRect.height)
                        
                        break outerLoop
                    }
                    
                    for setIndex in 0..<barDataSets.count {
                        
                        if barRectArray.count <= setIndex {
                            return CGRect()
                        }
                        
                        let entries = barDataSets[setIndex].entriesForXValue(selectedEntry.x)
                        
                        if entries.count == 0{
                            continue
                        }
                        
                        let entry = entries[0]
                        
                        let eIndex = barDataSets[setIndex].entryIndex(entry: entry)
                        
                        if let rect = barRectArray[setIndex][safe:eIndex] {
                            
                            if entry.y > 0 {
                                
                                let xOrigin = isInverted ? rect.maxX : rect.minX
                                
                                toRect = CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                                
                                break outerLoop
                            }
                            
                            if entry.y <= 0 && NanFlag {
                                
                                let xOrigin = isInverted ? rect.minX : rect.maxX
                                
                                toRect = CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                                
                                NanFlag = false
                            }
                        }
                    }
                }
                else {
                    
                    for setIndex in 0..<barDataSets.count {
                        
                        if barRectArray.count <= setIndex {
                            return CGRect()
                        }
                        
                        let entries = barDataSets[setIndex].entriesForXValue(selectedEntry.x)
                        
                        if entries.count == 0{
                            continue
                        }
                        
                        let entry = entries[0]
                        
                        let eIndex = barDataSets[setIndex].entryIndex(entry: entry)
                        
                        if let rect = barRectArray[setIndex][safe:eIndex] {
                            
                            if entry.y <= 0 {
                                
                                let xOrigin = isInverted ? rect.minX : rect.maxX
                                
                                toRect = CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                                
                                break outerLoop
                            }
                            
                            if entry.y > 0 && NanFlag {
                                
                                let xOrigin = isInverted ? rect.maxX : rect.minX
                                
                                toRect = CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                                
                                NanFlag = false
                            }
                        }
                    }
                    
                }
                
                if NanFlag {
                    toRect = CGRect(x: baseLineValue, y: selectedDatasetRect.minY, width: 0.0, height: selectedDatasetRect.height)
                }
                
                break
            }
            
            let entries = barDataSets[barIndex].entriesForXValue(selectedEntry.x)
            
            if entries.count == 0{
                barIndex -= 1
                continue
            }
            
            if selectedYval > 0 {
                
                let entryIndex = getRectForEntries( entries: entries, ispositive: true)
                
                if entryIndex > -1 {
                    
                    let eIndex = barDataSets[barIndex].entryIndex(entry: entries[entryIndex])
                    
                    if eIndex > -1 {
                    
                        if let rect = barRectArray[barIndex][safe:eIndex] {
                            
                            let xOrigin = isInverted ? rect.minX : rect.maxX
                            
                            toRect = CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                            
                            break
                        }
                    }
                }
            }
            
            if selectedYval < 0 {
                
                let entryIndex = getRectForEntries( entries: entries, ispositive: false)
                
                if entryIndex > -1 {
                    
                    let eIndex = barDataSets[barIndex].entryIndex(entry: entries[entryIndex])
                    
                    if eIndex > -1 {
                    
                        if let rect = barRectArray[barIndex][safe:eIndex] {
                            
                            let xOrigin = isInverted ? rect.maxX : rect.minX
                            
                            toRect = CGRect(x: xOrigin, y: rect.minY, width: 0.0, height: rect.height)
                            
                            break
                        }
                    }
                }
            }
            
            barIndex -= 1
        }
        
        return toRect
    }
    */
    static func prepareStackedLineRect(isRotated: Bool, dataSets: [IChartDataSet], selectedDataSets: [IChartDataSet], selectedDatasetIndex: Int, selectedDatasetRect: [CGRect], LineRectArray: [[CGRect]], baseLineValue: CGPoint) -> ([CGRect],IChartDataSet) {
        
        let selectedDataSet = dataSets[selectedDatasetIndex]
        
        var lineDataSets:[IChartDataSet] = dataSets.filter({
            ($0.plotType == selectedDataSet.plotType) && ($0.isVisible) && $0.entryCount > 0
                      })
        
        for dataSet in lineDataSets {
            if dataSet === selectedDataSet {
                continue
            }
            
            if selectedDataSets.contains(where: {$0 === dataSet}){
                lineDataSets = lineDataSets.filter( {!($0 === dataSet)})
            }
        }
        
        var lineIndex = 0
        
        for setIndex in 0..<lineDataSets.count{
            if selectedDataSet === lineDataSets[setIndex]{
                lineIndex = setIndex
                break
            }
        }
        
        lineDataSets = lineDataSets.filter({
            !($0 === selectedDataSet)
        })
        
        var barIndex = -1
        
        let positive = selectedDataSet.yMax > 0
        
        for setIndex in (0..<lineIndex).reversed(){
            
            if (lineDataSets[setIndex].yMax > 0 && positive) || (lineDataSets[setIndex].yMax < 0 && !positive)
            {
                barIndex = setIndex
                break
            }
        }
        
        if barIndex < 0 {
            
            var toRect: [CGRect] = [CGRect]()
            
            if selectedDataSet.plotType == .Radar {
                
                for rect in selectedDatasetRect {
                    toRect.append(CGRect(x: baseLineValue.x, y: baseLineValue.y, width: rect.width, height: rect.height))
                }
            }
            else{
                toRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: selectedDatasetRect,BaseValue: isRotated ? baseLineValue.x : baseLineValue.y)
            }
            
            return (toRect,selectedDataSet)
        }
        
        if let toRect = LineRectArray[safe:barIndex] {
            return (toRect,lineDataSets[barIndex])
        }
        
        return ([CGRect](),ChartDataSet() as IChartDataSet)
    }
    
    static func prepareinitialRectForHideAnim(chart: ChartViewBase,oldDataSetArray: [CGRect] ,newDataSetArray: [CGRect]) -> [CGRect] {
        
        var rect: [CGRect] = [CGRect]()
        
        if oldDataSetArray.count != newDataSetArray.count {
            return rect
        }
        
        if chart.isRotated{
            for index in 0..<oldDataSetArray.count{
                rect.append(CGRect(x: newDataSetArray[index].minX, y: oldDataSetArray[index].minY, width: newDataSetArray[index].width, height: oldDataSetArray[index].height))
            }
        }
        else{
            for index in 0..<oldDataSetArray.count{
                rect.append(CGRect(x: oldDataSetArray[index].minX, y: newDataSetArray[index].minY, width: oldDataSetArray[index].width, height: newDataSetArray[index].height))
            }
        }
        
        return rect
    }
    
    static func prepareBubblePieInterpolationForHide(selectedDataSet: IChartDataSet) -> [((Double) -> Double)] {
        
        var bubblePieInterpolatorArray: [((Double) -> Double)] = []
        
        
        for entryIndex in 0..<selectedDataSet.entryCount {
            
            guard let entry = selectedDataSet.entryForIndex(entryIndex), let plotVal = (entry.plotData as? Double) else {
                continue
            }
            
            bubblePieInterpolatorArray.append(Interpolator.interpolate(a: plotVal, b: 0.0))
            
        }
        
        return bubblePieInterpolatorArray
    }
    
    static func prepareInterpolationForAlignInteraction(dataSet: [IChartDataSet], selectedDataset: [IChartDataSet],fromArray: [[CGRect]],toArray: [[CGRect]], entryForSet: [Int:[ChartDataEntry]]) -> [[CustomRectInterpolator]]
    {
        
        var alignInterpolationArray: [[CustomRectInterpolator]] = [[CustomRectInterpolator]]()
        
        var toSetIndex = 0
        
        for setIndex in 0..<dataSet.count {
            
            if !dataSet[setIndex].isVisible || dataSet[setIndex].entryCount <= 0 {
                continue
            }
            
            var fromEntryIndex = 0
            
            if selectedDataset.contains(where: { $0 === dataSet[setIndex]})/*selectedDataset === dataSet[setIndex]*/ {
                continue
            }
            
            var setEntriesRectInterpolator:[CustomRectInterpolator] = []
            
            guard entryForSet[setIndex] != nil
            else { alignInterpolationArray.append(setEntriesRectInterpolator)
                toSetIndex += 1
                continue }
            for entry in entryForSet[setIndex]! {
                
                if fromArray[setIndex].count <= fromEntryIndex {
                    break
                }
                
                let entryIndex = dataSet[setIndex].entryIndex(entry: entry)
                
                if entry.x.isNaN && entry.y.isNaN {
                    continue
                }
                
                var interpolateXValue: ((Double) -> Double)
                
                var interpolateYValue: ((Double) -> Double)
                
                var interpolateWidth: ((Double) -> Double)
                
                var interpolateHeigth: ((Double) -> Double)
                
                interpolateXValue = Interpolator.interpolate(a: Double(fromArray[setIndex][fromEntryIndex].origin.x), b: Double(toArray[toSetIndex][entryIndex].origin.x))
                    
                interpolateWidth = Interpolator.interpolate(a: Double(fromArray[setIndex][fromEntryIndex].width), b: Double(toArray[toSetIndex][entryIndex].width))
                    
                interpolateYValue = Interpolator.interpolate(a: Double(fromArray[setIndex][fromEntryIndex].origin.y), b: Double(toArray[toSetIndex][entryIndex].origin.y))
                   
                interpolateHeigth = Interpolator.interpolate(a: Double(fromArray[setIndex][fromEntryIndex].height), b: Double(toArray[toSetIndex][entryIndex].height))
                
                setEntriesRectInterpolator.append(CustomRectInterpolator(x: interpolateXValue, y: interpolateYValue, width: interpolateWidth, height: interpolateHeigth))
                
                fromEntryIndex += 1
            }
            
            toSetIndex += 1
            
            alignInterpolationArray.append(setEntriesRectInterpolator)
        }
        
        return alignInterpolationArray
        
    }
    
    static func prepareHideInterpolationForLineRange(dataSets: [IChartDataSet],  selectedDataset: [IChartDataSet], oldRect: [[CGRect]], newRect: [[CGRect]]) -> [[CustomRectInterpolator]] {
        
        var LineRangeInterpolatorArray: [[CustomRectInterpolator]] = [[CustomRectInterpolator]]()
        
        var newRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if selectedDataset.contains(where: {$0 === dataSets[setIndex] }) || !dataSets[setIndex].isVisible || !(dataSets[setIndex].entryCount > 0) {
                continue
            }
            
            if dataSets[setIndex].plotType != .LineRange {
                newRectIndex += 1
                continue
            }
            
            var setEntriesRectInterpolator:[CustomRectInterpolator] = []
            
            for entryIndex in 0..<dataSets[setIndex].entryCount{
                
                var interpolateXValue: ((Double) -> Double)
                
                var interpolateYValue: ((Double) -> Double)
                
                var interpolateWidth: ((Double) -> Double)
                
                var interpolateHeigth: ((Double) -> Double)
                
                guard let oldRect = oldRect[safe:setIndex]?[safe:entryIndex], let newRect = newRect[safe:newRectIndex]?[safe:entryIndex] else {
                    continue
                }
                
                interpolateXValue = Interpolator.interpolate(a: Double(oldRect.origin.x), b: Double(newRect.origin.x))
                    
                interpolateYValue = Interpolator.interpolate(a: Double(oldRect.width), b: Double(newRect.width))
                    
                interpolateWidth = Interpolator.interpolate(a: Double(0.0), b: Double(0.0))
                   
                interpolateHeigth = Interpolator.interpolate(a: Double(0.0), b: Double(0.0))
                
                setEntriesRectInterpolator.append(CustomRectInterpolator(x: interpolateXValue, y: interpolateYValue, width: interpolateWidth, height: interpolateHeigth))
            }
            
            newRectIndex += 1
            
            LineRangeInterpolatorArray.append(setEntriesRectInterpolator)
        }
        
        return LineRangeInterpolatorArray
    }
    
    static func prepareIncludeInterpolationForLineRange(dataSets: [IChartDataSet],  selectedDataset: [IChartDataSet], oldRect: [[CGRect]], newRect: [[CGRect]]) -> [[CustomRectInterpolator]] {
        
        var LineRangeInterpolatorArray: [[CustomRectInterpolator]] = [[CustomRectInterpolator]]()
        
        var oldRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if selectedDataset.contains(where: {$0 === dataSets[setIndex] }) || !dataSets[setIndex].isVisible || !(dataSets[setIndex].entryCount > 0) {
                continue
            }
            
            if dataSets[setIndex].plotType != .LineRange {
                oldRectIndex += 1
                continue
            }
            
            var setEntriesRectInterpolator:[CustomRectInterpolator] = []
            
            for entryIndex in 0..<dataSets[setIndex].entryCount{
                
                var interpolateXValue: ((Double) -> Double)
                
                var interpolateYValue: ((Double) -> Double)
                
                var interpolateWidth: ((Double) -> Double)
                
                var interpolateHeigth: ((Double) -> Double)
                
                guard let oldRect = oldRect[safe:oldRectIndex]?[safe:entryIndex],let newRect = newRect[safe:setIndex]?[safe:entryIndex] else {
                    continue
                }
                
                interpolateXValue = Interpolator.interpolate(a: Double(oldRect.origin.x), b: Double(newRect.origin.x))
                    
                interpolateYValue = Interpolator.interpolate(a: Double(oldRect.width), b: Double(newRect.width))
                    
                interpolateWidth = Interpolator.interpolate(a: Double(0.0), b: Double(0.0))
                   
                interpolateHeigth = Interpolator.interpolate(a: Double(0.0), b: Double(0.0))
                
                setEntriesRectInterpolator.append(CustomRectInterpolator(x: interpolateXValue, y: interpolateYValue, width: interpolateWidth, height: interpolateHeigth))
            }
            
            oldRectIndex += 1
            
            LineRangeInterpolatorArray.append(setEntriesRectInterpolator)
        }
        
        return LineRangeInterpolatorArray
    }
    
    static func prepareInitialRectForLineFillPath(isRotated: Bool,lineDataSet: [IChartDataSet], lineRect: [[CGRect]], oldBaseValue: Double, newBaseValue: Double) -> ([IChartDataSet],[[CustomRectInterpolator]]) {
        
        var initialDataSet = [IChartDataSet]()
        
        var StackedLineinterpolationArray = [[CustomRectInterpolator]]()
        
        var positiveDatasetIndex = -1
        
        var posFlag = false
        
        var negativeDatasetIndex = -1
        
        var negFlag = false
        
        for datasetIndex in 0..<lineDataSet.count {
            
            if posFlag && negFlag {
                break
            }
            
            let yVal = lineDataSet[datasetIndex].yMax
            
            if yVal > 0 && !posFlag {
                posFlag = true
                positiveDatasetIndex = datasetIndex
            }
            
            if yVal < 0 && !negFlag {
                negFlag = true
                negativeDatasetIndex = datasetIndex
            }
        }
        
        if positiveDatasetIndex > -1 {
            initialDataSet.append(lineDataSet[positiveDatasetIndex])
            
            let oldRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: lineRect[positiveDatasetIndex],BaseValue: oldBaseValue)
            
            let newRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: lineRect[positiveDatasetIndex],BaseValue: newBaseValue)
            
            StackedLineinterpolationArray.append( getRectInterpolatorArray(dataSet: lineDataSet[positiveDatasetIndex], oldDataSetArray: oldRect, newDataSetArray: newRect))
        }
                                   
        if negativeDatasetIndex > -1 {
            initialDataSet.append(lineDataSet[negativeDatasetIndex])
            
            let oldRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: lineRect[negativeDatasetIndex],BaseValue: oldBaseValue)
            
            let newRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: lineRect[negativeDatasetIndex],BaseValue: newBaseValue)
            
            StackedLineinterpolationArray.append( getRectInterpolatorArray(dataSet: lineDataSet[negativeDatasetIndex], oldDataSetArray: oldRect, newDataSetArray: newRect))
        }
        
        return (initialDataSet,StackedLineinterpolationArray)
    }
    
    static func prepareInitialRectForAreaFillPath(isRotated: Bool,lineDataSet: [IChartDataSet], lineRect: [[CGRect]], oldBaseValue: Double, newBaseValue: Double) -> [[CustomRectInterpolator]] {
        
        var areaInterpolationArray = [[CustomRectInterpolator]]()
        
        for datasetIndex in 0..<lineDataSet.count {
            
            let oldRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: lineRect[datasetIndex],BaseValue: oldBaseValue)
            
            let newRect = getInitialRectForLineFillPath(isRotated: isRotated, oldRect: lineRect[datasetIndex],BaseValue: newBaseValue)
            
            areaInterpolationArray.append( getRectInterpolatorArray(dataSet: lineDataSet[datasetIndex], oldDataSetArray: oldRect, newDataSetArray: newRect))
            
        }
        
        return areaInterpolationArray
    }
    
    static func getInitialRectForLineFillPath(isRotated: Bool, oldRect: [CGRect],BaseValue: Double) -> [CGRect]{
        
        var toRect = [CGRect]()
        
        for rect in oldRect {
            
            var origin = CGPoint(x: rect.origin.x, y: BaseValue)
            
            if isRotated {
                origin = CGPoint(x: BaseValue, y: rect.origin.y)
            }
            toRect.append(CGRect(x: origin.x, y: origin.y, width: rect.width, height: rect.height))
        }
        
        return toRect
    }
    
    // MARK: - common animation functions
    
    static func
    barAnimation(oldDatasetRectArray: [CGRect],interpolation: [CustomRectInterpolator], chart: ChartViewBase, dataSet: IChartDataSet, animator: Animator) {
        
        if oldDatasetRectArray.count == 0 || !(oldDatasetRectArray.count == interpolation.count) {
            return
        }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
            
            var origin = CGPoint(x: oldDatasetRectArray[entryIndex].origin.x, y: oldDatasetRectArray[entryIndex].origin.y)
            
            var sizeChanged = CGSize(width: oldDatasetRectArray[entryIndex].width, height: oldDatasetRectArray[entryIndex].height)
            
            origin.x = interpolation[entryIndex].x(animator.phaseX)
            
            origin.y = interpolation[entryIndex].y(animator.phaseX)
            
            sizeChanged.width = interpolation[entryIndex].width(animator.phaseX)
            
            sizeChanged.height = interpolation[entryIndex].height(animator.phaseX)
            
            entry.centerChanged = origin
            
            entry.sizeChanged = sizeChanged
        }
    }
    
    static func performOpacityAnimation( opacInterpolator: ((Double) -> Double), dataSet: IChartDataSet, newDataSetRect: [CGRect]?,animator: Animator,isCenterChanged: Bool) {
        
        guard (newDataSetRect != nil)
        else { return }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            let entry = dataSet.entryForIndex(entryIndex)
            
            if isCenterChanged && newDataSetRect!.count > entryIndex{
            
                entry?.centerChanged = newDataSetRect![entryIndex].origin
                
                entry?.sizeChanged = newDataSetRect![entryIndex].size
                
            }
            
            entry?.opacityChanged = Float(opacInterpolator(animator.phaseX))
            
        }
    }
    
    static func
    positionAnimation(oldDatasetRectArray: [CGRect],interpolation: [CustomRectInterpolator], chart: ChartViewBase, dataSet: IChartDataSet, animator: Animator,originVal: Int) {
        
        if oldDatasetRectArray.count == 0 || !(oldDatasetRectArray.count == interpolation.count) {
            return
        }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
            
            
            if entry.x.isNaN || oldDatasetRectArray.count <= entryIndex {
                continue
            }
            
            var origin = CGPoint(x: oldDatasetRectArray[entryIndex].origin.x, y: oldDatasetRectArray[entryIndex].origin.y)
            
            
            if originVal == 0 || originVal == 2{
            
                origin.x = CGFloat(interpolation[entryIndex].x(animator.phaseX))
                
            }
            
            if originVal == 1 || originVal == 2{
            
                origin.y = CGFloat(interpolation[entryIndex].y(animator.phaseX))
                
            }
            
            entry.centerChanged = origin
        }
    }
    
    static func
    sizeAnimation(oldDatasetRectArray: [CGRect],interpolation: [CustomRectInterpolator], chart: ChartViewBase, dataSet: IChartDataSet, animator: Animator,sizeVal: Int) {
        
        if oldDatasetRectArray.count == 0 || !(oldDatasetRectArray.count == interpolation.count) {
            return
        }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            guard let entry = dataSet.entryForIndex(entryIndex), var sizeChanged = oldDatasetRectArray[safe:entryIndex]?.size
                else { continue }
            
//            var sizeChanged = oldDatasetRectArray[entryIndex].size
            
            if sizeVal == 0 || sizeVal == 2{
            
                sizeChanged.width = interpolation[entryIndex].width(animator.phaseX)
                
            }
            
            if sizeVal == 1 || sizeVal == 2{
                
                sizeChanged.height = interpolation[entryIndex].height(animator.phaseX)
                
            }
            
            entry.sizeChanged = sizeChanged
        }
    }
    
    static func
    positionAnimationForLine(oldDatasetRectArray: [CGRect],interpolation: [CustomRectInterpolator], chart: ChartViewBase, dataSet: IChartDataSet, animator: Animator) {
        
        if oldDatasetRectArray.count == 0 || !(oldDatasetRectArray.count == interpolation.count) {
            return
        }
        
        for entryIndex in 0..<dataSet.entryCount {
            
            guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
            
            if let rect = oldDatasetRectArray[safe: entryIndex] {
            
                var origin = CGPoint(x: rect.origin.x, y: rect.origin.y)
                
                if let  interpolator = interpolation[safe: entryIndex] {
                    
                    if chart.isRotated {
                        origin.x = CGFloat(interpolator.x(animator.phaseX))
                
                        origin.y = Interpolator.interpolate(a: origin.y, b: CGFloat(interpolator.y(1.0)))(animator.phaseX)
                    }
                    else {
                        origin.x = Interpolator.interpolate(a: origin.x, b: CGFloat(interpolator.x(1.0)))(animator.phaseX)
                        
                        origin.y = CGFloat(interpolator.y(animator.phaseX))
                    }
                }
                entry.lineCenterChanged = origin
            }
        }
    }
    
    //mark: filter animation
    
    static func performBarFilterAnimation(oldDatasetRectArray: [CGRect],interpolation: [CustomRectInterpolator], chart: ChartViewBase, dataSet: IChartDataSet, animator: Animator,isMagnification: Bool) {
        
        if oldDatasetRectArray.count == 0 || !(oldDatasetRectArray.count == interpolation.count) {
            return
        }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
            
            var origin = CGPoint(x: oldDatasetRectArray[entryIndex].minX, y: oldDatasetRectArray[entryIndex].minY)
            
            var sizeChanged = CGSize(width: oldDatasetRectArray[entryIndex].width, height: oldDatasetRectArray[entryIndex].height)
            
            if chart.isRotated{
                
                if isMagnification{
                
                    origin.y = CGFloat(interpolation[entryIndex].y(animator.phaseX))
                
                    sizeChanged.height = CGFloat(interpolation[entryIndex].height(animator.phaseX))
                }
                else{
                    origin.x = CGFloat(interpolation[entryIndex].x(animator.phaseX))
                
                    sizeChanged.width = CGFloat(interpolation[entryIndex].width(animator.phaseX))
                    
                }
                
            }
            else{
                
                if isMagnification{
                
                    origin.x = CGFloat(interpolation[entryIndex].x(animator.phaseX))
                
                    sizeChanged.width = CGFloat(interpolation[entryIndex].width(animator.phaseX))
                    
                }
                else{
                    
                    origin.y = CGFloat(interpolation[entryIndex].y(animator.phaseX))
                
                    sizeChanged.height = CGFloat(interpolation[entryIndex].height(animator.phaseX))
                }
                
            }
            
            entry.centerChanged = origin
            
            entry.sizeChanged = sizeChanged
        }
        
    }
    
    static func performBubblePieAnimation(chart: ChartViewBase, dataSet: IChartDataSet, Interpolation: [(Double) -> Double], animation: Animator) {
        
        for entryIndex in 0..<dataSet.entryCount {
            
            guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
            
            entry.plotData = Interpolation[entryIndex](animation.phaseX) as AnyObject
            
        }
        
        (chart.getProcessor(type: .BubblePie) as? BubblePiePreprocessor)?.updateBuffer()
        
        chart.highlightValue(nil, callDelegate: true)
    }
    
    static func performOpacityAnimationForNotes(notes: Notes, datasetIndex: Int,opacInterpolator: ((Double) -> Double), animation: Animator) {
        
        for nodeEntry in notes.noteEntries {
            
            if nodeEntry.noteEntryDataSetIndex == datasetIndex {
                nodeEntry.opacityChanged = opacInterpolator(animation.phaseX)
            }
        }
    }
    
    // MARK: - Include and align animation
    
    public static func IncludeAndAlignDataSet(chart: ChartViewBase, selectedDataset: [IChartDataSet], exitDuration: Double) {
        
        guard let chartData = chart.data else{
            return
        }
        
        let lastTouchMatrix = chart.viewPortHandler._touchMatrix
        
        let oldBaseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: selectedDataset[0])
        
        var oldPosition = chart.pixelForValues(point: CGPoint(x: 0.0, y: oldBaseLineValue), axisIndex: selectedDataset[0].axisIndex)
        
        let oldBaseValue = chart.isRotated ? oldPosition.x : oldPosition.y
        
        if chart.plotTypes.contains(.Radar) {
            
            if let plotOption = chart.getPlotOptions(type: .Radar) as? DialPlotOptions {
                oldPosition = plotOption.centerCircleBox
            }
        
        }
        
        var barRectArray: [[CGRect]] = [[CGRect]]()
        var lineRectArray: [[CGRect]] = [[CGRect]]()
        var areaRectArray: [[CGRect]] = [[CGRect]]()
        
        var lineDataSets:[IChartDataSet] = [IChartDataSet]()
        var areaDataSets:[IChartDataSet] = [IChartDataSet]()
        
        var isLinePlotTypes = false
        
        if chart.plotTypes.contains(.Line) || chart.plotTypes.contains(.Radar){
            
            if let linePlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line,.Radar]) as? PlotOptionsBase
            {
                if linePlot.isStacked {
                    lineDataSets = chartData.dataSets.filter({
                        ($0.plotType == .Line  || $0.plotType == .Radar) && ($0.isVisible) && $0.entryCount > 0
                              })
                
                    lineDataSets.forEach({
                        lineRectArray.append(LineHelperFunctions.prepareDataSetArray(selectedDataset: $0, chart: chart))
                    })
                }
            }
            
            isLinePlotTypes = true
        }
        
        if chart.plotTypes.contains(.Area) {
            
            if let areaPlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Area]) as? PlotOptionsBase
            {
                if areaPlot.isStacked {
                    areaDataSets = chartData.dataSets.filter({
                        ($0.plotType == .Area) && ($0.isVisible) && $0.entryCount > 0
                              })
                
                    areaDataSets.forEach({
                        areaRectArray.append(LineHelperFunctions.prepareDataSetArray(selectedDataset: $0, chart: chart))
                    })
                }
            }
            
            isLinePlotTypes = true
        }
        
        let oldRectArray = prepareRectArrayforAllDataset(chart: chart).filter( {$0.count > 0})
        
        let oldFilterArray = prepareArrayForFilterValues(chart: chart).filter( {$0.count > 0})
        
        let oldTicklabelModels = prepareTickLabelModels(chart: chart)
        
        let fromViewPortRect = chart.viewPortHandler.contentRect
        let fromChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
        
        let xDataNil = chart.data?.xMin == Double.greatestFiniteMagnitude
        
        let yDataNil = chart.data?.yMin == Double.greatestFiniteMagnitude
        
        for set in selectedDataset
        {
            set.visible = true
        }

        chart.lastSelected = nil
        
        chart.includeLayer = true
        
        if !chart.plotTypes.contains(.Radar) {
            calculateCurrentDataAndSetOldMinMax(axisChartBase: chart)
        }

        CommonHelperFunctions.updateMatrix(chart: chart)
        
        if (xDataNil && yDataNil) {
            chart.viewPortHandler._touchMatrix = lastTouchMatrix
            chart.notifyDataSetChanged(redrawRequired: false)
        }
        
        var originalVal:[Double] = []
        
        if selectedDataset.contains(where: { $0.plotType == .BubblePie }){
            
            for setIndex in 0..<selectedDataset.count{
                
                if selectedDataset[setIndex].plotType == .BubblePie{
                    
                    for entryIndex in 0..<selectedDataset[setIndex].entryCount{
                        
                        guard let entry = selectedDataset[setIndex].entryForIndex(entryIndex),
                              (entry.plotData as? Double) != nil
                        else {
                            continue
                        }
                        
                        originalVal.append(CGFloat(entry.plotData as! Double))
                        
                    }
                }
                
            }
        }
        
        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: selectedDataset[0])
        
        let position = chart.pixelForValues(point: CGPoint(x: 0.0, y: baseLineValue), axisIndex: selectedDataset[0].axisIndex)
        
        let newBaseValue = chart.isRotated ? position.x : position.y
        
        let newRectArray = prepareRectArrayforAllDataset(chart: chart)
        
        let newFilterArray = prepareArrayForFilterValues(chart: chart)
        
        let oldTicklabelPositionArray = ChartInteractionHelperFunction.prepareTickLabelPositions(chart: chart, tickLabelModelObject: oldTicklabelModels)
        
        let newTicklabelModels = prepareTickLabelModels(chart: chart)
        
        let toViewPortRect = chart.viewPortHandler.contentRect
        let toChartSize = CGSize(width: chart.viewPortHandler.chartWidth, height: chart.viewPortHandler.chartHeight)
        
        var (initalDatasetForStackedLine,initalInterpolatorForStackedLine) = ([IChartDataSet](),[[CustomRectInterpolator]]())
        var (initalDatasetForStackedArea,initalInterpolatorForStackedArea) = ([IChartDataSet](),[[CustomRectInterpolator]]())
        var initialInterpolatorForArea = [[CustomRectInterpolator]]()
        
        if BarHelperFunctions.isStacked(chart: chart) {
        
            barRectArray = prepareInitialBarRect(chart: chart, oldRect: oldRectArray, newRect: newRectArray, selectedDataset: selectedDataset) ?? []
        }
        
        if isLinePlotTypes {
            
            if let linePlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line]) as? PlotOptionsBase
            {
                if linePlot.isStacked {
                    
                    (initalDatasetForStackedLine,initalInterpolatorForStackedLine) = prepareInitialRectForLineFillPath(isRotated: chart.isRotated, lineDataSet: lineDataSets, lineRect: lineRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
                }
            }
            
            if let areaPlot = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Area]) as? PlotOptionsBase
            {
                if areaPlot.isStacked {
                    
                    (initalDatasetForStackedArea,initalInterpolatorForStackedArea) = prepareInitialRectForLineFillPath(isRotated: chart.isRotated, lineDataSet: areaDataSets, lineRect: areaRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
                }
                else {
                    
                    var areaRectArray = [[CGRect]]()
                    
                    let areaDataset = chartData.dataSets.filter({
                        ($0.plotType == .Area) && ($0.isVisible) && $0.entryCount > 0
                              })
                
                    areaDataset.forEach({
                        areaRectArray.append(LineHelperFunctions.prepareDataSetArray(selectedDataset: $0, chart: chart))
                    })
                    
                    initialInterpolatorForArea = prepareInitialRectForAreaFillPath(isRotated: chart.isRotated,lineDataSet: areaDataset, lineRect: areaRectArray, oldBaseValue: oldBaseValue, newBaseValue: newBaseValue)
                }
            }
        }
        
        if chart.plotTypes.contains(.LineRange) {
            initalInterpolatorForStackedLine = prepareIncludeInterpolationForLineRange(dataSets: chartData.dataSets,  selectedDataset: selectedDataset, oldRect: oldRectArray, newRect: newRectArray)
        }
        
        if !chart.plotTypes.contains(.Radar) {
            calculateCurrentDataAndSetOldMinMax(axisChartBase: chart)
        }
        
        guard let (rectInterpolator,opacityInterpolator,stackedBarInterpolator,bubblePieInterpolator) = prepareInterpolationForIncludeAnimation(oldDataSetArray: oldRectArray, newDataSetArray: newRectArray, chart: chart,selectedDataset: selectedDataset,barRectArray: barRectArray, lineRectArray: lineRectArray, areaRectArray: areaRectArray, oldBaseLineValue: oldPosition, newBaseLineValue: position.y) else {
            return
        }
        
        let extraInterpolator = prepareIncludeInterpolationForExtras(chart: chart, oldRect: oldFilterArray, newRect: newFilterArray, oldFinalRect: newRectArray, selectedDataset: selectedDataset)
        
        let defaultOpacityInterpolator = Interpolator.interpolate(a: Double(1), b: Double(1))
        
        let dataSets = chartData.dataSets
        
        let alignAnimator = Animator()
        
        alignAnimator.updateBlock = {
            
            var rectInterpolatorIndex = 0
            
            var oldRectIndex = 0
            
            var bubblePieIndex = 0
            
            var lineRangeInterpolationIndex = 0
            
            var areaDatasetIndex = 0
            
            setForcedValue(axisChartBase: chart, enable:true)
            
            for setIndex in 0..<dataSets.count {
                
                if !dataSets[setIndex].visible || dataSets[setIndex].entryCount <= 0 || newRectArray[setIndex].isEmpty {
                    continue
                }
                
                //MARK: align animation
                
                if !selectedDataset.contains(where: { $0 ===  dataSets[setIndex]}) {
                
                    switch dataSets[setIndex].plotType {
                        
                        case .Bar,.WaterFall,.Mekko:
                        
                        
                        guard let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions else{
                                continue
                            }
                    
                            if plotOption.isStacked{
                                
                                var val = 0
                                
                                if chart.isRotated{
                                    val = 1
                                }

                                positionAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex], interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator,originVal: val)
                                
                                sizeAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex], interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator,sizeVal: val)
                            
                            }
                            else{
                        
                                barAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                            }
                        
                            break
                        
                        case .Line,.LineRange,.Radar,.Scatter,.BubblePie,.Area:
                        
                            positionAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator,originVal: 2)
                        
                            if dataSets[setIndex].plotType == .LineRange {
                       
                                positionAnimationForLine(oldDatasetRectArray: oldRectArray[oldRectIndex],interpolation: initalInterpolatorForStackedLine[lineRangeInterpolationIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                
                                lineRangeInterpolationIndex += 1
                            }
                        
                            if dataSets[setIndex].plotType == .Line {
                   
                                if let linePlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Line]) as? LinePlotOptions {
              
                                    if linePlotOption.isStacked {
                                
                                        var index = -1
                                    
                                        for lineDatasetIndex in 0..<initalDatasetForStackedLine.count {
                                        
                                            if initalDatasetForStackedLine[lineDatasetIndex] === dataSets[setIndex] {
                                                index = lineDatasetIndex
                                            }
                                        }
                                    
                                        if index > -1{
                                        
                                            let oldRect = getInitialRectForLineFillPath(isRotated: chart.isRotated, oldRect: oldRectArray[oldRectIndex], BaseValue: oldBaseValue)
                                        
                                            positionAnimationForLine(oldDatasetRectArray: oldRect, interpolation: initalInterpolatorForStackedLine[index], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                        }
                                
                                    }
                                }
                            }
                        
                        if dataSets[setIndex].plotType == .Area {
               
                            if let linePlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Area]) as? LinePlotOptions {
          
                                if linePlotOption.isStacked {
                            
                                    var index = -1
                                
                                    for lineDatasetIndex in 0..<initalDatasetForStackedArea.count {
                                    
                                        if initalDatasetForStackedArea[lineDatasetIndex] === dataSets[setIndex] {
                                            index = lineDatasetIndex
                                        }
                                    }
                                
                                    if index > -1{
                                    
                                        let oldRect = getInitialRectForLineFillPath(isRotated: chart.isRotated, oldRect: oldRectArray[oldRectIndex], BaseValue: oldBaseValue)
                                    
                                        positionAnimationForLine(oldDatasetRectArray: oldRect, interpolation: initalInterpolatorForStackedArea[index], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                    }
                            
                                }
                                else {
                                    if let lineDatasetOption = dataSets[setIndex].dataSetOptions as? LineDataSetOptions {
                                        
                                        if lineDatasetOption.isDrawFilledEnabled {
                                            
                                            let oldRect = getInitialRectForLineFillPath(isRotated: chart.isRotated, oldRect: oldRectArray[oldRectIndex], BaseValue: oldBaseValue)
                                            
                                            if let interpolator = initialInterpolatorForArea[safe:areaDatasetIndex] {
                                                positionAnimationForLine(oldDatasetRectArray: oldRect, interpolation: interpolator, chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                                            }
                                            areaDatasetIndex += 1
                                        }
                                    }
                                }
                            }
                        }
                        
                            break
                        
                        case .Bubble,.PackedBubble:
                        
                            barAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex], interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                        
                            break
                        
                        case .BoxPlot:
                        
                            barAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                        
                            whiskersAnimation(oldDatasetRectArray: oldRectArray[oldRectIndex],interpolation: extraInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator)
                    
                        default:
                            break
                    }
                    
                    oldRectIndex += 1
                }
                else{
                    
                    if dataSets[setIndex].plotType == .BubblePie {
                    
                        performBubblePieAnimation(chart: chart, dataSet: dataSets[setIndex], Interpolation: bubblePieInterpolator[bubblePieIndex], animation: alignAnimator)
                
                        bubblePieIndex += 1
                        
                    }
                    else if dataSets[setIndex].plotType == .Line || dataSets[setIndex].plotType == .Radar || dataSets[setIndex].plotType == .Area {

                        if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? PlotOptionsBase {

                            if plotOption.isStacked {
                            
                                positionAnimation(oldDatasetRectArray: newRectArray[setIndex],interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: alignAnimator,originVal: 2)
                            }
                            else{
                                for entryIndex in 0..<dataSets[setIndex].entryCount{
                        
                                    if let entry = dataSets[setIndex].entryForIndex(entryIndex) {
                                        
                                        entry.opacityChanged = 0.0
                                    }
                                }
                                
                                if dataSets[setIndex].plotType == .Area {
                                    areaDatasetIndex += 1
                                }
                            }
                        }
                    }
                    else {
                        for entryIndex in 0..<dataSets[setIndex].entryCount{
                    
                            if let entry = dataSets[setIndex].entryForIndex(entryIndex) {
                                    
                                entry.opacityChanged = 0.0
                            }
                        }
                    }
                }
                    
                rectInterpolatorIndex += 1
            }
            
            animateTickLabelModel(chart: chart, phaseX: alignAnimator.phaseX, oldAxisTickLabelMobelObject: oldTicklabelModels, newAxisTickLabelMobelObject: newTicklabelModels, oldAxisTickLabelPositionsObject: oldTicklabelPositionArray)
            
            animateViewPort(chart: chart, fromViewPortRect: fromViewPortRect, toViewPortRect: toViewPortRect, fromChartSize: fromChartSize, toChartSize: toChartSize, phaseX: alignAnimator.phaseX)
            
            chart.setNeedsDisplay()
            
        }
        
        alignAnimator.stopBlock =
        { [unowned alignAnimator] in
            
            alignAnimator.updateBlock = nil
            
            if selectedDataset.contains(where: { $0.plotType == .BubblePie }){
                
                resetPlotData(selectedDataset: selectedDataset,originalVal: originalVal)
            }
            
            let includeAnimator = Animator()
            
            includeAnimator.updateBlock = {
                
                var rectInterpolatorIndex = 0
                
                var oldRectIndex = 0
                
                var stackedInterpolatorIndex = 0
                
                for setIndex in 0..<dataSets.count {
                    
                    if !dataSets[setIndex].visible || dataSets[setIndex].entryCount <= 0 || newRectArray[setIndex].isEmpty {
                        continue
                    }
                    
                    //MARK: include animation
                    
                    if selectedDataset.contains(where: { $0 ===  dataSets[setIndex]}) {
                        
                        if let notes = chart.notes, let opacityInterpolator = opacityInterpolator {
                            performOpacityAnimationForNotes(notes: notes, datasetIndex: chartData.indexOfDataSet(dataSets[setIndex]), opacInterpolator: opacityInterpolator, animation: includeAnimator)
                        }
                        
                        switch dataSets[setIndex].plotType {
                            
                            case .Bar,.WaterFall,.Mekko:
                            
                                if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {
                            
                                    if plotOption.isStacked {
                                    
                                        let initialRectArray = prepareStackedBarRect(chart: chart, selectedDataSetIndex: setIndex, selectedDatasetRect: newRectArray[setIndex], barRectArray: barRectArray,selectedDataSets: selectedDataset, baseLineValue: position.y)//prepareStackedBarRect(chart: chart, dataSets: dataSets, selectedDataSet: dataSets[setIndex], selectedDatasetRect: newRectArray[setIndex], barRectArray: barRectArray,selectedDataSets: selectedDataset, baseLineValue: position.y)
                                    
                                        barAnimation(oldDatasetRectArray: initialRectArray, interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: includeAnimator)
                                    }
                                    else{
                                        
                                        let includeDataSetArray = getFinalIncludeRectArray(chart: chart,dataSet: dataSets[setIndex],baseLineValue: baseLineValue, dataSetRectArray: newRectArray[setIndex])

                                        barAnimation(oldDatasetRectArray: includeDataSetArray,interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: includeAnimator)

                                    }
                                    
                                    performOpacityAnimation(opacInterpolator: defaultOpacityInterpolator, dataSet: dataSets[setIndex], newDataSetRect: newRectArray[setIndex], animator: includeAnimator,isCenterChanged: false)
                                }
                                        
                            
                                break
                            
                            case .Bubble,.Scatter,.PackedBubble:
                            
                                if let opacityInterpolator = opacityInterpolator
                                {
                            
                                    performOpacityAnimation( opacInterpolator: opacityInterpolator, dataSet: dataSets[setIndex], newDataSetRect: newRectArray[setIndex], animator: includeAnimator,isCenterChanged: true)
                                }
                                
                                break
                            
                            case .Line,.LineRange, .Radar, .Area:
                            
                                if let opacityInterpolator = opacityInterpolator
                                {
                                    
                                    let isCenterChangeNeeded = dataSets[setIndex].plotType == .Line || dataSets[setIndex].plotType == .Area ? true : false
                        
                                    performOpacityAnimation( opacInterpolator: opacityInterpolator, dataSet: dataSets[setIndex], newDataSetRect: newRectArray[setIndex], animator: includeAnimator,isCenterChanged: isCenterChangeNeeded)
                                    
                                    if dataSets[setIndex].plotType == .LineRange {
                                        for entryIndex in 0..<dataSets[setIndex].entryCount{
                                            
                                            let entry = dataSets[setIndex].entryForIndex(entryIndex)
                                            
                                            entry?.centerChanged = nil
                                            entry?.lineCenterChanged = nil
                                            
                                        }
                                    }
                                    
                                    if dataSets[setIndex].plotType == .Line || dataSets[setIndex].plotType == .Area {

                                        if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? PlotOptionsBase {

                                            if plotOption.isStacked || (dataSets[setIndex].dataSetOptions as? LineDataSetOptions)?.drawFilledEnabled ?? false {

                                                for entryIndex in 0..<dataSets[setIndex].entryCount {
                                                
                                                    if let entry = dataSets[setIndex].entryForIndex(entryIndex) {
                                                    entry.lineCenterChanged = nil
                                                    }
                                                }
                                            
                                            }
                                        }
                                    }
                                }
                                break
                            
                            case .BoxPlot:
                            
                                let baseLineValue: Double = -.greatestFiniteMagnitude
                            
                                let includeDataSetArray = getFinalIncludeRectArray(chart: chart,dataSet: dataSets[setIndex],baseLineValue: baseLineValue, dataSetRectArray: newRectArray[setIndex])

                                barAnimation(oldDatasetRectArray: includeDataSetArray,interpolation: rectInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: includeAnimator)

                                performOpacityAnimation(opacInterpolator: defaultOpacityInterpolator, dataSet: dataSets[setIndex], newDataSetRect: newRectArray[setIndex], animator: includeAnimator,isCenterChanged: false)
                            
                                whiskersAnimation(oldDatasetRectArray: includeDataSetArray,interpolation: extraInterpolator[rectInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: includeAnimator)
                            
                            
                            default:
                                break
                        }
                     
                        rectInterpolatorIndex += 1
                        
                        continue
                    }
                    else{
                        
                        if dataSets[setIndex].plotType == .Bar || dataSets[setIndex].plotType == .WaterFall ||
                            dataSets[setIndex].plotType == .Mekko {
                        
                            if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {
                        
                                if plotOption.isStacked {
                                
                                    let initialRectArray = prepareinitialRectForIncludeAnim(chart: chart, oldDataSetArray: oldRectArray[oldRectIndex], newDataSetArray: newRectArray[setIndex])
                                
                                    barAnimation(oldDatasetRectArray: initialRectArray, interpolation: stackedBarInterpolator[stackedInterpolatorIndex], chart: chart, dataSet: dataSets[setIndex], animator: includeAnimator)
                                    
                                    stackedInterpolatorIndex += 1
                                }
                            }
                        }
                        
                        oldRectIndex += 1
                    }
                    
                    rectInterpolatorIndex += 1
                }
                
                chart.setNeedsDisplay()
                
            }
            
            includeAnimator.stopBlock = { [unowned includeAnimator] in
                includeAnimator.updateBlock = nil
            }
            
            includeAnimator.animate(xAxisDuration: exitDuration/2)
        }
        
        alignAnimator.animate(xAxisDuration: exitDuration/2,easingOption: .linear)
    }
    
    static func
    prepareInterpolationForIncludeAnimation
    (oldDataSetArray:[[CGRect]], newDataSetArray:[[CGRect]], chart:ChartViewBase, selectedDataset: [IChartDataSet], barRectArray: [[CGRect]], lineRectArray: [[CGRect]], areaRectArray: [[CGRect]], oldBaseLineValue: CGPoint, newBaseLineValue: CGFloat) -> ( [[CustomRectInterpolator]], ((Double) -> Double)?, [[CustomRectInterpolator]], [[((Double) -> Double)]])? {
        
        guard let dataSets = chart.data?.dataSets else{
            return nil
        }
        
        if oldDataSetArray.count <= 0 || newDataSetArray.count <= 0{
            return nil
        }
        
        var rectInterpolateArray:[[CustomRectInterpolator]] = []
        
        var stackedBarInterpolateArray:[[CustomRectInterpolator]] = []
        
        var opacityInterpolateArray: ((Double) -> Double)?
        
        var bubblePieInterpolatorArray: [[((Double) -> Double)]] = []
        
        var newRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if !dataSets[setIndex].visible || newDataSetArray[setIndex].count <= 0{
                continue
            }
            
            if selectedDataset.contains(where: { $0 === dataSets[setIndex] }) {
                
                opacityInterpolateArray = Interpolator.interpolate(a: Double(-0.5), b: Double(1))
                
                
                var setEntriesRectInterpolator: [CustomRectInterpolator] = [CustomRectInterpolator]()
                
                
                if dataSets[setIndex].plotType == .Bar || dataSets[setIndex].plotType == .WaterFall || dataSets[setIndex].plotType == .BoxPlot ||
                    dataSets[setIndex].plotType == .Mekko {
                    
                    var filterDataSetArray: [CGRect] = [CGRect]()
                    
                    if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {
                    
                        if plotOption.isStacked {
                            
                            filterDataSetArray = prepareStackedBarRect(chart: chart, selectedDataSetIndex: setIndex, selectedDatasetRect: newDataSetArray[setIndex], barRectArray: barRectArray,selectedDataSets: selectedDataset, baseLineValue: newBaseLineValue)//prepareStackedBarRect(chart: chart, dataSets: dataSets, selectedDataSet: dataSets[setIndex], selectedDatasetRect: newDataSetArray[setIndex], barRectArray: barRectArray,selectedDataSets: selectedDataset, baseLineValue: newBaseLineValue)
                            
                        }
                        else{
                            
                            var baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: dataSets[setIndex])
                            
                            if dataSets[setIndex].plotType == .BoxPlot {
                                baseLineValue = -.greatestFiniteMagnitude
                            }
                            
                            filterDataSetArray = getFinalIncludeRectArray(chart: chart, dataSet: dataSets[setIndex], baseLineValue: baseLineValue, dataSetRectArray: newDataSetArray[setIndex])
                            
                        }
                        
                        setEntriesRectInterpolator = getRectInterpolatorArray(dataSet: dataSets[setIndex], oldDataSetArray: filterDataSetArray, newDataSetArray: newDataSetArray[setIndex])
                    }
                    
                }
                
                if dataSets[setIndex].plotType == .Line || dataSets[setIndex].plotType == .Radar || dataSets[setIndex].plotType == .Area {
                    if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? PlotOptionsBase {
                        
                        if plotOption.isStacked {
                            
                            let (finalDataSetArray,previousDataset) = prepareStackedLineRect(isRotated: chart.isRotated, dataSets: dataSets, selectedDataSets: selectedDataset, selectedDatasetIndex: setIndex, selectedDatasetRect: newDataSetArray[setIndex], LineRectArray: dataSets[setIndex].plotType == .Area ? areaRectArray : lineRectArray, baseLineValue: oldBaseLineValue)
                            
                            setEntriesRectInterpolator = getRectInterpolatorArray(currentDataset: dataSets[setIndex],previousDataset: previousDataset,oldDataSetArray: newDataSetArray[setIndex],newDataSetArray: finalDataSetArray, isInclude: true)
                            
                        }
                    }
                }
                
                if dataSets[setIndex].plotType == .BubblePie{
                    
                    bubblePieInterpolatorArray.append(prepareBubblePieInterpolationForInclude(selectedDataSet: dataSets[setIndex]))
                }
                
                rectInterpolateArray.append(setEntriesRectInterpolator)
                
                continue
            }
            
            let setEntriesRectInterpolator = getRectInterpolatorArray(dataSet: dataSets[setIndex], oldDataSetArray: oldDataSetArray[newRectIndex], newDataSetArray: newDataSetArray[setIndex])
            
            rectInterpolateArray.append(setEntriesRectInterpolator)
            
            if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions {
                
                if plotOption.isStacked {
                    
                    let initialRectArray = prepareinitialRectForIncludeAnim(chart: chart, oldDataSetArray: oldDataSetArray[newRectIndex], newDataSetArray: newDataSetArray[setIndex])
                    
                    let setEntriesRectInterpolator = getRectInterpolatorArray(dataSet: dataSets[setIndex], oldDataSetArray: initialRectArray, newDataSetArray: newDataSetArray[setIndex])
                    
                    stackedBarInterpolateArray.append(setEntriesRectInterpolator)
                }
            }
            
            newRectIndex += 1
            
        }
        
        return (rectInterpolateArray,opacityInterpolateArray,stackedBarInterpolateArray,bubblePieInterpolatorArray)
    }
    
    static func prepareInitialBarRect(chart: ChartViewBase,oldRect: [[CGRect]],newRect: [[CGRect]],selectedDataset: [IChartDataSet]) -> [[CGRect]]? {
        
        guard let dataSets = chart.data?.dataSets else{
            return nil
        }
        
        var initialRect: [[CGRect]] = [[CGRect]]()
        
        var newRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if selectedDataset.contains(where: { $0 === dataSets[setIndex] }) || !dataSets[setIndex].visible || dataSets[setIndex].entryCount <= 0 {
                continue
            }
            
            if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSets[setIndex].plotType]) as? BarPlotOptions{
                
                if plotOption.isStacked{
                
                    let initialRectArray = prepareinitialRectForIncludeAnim(chart:  chart,oldDataSetArray: oldRect[newRectIndex], newDataSetArray: newRect[setIndex])
                
                    initialRect.append(initialRectArray)
                }
            }
            
            newRectIndex += 1
            
        }
        
        return initialRect
        
    }
    
    static func getFinalIncludeRectArray(chart: ChartViewBase,dataSet: IChartDataSet, baseLineValue: Double, dataSetRectArray: [CGRect]) -> [CGRect] {
        
        var newRect: [CGRect] = [CGRect]()
        
        
        for entryIndex in 0..<dataSet.entryCount{
            
            guard let entry = dataSet.entryForIndex(entryIndex)
            else { continue }
            
            let abovebaseLine = entry.y > baseLineValue
            
            let rect = dataSetRectArray[entryIndex]
            
            if !chart.isRotated {
                
                if abovebaseLine{
                    newRect.append(CGRect(x: rect.minX, y: rect.maxY, width: rect.width, height: 0.0))
                }
                else{
                    newRect.append(CGRect(x: rect.minX, y: rect.minY, width: rect.width, height: 0.0))
                }
            }
            else {
                
                if abovebaseLine{
                    newRect.append(CGRect(x: rect.minX, y: rect.minY, width: 0.0, height: rect.height))
                }
                else{
                    newRect.append(CGRect(x: rect.maxX, y: rect.minY, width: 0.0, height: rect.height))
                }
            }
        }
        
        return newRect
    }
    
    static func prepareinitialRectForIncludeAnim(chart: ChartViewBase,oldDataSetArray: [CGRect] ,newDataSetArray: [CGRect]) -> [CGRect] {
        
        var includeRect: [CGRect] = [CGRect]()
        
        if newDataSetArray.count != oldDataSetArray.count {
            return includeRect
        }
        
        if chart.isRotated{
            for index in 0..<oldDataSetArray.count{
                includeRect.append(CGRect(x: oldDataSetArray[index].minX, y: newDataSetArray[index].minY, width: oldDataSetArray[index].width, height: newDataSetArray[index].height))
            }
        }
        else{
            for index in 0..<oldDataSetArray.count{
                includeRect.append(CGRect(x: newDataSetArray[index].minX, y: oldDataSetArray[index].minY, width: newDataSetArray[index].width, height: oldDataSetArray[index].height))
            }
        }
        
        return includeRect
    }
    
    static func prepareBubblePieInterpolationForInclude(selectedDataSet: IChartDataSet) -> [((Double) -> Double)] {
        
        var bubblePieInterpolatorArray: [((Double) -> Double)] = []
        
        
        for entryIndex in 0..<selectedDataSet.entryCount {
            
            guard let entry = selectedDataSet.entryForIndex(entryIndex), let plotVal = (entry.plotData as? Double) else {
                continue
            }
            
            bubblePieInterpolatorArray.append(Interpolator.interpolate(a: 0.0, b: plotVal))
            
        }
        
        return bubblePieInterpolatorArray
    }
    
    static func resetPlotData(selectedDataset: [IChartDataSet],originalVal: [Double]){
            
        var valIndex = 0
            
        for setIndex in 0..<selectedDataset.count{
                
            if selectedDataset[setIndex].plotType == .BubblePie{
                    
                for entryIndex in 0..<selectedDataset[setIndex].entryCount{
                        
                    guard let entry = selectedDataset[setIndex].entryForIndex(entryIndex) else {
                        continue
                    }
                        
                    entry.plotData = originalVal[safe:valIndex] as AnyObject
                        
                    valIndex += 1
                        
                }
            }
                
        }
    }
}

// BoxPlot
extension ChartInteractionHelperFunction {
    
    static func prepareArrayForFilterValues(chart: ChartViewBase) -> [[[CGRect?]]] {
        
        var tempDatasetPoints:[[[CGRect?]]] = []
        
        guard (chart.data?._dataSets) != nil
        else { return  tempDatasetPoints}
        
        for dataset in (chart.data?._dataSets)!
        {
            if !(dataset.isVisible)
            {
                tempDatasetPoints.append([[CGRect?]]())
                continue
            }
            
            switch dataset.plotType
            {
                case .BoxPlot:
                    tempDatasetPoints.append(BoxPlotHelperFunctions.prepareArrayOfPlotValues(chart: chart, dataset: dataset))
                
                default:
                    break
            }
        }
        
        return tempDatasetPoints
    }
    
    static func preformWhiskersAnimation(layer: BarLayer,rect: CGRect, percent: Double) -> CGMutablePath {
        
        guard let chart = layer.chartView,
              let BoxPlotPlotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.BoxPlot]) as? BoxPlotPlotOptions else {
            return CGMutablePath()
        }
        
        guard (layer.chartEntry) != nil
        else { return  CGMutablePath()}
        let (minWhiskersPoint,maxWhiskersPoint,_) = BoxPlotHelperFunctions.getPlotValues(chart: chart, entry: layer.chartEntry!)
        
        if minWhiskersPoint != nil && maxWhiskersPoint != nil {
            
            var newPath = CGMutablePath()
        
            if !chart.isRotated {
            
                let barWidth = rect.width / 2.0 * BoxPlotPlotOption.whiskersBandWidth
            
                let firstQuartilePoint = CGPoint(x: rect.midX, y: rect.maxY)
            
                let thridQuartilePoint = CGPoint(x: rect.midX, y: rect.minY)
            
                let minWhiskersInterPolation = Interpolator.interpolate(a: minWhiskersPoint!.y, b: rect.maxY)
            
                let maxWhiskersInterPolation = Interpolator.interpolate(a: maxWhiskersPoint!.y, b: rect.minY)
            
                WhiskersLayer.getInitialPathForWhiskers(path: &newPath, from: firstQuartilePoint, to: CGPoint(x: minWhiskersPoint!.x, y: minWhiskersInterPolation(percent)), whiskersWidthHalf: barWidth)
            
                WhiskersLayer.getInitialPathForWhiskers(path: &newPath, from: thridQuartilePoint, to: CGPoint(x: maxWhiskersPoint!.x, y: maxWhiskersInterPolation(percent)), whiskersWidthHalf: barWidth)
            }
            else {
                
                let barHeight = rect.height / 2.0 * BoxPlotPlotOption.whiskersBandWidth
            
                let firstQuartilePoint = CGPoint(x: rect.minX, y: rect.midY)
            
                let thridQuartilePoint = CGPoint(x: rect.maxX, y: rect.midY)
            
                let minWhiskersInterPolation = Interpolator.interpolate(a: minWhiskersPoint!.x, b: rect.minX)
            
                let maxWhiskersInterPolation = Interpolator.interpolate(a: maxWhiskersPoint!.x, b: rect.maxX)
            
                WhiskersLayer.getInitialPathForHorizontalWhiskers(path: &newPath, from: firstQuartilePoint, to: CGPoint(x: minWhiskersInterPolation(percent), y: minWhiskersPoint!.y), whiskersHeightHalf: barHeight)
            
                WhiskersLayer.getInitialPathForHorizontalWhiskers(path: &newPath, from: thridQuartilePoint, to: CGPoint(x: maxWhiskersInterPolation(percent), y: maxWhiskersPoint!.y), whiskersHeightHalf: barHeight)
                
            }
            /*
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: layer.chartEntry!) {
                whiskerLayer.opacity = 1.0
                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: newPath), duration: animationDuration)
            }
            */
            return newPath
        }
        
        return CGMutablePath()
    }
    
    static func prepareHideInterpolationForExtras(chart: ChartViewBase, oldRect: [[[CGRect?]]], newRect: [[[CGRect?]]], oldFinalRect: [[CGRect]],selectedDataset: [IChartDataSet]) -> [[[CustomRectInterpolator]]] {
        
        var interpolationArray = [[[CustomRectInterpolator]]]()
        
        guard let dataSets = chart.data?.dataSets else{
            return interpolationArray
        }
        
        if oldRect.count <= 0 || newRect.count <= 0 {
            return interpolationArray
        }
        
        var newRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if !dataSets[setIndex].visible || oldRect[setIndex].count <= 0 {
                continue
            }
            
            if selectedDataset.contains(where: { $0 === dataSets[setIndex] }) {
                interpolationArray.append([[CustomRectInterpolator]]())
                continue
            }
            
            interpolationArray.append(getRectInterpolatorForDataset(chart: chart, dataSet: dataSets[setIndex], oldDataSetArray: oldRect[setIndex], newDataSetArray: newRect[newRectIndex], filterDatasetArray: oldFinalRect[setIndex], isFilterDataset: false))
            
            newRectIndex += 1
        }
        
        return interpolationArray
    }
    
    static func prepareIncludeInterpolationForExtras(chart: ChartViewBase, oldRect: [[[CGRect?]]], newRect: [[[CGRect?]]], oldFinalRect: [[CGRect]],selectedDataset: [IChartDataSet]) -> [[[CustomRectInterpolator]]] {
        
        var interpolationArray = [[[CustomRectInterpolator]]]()
        
        guard let dataSets = chart.data?.dataSets else{
            return interpolationArray
        }
        
        if oldRect.count <= 0 || newRect.count <= 0 {
            return interpolationArray
        }
        
        var newRectIndex = 0
        
        for setIndex in 0..<dataSets.count {
            
            if !dataSets[setIndex].visible || newRect[setIndex].count <= 0 {
                continue
            }
            
            if selectedDataset.contains(where: { $0 === dataSets[setIndex] }) {
                
                interpolationArray.append(getRectInterpolatorForDataset(chart: chart, dataSet: dataSets[setIndex], oldDataSetArray: newRect[setIndex], newDataSetArray: newRect[setIndex], filterDatasetArray: oldFinalRect[setIndex], isFilterDataset: true))

                continue
            }
            
            interpolationArray.append(getRectInterpolatorForDataset(chart: chart,dataSet: dataSets[setIndex], oldDataSetArray: oldRect[newRectIndex], newDataSetArray: newRect[setIndex], filterDatasetArray: oldFinalRect[setIndex], isFilterDataset: false))
            
            newRectIndex += 1
        }
        
        return interpolationArray
    }
    
    static func getRectInterpolatorForDataset(chart: ChartViewBase,dataSet: IChartDataSet,oldDataSetArray: [[CGRect?]],newDataSetArray: [[CGRect?]], filterDatasetArray: [CGRect], isFilterDataset: Bool) -> [[CustomRectInterpolator]] {
        
        var datasetRectInterpolator:[[CustomRectInterpolator]] = []
        
        if !(oldDataSetArray.count == newDataSetArray.count){
            return datasetRectInterpolator
        }
        
        for entryIndex in 0..<dataSet.entryCount {
           
            if let oldEntryRect = oldDataSetArray[safe:entryIndex] {
                
                if isFilterDataset {
                    datasetRectInterpolator.append(getRectInterPolatorForIncludeEntry(chart: chart, oldEntryRect: oldEntryRect, filterRect: filterDatasetArray[entryIndex]))
                }
                else {
                    if let newEntryRect = newDataSetArray[safe:entryIndex] {
                        datasetRectInterpolator.append(getRectInterPolatorForEntry(oldEntryRect: oldEntryRect,newEntryRect: newEntryRect))
                    }
                }
            }
        }
        return datasetRectInterpolator
    }
    
    static func getRectInterpolator(oldRect: CGRect, newRect: CGRect) -> CustomRectInterpolator {
        
        var interpolateXValue: ((Double) -> Double)
        
        var interpolateYValue: ((Double) -> Double)
        
        var interpolateWidth: ((Double) -> Double)
        
        var interpolateHeigth: ((Double) -> Double)
        
        interpolateXValue = Interpolator.interpolate(a: Double(oldRect.origin.x), b: Double(newRect.origin.x))
            
        interpolateWidth = Interpolator.interpolate(a: Double(oldRect.width), b: Double(newRect.width))
            
        interpolateYValue = Interpolator.interpolate(a: Double(oldRect.origin.y), b: Double(newRect.origin.y))
           
        interpolateHeigth = Interpolator.interpolate(a: Double(oldRect.height), b: Double(newRect.height))
        
        return CustomRectInterpolator(x: interpolateXValue, y: interpolateYValue, width: interpolateWidth, height: interpolateHeigth)
    }
    
    static func getRectInterPolatorForEntry(oldEntryRect: [CGRect?],newEntryRect: [CGRect?]) -> [CustomRectInterpolator]{
        
        var entryRectInterpolator: [CustomRectInterpolator] = []
        
        if oldEntryRect.count == newEntryRect.count {
            
            for index in 0..<oldEntryRect.count {
                
                if let oldRect = oldEntryRect[index], let newRect = newEntryRect[index] {
                    entryRectInterpolator.append(getRectInterpolator(oldRect: oldRect, newRect: newRect))
                }
            }
        }
        
        return entryRectInterpolator
    }
    
    static func getRectInterPolatorForIncludeEntry(chart: ChartViewBase, oldEntryRect: [CGRect?], filterRect: CGRect) -> [CustomRectInterpolator] {
        
        var entryRectInterpolator: [CustomRectInterpolator] = []
        
        for index in 0..<oldEntryRect.count {
            if let oldRect = oldEntryRect[index] {
                
                var initialRect = filterRect
                
                if chart.isRotated {
                    initialRect = CGRect(origin: CGPoint(x: initialRect.minX, y: initialRect.minY + initialRect.height / 2.0), size: CGSize())
                }
                else {
                    initialRect = CGRect(origin: CGPoint(x: initialRect.minX + initialRect.width / 2.0, y: initialRect.maxY), size: CGSize())
                }
                
                entryRectInterpolator.append(getRectInterpolator(oldRect: initialRect, newRect: oldRect))
            }
        }
        
        return entryRectInterpolator
    }
    
    // whiskers and median animation
    
    static func whiskersAnimation(oldDatasetRectArray: [CGRect],interpolation: [[CustomRectInterpolator]], chart: ChartViewBase, dataSet: IChartDataSet, animator: Animator) {
        
        if oldDatasetRectArray.count == 0 || !(oldDatasetRectArray.count == interpolation.count) {
            return
        }
        
        for entryIndex in 0..<dataSet.entryCount{
            
            guard let entry = dataSet.entryForIndex(entryIndex)
                else { continue }
            
            entry.filterChanged = filterChangedInterpolatedValues(interpolationArray: interpolation[entryIndex], animator: animator)
        }
    }
    
    static func filterChangedInterpolatedValues(interpolationArray: [CustomRectInterpolator], animator: Animator) -> AnyObject {
        
        var filterChanged = [CGRect]()
        
        for interpolation in interpolationArray {
            
            let origin = CGPoint(x: interpolation.x(animator.phaseX), y: interpolation.y(animator.phaseX))
            
            filterChanged.append(CGRect(origin: origin, size: CGSize()))
        }
        
        return filterChanged as AnyObject
    }
    
    static func datasetForIndexPath(chart: ChartViewBase, indexPath: IndexPath) -> IChartDataSet? {
        
        guard let data = chart.data else {
            return nil
        }
        
        var indexCount = 0
        
        for dataset in data.dataSets {
            
            if !dataset.legendNeeded {
                continue
            }
            
            if indexCount == indexPath.item {
                return dataset
            }
            indexCount += 1
        }
        return nil
    }
}

extension ChartInteractionHelperFunction {
    
    enum AxisCompoundsType: CaseIterable {
        case xAxis
        case yAxis
        case xAxisGridLine
        case yAxisGridLine
    }
    
    struct TickInterpolatorObject<T:NSObject> {
        var tickAnimateModel: [T:TickModel]
    }
    
    struct TickPositionInterpolatorObject<T:NSObject> {
        var tickAnimateModel: [T:CGPoint]
    }
    
    internal static func prepareTickLabelModels(chart: ChartViewBase) -> [AxisCompoundsType:[Int:TickInterpolatorObject<NSObject>]] {
        
        var axisTickLabelMobelsObjectArr: [AxisCompoundsType:[Int:TickInterpolatorObject]] = [:]
        
        for renderer in chart.yAxisRenderers {
            
            guard let axis = renderer.axis as? YAxis else {
                continue
            }
            
            if axis.drawLabelsEnabled {
                getAxisTickLabelModel(model: renderer.tickLabels, scaleType: axis.scaleType, axisTickLabelMobelsObjectArr: &axisTickLabelMobelsObjectArr, axisType: .yAxis, axisIndex: axis.axisIndex)
            }
            
            if axis.isDrawGridLinesEnabled {
                getAxisTickLabelModel(model: renderer.tickPositions, scaleType: axis.scaleType, axisTickLabelMobelsObjectArr: &axisTickLabelMobelsObjectArr, axisType: .yAxisGridLine, axisIndex: axis.axisIndex)
            }
        }
        
        if chart.xAxis.drawLabelsEnabled {
            getAxisTickLabelModel(model: chart.xAxisRenderer.tickLabels, scaleType: chart.xAxis.scaleType, axisTickLabelMobelsObjectArr: &axisTickLabelMobelsObjectArr, axisType: .xAxis, axisIndex: 0)
        }
        
        if chart.xAxis.isDrawGridLinesEnabled {
            getAxisTickLabelModel(model: chart.xAxisRenderer.tickPositions, scaleType: chart.xAxis.scaleType, axisTickLabelMobelsObjectArr: &axisTickLabelMobelsObjectArr, axisType: .xAxisGridLine, axisIndex: 0)
        }
        
        return axisTickLabelMobelsObjectArr
    }
    
    internal static func getAxisTickLabelModel(model: [TickModel], scaleType: ScaleType, axisTickLabelMobelsObjectArr: inout [AxisCompoundsType:[Int:TickInterpolatorObject<NSObject>]], axisType: AxisCompoundsType, axisIndex: Int) {
        
        var ticklabelModelArr = [NSObject:TickModel]()
        
        for tickLabel in model {
            if scaleType == .Ordinal {
                ticklabelModelArr[tickLabel.label as NSObject] = tickLabel
            }
            else {
                ticklabelModelArr[tickLabel.value as NSObject] = tickLabel
            }
        }
        
        if axisTickLabelMobelsObjectArr[axisType] == nil {
            axisTickLabelMobelsObjectArr[axisType] = [:]
        }
        
        axisTickLabelMobelsObjectArr[axisType]?[axisIndex] = TickInterpolatorObject(tickAnimateModel: ticklabelModelArr)
    }
    
    internal static func mergeTickLabelModel<T>(chart: ChartViewBase, ticklabelModelObject : [AxisCompoundsType:[Int:TickInterpolatorObject<T>]]) {
        
        for type in ticklabelModelObject.keys {
            
            if let model = ticklabelModelObject[type] {
                for axisIndex in 0..<model.count {
                    if let tickLabelModelArr = model[axisIndex], let renderer = (type == .yAxis || type == .yAxisGridLine) ? chart.yAxisRenderers[safe:axisIndex] : chart.xAxisRenderer {
                        merge(oldTickLabelModel: tickLabelModelArr, renderer: renderer, isAxisLabelModel: type == .xAxis || type == .yAxis)
                    }
                }
            }
        }
    }
    
    internal static func merge<T>(oldTickLabelModel: TickInterpolatorObject<T>, renderer: AxisRendererBase, isAxisLabelModel: Bool) {
        
        let tickLabels = isAxisLabelModel ? renderer.tickLabels : renderer.tickPositions
        
        let isOrdinal = renderer.axis?.scaleType == .Ordinal
        
        for tickValue in oldTickLabelModel.tickAnimateModel.keys {
            
            if !tickLabels.contains(where: {  isOrdinal ? $0.label as NSObject == tickValue : $0.value as NSObject == tickValue}) {
                
                if isAxisLabelModel {
                    if let tickLabelModel = oldTickLabelModel.tickAnimateModel[tickValue]?.copy() as? TickLabel {
                        renderer.tickLabels.append(tickLabelModel)
                    }
                }
                else {
                    if let tickLabelModel = oldTickLabelModel.tickAnimateModel[tickValue]?.copy() as? TickModel {
                        renderer.tickPositions.append(tickLabelModel)
                    }
                }
            }
        }
    }
    
    internal static func prepareTickLabelPositions<T>(chart: ChartViewBase, tickLabelModelObject: [AxisCompoundsType:[Int:TickInterpolatorObject<T>]]) -> [AxisCompoundsType:[Int:TickPositionInterpolatorObject<NSObject>]] {
        
        var axisTickLabelPositionsObjectArr: [AxisCompoundsType:[Int:TickPositionInterpolatorObject]] = [:]
        
        for type in AxisCompoundsType.allCases {
            if let model = tickLabelModelObject[type] {
                
                if axisTickLabelPositionsObjectArr[type] == nil {
                    axisTickLabelPositionsObjectArr[type] = [:]
                }
                
                for axisIndex in 0..<model.count {
                    if let tickLabelModelArr = model[axisIndex],
                       let renderer = (type == .yAxis || type == .yAxisGridLine) ? chart.yAxisRenderers[safe:axisIndex] : chart.xAxisRenderer {
                        axisTickLabelPositionsObjectArr[type]?[axisIndex] = getAxisTickLabelPositionsObject(renderer: renderer, axisCompoundType: type, isRotated: chart.isRotated, tickLabelValues: tickLabelModelArr)
                    }
                }
            }
        }
        
        return axisTickLabelPositionsObjectArr
        
    }
    
    internal static func getAxisTickLabelPositionsObject<T:NSObject>(renderer: AxisRendererBase, axisCompoundType: AxisCompoundsType, isRotated: Bool, tickLabelValues: TickInterpolatorObject<T>) -> TickPositionInterpolatorObject<NSObject> {
        
        var ticklabelpositions = [NSObject:CGPoint]()
        
        if renderer.axis?.scaleType == .Ordinal {
            return TickPositionInterpolatorObject(tickAnimateModel: ticklabelpositions)
        }
        
        for value in tickLabelValues.tickAnimateModel.keys {
            
            if let value = value as? Double {
                ticklabelpositions[value as NSObject] = (isRotated && (axisCompoundType == .xAxis || axisCompoundType == .xAxisGridLine) || !isRotated && (axisCompoundType == .yAxis || axisCompoundType == .yAxisGridLine)) ? renderer.transformer!.pixelForValues(x: 0.0, y: value) : renderer.transformer!.pixelForValues(x: value, y: 0.0)
            }
            /*
            need to handle for ordinal case
            else if let value = value as? String {
                
            }*/
        }
        
        return TickPositionInterpolatorObject(tickAnimateModel: ticklabelpositions)
    }
    
    internal static func animateTickLabelModel<T>(chart: ChartViewBase, phaseX: CGFloat, oldAxisTickLabelMobelObject: [AxisCompoundsType:[Int:TickInterpolatorObject<T>]], newAxisTickLabelMobelObject: [AxisCompoundsType:[Int:TickInterpolatorObject<T>]], oldAxisTickLabelPositionsObject: [AxisCompoundsType:[Int:TickPositionInterpolatorObject<T>]], newAxisTickLabelPositionsObject: [AxisCompoundsType:[Int:TickPositionInterpolatorObject<T>]] = [:]) {
        
        for renderer in chart.yAxisRenderers {
            
            guard let yAxis = renderer.axis as? YAxis else {
                continue
            }
            
            let axisIndex = yAxis.axisIndex
            
            for type in [AxisCompoundsType.yAxis,AxisCompoundsType.yAxisGridLine] {
                if let oldTickLabelModels = oldAxisTickLabelMobelObject[type]?[axisIndex], let newTickLabelMobels = newAxisTickLabelMobelObject[type]?[axisIndex], let oldTickLabelPositions = oldAxisTickLabelPositionsObject[type]?[axisIndex] {
                    
                    let newTickLabelPositions = newAxisTickLabelPositionsObject[type]?[axisIndex] ?? TickPositionInterpolatorObject(tickAnimateModel: [:])
                    
                    tickLabelAnimationInterpolation(chart: chart, renderer: renderer, phaseX: phaseX,oldTickLabelModels: oldTickLabelModels, newTickLabelModels: newTickLabelMobels, oldTickLabelPositionsArray: oldTickLabelPositions, newTickLabelPositionsArray: newTickLabelPositions, isTicklabelAnimation: type == .yAxis)
                        
                }
            }
        }
        
        // need to handle multi x axis case
        for type in [AxisCompoundsType.xAxis,AxisCompoundsType.xAxisGridLine] {
            if let oldTickLabelModels = oldAxisTickLabelMobelObject[type]?[0], let newTickLabelMobels = newAxisTickLabelMobelObject[type]?[0], let oldTickLabelPositions = oldAxisTickLabelPositionsObject[type]?[0] {
                
                let newTickLabelPositions = newAxisTickLabelPositionsObject[type]?[0] ?? TickPositionInterpolatorObject(tickAnimateModel: [:])
                
                tickLabelAnimationInterpolation(chart: chart, renderer: chart.xAxisRenderer, phaseX: phaseX,oldTickLabelModels: oldTickLabelModels, newTickLabelModels: newTickLabelMobels, oldTickLabelPositionsArray: oldTickLabelPositions, newTickLabelPositionsArray: newTickLabelPositions, isTicklabelAnimation: type == .xAxis)
                
            }
        }
        
    }
    
    internal static func tickLabelAnimationInterpolation<T>(chart: ChartViewBase, renderer: AxisRendererBase, phaseX: CGFloat,oldTickLabelModels: TickInterpolatorObject<T>, newTickLabelModels: TickInterpolatorObject<T>, oldTickLabelPositionsArray: TickPositionInterpolatorObject<T>, newTickLabelPositionsArray: TickPositionInterpolatorObject<T> = TickPositionInterpolatorObject(tickAnimateModel: [:]), isTicklabelAnimation: Bool) {
        
        let newTickLabelPositionArr = newTickLabelPositionsArray
        
        let isxAxis = renderer.axis as? XAxis != nil ? true : false
            
        for tickLabel in isTicklabelAnimation ? renderer.tickLabels : renderer.tickPositions {
            
            guard let value = renderer.axis?.scaleType == .Ordinal ?  tickLabel.label as? T  : tickLabel.value as? T else {
                continue
            }
                
            // update
            if let oldTickLabelModel = oldTickLabelModels.tickAnimateModel[value], let newTicklabelModel = newTickLabelModels.tickAnimateModel[value] {
                tickLabel.point.x = Interpolator.interpolate(a: oldTickLabelModel.point.x, b: newTicklabelModel.point.x)(phaseX)
                tickLabel.point.y = Interpolator.interpolate(a: oldTickLabelModel.point.y, b: newTicklabelModel.point.y)(phaseX)
                
                if tickLabel.isKind(of: TickLabel.self) && oldTickLabelModel.isKind(of: TickLabel.self) && newTicklabelModel.isKind(of: TickLabel.self) {
                    (tickLabel as! TickLabel).angleInRadians = Interpolator.interpolate(a: (oldTickLabelModel as! TickLabel).angleInRadians, b: (newTicklabelModel as! TickLabel).angleInRadians)(phaseX)
                }
            }
            // exit
            else if let oldTickLabelModel = oldTickLabelModels.tickAnimateModel[value] {
                
                if let oldTickLabelPosition = oldTickLabelPositionsArray.tickAnimateModel[value] {
                    if (chart.isRotated && isxAxis || !chart.isRotated && !isxAxis) {
                        tickLabel.point.x = Interpolator.interpolate(a: oldTickLabelModel.point.x, b: oldTickLabelModel.point.x)(phaseX)
                        tickLabel.point.y = Interpolator.interpolate(a: oldTickLabelModel.point.y, b: oldTickLabelPosition.y)(phaseX)
                    }
                    else {
                        tickLabel.point.x = Interpolator.interpolate(a: oldTickLabelModel.point.x, b: oldTickLabelPosition.x)(phaseX)
                        tickLabel.point.y = Interpolator.interpolate(a: oldTickLabelModel.point.y, b: oldTickLabelModel.point.y)(phaseX)
                    }
                }
                
                let alpha = Interpolator.interpolate(a: 1.0, b: 0.0)(phaseX)
                let textColor = chart.getYAxis(atIndex: 0)?.labelTextColor
                (tickLabel as? TickLabel)?.attributes[.foregroundColor]  = textColor?.withAlphaComponent((textColor?.cgColor.alpha ?? 1.0) * alpha)
                
                tickLabel.opacity = alpha
            }
            // entry
            else if let newTickLabelModel = newTickLabelModels.tickAnimateModel[value] {
                    
                if let newTickLabelPosition = newTickLabelPositionArr.tickAnimateModel[value] {
                    
                    if (chart.isRotated && isxAxis || !chart.isRotated && !isxAxis) {
                        tickLabel.point.x = Interpolator.interpolate(a: newTickLabelModel.point.x, b: newTickLabelModel.point.x)(phaseX)
                        tickLabel.point.y = Interpolator.interpolate(a: newTickLabelPosition.y, b: newTickLabelModel.point.y)(phaseX)
                    }
                    else {
                        tickLabel.point.x = Interpolator.interpolate(a: newTickLabelPosition.x, b: newTickLabelModel.point.x)(phaseX)
                        tickLabel.point.y = Interpolator.interpolate(a: newTickLabelModel.point.y, b: newTickLabelModel.point.y)(phaseX)
                    }
                }
                    
                let alpha = Interpolator.interpolate(a: 0.0, b: 1.0)(phaseX)
                let textColor = chart.getYAxis(atIndex: 0)?.labelTextColor
                (tickLabel as? TickLabel)?.attributes[.foregroundColor]  = textColor?.withAlphaComponent((textColor?.cgColor.alpha ?? 1.0) * alpha)
                
                tickLabel.opacity = alpha
            }
        }
    }
    
    internal static func animateViewPort(chart: ChartViewBase, fromViewPortRect: CGRect,toViewPortRect: CGRect,  fromChartSize: CGSize, toChartSize: CGSize, phaseX: CGFloat) {
        
        
        guard let viewPortHandler = chart.viewPortHandler else {
            return
        }
        
        viewPortHandler.animateRectObject.origin.x = Interpolator.interpolate(a: fromViewPortRect.origin.x, b: toViewPortRect.origin.x)(phaseX)
        viewPortHandler.animateRectObject.origin.y = Interpolator.interpolate(a: fromViewPortRect.origin.y, b: toViewPortRect.origin.y)(phaseX)
        viewPortHandler.animateRectObject.size.width = Interpolator.interpolate(a: fromViewPortRect.size.width, b: toViewPortRect.size.width)(phaseX)
        viewPortHandler.animateRectObject.size.height = Interpolator.interpolate(a: fromViewPortRect.size.height, b: toViewPortRect.size.height)(phaseX)
        
        viewPortHandler.animateChartSizeObject.width = Interpolator.interpolate(a: fromChartSize.width, b: toChartSize.width)(phaseX)
        viewPortHandler.animateChartSizeObject.height = Interpolator.interpolate(a: fromChartSize.height, b: toChartSize.height)(phaseX)
    }
    
}
