//
//  GeoMapHelperFunctions.swift
//  zchart
//
//  Created by Aravinth T on 30/11/21.
//

import Foundation


open class GeoMapHelperFunctions {
    

    public static func highLightMapEntry(chart:ChartViewBase,entry:ChartDataEntry?)
    {
        let barLineChart = chart
        
        let range = barLineChart.legend.legendRange
        
        if barLineChart.colorAxis.enabled && entry != nil
        {
            if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: entry!, minimum: floor(range.0), maximum: floor(range.1))) {
                return
            }
        }
        
        barLineChart.lastSelected = nil
        
        for layer in GeoMapLayer.getAllGeoMapLayer(chart: barLineChart, includeBackground: false)
        {
            guard (layer.chartEntry) != nil
            else { continue }
            if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: layer.chartEntry!, minimum: floor(range.0), maximum: floor(range.1)))
            {
                layer.fillColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
                continue
            }
            
            layer.fillColor = barLineChart.colorAxis.getColor(entry: layer.chartEntry!)?.cgColor
            if layer.chartEntry === entry || entry == nil
            {
                layer.opacity = 1
                barLineChart.updateLastSelectedEntry(entry: entry)
            }
            else{
                layer.opacity = 0.5
            }
        }
        
        let high = (barLineChart.lastSelected != nil && barLineChart.lastSelected!.count > 0) ? chart.getHighlightByEntry(barLineChart.lastSelected![0]) : nil
        
        barLineChart.highlightValue(high, callDelegate: false, redrawRequired: false)
    }
    
}
