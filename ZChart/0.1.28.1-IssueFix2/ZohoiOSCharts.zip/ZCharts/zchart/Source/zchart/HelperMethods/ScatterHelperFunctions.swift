//
//  ScatterHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 04/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class ScatterHelperFunctions
{
    /// Scatter :- Highlights Entries in All Dataset with Given Entry X Value
    /// Vertical Line and Circle added
    public static func highlightMultiSeriesEntry(chart:ChartViewBase,entry:ChartDataEntry,point:CGPoint,innerCircleShape:ShapeProperties,outerCircleShape:ShapeProperties)
    {
        guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
        else { return }
         
        plotOption.barGroupSelectionEnabled = true

        let allEntriesAtIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry, includeNan: false, chart: chart)
        
        let highLighLayer = CommonHelperFunctions.createLayer()
        
        var circleLayers:[CAShapeLayer] = []
        
        for entry in allEntriesAtIndex
        {
            guard let circleLayer = ScatterHelperFunctions.highlightEntry(chart: chart, entry: entry, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
            else { continue }
            circleLayers.append(circleLayer)
        }

        let lineLayer = CommonHelperFunctions.getVerticalLineLayer(chart: chart, location: point)
        
        highLighLayer.addSublayer(lineLayer)
        
        for circleLayer in circleLayers
        {
            highLighLayer.addSublayer(circleLayer)
        }
        
        CommonHelperFunctions.addHighlightLayer(chart: chart, layer: highLighLayer)
    }
    
    /// Line :- Highlights Given Entry
    /// Vertical Line, Horizontal Line and Circle added
    public static func highlightSingleEntry(chart:ChartViewBase,entry:ChartDataEntry,point:CGPoint,innerCircleShape:ShapeProperties,outerCircleShape:ShapeProperties)
    {
        let highLighLayer = CommonHelperFunctions.createLayer()
        
        guard let circleLayer = ScatterHelperFunctions.highlightEntry(chart: chart, entry: entry, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
        else { return }
        
        if !(chart.plotTypes.contains(.Radar))
        {
            let lineLayer = CommonHelperFunctions.getVerticalandHorizontalLineLayer(chart: chart, location: point)
        
            highLighLayer.addSublayer(lineLayer)
        }
        
        highLighLayer.addSublayer(circleLayer)
        
        CommonHelperFunctions.addHighlightLayer(chart: chart, layer: highLighLayer)
    }
    
    /// Scatter :- returns Scatter Highlight Layer with Inner and Outer Circle
    public static func highlightEntry(chart:ChartViewBase,entry:ChartDataEntry,innerCircleShape:ShapeProperties,outerCircleShape:ShapeProperties) -> CAShapeLayer?
    {
        let dataSet = chart.data?.getDataSetForEntry(entry)
        
        guard let scatterPoint = (CommonHelperFunctions.getEntryLocation(chart: chart , entry: entry))
        else { return CAShapeLayer() }
        
        let innerCircleRadius = innerCircleShape.size.width/2
        let outerCircleRadius = outerCircleShape.size.width/2
        
        let innerCircleStrokeWidth = innerCircleShape.lineWidth
        let outerCircleStrokeWidth = outerCircleShape.lineWidth
        
        let innerCircleFillColor = innerCircleShape.holeColor == nil ? dataSet?.colors[0].cgColor : innerCircleShape.holeColor?.cgColor
        let outerCircleFillColor = outerCircleShape.holeColor == nil ? dataSet?.colors[0].cgColor : outerCircleShape.holeColor?.cgColor
        
        let innerCircleStrokeColor = innerCircleShape.strokeColor == nil ? dataSet?.colors[0].cgColor : innerCircleShape.strokeColor?.cgColor
        let outerCircleStrokeColor = outerCircleShape.strokeColor == nil ? dataSet?.colors[0].cgColor : outerCircleShape.strokeColor?.cgColor
        
        let innerCircle = CAShapeLayer()
        
//        innerCircle.path = UIBezierPath(arcCenter: scatterPoint, radius: innerCircleRadius - (innerCircleStrokeWidth/2), startAngle: 0, endAngle: 360, clockwise: true).cgPath
        let path = CGMutablePath()
        path.addArc(center: scatterPoint, radius: innerCircleRadius - (innerCircleStrokeWidth/2), startAngle: 0.0, endAngle: 360.0, clockwise: false)
        innerCircle.fillColor = innerCircleFillColor
        
        innerCircle.strokeColor = innerCircleStrokeColor
        
        innerCircle.lineWidth = innerCircleStrokeWidth
        
        innerCircle.lineCap = convertToCAShapeLayerLineCap("round")
        
        //Adding gradient to scatter inner circle layer for highlight
        let gradients = dataSet?.gradients
        if gradients != nil && (gradients?.count)! > 0 {
            
            guard (innerCircle.path != nil)
            else { return CAShapeLayer() }
            _ = GradientLayerRenderer.updateGradientLayer(container: innerCircle, gradientPath: innerCircle.path!, gradient: gradients![0], drawMaskEnabled: true)
        }
        
        let outerCircle = CAShapeLayer()
        
//        let newPath = UIBezierPath(arcCenter: scatterPoint, radius: outerCircleRadius - (outerCircleStrokeWidth/2), startAngle: 0, endAngle: 360, clockwise: true)
        
        let newPath = CGMutablePath()
        newPath.addArc(center: scatterPoint, radius: outerCircleRadius - (outerCircleStrokeWidth/2), startAngle: 0.0, endAngle: 360.0, clockwise: false)
        
        outerCircle.path = newPath//.cgPath
        
        outerCircle.strokeColor = outerCircleStrokeColor
        
        outerCircle.fillColor = outerCircleFillColor
        
        outerCircle.lineCap = convertToCAShapeLayerLineCap("round")
        
        outerCircle.lineWidth = outerCircleStrokeWidth
        
        outerCircle.addSublayer(innerCircle)
        
        return outerCircle
    }
    
    public static func performHighlight(newEntry:ChartDataEntry, chart:ChartViewBase)
    {
        guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
            else { return }
        
        guard let entryLocation = CommonHelperFunctions.getEntryLocation(chart: chart, entry: newEntry)
        else { return }
        
        let innerCircleShape = ShapeProperties()
        innerCircleShape.holeColor = nil // Set nil to fill default dataset color
        innerCircleShape.lineWidth = 2
        innerCircleShape.size = CGSize(width: 8.0, height: 8.0)
        innerCircleShape.strokeColor = NSUIColor.clear
        
        let outerCircleShape = ShapeProperties()
        outerCircleShape.holeColor = NSUIColor.white
        outerCircleShape.lineWidth = 2
        outerCircleShape.size = CGSize(width: 16.0, height: 16.0)
        outerCircleShape.strokeColor = nil
        
        if plotOption.barGroupSelectionEnabled == true
        {
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: newEntry, point: entryLocation, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
        }
        else{
            ScatterHelperFunctions.highlightSingleEntry(chart: chart, entry: newEntry, point: entryLocation, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
        }
        
        // Tooltip delegate
        chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(entryLocation), entry: newEntry)
    }
     
     /////====================== ****************************** ====================== /////
    
    static func maxScatterSize(chart: ChartViewBase) -> CGFloat {
        
        var maxShapeSize = 0.0
        
        guard let dataSets = chart.data?.dataSets else {
            return 0.0
        }
        
        for dataSet in dataSets {
            
            guard dataSet.plotType == .Scatter,
                  let datasetPlotOptions = dataSet.dataSetOptions as? AxisChartDataSetOptions else {
                continue
            }
            
            maxShapeSize = max(maxShapeSize, max(datasetPlotOptions.shapeProperties.size.width, datasetPlotOptions.shapeProperties.size.height))
        }
        
        return maxShapeSize
    }
    
    
    internal static func getAlignmentForDataLabel(chart: ChartViewBase, point: CGPoint, textSize: CGSize) -> NSTextAlignment {
        
        var align: NSTextAlignment = .center
        
        let viewPort = chart._viewPortHandler.contentRect
        
        if viewPort.minX > point.x - textSize.width / 2.0 {
            align = .right
        }
        
        if viewPort.maxX < point.x + textSize.width / 2.0 {
            align = .left
        }
        
        return align
    }
    
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCAShapeLayerLineCap(_ input: String) -> CAShapeLayerLineCap {
	return CAShapeLayerLineCap(rawValue: input)
}
