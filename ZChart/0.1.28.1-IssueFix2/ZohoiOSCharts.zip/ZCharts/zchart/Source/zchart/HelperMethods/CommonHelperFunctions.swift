//
//  HelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 02/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

import Foundation

open class CommonHelperFunctions
{
    public static func getAllLayer(chart: ChartViewBase) -> [ChartEntryLayer]
    {
        var layerArray:[ChartEntryLayer] = []
        
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: ChartEntryLayer.self)
                {
                    layerArray.append((caLayer as! ChartEntryLayer))
                }
            }
        }
        
        
        return layerArray
    }
    
    // MARK: - Processor Function
    
    /// Stack Checking Should be Done before Calling this Method
    internal static func calcPosNegSum(chart:ChartViewBase,plotAllowed:[ChartType]) -> [Int:[Int:Double]]
    {
        // Set Index -> EntryIndex -> YValue
        var entriesStackedYValue:[Int:[Int:Double]] = [:]
        
        var xUniqueValues = Set<Double>()
       
        guard let data = chart.data
              else { return entriesStackedYValue}
        
        let plotDataSets:[IChartDataSet] = data.dataSets.filter({
            plotAllowed.contains($0.plotType)
        })
        
        var xDatasetUniqueValues = [Set<Double>]()
        
        for set in plotDataSets
        {
            var setXValues = Set<Double>()
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else { continue }
                if (entry.x.isNaN)
                {
                    continue
                }
                xUniqueValues.insert((entry.x))
                setXValues.insert((entry.x))
            }
            xDatasetUniqueValues.append(setXValues)
        }
        
        
        for plotSetIndex in  0..<plotDataSets.count
        {
            let currentSet = plotDataSets[plotSetIndex]
            let setIndex = data.indexOfDataSet(currentSet)
            let xValuesToAdd = xUniqueValues.subtracting(xDatasetUniqueValues[setIndex])
            
            for setValue in xValuesToAdd
            {
                let tempEntry = ChartDataEntry(x: setValue, y: Double.nan, data: nil)
                if (chart.data?.xString) != nil &&  Int(setValue) <=  chart.data!.xString!.count
                {
                    tempEntry.xString = chart.data?.xString![Int(setValue)]
                }
                _ = currentSet.addEntryOrdered(tempEntry)
            }
        }
        
        
        var posY:[Double:Double] = [:]
        
        var negY:[Double:Double] = [:]
        
        var posSum:[Double:[Int:Double]] = [:]
        var negSum:[Double:[Int:Double]] = [:]
        
        var maxY = -(Double.greatestFiniteMagnitude)
        var minY = -(Double.greatestFiniteMagnitude)
        
       for plotSetIndex in 0..<plotDataSets.count
        {
           let set = plotDataSets[plotSetIndex]
           let setIndex = data.indexOfDataSet(set)
            if !set.isVisible
            {
                continue
            }
            
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else { continue }
                
                if  entry.x.isNaN
                {
                    continue
                }
                else if entry.y.isNaN
                {
                    var posValue:Double = 0
                    var negValue:Double = 0
                    
                    if set.yMax > 0
                    {
                        if posY[entry.x] != nil
                        {
                            posValue = posY[entry.x]!
                        }
                    }
                    else{
                        if negY[entry.x] != nil
                        {
                            negValue = -negY[entry.x]!
                        }
                    }
                    
                    if entriesStackedYValue[setIndex] == nil {
                        entriesStackedYValue[setIndex] = [:]
                    }
                    
                    if set.yMax > 0
                    {
                        entriesStackedYValue[setIndex]![entryIndex] = posValue
                    }
                    else{
                        entriesStackedYValue[setIndex]![entryIndex] = negValue
                    }
                    
                    continue
                }
                
                if entry.y >= 0
                {
                    if posSum[entry.x] == nil
                    {
                        
                        posSum[entry.x] = [setIndex:entry.y]
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entry.y
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entry.y]
                        }
                        
                        
                        posY[entry.x] = entry.y
                    }
                    else{
                        
                        let  lastPositiveDataSetIndexSoFar = posSum[entry.x]?.keys.max()
                        
                        
                        // CASE :- Same X For differnt entry
                        if lastPositiveDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if posSum[entry.x]?.keys.count == 1
                            {
                                if posSum[entry.x]![setIndex]! < entry.y
                                {
                                    posSum[entry.x]![setIndex] = entry.y
                                    posY[entry.x] = entry.y
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entry.y
                                
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (posSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    //Ignoring the current data set index
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                    
                                }
                                
                                let yValue = posSum[entry.x]![prevDataSetIndex]! + entry.y
                                
                                if yValue > posSum[entry.x]![setIndex]!
                                {
                                    posSum[entry.x]![setIndex] = yValue
                                    posY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                                
                                
                            }
                        }
                        else{
                            let yValue = posSum[entry.x]![lastPositiveDataSetIndexSoFar!]! + entry.y
                            
                            posSum[entry.x]![setIndex] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:yValue]
                            }
                            
                            posY[entry.x] = yValue
                            
                        }
                        
                    }
                    
                }
                else{
                    
                    if negSum[entry.x] == nil
                    {
                        
                        negSum[entry.x] = [setIndex:abs(entry.y)]
                        
                        
                        if entriesStackedYValue[setIndex] != nil
                        {
                            entriesStackedYValue[setIndex]![entryIndex] = entry.y
                        }
                        else{
                            entriesStackedYValue[setIndex] = [entryIndex:entry.y]
                        }
                        
                        negY[entry.x] = abs(entry.y)
                        
                    }
                    else{
                        
                        let  lastNegativeDataSetIndexSoFar = negSum[entry.x]?.keys.max()
                        
                        
                        // CASE :- Same X For differnt entry
                        if lastNegativeDataSetIndexSoFar == setIndex
                        {
                            //  1st dataset
                            if negSum[entry.x]?.keys.count == 1
                            {
                                if negSum[entry.x]![setIndex]! < abs(entry.y)
                                {
                                    negSum[entry.x]![setIndex] = abs(entry.y)
                                    negY[entry.x] = abs(entry.y)
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = entry.y
                            }
                            else{
                                var prevDataSetIndex = -1
                                
                                for sortedDict in  (negSum[entry.x]?.sorted(by: {$0.0 > $1.0}))!
                                {
                                    if prevDataSetIndex == 0
                                    {
                                        prevDataSetIndex = sortedDict.key
                                        break
                                    }
                                    prevDataSetIndex += 1
                                }
                                
                                let yValue = negSum[entry.x]![prevDataSetIndex]! + abs(entry.y)
                                
                                if yValue > negSum[entry.x]![setIndex]!
                                {
                                    negSum[entry.x]![setIndex] = yValue
                                    negY[entry.x] = yValue
                                }
                                
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                        }
                        else{
                            let yValue = negSum[entry.x]![lastNegativeDataSetIndexSoFar!]! + abs(entry.y)
                            
                            negSum[entry.x]![setIndex] = yValue
                            
                            negY[entry.x] = yValue
                            
                            if entriesStackedYValue[setIndex] != nil
                            {
                                entriesStackedYValue[setIndex]![entryIndex] = -yValue
                            }
                            else{
                                entriesStackedYValue[setIndex] = [entryIndex:-yValue]
                            }
                            
                            
                            
                        }
                    }
                }
                
                // Min & Max
                if posY[entry.x] != nil && posY[entry.x]! > maxY
                {
                    maxY = posY[entry.x]!
                }

                if negY[entry.x] != nil && negY[entry.x]! > minY
                {
                    minY = negY[entry.x]!
                }
            }
            
        }
        
        // Need to revise first two lines
       /* data._yMin = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
        data._yMax = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        
       //Need to check on below code based on actual available axis indices
       //otherwise Data yMin/yMax values will be written on all axis Index arrays
       for axisIndex in 0 ..< data._yAxisMinArray.count {
           data._yAxisMinArray[axisIndex] = data._yMin
        }
        
       for axisIndex in 0 ..< data._yAxisMaxArray.count {
           data._yAxisMaxArray[axisIndex] = data._yMax
        }*/
        
         minY = (minY == -Double.greatestFiniteMagnitude) ?  0 : -minY
         maxY = (maxY == -Double.greatestFiniteMagnitude) ?  0 : maxY
        
         if (minY < (data._yAxisMinArray[plotDataSets[0].axisIndex])!){
             data._yAxisMinArray[plotDataSets[0].axisIndex] = minY
         }
        
         if (maxY > (data._yAxisMaxArray[plotDataSets[0].axisIndex])!){
             data._yAxisMaxArray[plotDataSets[0].axisIndex] = maxY
         }
        
         if (minY < data._yMin) {
             data._yMin = minY
         }
        
         if (maxY > data._yMax) {
             data._yMax = maxY
         }
        
        return entriesStackedYValue
    }
    
    // MARK: - Entry
    
    /// Axis Chart :- returns Entry Location
    public static func getEntryLocation(chart:ChartViewBase, entry:ChartDataEntry) -> CGPoint?
    {
        let dataSet = chart.data?.getDataSetForEntry(entry)
        
        guard let chartData = chart.data, let dataSet = dataSet as? ChartDataSet else {
            return nil
        }
        
        let x = entry.x
        var y = entry.y
        
        if (CommonHelperFunctions.getPlotOption(chart: chart, types: [dataSet.plotType]) as? AxisChartPlotOptions)?.isStacked ?? false {
            if let preProcessor = chart.getProcessor(type: dataSet.plotType) as? AxisChartPreprocessor, let stackedYValue = preProcessor.entriesStackedYValue[chartData.indexOfDataSet(dataSet)]?[dataSet.entryIndex(entry: entry)] {
                y = stackedYValue
            }
        }
        
        return getPixelForValues(isRotated: chart.isRotated,x: x, y: y, dataset: dataSet , chart: chart)
    }
    
    /// returns Entry and High Object in Location
    public static func getHighAndEntryForPoint(chart: ChartViewBase, location: CGPoint) -> (high: Highlight?, entry: ChartDataEntry?)
    {
        var entry:ChartDataEntry? = nil
        
        let high = chart.getHighlightByTouchPoint(location)
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
        }
        return (high, entry)
    }
    
    /// returns Entry and High Object from recognizer
    public static func getHighAndEntryForRecognizer(chart: ChartViewBase, recognizer: NSUIGestureRecognizer) -> (high: Highlight?, entry: ChartDataEntry?)
    {
        let location = recognizer.location(in: chart)
        
        return self.getHighAndEntryForPoint(chart: chart, location: location)
    }
    
    /// Need to update
    /// returns Entry which is Above the Touch Location
    public static func getEntryAboveTouchPoint(location:CGPoint, chart: ChartViewBase) -> ChartDataEntry?
    {
        let closestHigh = chart.getHighlightByTouchPoint(location)
        
        var minDiff = CGFloat.greatestFiniteMagnitude
        
        var closestEntry:ChartDataEntry
        
        var entryAboveTouchPoint:ChartDataEntry? = nil
        
        if closestHigh != nil{
            
            guard let eForHigh = chart.entryForHighlight(closestHigh!)
            else { return nil}
            closestEntry = eForHigh
            
            var transformer:Transformer
            
            guard (chart.data?._dataSets) != nil
            else { return nil }
            for dataset in (chart.data?._dataSets)!
            {
                if !(dataset.isVisible)
                {
                    continue
                }

                transformer = chart.getTransformer(axisIndex: dataset.axisIndex)
                
                let entriesAtX = dataset.entriesForXValue(closestEntry.x)
                
                for entry in entriesAtX
                {
                    let yPixel = transformer.pixelForValues(x: (entry.x), y: (entry.y)).y
                    
                    if yPixel > location.y
                    {
                        continue
                    }
                    else{
                        let diff = location.y - yPixel
                        
                        if diff < minDiff
                        {
                            minDiff = diff
                            entryAboveTouchPoint = entry
                        }
                    }
                }
                
            }
        }
        
        return entryAboveTouchPoint
        
    }
    
    /// returns Entries from All Dataset with Given Entry X - Value
    public static func getAllDatasetEntriesAtGivenEntryIndex(entry:ChartDataEntry, includeNan:Bool, chart:ChartViewBase) -> [ChartDataEntry]
    {
        guard let dataSets = (chart.data?.dataSets)
        else { return [] }
        
        let entryIndex =  entry.x
        
        var otherEntries:[ChartDataEntry] = []
        
        for i in  0 ..< dataSets.count
        {
            let set = (dataSets[i])
            if dataSets[i].visible == true{
                
                for setEntry in set.entriesForXValue(entryIndex)
                {
                    if setEntry.y.isNaN && !includeNan
                    {
                        continue
                    }
                    otherEntries.append(setEntry)
                }
            }
            
        }
        
        return otherEntries
    }
    
    
    public static func getNextGreaterXEntry(set:ChartDataSet, xValue:Double, includeYNan:Bool, chart:ChartViewBase) -> ChartDataEntry?
    {
        guard let nextXEntry = set.entryForXValue(xValue, closestToY: Double.nan, rounding: .up)
            else { return nil }
        
        if nextXEntry.x > xValue && !(nextXEntry.y.isNaN)
        {
            return nextXEntry
        }
        else{
            let entryIndex = set.entryIndex(entry: nextXEntry)
            
            for index in entryIndex..<set.entryCount
            {
                guard let entry = set.entryForIndex(index)
                else { continue }
                if entry.x.isNaN || (!includeYNan && entry.y.isNaN)
                {
                    continue
                }
                
                if entry.x > xValue
                {
                    return entry
                }
            }
            
            return nil
        }
    }
    
    /// returns Next X in data
    public static func getNextXEntryinData(entry:ChartDataEntry?, includeXNan:Bool, includeYNan:Bool, loopingAllowed:Bool, chart:ChartViewBase) -> ChartDataEntry?
    {
        if entry == nil
        {
            return CommonHelperFunctions.getNextEntry(entry:entry, includeXNan:includeXNan, includeYNan:includeYNan, chart:chart)
        }
        
        guard let sets = (chart.data?.dataSets)
            else { return nil}
        
        var nextEntry:ChartDataEntry? = nil
        
        for set in sets
        {
            if !(set.isVisible) || (set.entryCount == 0) || (set as? ChartDataSet) == nil
            {
                continue
            }
            
            guard let nextXEntry = CommonHelperFunctions.getNextGreaterXEntry(set: set as! ChartDataSet, xValue: (entry?.x)!, includeYNan: includeYNan, chart: chart)         //set.entryForXValue((entry?.x)!, closestToY: Double.nan, rounding: .up)
                else { continue }
                        
            if (!includeYNan && nextXEntry.y.isNaN) {
                continue
            }
            
            if nextXEntry.x > (entry?.x)!
            {
                if nextEntry != nil
                {
                    if (nextEntry?.x)! > nextXEntry.x
                    {
                        nextEntry = nextXEntry
                    }
                }
                else{
                    nextEntry = nextXEntry
                }
            }
        }
        
        if nextEntry != nil || (nextEntry == nil && !(loopingAllowed)) {
            return nextEntry
        }
        else{
            return getNextEntry(entry:nil,includeXNan:includeXNan, includeYNan:includeYNan, chart:chart)
        }
    }
    
    /// returns Next Entry
    public static func getNextEntry(entry:ChartDataEntry?, includeXNan:Bool, includeYNan:Bool, chart:ChartViewBase) -> ChartDataEntry?
    {
        if entry == nil
        {
            guard let sets = chart.data?._dataSets
                else { return nil}
            
            var nextEntry:ChartDataEntry? = nil
            
            for dataset in sets
            {
                if dataset.isVisible && (dataset.entryCount > 0)
                {
                    let nextValidEntry = getNextEntryAfterIndex(index: dataset.entryCount-1, set: dataset, includeXNan: includeXNan, includeYNan: includeYNan)
                    
                    if nextValidEntry.x.isNaN
                    {
                        continue
                    }
                    
                    if nextEntry != nil
                    {
                        if nextValidEntry.x < (nextEntry?.x)!
                        {
                            nextEntry = nextValidEntry
                        }
                    }
                    else{
                        nextEntry = nextValidEntry
                    }
                }
            }
            
            return nextEntry
        }
        
        guard let set = (chart.data?.getDataSetForEntry(entry))
            else { return nil}
        
        let entryIndex =  set.entryIndex(entry: entry!)
        
        let nextEntry = getNextEntryAfterIndex(index: entryIndex, set: set, includeXNan: includeXNan, includeYNan: includeYNan)
        
        return nextEntry
    }
    
    /// returns Next Entry after index
    public static func getNextEntryAfterIndex(index:Int,set:IChartDataSet,includeXNan:Bool, includeYNan:Bool) -> ChartDataEntry
    {
        let indexCopy = index
        
        guard var nextEntry = set.entryForIndex((index+1)%set.entryCount)
        else { return ChartDataEntry() }
        
        var indexCount = index
        
        repeat {
            
            indexCount = (indexCount + 1) % set.entryCount
            
            guard set.entryForIndex(indexCount) != nil
            else { break }
            
            nextEntry = (set.entryForIndex(indexCount))!
            
        }
        while ( ((nextEntry.x.isNaN) && !(includeXNan)) || ((nextEntry.y.isNaN) && !(includeYNan)) ) && (indexCount != indexCopy)
        
        return nextEntry
    }
    
    /// returns Prev X in data
    public static func getPrevXEntryinData(entry:ChartDataEntry?, includeXNan:Bool, includeYNan:Bool, loopingAllowed:Bool, chart:ChartViewBase) -> ChartDataEntry?
    {
        if entry == nil
        {
            return CommonHelperFunctions.getPrevEntry(entry:entry, includeXNan:includeXNan, includeYNan:includeYNan, chart:chart)
        }
        
        guard let sets = (chart.data?.dataSets)
            else { return nil}
        
        var nextEntry:ChartDataEntry? = nil
        
        for set in sets
        {
            if !(set.isVisible) || (set.entryCount == 0) || (set as? ChartDataSet) == nil
            {
                continue
            }
            
            guard let nextXEntry = CommonHelperFunctions.getPrevLesserXEntry(set: set as! ChartDataSet, xValue: (entry?.x)!, includeYNan: includeYNan, chart: chart)         //set.entryForXValue((entry?.x)!, closestToY: Double.nan, rounding: .up)
                else { continue }
            
            if !includeYNan && nextXEntry.y.isNaN  {
                continue
            }
            
            if (nextXEntry.x < (entry?.x)!)
            {
                if nextEntry != nil
                {
                    if (nextEntry?.x)! < nextXEntry.x
                    {
                        nextEntry = nextXEntry
                    }
                }
                else{
                    nextEntry = nextXEntry
                }
            }
        }
        
        if nextEntry != nil || (nextEntry == nil && !(loopingAllowed)){
            return nextEntry
        }
        else{
            return getPrevEntry(entry:nil,includeXNan:includeXNan, includeYNan:includeYNan, chart:chart)
        }
    }
    
    public static func getPrevLesserXEntry(set:ChartDataSet, xValue:Double, includeYNan:Bool, chart:ChartViewBase) -> ChartDataEntry?
    {
        guard let nextXEntry = set.entryForXValue(xValue, closestToY: Double.nan, rounding: .up)
            else { return nil }
        
        if nextXEntry.x < xValue && !(nextXEntry.y.isNaN)
        {
            return nextXEntry
        }
        else{
            let entryIndex = set.entryIndex(entry: nextXEntry)
            
            for index in (0...entryIndex).reversed()
            {
                guard let entry = set.entryForIndex(index)
                else { continue }
                if entry.x.isNaN || (!includeYNan && entry.y.isNaN)
                {
                    continue
                }
                
                if entry.x < xValue
                {
                    return entry
                }
            }
            
            return nil
        }
    }
    
    /// returns Prev Entry
    public static func getPrevEntry(entry:ChartDataEntry?, includeXNan:Bool, includeYNan:Bool, chart:ChartViewBase) -> ChartDataEntry?
    {
        if entry == nil
        {
            guard let sets = chart.data?._dataSets
                else { return nil}
            
            var prevEntry:ChartDataEntry? = nil

            for dataset in sets
            {
                if dataset.isVisible && (dataset.entryCount > 0)
                {
                    let prevValidEntry = getPrevEntryAfterIndex(index: dataset.entryCount, set: dataset, includeXNan: includeXNan, includeYNan: includeYNan)
                    
                    if prevValidEntry.x.isNaN
                    {
                        continue
                    }
                    
                    if prevEntry != nil
                    {
                        if prevValidEntry.x > (prevEntry?.x)!
                        {
                            prevEntry = prevValidEntry
                        }
                    }
                    else{
                        prevEntry = prevValidEntry
                    }
                }
            }
            
            return prevEntry
        }
        
        guard let set = (chart.data?.getDataSetForEntry(entry))
            else { return nil}
        
        let entryIndex =  set.entryIndex(entry: entry!)
        
        let nextEntry = getPrevEntryAfterIndex(index: entryIndex, set: set, includeXNan: includeXNan, includeYNan: includeYNan)
        
        return nextEntry
    }
    
    /// returns Prev Entry after index
    public static func getPrevEntryAfterIndex(index:Int,set:IChartDataSet,includeXNan:Bool, includeYNan:Bool) -> ChartDataEntry
    {
        let indexCopy = index
        
        guard var nextEntry = set.entryForIndex((index-1)%set.entryCount)
        else { return ChartDataEntry()}
        
        var indexCount = index
        
        repeat {
            indexCount = indexCount == 0 ? set.entryCount : indexCount
            
            indexCount = (indexCount - 1) % set.entryCount
            
            guard set.entryForIndex(indexCount) != nil
            else { break }
            nextEntry = (set.entryForIndex(indexCount))!
            
        }
            while ( ((nextEntry.x.isNaN) && !(includeXNan)) || ((nextEntry.y.isNaN) && !(includeYNan)) ) && (indexCount != indexCopy)
        
        return nextEntry
    }
    
    /// returns visible set count
    public static func getVisibleSetCount(data:ChartData) -> Int
    {
        var setCount = 0
        
        for set in (data.dataSets)
        {
            if set.isVisible
            {
                setCount += 1
            }
        }
        
        return setCount
    }
    
    internal static func entryDatasetIsVisible(data: ChartData, entry: ChartDataEntry) -> Bool {
        
        guard let dataset = data.getDataSetForEntry(entry) else {
            return false
        }
        
        return dataset.isVisible
    }
    
    internal static func getPrevEntryIndex(dataset: IChartDataSet, entryIndex: Int) -> Int {
        
        var prevEntryIndex = entryIndex - 1
        
        var prevEntry = dataset.entryForIndex(prevEntryIndex)
        
        while prevEntry != nil && (prevEntry?.x.isNaN)!
        {
            prevEntryIndex -= 1
            prevEntry = dataset.entryForIndex(prevEntryIndex)
        }
        
        return prevEntryIndex
    }
    
    internal static func getLastDatasetIndexSoFor(stackedGroup: [Int], setIndex: Int) -> Int {
        return stackedGroup.firstIndex(where: { $0 == setIndex}) ?? 0
    }
    
    internal static func getLargestPointSize(datasets: [IChartDataSet]) -> CGFloat {
        
        var pointSize = 0.0
        
        for set in datasets {
            pointSize = max(set.valueFont.pointSize,pointSize)
        }
        
        return pointSize
    }
    
    // MARK: - Plot Options
       
    public static func getPlotOption(chart:ChartViewBase,types:[ChartType]) -> IPlotOptions?
   {
        for type in types
        {
            if let plot = chart.getPlotOptions(type: type)
            {
                return plot
            }
        }
           
        return nil
   }
    
    public static func getProcessor(chart:ChartViewBase,types:[ChartType]) -> ChartPreprocessor?
   {
           for type in types
           {
               if let processor = chart.getProcessor(type: type)
               {
                   return processor
               }
           }
              
           return nil
   }
    
    public static func getRenderer(chart:ChartViewBase, types:[ChartType]) -> DataRenderer?
    {
        for renderer in chart.renderers
        {
            for type in types
            {
                switch  type {
                    
                    case .Pie:
                        if renderer.isKind(of: PieChartRenderer.self)
                        {
                            return renderer
                        }
                        
                    case .Dial:
                        if renderer.isKind(of: DialChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Bar, .Bullet, .Mekko:
                        if renderer.isKind(of: BarChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Sanky:
                        if renderer.isKind(of: SankeyChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .HorizontalBarRange:
                        if renderer.isKind(of: HorizontalBarChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Line, .LineRange:
                        if renderer.isKind(of: LineChartRenderer.self) && !renderer.isKind(of: AreaChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Area:
                        if renderer.isKind(of: AreaChartRenderer.self)
                        {
                            return renderer
                        }
                        
                    case .Bubble:
                        if renderer.isKind(of: BubbleChartRenderer.self)
                        {
                            return renderer
                        }
                        
                    case .BubblePie:
                        if renderer.isKind(of: BubblePieChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .PackedBubble:
                        if renderer.isKind(of: PackedBubbleRenderer.self)
                        {
                            return renderer
                        }
                        
                    case .Scatter:
                        if renderer.isKind(of: ScatterChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Funnel:
                        if renderer.isKind(of: FunnelChartRenderer.self)
                        {
                            return renderer
                        }
                
                    case .HeatMap:
                        if renderer.isKind(of: HeatMapChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Radar:
                        if renderer.isKind(of: RadarChartRenderer.self)
                        {
                            return renderer
                        }
                        
                    case .WordCloud:
                        if renderer.isKind(of: TextChartRenderer.self)
                        {
                            return renderer
                        }
                                        
                    case .GeoHeatMap:
                        if renderer.isKind(of: GeoMapRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .WaterFall:
                        if renderer.isKind(of: WaterFallChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .BoxPlot:
                        if renderer.isKind(of: BoxPlotChartRenderer.self)
                        {
                            return renderer
                        }
                    
                    case .Combined:
                        return nil
                }
            }
        }
        
        return nil
            
    }
    
    public static func isStacked(chart: ChartViewBase) -> Bool {
        guard let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar,.WaterFall,.Mekko,.Line,.Area]) as? PlotOptionsBase
             else { return false }
         
         return plotOptions.isStacked
    }
    
    //MARK: - Axis Chart methods
    public static func getBaseLineValue(chart:ChartViewBase, dataSet:IChartDataSet) -> Double
    {
          var baseLineValue:Double = 0
          
            guard let axis = chart.getYAxis(atIndex: dataSet.axisIndex)
            else { return baseLineValue}
          
          if (axis.baseLineEnabled) {
              baseLineValue = (axis.baseLine?.baseValue) ?? 0
          }
          
          return baseLineValue
    }
    
    public static func checkIfBaseLineValueWithinRange(chart:ChartViewBase)
    {
        for axis in chart.yAxisArray where axis.isEnabled {
            if axis.baseLineEnabled && axis.baseLine != nil
            {
                if (axis.baseLine?.baseValue)! > axis.axisMaximum
                {
                    axis.setAxis(maximum: (axis.baseLine?.baseValue)!)
                }
                if (axis.baseLine?.baseValue)! < axis.axisMinimum
                {
                    axis.setAxis(minimum: (axis.baseLine?.baseValue)!)
                }
            }
        }
    }
    
    public static func getPolarAnchorPoint(angle:CGFloat,chart:ChartViewBase) -> CGPoint
    {
        let linearTransfomer = PolarTransformer(xScaleRange: 1, yScaleRange: 1, startAngle: 0, centerPoint: CGPoint(), radius: 10, viewPortHandler: chart.viewPortHandler)
        linearTransfomer.prepareMatrixValuePx(chartXMin: 90, deltaX: 180, deltaY: 180, chartYMin: 90)
        
        var anchor = CGPoint()
        if (angle >= 0 && angle < 90)  || (angle > 270 && angle <= 360)
        {
            anchor.x = 0
            if (angle > 0 && angle < 90)
            {
                anchor.y = linearTransfomer.pixelForValues(x: Double(angle+90), y: Double(angle+90)).x
            }
            else if (angle > 270 && angle < 360){
                anchor.y = linearTransfomer.pixelForValues(x: Double(angle-90), y: Double(angle-90)).x
            }
            else{
                anchor.y = 0.5
            }
        }
        else if (angle >= 90 && angle <= 270)
        {
            anchor.x = (angle == 90 || angle == 270) ? 0.5 : 1
            anchor.y = linearTransfomer.pixelForValues(x: Double(angle), y: Double(angle)).x
        }
        
        return  anchor
    }
    
    public static func getPaddingValues(spaceMinPixel: CGFloat, spaceMaxPixel: CGFloat, overAllPadding: CGFloat) -> (CGFloat,CGFloat){
        
        let totalPixelSpace = spaceMinPixel + spaceMaxPixel
        
        let spaceMinPercentage = (spaceMinPixel / totalPixelSpace) * 100
        
        let spaceMin = (spaceMinPercentage / 100) * overAllPadding
        
        return (spaceMin,abs(overAllPadding - spaceMin))
    }
    
    //MARK:  Data Modifiers
    public static func resetData(newEntries:[[ChartDataEntry]], chart: ChartViewBase)
    {
        chart.xAxis.longestLabel = ""
        
        guard (chart.data?.dataSetCount) != nil
        else { return }
        for i in 0..<(chart.data?.dataSetCount)!
        {
            guard let set = chart.data?._dataSets[i] as? ChartDataSet
            else { continue }
            
            set.clear()
            
            set._values = newEntries[i]
            
            set.calcMinMax()
        }
        
        self.updateMatrix(chart: chart)
    }
    
    public static func includeDataset(selectedDataset:[IChartDataSet], chart: ChartViewBase)
    {
        chart.xAxis.longestLabel = ""
        
        /*
        var callResize = true
        
        if chart.data?.yMin == Double.greatestFiniteMagnitude
        {
            callResize = false
        }
        */
        
        for set in selectedDataset
        {
            set.visible = true
        }
        
        chart.lastSelected = nil
        
        chart.includeLayer = true
        
        chart.data?.updateXYValues()
        
        chart.data?.notifyDataChanged()
        
//        chart.notifyDataSetChanged(redrawRequired: true)
        
        let typeAllowed:[ChartType] = [.Bar,.Bullet]
        
        if chart.plotTypes.contains(.Bar) || chart.plotTypes.contains(.Bullet) {
            guard let processor = CommonHelperFunctions.getProcessor(chart: chart, types: typeAllowed) as? BarPreprocessor
               else { return }
           processor.calcPosNegSum()
         }
        
        if chart.plotTypes.contains(.WaterFall)
        {
            guard let processor = chart.getProcessor(type: .WaterFall) as? WaterFallPreprocessor,
                let waterFallPlotOption = chart.getPlotOptions(type: .WaterFall) as? WaterFallPlotOptions
                           else { return }
            if waterFallPlotOption.isStacked
            {
                processor.calcPosNegSum()
            }
        }
        
        if chart.plotTypes.contains(.Line)
        {
            guard let processor = chart.getProcessor(type: .Line) as? LineChartPreprocessor
                                  else { return }
            if isStacked(chart: chart)
            {
                processor.calcPosNegSum()
            }
        }
        
        if chart.plotTypes.contains(.Area)
        {
            guard let processor = chart.getProcessor(type: .Area) as? LineChartPreprocessor
                                  else { return }
            if isStacked(chart: chart)
            {
                processor.calcPosNegSum()
            }
        }
        
        /*
        if callResize
        {
            ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
        }
        else{
            chart.notifyDataSetChanged(redrawRequired: true)
        }
        */
        
        chart.interactionAnimationInProgress = false
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: nil, dataSets: selectedDataset as? [ChartDataSet], dataSetAdded: true)
        
    }
    
    public static func hideDataSet(selectedDataset:[IChartDataSet], chart: ChartViewBase)
    {
        chart.xAxis.longestLabel = ""
        
        for set in selectedDataset
        {
            set.visible = false
        }

        chart.lastSelected = nil
        
        chart.includeLayer = true

        chart.data?.updateXYValues()

        chart.data?.notifyDataChanged()

        //Need to check this snippet
        let typeAllowed:[ChartType] = [.Bar,.Bullet]
        
        if chart.plotTypes.contains(.Bar) || chart.plotTypes.contains(.Bullet) {
            guard let processor = CommonHelperFunctions.getProcessor(chart: chart, types: typeAllowed) as? BarPreprocessor
               else { return }
           processor.calcPosNegSum()
         }
        
    
        if chart.plotTypes.contains(.Line)
        {
            guard let processor = chart.getProcessor(type: .Line) as? LineChartPreprocessor
                                  else { return }
            if isStacked(chart: chart)
            {
                processor.calcPosNegSum()
            }
        }
        
        if chart.plotTypes.contains(.Area)
        {
            guard let processor = chart.getProcessor(type: .Area) as? LineChartPreprocessor
                                  else { return }
            if isStacked(chart: chart)
            {
                processor.calcPosNegSum()
            }
        }
        
        if chart.plotTypes.contains(.WaterFall)
        {
            guard let processor = chart.getProcessor(type: .WaterFall) as? WaterFallPreprocessor,
                let waterFallPlotOption = chart.getPlotOptions(type: .WaterFall) as? WaterFallPlotOptions
                           else { return }
            if waterFallPlotOption.isStacked
            {
                processor.calcPosNegSum()
            }
        }

//        ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)

        chart.interactionAnimationInProgress = false
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        chart.delegateToContainer?.chartValueRemoved?(chart, entries: nil, dataSets: selectedDataset as? [ChartDataSet], dataSetRemoved: true,showTrackerView: false )
        
    }
    
    public static func updateMatrix(chart:ChartViewBase)
      {
          chart.data?.updateXYValues()
         
          chart.data?.notifyDataChanged()
          
          chart.notifyDataSetChanged(redrawRequired: false)
          
          //        self.prepareValuePxMatrix()
          
          //        self.notifyDataSetChanged()
      }
    
    // MARK: - Plot Viewport Transforms
    
    public static func zoomAndCenterPlotViewAnimated(chart:ChartViewBase, xValue:Double, yValue:Double, rectSizeToShow:CGRect, completionBlock:(() -> Void)?, duration:TimeInterval)
    {
        let fromMatrix = chart.viewPortHandler.touchMatrix
        
        zoomPlotView(chart: chart, rectSizeToShow: rectSizeToShow, animated: false, completionBlock: nil, duration: duration)
        
        centerPlotView(chart: chart, xValue: xValue, yValue: yValue, animated: false, completionBlock: nil, duration: duration)
        
        let toMatrix = chart.viewPortHandler.touchMatrix
        
        performPlotMatrixAnimation(chart: chart, fromMatrix: fromMatrix, toMatrix: toMatrix, completionBlock: completionBlock, duration: duration)
        
    }
    
    public static func zoomPlotView(chart:ChartViewBase, rectSizeToShow:CGRect, animated:Bool, completionBlock:(() -> Void)?, duration:TimeInterval)
    {
        guard let viewport = chart.viewPortHandler
        else { return }
        
        let fromMatrix = chart.viewPortHandler.touchMatrix
        
        let requiredWidthRange = rectSizeToShow.width
        let requiredHeightRange = rectSizeToShow.height
    
        let scaleX = chart.viewPortHandler.contentWidth / requiredWidthRange
        let scaleY = chart.viewPortHandler.contentHeight / requiredHeightRange
        
        let scaleValue = min(scaleX,scaleY)
        
        let matrix = viewport.setZoom(scaleX: scaleValue, scaleY: scaleValue)
        let _ = refreshPlotWithoutRedraw(newMatrix: matrix, chart: chart, invalidate: false)
        
        if animated
        {
            performPlotMatrixAnimation(chart: chart, fromMatrix: fromMatrix, toMatrix: matrix, completionBlock: completionBlock, duration: duration)
        }
    }
    
    public static func centerPlotView(chart:ChartViewBase, xValue:Double, yValue:Double, animated:Bool, completionBlock:(() -> Void)?, duration:TimeInterval)
    {
        guard let viewport = chart.viewPortHandler
        else { return }
        
        let fromMatrix = chart.viewPortHandler.touchMatrix
        
        var pt = CGPoint(x: xValue, y: yValue)

        chart.plotTransformer.pointValueToPixel(&pt)
        
        pt = CGPoint(x: pt.x - chart.viewPortHandler.contentWidth/2, y: pt.y - chart.viewPortHandler.contentHeight/2)
        
        let matrix = viewport.translate(pt: pt)
        let _ = refreshPlotWithoutRedraw(newMatrix: matrix, chart: chart, invalidate: false)
        
        if animated
        {
            performPlotMatrixAnimation(chart: chart, fromMatrix: fromMatrix, toMatrix: matrix, completionBlock: completionBlock, duration: duration)
        }
    }
    
    public static func refreshPlotWithoutRedraw(newMatrix: CGAffineTransform, chart: ChartViewBase, invalidate: Bool) -> CGAffineTransform
    {
        chart.viewPortHandler._touchMatrix = newMatrix
        
        // make sure scale and translation are within their bounds
        chart.viewPortHandler.limitTransAndScaleforPlot(matrix: &chart.viewPortHandler._touchMatrix, content: chart.viewPortHandler._contentRect)
        
        return chart.viewPortHandler._touchMatrix
    }
    
    public static func performPlotMatrixAnimation(chart:ChartViewBase,fromMatrix: CGAffineTransform,toMatrix: CGAffineTransform,completionBlock:(() -> Void)?,duration: TimeInterval)
    {
        guard let viewport = chart.viewPortHandler
        else { return }
        
        let scaleAnimator = Animator()
        
        let scaleAInterpolator = Interpolator.interpolate(a: (fromMatrix.a), b: (toMatrix.a))
        let scaleDInterpolator = Interpolator.interpolate(a: (fromMatrix.d), b: (toMatrix.d))
        let translateXInterpolator = Interpolator.interpolate(a: (fromMatrix.tx), b: (toMatrix.tx))
        let translateYInterpolator = Interpolator.interpolate(a: (fromMatrix.ty), b: (toMatrix.ty))
        
        scaleAnimator.updateBlock = {
            var matrix = fromMatrix
            matrix.a = scaleAInterpolator(CGFloat(scaleAnimator.phaseX))
            matrix.d = scaleDInterpolator(CGFloat(scaleAnimator.phaseX))
            matrix.tx = translateXInterpolator(CGFloat(scaleAnimator.phaseX))
            matrix.ty = translateYInterpolator(CGFloat(scaleAnimator.phaseX))
            let _ = viewport.refreshPlot(newMatrix: matrix, chart: chart, invalidate: true)
        }
        
        scaleAnimator.stopBlock = {
            completionBlock?()
        }
        
        scaleAnimator.animate(xAxisDuration: duration)
    }
    
    // MARK: - Axis Resize Animation
        
    public static func resizeAxisIfNeeded(chart:ChartViewBase) -> Bool
    {
        var index = 0
        var resizeStatus = false
        for yAxis in chart.yAxisArray where yAxis.isEnabled && yAxis.resizeEnabled {
            if resizeYaxisWithAnimation(axis: yAxis,axisRenderer: chart.yAxisRenderers[index], chart: chart)
            {
                resizeStatus = true
            }
            index = index + 1
        }
        
        return resizeStatus
    }
    
    public static func resizeYaxisWithAnimation(axis:YAxis,axisRenderer:AxisRendererBase, chart:ChartViewBase) ->  Bool
    {
        /*let dataMinMax = (min:data.getYMin(axisIndex: axis.axisIndex),max: data.getYMax(axisIndex: axis.axisIndex))  //getYMinMaxValue(axis: axis)
        
        var yMinMax = dataMinMax
        
        if yMinMax.min == Double.greatestFiniteMagnitude && yMinMax.max == -(Double.greatestFiniteMagnitude)
        {
            return false
        }
        
        if !self.isKind(of: BarChartView.self) &&  (yMinMax.min == yMinMax.max) {
            return false
        }
        
        var spaceBottomRequired:Bool = true
        var spaceTopRequired:Bool = true
        
        if isBarDataAvailable()
        {
            if yMinMax.min >= 0 {
                yMinMax.min = 0
                spaceBottomRequired = false
            }
            
            if yMinMax.max <= 0 {
                if yMinMax.max == 0 && yMinMax.min == 0
                {
                    yMinMax.max = 1
                }
                else{
                    yMinMax.max = 0
                }
                spaceTopRequired = false
            }
            
            if yMinMax.min == yMinMax.max
            {
                yMinMax.min = yMinMax.min - 1
                yMinMax.max = yMinMax.max + 1
            }

        }
        
        let pixelPaddingEnabled = axis.spaceMinPixel != 0 && axis.spaceMaxPixel != 0 && dataMinMax.min != dataMinMax.max
        
        if spaceBottomRequired && !pixelPaddingEnabled
        {
            let differenceToChangeMin = Double(axis.spaceBottom) * (yMinMax.max - yMinMax.min)
            yMinMax.min = yMinMax.min - differenceToChangeMin
        }
        
        if spaceTopRequired && !pixelPaddingEnabled
        {
            let differenceToChangeMax = Double(axis.spaceTop) * (yMinMax.max - yMinMax.min)
            yMinMax.max = yMinMax.max + differenceToChangeMax
        }
        
        if pixelPaddingEnabled && !isBarDataAvailable()
        {
            let viewWidth = Double(self.viewPortHandler.contentHeight)
            
            var neededWidth:Double = axis.spaceMaxPixel
            
            let range = yMinMax.max - yMinMax.min
            
            if viewWidth <= 0 || range <= 0
            {
                return false
            }
            
            if (neededWidth*2) >= viewWidth
            {
                neededWidth = viewWidth/4
            }
            
            let widthToMapRange = viewWidth - (neededWidth*2)
            
            let oneRangeinPixelAfterMappingToWidth = widthToMapRange/range
            
            let padValue = (1/oneRangeinPixelAfterMappingToWidth)*neededWidth
            
            
            
            yMinMax.min = yMinMax.min - padValue
            yMinMax.max = yMinMax.max + padValue
        }*/
        
        let oldMin  = axis.axisMinimum
        let oldMax = axis.axisMaximum
        
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        let yMinMax = (min:axis.axisMinimum,max:axis.axisMaximum)
        
        //Forcefully setting axis customMin and CustomMax to true, to avoid flickering on resizeAxis() during filter animations
        axis.axisMinimum = oldMin
        axis.axisMaximum = oldMax
        
        // Resizing for odrinal values
        /* if axis.scaleType == .Ordinal
         {
         oldMin = 0 - (oldMax - yMinMax.max)
         yMinMax.min = 0 - (yMinMax.max * 0.08)
         }*/
        
        let minInterpolator = Interpolator.interpolate(a: oldMin, b: yMinMax.min)
        let maxInterPolator = Interpolator.interpolate(a: oldMax, b: yMinMax.max)
        let scaleAnim = Animator()
        
        scaleAnim.updateBlock = { [unowned chart] in
            axis.setAxis(minimum: minInterpolator(scaleAnim.phaseX))
            axis.setAxis(maximum: maxInterPolator(scaleAnim.phaseX))
            axisRenderer.computeAxisValues(min: axis.axisMinimum, max: axis.axisMaximum)
            chart.calculateOffsets()
            chart.setNeedsDisplay()
            
        }
        
        scaleAnim.stopBlock = { [unowned scaleAnim] in
            scaleAnim.updateBlock = nil
        }
        
        scaleAnim.animate(xAxisDuration: 0.3)
        
        return true
        
    }
    
    public static func getXMinAndMaxValue(chart: ChartViewBase) -> (min: Double, max: Double)
    {
        guard let viewPortHandler = chart.viewPortHandler,
              let transformer = (chart.xAxisRenderer.transformer)
            else { return (0,1)}
                
        var p1 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop))
        var p2 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentRight, y: viewPortHandler.contentTop))
        
        var min = Double(p1.x),
        max = Double(p2.x)
        
        if chart.xAxis.isInverted
        {
            min = Double(p2.x)
            max = Double(p1.x)
        }
        
        if chart.isRotated {
            
            p1 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentBottom))
            p2 = transformer.valueForTouchPoint(CGPoint(x: viewPortHandler.contentLeft, y: viewPortHandler.contentTop))
            
            if chart.xAxis.isInverted
            {
                min = Double(p1.y)
                max = Double(p2.y)
            }
            else
            {
                min = Double(p2.y)
                max = Double(p1.y)
            }
        }
        
        (min,max) = chart.xAxis.convert(min: min, max: max)
        
        Log.debug("Min X and Max X value \(min) \(max)")
        
        return (min, max)
        
    }
    
    public static func getYMinMaxValueWithinView(axis:YAxis, chart:ChartViewBase)-> (min: Double, max: Double)
    {
        let xMinMaxValue = getXMinAndMaxValue(chart: chart)
        
        var yMin:Double = Double.greatestFiniteMagnitude, yMax:Double = -(Double.greatestFiniteMagnitude)
        
        guard let dataSetCount = (chart.data?.dataSetCount)
        else { return (yMin,yMax) }
        
        for i in 0 ..< dataSetCount
        {
            guard let dataSet = (chart.data?.dataSets[i])
            else { continue }
            
            if !dataSet.isVisible || !(dataSet.axisIndex == chart.getAxisIndex(axis: axis))
            {
                continue
            }
            
            let startIndex = dataSet.entryIndex(x: xMinMaxValue.min, closestToY: Double.nan, rounding: ChartDataSetRounding.closest)                       //getStartIndexForXValue(dataSet: dataSet, closestXValue: xMinMaxValue.min)
            
            let endIndex =  dataSet.entryIndex(x: xMinMaxValue.max, closestToY: Double.nan, rounding: ChartDataSetRounding.closest)                    //getEndIndexForXValue(dataSet: dataSet, closestXValue: xMinMaxValue.max)
            
            
            for j in stride(from: startIndex, through: endIndex, by: 1)
            {
                let entry = dataSet.entryForIndex(j)
                
                if entry == nil{
                    continue
                }
                
                if (entry?.y)! < yMin
                {
                    yMin = (entry?.y)!
                }
                
                if (entry?.y)! > yMax
                {
                    yMax = (entry?.y)!
                }
              
            }
            
        }
        
        (yMin,yMax) = chart.xAxis.convert(min: yMin, max: yMax)
        
        Log.debug("YMin \(yMin) YMAX \(yMax)")
        
        return (yMin, yMax)
    }
    
    public static func getXMinMaxValueforVisibleDatasetAcrossData(chart:ChartViewBase)-> (min: Double, max: Double)
    {
        var xMin:Double = Double.greatestFiniteMagnitude, xMax:Double = -(Double.greatestFiniteMagnitude)
        
        guard let data = chart.data
            else { return (xMin, xMax) }
        
        for set in data.dataSets where set.isVisible && set.entryCount > 0
        {
            if set.xMin < xMin
            {
                xMin = set.xMin
            }
            
            if set.xMax > xMax
            {
                xMax = set.xMax
            }
            
        }
        
        (xMin,xMax) = chart.xAxis.convert(min: xMin, max: xMax)
        
        //        (yMin,yMax) = axis.getMinMaxWithLimitValues(min: yMin, max: yMax)
        
        return (xMin, xMax)
    }
    
    public static func getYMinMaxValue(axis:YAxis, chart:ChartViewBase)-> (min: Double, max: Double)
    {
        
        
        var yMin:Double = Double.greatestFiniteMagnitude, yMax:Double = -(Double.greatestFiniteMagnitude)
        guard let dataSetCount = (chart.data?.dataSetCount),
              (chart.data) != nil
        else { return (yMin,yMax)}
        
//        let barData = data as? ChartData
        
        if BarHelperFunctions.isBarChart(chart: chart) && BarHelperFunctions.isStacked(chart: chart) //barData != nil && barData!.isStacked
        {
            yMin = chart.data!.yMin
            yMax = chart.data!.yMax
        }
        else{
            for i in 0 ..< dataSetCount
            {
                guard let dataSet = (chart.data?.dataSets[i])
                else { continue }
                
                if !dataSet.isVisible || !(dataSet.axisIndex == chart.getAxisIndex(axis: axis))
                {
                    continue
                }
                
                if dataSet.yMin < yMin
                {
                    yMin = dataSet.yMin
                }
                
                if dataSet.yMax > yMax
                {
                    yMax = dataSet.yMax
                }
                
            }
        }
        
        (yMin,yMax) = axis.getMinMaxWithLimitValues(min: yMin, max: yMax)
        
        (yMin,yMax) = axis.convert(min: yMin, max: yMax)
        
        Log.debug("YMin \(yMin) YMAX \(yMax)")
        
        return (yMin, yMax)
    }

    
    //MARK: - Transformer methods
    
    public static func getOnePointWidth(chart:ChartViewBase) -> CGFloat
    {
        var rect = CGRect(x: 0, y: 0, width: 1, height: 1)
        
        chart.yAxisTransformers[0].rectValueToPixel(&rect)
        
        return rect.width
        
    }
    
    public static func getOnePointHeight(chart:ChartViewBase, axis:YAxis) -> CGFloat
    {
        var rect = CGRect(x: 0, y: 0, width: 1, height: 1)
        
        chart.yAxisTransformers[axis.axisIndex].rectValueToPixel(&rect)
        
        return rect.height
        
        //        if axis.axisDependency == .left
        //        {
        //            return rect.applying(chart._leftAxisTransformer.valueToPixelMatrix).height
        //        }
        //        else{
        //            return rect.applying(chart._rightAxisTransformer.valueToPixelMatrix).height
        //        }
        
    }
    
    public static func getOnePointSize(chart:ChartViewBase, axis:YAxis) -> CGSize
    {
        var rect = CGRect(x: 0, y: 0, width: 1, height: 1)
        
        chart.yAxisTransformers[axis.axisIndex].rectValueToPixel(&rect)
        
        return rect.size
        
    }
    
    public static func stepSize(chart: ChartViewBase, axisIndex: Int) -> CGFloat {
        
        var rect = CGRect(x: 0, y: 0, width: 1, height: 1)
        
        chart.yAxisTransformers[axisIndex].rectValueToPixel(&rect)
        
//        let onePointSize = rect.applying(chart.yAxisTransformers[axisIndex].valueToPixelMatrix).size
        
        return chart.isRotated ? rect.height : rect.width
    }
    
    public static func getCurrentWidthBetweenEntries(barLineChart:ChartViewBase,location:CGPoint) -> CGFloat
    {
        guard let renderer = barLineChart.getRenderer() as? BarLineScatterCandleBubbleRenderer
        else { return 0 }
        
        let entryHigh = barLineChart.getHighlightByTouchPoint(location)
        
        var currentWidth:CGFloat = 0
        
        if entryHigh != nil{
            
                guard let currentEntry = barLineChart.entryForHighlight(entryHigh!),
                   let entryIndex = barLineChart.data?.dataSets[(entryHigh?.dataSetIndex)!].entryIndex(entry: currentEntry)
            else { return 0}
            
            
            let prevEntry = barLineChart.data?.dataSets[(entryHigh?.dataSetIndex)!].entryForIndex(entryIndex-1)
            
            let nextEntry = barLineChart.data?.dataSets[(entryHigh?.dataSetIndex)!].entryForIndex(entryIndex+1)
            
            var prevDistance = Double.greatestFiniteMagnitude
            
            var nextDistance = Double.greatestFiniteMagnitude
            
            let currentLocation = barLineChart.pixelForValues(isRotated: barLineChart.isRotated, x: (currentEntry.x), y: (currentEntry.y), axisIndex: 0)
            
            if prevEntry != nil && !(prevEntry?.x.isNaN)!
            {
                let prevLocation = barLineChart.pixelForValues(isRotated: barLineChart.isRotated, x: (prevEntry?.x)!, y: (prevEntry?.y)!, axisIndex: 0)
                prevDistance = barLineChart.isRotated ? abs(Double(prevLocation.y) - Double(currentLocation.y)) : abs(Double(prevLocation.x) - Double(currentLocation.x))
            }
            if nextEntry != nil && !(nextEntry?.x.isNaN)!
            {
                let nextLocation = barLineChart.pixelForValues(isRotated: barLineChart.isRotated, x: (nextEntry?.x)!, y: (nextEntry?.y)!, axisIndex: 0)
                nextDistance = barLineChart.isRotated ?  abs(Double(nextLocation.y) - Double(currentLocation.y)) : abs(Double(nextLocation.x) - Double(currentLocation.x))
            }
            
            if prevDistance == Double.greatestFiniteMagnitude && nextDistance == Double.greatestFiniteMagnitude
            {
                // calc count
                
                let leftXValue = renderer._xBounds.min
                
                let rightXValue = renderer._xBounds.max
                
                guard let leftIndex = barLineChart.data?.dataSets[(entryHigh?.dataSetIndex)!].entryIndex(x:Double(leftXValue), closestToY: Double.nan, rounding: ChartDataSetRounding.closest),
                
                let rightIndex = barLineChart.data?.dataSets[(entryHigh?.dataSetIndex)!].entryIndex(x:Double(rightXValue), closestToY: Double.nan, rounding: ChartDataSetRounding.closest)
                else { return 0}
                
                
                let currentVisibleCount = rightIndex - leftIndex - 1
                
                if currentVisibleCount < 5
                {
                    currentWidth = (barLineChart.getPlotOptions() as? AxisChartPlotOptions)?.maxWidthZoomRestrictionPixel ?? currentWidth
                }
                
            }
            else if prevDistance == Double.greatestFiniteMagnitude && nextDistance != Double.greatestFiniteMagnitude{
                currentWidth = CGFloat(nextDistance)
            }
            else if nextDistance == Double.greatestFiniteMagnitude && prevDistance != Double.greatestFiniteMagnitude{
                currentWidth = CGFloat(prevDistance)
            }
            else{
                currentWidth = CGFloat(min(prevDistance,nextDistance))
            }
            
        }
        
        return currentWidth
    }
    
    public static func getMaxWidthBetweenEntries(barLine:ChartViewBase) -> CGFloat
    {
        let xMinMaxValue = CommonHelperFunctions.getXMinAndMaxValue(chart: barLine)
        
        guard let dataSetCount = (barLine.data?.dataSetCount)
        else { return 0 }
        
        var maxDiff = -(Double.greatestFiniteMagnitude)
        
        var countAboveMaxWidth = 0
        var countBelowMaxWidth = 0
        
        var belowMaxWidthPixel:CGFloat = CGFloat.greatestFiniteMagnitude
        
        for i in 0 ..< dataSetCount
        {
            guard let dataSet = (barLine.data?.dataSets[i])
            else { continue }
            
            if !dataSet.isVisible
            {
                continue
            }
            
            let startIndex = dataSet.entryIndex(x: xMinMaxValue.min, closestToY: Double.nan, rounding: ChartDataSetRounding.closest)                       //getStartIndexForXValue(dataSet: dataSet, closestXValue: xMinMaxValue.min)
            
            let endIndex =  dataSet.entryIndex(x: xMinMaxValue.max, closestToY: Double.nan, rounding: ChartDataSetRounding.closest)                    //getEndIndexForXValue(dataSet: dataSet, closestXValue: xMinMaxValue.max)
            
            if var curEntry = dataSet.entryForIndex(startIndex), let endEntry = dataSet.entryForIndex(endIndex) {
                
                repeat {
                    
                    if let nextEntry = getNextXEntryinData(entry: curEntry, includeXNan: false, includeYNan: false, loopingAllowed: false, chart: barLine)
                    {
                        
                        let nextEntryVal = convertValue(chart: barLine, axisIndex: dataSet.axisIndex, point: CGPoint(x: nextEntry.x, y: nextEntry.y))
                        let curEntryVal = convertValue(chart: barLine, axisIndex: dataSet.axisIndex, point: CGPoint(x: curEntry.x, y: curEntry.y))
                        
                        var diff = nextEntryVal.x - curEntryVal.x
                        
                        let widthInPixel = CommonHelperFunctions.getOnePointWidth(chart: barLine) * CGFloat(diff)
                        
                        guard (barLine.getPlotOptions() as? AxisChartPlotOptions) != nil
                        else { continue }
                        
                        if widthInPixel > (barLine.getPlotOptions() as! AxisChartPlotOptions).maxWidthZoomRestrictionPixel
                        {
                            countAboveMaxWidth += 1
                        }
                        else{
                            countBelowMaxWidth += 1
                            if widthInPixel < belowMaxWidthPixel
                            {
                                belowMaxWidthPixel = widthInPixel
                            }
                        }
                        
                        if diff > maxDiff
                        {
                            maxDiff = diff
                        }
                        
                        curEntry = nextEntry
                    }
                    else {
                        break
                    }
                }while curEntry.x != endEntry.x
            }
            
        }
        
        guard (barLine.getPlotOptions() as? AxisChartPlotOptions) != nil
        else { return 0 }
        
        var maxWidth:CGFloat = ((maxDiff == -(Double.greatestFiniteMagnitude)) || (maxDiff == 0)) ? (barLine.getPlotOptions() as! AxisChartPlotOptions).maxWidthZoomRestrictionPixel : CommonHelperFunctions.stepSize(chart: barLine, axisIndex: 0) * CGFloat(maxDiff)
        
        if countAboveMaxWidth < countBelowMaxWidth //&& maxWidth > (barLine.data as! BarLineScatterCandleBubbleChartData).maxWidthZoomRestrictionPixel
        {
            if belowMaxWidthPixel != CGFloat.greatestFiniteMagnitude
            {
                maxWidth = belowMaxWidthPixel //(barLine.data as! BarLineScatterCandleBubbleChartData).maxWidthZoomRestrictionPixel - 1
            }
            else{
                maxWidth = 0
            }
        }
        
        return maxWidth
    }
    
    public static func getMaxWidthBetweenEntriesAcrossAllVisibleData(barLine:ChartViewBase) -> CGFloat
    {
     guard let data = barLine.data
        else { return 0 }

        var maxDiff = -(Double.greatestFiniteMagnitude)
        
        var countAboveMaxWidth = 0
        var countBelowMaxWidth = 0
        
        var belowMaxWidthPixel:CGFloat = CGFloat.greatestFiniteMagnitude
        
        for i in 0 ..< data.dataSetCount
        {
            let dataSet = data.dataSets[i]
            
            if !dataSet.isVisible
            {
                continue
            }
            
            let startIndex = 0
            
            let endIndex =  dataSet.entryCount-1
            
            var curEntry = dataSet.entryForIndex(startIndex)
            
            for j in stride(from: startIndex, through: endIndex-1, by: 1)
            {
                guard  curEntry != nil,
                    !(curEntry!.x.isNaN)
                    else  {
                        curEntry = dataSet.entryForIndex(j+1)
                        continue }
                
                guard let nextEntry = dataSet.entryForIndex(j+1),
                    !(nextEntry.x.isNaN)
                    else  { continue }
                
                let diff = nextEntry.x - curEntry!.x
                
                let widthInPixel = CommonHelperFunctions.stepSize(chart: barLine, axisIndex: dataSet.axisIndex) * CGFloat(diff)
                
                guard (barLine.getPlotOptions() as? AxisChartPlotOptions) != nil
                else { continue }
                
//                if widthInPixel > (data as! BarLineScatterCandleBubbleChartData).maxWidthZoomRestrictionPixel
                if widthInPixel > (barLine.getPlotOptions() as! AxisChartPlotOptions).maxWidthZoomRestrictionPixel
                {
                    countAboveMaxWidth += 1
                }
                else{
                    countBelowMaxWidth += 1
                    if widthInPixel < belowMaxWidthPixel
                    {
                        belowMaxWidthPixel = widthInPixel
                    }
                }
                
                if diff > maxDiff
                {
                    maxDiff = diff
                }
                
                curEntry = nextEntry
            }
        }
        
        guard (barLine.getPlotOptions() as? AxisChartPlotOptions) != nil
        else { return 0 }
        
        var maxWidth:CGFloat = ((maxDiff == -(Double.greatestFiniteMagnitude)) || (maxDiff == 0)) ? (barLine.getPlotOptions() as! AxisChartPlotOptions).maxWidthZoomRestrictionPixel : CommonHelperFunctions.stepSize(chart: barLine, axisIndex: 0) * CGFloat(maxDiff)
        
        if countAboveMaxWidth < countBelowMaxWidth //&& maxWidth > (barLine.data as! BarLineScatterCandleBubbleChartData).maxWidthZoomRestrictionPixel
        {
            if belowMaxWidthPixel != CGFloat.greatestFiniteMagnitude
            {
                maxWidth = belowMaxWidthPixel //(barLine.data as! BarLineScatterCandleBubbleChartData).maxWidthZoomRestrictionPixel - 1
            }
            else{
                maxWidth = 0
            }
        }
        
        return maxWidth
    }
    
    public static func getPlotViewLayer(chart:ChartViewBase) -> CALayer?
    {
        return chart.plotView?.layer
    }
    
    public static func isTouchInverted(chart:ChartViewBase) -> Bool
    {
           return chart.isAnyAxisInverted &&
               chart._closestDataSetToTouch !== nil &&
               (chart.getYAxis(atIndex:  chart._closestDataSetToTouch.axisIndex)?.isInverted ?? false)
    }
    
    public static func getPixelForValues(x:Double,y:Double, isOriginal: Bool = true, dataSet:ChartDataSet,chart:ChartViewBase) -> (CGPoint)
    {
        let plotType = dataSet.plotType
        
        switch  plotType {
        case .Radar:
            guard let trans = chart.getTransformer(axisIndex: dataSet.axisIndex) as? PolarTransformer,
                  let axis = chart.getYAxis(atIndex: dataSet.axisIndex)
                else { return CGPoint() }
            
            var yValue = isOriginal ? y < axis.axisMinimum ? axis.axisMinimum : y : y < axis._axisMinimum ? axis._axisMinimum : y
            
            yValue = isOriginal ? yValue > axis.axisMaximum ? axis.axisMaximum : yValue : yValue > axis._axisMaximum ? axis._axisMaximum : yValue
            
            return trans.pixelForPolarValues(x: x, y: yValue, isOriginal: isOriginal)
        default:
            let trans = chart.getTransformer(axisIndex: dataSet.axisIndex)
                
            return trans.pixelForValues(x: x, y: y, isOriginal: isOriginal)
        }
    }
    
    public static func getPixelForValues(isRotated: Bool, x: Double, y: Double, isOriginal: Bool = true, dataset: ChartDataSet, chart: ChartViewBase) -> CGPoint {
        
        return isRotated ? getPixelForValues(x: y, y: x, isOriginal: isOriginal, dataSet: dataset, chart: chart) : getPixelForValues(x: x, y: y, isOriginal: isOriginal, dataSet: dataset, chart: chart)
        
    }
    
    public static func convertValueToOriginalChart(chart: ChartViewBase, axisIndex: Int, point: CGPoint) -> CGPoint {
        
        let transformer = chart.getTransformer(axisIndex: axisIndex)
        
        if chart.isRotated {
            if let logTrans = transformer as? LogTransformerHorizontalChart {
                return logTrans.antiLogValueFor(point: point)
            }
            else if let logTrans = transformer as? SQRTTransformerHorizontalChart {
                return logTrans.square(point: point)
            }
        }
        else {
            if let logTrans = transformer as? LogTransformer {
                return logTrans.antiLogValueFor(point: point)
            }
            else if let polarLogTrans = transformer as? LogPolarTransformer {
                return polarLogTrans.antiLogValueFor(point: point)
            }
            else if let logTrans = transformer as? SQRTTransformer {
                return logTrans.square(point: point)
            }
            else if let polarLogTrans = transformer as? SQRTPolarTransformer {
                return polarLogTrans.square(point: point)
            }
        }
        return point
    }
    
    public static func convertValue(chart: ChartViewBase, axisIndex: Int, point: CGPoint) -> CGPoint {
        
        let transformer = chart.getTransformer(axisIndex: axisIndex)
        
        if chart.isRotated {
            if let logTrans = transformer as? LogTransformerHorizontalChart {
                return logTrans.logValueFor(point: point)
            }
            else if let logTrans = transformer as? SQRTTransformerHorizontalChart {
                return logTrans.squareRoot(point: point)
            }
        }
        else {
            if let logTrans = transformer as? LogTransformer {
                return logTrans.logValueFor(point: point)
            }
            else if let polarLogTrans = transformer as? LogPolarTransformer {
                return polarLogTrans.logValueFor(point: point)
            }
            else if let logTrans = transformer as? SQRTTransformer {
                return logTrans.squareRoot(point: point)
            }
            else if let polarLogTrans = transformer as? SQRTPolarTransformer {
                return polarLogTrans.squareRoot(point: point)
            }
        }
        return point
    }
    
    // MARK: - ViewPort Adjustments
    
//    public static func setAxisScrollDecelerationLoop( displayLink:inout NSUIDisplayLink, chart:ChartViewBase)
//    {
//        guard  (chart.preProcessors.count > 0),
//        let processor = chart.preProcessors[0] as? AxisChartPreprocessor
//        else { return }
//
//        displayLink = NSUIDisplayLink(target: processor.self, selector: #selector(AxisChartPreprocessor.decelerationLoop))
//    }
    
    public static func getAxisScrollDecelerationLoop(  chart:ChartViewBase) -> NSUIDisplayLink?
    {
           guard  (chart.preProcessors.count > 0)
            else { return nil}
//           else { return NSUIDisplayLink()}
           
        let processor = chart.preProcessors[0]
        
        return NSUIDisplayLink(target: processor.self, selector: #selector(ChartPreprocessor.decelerationLoop))
    }
    
    public static func scrollViewToXAndExecuteBlock(x:Double,y:Double,duration:TimeInterval, executionBlock: (() -> Void)?, alignCenter:Bool, chart:ChartViewBase){
        
        if x.isNaN {
            executionBlock?()
            return
        }
        
        var moved = false
        
        var finalYValue = y
        if finalYValue.isNaN {
            finalYValue = 0
        }
        
        /* if !(self.lowestVisibleX <= x && x <= self.highestVisibleX) {
         moved = true
         centerViewToAnimated(xValue: x, yValue: finalYValue, axis: (data?.dataSets[0].axisDependency)!, axisIndex: (data?.dataSets[0].axisIndex)!, duration: duration)
         }*/
        
        
        /* if self.isKind(of: HorizontalBarChartView.self) {
         if !(self.lowestVisibleX <= x && x <= self.highestVisibleX) {
         moved = true
         centerViewToAnimated(xValue: x, yValue: finalYValue, axis: (data?.dataSets[0].axisDependency)!, axisIndex: (data?.dataSets[0].axisIndex)!, duration: duration)
         }
         }else{
         if !(self.lowestVisibleX <= x && x <= self.highestVisibleX) {
         moved = true
         centerViewToAnimated(xValue: x, yValue: finalYValue, axis: (data?.dataSets[0].axisDependency)!, axisIndex: (data?.dataSets[0].axisIndex)!, duration: duration)
         }
         }*/
        
        if !(chart.lowestVisibleX <= x && x <= chart.highestVisibleX) {
            moved = true
            guard (chart.data) != nil
            else { return }
            if alignCenter {
                chart.centerViewToAnimated(xValue: x, yValue: finalYValue, axisIndex: (chart.data?.dataSets[0].axisIndex)!, duration: duration)
            }else {
                chart.moveViewToAnimated(xValue: x, yValue: finalYValue, axisIndex: (chart.data?.dataSets[0].axisIndex)!, duration: duration)
            }
        }
        
        if moved{
            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(1000 * duration)), execute: {
                executionBlock?()
            })
        }
        else{
            executionBlock?()
        }
        
    }
    
    public static func contentTop(interactionAnimationInProgress: Bool, viewPortHandler: ViewPortHandler) -> CGFloat
    {
        return  interactionAnimationInProgress ? viewPortHandler.animateRectObject.origin.y : viewPortHandler.contentTop
    }
    
    public static func contentLeft(interactionAnimationInProgress: Bool, viewPortHandler: ViewPortHandler) -> CGFloat
    {
        return interactionAnimationInProgress ? viewPortHandler.animateRectObject.origin.x : viewPortHandler.contentLeft
    }
    
    public static func contentRight(interactionAnimationInProgress: Bool, viewPortHandler: ViewPortHandler) -> CGFloat
    {
        return interactionAnimationInProgress ? viewPortHandler.animateRectObject.origin.x + viewPortHandler.animateRectObject.size.width : viewPortHandler.contentRight
    }
    
    public static func contentBottom(interactionAnimationInProgress: Bool, viewPortHandler: ViewPortHandler) -> CGFloat
    {
        return interactionAnimationInProgress ? viewPortHandler.animateRectObject.origin.y + viewPortHandler.animateRectObject.size.height : viewPortHandler.contentBottom
    }
    
    // MARK: - Touch Events
    
    public static func performPinch(recognizer:NSUIPinchGestureRecognizer,scaleValue:CGFloat,zoomLocation:CGPoint, chart: ChartViewBase) -> CGAffineTransform?
    {
        var pinchMatrix:CGAffineTransform? = nil
        
        guard let _viewPortHandler = chart._viewPortHandler
            else { return pinchMatrix }
        
        
        let isZoomingOut = (scaleValue < 1)
        var canZoomMoreX = isZoomingOut ? _viewPortHandler.canZoomOutMoreX : _viewPortHandler.canZoomInMoreX
        var canZoomMoreY = isZoomingOut ? _viewPortHandler.canZoomOutMoreY : _viewPortHandler.canZoomInMoreY
        
        if chart._isScaling
        {
            canZoomMoreX = canZoomMoreX && chart.scaleXEnabled && (chart._gestureScaleAxis == .both || chart._gestureScaleAxis == .x)
            canZoomMoreY = canZoomMoreY && chart.scaleYEnabled && (chart._gestureScaleAxis == .both || chart._gestureScaleAxis == .y)
            if canZoomMoreX || canZoomMoreY
            {
                var location = zoomLocation
                
                if chart.xAxis.isInverted
                {
//                    location.x = -(location.x - _viewPortHandler.offsetLeft)
                    location.x = (location.x - _viewPortHandler.offsetLeft)
                }
                else
                {
                    location.x = location.x - _viewPortHandler.offsetLeft
                }
                
                if CommonHelperFunctions.isTouchInverted(chart: chart)
                {
                    location.y = -(location.y - _viewPortHandler.offsetTop)
                }
                else
                {
                    if chart.isRotated && chart.xAxis.isInverted
                    {
                        location.y = location.y - _viewPortHandler.offsetTop
                    }
                    else
                    {
                        location.y = -(_viewPortHandler.chartHeight - location.y - _viewPortHandler.offsetBottom)
                    }
                }
                
                let scaleX = canZoomMoreX ? scaleValue : 1.0
                let scaleY = canZoomMoreY ? scaleValue : 1.0
                
                var matrix = CGAffineTransform(translationX: location.x, y: location.y)
                matrix = matrix.scaledBy(x: scaleX, y: scaleY)
                matrix = matrix.translatedBy(x: -location.x, y: -location.y)
                
                matrix = _viewPortHandler.touchMatrix.concatenating(matrix)
                
                pinchMatrix = matrix
                
                let _ = _viewPortHandler.refresh(newMatrix: matrix, chart: chart, invalidate: true)
                
                ChartPreprocessor.prepareDataLabelRects(chart: chart)
                
                /*  if chartActionListener != nil
                 {
                 chartActionListener?.chartScaled?(chartView: self, scaleX: scaleX, scaleY: scaleY, velocity: recognizer.velocity, start: String(f), end: String(l))
                 }*/
                
                if chart.delegateToContainer !== nil
                {
                    chart.delegateToContainer?.chartScaled?(chart, scaleX: scaleX, scaleY: scaleY)
                }
                
                
            }
            
            recognizer.nsuiScale = 1.0
            
        }
        
        return pinchMatrix
    }
    
    public static func performPlotPinch(recognizer:NSUIPinchGestureRecognizer,scaleValue:CGFloat,zoomLocation:CGPoint, chart: ChartViewBase) -> CGAffineTransform?
    {
            var pinchMatrix:CGAffineTransform? = nil
            
            guard let _viewPortHandler = chart._viewPortHandler
                else { return pinchMatrix }
            
            
            let isZoomingOut = (scaleValue < 1)
            var canZoomMoreX = isZoomingOut ? _viewPortHandler.canZoomOutMoreX : _viewPortHandler.canZoomInMoreX
            var canZoomMoreY = isZoomingOut ? _viewPortHandler.canZoomOutMoreY : _viewPortHandler.canZoomInMoreY
            
            if chart._isScaling
            {
                canZoomMoreX = canZoomMoreX && chart.scaleXEnabled && (chart._gestureScaleAxis == .both || chart._gestureScaleAxis == .x)
                canZoomMoreY = canZoomMoreY && chart.scaleYEnabled && (chart._gestureScaleAxis == .both || chart._gestureScaleAxis == .y)
                if canZoomMoreX || canZoomMoreY
                {
                    var location = zoomLocation

                    location.x = (location.x - _viewPortHandler.offsetLeft)
   
                    location.y = location.y - _viewPortHandler.offsetTop
                    
                    let scaleX = canZoomMoreX ? scaleValue : 1.0
                    let scaleY = canZoomMoreY ? scaleValue : 1.0
                    
                    var matrix = CGAffineTransform(translationX: location.x, y: location.y)
                    matrix = matrix.scaledBy(x: scaleX, y: scaleY)
                    matrix = matrix.translatedBy(x: -location.x, y: -location.y)
                    
                    matrix = _viewPortHandler.touchMatrix.concatenating(matrix)
                    
                    pinchMatrix = matrix
                    
                    let _ = _viewPortHandler.refreshPlot(newMatrix: matrix, chart: chart, invalidate: true)
                    
                    if chart.delegateToContainer !== nil
                    {
                        chart.delegateToContainer?.chartScaled?(chart, scaleX: scaleX, scaleY: scaleY)
                    }
                    
                    
                }
                
                recognizer.nsuiScale = 1.0
                
            }
            
            return pinchMatrix
    }
    
    public static func performPinch(recognizer:NSUIPinchGestureRecognizer, chart:ChartViewBase) -> CGAffineTransform?
    {
        return  performPinch(recognizer: recognizer, scaleValue: recognizer.nsuiScale, zoomLocation: recognizer.location(in: chart), chart: chart)
    }
    
    public static func performPlotPinch(recognizer:NSUIPinchGestureRecognizer, chart:ChartViewBase) -> CGAffineTransform?
    {
        return  performPlotPinch(recognizer: recognizer, scaleValue: recognizer.nsuiScale, zoomLocation: recognizer.location(in: chart), chart: chart)
    }
    
    public static func performPanChange(translation: CGPoint, chart:ChartViewBase) -> Bool
      {
          chart.customAnimationInProgress = false
          
          var translation = translation
          
          if isTouchInverted(chart: chart)
          {
            if chart.isRotated
              {
                  translation.x = -translation.x
              }
              else
              {
                  translation.y = -translation.y
              }
          }
          
          let originalMatrix = chart._viewPortHandler.touchMatrix
          
          var matrix = CGAffineTransform(translationX: translation.x, y: translation.y)
          matrix = originalMatrix.concatenating(matrix)
          
          matrix = chart._viewPortHandler.refresh(newMatrix: matrix, chart: chart, invalidate: true)
          
          if chart.delegateToContainer !== nil
          {
              chart.delegateToContainer?.chartTranslated?(chart, dX: translation.x, dY: translation.y)
          }
          
          // Did we managed to actually drag or did we reach the edge?
          return matrix.tx != originalMatrix.tx || matrix.ty != originalMatrix.ty
      }
    
    public static func performPanChangeforPlot(translation: CGPoint, chart:ChartViewBase) -> Bool
    {
        chart.customAnimationInProgress = false
        
        var translation = translation
        
        if isTouchInverted(chart: chart)
        {
          if chart.isRotated
            {
                translation.x = -translation.x
            }
            else
            {
                translation.y = -translation.y
            }
        }
        
        let originalMatrix = chart._viewPortHandler.touchMatrix
        
        var matrix = CGAffineTransform(translationX: translation.x, y: translation.y)
        matrix = originalMatrix.concatenating(matrix)
        
        matrix = chart._viewPortHandler.refreshPlot(newMatrix: matrix, chart: chart, invalidate: true)
        
        if chart.delegateToContainer !== nil
        {
            chart.delegateToContainer?.chartTranslated?(chart, dX: translation.x, dY: translation.y)
        }
        
        // Did we managed to actually drag or did we reach the edge?
        return matrix.tx != originalMatrix.tx || matrix.ty != originalMatrix.ty
    }
    
    //******************************** Animations ****************************************
    
    // MARK: - Animations
    
    
    /// Animate Layer Position
    public static func performPositionAnim(targetLayer:CAShapeLayer,point:CGPoint,duration:TimeInterval)
    {
        let positionAnimator = Animator()
        
        let xInterpolator = Interpolator.interpolate(a: Double(targetLayer.position.x), b: Double(point.x))
        let yInterpolator = Interpolator.interpolate(a: Double(targetLayer.position.y), b: Double(point.y))
        
        positionAnimator.updateBlock = {
            
            targetLayer.position = CGPoint(x:xInterpolator(positionAnimator.phaseX) , y: yInterpolator(positionAnimator.phaseX))
        }
        
        positionAnimator.stopBlock = { [unowned positionAnimator] in
            positionAnimator.updateBlock = nil
        }
        
        positionAnimator.animate(xAxisDuration: duration)
    }
    
    /// Animate Text Layer Position
    public static func performPositionAnim(textLayer:CATextLayer,position:CGPoint,duration:TimeInterval, completionBlock: (() -> Void)?)
    {
        CATransaction.begin()
        
        let anim = CABasicAnimation(keyPath: "position")
        
        anim.fromValue = textLayer.position
        
        anim.toValue = position
        
        anim.duration = duration
        
        CATransaction.setCompletionBlock(completionBlock)
        
        textLayer.add(anim, forKey: "path")
        
        CATransaction.commit()
        
        textLayer.position = position
    }
    
    /// Animate Layer Path
    public static func performPathAnim(targetLayer:CAShapeLayer,newPath:CGMutablePath,duration:TimeInterval)
    {
        if duration > 0
        {
            CATransaction.begin()
            
            let anim = CABasicAnimation(keyPath: "path")
            
            anim.fromValue = targetLayer.path
            
            anim.toValue = newPath//newPath.cgPath
            
            anim.duration = duration
            
            anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            
            targetLayer.add(anim, forKey: "path")
            
            CATransaction.commit()
        }
        
        targetLayer.path = newPath //newPath.cgPath
        
        GradientLayerRenderer.performGradientLayerPathAnimation(targetLayer: targetLayer, newPath: newPath, duration: duration)
    }
    
    /// Animate Layer Path and Runs Completion Block at End
    public static func performPathAnim(targetLayer:ChartEntryLayer,newPath:CGMutablePath,duration:TimeInterval, completionBlock: (() -> Void)?)
    {
        CATransaction.begin()
        
        let anim = CABasicAnimation(keyPath: "path")
        
        anim.fromValue = targetLayer.path
        
        anim.toValue = newPath // newPath.cgPath
        
        anim.duration = duration
        
        anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        CATransaction.setCompletionBlock(completionBlock)
        
        targetLayer.add(anim, forKey: "path")
        
        CATransaction.commit()
        
        targetLayer.path = newPath//newPath.cgPath
        
        GradientLayerRenderer.performGradientLayerPathAnimation(targetLayer: targetLayer, newPath: newPath, duration: duration)
    }
    
    /// Animate Layer Opacity
    public static func performOpacityAnim(targetLayer:ChartEntryLayer,opacity:CGFloat,duration:TimeInterval)
    {
        let opacAnimator = Animator()
        
        let opacInterpolator = Interpolator.interpolate(a: Double(targetLayer.opacity), b: Double(opacity))
        
        opacAnimator.updateBlock = {
            
            targetLayer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
        }
        
        opacAnimator.stopBlock = { [unowned opacAnimator] in
            opacAnimator.updateBlock = nil
        }
        
        opacAnimator.animate(xAxisDuration: duration)
    }
    
    /// Animate Layer Opacity
       public static func performOpacityAnim(targetLayers:[CALayer],fromOpacity:CGFloat,toOpacity:CGFloat,duration:TimeInterval)
      {
          let opacAnimator = Animator()
          
          let opacInterpolator = Interpolator.interpolate(a: Double(fromOpacity), b: Double(toOpacity))
          
          opacAnimator.updateBlock = {
                          
           targetLayers.forEach({ layer in
               layer.opacity = Float(opacInterpolator(opacAnimator.phaseX))
           })
           
          }
          
          opacAnimator.stopBlock = { [unowned opacAnimator] in
              opacAnimator.updateBlock = nil
          }
          
          opacAnimator.animate(xAxisDuration: duration)
      }
    
    /// Animate Layer line Width
    public static func performLineWidthAnim(targetLayer:ChartEntryLayer,newlineWidth:CGFloat,duration:TimeInterval)
    {
        let lineWidthAnimator = Animator()
        
        let lineWidthInterpolator = Interpolator.interpolate(a: targetLayer.lineWidth, b: newlineWidth)
        
        lineWidthAnimator.updateBlock = {
            
            targetLayer.lineWidth = lineWidthInterpolator(CGFloat(lineWidthAnimator.phaseX))
        }
        
        lineWidthAnimator.stopBlock = { [unowned lineWidthAnimator] in
            lineWidthAnimator.updateBlock = nil
        }
        
        lineWidthAnimator.animate(xAxisDuration: duration)
    }
    
    /// Axis Chart :- Animate Viewport to Given Distance
    public static func translateView(distance:CGFloat,duration:TimeInterval,chart:ChartViewBase)
    {
        let barChart = chart
        
        let dist = Interpolator.interpolate(a: 0, b: Double(distance))
        
        var prev:Double = 0
        
        var moveAnimator:Animator!
        
        if moveAnimator != nil
        {
            moveAnimator.stop()
        }
        
        moveAnimator  = Animator()
        
        moveAnimator.updateBlock =
            {
                
                var toMove = Double(0)
                var translation = CGPoint()
                
                toMove = dist(moveAnimator.phaseX) - prev
                
                if chart.isRotated
                {
                    translation = CGPoint(x: 0, y: toMove)
                }
                else
                {
                    translation = CGPoint(x: toMove, y: 0)
                }
                
                prev = dist(moveAnimator.phaseX)
                
                let _ = performPanChange(translation: translation, chart: chart)
                
        }
        
        moveAnimator.animate(xAxisDuration: duration, easingOption: ChartEasingOption.linear)
        
    }
    
    /// Animate Layer Path
    public static func performPositionAnim(targetLayer:CALayer,fromValue: CGPoint, toValue: CGPoint, duration:TimeInterval)
    {
        if duration > 0
        {
            CATransaction.begin()
            
            let anim = CABasicAnimation(keyPath: "position")
            
            anim.fromValue = fromValue
            
            anim.toValue = toValue
            
            anim.duration = duration
            
            anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            
            targetLayer.add(anim, forKey: "position")
            
            CATransaction.commit()
        }
    }
    
    // MARK: - Draw Layer
    
    public static func enableIncludeLayer(chart:ChartViewBase)
    {
        chart.computeLegend = true
        chart.includeLayer = true
        chart.lastSelected = nil
        chart.setNeedsDisplay()
        
    }
    
    /// returns Given Layer with Shape Path Constructed
    internal static func drawShapeLayer(shapeProperties:ShapeProperties,point:CGPoint,strokeColor:CGColor,currentLayer:CAShapeLayer) -> CAShapeLayer
    {
        let shapePath:CGPath
        
        if shapeProperties.shapeType == .custom
        {
            guard let path = ((shapeProperties.customPathDataSource?.shapePath?(point: point, shapeInstance: shapeProperties, shapeLayer: currentLayer)))
            else { return CAShapeLayer() }
            shapePath = path
        }
        else{
            shapePath = ShapeFactory.getPath(point: point, shapeInstance: shapeProperties)
        }
        
        currentLayer.path = shapePath
        
        if shapeProperties.holeColor != nil{
            currentLayer.fillColor = shapeProperties.holeColor?.cgColor
        }
        else{
            currentLayer.fillColor = NSUIColor.clear.cgColor
        }
        currentLayer.strokeColor = strokeColor
        currentLayer.lineWidth = CGFloat((shapeProperties.lineWidth))
        currentLayer.lineCap =  convertToCAShapeLayerLineCap("round")
        currentLayer.lineDashPhase = shapeProperties.lineDashPhase
        currentLayer.lineDashPattern =  LimitLineLayer.getNSNumberArray(lineDashLengths:shapeProperties.lineDashLengths)
        
        return currentLayer
    }
    
    /// returns Given Layer with Shape Path Constructed
    internal static func drawFormShapeLayer(shapeProperties:ShapeProperties,entry:LegendEntry,currentLayer:CAShapeLayer) -> CAShapeLayer
    {
        var propertiesUpdated = true
        
        if (shapeProperties.customPathDataSource?.updateShapeProperties?(frame: currentLayer.bounds, shapeInstance: shapeProperties, entry: entry)) == nil
        {
            propertiesUpdated = false
        }
        
        
        var shapePath:CGPath = CGMutablePath()
        
        if shapeProperties.shapeType == .custom
        {
            guard (shapeProperties.customPathDataSource != nil)
            else { return CAShapeLayer() }
            
            if let path = shapeProperties.customPathDataSource?.shapePath?(frame: currentLayer.bounds, shapeInstance: shapeProperties, entry: entry, shapeLayer: currentLayer) {
                shapePath = path
            }
        }
        else{
            if !(propertiesUpdated)
            {
                let shapeSize = min(currentLayer.bounds.width,min(shapeProperties.size.width, shapeProperties.size.height))
                shapeProperties.size = CGSize(width: shapeSize, height: shapeSize)
                shapeProperties.holeColor = entry.formColor
                shapeProperties.strokeColor = entry.formColor
            }
            shapePath = ShapeFactory.getPath(point: CGPoint(x: currentLayer.bounds.midX, y: currentLayer.bounds.midY), shapeInstance: shapeProperties)
        }
        
        currentLayer.path = shapePath
        
        if shapeProperties.holeColor != nil{
            currentLayer.fillColor = shapeProperties.holeColor?.cgColor
        }
        else{
            currentLayer.fillColor = NSUIColor.clear.cgColor
        }
        currentLayer.strokeColor = shapeProperties.strokeColor?.cgColor
        currentLayer.lineWidth = CGFloat((shapeProperties.lineWidth))
        currentLayer.lineCap =  convertToCAShapeLayerLineCap("round")
        currentLayer.lineDashPhase = shapeProperties.lineDashPhase
        currentLayer.lineDashPattern =  LimitLineLayer.getNSNumberArray(lineDashLengths:shapeProperties.lineDashLengths)
        
        return currentLayer
    }
    
    /// returns Given Layer with Shape Path Constructed
    internal static func drawShapeLayerGeneric(shapeProperties:ShapeProperties,entry:Any?,currentLayer:CAShapeLayer) -> CAShapeLayer
    {
        
        shapeProperties.customPathDataSource?.updateShapeProperties?(frame: currentLayer.bounds, shapeInstance: shapeProperties, entry: entry)
        
        var shapePath:CGPath = CGMutablePath()
        
        if shapeProperties.shapeType == .custom
        {
            guard (shapeProperties.customPathDataSource != nil)
            else { return CAShapeLayer() }
            
            if let path = shapeProperties.customPathDataSource?.shapePath?(frame: currentLayer.bounds, shapeInstance: shapeProperties, entry: entry, shapeLayer: currentLayer) {
                shapePath = path
            }
        }
        else{
            shapePath = ShapeFactory.getPath(point: CGPoint(x: currentLayer.bounds.midX, y: currentLayer.bounds.midY), shapeInstance: shapeProperties)
        }
        
        currentLayer.path = shapePath
        
        if shapeProperties.holeColor != nil{
            currentLayer.fillColor = shapeProperties.holeColor?.cgColor
        }
        else{
            currentLayer.fillColor = NSUIColor.clear.cgColor
        }
        currentLayer.strokeColor = shapeProperties.strokeColor?.cgColor
        currentLayer.lineWidth = CGFloat((shapeProperties.lineWidth))
        currentLayer.lineCap =  convertToCAShapeLayerLineCap("round")
        currentLayer.lineDashPhase = shapeProperties.lineDashPhase
        currentLayer.lineDashPattern =  LimitLineLayer.getNSNumberArray(lineDashLengths:shapeProperties.lineDashLengths)
        
        return currentLayer
    }
    
    /// returns Given Layer with Shape Path Constructed
    internal static func drawShapeLayerPolar(shapeProperties:ShapeProperties,point:CGPoint,strokeColor:CGColor,currentLayer:CAShapeLayer,angle:CGFloat) -> CAShapeLayer
    {
        var shapePath:CGPath = CGMutablePath()
        
        if shapeProperties.shapeType == .custom
        {
            guard shapeProperties.customPathDataSource != nil
            else { return CAShapeLayer() }
            
            if let path = shapeProperties.customPathDataSource?.shapePath?(point: point, shapeInstance: shapeProperties, shapeLayer: currentLayer) {
                shapePath = path
            }
        }
        else{
            let oppositeAngle = (angle + 180) > 360 ? (angle + 180) - 360 : (angle + 180)
            let bezierPath = CGMutablePath()
            bezierPath.move(to: ChartUtils.getPosition(center: point, dist: shapeProperties.size.width/2, angle: angle))
            bezierPath.addLine(to: ChartUtils.getPosition(center: point, dist: shapeProperties.size.width/2, angle: oppositeAngle))
            shapePath = bezierPath//.cgPath   // ShapeFactory.getPath(point: point, shapeInstance: shapeProperties)
        }
        
        currentLayer.path = shapePath
        
        if shapeProperties.holeColor != nil{
            currentLayer.fillColor = shapeProperties.holeColor?.cgColor
        }
        else{
            currentLayer.fillColor = NSUIColor.clear.cgColor
        }
        currentLayer.strokeColor = strokeColor
        currentLayer.lineWidth = CGFloat((shapeProperties.lineWidth))
        currentLayer.lineCap =  convertToCAShapeLayerLineCap("round")
        currentLayer.lineDashPhase = shapeProperties.lineDashPhase
        currentLayer.lineDashPattern =  LimitLineLayer.getNSNumberArray(lineDashLengths:shapeProperties.lineDashLengths)
        
        return currentLayer
    }
    
    
    /// draws x-Axis Labels without redraw
    public static func getTickInLayer(chart:ChartViewBase, tickLabel:TickLabel) -> CATextLayer
    {
        let (textRect,textPoint) = tickLabel.getRectOfMultilineText(text: tickLabel.label, point: tickLabel.point, attributes: tickLabel.attributes, constrainedToSize: tickLabel.constrainedSize, anchor: tickLabel.anchorPoint, angleRadians: tickLabel.angleInRadians)
        
        let layer = CATextLayer()
        layer.string = tickLabel.label
        guard let font = tickLabel.attributes[NSAttributedString.Key.font] as? NSUIFont,
              let color =  tickLabel.attributes[NSAttributedString.Key.foregroundColor] as? NSUIColor
        else { return layer}
        
                                
        layer.frame = textRect
        layer.fontSize = font.pointSize
        layer.font = font
        layer.foregroundColor = color.cgColor
        layer.contentsScale = NSUIMainScreen()!.nsuiScale //UIScreen.main.scale

        layer.truncationMode = .end
        
        layer.position = textPoint
        if (tickLabel.angleInRadians != 0 ) {
            layer.anchorPoint = CGPoint(x: 0.0, y: 0)
        }else {
            if (chart.xAxisRenderer.isKind(of: XAxisRendererHorizontalBarChart.self)) {
                layer.anchorPoint = CGPoint(x: 1, y: 0.5)
            }else {
                layer.anchorPoint = CGPoint(x: 0.5, y: 0)
            }
        }
                                
        var  transform = CATransform3DIdentity
        transform = CATransform3DMakeRotation(tickLabel.angleInRadians, 0, 0, 1);
        
        layer.transform =  transform
        return layer
    }
    
    /// draws x-Axis Labels without redraw
    public static func getAllTickLayers(chart:ChartViewBase) -> [TickLayer]
    {
        var tickLayerArray:[TickLayer] = []
        
        if let subLayer = chart.nsuiLayer?.sublayers
        {
            for layer in subLayer
            {
                if layer.isKind(of: TickLayer.self)
                {
                    tickLayerArray.append(layer as! TickLayer)
                }
            }
        }
        return tickLayerArray
    }
    
    public static func drawDataLabel(enabled: Bool = true, chart: ChartViewBase) {
        
        for layer in ChartEntryLayer.getAllValueLayers(chart: chart) {
            layer.opacity = enabled ? 1.0 : 0.0
        }
    }
    
    // MARK: - HighLight Layer
    
    /// Add Layer to Chart
    public static func addHighlightLayer(chart:ChartViewBase, layer:HighlightLayer)
    {
        chart.plotView?.nsuiLayer?.addSublayer(layer)
    }
    
    /// Add Layer to Chart
    public static func addLayerToPlot(chart:ChartViewBase, layer:CALayer)
    {
        chart.plotView?.nsuiLayer?.addSublayer(layer)
    }
    
    
    /// returns Highlight Layer Created
    public static func createLayer() -> HighlightLayer
    {
        return HighlightLayer()
    }
    
    /// returns Highlight Layer Created
    public static func createNoteLayer(noteEntry:NoteEntry) -> NoteLayer
    {
        return NoteLayer(noteEntry: noteEntry)
    }
    
    /// returns All Highlight Layers
    public static func getHighlightLayer(chart:ChartViewBase) -> [HighlightLayer]
    {
        var highLayers:[HighlightLayer] = []
        
        guard  let sublayers = (chart.plotView?.nsuiLayer?.sublayers) else { return highLayers }
        
        for layer in sublayers
        {
            let caLayer:CALayer = layer
            if caLayer.isKind(of: HighlightLayer.self)
            {
                highLayers.append((caLayer as! HighlightLayer))
            }
        }
        return highLayers
    }
    
    
    /// Removes Highlight Layers from Chart
    public static func removeHighlightLayer(chart:ChartViewBase)
    {
        let chartInstance = chart
        guard  let sublayers = (chartInstance.plotView?.nsuiLayer?.sublayers) else { return }
        
        for layer in sublayers
        {
            let caLayer:CALayer = layer
            if caLayer.isKind(of: HighlightLayer.self)
            {
                layer.removeFromSuperlayer()
            }
        }
    }
    
    /// returns Vertical and Horizontal Line
    public static func getVerticalandHorizontalLineLayer(chart:ChartViewBase,location:CGPoint) -> CAShapeLayer
    {
        let verticalLine = CommonHelperFunctions.getVerticalLineLayer(chart: chart, location: location)
        
        let horizontalPath = CGMutablePath()//UIBezierPath()
        horizontalPath.move(to: CGPoint(x:chart.viewPortHandler.contentLeft,y:location.y))
        horizontalPath.addLine(to: CGPoint(x: chart.viewPortHandler.contentRight, y: location.y))
        horizontalPath.closeSubpath()//.close()
        
        let horizontalLine = CAShapeLayer()
        horizontalLine.path = horizontalPath//.cgPath
        horizontalLine.lineDashPattern = [4,8]
        horizontalLine.lineWidth = 0.5
        horizontalLine.strokeColor = NSUIColor.black.cgColor
        
        verticalLine.addSublayer(horizontalLine)
        
        return verticalLine
    }
    
    /// returns Vertical Line
    public static func getVerticalLineLayer(chart:ChartViewBase,location:CGPoint) -> CAShapeLayer
    {
        let verticalPath = CGMutablePath()//UIBezierPath()
        verticalPath.move(to: CGPoint(x:location.x,y:0))
        verticalPath.addLine(to: CGPoint(x: location.x, y: chart.viewPortHandler.contentHeight))
        verticalPath.closeSubpath()//.close()
        
        let verticalLine = CAShapeLayer()
        verticalLine.path = verticalPath//.cgPath
        verticalLine.lineDashPattern = [4,8]
        verticalLine.lineWidth = 0.5
        verticalLine.strokeColor = NSUIColor.black.cgColor
        
        return verticalLine
    }
    
    public static func updateConstaints(containerView: ChartContainer) {
        
        NSLayoutConstraint.deactivate(containerView.installedConstraints)
        
        containerView.installedConstraints = containerView.getConstraints()
        
        #if os(OSX)
        containerView.needsUpdateConstraints = true
        #endif
    }
    
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCAShapeLayerLineCap(_ input: String) -> CAShapeLayerLineCap {
    return CAShapeLayerLineCap(rawValue: input)
}

extension CommonHelperFunctions {
    
    internal static func isOverlapping(currentBound: CGPath, previousBound: CGPath) -> Bool {
        
        for point in ChartUtils.cgPathToPoints(cgPath: currentBound) {
            
            if previousBound.contains(point) {
                return true
            }
        }
        
        return false
    }
    
    internal static func maxPixelSizeOfPlot(chart: ChartViewBase) -> CGFloat {
        
        var maxSize = 0.0
        
        for plotType in chart.getPlotTypes() {
            
            guard plotType == ChartType.Bubble || plotType == ChartType.BubblePie,
                  let axisPlotOption = chart.getPlotOptions(type: plotType) as? AxisChartPlotOptions else {
                continue
            }
            
            maxSize = max(maxSize, axisPlotOption.maximumShapeSizeInPixel)
        }
        
        maxSize = max(maxSize,ScatterHelperFunctions.maxScatterSize(chart: chart))
        
        return maxSize
    }
    
    public static func legendCellIndexForDataSet(chart: ChartViewBase, dataset: ChartDataSet) -> Int {
        
        guard let chartData = chart.data else {
            return -1
        }
        
        var index = 0
        
        for set in chartData.dataSets {
            
            if !set.legendNeeded {
                continue
            }
            
            if dataset.isEqual(set) {
                return index
            }
            
            index += 1
        }
        
        return -1
    }
}
