//
//  BubbleHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/02/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class BubbleHelperFunctions
{
    //TEMPORARY IMPL RATHER THAN THROWING ERROR
    public static func performHighlight(newEntry:ChartDataEntry, chart:ChartViewBase)
      {
          guard let location = CommonHelperFunctions.getEntryLocation(chart: chart, entry: newEntry)
          else { return }
          
          let bubbleLayer:BubbleLayer? = BubbleLayer.getBubbleLayerForEntry(chart: chart, entry: newEntry)
          
          chart.tapEventListener?.handler?.execute(chart, entry: newEntry, entryLayer: bubbleLayer, nil, location)
      }
    
    public static func hideDataset(dataSets:[ChartDataSet], chart:ChartViewBase, duration:TimeInterval)
    {
        guard let processor = chart.getProcessor(type: .PackedBubble) as? PackedBubblePreprocessor,
            let chartData = chart.data
            else { return }
        
        let oldValues = processor.dataValues
        
        for set in dataSets
        {
            set.visible = false
        }
        
        processor.doBubblePackLayout()
        
        let newValues = processor.dataValues
        
        let allLayers = BubbleLayer.getAllBubbleLayer(chart: chart)
        
        let entryAnimator = Animator()
        
        for text in BubbleLayer.getAllBubbleValueLayer(chart: chart)
        {
            text.opacity = 0
        }
                  
        entryAnimator.updateBlock = {
            
                var newIndex = -1
                
                for  oldIndex in 0..<oldValues.count
                {
                    guard let oldObject = oldValues[oldIndex] as? NSDictionary,
                    let oldXPosition = oldObject["x"] as? CGFloat,
                    let oldYPosition = oldObject["y"] as? CGFloat,
                    let oldRadius = oldObject["radius"] as? CGFloat,
                    let name = oldObject["name"] as? String,
                    let setIndex = (oldObject["setIndex"] as? Int)
                    else { continue }
                            
                    let set = chartData.dataSets[setIndex]
                   
                    if name == "root"
                    {
                        newIndex += 1
                        continue
                    }
                    
                    if set.isVisible
                    {
                        newIndex += 1
                        
                        guard let newObject = newValues[safe:newIndex] as? NSDictionary,
                              let dataOption = set.dataSetOptions as? AxisChartDataSetOptions
                            else { continue }
                        /*for value in newValues where (value as! NSDictionary)["setIndex"] as! Int == setIndex && (value as! NSDictionary)["name"] as! String == name
                        {
                            newObject = value as! NSDictionary
                            break
                        }*/
                        
                        guard let newXPosition = newObject["x"] as? CGFloat,
                        let newYPosition = newObject["y"] as? CGFloat,
                        let newRadius = newObject["radius"] as? CGFloat,
                        let name = newObject["name"] as? String
                        else { continue }
                        if name == "root"
                        {
                            newIndex += 1
                            continue
                        }
                        
                         var oldRect = CGRect(x: oldXPosition-oldRadius, y: oldYPosition-oldRadius, width: oldRadius * 2 , height: oldRadius * 2)
                         chart.plotTransformer.rectValueToPixel(&oldRect)
                        
                        var newRect = CGRect(x: newXPosition-newRadius, y: newYPosition-newRadius, width: newRadius * 2 , height: newRadius * 2)
                        chart.plotTransformer.rectValueToPixel(&newRect)
                        
                        let lineWidthHalf = dataOption.shapeProperties.lineWidth / 2.0
                        let xInterpolator = Interpolator.interpolate(a: oldRect.midX, b: newRect.midX)
                        let yInterpolator = Interpolator.interpolate(a: oldRect.midY, b: newRect.midY)
                        let radiusInterpolator = Interpolator.interpolate(a: oldRect.width - lineWidthHalf, b: newRect.width - lineWidthHalf)
//                        let xInterpolator = Interpolator.interpolate(a: oldXPosition, b: newXPosition)
//                        let yInterpolator = Interpolator.interpolate(a: oldYPosition, b: newYPosition)
//                        let radiusInterpolator = Interpolator.interpolate(a: oldRadius, b: newRadius)
                        
                        
                        let pointX = xInterpolator(CGFloat(entryAnimator.phaseX))
                        let pointY = yInterpolator(CGFloat(entryAnimator.phaseX))
                        let shapeHalf = radiusInterpolator(CGFloat(entryAnimator.phaseX)) / 2.0//shapeSize / 2.0
                        
//                        let circlePath = UIBezierPath(arcCenter: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat.pi * 2,  clockwise: true)
                        let circlePath = CGMutablePath()
                        circlePath.addArc(center: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle: CGFloat.pi * 2, clockwise: true)
                        
                        if let bubbleLayer = allLayers[safe:oldIndex]
                        {
                            bubbleLayer.path = circlePath//.cgPath
                        }
                        
                    }
                    else{
                        if let bubbleLayer = allLayers[safe:oldIndex]
                        {
                            bubbleLayer.opacity = 0
                        }
                    }
                }
              
        }
        
        entryAnimator.stopBlock = {
            chart.interactionAnimationInProgress = false
            
            chart.notifyDataSetChanged(redrawRequired: true)
            
            chart.delegateToContainer?.chartValueRemoved?(chart, entries: nil, dataSets: dataSets, dataSetRemoved: true,showTrackerView: false )
                
        }
      
        entryAnimator.animate(xAxisDuration: duration, easingOption: .linear)
    }
    
    public static func includeDataset(dataSets:[ChartDataSet], chart:ChartViewBase, duration:TimeInterval)
    {
            guard let processor = chart.getProcessor(type: .PackedBubble) as? PackedBubblePreprocessor,
                let chartData = chart.data
                else { return }
        
            let oldValues = processor.dataValues
            
            for set in dataSets
            {
                set.visible = true
            }
            
            processor.doBubblePackLayout()
            
            let newValues = processor.dataValues
            
            let allLayers = BubbleLayer.getAllBubbleLayer(chart: chart)
        
            for text in BubbleLayer.getAllBubbleValueLayer(chart: chart)
            {
                text.opacity = 0
            }
            
            let entryAnimator = Animator()
                      
            entryAnimator.updateBlock = {
                
                    var oldIndex = -1
                
                    for newIndex in 0..<newValues.count
                    {
                        guard let newObject = newValues[newIndex] as? NSDictionary,
                        let newXPosition = newObject["x"] as? CGFloat,
                        let newYPosition = newObject["y"] as? CGFloat,
                        let newRadius = newObject["radius"] as? CGFloat,
                        let newName = newObject["name"] as? String,
                        let setIndex = (newObject["setIndex"] as? Int),
                        let set = chartData.dataSets[setIndex] as? ChartDataSet
                        else { continue }
                        
                       
                        if newName == "root"
                        {
                            oldIndex += 1
                            continue
                        }
                        
                        if dataSets.contains(set)
                        {
                            continue
                        }
                        
                        oldIndex += 1
                        
                        guard let dataOption = set.dataSetOptions as? AxisChartDataSetOptions,
                        let oldObject = oldValues[oldIndex] as? NSDictionary,
                        let oldXPosition = oldObject["x"] as? CGFloat,
                        let oldYPosition = oldObject["y"] as? CGFloat,
                        let oldRadius = oldObject["radius"] as? CGFloat,
                        let oldName = oldObject["name"] as? String
                        else { continue }
                        
                        if oldName == "root"
                        {
                            oldIndex += 1
                            continue
                        }
                        
                       var oldRect = CGRect(x: oldXPosition-oldRadius, y: oldYPosition-oldRadius, width: oldRadius * 2 , height: oldRadius * 2)
                        chart.plotTransformer.rectValueToPixel(&oldRect)
                       
                       var newRect = CGRect(x: newXPosition-newRadius, y: newYPosition-newRadius, width: newRadius * 2 , height: newRadius * 2)
                       chart.plotTransformer.rectValueToPixel(&newRect)
                       
                       let lineWidthHalf = dataOption.shapeProperties.lineWidth / 2.0
                       let xInterpolator = Interpolator.interpolate(a: oldRect.midX, b: newRect.midX)
                       let yInterpolator = Interpolator.interpolate(a: oldRect.midY, b: newRect.midY)
                       let radiusInterpolator = Interpolator.interpolate(a: oldRect.width - lineWidthHalf, b: newRect.width - lineWidthHalf)
//
//                        let xInterpolator = Interpolator.interpolate(a: oldXPosition, b: newXPosition)
//                        let yInterpolator = Interpolator.interpolate(a: oldYPosition, b: newYPosition)
//                        let radiusInterpolator = Interpolator.interpolate(a: oldRadius, b: newRadius)
//
                        
                        let pointX = xInterpolator(CGFloat(entryAnimator.phaseX))
                        let pointY = yInterpolator(CGFloat(entryAnimator.phaseX))
                        
                        let shapeHalf = radiusInterpolator(CGFloat(entryAnimator.phaseX)) / 2.0
                        
//                        let circlePath = UIBezierPath(arcCenter: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat.pi * 2,  clockwise: true)
                        let circlePath = CGMutablePath()
                        circlePath.addArc(center: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle: CGFloat.pi * 2, clockwise: true)
                        
                        if let bubbleLayer = allLayers[safe:oldIndex]
                        {
                            bubbleLayer.path = circlePath//.cgPath
                        }
                        
                    }
                  
            }
            
            entryAnimator.stopBlock = {
                
                chart.interactionAnimationInProgress = false
                
                chart.notifyDataSetChanged(redrawRequired: true)
                
                chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: nil, dataSets: dataSets, dataSetAdded: true)
                    
            }
          
            entryAnimator.animate(xAxisDuration: duration, easingOption: .linear)
        }
    
    fileprivate static func performOpacityForCustomAnim(targetLayer:ChartEntryLayer,newOpacity:Float,duration:TimeInterval, delay:TimeInterval)
    {
//        CATransaction.begin()
        
        let anim = CABasicAnimation(keyPath: "opacity")
        
        anim.fromValue = targetLayer.opacity
        
        anim.toValue = newOpacity
        
//        anim.duration = duration
        
        anim.timingFunction =  CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        anim.beginTime = delay
        
//        CATransaction.setCompletionBlock( {
//            targetLayer.path = newPath.cgPath
//        })
//
        anim.fillMode = .forwards
        anim.isRemovedOnCompletion = false
        
        targetLayer.add(anim, forKey: "opacity")
        
    }
    
    
    public static func getAnimationBlock(chart:ChartViewBase, duration:TimeInterval) -> (() -> Void) {
        
        
        let animateBlock = {
                                        
                if chart.data == nil
                {
                    return
                }
                
                
                var xBasedMap:[Double:[BubbleLayer]] = [:]
            
                var xArray:[Double] = []
            
                for layer in BubbleLayer.getAllBubbleLayer(chart: chart)
                {
                    guard let entry = layer.chartEntry, !entry.x.isNaN else {
                        continue
                    }
                    
                    if (!xArray.contains(entry.x)) {
                        xArray.append(entry.x)
                    }
                    
                    var bubbleLayers = xBasedMap[entry.x]
                    if (bubbleLayers == nil){
                        bubbleLayers = []
                    }
                    bubbleLayers?.append(layer)
                    xBasedMap[entry.x] = bubbleLayers
                }
            
                xArray.sort()
                
                let intervalBetweenBarLayers = duration / Double(max(1, xBasedMap.count))

                let currentSystemTime = CACurrentMediaTime()
                        
                var mapIndex:Int = 0
                
                for x in xArray {
                    guard let bubbleLayers = xBasedMap[x]
                    else { continue }
                
                    let shapeDelay = (Double(mapIndex) * intervalBetweenBarLayers)
                    let shapeDuration = duration -  shapeDelay
                    let actualDelay = currentSystemTime + shapeDelay
                    
                    for bubbleLayer in bubbleLayers {
                                            
                        bubbleLayer.opacity = 0.0
                        
                        performOpacityForCustomAnim(targetLayer: bubbleLayer, newOpacity: 1.0, duration: shapeDuration, delay: actualDelay)
                    }
                    mapIndex = mapIndex + 1
                    
                }
        }
        
        return animateBlock
    }
    
    public static func enableSlice(chartEntry: [ChartDataEntry],chart:ChartViewBase,duration: TimeInterval)
    {
        let animator = Animator()
        
        var originalVal:[CGFloat] = []
        
        for e in chartEntry
        {
            guard let ePlotData = e.plotData as? Double
            else { continue }
            originalVal.append(CGFloat(ePlotData))
        }
        
        var yValueInterpolatorArray:[((Double) -> Double)] = []
        for val in originalVal
        {
            let interPolate = Interpolator.interpolate(a: 0 , b: Double(val) )
            yValueInterpolatorArray.append(interPolate)
        }
        
        animator.updateBlock = {
            for eIndex in 0..<chartEntry.count
            {
                let e = chartEntry[eIndex]
                e.plotData = yValueInterpolatorArray[eIndex](animator.phaseX) as AnyObject
            }
//            chart.notifyDataSetChanged(redrawRequired: true)
            (chart.getProcessor(type: .BubblePie) as? BubblePiePreprocessor)?.updateBuffer()
            chart.highlightValue(nil, callDelegate: true)
            chart.interactionAnimationInProgress = true
            
        }
        
        animator.stopBlock = {

            for eIndex in 0..<chartEntry.count
            {
                let e = chartEntry[eIndex]
                e.plotData = originalVal[eIndex] as AnyObject
            }
            chart.interactionAnimationInProgress = false

        }
        animator.animate(xAxisDuration: duration)
    }
    
    public static func disableSlice(chartEntry: [ChartDataEntry],chart:ChartViewBase,duration: TimeInterval)
    {
        let animator = Animator()
        
        var originalVal:[CGFloat] = []
        
        for e in chartEntry
        {
            guard let ePlotData = e.plotData as? Double
            else { continue }
            originalVal.append(CGFloat(ePlotData))
        }
        
        var yValueInterpolatorArray:[((Double) -> Double)] = []
        for val in originalVal
        {
            let interPolate = Interpolator.interpolate(a: Double(val), b: 0 )
            yValueInterpolatorArray.append(interPolate)
        }
        
        animator.updateBlock = {
            for eIndex in 0..<chartEntry.count
            {
                let e = chartEntry[eIndex]
                e.plotData = yValueInterpolatorArray[eIndex](animator.phaseX) as AnyObject
            }
//            chart.notifyDataSetChanged(redrawRequired: true)
            (chart.getProcessor(type: .BubblePie) as? BubblePiePreprocessor)?.updateBuffer()
            chart.highlightValue(nil, callDelegate: true)
            chart.interactionAnimationInProgress = true
            
        }
        
        animator.stopBlock = {

            for eIndex in 0..<chartEntry.count
            {
                let e = chartEntry[eIndex]
                e.plotData = originalVal[eIndex] as AnyObject
            }
            chart.interactionAnimationInProgress = false

        }
        animator.animate(xAxisDuration: duration)
    }
}
