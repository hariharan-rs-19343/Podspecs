//
//  HeatMapHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 10/06/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation


open class HeatMapHelperFunctions {
    
    public static func highLightMapEntry(chart:ChartViewBase,entry:ChartDataEntry?)
    {
        let barLineChart = chart
        
        let range = barLineChart.legend.legendRange
        
        if barLineChart.colorAxis.enabled && entry != nil
        {
            if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: entry!, minimum: floor(range.0), maximum: floor(range.1))) {
                return
            }
        }
        
        barLineChart.lastSelected = nil
        
        for layer in MapLayer.getAllMapLayer(chart: barLineChart)
        {
            guard (layer.chartEntry) != nil
            else { continue }
            if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: layer.chartEntry!, minimum: floor(range.0), maximum: floor(range.1)))
            {
                layer.fillColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
                continue
            }
            
            layer.fillColor = barLineChart.colorAxis.getColor(entry: layer.chartEntry!)?.cgColor
            if layer.chartEntry === entry || entry == nil
            {
                layer.opacity = 1
                  barLineChart.updateLastSelectedEntry(entry: entry)

            }
            else{
                layer.opacity = 0.5
            }
        }
        
        for textLayer in MapLayer.getAllValueLayer(chart: barLineChart) {
            
            guard let entry = textLayer.value(forKey: "entryForHighlight") as? ChartDataEntry else {
                continue
            }
            
            if !(barLineChart.colorAxis.isEntryAllowed(chartEntry: entry, minimum: floor(range.0), maximum: floor(range.1)))
            {
                textLayer.opacity = 0
                continue
            }
            
            textLayer.opacity = 1
            
        }
        
        let high = (barLineChart.lastSelected != nil && barLineChart.lastSelected!.count > 0) ? chart.getHighlightByEntry(barLineChart.lastSelected![0]) : nil
        
        barLineChart.highlightValue(high, callDelegate: false, redrawRequired: false)
    }
    
    public static func isDataLabelWithInRectBound(chart: ChartViewBase, labelRect: CGRect, rectBound: CGSize) -> Bool {
        
        if labelRect.width > rectBound.width || labelRect.height > rectBound.height {
            return false
        }
        
        return true
    }
    
    public static func constrainedWidthForDataLabel(chart: ChartViewBase, entry: ChartDataEntry, labelRect: CGRect, rectBound: CGSize) -> CGFloat {
        
        var constrainedWidth = -1.0
        
        if !isDataLabelWithInRectBound(chart: chart, labelRect: labelRect, rectBound: rectBound) {
            constrainedWidth = rectBound.width
        }
        else {
            constrainedWidth = labelRect.width
        }
        
        return constrainedWidth
    }
    
}
