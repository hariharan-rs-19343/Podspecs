//
//  ParserHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 15/03/23.
//


import Foundation
import JavaScriptCore


open class ParserHelperFunctions {
    
    public static func initializeChart(jsonString:String,containerView:ChartContainer)
    {
        var jsonStringFinal:AnyObject?
        do
        {
            if let goodJson = JSContext().evaluateScript("JSON.stringify(\(jsonString))"),
               let goodStr = goodJson.toString(),
               let data = goodStr.data(using: .utf8) {
                
                    if let jsonDict = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: AnyObject] {
                        
                        if let dataArray = jsonDict as? AnyObject {
                            jsonStringFinal = dataArray
                        }
                    }
            }
        }
        catch let jsonError {
            Log.error(jsonError)
        }
        
        var timerValue = Double(0)
      
        containerView.isAxisChart = true
        
        addChart(testCase: jsonStringFinal!, containerView: containerView)
        
        CommonHelperFunctions.updateConstaints(containerView: containerView)

        if (jsonStringFinal!["plotOption"] as? [String:Any])?["WORD_CLOUD"] != nil || (jsonStringFinal!["plotOption"] as? [String:Any])?["SANKEY"] != nil {
            timerValue += 5
        }
        else{
            timerValue += 0.2
        }
        
        if #available(iOS 10.0, *) {
            Timer.scheduledTimer(withTimeInterval: timerValue, repeats: false) { timer in
                print("Timer fired!")
                
                if containerView.legend.type == LegendType.continous
                {
//                    containerView.currentOrientation = .Undefined
//                    containerView.legend.type = .discrete
                    
//                    containerView.legendView.collectionView?.dataSource = containerView.legendView
//                    containerView.updateConstraints()
                }
                
                return
            }
        } else {
            // Fallback on earlier versions
        }

    }
    
    internal static func addChart(testCase:AnyObject,containerView:ChartContainer?)
    {
        //*****************************  initialize chart  *******************************//
        
        var chartView = containerView?.initializeChart()
        
        chartView?.isRotated = testCase["isRotated"] as! Bool
        
        //*****************************  Handlers  *******************************//
        
        chartView?.tapEventListener?.handler = BarHighlightHandler()
        
        chartView?.panEventListener?.handler = StackedBarPanHandler()
        
//        chartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        chartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        //*****************************  Axis  *******************************//
        
        let xAxisDict = testCase["xAxis"] as! [String:AnyObject]
        
        if let data = try? JSONSerialization.data(withJSONObject: xAxisDict, options: .prettyPrinted),
           let str = String(data: data, encoding: .utf8) {
            
            let decodeData = str.data(using: .utf8)
            let decoder = JSONDecoder()
            let valueDecoded = try? decoder.decode(XAxis.self, from: decodeData!)
            chartView?.xAxis = valueDecoded!
            chartView?.xAxisRenderer.axis = chartView?.xAxis
            chartView?.xAxis.valueFormatter = ValueFormatter(chart: chartView!)
            
//            chartView?.xAxis.tickDelegate = self
        }
        
        let yAxisDict = testCase["yAxis"] as! [[String:AnyObject]]
        
        if let data = try? JSONSerialization.data(withJSONObject: yAxisDict, options: .prettyPrinted),
           let str = String(data: data, encoding: .utf8) {
            
            let decodeData = str.data(using: .utf8)
            let decoder = JSONDecoder()
            let valueDecoded = try? decoder.decode([YAxis].self, from: decodeData!)
            
            for axisList in valueDecoded!
            {
                let _ = chartView?.createYAxis(axisIndex: axisList.axisIndex)
                
                let yAxisArray = (chartView!.yAxisArray)
                for yIndex in 0..<yAxisArray.count where yAxisArray[yIndex].axisIndex == axisList.axisIndex
                {
                    chartView?.yAxisArray[yIndex] = axisList
                    chartView?.yAxisArray[yIndex].valueFormatter = ValueFormatter(chart: chartView!)
                }
            }
        }
        
        chartView?.scaleXEnabled = true
        chartView?.scaleYEnabled = false
        
        //*****************************  Data  *******************************//
        
        let dataDict = testCase["data"] as! [String:AnyObject]
        
        if let data = try? JSONSerialization.data(withJSONObject: dataDict, options: .prettyPrinted),
           let str = String(data: data, encoding: .utf8) {
            
            let decodeData = str.data(using: .utf8)
            let decoder = JSONDecoder()
            let valueDecoded = try? decoder.decode(ChartData.self, from: decodeData!)
            
            if (chartView!.isRotated)
            {
                for set in valueDecoded!.dataSets where set.plotType == .Bar || set.plotType == .Bullet || set.plotType == .WaterFall || set.plotType == .BoxPlot
                {
                    let dataSetOptionsCopy = set.dataSetOptions
                    
                    set.dataSetOptions = dataSetOptionsCopy
                }
            }
            
            if valueDecoded?.dataSets[0].plotType == .Sanky {
                chartView?.xAxis.scaleType = .Ordinal
                
                let yAxisArray = (chartView!.yAxisArray)
                for yIndex in 0..<yAxisArray.count
                {
                    chartView?.yAxisArray[yIndex].scaleType = .Ordinal
                }
            }
            
            chartView?.data = valueDecoded!
            for set in valueDecoded!.dataSets
            {
                if !(set.plotType == .Scatter || set.plotType == .Bubble || set.plotType == .BubblePie || set.plotType == .PackedBubble)
                {
                    (set.dataSetOptions as! AxisChartDataSetOptions).shapeProperties.shapeType = .Default
                }
                
                if set.drawValuesEnabled
                {
                    chartView?.data!.setDrawValues(true)
                    break
                }
            }
            if chartView?.data?.valuesEnabled == nil
            {
                chartView?.data?.setDrawValues(false)
            }
            
            if (chartView?.getPlotTypes().contains(.BoxPlot))! {
                for set in valueDecoded!.dataSets {
                    for entryIndex in 0..<set.entryCount {
                        
                        let entry = set.entryForIndex(entryIndex)
                        
                        let dataObject = entry!.data as! [Any]
                        
                        var data = [Double]()
                        
//                        data.append(0.0)
                        
                        for val in dataObject {
                            if ((val as? Double) != nil) {
                                data.append(val as! Double)
                            }
                        }
                        
                        entry!.plotData = data as AnyObject
                    }
                }
            }
        }
        
        //****************** notes ***********************//
        
        if !(chartView?.getPlotTypes().contains(.WordCloud))!  && !(chartView?.getPlotTypes().contains(.Dial))! && !(chartView?.getPlotTypes().contains(.HeatMap))! {
            if let notesDict = testCase["notes"] as? [String:AnyObject] {
                
                if let data = try? JSONSerialization.data(withJSONObject: notesDict, options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    
                    if let valueDecoded = try? decoder.decode(Notes.self, from: decodeData!) {
                        chartView?.notes = valueDecoded
                        //                barChartView?.notes?.notesShape.customPathDataSource = self
                    }
                    
                }
            }
        }
        
        
        if let legendObject = (testCase["legend"] as? [String:AnyObject]) {
            
            containerView?.legend.legendEnabled = (legendObject["enable"] as? Bool) ?? true
            
            if containerView!.legend.legendEnabled
            {
                if let orientation = (legendObject["orientation"] as? String)
                {
                    switch orientation
                    {
                        case "VERTICAL":
                        containerView?.legend.legendOrientation = .Vertical
                        default:
                        containerView?.legend.legendOrientation = .Horizontal
                    }
                }

                if let position = (legendObject["position"] as? String)
                {
                    switch position
                    {
                        case "TOP":
                        containerView?.legend.legendPosition = .top
                        case "LEFT":
                        containerView?.legend.legendPosition = .left
                        case "RIGHT":
                        containerView?.legend.legendPosition = .right
                        default:
                        containerView?.legend.legendPosition = .bottom
                    }
                }
                
                let isContinuous = (legendObject["continuousLegend"] as? Bool) ?? false
                containerView?.legend.type = isContinuous ? .continous : .discrete
            
                if let legendFormObject = (legendObject["formProperties"] as? [String:AnyObject])
                {
                    
                    if let legendShape = (legendFormObject["type"] as? String) {
                        
                        let formshape = ShapeProperties()
                        
                        var shape: LineShapes
                        
                        switch legendShape {
                            
                        case "TRIANGLE":
                            shape = LineShapes.triangle
                            break
                        case "SQUARE":
                            shape = LineShapes.square
                            break
                        case "CROSS":
                            shape = LineShapes.cross
                            break
                        case "X":
                            shape = LineShapes.x
                            break
                        case "CIRCLE":
                            shape = LineShapes.circle
                            break
                        case "LINE":
                            shape = LineShapes.line
                            break
                        default:
                            shape = LineShapes.custom
                            break
                        }
                        
                        formshape.shapeType = shape
                        
                        //            formshape.customPathDataSource = self
                        
                        containerView?.legend.legendFormCustomEnabled = true
                        
                        containerView?.legend.customFormShape = formshape
                    }
                    
                }
            }
            
        }
        
    /*    if let legendShape = try? (testCase["legendShape"] as! String) {
            
            let formshape = ShapeProperties()
            
            var shape: LineShapes
            
            switch legendShape {
                
            case "TRIANGLE":
                shape = LineShapes.triangle
                break
            case "SQUARE":
                shape = LineShapes.square
                break
            case "CROSS":
                shape = LineShapes.cross
                break
            case "X":
                shape = LineShapes.x
                break
            case "CIRCLE":
                shape = LineShapes.circle
                break
            case "LINE":
                shape = LineShapes.line
                break
            default:
                shape = LineShapes.custom
                break
            }
            
            formshape.shapeType = shape
            
//            formshape.customPathDataSource = self
            
            containerView?.legend.legendFormCustomEnabled = true
            
            containerView?.legend.customFormShape = formshape
        }*/
        
        //*****************************  PlotOptions  *******************************//
        
        let plotOptionDict = testCase["plotOption"] as! [String:AnyObject]
        
        let isCombined = plotOptionDict.count > 1
        
        chartView?.isCombined = isCombined
        
        for (key,_) in plotOptionDict
        {
            switch key {
            case "BAR":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["BAR"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(BarPlotOptions.self, from: decodeData!)
                    
//                    if chartView!.isRotated
//                    {
//                        if valueDecoded?.levelMarkerWidthPixel != 0
//                        {
//                            chartView?.plotOptions[.HorizontalBullet] = valueDecoded!
//                        }
//                        else{
//                            chartView?.plotOptions[.Bar] = valueDecoded!
//                        }
//                    }
//                    else{
                        if valueDecoded?.levelMarkerWidthPixel != 0
                        {
                            chartView?.plotOptions[.Bullet] = valueDecoded!
                        }
                        else{
                            chartView?.plotOptions[.Bar] = valueDecoded!
                        }
//                    }
                    chartView?.scalePreference = isCombined ? .Bar : .Line
                    
                    if valueDecoded?.levelMarkerWidthPixel != 0
                    {
                        for set in (chartView?.data?.dataSets)! where set.plotType == .Bullet
                        {
                            for e in (set as! ChartDataSet).values
                            {
                                e.levelMarker  = ((e.data as? [AnyObject])?[0] as? [Double])
                                e.targetMarker  = ((e.data as? [AnyObject])?[1] as? Double)
                            }
                            set.notifyDataSetChanged()
                        }
                        chartView?.data?.notifyDataChanged()
                    }
                }
                break
                
            case "PIE":
                containerView?.isAxisChart = false
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["PIE"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(PiePlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Pie] = valueDecoded!
                }
                break
                
            case "DIAL":
                containerView?.isAxisChart = false
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["DIAL"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(DialPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Dial] = valueDecoded!
                    
                    for set in (chartView?.data?.dataSets)! where set.plotType == .Dial
                    {
                        for e in (set as! ChartDataSet).values
                        {
                            let anyObjectArray = (e.data as? [AnyObject])
                            if anyObjectArray != nil
                            {
                                e.levelMarker  = anyObjectArray?.count == 1 ? (anyObjectArray?[0] as? [Double]) : nil
                                e.targetMarker  = anyObjectArray?.count == 2 ? (anyObjectArray?[1] as? Double) : nil
                                e.calcPosNegMax()
                            }
                        }
                        set.notifyDataSetChanged()
                    }
                    chartView?.data?.notifyDataChanged()
                }
                break
                
            case "RADAR":
                containerView?.isAxisChart = false
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["RADAR"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(DialPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Radar] = valueDecoded!
                }
                break
                
            case "FUNNEL":
                containerView?.isAxisChart = false
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["FUNNEL"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(FunnelPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Funnel] = valueDecoded!
                }
                break
                
            case "WORD_CLOUD":
                let colorAxisDict = testCase["colorAxis"] as! [String:AnyObject]
                
                let isContinousLegend = colorAxisDict["legendType"] as! String == "LINEAR"
                if isContinousLegend
                {
                    containerView?.legendView.type = .continous
                }
                
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["WORD_CLOUD"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(WordCloudPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.WordCloud] = valueDecoded!
                    
                }
                if isContinousLegend
                {
                    for set in (chartView?.data?.dataSets)! where set.plotType == .WordCloud
                    {
                        for e in (set as! ChartDataSet).values
                        {
                            let anyObjectArray = (e.data as? [AnyObject])
                            if anyObjectArray != nil
                            {
                                e.colorValue  = anyObjectArray?.count == 2 ? ((e.data as? [AnyObject])?[1] as? String) != nil ? Double.nan : ((e.data as? [AnyObject])?[1] as? Double) : nil
                            }
                        }
                    }
                    
                    if let data = try? JSONSerialization.data(withJSONObject: colorAxisDict, options: .prettyPrinted),
                       let str = String(data: data, encoding: .utf8) {
                        
                        let decodeData = str.data(using: .utf8)
                        let decoder = JSONDecoder()
                        let valueDecoded = try? decoder.decode(ColorAxis.self, from: decodeData!)
                        
                        chartView?.colorAxis = valueDecoded?.copy() as! ColorAxis
                        chartView?.colorAxis.enabled = true
                        chartView?.colorAxis.legend = chartView?.legend
                    }
                }
                
                break
                
            case "LINE":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["LINE"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(LinePlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Line] = valueDecoded!
                }
                break
                
            case "BUBBLE":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["BUBBLE"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(BubblePlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Bubble] = valueDecoded!
                }
                
                for set in (chartView?.data?.dataSets)! where set.plotType == .Bubble
                {
                    for e in (set as! ChartDataSet).values
                    {
                        e.size = ((e.data as? [AnyObject])?[0] as? CGFloat) ?? 0
                    }
                    set.calcMinMax()
                }
                chartView?.data?.calcMinMax()
                break
                
            case "BUBBLE_PIE":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["BUBBLE_PIE"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(BubblePiePlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.BubblePie] = valueDecoded!
                }
                
                for set in (chartView?.data?.dataSets)! where set.plotType == .BubblePie
                {
                    for e in (set as! ChartDataSet).values
                    {
                        e.size = ((e.data as? [AnyObject])?[0] as? CGFloat) ?? 0
                        e.data = ((e.data as? [AnyObject])?[1] as? AnyObject) ?? (Double.nan as? AnyObject)
                        e.plotData = ((e.data as? AnyObject) ?? 0 as AnyObject)
                    }
                    set.calcMinMax()
                }
                chartView?.data?.calcMinMax()
                break
                
            case "PACKED_BUBBLE":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["PACKED_BUBBLE"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(BubblePlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.PackedBubble] = valueDecoded!
                }
                break
                
            case "HEAT_MAP":
//                containerView?.legendView.type = .continous
                
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["HEAT_MAP"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(AxisChartPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.HeatMap] = valueDecoded!
                    
                    for set in (chartView?.data?.dataSets)! where set.plotType == .HeatMap
                    {
                        for e in (set as! ChartDataSet).values
                        {
                            let anyObjectArray = (e.data as? [AnyObject])
                            if anyObjectArray != nil
                            {   if anyObjectArray!.count > 1
                                {
                                if ((e.data as? [AnyObject])?[1] as? String) != nil
                                {
                                    e.colorString = ((e.data as? [AnyObject])?[1] as? String) == "" ? nil : ((e.data as? [AnyObject])?[1] as? String)
                                }
                                else{
                                    e.colorValue  = ((e.data as? [AnyObject])?[1] as? Double)
                                }
                            }
                                e.size = 1//((e.data as? [AnyObject])?[0] as? CGFloat) ?? 0
                            }
                        }
                        set.calcMinMax()
                    }
                    chartView?.data?.calcMinMax()
                }
                
                let colorAxisDict = testCase["colorAxis"] as! [String:AnyObject]
                
                if let data = try? JSONSerialization.data(withJSONObject: colorAxisDict, options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(ColorAxis.self, from: decodeData!)
                    
                    chartView?.colorAxis = valueDecoded?.copy() as! ColorAxis
                    chartView?.colorAxis.enabled = true
                    chartView?.colorAxis.legend = chartView?.legend
                }
                break
                
            case "GEO_HEATMAP":
                containerView?.legendView.type = .continous
                
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["GEO_HEATMAP"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(GeoMapPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.GeoHeatMap] = valueDecoded!
                    
                    for set in (chartView?.data?.dataSets)! where set.plotType == .GeoHeatMap
                    {
                        for e in (set as! ChartDataSet).values
                        {
                            let anyObjectArray = (e.data as? [AnyObject])
                            if anyObjectArray != nil
                            {   if anyObjectArray!.count > 1
                                {
                                e.colorValue  = ((e.data as? [AnyObject])?[1] as? Double)
                            }
                            }
                        }
                    }
                    
                }
                
                let colorAxisDict = testCase["colorAxis"] as! [String:AnyObject]
                
                if let data = try? JSONSerialization.data(withJSONObject: colorAxisDict, options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(ColorAxis.self, from: decodeData!)
                    
                    chartView?.colorAxis = valueDecoded?.copy() as! ColorAxis
                    chartView?.colorAxis.enabled = true
                    chartView?.colorAxis.legend = chartView?.legend
                }
                break
                
            case "WATERFALL":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["WATERFALL"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(WaterFallPlotOptions.self, from: decodeData!)
                    
                    chartView?.plotOptions[.WaterFall] = valueDecoded!
                }
                break
                
            case "BOXPLOT":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["BOXPLOT"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(BoxPlotPlotOptions.self, from: decodeData!)
                    
                    for set in (chartView?.data?.dataSets)!
                    {
                        for e in (set as! ChartDataSet).values
                        {
                            let anyObjectArray = (e.data as? [AnyObject])
                            if anyObjectArray != nil
                            {   if anyObjectArray!.count > 1
                                {
                                if let plotData = (e.data as? [AnyObject]) {
                                    if plotData.count > 4 {
                                        e.colorValue  = plotData[4] as? Double
                                    }
                                }
                            }
                            }
                        }
                    }
                    
                    chartView?.plotOptions[.BoxPlot] = valueDecoded!
                }
                
                let colorAxisDict = testCase["colorAxis"] as! [String:AnyObject]
                
                if let data = try? JSONSerialization.data(withJSONObject: colorAxisDict, options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(ColorAxis.self, from: decodeData!)
                    
                    chartView?.colorAxis = valueDecoded?.copy() as! ColorAxis
                    chartView?.colorAxis.enabled = true
                    chartView?.colorAxis.legend = chartView?.legend
                }
                break
                
                
            case "MARIMEKKO":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["MARIMEKKO"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(BarPlotOptions.self, from: decodeData!)
                    
                    for set in (chartView?.data?.dataSets)!
                    {
                        for e in (set as! ChartDataSet).values
                        {
                            let anyObjectArray = (e.data as? [AnyObject])
                            if anyObjectArray != nil
                            {   if anyObjectArray!.count == 1
                                {
                                if let sizeData = anyObjectArray![0] as? CGFloat {
                                    e.size = sizeData
                                }
                            }
                            }
                        }
                    }
                    
                    chartView?.plotOptions[.Mekko] = valueDecoded!
                }
                break
                
            case "SANKEY":
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict["SANKEY"], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(SankeyPlotOptions.self, from: decodeData!)
                    
                }
                
                for set in (chartView?.data?.dataSets)! where set.plotType == .Sanky
                {
                    for e in (set as! ChartDataSet).values
                    {
                        e.size = ((e.data as? [AnyObject])?[0] as? CGFloat) ?? 0
                    }
                    set.calcMinMax()
                }
                
                chartView?.data?.calcMinMax()
                break
                
                
            default:
                if let data = try? JSONSerialization.data(withJSONObject: plotOptionDict[key], options: .prettyPrinted),
                   let str = String(data: data, encoding: .utf8) {
                    
                    let decodeData = str.data(using: .utf8)
                    let decoder = JSONDecoder()
                    let valueDecoded = try? decoder.decode(AxisChartPlotOptions.self, from: decodeData!)
                    chartView?.plotOptions[.Scatter] = valueDecoded!
                }
                break
            }
        }
        
        // should be given after data input
        //        barChartView?.xAxis.labelCount = 30
        
        //*****************************  Other chart properties  *******************************//
        
        chartView?.chartDescription?.enabled = false
        
    }
    
}
