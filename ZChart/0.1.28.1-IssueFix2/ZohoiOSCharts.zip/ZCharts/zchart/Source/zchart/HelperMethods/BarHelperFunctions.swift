//
//  BarHelperFunctions.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 29/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

import Foundation

open class BarHelperFunctions
{
    static let typeAllowed = [ChartType.Bar, ChartType.Bullet, ChartType.WaterFall, ChartType.BoxPlot, ChartType.Mekko,ChartType.HorizontalBarRange]
    
    /// Group/Multi Bar :- Includes Dataset
    public static func enableMultiBar(chartEntry: ChartDataEntry, chart:ChartViewBase, duration: TimeInterval, animation: ChartEasingOption)
    {
        guard let set = chart.data?.getDataSetForEntry(chartEntry)
        else { return }
        
        splitMultiBar(selectedDataset: set, chart: chart)
        
    }
    
    /// Group/Multi Bar :- Excludes Dataset
    public static func disableMultiBar(set: IChartDataSet, chart:ChartViewBase, duration: TimeInterval, animation: ChartEasingOption)
    {
        BarHelperFunctions.changeSizeOpacityForSelectedDataset(selectedDataset:set,chart: chart)
        
    }
    
    /// Bar :- Animate to Given Size and Opacity
    public static func barSizeOpacityAnimator(barLayer:BarLayer,opacity:CGFloat,changeSize:CGSize,chart:ChartViewBase,duration:TimeInterval)
    {
        guard let barRect = barLayer.barRect
        else { return }
        
        let newRect = CGRect(x: (barRect.origin.x + ((barRect.size.width - changeSize.width)/2)), y: (barRect.origin.y + ((barRect.size.height - changeSize.height)/2)), width: changeSize.width, height: changeSize.height)
        
        let newPath = barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        CommonHelperFunctions.performOpacityAnim(targetLayer: barLayer, opacity: opacity, duration: duration)
    
    }
    
    /// Group/Multi Bar :- Excludes Given Dataset With Size and Opacity Animation
    public static func changeSizeOpacityForSelectedDataset(selectedDataset:IChartDataSet,chart: ChartViewBase)
    {
        let allLayers = BarLayer.getAllBarLayer(chart: chart)
        
        
        for eachBarLayer in allLayers
        {
            if chart.data?.getDataSetForEntry(eachBarLayer.chartEntry) === selectedDataset
            {
                guard let currentRect = eachBarLayer.barRect
                else { continue }
                var changeSize = CGSize(width: (currentRect.width), height: (currentRect.height))
                
                if chart.isRotated
                {
                    changeSize.height = 0
                }
                else{
                    changeSize.width = 0
                }
                
                barSizeOpacityAnimator(barLayer: eachBarLayer, opacity: 0, changeSize: changeSize , chart: chart, duration: 0.6)
                
            }
            
        }

        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(600), execute: {
            
              alignMultiBar(selectedDataset: selectedDataset, chart: chart)
            
        })
        
        
    }
    
    /// Bar :- Animate layer to Given X- Position
    public static func barXInterpolateAnimator(barLayer:BarLayer,from:Double,to:Double,duration:TimeInterval)
    {
        let eachBarLayer = barLayer
        
        let selectedBarXInterpolator = Interpolator.interpolate(a: from, b: to)
        
        let barAnimator = Animator()
        
        barAnimator.updateBlock = {
            
            guard let currentRect = eachBarLayer.barRect
            else { return }
            
//            eachBarLayer.path = UIBezierPath(rect:CGRect(x: CGFloat(selectedBarXInterpolator(barAnimator.phaseX)), y: (currentRect.minY), width: (currentRect.width) , height: (currentRect.height))).cgPath
            eachBarLayer.path = CGMutablePath(rect:CGRect(x: CGFloat(selectedBarXInterpolator(barAnimator.phaseX)), y: (currentRect.minY), width: (currentRect.width) , height: (currentRect.height)), transform: nil)
        }
        
        
        barAnimator.animate(xAxisDuration: duration, easingOption: .linear)
    }
    
    /// Bar :- Highlights Bar in Given Location
    public static func highlightBar(location:CGPoint,bar:ChartViewBase)
    {
        var curSelected:BarLayer? = nil
        
        guard let barData = bar.data,
              let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: bar, types: typeAllowed) as? BarPlotOptions
            else { return }
        
        
        if barPlotOptions.isStacked || (barData.dataSetCount) > 1
        {
            curSelected = BarLayer.getBarLayerInPointOriginal(chart: bar ,loc: location)
        }
        else
        {
            curSelected = BarLayer.getBarLayerInPoint(chart: bar ,loc: location)
        }
        
        if curSelected != nil
        {
             if barPlotOptions.isStacked
             {
                
                if bar.lastSelected != nil &&  bar.IsEntrySelected(entry: curSelected?.chartEntry)
                {
                    barPlotOptions.barGroupSelectionEnabled = true
                    bar.xGroupSelected = true
                }
                 else {
                     bar.datasetSelected = true
                 }
               
             }
             else{
                
                 if bar.lastSelected != nil && bar.IsEntrySelected(entry: curSelected?.chartEntry) && !bar.lastSelected!.contains(where: { $0 === curSelected?.chartEntry})
                {
                    barPlotOptions.barGroupSelectionEnabled = true
                    bar.xGroupSelected = true
                }
                else{
                    barPlotOptions.barGroupSelectionEnabled = false
                    bar.xGroupSelected = false
                    bar.datasetSelected = true
                }
            }
            
            curSelected?.opacity = 1.0
            
            bar.updateLastSelectedEntry(entry: curSelected?.chartEntry)
            
            if ((barData.dataSetCount) == 1)
            {
                barPlotOptions.barGroupSelectionEnabled = true
                bar.resetHighlight()
            }
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                if curSelected != layer
                {
                    layer.opacity = 0.5
                }
                
            }
            
        }
        else
        {
            barPlotOptions.barGroupSelectionEnabled = false
            bar.xGroupSelected = false
            
            bar.lastSelected = nil
            
            if barPlotOptions.isStacked || (barData.dataSetCount) > 1
            {
                curSelected = BarLayer.getBarLayerInPoint(chart: bar ,loc: location)
                
                if curSelected != nil{
                    barPlotOptions.barGroupSelectionEnabled = true
                    bar.xGroupSelected = true
                     bar.updateLastSelectedEntry(entry: curSelected?.chartEntry)
                }
            }
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                
                    layer.opacity = 1.0
            }
        }
    }
    
    /// Bar :- Highlights Bar in Given Location with Magnified Effect
    public static func highlightBarWithMagnifiedEffect(location:CGPoint,changePercent:CGFloat,bar:ChartViewBase)
    {
        guard let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: bar, types: [.Bar]) as? BarPlotOptions
            else { return }
        
        let h = bar.getHighlightByTouchPoint(location)
        
        let curSelected = BarLayer.getBarLayerInPoint(chart: bar ,loc: location)
    
        if barPlotOptions.isStacked
        {
            magnifierEffectForStackedBar(location: location, bar: bar)
            
            return
        }

        
        if !bar.IsEntrySelected(entry: curSelected?.chartEntry) //curSelected?.chartEntry != bar.lastSelected
        {
            
            
            ///Need to handle highlight/non highlight gradient during magnify effect
            ///CURRENTLY COMMENETED OUT THE MAGNIFY HIGHLIGHTING OPTIONS
           /* var baseGradient:BaseGradient? = nil
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                if curSelected != layer {
                    baseGradient = ((bar.data) as! ChartData).nonHighlightGradient
                    if baseGradient == nil && (layer.barDataSet?.gradients.count)! >= 1 {
                        baseGradient = layer.barDataSet?.gradient(atIndex: layer.getGradientColorIndex())
                    }
                } else {
                    baseGradient = ((bar.data) as! ChartData).highlightGradient
                }
                
                if baseGradient != nil {
                    _ = GradientLayerRenderer.updateGradientLayer(container: layer, gradientPath: (layer.path)!, gradient: baseGradient!, drawMaskEnabled: false)
                }
                baseGradient = nil
            }
            */
           
//            bar.lastSelected = curSelected?.chartEntry
            bar.updateLastSelectedEntry(entry: curSelected?.chartEntry)
           // No redraw occurs..
            bar.callDelegateToContainer(highlight: h, entry: curSelected?.chartEntry)
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                
                if curSelected?.chartEntry?.x != layer.chartEntry?.x
                {
                    var changeOpacity:CGFloat
                    
                    let color = (barPlotOptions).nonHighlightColor?.cgColor
                    if color != nil
                    {
                        layer.fillColor = color
                        changeOpacity = 1.0
                    }
                    else{
                        changeOpacity = 0.5
                        layer.fillColor = layer.barDataSet?.color(atIndex: 0).cgColor
                    }
                    
                    guard let layerRect = layer.barRect
                    else { continue }
                    
                    let currentSize:CGSize
                    if bar.isRotated
                    {
                        currentSize = CGSize(width: (layerRect.width), height: (layerRect.height)-(((layerRect.height) * changePercent)))
                    }
                    else{
                        currentSize = CGSize(width: (layerRect.width)-(((layerRect.width) * changePercent)), height: (layerRect.height))
                    }
                    
                    
                    barSizeOpacityAnimator(barLayer: layer, opacity: CGFloat(changeOpacity), changeSize: currentSize, chart: bar, duration: 0.2)
                }
                else{
                    layer.opacity = 1.0
                    
                    guard let layerRect = layer.barRect
                    else { continue }
                    
                    let changeSize:CGSize
                    
                    if bar.isRotated
                    {
                        changeSize = CGSize(width: (layerRect.width), height: (layerRect.height)+(((layerRect.height) * changePercent)))
                    }
                    else{
                        changeSize = CGSize(width: (layerRect.width)+(((layerRect.width) * changePercent)), height: (layerRect.height))
                    }
                    
                    let color = (barPlotOptions).highlightColor?.cgColor
                    if color != nil
                    {
                        layer.fillColor = color
                    }
                    else
                    {
                        layer.fillColor = layer.barDataSet?.color(atIndex: 0).cgColor
                    }
                    
                    barSizeOpacityAnimator(barLayer: layer, opacity: 1.0, changeSize: changeSize, chart: bar, duration: 0.2)
                }
                
            }
        }
        
    }
    
    public static func singleBarActionOnTooltipSelect(entry: ChartDataEntry, chart: ChartViewBase)
    {
        guard let barPlotOptions =  CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar]) as? BarPlotOptions,
            let viewPortHandler = chart.viewPortHandler
        else { return }
        
        let allBarLayer = BarLayer.getAllBarLayer(chart: chart)
        
        var barwidth:CGFloat = 0
        
        guard let firsrBarRect = allBarLayer[0].barRect
        else { return }
        
        if chart.isRotated
        {
            barwidth = (firsrBarRect.height)
        }
        else{
            barwidth = (firsrBarRect.width)
        }
        
        guard let curIndex = chart.data?.dataSets[0].entryIndex(entry: entry),
              let eCount = (chart.data?.dataSets[0].entryCount)
        else { return }
        
        let nextIndex = (curIndex + 1) % eCount
        
        let curEntry = chart.data?.dataSets[0].entryForIndex(nextIndex)
//        chart.lastSelected = curEntry
        chart.updateLastSelectedEntry(entry: curEntry)
        
        var animate:Bool = false
        
        var distance:CGFloat = 0
        
        let lastLayer = allBarLayer[allBarLayer.count-1]
        
        if nextIndex == 0
        {
            animate = true
            
            guard let curEntry = chart.data?._dataSets[0].entryForIndex(0)
            else { return }
//            chart.lastSelected = curEntry
            chart.updateLastSelectedEntry(entry: curEntry)
            
            chart.delegateToContainer?.chartValueSelected?(chart, entry: curEntry)
            
            let barSpaceWidth = (barwidth/CGFloat(barPlotOptions.barWidth))*CGFloat(1-barPlotOptions.barWidth)
            
            distance = CGFloat(((curIndex)+1))*(barwidth+barSpaceWidth)
            
            if chart.isRotated
            {
                if chart.xAxis.isInverted //X axis inverted
                {
                }
                else
                {
                    distance = -distance
                }
                
            }
            else
            {
                if chart.xAxis.isInverted //X axis inverted
                {
                    distance = -distance
                }
            }
            
            
            
        }
        else
        {
            var translate = false
            var offset = CGFloat(0)
            
            guard (curEntry != nil),
                  (lastLayer.chartEntry != nil),
                    (lastLayer.barRect != nil)
            else { return }
            
            if (lastLayer.chartEntry?.x)! < (curEntry?.x)!
            {
                translate = true
            }
            if chart.isRotated
            {
                if ((lastLayer.chartEntry?.x)! == (curEntry?.x)! && ((lastLayer.barRect?.maxY)! > viewPortHandler.contentBottom))
                {
                    translate = true
                    offset = viewPortHandler.contentBottom - (lastLayer.barRect?.minY)!
                }
            }
            else{
                if ((lastLayer.chartEntry?.x)! == (curEntry?.x)! && ((lastLayer.barRect?.maxX)! > viewPortHandler.contentRight))
                {
                    translate = true
                    offset = viewPortHandler.contentRight - (lastLayer.barRect?.minX)!
                }
            }
            
            if translate
            {
                animate = true
                distance = -viewPortHandler.contentRect.width + offset
                
                if chart.xAxis.isInverted //X axis inverted, single bar chart
                {
                    distance = viewPortHandler.contentRect.width - offset
                }
                
                if chart.isRotated
                {
                    if chart.xAxis.isInverted //X axis inverted
                    {
                        distance = -(viewPortHandler.contentRect.height) + offset
                    }
                    else
                    {
                        distance = viewPortHandler.contentRect.height - offset
                    }
                }
                
                chart.delegateToContainer?.chartValueSelected?(chart, entry: curEntry!)
            }
        }
        
        
        if animate{
            
            CommonHelperFunctions.translateView(distance: distance, duration: 1, chart: chart)
        }
        else{
            chart.delegateToContainer?.chartValueSelected?(chart, entry: curEntry!)
            chart.setNeedsDisplay()
        }
    }
        
    public static func singleBarActionOnTooltipSelectNewLogic(entry: ChartDataEntry?, chart: ChartViewBase) {
        
        guard let newEntry =  chart.xAxis.isInverted ? CommonHelperFunctions.getPrevEntry(entry: entry, includeXNan: false, includeYNan: true, chart: chart) : CommonHelperFunctions.getNextEntry(entry: entry, includeXNan: false, includeYNan: true, chart: chart)
            else { return }
        
        let block = {
//            chart.lastSelected = newEntry
            chart.updateLastSelectedEntry(entry: newEntry)
            chart.delegateToContainer?.chartValueSelected?(chart, entry: newEntry)
            chart.setNeedsDisplay()
        }
        
        let x = chart.xAxis.inverted ? newEntry.x + 0.5 : newEntry.x - 0.5
        CommonHelperFunctions.scrollViewToXAndExecuteBlock(x: x, y: newEntry.y, duration: 0.5, executionBlock: block, alignCenter: false, chart: chart)
    }
    
    
    /// Stacked Bar :- Magnification and Shrinking
    public static func magnifierEffectForStackedBar(location:CGPoint,bar:ChartViewBase)
    {
        let curSelected = BarLayer.getBarLayerInPoint(chart: bar ,loc: location)
        
        if curSelected == nil
        {
            if bar.lastSelected != nil
            {
                bar.lastSelected = nil
                
                bar.callDelegateToContainer(highlight: nil, entry: curSelected?.chartEntry)
                
                for layer in BarLayer.getAllBarLayer(chart: bar)
                {
                    guard let layerRect = layer.barRect
                    else { continue }
                    barSizeOpacityAnimator(barLayer: layer, opacity: 1.0, changeSize: CGSize(width: (layerRect.size.width), height: (layerRect.height)), chart: bar, duration: 0.1)
                }
            }
            
            return
        }
        
        let curEntry = curSelected?.getBarChartEntry()
        
        if curEntry != nil && bar.IsEntryXSelected(x: curEntry!.x) //curEntry?.x == bar.lastSelected?.x
        {
            return
        }
        
        let h = bar.getHighlightByTouchPoint(location)
        
//        bar.lastSelected = curSelected?.chartEntry
       bar.updateLastSelectedEntry(entry: curSelected?.chartEntry)
        
        bar.callDelegateToContainer(highlight: h, entry: curSelected?.chartEntry)
        
        for layer in BarLayer.getAllBarLayer(chart: bar)
        {
           if layer.getBarChartEntry().x == curEntry?.x
           {
            
            magnifyBarLayer(curSelected: layer, bar: bar )
        
           }
           else
           {
            shrinkBarLayer(layer: layer, bar: bar)
           }
       }
        
    }
    
    /// Bar :- Animate View to Given Entry Index Position
    public static func moveViewToIndex(newIndex:Int,barChart:ChartViewBase) -> Bool
    {
        guard let barPlotOptions =  CommonHelperFunctions.getPlotOption(chart: barChart, types: [.Bar]) as? BarPlotOptions
               else { return false }
        
        let allBarLayer = BarLayer.getAllBarLayer(chart: barChart)
        
        let barwidth:CGFloat
        
        guard let firstBarRect = allBarLayer[0].barRect
        else { return false }
        
        if barChart.isRotated
        {
            barwidth = (firstBarRect.height)
        }
        else{
            barwidth = (firstBarRect.width)
        }
        
        guard let barData = barChart.data,
                let startEntry = (allBarLayer[0].chartEntry),
                let endEntry = (allBarLayer[allBarLayer.count-1].chartEntry)
        else { return false }
        
        let barSpaceWidth = (barwidth/CGFloat(barPlotOptions.barWidth))*CGFloat(1-barPlotOptions.barWidth)
        
        var moved:Bool = false
        
        let barLayerStartIndex = (barData.dataSets[0].entryIndex(entry: startEntry))
        
        let barLayerEndIndex = (barData.dataSets[0].entryIndex(entry: endEntry))
        
        if (newIndex < barLayerStartIndex) || (newIndex > barLayerEndIndex)
        {
            
            var count = 0
            if barPlotOptions.isStacked
            {
//                let stackEntryYcount = (allBarLayer[0].chartEntry as! ChartDataEntry).yValues?.count
//                count = barLayerStartIndex - newIndex + (allBarLayer.count/(2*stackEntryYcount!))
            }
            else
            {
                count = barLayerStartIndex - newIndex + (allBarLayer.count/2)
            }
            
            
            let distToMove = CGFloat(count) * (barwidth+barSpaceWidth)
            
            if barChart.isRotated
            {
                if barChart.xAxis.isInverted //x-axis inverted
                {
                    CommonHelperFunctions.translateView(distance: distToMove, duration: 1, chart: barChart)
                }
                else
                {
                    CommonHelperFunctions.translateView(distance: -distToMove, duration: 1, chart: barChart)
                }
            }
            else{
                if barChart.xAxis.isInverted //x-axis inverted
                {
                    CommonHelperFunctions.translateView(distance: -distToMove, duration: 1, chart: barChart)
                }
                else
                {
                    CommonHelperFunctions.translateView(distance: distToMove, duration: 1, chart: barChart)
                }
            }
            moved = true
            
        }
        
        return moved
    }
    
  
    
    /// Bar :- Performs Magnification Animation
   static func magnifyBarLayer(curSelected: BarLayer?, bar: ChartViewBase)
     {
        guard let barPlotOptions =  CommonHelperFunctions.getPlotOption(chart: bar, types: [.Bar]) as? BarPlotOptions
        else { return  }
        
        curSelected?.opacity = 1.0
        
        let color = barPlotOptions.highlightColor?.cgColor
        if color != nil
        {
            curSelected?.fillColor = color
        }
        else
        {
            curSelected?.fillColor = curSelected?.barDataSet?.color(atIndex: 0).cgColor
        }
        
        /* Need to check across bars
        let highlightGradient = ((bar.data) as! ChartData).highlightGradient
        
        if highlightGradient != nil {
            _ = GradientLayerRenderer.updateGradientLayer(container: curSelected!, gradientPath: (curSelected?.path)!, gradient: highlightGradient!, drawMaskEnabled: false)
        } */
    
        let selectedBarSizeInterpolator:((Double) -> Double)
        
        let selectedBarXYInterpolator:((Double) -> Double)
        
        let horizontalChart = bar.isRotated
        
         guard let curBarRect = curSelected?.barRect
         else { return }
         
        if horizontalChart
        {
            selectedBarSizeInterpolator = Interpolator.interpolate(a: Double((curBarRect.height)), b: Double((curBarRect.height)+(((curBarRect.height) * 0.25))))
            
            selectedBarXYInterpolator = Interpolator.interpolate(a: Double((curBarRect.minY)), b: Double((curBarRect.minY)-(((curBarRect.height) * 0.25)/2)))
        }
        else{
           
            selectedBarSizeInterpolator = Interpolator.interpolate(a: Double((curBarRect.width)), b: Double((curBarRect.width)+(((curBarRect.width) * 0.25))))
            
            selectedBarXYInterpolator = Interpolator.interpolate(a: Double((curBarRect.minX)), b: Double((curBarRect.minX)-(((curBarRect.width) * 0.25)/2)))
        }
        
    
    let barAnimator = Animator()
    
    barAnimator.updateBlock = {
    
        let newPath:CGMutablePath
        
        let rect: CGRect
        
        if horizontalChart
        {
//            newPath = UIBezierPath(rect:CGRect(x: (curSelected?.barRect?.minX)! , y: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), width: (curSelected?.barRect?.width)! , height: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX))))
            
            rect = CGRect(x: (curBarRect.minX) , y: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), width: (curBarRect.width) , height: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX)))
        }
        else{
//            newPath = UIBezierPath(rect:CGRect(x: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), y: (curSelected?.barRect?.minY)!, width: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX)) , height: (curSelected?.barRect?.height)!))
            rect = CGRect(x: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), y: (curBarRect.minY), width: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX)) , height: (curBarRect.height))
        }
        
        guard curSelected != nil
        else { return }
        newPath = (curSelected?.getPath(rect: rect))!

        CommonHelperFunctions.performPathAnim(targetLayer: curSelected!, newPath: newPath, duration: 0)
    }
         
         barAnimator.stopBlock = { [unowned barAnimator] in
             barAnimator.updateBlock = nil
         }
    
      barAnimator.animate(xAxisDuration: 0.2, easingOption: .linear)
    
    }
    
    /// Bar :- Performs Shrinking Animation
    static func shrinkBarLayer(layer: BarLayer, bar: ChartViewBase)
    {
        guard let barPlotOptions =  CommonHelperFunctions.getPlotOption(chart: bar, types: [.Bar]) as? BarPlotOptions
        else { return  }
        
        layer.opacity = 0.5
        
        let color = barPlotOptions.nonHighlightColor?.cgColor
        if color != nil
        {
            layer.fillColor = color
            layer.opacity = 1.0
        }
        else{
            layer.opacity = 0.5
            layer.fillColor = layer.barDataSet?.color(atIndex: 0).cgColor
        }
        
        /* Need to check across bars
        let nonHighlightGradient = ((bar.data) as! ChartData).nonHighlightGradient
        
        if nonHighlightGradient != nil {
            _ = GradientLayerRenderer.updateGradientLayer(container: layer, gradientPath: (layer.path!), gradient: nonHighlightGradient!, drawMaskEnabled: false)
        }
        */
        
        let selectedBarSizeInterpolator:((Double) -> Double)
        
        let selectedBarXYInterpolator:((Double) -> Double)
        
        let horizontalChart = bar.isRotated
        
        guard let layerPath = layer.path,
              let layerRect = layer.barRect
        else { return }
        if horizontalChart
        {
            selectedBarSizeInterpolator = Interpolator.interpolate(a: Double((layerPath.boundingBox.height)), b: Double((layerRect.height)-(((layerRect.height) * 0.25))))
            
            selectedBarXYInterpolator = Interpolator.interpolate(a: Double((layerPath.boundingBox.minY)), b: Double((layerRect.minY)+(((layerRect.height) * 0.25)/2)))
        }
        else{
            
            selectedBarSizeInterpolator = Interpolator.interpolate(a: Double((layerPath.boundingBox.width)), b: Double((layerRect.width)-(((layerRect.width) * 0.25))))
            
            selectedBarXYInterpolator = Interpolator.interpolate(a: Double((layerPath.boundingBox.minX)), b: Double((layerRect.minX)+(((layerRect.width) * 0.25)/2)))
        }
        
            let barAnimator = Animator()
            
            barAnimator.updateBlock = {
                let newPath:CGMutablePath
                
                let rect: CGRect
                
                if horizontalChart
                {
//                    newPath = UIBezierPath(rect:CGRect(x: (layer.barRect?.minX)! , y: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), width: (layer.barRect?.width)! , height: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX))))
                    rect = CGRect(x: (layerRect.minX) , y: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), width: (layerRect.width) , height: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX)))
                }
                else{
//                    newPath = UIBezierPath(rect:CGRect(x: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), y: (layer.barRect?.minY)!, width: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX)) , height: (layer.barRect?.height)!))
                    rect = CGRect(x: CGFloat(selectedBarXYInterpolator(barAnimator.phaseX)), y: (layerRect.minY), width: CGFloat(selectedBarSizeInterpolator(barAnimator.phaseX)) , height: (layerRect.height))
                }
                
                newPath = layer.getPath(rect: rect)//UIBezierPath(rect: rect)
                
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0)
            }
        
        barAnimator.stopBlock = { [unowned barAnimator] in
            barAnimator.updateBlock = nil
        }
            
        barAnimator.animate(xAxisDuration: 0.2, easingOption: .linear)
    }
    
    /// Stacked Bar :- Includes Stack Dataset With Animation
    public static func includeStackEntry(barChartView:ChartViewBase, indexToInclude:Int)
    {
        guard let selectedDataset = barChartView.data?.dataSets[indexToInclude],
            let processor = barChartView.getProcessor(type: .Bar) as? BarPreprocessor
            else { return }
        
        var yInterpolator:[((Double) -> Double)] = []
        
        /*for i in 0..<(selectedDataset.entryCount)
        {
            guard let entry = selectedDataset.entryForIndex(i)
                else { continue }
            
            yInterpolator.append(Interpolator.interpolate(a: 0, b: (entry.y)))
            
            entry.y = 0
        }*/
        
        selectedDataset.visible = true
        
        barChartView.includeLayer = true
        
        barChartView.data?.updateXYValues()
        
        barChartView.data?.notifyDataChanged()
        
//        barChartView.notifyDataSetChanged(redrawRequired: false)
        
//        barChartView.notifyDataSetChanged()
        
        //THIS IS TO AVOID AXIS SETTING NEW MIN MAX VALUE FOR SMOOTH ANIMATION
//        ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: barChartView)
        
        for i in 0..<(selectedDataset.entryCount)
       {
           guard let entry = selectedDataset.entryForIndex(i)
               else { continue }
           
           yInterpolator.append(Interpolator.interpolate(a: 0, b: (entry.y)))
           
           entry.y = 0
       }
        
        ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: barChartView)
        
        var entryToAdd:[ChartDataEntry] = []
        
        let selectedDatasetEntry = selectedDataset.entryForIndex(0)
        
        if selectedDatasetEntry != nil
        {
            entryToAdd.append(selectedDatasetEntry!)
        }
        
        let barEntryAnimator = Animator()
        
        barEntryAnimator.updateBlock = {
            
            for i in 0..<(selectedDataset.entryCount)
            {
                guard let entry = selectedDataset.entryForIndex(i)
                    else { continue }
                
                entry.y = yInterpolator[i](barEntryAnimator.phaseX)
            }
            
//            barChartView.data?.notifyDataChanged()
            
            processor.calcPosNegSum()
            
            barChartView.setNeedsDisplay()
        }
        
        barEntryAnimator.stopBlock = {
            
          /*  barChartView.interactionAnimationInProgress = false
            
            barChartView.data?.notifyDataChanged()
            
            processor.calcPosNegSum()
            
            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: barChartView)
            
            barChartView.chartActionListener?.chartValueAdded?(chartView: barChartView, entry: entryToAdd , index: indexToInclude, dataSetAdded: true) */
            
            CommonHelperFunctions.includeDataset(selectedDataset: [selectedDataset], chart: barChartView)
        }
        
        
        barEntryAnimator.animate(xAxisDuration: 0.3, easingOption: .linear)
        
    }
    
    /// Stacked Bar :- Excludes Stack Dataset With Animation
    public static func excludeStackEntry(barChartView:ChartViewBase, indexToRemove:Int)
    {
        let barChart = barChartView
    
        guard let set = (barChart.data?.dataSets[indexToRemove])
        else { return }
//        barChart.lastSelected = CommonHelperFunctions.getNextEntryAfterIndex(index: set.entryCount-1, set: set, includeXNan: false, includeYNan: true)
        barChart.updateLastSelectedEntry(entry: CommonHelperFunctions.getNextEntryAfterIndex(index: set.entryCount-1, set: set, includeXNan: false, includeYNan: true))
        
        BarLayer.removeAllValueLayer(chart: barChart)
        
        let animationDuration = 0.2
        
        if barChart.isRotated
        {
            self.callHorizontalGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: 1)
        }
        else{
            self.callGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: 1)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(animationDuration * 1000)), execute: {
            
            if isStackPercentEnabled(chart: barChart)
            {
                    BarHelperFunctions.callGroupFilterEndAnimation( chartView: barChart, animationDuration: 0.15)
                
                    DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(0.15 * 1000)), execute: {
                    
                            guard let removedSet = barChart.data?.dataSets[indexToRemove] as? ChartDataSet
                        else { return }
                            
                            barChartView.interactionAnimationInProgress = false
                        
                            barChartView.delegateToContainer?.chartValueRemoved?(barChartView, entries: nil, dataSets: [removedSet], dataSetRemoved: true, showTrackerView: false)
                        
                    })
            }
            else{
                
                guard let set = (barChartView.data?.dataSets[indexToRemove])
                else { return }
                barChartView.lastSelected = nil
                CommonHelperFunctions.hideDataSet(selectedDataset: [set], chart: barChartView)
            }
            
        })
        
    }
    
    /// Stacked Bar :- Performs Selected Stack Layers Filtering Animation
    public static func callGroupFilterAnimation(chartView:ChartViewBase, animationDuration:TimeInterval,percent:CGFloat)
    {
        
        guard
            let barData = chartView.data,
            let lastSelectedEntries = chartView.lastSelected,
            lastSelectedEntries.count > 0,
            let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0])
            else { return }
      
        let barChart = chartView
        
        let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)
        
        let indexToBarLayer = BarHelperFunctions.getStackIndexToBarLayer(barChart: barChart)
        
        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barChart, dataSet: barData.dataSets[0])
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            guard let layerSet = layer.barDataSet,
                  let layEntry = layer.chartEntry
            else { return }
            let currentDataSetIndex = barData.indexOfDataSet(layerSet)
            
            let aboveBaseLine = (layEntry.y) > baseLineValue
            
            let filterlayer = indexToBarLayer[(layEntry.x)]
            
            if filterlayer == nil || filterlayer?.barRect == nil || layer.barRect == nil || filterlayer?.chartEntry == nil
            {
                continue
            }
            
            let filteredLayerAboveBaseLine = (filterlayer?.chartEntry?.y)! > baseLineValue
            
            if  currentDataSetIndex == lastSelectedDataSetIndex
            {
                guard let layerHeight = layer.barRect?.size.height
                else { continue }
                
                if layerHeight == 0
                {
                    continue
                }
                
                let newTransY =  (layerHeight) * percent
                
                if aboveBaseLine
                {
                    BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: newTransY, chart: chartView, duration: animationDuration)
                }
                else{
                    BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: 0, changeHeight: -newTransY, chart: barChart, duration: animationDuration)
                }
                
            }
            else if (filteredLayerAboveBaseLine == aboveBaseLine) && ((aboveBaseLine && (layer.barRect?.minY)! < (filterlayer?.barRect?.minY)!) || (!aboveBaseLine && (layer.barRect?.minY)! > (filterlayer?.barRect?.minY)!))
            {
                
                guard let layerHeight = filterlayer?.barRect?.size.height
                else { continue }
                
                if layerHeight == 0
                {
                    continue
                }
                
                let newTransY = (layerHeight) * percent
                
                if aboveBaseLine
                {
                    BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: newTransY, chart: barChart, duration: animationDuration)
                }
                else{
                    BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: -newTransY, chart: barChart, duration: animationDuration)
                }
                
                
            }
            else{
                let barPath = layer.getPath(rect: layer.barRect!)//UIBezierPath(rect:layer.barRect!)
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                
                if layer.barDataSet?.plotType == .BoxPlot {
                    
                    guard let layerBarRect = layer.barRect,
                          let chartEntry = layer.chartEntry
                    else { continue }
                    let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: layer,rect: layerBarRect, percent: ((layer.barRect?.size.height)! * percent))
                    
                    if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chartView, entry: chartEntry) {
//                        CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: animationDuration)
                        CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath , duration: animationDuration)
                    }
                }
            }
        }
        
    }
    
    /// Stacked Bar(Horizontal) :- Performs Selected Stack Layers Filtering Animation
    public static func callHorizontalGroupFilterAnimation(chartView:ChartViewBase, animationDuration:TimeInterval,percent:CGFloat)
    {
        guard
            let barData = chartView.data,
            let lastSelectedEntries = chartView.lastSelected,
            lastSelectedEntries.count > 0,
            let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0])
            else { return }
        
        let barChart = chartView
        
        let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)
        
        let indexToBarLayer = BarHelperFunctions.getStackIndexToBarLayer(barChart: barChart)
        
        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: barChart, dataSet: (barData.dataSets[0]))
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            guard let layerSet = layer.barDataSet,
                  (layer.chartEntry != nil)
            else { continue }
            let currentDataSetIndex = barData.indexOfDataSet(layerSet)
            
            let aboveBaseLine = (layer.chartEntry?.y)! > baseLineValue
            
            let filterlayer = indexToBarLayer[(layer.chartEntry?.x)!]
            
            if filterlayer == nil || filterlayer?.barRect == nil || layer.barRect == nil || filterlayer?.chartEntry == nil
            {
                continue
            }
            
            let filteredLayerAboveBaseLine = (filterlayer?.chartEntry?.y)! > baseLineValue
            
            if  currentDataSetIndex == lastSelectedDataSetIndex
            {
                guard let layerWidth = layer.barRect?.size.width
                else { continue }
                
                if layerWidth == 0
                {
                    continue
                }
                
                let newTransY =  (layerWidth) * percent
                
                if aboveBaseLine
                {
                    BarHelperFunctions.changeBarXPositionAndWidth(barLayer: layer, changeXValue: 0, changeWidth: -newTransY, chart: chartView, duration: animationDuration)
                }
                else{
                    BarHelperFunctions.changeBarXPositionAndWidth(barLayer: layer, changeXValue: newTransY, changeWidth: -newTransY, chart: chartView, duration: animationDuration)
                }
                
            }
            else if (filteredLayerAboveBaseLine == aboveBaseLine) && ((aboveBaseLine && (layer.barRect?.minX)! > (filterlayer?.barRect?.minX)!) || (!aboveBaseLine && (layer.barRect?.minX)! < (filterlayer?.barRect?.minX)!))
            {
                
                guard let layerWidth = filterlayer?.barRect?.size.width
                else { continue }
                
                if layerWidth == 0
                {
                    continue
                }
                
                let newTransY = (layerWidth) * percent
                
                if aboveBaseLine
                {
                    BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: -newTransY, chart: barChart, duration: animationDuration)
                }
                else{
                     BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: newTransY, chart: barChart, duration: animationDuration)
                }
                
                
            }
            else{
                let barPath = layer.getPath(rect: layer.barRect!)//UIBezierPath(rect:layer.barRect!)
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                
                if layer.barDataSet?.plotType == .BoxPlot && chartView.isRotated {
                    guard let chartEntry = layer.chartEntry
                    else { continue }
                    
                    let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: layer,rect: layer.barRect!, percent: ((layer.barRect?.size.width)! * percent))
                    
                    if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chartView, entry: chartEntry) {
//                        CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: animationDuration)
                        CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: animationDuration)
                    }
                }
            }
        }
        
    }
    
    /// Stacked Percentage Bar :- Performs Resizing Animation With Current Stack Layers
    public static func callGroupFilterEndAnimation(chartView:ChartViewBase, animationDuration:TimeInterval)
    {
        Log.info("Group filter end animation for stacked percentage")
        
        let barChart = chartView
        
        guard
            let barData = barChart.data ,
            let lastSelectedEntries = barChart.lastSelected,
            lastSelectedEntries.count > 0,
            let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0]),
            let processor = barChart.getProcessor(type: .Bar) as? BarPreprocessor
            else { return  }
        
        let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)
        
        let horizontalChart = chartView.isRotated
        
        var posSum:[Double:Double] = [:]
        var deletedStackValue = Double(0)
     
        let dataSet = barData.dataSets[0]
        
        let horizontalBottom = barChart.viewPortHandler.contentLeft
        let verticalBottom = barChart.viewPortHandler.contentBottom
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            guard let stackedEntry = (layer.chartEntry)
            else { continue }
            
            if stackedEntry.x.isNaN || stackedEntry.y.isNaN || layer.barDataSet == nil
            {
                continue
            }
            
            let currentDataSetIndex = barData.indexOfDataSet(layer.barDataSet!)
            
            let entriesAtX = lastSelectedSet.entriesForXValue(stackedEntry.x)
            
            if entriesAtX.count > 0
            {
                deletedStackValue = entriesAtX[0].y
            }
            else {
                continue
            }
            
            guard let posSumAtCurrentX = processor.positiveSum[stackedEntry.x]
                else { continue }
           
            if currentDataSetIndex != lastSelectedDataSetIndex
            {
                let stackPercent = (stackedEntry.y/(posSumAtCurrentX - deletedStackValue))*100
                
                if stackPercent.isNaN
                {
                    continue
                }
                
                if posSum[stackedEntry.x] == nil
                {
                    posSum[stackedEntry.x] = stackPercent
                }
                else{
                    posSum[stackedEntry.x] = posSum[stackedEntry.x]! + stackPercent
                }
                
                if layer.barRect == nil
                {continue}
                
                let stackHeight:CGFloat
                let yPosition:CGFloat
                
                let newPath:CGMutablePath
                
                if horizontalChart
                {
                    stackHeight = (horizontalBottom -  barChart.pixelForValues(x: stackPercent, y: 0, axisIndex: dataSet.axisIndex).x)
                    yPosition = barChart.pixelForValues(x: posSum[stackedEntry.x]!, y: 0, axisIndex: dataSet.axisIndex).x
                    
                    let newRect = CGRect(x: yPosition, y: (layer.barRect?.minY)!, width: stackHeight, height: (layer.barRect?.height)!)
                    
                    newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: yPosition, y: (layer.barRect?.minY)!, width: stackHeight, height: (layer.barRect?.height)!))
                }
                else{
                    stackHeight  = (verticalBottom -  barChart.pixelForValues(x: 0, y: stackPercent, axisIndex: dataSet.axisIndex).y)
                    yPosition = barChart.pixelForValues(x: 0, y: posSum[stackedEntry.x]!, axisIndex: dataSet.axisIndex).y
                    
                    let newRect = CGRect(x: (layer.barRect?.minX)!, y: yPosition, width: (layer.barRect?.width)!, height: stackHeight)
                    
                    newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (layer.barRect?.minX)!, y: yPosition, width: (layer.barRect?.width)!, height: stackHeight))
                }
                
                
                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
            }
        }
        
    }

    /// Bar :- Animates Bar Y position Alone
    public static func changeBarYPosition(barLayer:BarLayer,newYValue:CGFloat,chart:ChartViewBase,duration:TimeInterval)
    {
        guard let barRect = barLayer.barRect
        else { return }
        
        let curY = barRect.origin.y + newYValue
        
        let newRect = CGRect(x: (barRect.origin.x), y: curY, width: barRect.size.width, height: barRect.size.height)
        
        let newPath = barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        if barLayer.barDataSet?.plotType == .BoxPlot {
            
            guard let chartEntry = barLayer.chartEntry
            else { return }
            
            let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: barLayer,rect: newRect, percent: abs(newYValue)/barRect.size.height)
            
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: chartEntry) {
//                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: duration)
                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: duration)
            }
        }
    }
    
    /// Bar :- Animates Bar Y position and Height Synchronously
    public static func changeBarYPositionAndHeight(barLayer:BarLayer,newYValue:CGFloat,chart:ChartViewBase,duration:TimeInterval)
    {
        
        guard let barRect = barLayer.barRect
        else { return }
        
        let curY = barRect.origin.y + newYValue
        
        let newHeight = barRect.size.height - newYValue
        
        let newRect = CGRect(x: (barRect.origin.x), y: curY, width: barRect.size.width, height: newHeight)
        
        let newPath = barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        if barLayer.barDataSet?.plotType == .BoxPlot {
            
            guard let chartEntry = barLayer.chartEntry
            else { return }
            
            let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: barLayer,rect: newRect, percent: abs(newYValue)/barRect.size.height)
            
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: chartEntry) {
//                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: duration)
                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: duration)
            }
        }
    }
    
    
    /// Bar :- Animates Bar Y position and Height to Given Y and Height
    public static func changeBarYPositionAndHeight(barLayer:BarLayer,newYValue:CGFloat,changeHeight:CGFloat,chart:ChartViewBase,duration:TimeInterval)
    {
        
        guard let barRect = barLayer.barRect
        else { return }
        
        let curY = barRect.origin.y + newYValue
        
        let newHeight = barRect.size.height + changeHeight
        
        let newRect = CGRect(x: (barRect.origin.x), y: curY, width: barRect.size.width, height: newHeight)
        
        let newPath = barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        if barLayer.barDataSet?.plotType == .BoxPlot {
            
            let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: barLayer,rect: newRect, percent: abs(changeHeight)/barRect.size.height)
            
            if barLayer.chartEntry == nil
            {
                return
            }
            
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: barLayer.chartEntry!) {
//                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: duration)
                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath:finalPath as! CGMutablePath, duration: duration)
            }
        }
        
    }
    
    /// Bar :- Animates Bar X position Alone
    public static func changeBarXPosition(barLayer:BarLayer,newXValue:CGFloat,chart:ChartViewBase,duration:TimeInterval)
    {
        guard let barRect = barLayer.barRect
        else { return }
        
        let curX = barRect.origin.x + newXValue
        
        let newRect = CGRect(x: curX, y: (barRect.origin.y), width: barRect.size.width, height: barRect.size.height)
        
        let newPath = barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        if barLayer.barDataSet?.plotType == .BoxPlot && chart.isRotated {
            
            guard let chartEntry = barLayer.chartEntry
            else { return }
            
            let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: barLayer,rect: newRect, percent: abs(newXValue)/barRect.size.width)
            
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: chartEntry) {
//                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: duration)
                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: duration)
            }
        }
    }
    
    /// Bar :- Animates Bar X position and Width to Given X and Width
    public static func changeBarXPositionAndWidth(barLayer:BarLayer,changeXValue:CGFloat,changeWidth:CGFloat,chart:ChartViewBase,duration:TimeInterval)
    {
        
        guard let barRect = barLayer.barRect
        else { return }
        
        let curX = barRect.origin.x + changeXValue
        
        let newWidth = barRect.size.width + changeWidth
        
        let newRect = CGRect(x: curX, y: (barRect.origin.y), width: newWidth, height: barRect.size.height)
        
        let newPath = barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        if barLayer.barDataSet?.plotType == .BoxPlot && chart.isRotated {
            
            guard let chartEntry = barLayer.chartEntry
            else { return }
            
            let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: barLayer,rect: newRect, percent: abs(changeWidth)/barRect.size.width)
            
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: chartEntry) {
//                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: duration)
                CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: duration)
            }
        }
        
    }
    
    
    /// Stacked Bar :- returns Dictionary contains Corresponding Stack Layer for Index
    public static func getStackIndexToBarLayer(barChart:ChartViewBase) -> [Double:BarLayer]
    {
        var dictionary:[Double : BarLayer] = [:]
       
        guard let chartData = barChart.data,
            let lastSelectedEntries = barChart.lastSelected,
            lastSelectedEntries.count > 0,
            let lastSelectedSet = chartData.getDataSetForEntry(lastSelectedEntries[0])
            else { return dictionary }
        
        let lastSelectedDataSetIndex = chartData.indexOfDataSet(lastSelectedSet)
  
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            guard let laySet = layer.barDataSet,
                  let layEntry = layer.chartEntry
            else { continue }
            let currentDatasetIndex = chartData.indexOfDataSet(laySet)
            if currentDatasetIndex == lastSelectedDataSetIndex
            {
                dictionary[(layEntry.x)] = layer
            }
        }

        return dictionary
    }
    
    public static func getBarPositiveSum(chartViewBase:ChartViewBase) -> [Double:Double]? {
        guard let processor = CommonHelperFunctions.getProcessor(chart: chartViewBase, types: barAllowedTypes) as? BarPreprocessor
            else { return nil }
        
        return processor.positiveSum
    }
    
    public static func getBarNegativeSum(chartViewBase:ChartViewBase) -> [Double:Double]?{
        guard let processor = CommonHelperFunctions.getProcessor(chart: chartViewBase, types: barAllowedTypes) as? BarPreprocessor
        else { return nil }
        
        return processor.negativeSum
    }
    
    public static func getBarEntryStackedValue(chartViewBase:ChartViewBase) -> [Int:[Int:Double]]? {
        guard let processor = CommonHelperFunctions.getProcessor(chart: chartViewBase, types: barAllowedTypes) as? BarPreprocessor
        else { return nil }
        
        return processor.entriesStackedYValue
    }
    
    static let barAllowedTypes:[ChartType] = [.Bar,.Bullet]
    
      // MARK: - Chart Filter/Drill Methods
        
    public static func removeEntry(barEntry:ChartDataEntry,defaultAnimation:Bool, chart:ChartViewBase)
    {
        guard let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar,.WaterFall,.BoxPlot,.Mekko]) as? BarPlotOptions,
              let chartData = chart.data
            else { return }
        
        chart.updateDataOrigIndex()
        
        var removeEntries:[ChartDataEntry] = []
        for set in chartData.dataSets
        {
            for entry in (set as! ChartDataSet).values where barEntry.origX != nil && entry.origX != nil && round(barEntry.origX!) == round(entry.origX!){
           
               removeEntries.append(entry)
           }
        }
        
        if defaultAnimation
        {
            //Stacked Bar
            if self.isStacked(chart: chart)
            {
                if chart.xGroupSelected || plotOptions.barGroupSelectionEnabled
                {
                    let executionBlock = {
//                        self.removeStackedBarEntry(barEntry: barEntry, barChart: chart)
//                        ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: barEntry, chart: chart, duration: 0.5)
                          ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: chart, duration: 0.5)
                    }
                    
                    CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:barEntry.x,y: barEntry.y, duration: 0.5, executionBlock: executionBlock, alignCenter: true, chart: chart)
                    
                }
                else{
                    
                    guard let set = (chart.data?.getDataSetForEntry(barEntry))
                    else { return }
                    chart.lastSelected = nil
//                    CommonHelperFunctions.hideDataSet(selectedDataset: [set], chart: chart)
                    
                    ChartInteractionHelperFunction.hideDataSetWithAnimation(barChart: chart, selectedDataset: [set], animationOptions: .StackedBaralign,animationDuration: 0.3)
                }
            }
            // Multi Bar
            else if (chartData.dataSetCount) > 1
            {
                ///  self.barGroupSelectionEnabled should be added  LATER
                
                /*
                if plotOptions.barGroupSelectionEnabled
                {
                    let executionBlock = {
                          ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: chart, duration: 0.5)
                    }
                    
                    CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:barEntry.x,y: barEntry.y, duration: 0.5, executionBlock: executionBlock, alignCenter: true, chart: chart)
                    
                }
                else {
                let set = chart.data?.getDataSetForEntry(barEntry)
                
                ChartInteractionHelperFunction.hideDataSetWithAnimation(barChart: chart, selectedDataset: [set!], animationOptions: .align,animationDuration: 0.3)
                }*/
                
                guard let set = chart.data?.getDataSetForEntry(barEntry)
                else { return }
//                alignMultiBar(selectedDataset: set!, chart: chart)
                
                ChartInteractionHelperFunction.hideDataSetWithAnimation(barChart: chart, selectedDataset: [set], animationOptions: .align,animationDuration: 0.3)
                
            }
            // Single Bar
            else{
                let executionBlock = {
//                    self.alignBar(barEntry:barEntry)
//                    ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: barEntry, chart: chart, duration: 0.5)
//                    removeStackedBarEntry(barEntry: barEntry, barChart: chart)
                   
                    ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: chart, duration: 0.5)
                }
                
                CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:barEntry.x,y:barEntry.y,duration: 0.5, executionBlock: executionBlock, alignCenter: true, chart: chart)
            }
            
        }
    }
    
    public static func removeStackedBarEntry(barEntry:ChartDataEntry, barChart:ChartViewBase)
    {
        let completionBlock:(() -> Void)? =
        {
            let typeAllowed = [ChartType.Bar]
            guard let barData = barChart.data,
                let plotOptions = CommonHelperFunctions.getPlotOption(chart: barChart, types: typeAllowed) as? BarPlotOptions,
                let processor = barChart.getProcessor(type: .Bar) as? BarPreprocessor,
                let barRenderer = (CommonHelperFunctions.getRenderer(chart: barChart, types: typeAllowed) as? BarChartRenderer)
                else { return }
            
            barChart.lastSelected = nil
            plotOptions.barGroupSelectionEnabled = false
            
            let xToRemove =  barEntry.x
            
            var oldEntries:[[ChartDataEntry]] = []
            var newEntries:[[ChartDataEntry]] = []
            
            for set in barData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i)
                        else { return }
                    
                    if entry.x == xToRemove
                    {
                        entry.filterEnabled = true
                    }
                    
                    setEntries.append(entry)
                }
                oldEntries.append(setEntries)
            }
            
            
            
            for set in barData.dataSets
            {
                var setEntries:[ChartDataEntry] = []
                for i in 0..<(set.entryCount)
                {
                    guard let entry = set.entryForIndex(i),
                    let finalEntry = entry.copy() as? ChartDataEntry
                        else { return }
                    
                    if (finalEntry.x == Double.leastNormalMagnitude && finalEntry.origX == barEntry.origX) || finalEntry.x == xToRemove
                    {
                        continue
                    }
                    if finalEntry.x != Double.leastNormalMagnitude && finalEntry.x > xToRemove
                    {
                        finalEntry.x = Double(finalEntry.x-1)
                    }
                    
                    
                    setEntries.append(finalEntry)
                }
                newEntries.append(setEntries)
            }
            
            let oldBarPositionArray:[[CGRect]] = ChartInteractionHelperFunction.prepareBarRectArrayforAllDataset(barChart: barChart)
            
            // reset with newEntries
            CommonHelperFunctions.resetData(newEntries: newEntries, chart: barChart)
            
            let newBarPositionArray:[[CGRect]] = ChartInteractionHelperFunction.prepareBarRectArrayforAllDataset(barChart: barChart)
            
            // reset back with oldEntries
            CommonHelperFunctions.resetData(newEntries: oldEntries, chart: barChart)
            
            var xyInterpolateArray:[[((Double) -> Double)]] = []
            
            var sizeInterpolateArray:[[((Double) -> Double)]] = []
            
            for dataSetIndex in 0..<barData.dataSetCount
            {
                guard let set = barData.dataSets[dataSetIndex] as? ChartDataSet
                    else{ return }
                
                if !(set.isVisible)
                {
                    xyInterpolateArray.append([((Double) -> Double)]())
                    sizeInterpolateArray.append([((Double) -> Double)]())
                    continue
                }
                
                var setEntriesXYInterpolator:[((Double) -> Double)] = []
                
                var setEntriesSizeInterpolator:[((Double) -> Double)] = []
                
                var entryIndex = -1
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    guard let entry =  set.entryForIndex(index)
                    else { continue }
                    
                    if entry.x == xToRemove
                    {
                        continue
                    }
                    
                    entryIndex += 1
                    
                    var oldValue = CGFloat(0)
                    var oldSize = CGFloat(0)
                    
                    var newValue = CGFloat(0)
                    var newSize = CGFloat(0)
                    
                    guard let oldDatasetRect = oldBarPositionArray[safe:dataSetIndex],
                        let oldEntryRect = oldDatasetRect[safe:index],
                        let newDatasetRect = newBarPositionArray[safe:dataSetIndex],
                        let newEntryRect = newDatasetRect[safe:entryIndex]
                        else { continue }
                    
                    if barChart.isRotated
                    {
                        oldValue = oldEntryRect.origin.y
                        oldSize = oldEntryRect.size.height
                        
                        newValue = newEntryRect.origin.y
                        newSize = newEntryRect.size.height
                    }
                    else{
                        oldValue = oldEntryRect.origin.x
                        oldSize = oldEntryRect.size.width
                        
                        newValue = newEntryRect.origin.x
                        newSize = newEntryRect.size.width
                    }
                    
                    
                    let radiusDiff = Interpolator.interpolate(a: Double(oldValue), b: (Double(newValue)))
                    let widthDiff = Interpolator.interpolate(a: Double(oldSize), b: (Double(newSize)))
                    
                    setEntriesXYInterpolator.append(radiusDiff)
                    
                    setEntriesSizeInterpolator.append(widthDiff)
                }
                xyInterpolateArray.append(setEntriesXYInterpolator)
                sizeInterpolateArray.append(setEntriesSizeInterpolator)
            }
            
            var sliceAnimator:Animator! = Animator()
            
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                barRenderer.barDeleted = true
                
                barChart.interactionAnimationInProgress = true
                
                var interpolatorIndex:Int = 0
                
                for dataSetIndex in 0..<barData.dataSetCount
                {
                    guard let set = barData.dataSets[dataSetIndex] as? ChartDataSet
                        else { continue }
                    
                    if !(set.isVisible)
                    {
                        continue
                    }
                    
                    interpolatorIndex = 0
                    
                    for index in stride(from: 0, to: set.entryCount, by: 1)
                    {
                        guard let entry = set.entryForIndex(index)
                        else { continue }
                        
                        if entry.x == xToRemove
                        {
                            continue
                        }
                        guard let oldDataset = oldEntries[safe:dataSetIndex],
                            let oldDatasetEntry = oldDataset[safe:index],
                            let oldDatasetRect = oldBarPositionArray[safe:dataSetIndex],
                            let oldDatasetEntryRect = oldDatasetRect[safe:index],
                            let valInterpolator = xyInterpolateArray[safe:dataSetIndex],
                            let valInterpolatorfn = valInterpolator[safe:interpolatorIndex],
                            let widthInterpolator = sizeInterpolateArray[safe:dataSetIndex],
                            let widthInterpolatorfn = widthInterpolator[safe:interpolatorIndex]
                            else { return }
                        
                        let newEntry = oldDatasetEntry
                        
                        let oldRect = oldDatasetEntryRect
                        
                        var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                        
                        var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                        
                        let newVal = valInterpolatorfn(sliceAnimator.phaseX)
                        let newWidth = widthInterpolatorfn(sliceAnimator.phaseX)
                        interpolatorIndex = interpolatorIndex + 1
                        
                        if barChart.isRotated
                        {
                            newCenter.y = CGFloat(newVal)
                            newSize.height = CGFloat(newWidth)
                        }
                        else{
                            newCenter.x = CGFloat(newVal)
                            newSize.width = CGFloat(newWidth)
                        }
                        
                        
                        newEntry.centerChanged = newCenter
                        
                        newEntry.sizeChanged = newSize
                    }
                }
                barChart.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                barRenderer.barDeleted = false
                
                sliceAnimator = nil
                
//                barChart.enableDrawValues()
                barChart.interactionAnimationInProgress = false
                
                barChart.setNeedsDisplay()
                
                var removedEntries:[ChartDataEntry] = []
                
                /*for set in barData.dataSets
                {
                    for entryToRemove in (set.entriesForXValue(xToRemove))
                    {
                        removedEntries.append(entryToRemove)
                    }
                }*/
                
                for set in barData.dataSets
                {
                    for entryToRemove in  (set as! ChartDataSet).values where entryToRemove.origX == barEntry.origX
                    {
                        removedEntries.append(entryToRemove)
                    }
                }
                
                ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: barChart, newEntries: newEntries)
                 
                ChartInteractionHelperFunction.callResizeAxis(axisChartBase: barChart)
                
               /* CommonHelperFunctions.resetData(newEntries: newEntries, chart: barChart)
                
//                barChart.resizeAxisIfNeeded()
                
                barData.updateXYValues()
                
                for set in barData.dataSets
                {
                    set.calcMinMax()
                }
                
                barData.notifyDataChanged()
                
                processor.calcPosNegSum()
                
                //Should be called before calling chart.notifyDataSetChanged()
                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: barChart)
                
                barChart.notifyDataSetChanged(redrawRequired: true)*/
                
                CommonHelperFunctions.enableIncludeLayer(chart: barChart)
                
                barChart.lastSelected = nil
                plotOptions.barGroupSelectionEnabled = false
                
                barChart.callDelegateToContainer(highlight: nil, entry: nil)
                
                barChart.delegateToContainer?.chartValueRemoved?(barChart, entries: removedEntries, dataSets: nil, dataSetRemoved: false , showTrackerView: true)
                
            }
            
            sliceAnimator.animate(xAxisDuration: 0.5, easingOption: .linear)
            
        }
        
        completionBlock!()
    }
    
    /*open func alignBar(barEntry:ChartDataEntry)
    {
        let completionBlock:(() -> Void)? =
        {
            guard let data = self.data,
                let barDataset = data.dataSets[0] as? ChartDataSet,
                let barChart = self as? BarChartView,
                let barAnimator = self._animator,
                let barRenderer = (barChart.renderer as? BarChartRenderer)
                else { return }
            
            barChart.lastSelected = nil
            
            barEntry.filterEnabled = true
            //            self.includeLayer = false
            
            let deletedIndex = barDataset.entryIndex(entry: barEntry)
            
            var oldEntries:[ChartDataEntry] = []
            var newEntries:[ChartDataEntry] = []
            
            for i in 0 ..< (barDataset.entryCount)
            {
                guard let oldEntry = barDataset.entryForIndex(i) as? ChartDataEntry
                    else { continue }
                oldEntries.append(oldEntry)
            }
            
            
            for i in 0 ..< (barDataset.entryCount)
            {
                guard let newEntry = barDataset.entryForIndex(i) as? ChartDataEntry,
                    let finalEntry = newEntry.copy() as? ChartDataEntry
                else { return }
                
                if i == deletedIndex
                {
                    continue
                }
                
                if i > deletedIndex
                {
                    finalEntry.x = Double(newEntry.x-1)
                }
                
                
                newEntries.append(finalEntry)
            }
            
            
            var oldBarPositionArray:[CGRect]
            
            var newBarPositionArray:[CGRect]
            
            if self.isKind(of: HorizontalBarChartView.self)
            {
                oldBarPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: oldEntries, animator: barAnimator, dataSet: barDataset, dataProvider: barChart, chart: self)
                
            }
            else{
                oldBarPositionArray = BarChartRenderer.getBarRectArray(entries: oldEntries, animator: barAnimator, dataSet: barDataset, dataProvider: barChart, chart: self)
                
            }
            
            // reset dataset with newEntries
            self.resetDatasetEntries(dataset: barDataset, entries: newEntries)
            
            if self.isKind(of: HorizontalBarChartView.self)
            {
                newBarPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: newEntries, animator: barAnimator, dataSet: barDataset, dataProvider: barChart, chart: self)
            }
            else{
                
                newBarPositionArray = BarChartRenderer.getBarRectArray(entries: newEntries, animator: barAnimator, dataSet: barDataset, dataProvider: barChart, chart: self)
            }
            
            
            // reset back with oldEntries
            self.resetDatasetEntries(dataset: barDataset, entries: oldEntries)
            
            var interpolateArray:[((Double) -> Double)] = []
            var widthInterpolateArray:[((Double) -> Double)] = []
            
            for index in stride(from: 0, to: oldEntries.count, by: 1)
            {
                if index == deletedIndex
                {
                    continue
                }
                
                var oldVal:CGFloat
                let newVal:CGFloat
                
                var oldWidth:CGFloat = 0
                var newWidth:CGFloat = 0
                
                guard index >= 0 && index < oldBarPositionArray.count && (index - 1) < newBarPositionArray.count
                    else { return }
                
                if self.isKind(of: HorizontalBarChartView.self)
                {
                    oldVal = oldBarPositionArray[index].origin.y
                    oldWidth = oldBarPositionArray[index].size.height
                    
                    if index < deletedIndex{
                        
                        guard index < newBarPositionArray.count
                            else { return }
                        
                        newVal = newBarPositionArray[index].origin.y
                        newWidth = newBarPositionArray[index].size.height
                    }
                    else{
                        newVal = newBarPositionArray[index-1].origin.y
                        newWidth = newBarPositionArray[index-1].size.height
                    }
                }
                else
                {
                    oldVal = oldBarPositionArray[index].origin.x
                    oldWidth = oldBarPositionArray[index].size.width
                    
                    if index < deletedIndex{
                        
                        guard index < newBarPositionArray.count
                            else { return }
                        
                        newVal = newBarPositionArray[index].origin.x
                        newWidth = newBarPositionArray[index].size.width
                    }
                    else{
                        newVal = newBarPositionArray[index-1].origin.x
                        newWidth = newBarPositionArray[index-1].size.width
                    }
                    
                    
                }
                let radiusDiff = Interpolator.interpolate(a: Double(oldVal), b: (Double(newVal)))
                
                let widthDiff = Interpolator.interpolate(a: Double(oldWidth), b: (Double(newWidth)))
                
                interpolateArray.append(radiusDiff)
                
                widthInterpolateArray.append(widthDiff)
            }
            
            var sliceAnimator:Animator! = Animator()
            
            if sliceAnimator != nil
            {
                sliceAnimator.stop()
            }
            
            sliceAnimator = Animator()
            
            sliceAnimator.updateBlock = {
                
                barRenderer.barDeleted = true
                
                data.setDrawValues(false)
                
                var interpolatorIndex:Int = 0
                
                for index in stride(from: 0, to: oldBarPositionArray.count, by: 1)
                {
                    if index == deletedIndex
                    {
                        continue
                    }
                    guard let newEntry = oldEntries[safe:index],
                        let valInterpolator = interpolateArray[safe:interpolatorIndex],
                        let widthInterpolator = widthInterpolateArray[safe:interpolatorIndex]
                        else { return }
                    
                    let oldRect = oldBarPositionArray[index]
                    
                    var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                    
                    var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                    
                    
                    let newVal = valInterpolator(sliceAnimator.phaseX)
                    
                    let newWidth = widthInterpolator(sliceAnimator.phaseX)
                    
                    interpolatorIndex = interpolatorIndex + 1
                    
                    if self.isKind(of: HorizontalBarChartView.self)
                    {
                        newCenter.y = CGFloat(newVal)
                        
                        newSize.height = CGFloat(newWidth)
                    }
                    else{
                        newCenter.x = CGFloat(newVal)
                        
                        newSize.width = CGFloat(newWidth)
                    }
                    
                    newEntry.centerChanged = newCenter
                    
                    newEntry.sizeChanged = newSize
                }
                
                self.setNeedsDisplay()
                
            }
            
            sliceAnimator.stopBlock = {
                
                barRenderer.barDeleted = false
                
                sliceAnimator = nil
                
                self.enableDrawValues()
                
                self.setNeedsDisplay()
                
                /*************************** NEED TO REVISIT THE FOLLOWING SNIPPET ****************************/
                
                /*  let set1:ChartDataSet = ChartDataSet(values: newEntries, label: "Set1")
                 set1.colors = [ChartColorTemplates.pieColor()[6]]
                 
                 data.dataSets[0] = set1
                 
                 self.data = data */
                
                barDataset.clear()
                
                for newEntry in newEntries
                {
                    _ = barDataset.addEntry(newEntry)
                }
                
                data.updateXYValues()
                
                barDataset.calcMinMax()
                
                data.notifyDataChanged()
                
                //Should be called before calling chart.notifyDataSetChanged()
                self.resizeAxisIfNeeded()
                
                self.notifyDataSetChanged()
                
                self.enableIncludeLayer()
                
                var removedEntries:[ChartDataEntry] = []
                removedEntries.append(barEntry)
                
                self.interactionAnimationInProgress = false
                
                self.delegateToContainer?.chartValueRemoved?(self, entry: removedEntries, index: deletedIndex, dataSetRemoved: false , showTrackerView: true)
                
                self.chartActionListener?.chartValueRemoved?(chartView: self, entry: removedEntries, index: deletedIndex, dataSetRemoved: false)
            }
            
            sliceAnimator.animate(xAxisDuration: 0.5, easingOption: .linear)
            
        }
        
        completionBlock!()
        
    }*/
    
    public static func alignMultiBar(selectedDataset: IChartDataSet, chart:ChartViewBase)
    {
        guard let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Bar]) as? BarChartRenderer
            else { return }
        
        for i in 0..<(selectedDataset.entryCount)
        {
            let entry = selectedDataset.entryForIndex(i)
            entry?.filterEnabled = true
        }
        
        let oldDataSetArray = self.prepareDataSetArrayforMultiBar(selectedDataset: selectedDataset, chart: chart)
        
        
        selectedDataset.visible = false
        
        chart.data?.updateXYValues()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        
        let newDataSetArray = prepareDataSetArrayforMultiBar(selectedDataset: selectedDataset, chart: chart)
        
        
        selectedDataset.visible = true
        
        chart.data?.updateXYValues()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        // Interpolater Array
        
        let (barInterpolateArray,widthInterpolateArray) = self.prepareBarXandBarWidthInterpolatorforMultiBar(selectedDataset: selectedDataset, oldDataSetArray: oldDataSetArray, newDataSetArray: newDataSetArray, chart: chart)
        
        
        // Animation
        
        let endBlock = {
            
            renderer.barDeleted = false
            
//            chart.enableDrawValues()
            chart.interactionAnimationInProgress = false
            
            for i in 0..<(selectedDataset.entryCount)
            {
                let entry = selectedDataset.entryForIndex(i)
                entry?.filterEnabled = false
            }
            
            CommonHelperFunctions.hideDataSet(selectedDataset: [selectedDataset], chart: chart)
        }
        
        self.performBarXandBarWidthAnimationforMultiBar(selectedDataset: selectedDataset, barInterpolateArray: barInterpolateArray, widthInterpolateArray: widthInterpolateArray, oldDataSetArray: oldDataSetArray, stopBlock: endBlock, chart: chart)
        
        
    }
    
    public static func drillEntry(barEntry:ChartDataEntry, chart: ChartViewBase)
    {
        guard let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar]) as? BarPlotOptions
            else { return }
        
        chart.curLevel = chart.curLevel + 1
        
        chart.delegateToContainer?.chartValueDrillPerformed?(chart, entry: barEntry, level: chart.curLevel)
        
        /*//Stacked Bar
        if isStacked(chart: chart)
        {
            if plotOptions.barGroupSelectionEnabled
            {
                guard let set = chart.data?.getDataSetForEntry(barEntry)
                    else { return }
                
                let index = set.entryIndex(entry: barEntry)
                chart.delegateToContainer?.chartValueDrillPerformed!(chart, entry: barEntry, level: chart.curLevel)
                chart.chartActionListener?.drillPerformed!(chartView: chart, selectedEntry: barEntry,index:index )
            }
            else{
                guard let set = chart.data?.getDataSetForEntry(barEntry)
                    else { return }
                
                let index = (chart.data?.indexOfDataSet(set))!
                chart.delegateToContainer?.chartValueDrillPerformed!(chart, entry: barEntry, level: chart.curLevel)
                chart.chartActionListener?.drillPerformed!(chartView: chart, selectedEntry: barEntry,index: index)
            }
        }
            // Multi Bar
        else if (chart.data?.dataSetCount)! > 1
        {
            if plotOptions.barGroupSelectionEnabled
            {
                
            }
            else{
                let set = chart.data?.getDataSetForEntry(barEntry)
                let index = chart.data?.indexOfDataSet(set!)
                chart.delegateToContainer?.chartValueDrillPerformed!(chart, entry: barEntry, level: chart.curLevel)
                chart.chartActionListener?.drillPerformed!(chartView: chart, selectedEntry: barEntry,index: index!)
            }
        }
            // Single Bar
        else{
            
            let index = chart.data?.dataSets[0].entryIndex(entry: barEntry)
            
            chart.delegateToContainer?.chartValueDrillPerformed!(chart, entry: barEntry, level: chart.curLevel)
            chart.chartActionListener?.drillPerformed!(chartView: chart, selectedEntry: barEntry,index: index!)
        }*/
        
    }
    
    
    
    public static func includeMultiBar(selectedDataset:IChartDataSet, chart: ChartViewBase)
    {
        var yInterpolator:[((Double) -> Double)] = []
        
        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: selectedDataset)
        
       /* for i in 0..<(selectedDataset.entryCount)
        {
            let entry = selectedDataset.entryForIndex(i)
            
            yInterpolator.append(Interpolator.interpolate(a: baseLineValue, b: (entry?.y)!))
            
            entry?.y = baseLineValue
        }*/
        
        let barChart = chart
//        let data = (self.data as! ChartData)
        guard
            let processor = barChart.getProcessor(type: .Bar) as? BarPreprocessor,
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: barChart, types: [.Bar, .WaterFall]) as? BarPlotOptions
            else { return }
        
        
        selectedDataset.visible = true
        
        chart.data?.updateXYValues()
        
        processor.groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace, xInverted: chart.xAxis.isInverted)
        
        chart.includeLayer = true
        
        chart.data?.notifyDataChanged()
        
        for i in 0..<(selectedDataset.entryCount)
        {
            guard let entry = selectedDataset.entryForIndex(i)
            else { continue }
              
            yInterpolator.append(Interpolator.interpolate(a: baseLineValue, b: (entry.y)))
              
            entry.y = baseLineValue
        }
        
        //===================================================================//
        
        //        //To avoid flickering, while including bar at the end
        //        if self.leftAxis.resizeEnabled {
        //            self.leftAxis._customAxisMin = true
        //        }
        //
        //        if self.rightAxis.resizeEnabled {
        //            self.rightAxis._customAxisMin = true
        //        }
        //===================================================================//
        
//        self.notifyDataSetChanged() //Commented and called calculateCurrentData() and changed the entry,y value to baseline value for multi axis bar chart issue
//        chart.notifyDataSetChanged(redrawRequired: false)
        ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: barChart)
        //===================================================================//
        
        //To avoid flickering, while including bar at the end
        //        if self.leftAxis.resizeEnabled {
        //            self.leftAxis.resetCustomAxisMin()
        //        }
        //
        //        if self.rightAxis.resizeEnabled {
        //            self.rightAxis.resetCustomAxisMin()
        //        }
        //===================================================================//
        
        
        let barEntryAnimator = Animator()
        
        barEntryAnimator.updateBlock = {
            
            for i in 0..<(selectedDataset.entryCount)
            {
                let entry = selectedDataset.entryForIndex(i)
                
                entry?.y = yInterpolator[i](barEntryAnimator.phaseX)
            }
            
            processor.updateEntriesStackValue()
            
            chart.setNeedsDisplay()
        }
        
        guard let firstE = selectedDataset.entryForIndex(0)
        else { return }
        var entryToAdd:[ChartDataEntry] = []
        entryToAdd.append(firstE)
        
        barEntryAnimator.stopBlock = {
            
            // Since y value changed, needs recalculation
           /* selectedDataset.notifyDataSetChanged()
            
            chart.data?.updateXYValues()

            processor.groupBars(fromX: 0, groupSpace: barPlotOptions.groupSpace, barSpace: barPlotOptions.barSpace, xInverted: chart.xAxis.isInverted)

            _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
            
            chart.chartActionListener?.chartValueAdded?(chartView: chart, entry: entryToAdd , index: (chart.data?.indexOfDataSet(selectedDataset))!, dataSetAdded: true)
            
            chart.interactionAnimationInProgress = false*/
            
            CommonHelperFunctions.includeDataset(selectedDataset: [selectedDataset], chart: chart)
        }
        
        
        barEntryAnimator.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        
    }
    
        
    public static func chartEntryEnabled(entry: [ChartDataEntry]?,duration:TimeInterval, chart:ChartViewBase) {
        
        guard let entry = entry,
            let chartData = chart.data,
            let plotOption = chart.getPlotOptions() as? AxisChartPlotOptions
            else {  return  }
        
        var chartEntry = entry[0]
        
        // Entry with No Nan in X
        for entryWithoutNan in entry where !(entryWithoutNan.x.isNaN) && (entryWithoutNan.x != Double.leastNormalMagnitude)
        {
            chartEntry = entryWithoutNan
            break
        }
        
        let setIndex = ChartInteractionHelperFunction.getSetIndex(axisChartBase: chart,chartEntry: chartEntry)
        
        let set = chartData.dataSets[setIndex]
        
        var newXPosition = ChartInteractionHelperFunction.getNewXPositionToInsertForEntry(axisChartBase: chart,chartEntry:chartEntry,dataset:set)
        
        //After sorting, entry index is based on entry Y value
        if plotOption.sortInteractionCalled
        {
            newXPosition = getNewIndexInCaseOfSortedEntries(entry: chartEntry, chart: chart)
        }
        
        guard  newXPosition != -1 else {
            return
        }
 
        for dataEntry in entry
        {
            dataEntry.filterEnabled = false
            dataEntry.x = Double(newXPosition)
        }
        
        let executionBlock:(() -> Void)? = {
            self.includeStackedBar(barEntries: entry , newXPosition: newXPosition, duration: duration, chart: chart)
        }
        
       /* var diff:Double = 0
        
        if (chart.xAxis.inverted) {
            diff = 1
        }*/
        
        CommonHelperFunctions.scrollViewToXAndExecuteBlock(x:newXPosition, y:chartEntry.y, duration:0.5, executionBlock: executionBlock, alignCenter: true, chart: chart) //(chartEntry.origX! - diff)
        
    }
    
    
    public static func getNewIndexInCaseOfSortedEntries(entry:ChartDataEntry, chart:ChartViewBase) -> Double
    {
        guard let plotOptions = chart.getPlotOptions() as? AxisChartPlotOptions,
              let chartData = chart.data
            else { return -1 }
        
        var finalIndex:Double = -1
        
        guard let entryCount = (chart.data?.dataSets[0].entryCount)
        else { return -1 }
        
        for i in 0 ..< entryCount
        {
            guard let currentEntry = chart.data?.dataSets[0].entryForIndex(i)
                else { continue }
            
            if plotOptions.sortAscendingEnabled
            {
                if entry.y <= (currentEntry.y)
                {
                    finalIndex = currentEntry.x
                    break
                }
            }
            else
            {
                if entry.y >= (currentEntry.y)
                {
                    finalIndex = currentEntry.x
                    break
                }
            }
        }
        
        if finalIndex == -1
        {
            finalIndex = (chartData.dataSets[0].xMax) + 1
        }
        
        return finalIndex
        
    }
    
    /*func includeBar(barEntry:ChartDataEntry, newIndex:Int,duration:TimeInterval)
    {
        
       // self.includeLayer = false
        
        //        self.setNeedsDisplay()
        
        guard let data = self.data as? ChartData,
            let barDataSet = data.dataSets[0] as? ChartDataSet,
            let barRenderer = (self.renderer as? BarChartRenderer),
            let barAnimator = self._animator
            else { return }
        
        let dataEntryCount = barDataSet.entryCount
        
        var oldEntries:[ChartDataEntry] = []
        var newEntries:[ChartDataEntry] = []
        
        for i in 0 ..< dataEntryCount
        {
            guard let oldEntry = barDataSet.entryForIndex(i) as? ChartDataEntry
                else { continue }
            oldEntries.append(oldEntry)
        }
        
        var flag = Double(0)
        
        for i in 0 ..< dataEntryCount
        {
            if i == newIndex
            {
                guard var tempEntry = barDataSet.entryForIndex(i) as? ChartDataEntry
                    else{ continue }
                
                if tempEntry.x.isNaN
                {
                    let indexPosition = barDataSet.getClosestEntryandIndex(currentIndex: i, closestToIndex: i, closestToX: nil)
                    
                    guard indexPosition != -1,
                        let entryAtIndexPosition = barDataSet.entryForIndex(indexPosition) as? ChartDataEntry
                        else { continue }
                    
                    tempEntry = entryAtIndexPosition
                    
                    if indexPosition < i{
                        barEntry.x = tempEntry.x + 1
                    }
                    else{
                        barEntry.x = tempEntry.x
                    }
                }
                else{
                    barEntry.x = tempEntry.x
                }
                
                newEntries.append(barEntry)
                flag = 1
            }
            
            guard let newEntry = barDataSet.entryForIndex(i) as? ChartDataEntry,
            let finalEntry = newEntry.copy() as? ChartDataEntry
            else { continue }
            
            finalEntry.x = Double(newEntry.x+flag)
            
            newEntries.append(finalEntry)
        }
        
        if flag == 0
        {
            guard var tempEntry = barDataSet.entryForIndex(dataEntryCount-1) as? ChartDataEntry
                else { return }
            
            if tempEntry.x.isNaN
            {
                let indexPosition = barDataSet.getClosestEntryandIndex(currentIndex: dataEntryCount-1, closestToIndex: dataEntryCount-1, closestToX: nil)
                
                guard indexPosition != -1,
                let entryAtIndexPosition = barDataSet.entryForIndex(indexPosition) as? ChartDataEntry
                    else { return }
                
                tempEntry = entryAtIndexPosition
            }
            barEntry.x = tempEntry.x + 1
            newEntries.append(barEntry)
        }
        
        
        let barChart = self
        
        var oldBarPositionArray:[CGRect]
        
        var newBarPositionArray:[CGRect]
        
        if self.isKind(of: HorizontalBarChartView.self)
        {
            oldBarPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: oldEntries, animator: barAnimator, dataSet: barDataSet, dataProvider: barChart, chart: self)
            
        }
        else{
            oldBarPositionArray = BarChartRenderer.getBarRectArray(entries: oldEntries, animator: barAnimator, dataSet: barDataSet, dataProvider: barChart, chart: self)
            
        }
        // reset dataset with newEntries
        self.resetDatasetEntries(dataset: barDataSet, entries: newEntries)
        
        if self.isKind(of: HorizontalBarChartView.self)
        {
            newBarPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: newEntries, animator: barAnimator, dataSet: barDataSet, dataProvider: barChart, chart: self)
        }
        else{
            
            newBarPositionArray = BarChartRenderer.getBarRectArray(entries: newEntries, animator: barAnimator, dataSet: barDataSet, dataProvider: barChart, chart: self)
        }
        
        // reset dataset back with oldEntries
        self.resetDatasetEntries(dataset: barDataSet, entries: oldEntries)
        
        var interpolateArray:[((Double) -> Double)] = []
        
        var widthInterpolateArray:[((Double) -> Double)] = []
        
        for index in stride(from: 0, to: oldEntries.count, by: 1)
        {
            var oldVal:CGFloat
            let newVal:CGFloat
            
            var oldWidth:CGFloat = 0
            var newWidth:CGFloat = 0
            
            guard index >= 0 && index < oldBarPositionArray.count && index < newBarPositionArray.count
                else { return }
            
            if self.isKind(of: HorizontalBarChartView.self)
            {
                oldVal = oldBarPositionArray[index].origin.y
                oldWidth = oldBarPositionArray[index].size.height
                
                if index < newIndex{
                    newVal = newBarPositionArray[index].origin.y
                    newWidth = newBarPositionArray[index].size.height
                }
                else{
                    guard (index + 1) < newBarPositionArray.count
                        else { return }
                    
                    newVal = newBarPositionArray[index+1].origin.y
                    newWidth = newBarPositionArray[index+1].size.height
                }
            }
            else
            {
                oldVal = oldBarPositionArray[index].origin.x
                oldWidth = oldBarPositionArray[index].size.width
                
                if index < newIndex{
                    newVal = newBarPositionArray[index].origin.x
                    newWidth = newBarPositionArray[index].size.width
                }
                else{
                    guard (index + 1) < newBarPositionArray.count
                        else { return }
                    
                    newVal = newBarPositionArray[index+1].origin.x
                    newWidth = newBarPositionArray[index+1].size.width
                }
                
                
            }
            
        
            let radiusDiff = Interpolator.interpolate(a: Double(oldVal), b: (Double(newVal)))
        
            let widthDiff = Interpolator.interpolate(a: Double(oldWidth), b: (Double(newWidth)))
            
            interpolateArray.append(radiusDiff)
            
            widthInterpolateArray.append(widthDiff)
        }
        
        var sliceAnimator:Animator! = Animator()
        
        if sliceAnimator != nil
        {
            sliceAnimator.stop()
        }
        
        sliceAnimator = Animator()
        
        sliceAnimator.updateBlock = {
            
            barRenderer.barDeleted = true
            
            data.setDrawValues(false)
            
            var interpolatorIndex:Int = 0
            
            for index in stride(from: 0, to: oldBarPositionArray.count, by: 1)
            {
                guard let newEntry = oldEntries[safe:index],
                    let valueInterpolator = interpolateArray[safe:interpolatorIndex],
                    let widthInterpolator = widthInterpolateArray[safe:interpolatorIndex]
                    else { continue }
                
                let oldRect = oldBarPositionArray[index]
                
                var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                
                var newSize = CGSize(width: oldRect.width, height: oldRect.height)

                    let newVal = valueInterpolator(sliceAnimator.phaseX)
                
                    let newWidth = widthInterpolator(sliceAnimator.phaseX)
                
                    interpolatorIndex = interpolatorIndex + 1
                
                    if self.isKind(of: HorizontalBarChartView.self)
                    {
                        newCenter.y = CGFloat(newVal)
                        
                        newSize.height = CGFloat(newWidth)
                    }
                    else{
                        newCenter.x = CGFloat(newVal)
                        
                        newSize.width = CGFloat(newWidth)
                    }
                
                    newEntry.centerChanged = newCenter
                
                    newEntry.sizeChanged = newSize
            }
            
            self.setNeedsDisplay()
            
        }
        
        sliceAnimator.stopBlock = {
          
            guard let barEntryToUpdate = newEntries[safe:newIndex]
                else { return }
            
            barEntryToUpdate.isIncluded = true
            
            let baseLineValue = self.getBaseLineValue(dataSet: barDataSet)
            
            let aboveBaseLine = barEntryToUpdate.y > baseLineValue
            
            barRenderer.barDeleted = false
            
            barDataSet.clear()
            
            for newEntry in newEntries
            {
                _ = barDataSet.addEntry(newEntry)
            }
            
            self.data?.updateXYValues()

            barDataSet.notifyDataSetChanged()
            
            data.notifyDataChanged()
            
            //===================================================================//
            
            //To avoid flickering, while including bar at the end
//            if self.leftAxis.resizeEnabled {
//                self.leftAxis._customAxisMin = true
//            }
//
//            if self.rightAxis.resizeEnabled {
//                self.rightAxis._customAxisMin = true
//            }
            //===================================================================//
            
            
            self.notifyDataSetChanged()
            
            //===================================================================//
            
             //To avoid flickering, while including bar at the end
//            if self.leftAxis.resizeEnabled {
//                self.leftAxis.resetCustomAxisMin()
//            }
//
//            if self.rightAxis.resizeEnabled {
//                self.rightAxis.resetCustomAxisMin()
//            }
            //===================================================================//
            
            if self.isKind(of: HorizontalBarChartView.self)
            {
                if aboveBaseLine
                {
                    barEntryToUpdate.sizeChanged = CGSize(width: 0, height: 0)
                }
                else{
                    let basePosition = self.pixelForValues(x: baseLineValue, y: barEntryToUpdate.y, axisIndex: barDataSet.axisIndex)
                    barEntryToUpdate.barYValue = basePosition.x
                    barEntryToUpdate.sizeChanged = CGSize(width: 0, height: 0)
                }
            }
            else{
                if aboveBaseLine
                {
                    let basePosition = self.pixelForValues(x: barEntryToUpdate.x, y: baseLineValue, axisIndex: barDataSet.axisIndex)
                    barEntryToUpdate.barYValue = basePosition.y
                    barEntryToUpdate.sizeChanged = CGSize(width: 0, height: 0)
                }
                else{
                    barEntryToUpdate.sizeChanged = CGSize(width: 0, height: 0)
                }
                
            }
            
            let yInterpolator:((Double) -> Double)
            let sizeInterpolator:((Double) -> Double)
            
            guard let newEntryRect = newBarPositionArray[safe:newIndex],
                let changedSize = barEntryToUpdate.sizeChanged
                else { return }
            
            if self.isKind(of: HorizontalBarChartView.self)
            {
                newBarPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: newEntries, animator: barAnimator, dataSet: barDataSet, dataProvider: barChart, chart: self)
                
                yInterpolator = Interpolator.interpolate(a: Double(barEntryToUpdate.barYValue), b: Double(newEntryRect.minX))
                sizeInterpolator = Interpolator.interpolate(a: Double(changedSize.width), b: Double(newEntryRect.width))
            }
            else{
                newBarPositionArray = BarChartRenderer.getBarRectArray(entries: newEntries, animator: barAnimator, dataSet: barDataSet, dataProvider: barChart, chart: self)

                yInterpolator = Interpolator.interpolate(a: Double(barEntryToUpdate.barYValue), b: Double(newEntryRect.minY))
                sizeInterpolator = Interpolator.interpolate(a: Double(changedSize.height), b: Double(newEntryRect.height))
            }
            
            
            let barEntryAnimator = Animator()
            
            barEntryAnimator.updateBlock = {
                
                if self.isKind(of: HorizontalBarChartView.self)
                {
                    barEntryToUpdate.sizeChanged?.width = CGFloat(sizeInterpolator(barEntryAnimator.phaseX))
                    
                    if !aboveBaseLine
                    {
                        barEntryToUpdate.barYValue = CGFloat(yInterpolator(barEntryAnimator.phaseX))
                    }
                    
                }
                else{
                    barEntryToUpdate.sizeChanged?.height = CGFloat(sizeInterpolator(barEntryAnimator.phaseX))
                    
                    if aboveBaseLine
                    {
                        barEntryToUpdate.barYValue = CGFloat(yInterpolator(barEntryAnimator.phaseX))
                    }
                    
                }
                
                self.setNeedsDisplay()
            }
            
            barEntryAnimator.stopBlock = {
                
                self.interactionAnimationInProgress = false
                
                barEntryToUpdate.isIncluded = false
                
                self.resizeAxisIfNeeded()
                
                self.enableDrawValues()
                
              //  UIView.animate(withDuration: 0.5, animations:
              //  {
                        self.enableIncludeLayer()
                        
                         sliceAnimator = nil
               // })
                
                var entryToAdd:[ChartDataEntry] = []
                entryToAdd.append(barEntry)
                
                
                self.chartActionListener?.chartValueAdded?(chartView: barChart, entry: entryToAdd, index: newIndex, dataSetAdded: false)
            }
           
            barEntryAnimator.animate(xAxisDuration: duration/2, easingOption: .linear)
           
        }
        
        sliceAnimator.animate(xAxisDuration: duration/2, easingOption: .linear)
        
        
    }*/
    
    public static func includeStackedBar(barEntries:[ChartDataEntry], newXPosition:Double,duration:TimeInterval, chart:ChartViewBase)
    {
        guard let processor = chart.getProcessor(type: .Bar) as? BarPreprocessor,
            let plotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar]) as? BarPlotOptions,
            let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Bar]) as? BarChartRenderer,
              let chartData = chart.data
            else { return }
        
        chart.lastSelected = nil
        plotOptions.barGroupSelectionEnabled = false
        chart.callDelegateToContainer(highlight: nil, entry: nil)
        
        var oldEntries:[[ChartDataEntry]] = []
        var newEntries:[[ChartDataEntry]] = []
        
        guard let origX = barEntries[0].origX
        else { return }
        let xIndexDict = chart.originalMap[origX]
        
        for set in (chartData._dataSets)
        {
            var setEntries:[ChartDataEntry] = []
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                setEntries.append(entry)
            }
            oldEntries.append(setEntries)
        }
        
        // To track index to includeEntry
        var trackIndex:Int = 0
        
        for setIndex in 0..<(chartData._dataSets.count)
        {
            guard let set = (chart.data?.dataSets[setIndex])
            else { continue }
            var setEntries:[ChartDataEntry] = []
            var entryToAddCount = 0
            
            if xIndexDict == nil
            {
                continue
            }
            
            if xIndexDict![setIndex] != nil
            {
                entryToAddCount = (xIndexDict![setIndex]?.count) ?? 0
            }
            for i in 0..<(set.entryCount)
            {
                guard let entry = set.entryForIndex(i)
                else { continue }
                
                while  entryToAddCount > 0 && entry.x >= newXPosition   //(entry.origIndex)! > (barEntries[trackIndex].origIndex)!
                {
                    setEntries.append(barEntries[trackIndex])
                    trackIndex += 1
                    entryToAddCount -= 1
                }
                
                
                guard let finalEntry = entry.copy() as? ChartDataEntry
                else { continue }
                
                let isEntryAfterFilterEntry = entry.x >= newXPosition //isStacked() ? entry.x >= newXIndex : i >=  ChartUtils.doubleToIntSafeCast(value:newXIndex)
                if  isEntryAfterFilterEntry
                {
                    finalEntry.x = Double(entry.x+1)
                }
                
                setEntries.append(finalEntry)
            }
            
            while entryToAddCount > 0
            {
                setEntries.append(barEntries[trackIndex])
                trackIndex += 1
                entryToAddCount -= 1
            }
            
            newEntries.append(setEntries)
        }
        
        
        let oldBarPositionArray:[[CGRect]] = ChartInteractionHelperFunction.prepareBarRectArrayforAllDataset(barChart: chart)
        
        // reset with newEntries
        CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)
        //            self.customAnimationInProgress = false
        
        let newBarPositionArray:[[CGRect]] = ChartInteractionHelperFunction.prepareBarRectArrayforAllDataset(barChart: chart)
        
        // reset back with oldEntries
        CommonHelperFunctions.resetData(newEntries: oldEntries, chart: chart)
        
        var xyInterpolateArray:[[((Double) -> Double)]] = []
        
        var sizeInterpolateArray:[[((Double) -> Double)]] = []
        
        for dataSetIndex in 0..<(chartData.dataSetCount)
        {
            guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
            else { continue }
            
            if !(set.isVisible)
            {
                xyInterpolateArray.append([((Double) -> Double)]())
                sizeInterpolateArray.append([((Double) -> Double)]())
                continue
            }
            
            var setEntriesXYInterpolator:[((Double) -> Double)] = []
            
            var setEntriesSizeInterpolator:[((Double) -> Double)] = []
            
            var entryToAddCount = 0
            
            if xIndexDict == nil
            {
                continue
            }
            
            
            if xIndexDict![dataSetIndex] != nil
            {
                entryToAddCount = (xIndexDict![dataSetIndex]?.count) ?? 0
            }
            
            for index in stride(from: 0, to: set.entryCount, by: 1)
            {
                guard let currentEntry = set.entryForIndex(index)
                else { continue }
                
                var oldValue = CGFloat(0)
                var oldSize = CGFloat(0)
                
                var newValue = CGFloat(0)
                var newSize = CGFloat(0)
             
                var entryIndex = index
                
                let isEntryAfterFilterEntry = currentEntry.x >= newXPosition //isStacked() ? currentEntry.x >= newXIndex : index >=  ChartUtils.doubleToIntSafeCast(value:newXIndex)
                
                if  isEntryAfterFilterEntry
                {
                      entryIndex = index + entryToAddCount
                }
                    
                if chart.isRotated
                {
                    oldValue = oldBarPositionArray[dataSetIndex][index].origin.y
                    oldSize = oldBarPositionArray[dataSetIndex][index].size.height
                    
                    newValue = newBarPositionArray[dataSetIndex][entryIndex].origin.y
                    newSize = newBarPositionArray[dataSetIndex][entryIndex].size.height
                }
                else{
                    oldValue = oldBarPositionArray[dataSetIndex][index].origin.x
                    oldSize = oldBarPositionArray[dataSetIndex][index].size.width
                    
                    newValue = newBarPositionArray[dataSetIndex][entryIndex].origin.x
                    newSize = newBarPositionArray[dataSetIndex][entryIndex].size.width
                }
                
                
                let radiusDiff = Interpolator.interpolate(a: Double(oldValue), b: (Double(newValue)))
                let widthDiff = Interpolator.interpolate(a: Double(oldSize), b: (Double(newSize)))
                
                setEntriesXYInterpolator.append(radiusDiff)
                
                setEntriesSizeInterpolator.append(widthDiff)
            }
            
            xyInterpolateArray.append(setEntriesXYInterpolator)
            sizeInterpolateArray.append(setEntriesSizeInterpolator)
        }
        
        var sliceAnimator:Animator! = Animator()
        
        if sliceAnimator != nil
        {
            sliceAnimator.stop()
        }
        
        sliceAnimator = Animator()
        
        sliceAnimator.updateBlock = {
            
            renderer.barDeleted = true
            
            chart.interactionAnimationInProgress = true
            
            var interpolatorIndex:Int = 0
            
            for dataSetIndex in 0..<(chartData.dataSetCount)
            {
                guard let set = chart.data?._dataSets[dataSetIndex] as? ChartDataSet
                else { continue}
                
                if !(set.isVisible)
                {
                    continue
                }
                
                interpolatorIndex = 0
                
                for index in stride(from: 0, to: set.entryCount, by: 1)
                {
                    let newEntry = oldEntries[dataSetIndex][index]
                    
                    let oldRect = oldBarPositionArray[dataSetIndex][index]
                    
                    var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
                    
                    var newSize = CGSize(width: oldRect.width, height: oldRect.height)
                    
                    let newVal = xyInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                    
                    let newWidth = sizeInterpolateArray[dataSetIndex][interpolatorIndex](sliceAnimator.phaseX)
                    
                    interpolatorIndex = interpolatorIndex + 1
                    
                    if chart.isRotated
                    {
                        newCenter.y = CGFloat(newVal)
                        
                        newSize.height = CGFloat(newWidth)
                    }
                    else{
                        newCenter.x = CGFloat(newVal)
                        
                        newSize.width = CGFloat(newWidth)
                    }
                    
                    newEntry.centerChanged = newCenter
                    
                    newEntry.sizeChanged = newSize
                }
            }
            
            chart.setNeedsDisplay()
            
        }
        
        sliceAnimator.stopBlock = {

           renderer.barDeleted = false
  
            /*CommonHelperFunctions.resetData(newEntries: newEntries, chart: chart)

            chart.data?.updateXYValues()
            
            for set in (chart.data?._dataSets)!
            {
                set.calcMinMax()
            }
            
            chart.data?.notifyDataChanged()
            
            chart.notifyDataSetChanged(redrawRequired: true)*/
            
            ChartInteractionHelperFunction.resetEntriesAndNotifyData(axisChartBase: chart, newEntries: newEntries)
            
            ChartInteractionHelperFunction.calculateCurrentDataAndSetOldMinMax(axisChartBase: chart)

            
            // To make percentage rise animation
            var stackInterpolateArray:[((Double) -> Double)] = []

            for entry in barEntries
            {
                let yInterpolator = Interpolator.interpolate(a: 0, b: entry.y)
                stackInterpolateArray.append(yInterpolator)
                entry.y = 0
            }
            processor.updateEntriesStackValue()
            
            let barEntryAnimator = Animator()
            
            barEntryAnimator.updateBlock = {
                
                var stackIndex = -1
                for entry in barEntries
                {
                    stackIndex += 1
                    entry.y = stackInterpolateArray[stackIndex](barEntryAnimator.phaseX)
                }
                processor.updateEntriesStackValue()
                chart.setNeedsDisplay()
            }
            
            barEntryAnimator.stopBlock = {
                
                chart.interactionAnimationInProgress = false
                
//                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
                ChartInteractionHelperFunction.callResizeAxis(axisChartBase: chart)
                
//                chart.enableDrawValues()
                
                CommonHelperFunctions.enableIncludeLayer(chart: chart)
                
                sliceAnimator = nil
                
                chart.delegateToContainer?.chartValueAdded?(chartView: chart, entries: barEntries, dataSets: nil, dataSetAdded: false)
            }
            
            barEntryAnimator.animate(xAxisDuration: duration/2, easingOption: .linear)
        }
        
        sliceAnimator.animate(xAxisDuration: duration/2, easingOption: .linear)
    }
    
    
    public static func splitMultiBar(selectedDataset: IChartDataSet, chart: ChartViewBase)
    {
        guard let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Bar,.WaterFall]) as? BarChartRenderer
        else { return }
        
        let barChart = chart
        
        let oldDataSetArray = prepareDataSetArrayforMultiBar(selectedDataset: selectedDataset, chart: chart)
        
        
        selectedDataset.visible = true
        
        chart.data?.updateXYValues()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        
        let newDataSetArray = prepareDataSetArrayforMultiBar(selectedDataset: selectedDataset, chart: chart)
        
        
        selectedDataset.visible = false
        
        chart.data?.updateXYValues()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        
        
        // Interpolater Array
        
        let (barInterpolateArray,widthInterpolateArray) = prepareBarXandBarWidthInterpolatorforMultiBar(selectedDataset: selectedDataset, oldDataSetArray: oldDataSetArray, newDataSetArray: newDataSetArray, chart: chart)
        
        
        
        // Animation
        
        let endBlock = {
            
            renderer.barDeleted = false
            
//            barChart.enableDrawValues()
            barChart.interactionAnimationInProgress = false
            
            includeMultiBar(selectedDataset: selectedDataset, chart: chart)
        }
        
        
        performBarXandBarWidthAnimationforMultiBar(selectedDataset: selectedDataset, barInterpolateArray: barInterpolateArray, widthInterpolateArray: widthInterpolateArray, oldDataSetArray: oldDataSetArray, stopBlock: endBlock, chart: chart)
        
    }
    
    internal static func performFilterAnimation(chartEntry:ChartDataEntry,filterDuration:Double, chart:ChartViewBase)
    {
        let opacDuration = filterDuration * (3/4)
        
        guard let barLayer = BarLayer.getBarLayerForEntry(chart: chart, entry: chartEntry)
        else { return }
        
        
        CommonHelperFunctions.performOpacityAnim(targetLayer: barLayer, opacity: 0, duration: opacDuration)
        
        guard let barRect = (barLayer.barRect)
        else { return }
        if chart.isRotated
        {
            let newRect = CGRect(x: barRect.minX, y: barRect.minY, width: barRect.width/4, height: barRect.height)
            let path = (barLayer.getPath(rect: newRect))
            
            CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: path, duration: filterDuration)
        }
        else{
            
            BarHelperFunctions.changeBarYPositionAndHeight(barLayer: barLayer, newYValue: ((barRect.height)*(3/4)) , chart: chart, duration: filterDuration)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(filterDuration*1000)), execute: {
            self.removeEntry(barEntry: chartEntry, defaultAnimation: true, chart: chart)
        })
    }
        
    public static func moveAllBarEntriesToXPoints(distance:CGFloat, chart:ChartViewBase)
    {
        guard let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Bar]) as? BarChartRenderer
        else { return }
        
        let barChart =  chart
        
        renderer.barDeleted = true
        
        guard let data = chart.data
        else { return }
        
        var oldEntries:[ChartDataEntry] = []
        
        for i in 0 ..< (data.dataSets[0].entryCount)
        {
            guard let oldEntry = data.dataSets[0].entryForIndex(i)
            else { continue }
            oldEntries.append(oldEntry)
        }
        
        let oldBarPositionArray:[CGRect] = BarChartRenderer.getBarRectArray(entries: oldEntries, animator: (barChart._animator), dataSet: data.dataSets[0], chart: chart)
        
        for index in stride(from: 0, to: oldBarPositionArray.count, by: 1)
        {
            let newEntry = oldEntries[index]
            let oldRect = oldBarPositionArray[index]
            var newCenter = CGPoint(x: oldRect.origin.x, y: oldRect.origin.y)
            if index >= 0
            {
                newCenter.x = newCenter.x + distance
            }
            
            if (!barChart.viewPortHandler.isInBoundsLeft(newCenter.x + oldRect.size.width)) || (!barChart.viewPortHandler.isInBoundsRight(oldRect.origin.x))
            {
                newEntry.filterEnabled = true
            }
            
            newEntry.centerChanged = newCenter
            
            newEntry.sizeChanged = CGSize(width: oldRect.width, height: oldRect.height)
        }
        
        barChart.setNeedsDisplay()
        
    }
    
    
    // MARK: - Gesture Handling
       
       
    public static func tapHighlight(location: CGPoint, _ recognizer: TapEventListener?, chart:ChartViewBase ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
     {
           
           var entry:ChartDataEntry? = nil
           
           var high = chart.getHighlightByTouchPoint(location)
           
           var barLayer:BarLayer? = nil
           
           if BarLayer.getBarLayerInPoint(chart: chart, loc: location) == nil
           {
               high = nil
           }
           
           if high != nil
           {
               entry = chart.entryForHighlight(high!)
           }
           
           
           if recognizer?.handler?.getEventHandlerType() == EventHandlerType.custom && entry != nil
           {
               barLayer = BarLayer.getBarLayerInPoint(chart: chart, loc: location)
           }
        
            return (entry,barLayer)
           
       }
     
    #if os(iOS)
    public static func longPressPerformed(_ recognizer: LongPressEventListener , chart:ChartViewBase) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
       {
           let location = recognizer.location(in: chart)

           var entry:ChartDataEntry? = nil
           
           let high = chart.getHighlightByTouchPoint(location)
           
           var barLayer:BarLayer? = nil
           
           if high != nil
           {
               entry = chart.entryForHighlight(high!)
           }
           
           if recognizer.state == .began
           {
               ChartUtils.longPressSound()
           }
           
           if recognizer.handler?.getEventHandlerType() == EventHandlerType.custom && entry != nil
           {
                if isStacked(chart: chart)
               {
                   barLayer = BarLayer.getBarLayerInPointOriginal(chart: chart, loc: location)
               }
               else
               {
                   barLayer = BarLayer.getBarLayerInPoint(chart: chart, loc: location)
               }
           }
           
           return (entry,barLayer)

       }
    #endif
       
    public static func panPerformed(_ recognizer: PanEventListener, chart:ChartViewBase) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
       {
           var entry:ChartDataEntry? = nil
           
           let location = recognizer.location(in: chart)
           
           let high = chart.getHighlightByTouchPoint(location)
           
           if high != nil
           {
               entry = chart.entryForHighlight(high!)
           }
           
           
           var barLayer:BarLayer? = nil
           
           if recognizer.handler?.getEventHandlerType() == EventHandlerType.custom && entry != nil
           {
               //            barLayer = BarLayer.getBarLayerInPoint(chart: self, loc: location)
               if isStacked(chart: chart)
               {
                   barLayer = BarLayer.getBarLayerInPointOriginal(chart: chart, loc: location)
               }
               else
               {
                   barLayer = BarLayer.getBarLayerInPoint(chart: chart, loc: location)
               }
           }
           
          return (entry,barLayer)
       }
       
    public static func pinchPerformed(_ recognizer: PinchEventListener, chart:ChartViewBase ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
       {
           let location = recognizer.location(in: chart)
           
           var entry:ChartDataEntry? = nil
           
           let high = chart.getHighlightByTouchPoint(location)
           
           var barLayer:BarLayer? = nil
           
           if high != nil
           {
               entry = chart.entryForHighlight(high!)
           }
           
           
           if recognizer.handler?.getEventHandlerType() == EventHandlerType.custom && entry != nil
           {
               if isStacked(chart: chart)
               {
                   barLayer = BarLayer.getBarLayerInPointOriginal(chart: chart, loc: location)
               }
               else
               {
                   barLayer = BarLayer.getBarLayerInPoint(chart: chart, loc: location)
               }
           }
           
           return (entry,barLayer)
           
       }
    
    // MARK: - Supporting Methods
    
    public static func getPositiveSum(chart:ChartViewBase) -> [Double:Double]
    {
        guard let processor = chart.getProcessor(type: .Bar) as? BarPreprocessor
            else { return [:] }
        
        return processor.positiveSum
        
    }
    
    public static func getNegativeSum(chart:ChartViewBase) -> [Double:Double]
    {
        guard let processor = chart.getProcessor(type: .Bar) as? BarPreprocessor
            else { return [:] }
        
        return processor.negativeSum
        
    }
       
    public static func isBarChart(chart:ChartViewBase) -> Bool
   {
    return chart.plotTypes.contains(.Bar)
       
   }
   
    public static func isStacked(chart:ChartViewBase) -> Bool
   {
       guard let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar,.WaterFall,.Mekko]) as? BarPlotOptions
            else { return false }
        
        return barPlotOptions.isStacked
   }
    
    public static func isStackPercentEnabled(chart:ChartViewBase) -> Bool
    {
          guard let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar]) as? BarPlotOptions
                    else { return false }
                
            return barPlotOptions.stackedPercentEnabled
    }
    

    public static func distance(from: CGPoint, to: CGPoint) -> CGFloat
    {
        let dx = from.x - to.x
        let dy = from.y - to.y
        return sqrt(dx * dx + dy * dy)
    }
   
   public static func getEntryAndLayer(_ recognizer: NSUIGestureRecognizer ) -> (entry:ChartDataEntry?,layer:ChartEntryLayer?)
   {
       fatalError("getEntryAndLayer cannot be called on BarLineChartViewBase")
   }
   
   public static func performHighlight(newEntry:ChartDataEntry)
   {
       fatalError("Highlight cannot be called on BarLineChartViewBase")
   }
   
    public static func resetDatasetEntries(dataset:IChartDataSet,entries:[ChartDataEntry], chart:ChartViewBase)
   {
       dataset.clear()
       
       for entry in entries
       {
           let _ = dataset.addEntry(entry)
       }
       
       dataset.calcMinMax()
       
       chart.data?.notifyDataChanged()
       
       if isBarChart(chart: chart)
       {
            chart.notifyDataSetChanged(redrawRequired: false)
       }
       else{
           chart.notifyDataSetChanged(redrawRequired: false)
           chart.prepareValuePxMatrix()
       }
   }
   
    
    /// - returns: The bounding box of the specified Entry in the specified DataSet. Returns null if the Entry could not be found in the charts data.
    public static func getBarBounds(entry e: ChartDataEntry, chart:ChartViewBase) -> CGRect
      {
          /*guard let
              data = _data as? ChartData,
              let set = data.getDataSetForEntry(e) as? IChartDataSet
              else { return CGRect.null }
          
          let y = e.y
          let x = e.x
          
          let barWidth = data.barWidth
          
          let left = x - barWidth / 2.0
          let right = x + barWidth / 2.0
          let top = y >= 0.0 ? y : 0.0
          let bottom = y <= 0.0 ? y : 0.0
          
          var bounds = CGRect(x: left, y: top, width: right - left, height: bottom - top)
          
          getTransformer(axisIndex: set.axisIndex).rectValueToPixel(&bounds)
          
          return bounds*/
          guard let barLayer = BarLayer.getBarLayerForEntry(chart: chart, entry: e),
                (barLayer.barRect != nil)
          else { return CGRect.null }
          return barLayer.barRect!
      }
   
   
    public static func prepareDataSetArrayforMultiBar(selectedDataset:IChartDataSet, chart:ChartViewBase ) -> [[CGRect]]
   {
       let barChart = chart
       
       var tempDatasetArray:[[CGRect]] = []
       
       guard let barData = chart.data
       else { return tempDatasetArray }
       
       for dataset in (barData._dataSets)
       {
           var datasetEntries:[ChartDataEntry] = []
           
           if dataset === selectedDataset || !(dataset.isVisible)
           {
               continue
               
           }
           for i in 0..<(dataset.entryCount)
           {
               guard let entry = (dataset.entryForIndex(i))
               else { continue }
               datasetEntries.append(entry)
               
           }
           
           let barPositionArray:[CGRect]
           
            if chart.isRotated
           {
               barPositionArray = HorizontalBarChartRenderer.getHorizontalBarRectArray(entries: datasetEntries, animator: ((barChart)._animator), dataSet: dataset, chart: chart)
           }
           else{
               barPositionArray = BarChartRenderer.getBarRectArray(entries: datasetEntries, animator: ((barChart)._animator), dataSet: dataset, chart: chart)
           }
           
           
           tempDatasetArray.append(barPositionArray)
       }
       
       return tempDatasetArray
   }
    
    
   public static func prepareDataSetArray(selectedDataset:IChartDataSet, chart:ChartViewBase ) -> [CGRect]
   {
        var datasetEntries:[ChartDataEntry] = []
        
        for i in 0..<(selectedDataset.entryCount)
        {
            guard let entry = (selectedDataset.entryForIndex(i))
            else { continue }
            datasetEntries.append(entry)
            
        }
        
        let barPositionArray:[CGRect]
        
        barPositionArray = BarChartRenderer.getBarRectArray(entries: datasetEntries, animator: ((chart)._animator), dataSet: selectedDataset, chart: chart)
    
        return barPositionArray
    
    }
   
    public static func prepareBarXandBarWidthInterpolatorforMultiBar(selectedDataset:IChartDataSet,oldDataSetArray:[[CGRect]],newDataSetArray:[[CGRect]], chart:ChartViewBase) -> ([[((Double) -> Double)]],[[((Double) -> Double)]])
   {
       var barInterpolateArray:[[((Double) -> Double)]] = []
       
       var widthInterpolateArray:[[((Double) -> Double)]] = []
       
       guard let chartData = chart.data
       else { return (barInterpolateArray,widthInterpolateArray)}
       
       var dataSetCount = 0
       
       for dataset in (chartData._dataSets)
       {
           var entriesInterpolator:[((Double) -> Double)] = []
           
           var entriesWidthInterpolator:[((Double) -> Double)] = []
           
           if dataset === selectedDataset || !(dataset.isVisible)
           {
               continue
               
           }
           
           
           for i in 0..<(dataset.entryCount)
           {
               let interpolateValue:((Double) -> Double)
               let sizeInterpolateValue:((Double) -> Double)
               
                if chart.isRotated
               {
                   interpolateValue = Interpolator.interpolate(a: Double(oldDataSetArray[dataSetCount][i].minY), b: Double(newDataSetArray[dataSetCount][i].minY))
                   sizeInterpolateValue = Interpolator.interpolate(a: Double(oldDataSetArray[dataSetCount][i].height), b: Double(newDataSetArray[dataSetCount][i].height))
               }
               else{
                   interpolateValue = Interpolator.interpolate(a: Double(oldDataSetArray[dataSetCount][i].minX), b: Double(newDataSetArray[dataSetCount][i].minX))
                   sizeInterpolateValue = Interpolator.interpolate(a: Double(oldDataSetArray[dataSetCount][i].width), b: Double(newDataSetArray[dataSetCount][i].width))
               }
               
               entriesInterpolator.append(interpolateValue)
               
               entriesWidthInterpolator.append(sizeInterpolateValue)
               
           }
           
           barInterpolateArray.append(entriesInterpolator)
           
           widthInterpolateArray.append(entriesWidthInterpolator)
           
           dataSetCount += 1
       }
       
       return (barInterpolateArray,widthInterpolateArray)
   }
   
    public static func performBarXandBarWidthAnimationforMultiBar(selectedDataset:IChartDataSet,barInterpolateArray:[[((Double) -> Double)]],widthInterpolateArray:[[((Double) -> Double)]],oldDataSetArray:[[CGRect]],stopBlock:(() -> Void)?, chart: ChartViewBase)
   {
        let barChart = chart
    
       guard
        let barRenderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Bar,.WaterFall]) as? BarChartRenderer,
       let barData = barChart.data
           else { return }
    
       
       var dataSetCount = 0
       
       let sliceAnimator:Animator! = Animator()
       
       if sliceAnimator != nil
       {
           sliceAnimator.stop()
       }
       
       sliceAnimator.updateBlock = {
           
           barRenderer.barDeleted = true
           
           barChart.interactionAnimationInProgress = true
           
           dataSetCount = 0
           
           for dataset in barData.dataSets
           {
               
               if dataset === selectedDataset || !(dataset.isVisible)
               {
                   continue
                   
               }
               for i in 0..<(dataset.entryCount)
               {
                   guard let entry = (dataset.entryForIndex(i)),
                       let oldDatasetRect = oldDataSetArray[safe:dataSetCount],
                       let oldEntryRect = oldDatasetRect[safe:i],
                       let barDatasetInterpolator = barInterpolateArray[safe:dataSetCount],
                       let barValuefn = barDatasetInterpolator[safe:i],
                       let widthDatasetInterpolator = widthInterpolateArray[safe:dataSetCount],
                       let widthValuefn = widthDatasetInterpolator[safe:i]
                       else { continue }
                   
                   var center = CGPoint(x: oldEntryRect.minX, y: oldEntryRect.minY)
                   
                   var sizeChanged = CGSize(width: oldEntryRect.width, height: oldEntryRect.height)
                   
                    if chart.isRotated
                   {
                       center.y = CGFloat(barValuefn(sliceAnimator.phaseX))
                       sizeChanged.height = CGFloat(widthValuefn(sliceAnimator.phaseX))
                   }
                   else{
                       center.x = CGFloat(barValuefn(sliceAnimator.phaseX))
                       sizeChanged.width = CGFloat(widthValuefn(sliceAnimator.phaseX))
                   }
                   
                   entry.centerChanged = center
                   
                   entry.sizeChanged = sizeChanged
                   
               }
               
               dataSetCount += 1
           }
           
           chart.setNeedsDisplay()
           
       }
       
       sliceAnimator.stopBlock = stopBlock
       
       sliceAnimator.animate(xAxisDuration: 0.5, easingOption: .linear)
   }
    
    public static func prepareBaseValueForLevelMarker(levelValues: [Double], basevalue: Double) -> [Double] {
        
        var baseLevelValue: [Double] = []
        
        var containsPositive = false
        var containsNegative = false
        
        for level in levelValues where !(level.isNaN)
        {
            if level > 0
            {
                containsPositive = true
            }
            if level < 0
            {
                containsNegative = true
            }
        }
        
        if levelValues.count > 0 {
            for levelValueIndex in 0..<levelValues.count - 1 {
                
                if levelValues[levelValueIndex] >= 0.0 && levelValues[levelValueIndex + 1] >= 0.0 {
                    baseLevelValue.append(levelValues[levelValueIndex])
                }
                else if levelValues[levelValueIndex] <= 0.0 && levelValues[levelValueIndex + 1] <= 0.0 {
                    baseLevelValue.append(levelValues[levelValueIndex + 1])
                }
                else {
                    baseLevelValue.append(contentsOf: [basevalue,basevalue])
                }
            }
        }
        
        if containsPositive && !containsNegative
        {
            baseLevelValue.insert(basevalue, at: 0)
        }

        if containsNegative && !containsPositive
        {
            baseLevelValue.insert(basevalue, at: baseLevelValue.count)
        }
        
        return baseLevelValue
    }

    
        // MARK: - UNUSED
        
    // Need to revise..... Auto Scale Y-axis
    public static func binSearchForLowestClosestValue(dataSet: IChartDataSet, startIndex: Int, endIndex: Int, closestValue:  Double) -> ChartDataEntry?
    {
        if endIndex >= startIndex
        {
            
            let mid = startIndex + (endIndex - startIndex) / 2
            
            guard let entry = (dataSet.entryForIndex(mid))
            else { return nil}
            
            if entry.x == closestValue
            {
                return entry
            }
            
            if entry.x > closestValue
            {
                return binSearchForLowestClosestValue(dataSet: dataSet, startIndex: startIndex, endIndex: (mid - 1), closestValue: closestValue)
            }
            
            //if entry.x > closestValue
            
            let nextEntry = (dataSet.entryForIndex(mid + 1))
            
            if nextEntry == nil
            {
                return entry
            }
            
            if closestValue <= (nextEntry?.x)!
            {
                return entry
            }
            else
            {
                return binSearchForLowestClosestValue(dataSet: dataSet, startIndex: (mid + 1), endIndex: endIndex, closestValue: closestValue)
            }
            
        }
        
        return  nil
    }
    
    
    public static func binSearchForHighestClosestValue(dataSet: IChartDataSet, startIndex: Int, endIndex: Int, closestValue:  Double) -> ChartDataEntry?
    {
        if endIndex >= startIndex
        {
            
            let mid = startIndex + (endIndex - startIndex) / 2
            
            guard let entry = (dataSet.entryForIndex(mid))
            else { return nil }
            
            if entry.x == closestValue
            {
                return entry
            }
            
            if entry.x < closestValue
            {
                return binSearchForHighestClosestValue(dataSet: dataSet, startIndex: (mid + 1), endIndex: endIndex, closestValue: closestValue)
            }
            
            //if entry.x > closestValue
            
            let prevEntry = (dataSet.entryForIndex(mid - 1))
            
            if prevEntry == nil
            {
                return entry
            }
            
            if closestValue >= (prevEntry?.x)!
            {
                return entry
            }
            else
            {
                return binSearchForHighestClosestValue(dataSet: dataSet, startIndex: startIndex , endIndex: (mid - 1), closestValue: closestValue)
                //                return binSearchForHighestClosestValue(dataSet: dataSet, startIndex: (mid - 1), endIndex: endIndex, closestValue: closestValue)
            }
            
        }
        
        return  nil
    }
    
    public static func getStartIndexForXValue(dataSet: IChartDataSet, closestXValue:Double) -> ChartDataEntry?
    {
        let count = (dataSet.entryCount)
        let chartDataEntry = binSearchForLowestClosestValue(dataSet: dataSet, startIndex: 0, endIndex: count-1, closestValue: closestXValue)
        Log.debug("Start Index value - \(String(describing: chartDataEntry))")
        
        return chartDataEntry
    }
    
    public static func getEndIndexForXValue(dataSet: IChartDataSet, closestXValue:Double) -> ChartDataEntry?
    {
        let count = (dataSet.entryCount)
        let chartDataEntry = binSearchForHighestClosestValue(dataSet: dataSet, startIndex: 0, endIndex: count-1, closestValue: closestXValue)
        Log.debug("End Index value - \(String(describing: chartDataEntry))")
        
        return chartDataEntry
    }
    
    public static func getAnimationBlock(chartView: ChartViewBase, duration:TimeInterval) -> (() -> Void)
    {
        let animateBlock = {
            
            if chartView.data == nil
            {
                return
            }
            
            var newLayers = BarLayer.getAllBarLayer(chart: chartView)
            
        
            newLayers = newLayers.sorted(by: {
                (layer1:BarLayer, layer2:BarLayer) -> Bool in
                return ((layer1.chartEntry?.x.isNaN ?? true ? 0 : layer1.chartEntry?.x) ?? 0) < ((layer2.chartEntry?.x.isNaN ?? true ? 0 : layer2.chartEntry?.x) ?? 0)
            })
            
            var layerDict:[Double:[BarLayer]] = [:]
            
            var xArray:[Double] = []
            
            for layer in newLayers
            {
                guard var x = layer.chartEntry?.x
                else { continue }
                if (x.isNaN) {
                    x = 0.0
                }
                
                if (!xArray.contains(x)) {
                    xArray.append(x)
                }
                
                var barLayerArray = layerDict[x]
                
                if (barLayerArray == nil) {
                    barLayerArray = []
                }
                barLayerArray?.append(layer)
                layerDict[x] = barLayerArray
            }
                    
            let mapCount = layerDict.count
            
            let intervalBetweenBarLayers = duration / Double(mapCount)
            
            let currentSystemTime = CACurrentMediaTime()
                    
            var mapIndex:Int = 0
            
            for x in xArray {
                guard let barLayers = layerDict[x]
                else { continue }
                let shapeDelay = (Double(mapIndex) * intervalBetweenBarLayers)
                let shapeDuration = duration -  shapeDelay
                let actualDelay = currentSystemTime + shapeDelay
                
                let baseValue = getBaseValue(chartView: chartView, barLayers: barLayers)
                
                for barLayer in barLayers {
                    
                    if barLayer.path == nil
                    {
                        continue
                    }
                    
                    let finalPath = barLayer.path!//UIBezierPath(cgPath: barLayer.path!)// barLayer.path
                                        
                    updateLayerPathForCustomAnim(chartView:chartView, phaseValue: 0.0,indexLayer: barLayer, baseValue:baseValue,duration: shapeDuration, delay: actualDelay)
                    
                    performPathAnimForCustomAnim(targetLayer: barLayer, newPath: finalPath as! CGMutablePath, duration: shapeDuration, delay: actualDelay)
                }
                mapIndex = mapIndex + 1
            }
         
        }
        
        return animateBlock
    }
    
    static func getBaseValue(chartView:ChartViewBase, barLayers:[BarLayer]) -> CGFloat {
                
        var baseValue:CGFloat = CGFloat.nan
        var currentBase:CGFloat = CGFloat.zero
        for barLayer in barLayers
        {
            guard var yVal = barLayer.chartEntry?.y,
                  let barRect = barLayer.barRect
            else { continue }
            
            if (yVal.isNaN) {
                yVal = 0.0
            }
            
            if (chartView.isRotated)
            {
                if (yVal >= 0 )
                {
                    currentBase = barRect.origin.x
                    baseValue = (baseValue.isNaN || (currentBase < baseValue )) ? currentBase : baseValue
                }
                else
                {
                    currentBase = barRect.origin.x + barRect.width
                    baseValue = (baseValue.isNaN || (currentBase > baseValue )) ? currentBase : baseValue
                }
            }
            else
            {
                if (yVal >= 0 )
                {
                    currentBase = barRect.origin.y + barRect.height
                    baseValue = (baseValue.isNaN || (currentBase > baseValue )) ? currentBase : baseValue
                }
                else
                {
                    currentBase = barRect.origin.y
                    baseValue = (baseValue.isNaN || (currentBase < baseValue )) ? currentBase : baseValue
                }
            }
        }
        return baseValue
    }
        
    static func updateLayerPathForCustomAnim(chartView:ChartViewBase,phaseValue:CGFloat,indexLayer:BarLayer, baseValue:CGFloat, duration: CGFloat, delay: CGFloat)
    {
        if indexLayer.barRect == nil {
            return
        }
        
        guard let barRect = indexLayer.barRect,
              let entry = indexLayer.chartEntry
        else { return }
        
        
        
        var newWidth = barRect.width
        
        var newHeight = barRect.height
        
        var newX =  barRect.origin.x
        
        var newY = barRect.origin.y
                
        if (chartView.isRotated)
        {
            newWidth = phaseValue * barRect.width
            
            if (entry.y >= 0 )
            {
                newX = baseValue.isNaN ? barRect.origin.x : baseValue
            }
            else
            {
                newX = baseValue.isNaN ? (barRect.origin.x + barRect.width) : baseValue
            }
        }
        else
        {
            newHeight = phaseValue * barRect.height
            
            if (entry.y >= 0 )
            {
                newY = baseValue.isNaN ? ( barRect.origin.y + barRect.height) : baseValue
            }
            else
            {
                newY = baseValue.isNaN ?  barRect.origin.y : baseValue
            }
        }
        
        let rect = CGRect(x: newX, y: newY, width: newWidth, height: newHeight)
        
        let path = indexLayer.getPath(rect: rect)//UIBezierPath(rect: rect)
        
        indexLayer.path = path//.cgPath
        
        indexLayer.opacity = 1.0
        
        GradientLayerRenderer.updateGradientLayerPath(targetLayer: indexLayer, newPath: path)
        
        if indexLayer.barDataSet?.plotType == .BoxPlot {
            
            guard let indexEntry = indexLayer.chartEntry
                else { return }
            if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chartView, entry: indexEntry) {
                
                guard let finalPath = whiskerLayer.path
                else { return }
                
                whiskerLayer.path = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: indexLayer,rect:rect, percent: 1.0)
                
                whiskerLayer.opacity = 1.0
                
//                performPathAnimForCustomAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: duration, delay: delay)
                performPathAnimForCustomAnim(targetLayer: whiskerLayer, newPath: finalPath as! CGMutablePath, duration: duration, delay: delay)
            }
        }
        
    }
    
    /// Animate Layer Path and Runs Completion Block at End
    fileprivate static func performPathAnimForCustomAnim(targetLayer:CAShapeLayer,newPath:CGMutablePath,duration:TimeInterval, delay:TimeInterval)
    {
//        CATransaction.begin()
        
        let anim = CABasicAnimation(keyPath: "path")
        
        anim.fromValue = targetLayer.path
        
        anim.toValue = newPath//.cgPath
        
        anim.duration = duration
        
        anim.timingFunction =  CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        anim.beginTime = delay
        
//        CATransaction.setCompletionBlock( {
//            targetLayer.path = newPath.cgPath
//        })
//
        anim.fillMode = .forwards
        anim.isRemovedOnCompletion = false
        
        targetLayer.add(anim, forKey: "path")
        
//        CATransaction.commit()
        
        GradientLayerRenderer.performGradientLayerPathAnimation(targetLayer: targetLayer, newPath: newPath, duration: duration)
    }
    
    /////====================== ****************************** ====================== /////
    
    public static func HighlightByDataEntry(entry: ChartDataEntry,bar:ChartViewBase){
        
        var curSelected:BarLayer? = nil
        
        guard let barData = bar.data,
              let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: bar, types: typeAllowed) as? BarPlotOptions
            else { return }
        
        
        
        barPlotOptions.barGroupSelectionEnabled = false
        
        bar.lastSelected = nil
        
        curSelected = BarLayer.getBarLayerForEntry(chart: bar, entry: entry)
        
        if barPlotOptions.isStacked || (barData.dataSetCount) > 1
        {
            
            if curSelected != nil{
                barPlotOptions.barGroupSelectionEnabled = true
                
                 bar.updateLastSelectedEntry(entry: curSelected?.chartEntry)
            }
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                    layer.opacity = 1.0
            }
        }
        else{
            if bar.lastSelected != nil && bar.IsEntrySelected(entry: curSelected?.chartEntry)
            {
                barPlotOptions.barGroupSelectionEnabled = true
            }
            else{
                barPlotOptions.barGroupSelectionEnabled = false
            }
            
            curSelected?.opacity = 1.0
            
    //            bar.lastSelected = curSelected?.chartEntry
            bar.updateLastSelectedEntry(entry: curSelected?.chartEntry)
            
            if ((barData.dataSetCount) == 1)
            {
                barPlotOptions.barGroupSelectionEnabled = true
            }
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                if curSelected != layer
                {
                    layer.opacity = 0.5
                }
                
            }
        }
    }
    
}

// mekko helper functions
extension BarHelperFunctions {
     
    public static func getCategoryToSizeForEntryXValue( chart: ChartViewBase, value: Double) -> (CGFloat,CGFloat) {
        
        guard
            let chartData = chart.data,
            let processor = chart.getProcessor(type: .Mekko) as? MekkoPreprocessor,
            let xString = chartData.xString?[ChartUtils.doubleToIntSafeCast(value: value)],
            let (startVal, sizeVal) = processor.categoryToSize[xString]
        else { return (0.0,0.0)}
        
        return (startVal,sizeVal)
    }
    
    public static func getXPoint( chart: ChartViewBase, value: Double) -> Double {
        
        guard let chartData = chart.data else {
            return 0.0
        }
        
        let (startVal,sizeVal) = getCategoryToSizeForEntryXValue( chart: chart, value: value)
        
        let trans = chart.getTransformer(axisIndex: chartData.dataSets[0].axisIndex)
        
        var point = CGPoint(x: startVal + sizeVal, y: 0.0)
        
        trans.pointValueToPixel(&point)
        
        return point.x
    }
    
    public static func precentageOfXEntry(chart: ChartViewBase, value: Double) -> Double? {
        
        guard
            let xString = chart.data?.xString else {
            return nil
        }
        
        let countOfXString = xString.count - 1
        
        
        let (startVal,sizeVal) = getCategoryToSizeForEntryXValue(chart: chart, value: Double(countOfXString))
        
        let currentSize = getCategoryToSizeForEntryXValue(chart: chart, value: value).1
        
        let totalSize = startVal + sizeVal
        
        return Double(ChartUtils.roundNumber(number: (currentSize / totalSize) * 100.0))
    }
}
