//
//  FunnelLongPressListener.swift
//  ZCharts
//
//  Created by Aravinth T on 09/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

import Foundation

open class FunnelLongPressListener: NSObject,EventHandler {
    
    var prevChartEntry:ChartDataEntry? = nil
    
    var toggleAscending:Bool = true
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }

    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
     
        let funnelChart =  chartView
        
        guard funnelChart.data != nil
            else { return }
        
        if recognizer?.state == .began {
            
            ChartUtils.longPressSound()
            self.prevChartEntry = nil
            callHighlight(entry: entry, funnelChart: funnelChart)
            
        } else if recognizer?.state == .changed {
            
            if prevChartEntry != nil && entry == nil {
//                resetLastselectedToNil(chart: funnelChart)
            } else if (prevChartEntry == nil && entry != nil) || (prevChartEntry != nil && entry != nil && prevChartEntry != entry) {
                callHighlight(entry: entry, funnelChart: funnelChart)
            }
            
        } else if recognizer?.state == .ended {
//             resetLastselectedToNil(chart: chartView)
        }
    }
    
    func callHighlight(entry: ChartDataEntry?, funnelChart: ChartViewBase){
        if entry != nil {
            FunnelHelperFunctions.highlightFunnelLayerForEntry(entry: entry!, funnelChart: funnelChart)
            prevChartEntry = entry
        }
    }
    
    func resetLastselectedToNil(chart:ChartViewBase) {
        chart.lastSelected = nil
        chart.highlightValue(nil, callDelegate: false, redrawRequired: false)
        self.prevChartEntry = nil
    }
    
}
