//
//  StackedBarPanHandler.swift
//  ZCharts
//
//  Created by Aravinth T on 10/11/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif


open class StackedBarPanHandler: NSObject,EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    
    
    var indexToBarLayer:[Double:BarLayer] = [:]
    
    var totalHeight:CGFloat = 0.0
    
    // 20 % of viewport height
    var maxHeight:CGFloat = 0.0
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart
        guard let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar,.WaterFall,.BoxPlot,.Mekko]) as? BarPlotOptions
        else { return }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: startLoc!)
            
            if barChart.lastSelected != nil && barChart.lastSelected!.count > 0
            {
                startLay = BarLayer.getBarLayerForEntry(chart: barChart, entry: barChart.lastSelected![0])
            }
            
            lastTouched = startLoc
            maxHeight = barChart.viewPortHandler.contentHeight * 0.2
            
            if startLay != nil{
                indexToBarLayer = BarHelperFunctions.getStackIndexToBarLayer(barChart: barChart )
                BarLayer.removeAllValueLayer(chart: barChart)
                totalHeight = getTotalHeightOfSelectedEntry(barChart: barChart )
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            //            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            guard let barData = barChart.data
                else { return }
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            // **************************************** Vertical Pan Change**************************************************************
            if /* (barChart.lastSelected == startLay?.chartEntry) */  barChart.IsEntrySelected(entry: startLay?.chartEntry) && verticalMove && !(recognizer.nsuiNumberOfTouches() == 2) && startLay != nil
            {
                trans = recognizer.translation(in: barChart)
                
                if chart.plotTypes.contains(.WaterFall) {
                    WaterFallHelperFunction.disableConnectorLine(chart: chart)
                }
                
                // **************************************** Group Selection **************************************************************
                if chart.xGroupSelected || plotOption.barGroupSelectionEnabled
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let selectedBarEntry = (barChart.lastSelected![0])
                    
                    let barDataSet = (barChart.data?.dataSets[0] as! ChartDataSet)
                    
                    let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barDataSet)
                    
                    let negativeSum = BarHelperFunctions.getNegativeSum(chart: chart)
                    
                    var bottomYValue = negativeSum[selectedBarEntry.x] == nil ? baseLineValue : negativeSum[selectedBarEntry.x]!
                    
                    bottomYValue = chart.plotTypes.contains(.WaterFall) ? bottomYValue : -(bottomYValue)
                    
                    var bottomYPosition = barChart.pixelForValues(x: 0, y: bottomYValue, axisIndex: barDataSet.axisIndex).y
                    
                    // **************************************** Group Drill **************************************************************
                    if trans.y <= 0
                    {
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        let opac:CGFloat!
                        
                        let curWidth:CGFloat!
                        
                        if abs(trans.y) > (maxHeight)
                        {
                            trans.y = -(maxHeight)
                        }
                        
                        let origDiff = maxHeight
                        
                        let curDiff =  origDiff + trans.y
                        
                        if curDiff < 0
                        {
                            opac = 0
                            curWidth = 0
                        }
                        else
                        {
                            
                            opac = (1/origDiff)*curDiff
                            
                            curWidth =  ((BarLayer.getAllBarLayer(chart: barChart)[0].barRect?.width)!/origDiff)*curDiff
                            
                            
                        }
                        
                        animationDuration = 0
                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart )
                        {
                            if barChart.IsEntryXSelected(x: layer.getBarChartEntry().x) // layer.getBarChartEntry().x == barChart.lastSelected?.x
                            {
                                if  (layer.barRect?.maxY)! == bottomYPosition //&& (layer.barRect?.height)! > 0
                                {
                                    BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: trans.y, chart: barChart, duration: animationDuration)
                                }
                                else
                                {
                                    BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: trans.y, chart: barChart, duration: animationDuration)
                                    
                                }
                            }
                            else{
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: opac, changeSize: CGSize(width: curWidth, height: (layer.barRect?.height)!), chart: barChart, duration: animationDuration)
                            }
                        }
                        
                    }
                        // **************************************** Group Filter **************************************************************
                    else
                    {
                        if dist >= (totalHeight)
                        {
                            trans.y = totalHeight
                            animationDuration = 0
                        }
                        
                        let percent = (trans.y / totalHeight)
                        
                        if isGroupFilterAllowed(barChart: chart )
                        {
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                if barChart.IsEntryRoundedXSelected(x: round(layer.getBarChartEntry().x))//.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        bottomYPosition = Double((layer.barRect?.maxY)!)
                                        
                                        if let medianLayer = MedianLayer.getMedianLayerForEntry(chart: chart, entry: layer.chartEntry!) {
                                            medianLayer.opacity(opacityValue: 0)
                                        }
                                    }
                                    
                                    var yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: bottomYPosition)
                                    
                                    if layer.barDataSet?.plotType == .WaterFall && !plotOption.isStacked {
                                    
                                        yInterPolator = Interpolator.interpolate(a: layer.barRect!.minY, b: layer.barRect!.maxY)
                                    
                                        if layer.chartEntry!.y < 0 {
                                            yInterPolator = Interpolator.interpolate(a: layer.barRect!.minY, b: layer.barRect!.minY)
                                        }
                                    }
                                    
                                    let heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: 0)
                                    
                                    let rect = CGRect(x: (layer.barRect?.minX)!, y: yInterPolator(percent), width: (layer.barRect?.width)!, height: heightInterpolator(percent))
                                    
                                    let newPath = layer.getPath(rect: rect)//UIBezierPath(rect: rect)
                                    
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        
                                        let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: layer,rect: rect, percent: percent)
                                        
                                        if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: layer.chartEntry!) {
//                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: animationDuration)
                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath:  finalPath, duration: animationDuration)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                    
                    // **************************************** Stack Selection **************************************************************
                    
                else
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let barHeight = (startLay?.barRect?.size.height)!
                    
                    // **************************************** Stack Drill **************************************************************
                    
                    if trans.y <= 0
                    {
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        let heightToDrill = maxHeight
                        
                        if abs(trans.y) > heightToDrill
                        {
                            trans.y = -heightToDrill
                        }
                        
                        let percent = trans.y / -heightToDrill
                        
                        
                        var index = -1
                        
                        let barDataSet = (barData.dataSets[0] as! ChartDataSet)
                        
                        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barDataSet)
                        
                        guard let lastSelectedEntries = barChart.lastSelected,
                            lastSelectedEntries.count > 0,
                            let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0])
                            else { return  }
                        
                        let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)
                        
                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart)
                        {
                            index += 1
                            
                            let layerEntry = layer.chartEntry!
                            
                            let currentDataSetIndex = barData.indexOfDataSet(layer.barDataSet!)
                            
                            let positiveSum = BarHelperFunctions.getPositiveSum(chart: chart)
                            let negativeSum = BarHelperFunctions.getNegativeSum(chart: chart)
                            
                            var topValue = positiveSum[layerEntry.x] == nil ? baseLineValue : positiveSum[layerEntry.x]!
                            var bottomValue = negativeSum[layerEntry.x] == nil ? baseLineValue : -(negativeSum[layerEntry.x]!)
                            
                            if BarHelperFunctions.isStackPercentEnabled(chart: chart)
                            {
                                topValue = 100
                                bottomValue = 0
                            }
                            
                            let topYPosition = barChart.pixelForValues(x: 0, y: topValue, axisIndex: (barDataSet.axisIndex)).y
                            let bottomYPosition = barChart.pixelForValues(x: 0, y: bottomValue, axisIndex: (barDataSet.axisIndex)).y
                            
                            let filterLayer = indexToBarLayer[layerEntry.x]
                            
                            if filterLayer == nil || (filterLayer?.barRect?.height)! == 0
                            {
                                continue
                            }
                            
                            let yInterPolator:((CGFloat) -> CGFloat)
                            let heightInterpolator:((CGFloat) -> CGFloat)
                            
                            if (layer.barRect?.minY)! > (filterLayer?.barRect?.minY)! && currentDataSetIndex != lastSelectedDataSetIndex //layer.getStackIndex() != barChart.lastSelectedStackIndex
                            {
                                yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: bottomYPosition)
                                heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: 0)
                                
                            }
                            else if currentDataSetIndex == lastSelectedDataSetIndex
                            {
                                
                                yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: topYPosition)
                                heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: (bottomYPosition - topYPosition))
                                
                            }
                            else{
                                
                                yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: topYPosition)
                                heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: 0)
                                
                            }
                            
                            let rect = CGRect(x: (layer.barRect?.minX)!, y: yInterPolator(percent), width: (layer.barRect?.width)!, height: heightInterpolator(percent))
                            
                            let newPath = layer.getPath(rect: rect)

                            CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0)
                            
                        }
                        
                        return
                        
                    }
                        // **************************************** Stack Filter **************************************************************
                    else if dist >= (barHeight)
                    {
                        trans.y = barHeight
                        animationDuration = 0
                    }
                    
                    if isStackEntryFilterAllowed(barData: barData)
                    {
                        let percent = trans.y / barHeight
                        
                        BarHelperFunctions.callGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: percent)
                    }
                    else{
                        return
                    }
                    
                }
                //                }
            }
                // **************************************** Horizontal Pan Change **************************************************************
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                
                if recognizer.nsuiNumberOfTouches() == 2
                {
                    barChart._isDragging = true
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chart)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        plotOption.barGroupSelectionEnabled = true
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
            // **************************************** Verical Pan End **************************************************************
            if verticalMove && startLay != nil  && !barChart._isDragging
            {
                let vel = recognizer.velocity(in: barChart)
                
                guard let barData = barChart.data
                    else { return }
                
                // **************************************** Grouped Selection End  **************************************************************
                if !BarHelperFunctions.isStacked(chart: chart) || chart.xGroupSelected
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let selectedBarEntry = (barChart.lastSelected![0])
                    
                    let barDataSet = (barChart.data?.dataSets[0] as! ChartDataSet)
                    
                    let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barDataSet)
                    
                    let negativeSum = BarHelperFunctions.getNegativeSum(chart: chart)
                    
                    var bottomYValue = negativeSum[selectedBarEntry.x] == nil ? baseLineValue : negativeSum[selectedBarEntry.x]!
                    
                    bottomYValue = chart.plotTypes.contains(.WaterFall) ? bottomYValue : -(bottomYValue)
                    
                    var bottomYPosition = barChart.pixelForValues(x: 0, y: bottomYValue, axisIndex: barDataSet.axisIndex).y
                    
                    if trans == nil
                    {
                        return
                    }
                    
                    // **************************************** Grouped Drill  **************************************************************
                    if trans.y <= 0
                    {
                        // **************************************** Drill Performed **************************************************************
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        if abs(trans.y) >= (maxHeight)
                        {
                            trans.y = maxHeight
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                if  barChart.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    
                                    let newRect = CGRect(x: (layer.barRect?.minX)!, y: bottomYPosition, width: (layer.barRect?.width)!, height: plotOption.roundedRadii + 2.0)
                                    
                                    let newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (layer.barRect?.minX)!, y: bottomYPosition, width: (layer.barRect?.width)!, height: 0))
                                    
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: { [unowned chart] in
                                BarHelperFunctions.drillEntry(barEntry: chart.lastSelected![0], chart: chart)
                            })
                        }
                            // **************************************** Drill reverted **************************************************************
                        else{
                            trans.y = 0
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                var barPath = CGMutablePath(rect: layer.barRect!, transform: nil) //var barPath = UIBezierPath(rect:layer.barRect!)
                                
                                if let newRect = layer.barRect{
                                    barPath = layer.getPath(rect: newRect)
                                }
//                                let barPath = UIBezierPath(rect:layer.barRect!)
                                //                                BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: barPath, chart: barChart, duration: animationDuration)
                                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                            }
                            
                        }
                    }
                        // **************************************** Grouped Filter  **************************************************************
                    else
                    {
                        var filtered = true
                        
                        if vel.y > 1200
                        {
                            trans.y = totalHeight
                            animationDuration = 0.2
                        }
                        else if dist > (totalHeight / 2 ) &&  dist <= (totalHeight )
                        {
                            trans.y = totalHeight
                            animationDuration = 0.2
                        }
                        else if dist >= (totalHeight)
                        {
                            trans.y = totalHeight
                            animationDuration = 0
                        }
                        else if dist <= (totalHeight / 2)
                        {
                            filtered = false
                            trans.y = 0
                            animationDuration = 0.2
                        }
                        
                        let percent = (trans.y / totalHeight)
                        
                        if isGroupFilterAllowed(barChart: chart)
                        {
                            barChart.interactionAnimationInProgress = true
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart )
                            {
                                if barChart.IsEntryRoundedXSelected(x: round(layer.getBarChartEntry().x))//.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        
                                        bottomYPosition = Double((layer.barRect?.maxY)!)
                                        
                                        if let medianLayer = MedianLayer.getMedianLayerForEntry(chart: chart, entry: layer.chartEntry!) {
                                            medianLayer.opacity(opacityValue: 0)
                                        }
                                    }
                                    
                                    var yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: bottomYPosition)
                                    
//                                    if WaterFallHelperFunction.isCascade(entry: layer.chartEntry!) {
//                                        yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: 0)
//                                    }
                                    
                                    if layer.barDataSet?.plotType == .WaterFall && !plotOption.isStacked {

                                        yInterPolator = Interpolator.interpolate(a: layer.barRect!.minY, b: layer.barRect!.maxY)

                                        if layer.chartEntry!.y < 0 {
                                            yInterPolator = Interpolator.interpolate(a: layer.barRect!.minY, b: layer.barRect!.minY)
                                        }
                                    }
                                    
                                    let heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: 0)
                                    
                                    let newRect = CGRect(x: (layer.barRect?.minX)!, y: yInterPolator(percent), width: (layer.barRect?.width)!, height: heightInterpolator(percent))
                                    
                                    let newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: rect)
        
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        
                                        let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: layer,rect: newRect, percent: percent)
                                        
                                        if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: layer.chartEntry!) {
//                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: animationDuration)
                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: animationDuration)
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: { [unowned barChart,self] in
                                
                                if filtered
                                {
                                    BarHelperFunctions.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true, chart: barChart)
                                }else {
                                    barChart.interactionAnimationInProgress = false
                                    
                                    if barChart.plotTypes.contains(.WaterFall) {
                                        WaterFallHelperFunction.enableConnectorLine(chart: barChart)
                                    }
                                    
                                    if barChart.plotTypes.contains(.BoxPlot) {
                                        if let medianLayer = MedianLayer.getMedianLayerForEntry(chart: barChart, entry: (self.startLay?.getBarChartEntry())!) {
                                            medianLayer.opacity(opacityValue: 1)
                                        }
                                    }
                                }
                                
                            })
                        }
                        
                    }
                }
                    // **************************************** Stack Selection End **************************************************************
                else if barChart.lastSelected != nil
                {
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let barHeight = (startLay?.barRect?.size.height)!
                    
                    var animationDuration:TimeInterval = 0
                    
                    // **************************************** Stack Drill  **************************************************************
                    if trans.y <= 0
                    {
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        // Height required to drill
                        let heightToDrill = maxHeight
                        
                        // **************************************** Drill Performed  **************************************************************
                        if abs(trans.y) >= heightToDrill
                        {
                            
                            let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: (barData.dataSets[0]))
                            
                            let baseLineYPosition = barChart.pixelForValues(x: 0, y: baseLineValue, axisIndex: (barData.dataSets[0]).axisIndex).y
                            
                            let percentEnabled = BarHelperFunctions.isStackPercentEnabled(chart: chart)
                            
                            var indexCount = -1
                           
                            guard let lastSelectedEntries = barChart.lastSelected,
                             lastSelectedEntries.count > 0,
                             let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0])
                            else { return  }
                            
                            let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                indexCount += 1
                                
                                let filterLayer = indexToBarLayer[(layer.chartEntry?.x)!]
                                
                                if filterLayer == nil
                                {
                                    CommonHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: 0, duration: 0.75)
                                    continue
                                }
                                
                                let stackValue = (filterLayer?.chartEntry?.y)!
                                
                                let currentDataSetIndex = barData.indexOfDataSet(layer.barDataSet!)
                                
                                // Current Drilled Stack
                                if currentDataSetIndex == lastSelectedDataSetIndex && !percentEnabled
                                {
                                    let aboveBaseLine = (layer.chartEntry?.y)! > baseLineValue
                                    
                                    let yValue:CGFloat
                                    
                                    if aboveBaseLine
                                    {
                                        yValue = baseLineYPosition - (layer.barRect?.height)!
                                    }
                                    else{
                                        yValue = baseLineYPosition
                                    }
                                    
                                    let newRect = CGRect(x: (layer.barRect?.minX)!, y: yValue, width: (layer.barRect?.width)!, height: (layer.barRect?.height)!)
                                    
                                    let toPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (layer.barRect?.minX)!, y: yValue, width: (layer.barRect?.width)!, height: (layer.barRect?.height)!))
                                    
                                    //                                    BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: toPath, chart: barChart, duration: 1)
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: toPath, duration: 1)
                                    
                                }
                                else if stackValue.isNaN || stackValue == 0
                                {
                                    CommonHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: 0, duration: 0.75)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(1)*CGFloat(1000))), execute: { [unowned barChart,barData] in
                                
                                var setArray:[IChartDataSet] = []
                                for index in 0..<(barData.dataSets.count)
                                {
                                    let dataset = barData.dataSets[index]
                                    if dataset.isVisible && index != lastSelectedDataSetIndex
                                    {
                                        setArray.append(dataset)
                                    }
                                }
                                barChart.lastSelected = nil
                                //CommonHelperFunctions.hideDataSet(selectedDataset: setArray, chart: chart)
                                
                                ChartInteractionHelperFunction.hideDataSetWithAnimation(barChart: barChart, selectedDataset: setArray, animationOptions: .StackedBaralign, animationDuration: 0.3)
                                
                            })
                            
                        }
                            // **************************************** Drill Reverted  **************************************************************
                        else{
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let barPath = layer.getPath(rect: layer.barRect!)//UIBezierPath(rect:layer.barRect!)
                                //                                BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: barPath, chart: barChart, duration: 0)
                                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: 0)
                            }
                        }
                        
                    }
                        
                        // **************************************** Stack Filter  **************************************************************
                    else
                    {
                        if vel.y > 1200
                        {
                            trans.y = barHeight
                            animationDuration = 0.2
                        }
                        else if dist > (barHeight / 2 ) &&  dist <= (barHeight )
                        {
                            trans.y = barHeight
                            animationDuration = 0.2
                        }
                        else if dist >= (barHeight)
                        {
                            trans.y = barHeight
                            animationDuration = 0
                        }
                        else if dist <= (barHeight / 2)
                        {
                            trans.y = 0
                            animationDuration = 0.2
                        }
                        if isStackEntryFilterAllowed(barData: barData)
                        {
                            
                            barChart.interactionAnimationInProgress = true
                            
                            var percent = trans.y / (startLay?.barRect?.height)!
                            if percent > 1
                            {
                                percent = 1
                            }
                            BarHelperFunctions.callGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: percent)
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: { [unowned self,barChart] in
                                
                                let boundingRect = (self.startLay?.path?.boundingBox)!
                                
                                if boundingRect.size.height == 0
                                {
                                    if BarHelperFunctions.isStackPercentEnabled(chart: chart)
                                    {
                                        BarHelperFunctions.callGroupFilterEndAnimation(chartView: barChart, animationDuration: 0.15)
                                        
                                        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(0.15)*CGFloat(1000))), execute: { [unowned self,barChart] in
                                            BarHelperFunctions.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true, chart: barChart)
                                            barChart.setNeedsDisplay()
                                        })
                                    }
                                    else{
                                        BarHelperFunctions.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true, chart: barChart)
                                    }
                                }else {
                                    barChart.interactionAnimationInProgress = false
                                }
                                
                            })
                        }
                        else{
                            return
                        }
                    }
                    
                }
                
                
            }
                // **************************************** Horizontal Pan End **************************************************************
            else{
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.nsuiIsScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
    
    open func getTotalHeightOfSelectedEntry(barChart:ChartViewBase) -> CGFloat
    {
        var height:CGFloat = 0.0
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            if barChart.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
            {
                height = height + (layer.barRect?.size.height)!
            }
        }
        
        return height
    }

    open func distance(from: CGPoint, to: CGPoint) -> CGFloat
    {
        let dx = from.x - to.x
        let dy = from.y - to.y
        return sqrt(dx * dx + dy * dy)
    }
    
    open func isStackEntryFilterAllowed(barData:ChartData) ->  Bool
    {
        if CommonHelperFunctions.getVisibleSetCount(data: barData) == 1
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    open func isGroupFilterAllowed(barChart:ChartViewBase) -> Bool
    {
        let count = barChart.data?.dataSets[0].entryCount
        if (count)! <= 1
        {
            return false
        }
        else
        {
            return true
        }
    }
}
