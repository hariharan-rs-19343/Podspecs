//
//  MultiBarPanHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 27/10/17.
//  Copyright © 2017 zoho. All rights reserved.
//



#if !os(OSX)
    import UIKit
#endif

open class MultiBarPanHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    var sumChange:CGFloat = 0
    
    var baseLineValue = Double(0)
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }
    

    func changeOpacityForOther(barLayer:BarLayer,opacity:CGFloat,width:CGFloat,chart: ChartViewBase)
    {
        
        
        let allLayers = BarLayer.getAllBarLayer(chart: chart)
        
        //chart.data?.setDrawValues(false)
        
        
        for eachBarLayer in allLayers
            
        {
            
            if eachBarLayer == barLayer
            {
                continue
            }
            
            eachBarLayer.opacity = Float(opacity)
            
//            eachBarLayer.path = UIBezierPath(rect: CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!)).cgPath
            
            let newRect = CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!)
            
            let path = eachBarLayer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!))
            
            CommonHelperFunctions.performPathAnim(targetLayer: eachBarLayer, newPath: path, duration: 0)
        }
        
        
    }
    
    func changeOpacityForCurrentDatset(barLayer:BarLayer,opacity:CGFloat,width:CGFloat,chart: ChartViewBase)
    {
        
        let allLayers = BarLayer.getAllBarLayer(chart: chart)
        
        //chart.data?.setDrawValues(false)
        
        let selectedDataSet = chart.data?.getDataSetForEntry(barLayer.chartEntry)
        
        
        for eachBarLayer in allLayers
            
        {
            let curDataSet = chart.data?.getDataSetForEntry(eachBarLayer.chartEntry)
            
            if selectedDataSet === curDataSet && eachBarLayer != barLayer
            {
                
                
                eachBarLayer.opacity = Float(opacity)
                
//                eachBarLayer.path = UIBezierPath(rect: CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!)).cgPath
                
            }
            
        }
        
        
        }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart
        
         guard let plotOption = chart.getPlotOptions(type: .Bar) as? BarPlotOptions
            else { return }
    
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
            sumChange = 0
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: startLoc!)
            lastTouched = startLoc
            
            if startLay != nil
            {
                baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: (barChart.data?.getDataSetForEntry(startLay?.chartEntry))!)
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            // If drag is enabled and we are in a position where there's something to drag:
            //  * If we're zoomed in, then obviously we have something to drag.
            //  * If we have a drag offset - we always have something to drag
           /* if barChart.isDragEnabled &&
                (!barChart.hasNoDragOffset || !barChart.isFullyZoomedOut)
            {
                barChart._isDragging = true
                
                barChart._closestDataSetToTouch = barChart.getDataSetByTouchPoint(point:  recognizer.location(ofTouch: 0, in: barChart))
                
                let translation = recognizer.translation(in: barChart)
                let didUserDrag = (barChart is HorizontalBarChartView) ? translation.y != 0.0 : translation.x != 0.0
                
                // Check to see if user dragged at all and if so, can the chart be dragged by the given amount
                if didUserDrag && !barChart.performPanChange(translation: translation)
                {
                    if barChart._outerScrollView !== nil
                    {
                        // We can stop dragging right now, and let the scroll view take control
                        barChart._outerScrollView = nil
                        barChart._isDragging = false
                    }
                }
                else
                {
                    if barChart._outerScrollView !== nil
                    {
                        // Prevent the parent scroll view from scrolling
                        barChart._outerScrollView?.isScrollEnabled = false
                    }
                }
                
                barChart._lastPanPoint = recognizer.translation(in: barChart)
            }
            else if barChart.isHighlightPerDragEnabled
            {
                // We will only handle highlights on NSUIGestureRecognizerState.Changed
                
                barChart._isDragging = false
            }*/
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            if curLay != nil && (curLay?.chartEntry == startLay?.chartEntry) && verticalMove
            {
                if plotOption.barGroupSelectionEnabled
                {
                    return
                }
                
                for eachBar in BarLayer.getAllValueLayer(chart: chart)
                {
                    eachBar.opacity = 0
                }
                
                trans = recognizer.translation(in: barChart)
                
                if vel.y > 5 || vel.y < -5 {
                    
                    let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
                    sumChange += trans.y
                    
                    
                    if ll != nil
                    {
                        var curY = (ll?.barRect?.minY)!+trans.y
                        let newPath:CGMutablePath!
                        
                        // Filtering
                        if trans.y > 0
                        {
                            // To prevent filter of last dataset
                            if ((barChart.data?.dataSetCount)! - barChart.removedCount) > 1
                            {
                                if (ll?.path?.boundingBox.height)! <  ((ll?.barRect?.height)!/2)
                                {
                                    let curDiff = (ll?.path?.boundingBox.height)! - ((ll?.barRect?.height)!/4)
                                    
                                    let origDiff = (ll?.barRect?.height)!/4
                                    
                                    if curDiff <= 0
                                    {
                                        changeOpacityForCurrentDatset(barLayer: ll!, opacity: 0, width: (ll?.barRect?.width)!, chart: chart)
                                    }
                                    else
                                    {
                                        
                                        let opac = (1/origDiff)*curDiff
                                        changeOpacityForCurrentDatset(barLayer: ll!, opacity: opac, width: (ll?.barRect?.width)!, chart: chart)
                                    }
                                }
                                else{
                                    changeOpacityForCurrentDatset(barLayer: ll!, opacity: 1, width: (ll?.barRect?.width)!, chart: chart)
                                }
                                
                                let height = ((ll?.barRect?.height)! - trans.y) < 0 ? 0 : ((ll?.barRect?.height)! - trans.y)
                                
                                let newRect = CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height)
                                
                                newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height))
                          
                            }
                            else{
                                
                                newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                                
                            }
                        }
                        else{           // Drilling
                            
                            let opac:CGFloat!
                            
                            let curWidth:CGFloat!
                            
                            var height = (ll?.barRect?.height)! + abs(trans.y)
                            
                            
                            // 20 % of viewport height
                            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
                            
                            if abs(trans.y) > maxHeight
                            {
                                height = (ll?.barRect?.height)! + maxHeight
                                
                                curY = (ll?.barRect?.minY)! - maxHeight
                            }
                            
                            let origDiff = maxHeight
                            
                            let curDiff = maxHeight - abs(trans.y)          //(curY - ((ll?.barRect?.minY)! - origDiff))
                            
                            if curDiff < 0
                            {
                                opac = 0
                                curWidth = 0
                            }
                            else
                            {
                                opac = (1/origDiff)*curDiff
                                
                                curWidth =  ((ll?.barRect?.width)!/origDiff)*curDiff
                            }
                            
                            changeOpacityForOther(barLayer: ll!, opacity: opac, width: curWidth, chart: barChart)
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height))

                        }
                        
                        
                        
                      /*  let anim = CABasicAnimation(keyPath: "path")
                        anim.fromValue = ll?.path
                        anim.toValue = newPath.cgPath
                        anim.duration = 0
                        anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                        ll?.add(anim, forKey: "path")
                        ll?.path = newPath.cgPath */
                        
                        CommonHelperFunctions.performPathAnim(targetLayer: ll!, newPath: newPath, duration: 0)
                    }
                }
            }
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                
                if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
                {
                    barChart._isDragging = true
                }
                
                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                {
                    eachBar.opacity = 1
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chart)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    if plotOption.barGroupSelectionEnabled
                    {
                        return
                    }
                    
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }
                    
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            var flag = true
            if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
            // 20 % of viewport height
            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
            
            let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: lastTouched!)
            if verticalMove && ll != nil && startLay != nil  && !barChart._isDragging
            {
                
                if plotOption.barGroupSelectionEnabled
                {
                    return
                }
                
                let selectedDataSet = chart.data?.getDataSetForEntry(ll?.chartEntry)
                let vel = recognizer.velocity(in: barChart)
                var newPath:CGMutablePath!
                let animDur:TimeInterval!
                
                var drilled:Bool = false
                
                
                if ll != nil && startLay != nil{
                
                    // Drill
                    if vel.y < -1200 || ((ll?.path?.boundingBox.height)! > (ll?.barRect?.height)!)
                    {
                        
                        if (ll?.path?.boundingBox.height)! == (ll?.barRect?.height)! + maxHeight || vel.y < -1200
                        {
                            drilled = true
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.maxY)!, width: (ll?.barRect?.width)!, height: plotOption.roundedRadii + 2)
                            
                            newPath = CGMutablePath(rect: newRect, transform: nil)//UIBezierPath(rect: newRect)
                            
                            if let layer = ll{
                                newPath = layer.getPath(rect: newRect)
                            }
                            
                            //                         changeOpacityForOtherBars(barLayer: ll!, chart: barChart, opacity: 0.1, width: 0)
                            
                            for eachBar in BarLayer.getAllBarLayer(chart: chart)
                            {
                                if eachBar == ll
                                {
                                    continue
                                }
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 0, changeSize: CGSize(width: 0, height: (eachBar.barRect?.height)!), chart: chart, duration: 0.4)
                            }
                        }
                        else
                        {
                            flag = false
                            
                            newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                            //                            changeOpacityForOtherBars(barLayer: ll!, chart: barChart, opacity: 1, width: (ll?.barRect?.width)!)
                            for eachBar in BarLayer.getAllBarLayer(chart: chart)
                            {
                                if eachBar == ll
                                {
                                    continue
                                }
                                
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 1, changeSize: CGSize(width: (ll?.barRect?.width)!, height: (eachBar.barRect?.height)!) , chart: chart, duration: 0.4)
                            }
                            
                        }
                   
                        animDur = 0.4
                    }
                    else if vel.y > 1200 || ((ll?.path?.boundingBox.height)! < ((ll?.barRect?.height)!/2))
                    {
                        
                        if ((barChart.data?.dataSetCount)! - barChart.removedCount) > 1
                        {
                            barChart.interactionAnimationInProgress = true
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.maxY)!, width: (ll?.barRect?.width)!, height: plotOption.roundedRadii + 2)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.maxY)!, width: (ll?.barRect?.width)!, height: 0)

                            let opacityAnimator = Animator()
                            
                            opacityAnimator.updateBlock = { [unowned chart] in
                                
                                for eachBar in BarLayer.getAllBarLayer(chart: chart)
                                {
                                    let barOpacity = Interpolator.interpolate(a: Double((eachBar.opacity)), b: 0)
                                    
                                    let curDataSet = chart.data?.getDataSetForEntry(eachBar.chartEntry)
                                    
                                    if selectedDataSet === curDataSet && eachBar != ll
                                    {
                                    
                                    eachBar.opacity = Float(barOpacity(opacityAnimator.phaseX))
                                        
                                    }
                                }
                            }
                            
                            opacityAnimator.stopBlock = { [unowned opacityAnimator] in
                                opacityAnimator.updateBlock = nil
                            }
                            
                            let dur:TimeInterval!
                            
                            if (ll?.path?.boundingBox.height)! < ((ll?.barRect?.height)!/2)
                            {
                                dur = 0.3
                                animDur = 0.5
                            }
                            else{
                                dur = 0.7
                                animDur = 0.9
                            }
                            
                            opacityAnimator.animate(xAxisDuration: dur, easingOption: .linear)
                        }
                        else{
                            
                            flag = false
                            newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                            animDur = 1
                        }
                        
                    }
                    else{
                        
                        flag = false
                        newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                        animDur = 1
                    }
                    
                   /* CATransaction.begin()
                    let anim = CABasicAnimation(keyPath: "path")
                    anim.fromValue = ll?.path
                    anim.toValue = newPath.cgPath
                    anim.duration = animDur
                    anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                    CATransaction.setCompletionBlock({
                        if flag{
                            barChart.updateDataOrigIndex()
                            if drilled
                            {
                                barChart.drillEntry(barEntry: ll?.chartEntry as! ChartDataEntry)
                            }
                            else                
                            {
                                barChart.removedCount += 1
                                
                                barChart.removeEntry(barEntry: ll?.chartEntry as! ChartDataEntry, defaultAnimation: true)
                            }
                            }
                        else{
                            for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                            {
                                eachBar.opacity = 1
                            }
                        }
                    })
                    
                    ll?.add(anim, forKey: "path")
                    CATransaction.commit()
                    ll?.path = newPath.cgPath */
                    
                    let completionBlock = { [unowned chart] in
                        
                        if flag{
                            
                            barChart.updateDataOrigIndex()
                            if drilled
                            {
                                BarHelperFunctions.drillEntry(barEntry: (ll?.chartEntry)!, chart: chart)
                            }
                            else
                            {
                                barChart.removedCount += 1
                                
                                BarHelperFunctions.removeEntry(barEntry: (ll?.chartEntry)!, defaultAnimation: true, chart: chart)
                            }
                        }
                        else{
                            for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                            {
                                eachBar.opacity = 1
                            }
                        }
                    }
                    CommonHelperFunctions.performPathAnim(targetLayer: ll!, newPath: newPath, duration: animDur, completionBlock: completionBlock)
                }
                
                
            }
            else{
                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                {
                    eachBar.opacity = 1
                }
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.nsuiIsScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
}

