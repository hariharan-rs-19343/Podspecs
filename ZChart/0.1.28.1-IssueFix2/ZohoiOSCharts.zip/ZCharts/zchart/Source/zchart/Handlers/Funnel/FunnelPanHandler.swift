//
//  FunnelPanHandler.swift
//  zchart
//
//  Created by Aravinth T on 11/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class FunnelPanHandler: NSObject, EventHandler {

    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    var initLayer:FunnelLayer? = nil
    var textLayer:CATextLayer? = nil
    
    var maxTransLimit:CGFloat = 100
    
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        
        let funnelChart = chartView
        let vel = recognizer.velocity(in: funnelChart)
        let translation = recognizer.translation(in: funnelChart)
        
        guard funnelChart.data != nil
            else { return }

        if getValidEntryCount(funnelChart: funnelChart) == 1 {
            return
        }
        
        
        if recognizer.state == NSUIGestureRecognizerState.began {
            
            maxTransLimit = funnelChart.viewPortHandler.contentWidth * (40/100)
            Log.info("Max Translimit \(maxTransLimit)")
            resetInitLayer()
            setInitLayer(chart: funnelChart, entryLayer: entryLayer)
            
        }  else if recognizer.state == NSUIGestureRecognizerState.changed {
            
            setInitLayer(chart: funnelChart,entryLayer: entryLayer)
            
            if initLayer != nil {
                
                let newPath = getPathForFunnelPointAndTranslation(layer: initLayer!, transXVal: translation.x)
                let newopacity = getNewOpacityValue(translationX: translation.x)
                
                
                self.perforPathAndOpacityAnimation(targetLayer: initLayer!, finalPath: newPath, duration: 0, opacity: newopacity, completionBlock: nil)
            }
            
        } else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled {
            
            if initLayer != nil {
                
                
                if abs(translation.x) > maxTransLimit || abs(vel.x) > 1200 {
                    
                    funnelChart.interactionAnimationInProgress = true
                    
                    var transXVal = translation.x
                    
                    if abs(translation.x) > maxTransLimit {
                        transXVal = translation.x
                    } else {
                        transXVal = (translation.x > 0) ? maxTransLimit : (-maxTransLimit)
                    }
                    
                    let newPath = getPathForFunnelPointAndTranslation(layer: initLayer!, transXVal: transXVal)
                    
                    let newopacity = getNewOpacityValue(translationX: transXVal)
                    
                    let completionBlock = { [unowned self,funnelChart] in
                        FunnelHelperFunctions.removeEntryAndAnimateOtherLayers(layersToRemove: [self.initLayer!], funnelChart: funnelChart)
                    }
                    
                    self.perforPathAndOpacityAnimation(targetLayer: initLayer!, finalPath: newPath, duration: 0, opacity: newopacity, completionBlock: completionBlock)
                    
                    
                }else {
                    
                    let newPath = getPathForFunnelPointAndTranslation(layer: initLayer!, transXVal: 0)
                    self.perforPathAndOpacityAnimation(targetLayer: initLayer!, finalPath: newPath, duration: 0.1, opacity: Float(1.0), completionBlock: nil)
                    
                }
                
            }
            
        }
        
        
    }
    
    func getPathForFunnelPointAndTranslation(layer:FunnelLayer, transXVal:CGFloat) -> CGMutablePath {
        
        let funnelPoint = (layer.funnelSlicePoint)!
        let points = funnelPoint.points
        var newPoints:[CGPoint] = []
        for var point in points {
            point.x = point.x + transXVal
            newPoints.append(point)
        }
        let newPath = FunnelLayer.getBezeirPath(cgPoints: newPoints)
        return newPath
    }
    
    func getNewOpacityValue(translationX:CGFloat) -> Float {
        let transX = abs(translationX)
        return Float(1.0 - (transX / maxTransLimit))
    }
    
    func resetInitLayer() {
        self.initLayer = nil
        self.textLayer = nil
    }
    
    func setInitLayer(chart:ChartViewBase, entryLayer: ChartEntryLayer?) {
        if initLayer == nil && entryLayer != nil {
            initLayer = entryLayer as? FunnelLayer
            textLayer = FunnelLayer.getFunnelValueLayerForIndex(chart: chart, index: (initLayer?.getEntryIndex())!)
        }
    }
   
    func getValidEntryCount(funnelChart: ChartViewBase) -> Int {
        
        let dataSet = funnelChart.data?.dataSets[0] as! ChartDataSet
        
        let validEntries = FunnelChartRenderer.getValidEntries(entries: dataSet.values)
        
        return validEntries.count
    }
    
    
    func perforPathAndOpacityAnimation(targetLayer:ChartEntryLayer, finalPath:CGMutablePath, duration:TimeInterval, opacity:Float, completionBlock: (() -> Void)?) {
        CommonHelperFunctions.performPathAnim(targetLayer: initLayer!, newPath: finalPath, duration: duration, completionBlock: completionBlock)
        CATransaction.begin()
        self.initLayer?.opacity = opacity
        if self.textLayer != nil {
            self.textLayer?.opacity = opacity
        }
        CATransaction.commit()
    }
    
}
