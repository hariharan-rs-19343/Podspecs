//
//  HeatMapPinchHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 29/08/19.
//  Copyright © 2019 zoho. All rights reserved.
//

open class HeatMapPinchHandler:NSObject,EventHandler
{
    
    open var xDrillState:Bool = false
    
    open var yDrillState:Bool = false
    
    open var drillStateMatrix:CGAffineTransform? = nil
    
    var scaledMatrix:CGAffineTransform? = nil
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.zoomInOut
    }
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint)
    {
        let barLineChart = chartView
        
        let recognizer = recognizer as! NSUIPinchGestureRecognizer
        
        
        // width for single point
        let currentWidth:CGFloat =  CommonHelperFunctions.getOnePointWidth(chart: barLineChart)
        
        let currentHeight:CGFloat =  CommonHelperFunctions.getOnePointHeight(chart: barLineChart, axis: barLineChart.getYAxisArray()[0])
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            barLineChart.stopDeceleration()
            
            if barLineChart._data !== nil &&
                (barLineChart.pinchZoomEnabled || barLineChart.scaleXEnabled || barLineChart.scaleYEnabled)
            {
                barLineChart._isScaling = true
                
                if barLineChart.pinchZoomEnabled
                {
                    barLineChart._gestureScaleAxis = .both
                }
                else
                {
//                    let x = abs((recognizer.location(in: barLineChart).x) - (recognizer.location(ofTouch: 1, in: barLineChart).x))
//                    let y = abs((recognizer.location(in: barLineChart).y) - (recognizer.location(ofTouch: 1, in: barLineChart).y))
                    
                    var touchLoaction = CGPoint()
                    
                    #if os(iOS)
                        touchLoaction = recognizer.numberOfTouches > 0 ? recognizer.nsuiLocationOfTouch(1, inView: barLineChart) : touchLoaction
                    #endif
                    
                    let x = abs((recognizer.location(in: barLineChart).x) - touchLoaction.x)
                    let y = abs((recognizer.location(in: barLineChart).y) - touchLoaction.y)
                    
                    if barLineChart.scaleXEnabled != barLineChart.scaleYEnabled
                    {
                        barLineChart._gestureScaleAxis = barLineChart.scaleXEnabled ? .x : .y
                    }
                    else
                    {
                        barLineChart._gestureScaleAxis = x > y ? .x : .y
                    }
                }
            }
            
            /// Since translation should be allowed on zoom restriction
            if drillStateMatrix != nil
            {
                if xDrillState
                {
                    drillStateMatrix?.tx = barLineChart.viewPortHandler.touchMatrix.tx
                }
                
                if yDrillState
                {
                    drillStateMatrix?.ty = barLineChart.viewPortHandler.touchMatrix.ty
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let widthToAttain = (barLineChart.viewPortHandler.contentWidth * 0.40)       // CGFloat(100)
            
            let heightToAttain = (barLineChart.viewPortHandler.contentHeight * 0.40)    // CGFloat(100)
            
            if (currentWidth >= widthToAttain && barLineChart._gestureScaleAxis == .x)
            {
                if xDrillState == false
                {
                    ChartUtils.longPressSound()
                    xDrillState = true
                    
                    if drillStateMatrix == nil
                    {
                        drillStateMatrix = barLineChart.viewPortHandler.touchMatrix
                    }
                    else{
                        drillStateMatrix?.a = barLineChart.viewPortHandler.touchMatrix.a
                        drillStateMatrix?.tx = barLineChart.viewPortHandler.touchMatrix.tx
                    }
                }
                
            }
            else if (currentHeight >= heightToAttain && barLineChart._gestureScaleAxis == .y)
            {
                if yDrillState == false
                {
                    ChartUtils.longPressSound()
                    yDrillState = true
                    
                    if drillStateMatrix == nil
                    {
                        drillStateMatrix = barLineChart.viewPortHandler.touchMatrix
                    }
                    else{
                        drillStateMatrix?.d = barLineChart.viewPortHandler.touchMatrix.d
                        drillStateMatrix?.ty = barLineChart.viewPortHandler.touchMatrix.ty
                    }
                }
            }
            else{
                
                xDrillState = false
                yDrillState = false
                
                drillStateMatrix = nil
            }
       

                let returnMatrix = CommonHelperFunctions.performPinch(recognizer: recognizer, chart: barLineChart)
                barLineChart.updatePadding()
                if returnMatrix != nil{
                    scaledMatrix = returnMatrix
                }

            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended ||
            recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            if barLineChart._isScaling
            {
                if xDrillState || yDrillState
                {
                    var needToAnimateX = true
                    var needToAnimateY = true
                    
                    if ((scaledMatrix?.a)! < (drillStateMatrix?.a)! && xDrillState)
                    {
                        drillStateMatrix?.a = scaledMatrix!.a
                        drillStateMatrix?.tx = scaledMatrix!.tx
                        needToAnimateX = false
                    }
                        
                    if ((scaledMatrix?.d)! < (drillStateMatrix?.d)! && yDrillState)
                    {
                        drillStateMatrix?.d = scaledMatrix!.d
                        drillStateMatrix?.ty = scaledMatrix!.ty
                        needToAnimateY = false
                    }
                    
                    if needToAnimateX || needToAnimateY
                    {
                        let scaleAnimator = Animator()
                        
                        let scaleXInterpolator = Interpolator.interpolate(a: (scaledMatrix?.a)!, b: (drillStateMatrix?.a)!)
                        let scaleYInterpolator = Interpolator.interpolate(a: (scaledMatrix?.d)!, b: (drillStateMatrix?.d)!)
                        let translateXInterpolator = Interpolator.interpolate(a: (scaledMatrix?.tx)!, b: (drillStateMatrix?.tx)!)
                        let translateYInterpolator = Interpolator.interpolate(a: (scaledMatrix?.ty)!, b: (drillStateMatrix?.ty)!)
                        
                        scaleAnimator.updateBlock = { [unowned barLineChart] in
                            var matrix = self.scaledMatrix
                            
                            if self.xDrillState && needToAnimateX
                            {
                                matrix?.a = scaleXInterpolator(CGFloat(scaleAnimator.phaseX))
                                matrix?.tx = translateXInterpolator(CGFloat(scaleAnimator.phaseX))
                            }
                            
                             if self.yDrillState && needToAnimateY
                            {
                                matrix?.d = scaleYInterpolator(CGFloat(scaleAnimator.phaseX))
                                matrix?.ty = translateYInterpolator(CGFloat(scaleAnimator.phaseX))
                            }
                            
                            let _ = barLineChart._viewPortHandler.refresh(newMatrix: matrix!, chart: barLineChart, invalidate: true)
                            barLineChart.updatePadding()
                        }
                        
                        scaleAnimator.stopBlock = { [unowned scaleAnimator] in
                            scaleAnimator.updateBlock = nil
                            
                        }
                        
                        scaleAnimator.animate(xAxisDuration: 0.2)
                    }
                }
                
                barLineChart._isScaling = false
                
//                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: barLineChart)
                
                // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
                barLineChart.calculateOffsets()
                barLineChart.setNeedsDisplay()
                
            }
        }
    }
    
    
    func isInBounds(barLineChart:ChartViewBase, xIndex:Double)-> Bool
    {
        let location = barLineChart.pixelForValues(x: xIndex, y: 10, axisIndex: 0)
        
        if barLineChart.viewPortHandler.isInBoundsX(location.x)
        {
            return true
        }
        else{
            return false
        }
        
    }
    
    public func onNoDrill(_ chartView: ChartViewBase, stateMatrix:CGAffineTransform?){
        
        let scaleAnimator = Animator()
        
        if stateMatrix == nil || scaledMatrix == nil {
            return
        }
        
        let scaleInterpolator = Interpolator.interpolate(a: (scaledMatrix?.a)!, b: (stateMatrix?.a)!)
        
        let translateInterpolator = Interpolator.interpolate(a: (scaledMatrix?.tx)!, b: (stateMatrix?.tx)!)
        
        scaleAnimator.updateBlock = { [unowned chartView] in
            
            var matrix = self.scaledMatrix
            
            matrix?.a = scaleInterpolator(CGFloat(scaleAnimator.phaseX))
            
            matrix?.tx = translateInterpolator(CGFloat(scaleAnimator.phaseX))
            
            let _ = chartView._viewPortHandler.refresh(newMatrix: matrix!, chart: chartView, invalidate: true)
            
        }
        
        scaleAnimator.stopBlock = { [unowned scaleAnimator] in
            scaleAnimator.updateBlock = nil
        }
        
        scaleAnimator.animate(xAxisDuration: 0.5)
        
    }
    
}

