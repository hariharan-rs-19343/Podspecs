//
//  TouchHandler.swift
//  zchart
//
//  Created by Aravinth T on 11/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

@objc
public enum TouchHandlerType: Int
{
    case rotation
    case custom
}

@objc
public protocol TouchHandler: NSObjectProtocol {

     @objc func getTouchHandlerType() -> TouchHandlerType
    
    @objc func touchEventBegan(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?,_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    
    @objc func touchEventMoved(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?,_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    
    @objc func touchEventEnded(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?,_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)

    @objc optional  func touchEventCancelled(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?,_ touches: Set<NSUITouch>, withEvent event: NSUIEvent?)
    
}
