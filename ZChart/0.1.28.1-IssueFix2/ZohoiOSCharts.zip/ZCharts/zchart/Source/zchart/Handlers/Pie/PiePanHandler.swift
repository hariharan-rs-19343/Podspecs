//
//  PiePanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 13/06/18.
//  Copyright © 2018 charts. All rights reserved.
//


#if !os(OSX)
    import UIKit
#endif

open class PiePanHandler: NSObject,EventHandler
{
    var sliceRadiusChange:CGFloat = 0
    var oldLayer:PieLayer? = nil
    var startLocation = CGPoint()
    
    
    var high:Highlight? = Highlight()

    var angle:CGFloat = 0
    var dist:CGFloat = 0
    var distcal:CGFloat = 0
    var startAngle:CGFloat = 0
    var totAngle:CGFloat = 0
    var angleLength:CGFloat = 0
    var absAngle:CGFloat = 0
    
    
    var sliceDisplayLink:NSUIDisplayLink!
    var changingFactor:CGFloat = 1
    
    var filterLayer :PieLayer? = nil
    var filterhigh :Highlight? = Highlight()
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        var (selectedHigh, selectedEntry) = CommonHelperFunctions.getHighAndEntryForRecognizer(chart: chartView, recognizer: recognizer!)
        
        let pieChart = chartView
      
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }

        let selectedLayer:PieLayer? = entryLayer as? PieLayer
        
        let thresholdForDrill = piePlot.radius/8
        
//        if(PieLayer.getAllPieLayer(chart: pieChart).count <= 1)
//        {
//            pieChart.lastSelected = nil
//           pieChart.callDelegateToContainer(highlight: nil, entry: nil)
//            return
//        }
//
        
        
        if recognizer?.state == NSUIGestureRecognizerState.began
        {
            
            if selectedHigh == nil || selectedEntry == nil { return }
            
            /// To Calculate Velocity of Gestures
            PieHelperFunctions.resetVelocity(chart: pieChart)
            PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: startLocation)
            
            changingFactor = 0
            
            if pieChart.lastSelected != nil && pieChart.lastSelected!.count > 0
            {
                let entry = pieChart.lastSelected![0]
                entry.filterEnabled = false
                if entry === selectedEntry
                {
                    changingFactor = thresholdForDrill
                }
                else{
                    
                    let lastSelectedLayer = PieLayer.getPieLayerForEntry(chart: pieChart, entry: entry)
                    PieHelperFunctions.sliceIn(sliceLayer: lastSelectedLayer!, chart: pieChart, duration: 0.2, completionBlock: nil)
                }
                pieChart.lastSelected = nil
                pieChart.callDelegateToContainer(highlight: nil, entry: nil)
            }
            
            sliceRadiusChange = piePlot.radius
            
            startLocation = touchLocation
            
            oldLayer = selectedLayer
            
            high = selectedHigh
            
            for layer in PieLayer.getAllPieValueLayer(chart: pieChart)
            {
                layer.opacity = 0
            }
                
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.changed
        {
            
            
            if oldLayer == nil { return }
            
            let changeLocation = (recognizer?.location(in: pieChart))!
            
            let chartEntry = oldLayer?.chartEntry
            
            angle = PieHelperFunctions.getMidAngle(chart: pieChart, entry: chartEntry!)
            
            if  ((315 < angle  && angle <= 360)||(0 <= angle && angle <= 45) )
            {
                changingFactor = changingFactor + (changeLocation.x - startLocation.x)
            }
            else if  (45 < angle  && angle <= 135 )
            {
                changingFactor = changingFactor + (changeLocation.y - startLocation.y)
            }
            else if  (135 < angle  && angle <= 225)
            {
                changingFactor = changingFactor - (changeLocation.x - startLocation.x)
            }
            else if  (225 < angle  && angle <= 315 )
            {
                changingFactor = changingFactor - (changeLocation.y - startLocation.y)
            }
            
            if PieLayer.getAllPieLayer(chart: pieChart).count <= 1
            {
                changingFactor = abs(PieHelperFunctions.distance(from: startLocation, to: changeLocation))
                sliceRadiusChange = piePlot.radius + changingFactor
                PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: 0, fromRadius: piePlot.radius, toRadius: sliceRadiusChange, pieCenter: piePlot.centerCircleBox, completionBlock: nil)
                
                return
            }
            /// Filter
            if(changingFactor < 0)
            {
                if changingFactor < -piePlot.radius
                {
                    changingFactor = -piePlot.radius
                }
                
                sliceRadiusChange = piePlot.radius + changingFactor
                
                filterLayer = oldLayer
                filterhigh = high
                
                PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: 0, fromRadius: piePlot.radius, toRadius: sliceRadiusChange, pieCenter: piePlot.centerCircleBox, completionBlock: nil)
                
                changingFactor = 0.0
            }
            else{
                sliceRadiusChange = piePlot.radius + changingFactor
                
                if(changingFactor <= thresholdForDrill)
                {
                    let newx = piePlot.centerCircleBox.x + (changingFactor) * cos(angle.radians())
                    
                    let newy = piePlot.centerCircleBox.y + (changingFactor) * sin(angle.radians())
                    
                    PieHelperFunctions.sliceMove(sliceLayer: oldLayer!, high: high!, chart: pieChart, duration: 0, nx:newx, ny:newy, completionBlock: nil)
                }
                else
                {
                    sliceRadiusChange -= thresholdForDrill
                    
                    let newx = piePlot.centerCircleBox.x + thresholdForDrill * cos(angle.radians())
                    
                    let newy = piePlot.centerCircleBox.y + thresholdForDrill * sin(angle.radians())
                    
                    PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: 0, fromRadius: piePlot.radius, toRadius: sliceRadiusChange, pieCenter: CGPoint(x: newx, y: newy), completionBlock: nil)
                    
                }
                startLocation = changeLocation
            }
            
            
            PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: changeLocation)
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.ended
        {
            if oldLayer == nil {
                return
            }
            
            let oldEntry = oldLayer?.chartEntry
            
            let endLocation = (recognizer?.location(in: pieChart))!
            
            PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: endLocation)
            
            let velocityCalculated = PieHelperFunctions.calculateVelocity(chart: pieChart)
            
//            if PieLayer.getAllPieLayer(chart: pieChart).count <= 1
//            {
//
//                PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: 0, fromRadius: pieChart.radius, toRadius: sliceRadiusChange, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
//
//                return
//            }
            
            ///Filter
            if  sliceRadiusChange < (piePlot.radius-20) && PieLayer.getAllPieLayer(chart: pieChart).count > 1
            {
                let completionBlock = { [unowned pieChart,self] in
                    PieHelperFunctions.deleteSliceWithNoFill(sliceLayer: self.filterLayer!, high: self.filterhigh!, chart: pieChart, duration: 0.3, animation: .linear)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(400), execute: { [unowned pieChart] in
                        self.filterLayer?.chartEntry?.layerEnabled = false
                        pieChart.highlightValue(nil, callDelegate: true)
                        if (pieChart.data?.valuesEnabled)! {
                            pieChart.data?.setDrawValues(true)
                        }
                    })
                }
                
                PieHelperFunctions.changeRadiusAnimator(sliceLayer: filterLayer!, chart: pieChart, duration: 0.3, fromRadius: sliceRadiusChange, toRadius: 0, pieCenter: piePlot.centerCircleBox, completionBlock: completionBlock)
                
            }
            /// Drill
            else if ((velocityCalculated > 20 && changingFactor > (piePlot.radius/4)) || (PieHelperFunctions.distance(from: piePlot.centerCircleBox , to: endLocation) >= piePlot.radius))
            {
                
                for layer in PieLayer.getAllPieLayer(chart: pieChart)
                {
                    if layer != oldLayer
                    {
                        PieHelperFunctions.changeRadiusAnimator(sliceLayer: layer, chart: pieChart, duration: 0.3, fromRadius: piePlot.radius, toRadius: 0, pieCenter: piePlot.centerCircleBox, completionBlock: nil)
                        
                    }
                    else
                    {
                        PieHelperFunctions.sliceIn(sliceLayer: layer, chart: pieChart, duration: 0.3, completionBlock: nil)

                    }
                }
                
                
                DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(400), execute: { [unowned pieChart] in
                    
                    oldEntry?.layerEnabled = false
                    pieChart.setNeedsDisplay()
                    if (pieChart.data?.valuesEnabled)! {
                        pieChart.data?.setDrawValues(true)
                    }
                    pieChart.drillEntry(selectedEntry: oldEntry!)
                    
                })
                
            }
            else{
                
                selectedEntry = oldLayer?.chartEntry
                
                let completionBlock = { [unowned pieChart] in
                  
                    selectedEntry?.layerEnabled = false
                    
                    if (pieChart.data?.valuesEnabled)!
                    {
                        pieChart.data?.setDrawValues(true)
                    }
                    
                    pieChart.callDelegateToContainer(highlight: nil, entry: nil)
                    
                    pieChart.setNeedsDisplay()
                 
                    self.oldLayer = nil
                }
                
                PieHelperFunctions.sliceIn(sliceLayer: oldLayer!, chart: pieChart, duration: 0.3, completionBlock: completionBlock)
            }
        }
        
    }
    
}




