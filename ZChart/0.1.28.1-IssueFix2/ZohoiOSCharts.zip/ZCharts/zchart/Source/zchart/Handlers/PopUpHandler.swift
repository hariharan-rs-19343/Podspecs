//
//  PopUpHandler.swift
//  zchart
//
//  Created by keerthi-pt4274 on 16/05/22.
//

import Foundation

open class popUpHandler: NSObject,EventHandler {
    
    open var shapeProperties: ShapeProperties?
    
    var label: String?
    
    open var offSet = CGPoint()
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        CommonHelperFunctions.removeHighlightLayer(chart: chartView)
        
        if chartView.viewPortHandler.isInBounds(x: touchLocation.x, y: touchLocation.y) {
                
            if let layer = entryLayer, let entry = entry {
                    
                let position = CGPoint(x: layer.path!.boundingBox.midX, y: layer.path!.boundingBox.minY)
                    
                reloadPopUpView(chart: chartView, entry: entry, position: position)
            }
        }
    }
    
    internal func reloadPopUpView(chart: ChartViewBase,entry: ChartDataEntry,position: CGPoint) {
        
        setUpLabel(entry: entry)
        
        let offsetPos = calculateOffSet(chart: chart, position: position)
        
        drawPopUp(chart: chart,layer: HighlightLayer(),position: offsetPos)
        
    }
    
    open func calculateOffSet(chart: ChartViewBase, position: CGPoint) -> CGPoint {
        
        guard let shapeProperties = shapeProperties else {
            return CGPoint()
        }
        
        let size = shapeProperties.size
        
        let offPoint = CGPoint(x: position.x - offSet.x, y: position.y - (size.height / 2) - offSet.y)
        
        return offPoint
    }
    
    open func setUpLabel(entry: ChartDataEntry) {
        label = entry.xString
    }
    
    open func drawPopUp(chart: ChartViewBase, layer: HighlightLayer, position: CGPoint) {
        
        guard let shapeProperties = shapeProperties else {
            return
        }
        
        let size = shapeProperties.size
        
        let origin = CGPoint(x: position.x - (size.width / 2.0), y: position.y - (size.height / 2.0))
        
        layer.frame = CGRect(origin: origin, size: CGSize(width: size.width, height: size.height + offSet.y))
        
        let baseLayer = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProperties, point: CGPoint(x: size.width/2.0, y: size.height/2.0), strokeColor: shapeProperties.strokeColor!.cgColor, currentLayer: CAShapeLayer())
        
        baseLayer.frame = CGRect(origin: CGPoint(), size: size)
        
        let textLayer = CATextLayer()
        
        textLayer.string = label
        
        textLayer.foregroundColor = NSUIColor.black.cgColor
        
        textLayer.fontSize = CGFloat(11.0)
        
        textLayer.alignmentMode = .center
        
        textLayer.frame = CGRect(origin: baseLayer.frame.origin, size: size)
        
        baseLayer.sublayers = [textLayer]

        layer.sublayers = [baseLayer]
        
        CommonHelperFunctions.addHighlightLayer(chart: chart, layer: layer)
    }
    
}

extension popUpHandler: ShapeFactoryDataSource {
    
    public func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer: CAShapeLayer) -> CGMutablePath {
        
        let path = CGMutablePath()
        
        let size = shapeInstance.size
        
        let x = point.x - size.width / 2.0
        let y = point.y - size.height / 2.0
        let width = size.width
        
        let height = (size.height - 10.0)
        let leftbottomHalf = point.x + 10.0
        let rightbottomHalf = point.x - 10.0
        
        path.move(to: CGPoint(x: x, y: y))
        path.addLine(to: CGPoint(x: x+width, y: y))
        path.addLine(to: CGPoint(x: x+width, y: y+height))
        path.addLine(to: CGPoint(x: leftbottomHalf, y: y+height))
        path.addLine(to: CGPoint(x: point.x, y: point.y + (size.height) / 2.0))
        path.addLine(to: CGPoint(x: rightbottomHalf, y: y+height))
        path.addLine(to: CGPoint(x: x, y: y+height))
                
        path.closeSubpath()//.close()
                
        return path
    }
}
