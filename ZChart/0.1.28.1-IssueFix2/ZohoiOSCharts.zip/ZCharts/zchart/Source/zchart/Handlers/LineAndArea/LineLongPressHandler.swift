//
//  LineLongPressHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 27/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif
#if os(iOS) || os(tvOS)
open class LineLongPressHandler: NSObject, EventHandler {
    
    
    var verticalMove:Bool = true
    
    var startHigh:Highlight? = nil
    
    var curHigh:Highlight? = nil
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.lineLongPress
    }
    

    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUILongPressGestureRecognizer
        let lineChart = chart
        
        if entry == nil{ 
            lineChart.resetHighlight()
            lineChart.lastSelected = nil
            return
        }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            verticalMove = true
            
            CommonHelperFunctions.removeHighlightLayer(chart: chart)
            
            let curLoc = recognizer.location(in: lineChart)
            startHigh = chart.getHighlightByTouchPoint(curLoc)
   
            if lineChart.lastSelectedHigh == nil
            {
            lineChart.updateLastSelectedEntry(entry: entry)
            LineHelperFunctions.magnifyDataSet(chart: lineChart, dataSetIndex:(startHigh?.dataSetIndex)!)
            lineChart.datasetSelected = true
            
            }
            
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let curLoc = recognizer.location(in: lineChart)
            curHigh = chart.getHighlightByTouchPoint(curLoc)
            
            if startHigh?.x == curHigh?.x && verticalMove || lineChart.lastSelectedHigh != nil
            {
                
                
            if lineChart.lastSelectedHigh == nil{
                
                lineChart.updateLastSelectedEntry(entry: entry)
                
                LineHelperFunctions.magnifyDataSet(chart: lineChart, dataSetIndex:(curHigh?.dataSetIndex)!)
                
                lineChart.datasetSelected = true
                
                let entryToHighlight = chart.entryForHighlight(curHigh!)

                chart.callDelegateToContainer(highlight: curHigh, entry: entryToHighlight!)
            }
            else{
                
                let lastSelectedSet = lineChart.data?.dataSets[(lineChart.lastSelectedHigh?.dataSetIndex)!]
                let highlightEntry = lastSelectedSet?.entryForXValue((curHigh?.x)!, closestToY: (curHigh?.y)!)
            
                if highlightEntry != nil
                {
                    LineHelperFunctions.highlightCurrentDatasetEntry(entry: highlightEntry!, chart: chart )
                    chart.callDelegateToContainer(highlight: lineChart.lastSelectedHigh, entry: highlightEntry)
                }
            }
          
            }
            else
            {
                if verticalMove
                {
                    LineHelperFunctions.removeMagnifyEffect(chart: lineChart)
                }
                verticalMove = false
                
                let entry = chart.entryForHighlight(curHigh!)
                
                LineHelperFunctions.highlightAllDatasetEntry(entry: entry!, chart: chart , includeVerticalLine: true)
                
                chart.callDelegateToContainer(highlight: curHigh, entry: entry)
                
            }

            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            let curLoc = recognizer.location(in: lineChart)
            curHigh = chart.getHighlightByTouchPoint(curLoc)
            
            if lineChart.lastSelectedHigh == nil && verticalMove {
                lineChart.lastSelectedHigh = curHigh
            }
        }
        
    }
 
}

#endif
