//
//  PieArrowLongPressHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 26/10/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class PieArrowLongPressHandler: NSObject,EventHandler
{
    var pieRadChange:CGFloat = 0
    var oldEntry : ChartDataEntry? = nil
    var oldLayer:PieLayer? = nil
    var high:Highlight? = Highlight()
    var oldhigh:Highlight? = Highlight()
    var angle:CGFloat = 0
    var dist:CGFloat = 0
    var distcal:CGFloat = 0
    var startAngle:CGFloat = 0
    var totAngle:CGFloat = 0
    var angleLength:CGFloat = 0
    var absAngle:CGFloat = 0
    var location:CGPoint = CGPoint()
    
    var dataInd:Int = 0
    
    unowned var pieChartInstance:ChartViewBase
    var sliceDisplayLink:NSUIDisplayLink!
    var changingFactor:CGFloat = 1
    
    var filterLayer :PieLayer? = nil
    var filterhigh :Highlight? = Highlight()
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public override init() {
        
        let pieChartInstance = ChartViewBase()
        
        self.pieChartInstance = pieChartInstance
        
        super.init()
    }
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        
        var (selectedHigh, selectedEntry) = CommonHelperFunctions.getHighAndEntryForRecognizer(chart: chartView, recognizer: recognizer!)
        
        
        let pieChart = chartView
        
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        let selectedLayer:PieLayer? = entryLayer as? PieLayer
        
        pieChartInstance = chartView
        
        
        if(PieLayer.getAllPieLayer(chart: pieChart).count <= 1)
        {
            pieChart.lastSelected = nil
            pieChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
        
        if piePlot._isRotating
        {
            oldLayer = nil
            return
        }
        
        if recognizer?.state == NSUIGestureRecognizerState.began
        {
            ChartUtils.longPressSound()
            
            if pieChart.lastSelected != nil && pieChart.lastSelected!.count > 0
            {
                let entry = pieChart.lastSelected![0]
                entry.filterEnabled = false
                pieChart.lastSelected = nil
            }
            
            pieRadChange = piePlot.radius
            PieHelperFunctions.resetVelocity(chart: pieChart)
            
            PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: location)
            
            if selectedHigh == nil || selectedEntry == nil { return }
            
            
            pieChart.data?.setDrawValues(false)
            
            
            oldLayer = selectedLayer
            
            
            location = (recognizer?.location(in: pieChart))!
            oldEntry = entry
            high = pieChart.getHighlightByTouchPoint(location)
            
            
            if high != nil {
                
                let chartEntry = pieChart.entryForHighlight(high!)
                
                angle =  PieHelperFunctions.getMidAngle(chart: pieChart, entry: chartEntry!)
                
                
                if piePlot.pieComponents.arrowlayer != nil
                {
                    piePlot.pieComponents.arrowlayer?.opacity = 0
                }
                
                changingFactor = 21
                
                for layer in PieLayer.getAllPieValueLayer(chart: pieChart)
                {
                    layer.opacity = 0
                }
                
            }
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.changed
        {
            
            
            if oldLayer == nil { return }
            
            let changeLocation = (recognizer?.location(in: pieChart))!
            
            if high != nil{
                
                let chartEntry = pieChart.entryForHighlight(high!)
                
                angle =  PieHelperFunctions.getMidAngle(chart: pieChart, entry: chartEntry!)
                
                if  ((315 < angle  && angle <= 360)||(0 <= angle && angle <= 45) )
                {
                    changingFactor = changingFactor + (changeLocation.x - location.x)
                }
                else if  (45 < angle  && angle <= 135 )
                {
                    changingFactor = changingFactor + (changeLocation.y - location.y)
                }
                else if  (135 < angle  && angle <= 225)
                {
                    changingFactor = changingFactor - (changeLocation.x - location.x)
                }
                else if  (225 < angle  && angle <= 315 )
                {
                    changingFactor = changingFactor - (changeLocation.y - location.y)
                }
                
                
                let origDiff = piePlot.radius * 0.8
                
                let opac:CGFloat!
                
                let curDiff =  abs(changingFactor)
                
                opac = (1/origDiff)*curDiff
                
                oldLayer?.opacity = 1 - Float(opac)
                
                if(changingFactor < 0)
                {
            
                    pieRadChange = piePlot.radius + changingFactor
                    
                    PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: 0, fromRadius: piePlot.radius, toRadius: piePlot.radius+changingFactor, pieCenter: piePlot.centerCircleBox, completionBlock: nil)
                    
                    changingFactor = 0.0
                    
                    
                    PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: changeLocation)
                    
                    return
                    
                }
                else{
                    
                    pieRadChange = piePlot.radius + changingFactor
                    
                    filterLayer = oldLayer
                    filterhigh = high
                    
                    let newx = piePlot.centerCircleBox.x + (changingFactor) * cos(angle.radians())
                    
                    let newy = piePlot.centerCircleBox.y + (changingFactor) * sin(angle.radians())
                    
                    PieHelperFunctions.sliceMove(sliceLayer: oldLayer!, high: high!, chart: pieChart, duration: 0, nx:newx, ny:newy, completionBlock: nil)
                }
                
                oldhigh = high
                

                location = changeLocation
                PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: location)
            }
        }
        else if recognizer?.state == NSUIGestureRecognizerState.ended
        {
            if oldLayer == nil {
                return
            }
            
            let endLocation = (recognizer?.location(in: pieChart))!
            
            PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: endLocation)
            
            let velocityCalculated = PieHelperFunctions.calculateVelocity(chart: pieChart)
            
            ///Drill
            if  pieRadChange < (piePlot.radius-20) //(velocityCalculated < -10 && changingFactor < (pieChart.radius/8)) ||
            {
                let completionBlock = {

                    self.oldEntry?.layerEnabled = false
                    pieChart.setNeedsDisplay()
                    if (pieChart.data?.valuesEnabled)! {
                        pieChart.data?.setDrawValues(true)
                    }
                    pieChart.drillEntry(selectedEntry: self.oldEntry!)
                }
                
                PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: 0.3, fromRadius: pieRadChange, toRadius: 0, pieCenter: piePlot.centerCircleBox, completionBlock: completionBlock)
                
            }
                /// Filter
            else if ((velocityCalculated > 20 && changingFactor > (piePlot.radius/4)) || (PieHelperFunctions.distance(from: piePlot.centerCircleBox , to: endLocation) >= piePlot.radius))
            {
                let completionBlock = {
                    PieHelperFunctions.deleteSliceWithNoFill(sliceLayer: self.filterLayer!, high: self.filterhigh!, chart: pieChart, duration: 0.3, animation: .linear)
                    self.filterLayer?.chartEntry?.layerEnabled = false
                    
                    pieChart.highlightValue(nil, callDelegate: true)
//                    if (pieChart.data?.valuesEnabled)! {
//                        pieChart.data?.setDrawValues(true)
//                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(400), execute: {
                        
                        PieHelperFunctions.positionMid(chart: pieChart, duration: 1.5)
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(1600), execute: {
                            pieChart.interactionAnimationInProgress = false
                        })
                        
                    })
                }
                
                pieChart.interactionAnimationInProgress = true
                
                let newx = piePlot.centerCircleBox.x + (piePlot.radius) * cos(angle.radians())
                
                let newy = piePlot.centerCircleBox.y + (piePlot.radius) * sin(angle.radians())
                
                PieHelperFunctions.sliceMove(sliceLayer: oldLayer!, high: high!, chart: pieChart, duration: 0.3, nx:newx, ny:newy, completionBlock: completionBlock)
        
            }
            else{
                
                selectedEntry = pieChart.entryForHighlight(high!)
                
                
                
                let completionBlock = {
                    
                    
                    
                    selectedEntry?.layerEnabled = false
                    
                    
                    if (pieChart.data?.valuesEnabled)!
                        
                    {
                        
                        pieChart.data?.setDrawValues(true)
                        
                    }
                    
                    
                    
                    pieChart.setNeedsDisplay()
                    
                    
                    
                    self.oldLayer = nil
                    
                    if (pieChart.data?.valuesEnabled)! {
                        pieChart.data?.setDrawValues(true)
                    }
                    
                }
                
                
                
                PieHelperFunctions.sliceIn(sliceLayer: oldLayer!, chart: pieChart, duration: 0.3, completionBlock: completionBlock)
                
                
                
            }
            
            
        }
        
    }
    
}


