//
//  ScatterPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 09/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class ScatterPanHandler: NSObject, EventHandler {
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterPan
    }
    
    var startLoc:CGPoint!
    var startEntry:ChartDataEntry!
    var startLayer:ChartEntryLayer!
    
    var yValueToMove:CGFloat = 0
    
    var allOtherScatterLayerAtSameIndex:[ScatterLayer]!
    
    var verticalPan = false
    var horizontalPan = false
    
    var highlighted = false
    
    var movingUp = false
    
    var allowed = true
    
    open func deselect(chart:ChartViewBase)
    {
        guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
        else { return }
        
        chart.lastSelected = nil
        chart.resetHighlight()
//        plotOption.barGroupSelectionEnabled = false
        chart.callDelegateToContainer(highlight: nil, entry: nil)
    }
    
    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barLine = chart
        let trans = recognizer.translation(in: barLine)
        
        guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions,
            let renderer = CommonHelperFunctions.getRenderer(chart: barLine, types: [.Scatter]) as? ScatterChartRenderer
        else { return }
        
        if renderer.entryDeleted == true  || recognizer.nsuiNumberOfTouches() > 1 || (barLine.customAnimationInProgress)
        {   startEntry = nil
            return
        }
        
        if entry == nil || entryLayer == nil
        {
            barLine._isDragging = true
        }

        if recognizer.state == NSUIGestureRecognizerState.began //&& recognizer.nsuiNumberOfTouches() > 0
        {
            barLine.stopDeceleration()
            
            
            if barLine.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barLine._lastPanPoint = recognizer.translation(in: barLine)
            
            barLine._isDragging = false
            
            if (barLine.data?.getDataSetForEntry(entry) == nil)
            {
                startEntry = nil
                return
            }
            
            startLoc = CommonHelperFunctions.getEntryLocation(chart: chart , entry: entry!)
            startEntry = entry
            startLayer = entryLayer as? ScatterLayer
  
            if barLine.lastSelected != nil && barLine.lastSelected!.count > 0
            {
                if CommonHelperFunctions.getHighlightLayer(chart: barLine).count != 0
                {
                    highlighted = true
                    startLoc = CommonHelperFunctions.getEntryLocation(chart: barLine, entry: barLine.lastSelected![0])
                    startEntry = barLine.lastSelected![0]
                }
                else{
                    barLine.lastSelected = nil
//                    plotOption.barGroupSelectionEnabled = false
                    barLine.resetHighlight()
                }
            }
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            if !barLine._isDragging {
                // Detecting vertical pan - once detected no change to horizontal
                if abs(trans.y) > 10 && abs(trans.x) < 10 && !verticalPan && !horizontalPan
                {
                    if startEntry == nil
                    {
                        return
                    }
                    
                    verticalPan = true
                    
                    let maxEntryLocation = getMaximumEntryLocation(barLine: barLine)
                    
                    yValueToMove =  (chart.viewPortHandler.contentBottom - maxEntryLocation.y + 6) / 2
                    
                }
                else if abs(trans.x) > 10 && abs(trans.y) < 10 && !horizontalPan && !verticalPan
                {
                    if startEntry == nil
                    {
                        return
                    }
                    
                    horizontalPan = true
                    
                    let maxEntryLocation = getMaximumEntryLocation(barLine: barLine)
                    
                    yValueToMove =  (maxEntryLocation.x + 6 - chart.viewPortHandler.contentLeft) / 2
                }
            }
            
            if verticalPan
            {
                if barLine.isRotated {
                    barLine._isDragging = true
                    verticalPan = false
                }
                else {
                    barLine._isDragging = false
                    isGoingToDrilled(chart: chart, plotOption: plotOption, trans: trans)
                }
            }
            else if horizontalPan{
                if barLine.isRotated {
                    barLine._isDragging = false
                    isGoingToDrilled(chart: chart, plotOption: plotOption, trans: trans)
                }
                else {
                    barLine._isDragging = true
                    horizontalPan = false
                }
            }
            
            if verticalPan || horizontalPan
            {
                if (chart.isRotated && trans.x > 0) || (!chart.isRotated && trans.y < 0) || movingUp
                {
                    // All entry highlighted case - not allowing up
                    if chart.xGroupSelected//plotOption.barGroupSelectionEnabled
                    {
                        CommonHelperFunctions.getHighlightLayer(chart: barLine)[safe:0]?.position = CGPoint(x: 0, y: 0 )
                        return
                    }
                    
                    if allowed && (!chart.isRotated && trans.y < 0 || chart.isRotated && trans.x > 0)
                    {
                        allowed = false
                        
                        
                        for layer in ScatterLayer.getAllScatterLayer(chart: chart)
                        {
                            if layer.chartEntry == startEntry
                            {
                                continue
                            }
                            
                            let newPath = CGMutablePath()
                            newPath.addArc(center: layer.shapePoint!, radius: 0.0, startAngle: 0.0, endAngle: 360.0, clockwise: false)
                        
                            CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0.5)
                            
                            CommonHelperFunctions.performLineWidthAnim(targetLayer: layer, newlineWidth: 0, duration: 0.5)
                            
                            layer.strokeColor = NSUIColor.lightGray.cgColor
                        }
                        
                    }
                    
                    // Exponential increment
                    var yValue = chart.isRotated ? abs(3*trans.x) : abs(3*trans.y)

                    if yValue > yValueToMove
                    {
                        yValue = yValueToMove
                    }
                    
                    // Restrict moving down
                    if (chart.isRotated && trans.x < 0) || !chart.isRotated && trans.y > 0
                    {
                        yValue = 0
                    }
                    
                    var newPoint = startLoc
                    if chart.isRotated {
                        newPoint?.x += yValue
                    }
                    else {
                        newPoint?.y -= yValue
                    }
                    
                    
                    if highlighted
                    {
                        // Circle
                        CommonHelperFunctions.getHighlightLayer(chart: barLine)[0].sublayers![1].position = chart.isRotated ? CGPoint(x: 0 - yValue, y: 0) : CGPoint(x: 0, y: 0 - yValue)
                        
                        // Horizontal Line
//                        LineHelperFunctions.getHighlightLayer(chart: barLine)[0].sublayers![0].sublayers![0].position = CGPoint(x: 0, y: 0 - yValue)
  
                    }
                    else{
//                        let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                        let newPath = CGMutablePath()
                        newPath.addArc(center: newPoint!, radius: 5.0, startAngle: 0.0, endAngle: 360.0, clockwise: false)
                        if startLayer != nil {
                            CommonHelperFunctions.performPathAnim(targetLayer: startLayer, newPath: newPath, duration: 0)
                        }
                    }

                }
                else if !movingUp {         // Moving Down Case
                    
                    let yValue = chart.isRotated ? abs(3*trans.x) : abs(3*trans.y)
                    
                    if highlighted
                    {
                        if !chart.xGroupSelected//!plotOption.barGroupSelectionEnabled
                        {
                            return
                        }
                        else{
                            CommonHelperFunctions.getHighlightLayer(chart: barLine)[0].position = CGPoint(x: 0, y: 0 + yValue)
                        }
                        
                    }
                    else{
                        for target in allOtherScatterLayerAtSameIndex
                        {
                            var newPoint = target.shapePoint
                            if chart.isRotated {
                                newPoint?.x -= yValue
                            }
                            else {
                                newPoint?.y += yValue
                            }
                            
//                            let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                            let newPath = CGMutablePath()
                            newPath.addArc(center: newPoint!, radius: 5.0, startAngle: 0.0, endAngle: 360.0, clockwise: false)
                            CommonHelperFunctions.performPathAnim(targetLayer: target, newPath: newPath, duration: 0)
                        }
                    }
                    
                    
                }
                
            }
            else    // Scroll
          {
            if barLine.lastSelected != nil
            {
                deselect(chart: barLine)
            }
            
            let originalTranslation = recognizer.translation(in: barLine)
            let translation = CGPoint(x: originalTranslation.x - barLine._lastPanPoint.x, y: originalTranslation.y - barLine._lastPanPoint.y)
            
            let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: barLine)
            
            barLine._lastPanPoint = originalTranslation
            }
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if verticalPan || horizontalPan
            {
                if startEntry == nil
                {
                    return
                }
                
                if movingUp
                {
                    // Check for drill condition
                    if !chart.isRotated && abs(trans.y*3) >= yValueToMove && trans.y < 0 || chart.isRotated && abs(trans.x*3) >= yValueToMove && trans.x > 0
                    {
                        barLine.curLevel += 1
                        barLine.delegateToContainer?.chartValueDrillPerformed!(barLine, entry: startEntry, level: barLine.curLevel)
//                        barLine.chartActionListener?.drillPerformed!(chartView: barLine, selectedEntry: startEntry,index: barLine.curLevel)
                    }
                    
                    barLine.setNeedsDisplay()
                }
                else{
                  
                    var filterAllowed = true
                    for set in (barLine.data?.dataSets)!
                    {
                        if set.isVisible
                        {
                            let startX =  (set.entryForXValue(-Double.greatestFiniteMagnitude, closestToY: Double.nan))?.x
                            let endX = (set.entryForXValue(Double.greatestFiniteMagnitude, closestToY: Double.nan))?.x
                            if startX == endX && startX == startEntry.x
                            {
                                filterAllowed = false
                                
                            }
                        }
                    }
                    
                    
                    let currentYValue = chart.isRotated ? abs(3*trans.x) : abs(3*trans.y)
                    
                    // Check for filter condition
                    if filterAllowed && currentYValue >= yValueToMove && trans.y > 0 || trans.x < 0
                    {
                        barLine.interactionAnimationInProgress = true

                        let percent = currentYValue / (yValueToMove*2)
                        
                        barLine.updateDataOrigIndex()
                        
                        var removeEntries:[ChartDataEntry] = []
                        for set in chart.data!.dataSets
                        {
                            for entry in (set as! ChartDataSet).values where self.startEntry.origX == entry.origX
                           {
                               removeEntries.append(entry)
                           }
                        }
                        
                        // isFullyHidden
                        if percent < 1
                        {
                            let duration = Double(1 - percent)
                            
                            if highlighted
                            {
                                let highLayer = CommonHelperFunctions.getHighlightLayer(chart: barLine)[0]
                                if chart.isRotated {
                                    CommonHelperFunctions.performPositionAnim(targetLayer: highLayer, point: CGPoint(x: 0 + (yValueToMove*4), y: 0), duration: duration)
                                }
                                else {
                                    CommonHelperFunctions.performPositionAnim(targetLayer: highLayer, point: CGPoint(x: 0, y: 0 + (yValueToMove*4)), duration: duration)
                                }
                            }
                            else{
                                for target in allOtherScatterLayerAtSameIndex
                                {
                                    var newPoint = target.shapePoint
                                    
                                    if chart.isRotated {
                                        newPoint?.x += (yValueToMove*2)
                                    }
                                    else {
                                        newPoint?.y += (yValueToMove*2)
                                    }
                                    
//                                    let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                                    let newPath = CGMutablePath()
                                    newPath.addArc(center: newPoint!, radius: 5.0, startAngle: 0.0, endAngle: 360.0, clockwise: false)
                                    CommonHelperFunctions.performPathAnim(targetLayer: target, newPath: newPath, duration: duration)
                                }
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(duration*1000)), execute: { [unowned barLine] in
                                
//                                ChartInteractionHelperFunction.alignScatterBubble(axisChartBase: barLine, chartEntry: self.startEntry, type: ChartType.Scatter)
//                                ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: self.startEntry, chart: barLine, duration: 0.5)
                                
                                ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: barLine, duration: 0.5)
                            })
                            
                        }
                        else{
//                            ChartInteractionHelperFunction.alignScatterBubble(axisChartBase: barLine, chartEntry: self.startEntry, type: ChartType.Scatter)
//                            ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: self.startEntry, chart: barLine, duration: 0.5)
                            ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: barLine, duration: 0.5)
                        }
                    }
                    else{
                        
                        barLine.setNeedsDisplay()
                    }
                    
                  
                }
                allowed = true
                movingUp = false
            }
            else{
                    barLine._isDragging = true
                
                    if recognizer.state == NSUIGestureRecognizerState.ended && barLine.isDragDecelerationEnabled
                    {
                        barLine.stopDeceleration()
                        
                        barLine._decelerationLastTime = CACurrentMediaTime()
                        barLine._decelerationVelocity = recognizer.velocity(in: barLine)
                        
                        barLine._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barLine)
                        barLine._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                        
                    }
                
                    barLine._isDragging = false

                    if barLine._outerScrollView !== nil
                    {
                        barLine._outerScrollView?.nsuiIsScrollEnabled = true
                        barLine._outerScrollView = nil
                    }
                
            }
            // To all
            verticalPan = false
            horizontalPan = false
            highlighted = false
            deselect(chart: barLine)
        }
    }
    
    func isGoingToDrilled(chart: ChartViewBase, plotOption: AxisChartPlotOptions, trans: CGPoint) {
        
        if  highlighted
        {
            if !chart.xGroupSelected//!plotOption.barGroupSelectionEnabled
            {
                yValueToMove = startLoc.y - 6 - chart.viewPortHandler.contentTop
                movingUp = true
            }
        }
        else{
            
            if chart.isRotated {
                if trans.x > 0 {
                    yValueToMove = chart.viewPortHandler.contentRight - (startLoc.x - 6)
                    movingUp = true
                }
            }
            else {
                if trans.y < 0
                {
                    yValueToMove = startLoc.y - 6 - chart.viewPortHandler.contentTop
                    movingUp = true
                }
            }
        }
    }
    
    func getMaximumEntryLocation(barLine: ChartViewBase) -> CGPoint {
        
        if startEntry == nil
        {
            return CGPoint()
        }
        
        startLayer = ScatterLayer.getScatterEntryLayer(chart: barLine, loc: startLoc)
        
        let otherEntriesAtSameIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: startEntry,includeNan:false, chart: barLine)
        
        var maxEntry = startEntry
        
        allOtherScatterLayerAtSameIndex = []
        
        // find entry at the top - maxY value
        for entry in otherEntriesAtSameIndex
        {
            if !highlighted
            {
                if let layer = ScatterLayer.getScatterLayerForEntry(chart: barLine, entry: entry) {
                    allOtherScatterLayerAtSameIndex.append(layer)
                }
            }
            else{
                ScatterLayer.getScatterLayerForEntry(chart: barLine, entry: entry)?.opacity = 0
            }
            
            
            if  entry.y > (maxEntry?.y)!
            {
                maxEntry = entry
            }
        }
        
        return CommonHelperFunctions.getEntryLocation(chart: barLine, entry: maxEntry!)!
    }
}
