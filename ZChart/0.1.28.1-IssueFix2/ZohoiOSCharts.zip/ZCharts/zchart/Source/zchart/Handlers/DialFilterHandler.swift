//
//  DialFilterHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 05/07/22.
//

import Foundation

open class DialFilterHandler: NSObject,EventHandler {
    
    var lastSelectedLayer: DialLevelLayer?
    
    var lastSelectedIndex: Int?
    
    public func getEventHandlerType() -> EventHandlerType {
        EventHandlerType.custom
    }
    
    var levelMarkerColorsBackup:[NSUIColor] = ChartColorTemplates.pieColor()
    
    var filteredLevels:[Double] = []
    
    var filteredColorIndex:[Int] = []
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint){
        
        let touchLayer = getDialLayerInTouchPoint(touchPoint: touchLocation, levelLayers: DialLevelLayer.getAllDialLevelLayers(chart: chartView))
        
        if touchLayer.0 != nil
        {
            let removedColor = filterOutLevel(chart: chartView, levelLayer: touchLayer.0!)
            
            filteredLevels.append(touchLayer.0!.levelValue)
            filteredColorIndex.append(self.levelMarkerColorsBackup.firstIndex(of: removedColor)!)
            
            return
        }
        else{
            if filteredLevels.isEmpty
            {
                return
            }
            let value = filteredLevels.remove(at: 0)
            filteredColorIndex.remove(at: 0)
            var newColorArray:[NSUIColor] = []
            for colorIndex in 0..<levelMarkerColorsBackup.count
            {
                if filteredColorIndex.contains(colorIndex)
                {
                    continue
                }
                
                newColorArray.append(levelMarkerColorsBackup[colorIndex])
                
            }
            filterInLevel(chart: chartView, set: chartView.data!.dataSets[0] as! ChartDataSet, entry: chartView.data!.dataSets[0].entryForIndex(0)!, levelValue: value, levelColor: [newColorArray])
        }
        
    }
    
    // MARK: - Filter In
    
    func filterInLevel(chart:ChartViewBase, set:ChartDataSet, entry:ChartDataEntry, levelValue:Double, levelColor:[[NSUIColor]])
    {
        
        let entryIndex = set.entryIndex(entry: entry)
        
        entry.levelMarker?.append(levelValue)
        
        guard
              let levelMarker = entry.levelMarker?.sorted(by: {
                  $0 < $1
              })
            else { return }
        
        var tempLevels:[Double] = []
        
        for levelIndex in 0..<levelMarker.count
        {
            let l = levelMarker[levelIndex]
            
            if l == levelValue
            {
                if l < 0
                {
                    if levelIndex+1 < levelMarker.count
                    {
                        let value = levelMarker[levelIndex+1] > 0 ? 0 : levelMarker[levelIndex+1]
                        tempLevels.append(value)
                    }
                    else{
                        tempLevels.append(0)
                    }
                }
                else{
                    if tempLevels.count > 0
                    {
                        let value = tempLevels[tempLevels.count-1] < 0 ? 0 : tempLevels[tempLevels.count-1]
                        tempLevels.append(value)
                    }
                    else{
                        tempLevels.append(0)
                    }
                }
                continue
            }
            tempLevels.append(l)
        }
        
        entry.levelMarker =  tempLevels
        
        let dialOptions = chart.getPlotOptions(type: .Dial) as! DialPlotOptions
        
        dialOptions.levelMarkerColors = levelColor
        
        chart.yAxisArray[set.axisIndex].resetCustomAxisMin()
        chart.yAxisArray[set.axisIndex].resetCustomAxisMax()
        
        //***********************************
        
        entry.calcPosNegMax()
        
        set.notifyDataSetChanged()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        
        //***********************************
        
        
        let filterInBlock = { [unowned self] in
        guard let changedlevelMarker = entry.levelMarker?.sorted(by: {
                  $0 < $1
              })
            else { return }
        
        var levelSorted = PieHelperFunctions.prepareLevelValues(chart: chart, dataset: set, levelMarker: changedlevelMarker)
        
        let oldStartEndAngles = getStartEndAngles(chart: chart, axisIndex: set.axisIndex, levelArray: levelSorted)
        
        let (oldLevelMarkerInnerRadius,oldLevelMarkerOuterRadius) =  PieHelperFunctions.getInnerOuterLevelRadius(chart: chart)
        
        let oldDataStartEndAngles = getDataStartEndAngles(chart: chart, entryIndex: entryIndex, axisIndex: set.axisIndex)
            
        let (oldDataInnerRadius,oldDataOuterRadius) =  PieHelperFunctions.getDataInnerOuterRadius(chart: chart)
        
        //***********************************
         
        entry.levelMarker = levelMarker
            
        chart.yAxisArray[set.axisIndex].resetCustomAxisMin()
        chart.yAxisArray[set.axisIndex].resetCustomAxisMax()
        
        entry.calcPosNegMax()
        
        set.notifyDataSetChanged()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        
        //***********************************
        
        let (newLevelMarkerInnerRadius,newLevelMarkerOuterRadius) =  PieHelperFunctions.getInnerOuterLevelRadius(chart: chart)
        
        //*************************************
        
        levelSorted = PieHelperFunctions.prepareLevelValues(chart: chart, dataset: set, levelMarker: entry.levelMarker!)
        
        let newStartEndAngles = getStartEndAngles(chart: chart, axisIndex: set.axisIndex, levelArray: levelSorted)
            
        let newDataStartEndAngles = getDataStartEndAngles(chart: chart, entryIndex: entryIndex, axisIndex: set.axisIndex)
            
        let (newDataInnerRadius,newDataOuterRadius) =  PieHelperFunctions.getDataInnerOuterRadius(chart: chart)
        
//        let innerOuterRadius =
        var startAngleInterpolator:[((Double) -> Double)] = []
        var endAngleInterpolator:[((Double) -> Double)] = []
        let innerRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldLevelMarkerInnerRadius, b: newLevelMarkerInnerRadius)
        let outerRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldLevelMarkerOuterRadius, b: newLevelMarkerOuterRadius)
            
        let dataStartAngleInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataStartEndAngles.startAngle, b: newDataStartEndAngles.startAngle)
        let dataEndAngleInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataStartEndAngles.endAngle, b: newDataStartEndAngles.endAngle)
        let datainnerRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataInnerRadius, b: newDataInnerRadius)
        let dataouterRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataOuterRadius, b: newDataOuterRadius)
        
        for angleIndex in 0..<oldStartEndAngles.count
        {
            startAngleInterpolator.append(Interpolator.interpolate(a: oldStartEndAngles[angleIndex].startAngle, b: newStartEndAngles[angleIndex].startAngle))
            endAngleInterpolator.append(Interpolator.interpolate(a: oldStartEndAngles[angleIndex].endAngle, b: newStartEndAngles[angleIndex].endAngle))
        }
            
        var dataLayer:PieLayer? = nil
        
        for layer in PieLayer.getAllPieLayer(chart: chart)
        {
            if !(layer.isKind(of: DialLevelLayer.self))
            {
                dataLayer = layer
                break
            }
        }
        
        let filterAnimator = Animator()
        
        filterAnimator.updateBlock = { [unowned chart] in
            
            var angleIndex = 0
            for level in DialLevelLayer.getAllDialLevelLayers(chart: chart)
            {
                level.path = PieHelperFunctions.getSlicePath(chart: chart, dataSet: set, entryIndex: entryIndex, visibleAngleCount: set.entryCount, startAngle: startAngleInterpolator[angleIndex](filterAnimator.phaseX), sliceAngle: endAngleInterpolator[angleIndex](filterAnimator.phaseX), innerRadius: innerRadiusInterpolator(filterAnimator.phaseX), outerRadius: outerRadiusInterpolator(filterAnimator.phaseX), animate: false, phaseY: 1)
                level.fillColor = levelColor[0][angleIndex].cgColor
                angleIndex += 1
            }
            
            if dataLayer != nil
            {
                dataLayer?.path = PieHelperFunctions.getSlicePath(chart: chart, dataSet: set, entryIndex: entryIndex, visibleAngleCount: set.entryCount, startAngle: dataStartAngleInterpolator(filterAnimator.phaseX), sliceAngle: dataEndAngleInterpolator(filterAnimator.phaseX), innerRadius: datainnerRadiusInterpolator(filterAnimator.phaseX), outerRadius: dataouterRadiusInterpolator(filterAnimator.phaseX), animate: false, phaseY: 1)
            }
        }
        
        filterAnimator.stopBlock = { [unowned chart, filterAnimator] in
            filterAnimator.updateBlock = nil
            chart.notifyDataSetChanged(redrawRequired: true)
        }
        
        filterAnimator.animate(xAxisDuration: 0.5, easingOption: .linear)
        }
        
        let tempAnimator = Animator()
        
        
        tempAnimator.updateBlock = {
            
            
        }
        
        tempAnimator.stopBlock = {
            
            filterInBlock()
        }
        
        tempAnimator.animate(xAxisDuration: 0.1)
    }
    
    // MARK: - Filter Out
    
    func filterOutLevel(chart:ChartViewBase, levelLayer:DialLevelLayer) -> NSUIColor
    {
        guard let set = levelLayer.chartDataSet,
              let entry = levelLayer.chartEntry,
              let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              let levelMarker = entry.levelMarker?.sorted(by: {
                  $0 < $1
              })
            else { return NSUIColor.red }
        
        let entryIndex = set.entryIndex(entry: entry)
        
        var levelSorted = PieHelperFunctions.prepareLevelValues(chart: chart, dataset: set, levelMarker: levelMarker)
        
        let oldStartEndAngles = getStartEndAngles(chart: chart, axisIndex: set.axisIndex, levelArray: levelSorted)
        
        let (oldLevelMarkerInnerRadius,oldLevelMarkerOuterRadius) =  PieHelperFunctions.getInnerOuterLevelRadius(chart: chart)
        
        let oldDataStartEndAngles = getDataStartEndAngles(chart: chart, entryIndex: entryIndex, axisIndex: set.axisIndex)
        
        let (oldDataInnerRadius,oldDataOuterRadius) =  PieHelperFunctions.getDataInnerOuterRadius(chart: chart)
        
        var tempLevels:[Double] = []
        
        var removedIndex = -1
        
        for levelIndex in 0..<levelMarker.count
        {
            let l = levelMarker[levelIndex]
            
            if l == levelLayer.levelValue
            {
                removedIndex = levelIndex
                if l < 0
                {
                    if levelIndex+1 < levelMarker.count
                    {
                        let value = levelMarker[levelIndex+1] > 0 ? 0 : levelMarker[levelIndex+1]
                        tempLevels.append(value)
                    }
                    else{
                        tempLevels.append(0)
                    }
                }
                else{
                    if tempLevels.count > 0
                    {
                        let value = tempLevels[tempLevels.count-1] < 0 ? 0 : tempLevels[tempLevels.count-1]
                        tempLevels.append(value)
                    }
                    else{
                        tempLevels.append(0)
                    }
                }
                continue
            }
            tempLevels.append(l)
        }
        
        entry.levelMarker =  tempLevels
        
        //***********************************
        
        entry.calcPosNegMax()
        
        set.notifyDataSetChanged()
        
        chart.data?.notifyDataChanged()
        
        chart.notifyDataSetChanged(redrawRequired: false)
        
        
        //***********************************
        
        let (newLevelMarkerInnerRadius,newLevelMarkerOuterRadius) =  PieHelperFunctions.getInnerOuterLevelRadius(chart: chart)
        
        //*************************************
        
        levelSorted = PieHelperFunctions.prepareLevelValues(chart: chart, dataset: set, levelMarker: entry.levelMarker!)
        
        let newStartEndAngles = getStartEndAngles(chart: chart, axisIndex: set.axisIndex, levelArray: levelSorted)
        
        let newDataStartEndAngles = getDataStartEndAngles(chart: chart, entryIndex: entryIndex, axisIndex: set.axisIndex)
        
        let (newDataInnerRadius,newDataOuterRadius) =  PieHelperFunctions.getDataInnerOuterRadius(chart: chart)
        
        var startAngleInterpolator:[((Double) -> Double)] = []
        var endAngleInterpolator:[((Double) -> Double)] = []
        let innerRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldLevelMarkerInnerRadius, b: newLevelMarkerInnerRadius)
        let outerRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldLevelMarkerOuterRadius, b: newLevelMarkerOuterRadius)
        
        let dataStartAngleInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataStartEndAngles.startAngle, b: newDataStartEndAngles.startAngle)
        let dataEndAngleInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataStartEndAngles.endAngle, b: newDataStartEndAngles.endAngle)
        let datainnerRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataInnerRadius, b: newDataInnerRadius)
        let dataouterRadiusInterpolator:((Double) -> Double) = Interpolator.interpolate(a: oldDataOuterRadius, b: newDataOuterRadius)
        
        for angleIndex in 0..<oldStartEndAngles.count
        {
            startAngleInterpolator.append(Interpolator.interpolate(a: oldStartEndAngles[angleIndex].startAngle, b: newStartEndAngles[angleIndex].startAngle))
            endAngleInterpolator.append(Interpolator.interpolate(a: oldStartEndAngles[angleIndex].endAngle, b: newStartEndAngles[angleIndex].endAngle))
        }
        
        var dataLayer:PieLayer? = nil
        
        for layer in PieLayer.getAllPieLayer(chart: chart)
        {
            if !(layer.isKind(of: DialLevelLayer.self))
            {
                dataLayer = layer
                break
            }
        }
        
        let filterAnimator = Animator()
        
        filterAnimator.updateBlock = { [unowned chart,set,filterAnimator] in
            
            var angleIndex = 0
            for level in DialLevelLayer.getAllDialLevelLayers(chart: chart)
            {
                level.path = PieHelperFunctions.getSlicePath(chart: chart, dataSet: levelLayer.chartDataSet!, entryIndex: entryIndex, visibleAngleCount: set.entryCount, startAngle: startAngleInterpolator[angleIndex](filterAnimator.phaseX), sliceAngle: endAngleInterpolator[angleIndex](filterAnimator.phaseX), innerRadius: innerRadiusInterpolator(filterAnimator.phaseX), outerRadius: outerRadiusInterpolator(filterAnimator.phaseX), animate: false, phaseY: 1)
                angleIndex += 1
            }
            if dataLayer != nil
            {
                dataLayer?.path = PieHelperFunctions.getSlicePath(chart: chart, dataSet: set, entryIndex: entryIndex, visibleAngleCount: set.entryCount, startAngle: dataStartAngleInterpolator(filterAnimator.phaseX), sliceAngle: dataEndAngleInterpolator(filterAnimator.phaseX), innerRadius: datainnerRadiusInterpolator(filterAnimator.phaseX), outerRadius: dataouterRadiusInterpolator(filterAnimator.phaseX), animate: false, phaseY: 1)
            }
            
        }
        
        filterAnimator.stopBlock = { [unowned chart,filterAnimator,set] in
            filterAnimator.updateBlock = nil
           /* guard let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions
            else { return  }
            
            tempLevels.remove(at: removedIndex)
            entry.levelMarker =  tempLevels
            dialOption.levelMarkerColors[0].remove(at: removedIndex)
        
            entry.calcPosNegMax()
            
            set.notifyDataSetChanged()
            
            chart.data?.notifyDataChanged()
            
            chart.notifyDataSetChanged(redrawRequired: true)*/
        }
        
        filterAnimator.animate(xAxisDuration: 0.5, easingOption: .linear)
        
        return dialOption.levelMarkerColors[0][removedIndex]
    }
    
    // MARK: - Angles
    
    func getStartEndAngles(chart:ChartViewBase, axisIndex:Int, levelArray:[Double]) -> [(startAngle:Double,endAngle:Double)]
    {
        var pair:[(startAngle:Double,endAngle:Double)] = []
        
        guard let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              let transformer = chart.getTransformer(axisIndex: axisIndex) as? PolarTransformer,
              let yAxis = chart.getYAxis(atIndex: axisIndex)
              else {return pair}
        
        
        for levelIndex in 0..<levelArray.count-1
        {
            var fromVal = levelArray[levelIndex].isNaN ? 0 : levelArray[levelIndex]
            
            var toVal = levelArray[levelIndex + 1].isNaN ? 0 : levelArray[levelIndex + 1]
            
            if fromVal > yAxis.axisMaximum
            {
                fromVal = yAxis.axisMaximum
            }

            if fromVal < yAxis.axisMinimum
            {
                fromVal = yAxis.axisMinimum
            }
            
            let startAngle = transformer.absoluteAngleForValue(value: fromVal)
              
            if toVal > yAxis.axisMaximum
            {
                toVal = yAxis.axisMaximum
            }

            if toVal < yAxis.axisMinimum
            {
                toVal = yAxis.axisMinimum
            }
            
            let rect = CGRect(x: 0, y: 0, width: abs(abs(fromVal - toVal)), height: abs(abs(fromVal - toVal)))
            
            var endAngle = rect.applying(transformer.valueToPixelMatrix).height
            
            endAngle = endAngle > dialOption.maxAngle ? dialOption.maxAngle : endAngle
            
            pair.append((startAngle,endAngle))
        }
    
        return pair
    }
    
    func getDataStartEndAngles(chart:ChartViewBase, entryIndex:Int, axisIndex:Int) -> (startAngle:Double,endAngle:Double)
    {
        var startAngle:Double = 0
        
        guard let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions,
              let transformer = chart.getTransformer(axisIndex: axisIndex) as? PolarTransformer,
              let yAxis = chart.getYAxis(atIndex: axisIndex)
              else {return (startAngle,0)}
        
        startAngle = dialOption.startAngle
        
        // Negative Data Handling
        if  yAxis.axisMinimum < 0
        {
            let val = min(yAxis.axisMaximum,0)
            startAngle = transformer.absoluteAngleForValue(value: val)
            
        }
        return (startAngle,dialOption.drawAngles[entryIndex])
    }
    
    func getDialLayerInTouchPoint(touchPoint: CGPoint,levelLayers: [DialLevelLayer]) -> (DialLevelLayer?,Int){
        
        var layer: DialLevelLayer?
        
        var index = -1
        
        for levelLayerIndex in 0..<levelLayers.count {
            
            if let path = levelLayers[levelLayerIndex].path {
                if path.contains(touchPoint) {
                    layer = levelLayers[levelLayerIndex]
                    index = levelLayerIndex
                    break
                }
            }
        }
        
        return (layer,index)
    }
}

