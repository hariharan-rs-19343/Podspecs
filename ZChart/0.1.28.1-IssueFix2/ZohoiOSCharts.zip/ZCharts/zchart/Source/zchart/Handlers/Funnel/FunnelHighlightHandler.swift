//
//  FunnelHighlightHandler.swift
//  zchart
//
//  Created by Aravinth T on 09/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

#if !os(OSX)
    import UIKit
#endif

open class FunnelHighlightHandler: NSObject, EventHandler {
    
    let highlightDifference:CGFloat = 15.0
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        resetLastSelected(chart: chart)
        
        if entry == nil || (entry != nil && chart.lastSelected != nil && chart.IsEntrySelected(entry: entry)  /*chart.lastSelected == entry */) {
            
            self.resetLastselectedToNil(chart: chart)
            
        } else if entry != nil {
            
            let funnelLayer = entryLayer as! FunnelLayer
            let funnelSlicePoint = funnelLayer.funnelSlicePoint
            var points = (funnelSlicePoint?.points)!
            
            if points.count == 6 { //STEM POINT
                //Left side
                points[0].x = points[0].x - highlightDifference
                points[4].x = points[4].x - highlightDifference
                points[5].x = points[5].x - highlightDifference
                //Right Side
                points[1].x = points[1].x + highlightDifference
                points[2].x = points[2].x + highlightDifference
                points[3].x = points[3].x + highlightDifference
            } else { //OTHER POINT
                //Left side
                points[0].x = points[0].x - highlightDifference
                points[3].x = points[3].x - highlightDifference
                //Right Side
                points[1].x = points[1].x + highlightDifference
                points[2].x = points[2].x + highlightDifference
            }
            
//            chart.lastSelected = entry
            chart.updateLastSelectedEntry(entry: entry)
            let path = FunnelLayer.getBezeirPath(cgPoints: points)
            CommonHelperFunctions.performPathAnim(targetLayer: funnelLayer, newPath: path, duration: 0.2)
            
            let high = chart.getHighlightByTouchPoint(touchLocation)
            chart.highlightValue(high, callDelegate: false, redrawRequired: false)
            
        }
        
    }
    
    func resetLastselectedToNil(chart:ChartViewBase) {
        chart.lastSelected = nil
        chart.highlightValue(nil, callDelegate: false, redrawRequired: false)
    }
    
    func resetLastSelected(chart: ChartViewBase){
        let lastSelected = chart.lastSelected
        
        if lastSelected != nil && lastSelected!.count > 0  {
            let funnelLayer = FunnelLayer.getFunnelLayerForEntry(chart: chart, entry:lastSelected![0])
            
            if funnelLayer == nil {
                return
            }
            
            let funnelSlicePoint = funnelLayer?.funnelSlicePoint
            
            let points = (funnelSlicePoint?.points)!
            
            let path = FunnelLayer.getBezeirPath(cgPoints: points)
            CommonHelperFunctions.performPathAnim(targetLayer: funnelLayer!, newPath: path, duration: 0.2)
        }
    }
    
    
    ///********************** Multiple Entry Removal Testing ********************
    /*var uniqueX = Set<String>()
    var removeEntries:[ChartDataEntry] = []
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        if removeEntries.count > 0
        {
            FunnelHelperFunctions.includeEntries(entries: removeEntries, chart: chart, duration: 2)
            return
        }
            
            if entryLayer != nil
            {
                uniqueX.insert((entry!.xString!))
                return
            }
            else{
                
                for set in chart.data!.dataSets
                {
                    for entry in (set as! ChartDataSet).values where uniqueX.contains(entry.xString!)
                   {
                       removeEntries.append(entry)
                   }
                }
                FunnelHelperFunctions.removeEntries(entries: removeEntries, chart: chart, duration: 2)
                uniqueX.removeAll()
            }
        }*/
}
