//
//  ScatterHighlightHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 04/04/18.
//  Copyright © 2018 charts. All rights reserved.
//


open class ScatterHighlightHandler: NSObject, EventHandler {

    public static var needRefresh = false
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterHighlight
    }
    
    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        var entry = entry
        
        let scatterChart = chart
        
        let scatterData = scatterChart.data!
        
        guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
        else { return }
        
        if scatterChart.isAnimationinProgress()
        {
            return
        }
        
        scatterChart.stopDeceleration()
        
        // To remove previous highlight laayer
        CommonHelperFunctions.removeHighlightLayer(chart: chart)
        
        
        
        for layer in ScatterLayer.getAllScatterLayer(chart: chart)
        {
                layer.strokeColor = NSUIColor.lightGray.cgColor
        }
        
        if ScatterHighlightHandler.needRefresh
        {
            entry = nil
            ScatterHighlightHandler.needRefresh = false
        }
        
        
        if scatterChart.lastSelected != nil && scatterChart.lastSelected!.count > 0 && entry != nil && entryLayer != nil
        {
            if plotOption.barGroupSelectionEnabled
            {
                if  scatterChart.IsEntryXSelected(x: entry!.x) //(entry?.x)! == (scatterChart.lastSelected?.x)!
                {
                    entry = nil
                }
            }
            else{
                if scatterChart.IsEntrySelected(entry: entry)// entry! == scatterChart.lastSelected!
                {
                    entry = nil
                }
            }
        }
        

        
        if entry != nil && entryLayer != nil && chart.viewPortHandler.isInBoundsX(touchLocation.x){
            
            let entryLocation = CommonHelperFunctions.getEntryLocation(chart: chart , entry: entry!)!
            
            let interSpace = (scatterData.dataSets[0].dataSetOptions as! AxisChartDataSetOptions).shapeProperties.size.width

            let scatterLayer = entryLayer as! ScatterLayer
            
            let innerCircleShape = ShapeProperties()
            innerCircleShape.holeColor = nil // Set nil to fill default dataset color
            innerCircleShape.lineWidth = 2
            innerCircleShape.size = CGSize(width: 8.0, height: 8.0)
            innerCircleShape.strokeColor = NSUIColor.clear
            
            let outerCircleShape = ShapeProperties()
            outerCircleShape.holeColor = NSUIColor.white
            outerCircleShape.lineWidth = 2
            outerCircleShape.size = CGSize(width: 16.0, height: 16.0)
            outerCircleShape.strokeColor = nil
            
            // SingleEntry Selection
            if abs(touchLocation.x - entryLocation.x) <= interSpace && abs(touchLocation.y - entryLocation.y) <= interSpace
            {
//                scatterChart.lastSelected = entry
                scatterChart.updateLastSelectedEntry(entry: entry)

                plotOption.barGroupSelectionEnabled = false
                
                ScatterHelperFunctions.highlightSingleEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
            }
            else{   //MultiSeries Entry Selection
                
//                scatterChart.lastSelected = entry
                scatterChart.updateLastSelectedEntry(entry: entry)
                
                chart.xGroupSelected = true

                plotOption.barGroupSelectionEnabled = true
                
                ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
                
            }
            
//            chart.updateLastSelectedEntry(entry: entry)
        }
        else{
            scatterChart.lastSelected = nil
//            plotOption.barGroupSelectionEnabled = false
            chart.resetHighlight()
            chart.setNeedsDisplay()
//            entry = nil
        }
        
        // Tooltip delegate
        chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(touchLocation), entry: entry)
    }
    
    ///********************** Multiple X Removal Testing ********************
    
    /*var uniqueX = Set<Double>()
        
        public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
            
            var entry = entry
            
            let scatterChart = chart
            
            let scatterData = scatterChart.data!
            
            guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
            else { return }
            
            if scatterChart.isAnimationinProgress()
            {
                return
            }
            
            if entry != nil && entryLayer != nil && chart.viewPortHandler.isInBoundsX(touchLocation.x)
            {
                uniqueX.insert((entry!.x))
            }
            else if !(chart.viewPortHandler.isInBoundsX(touchLocation.x)){
                
                chart.updateDataOrigIndex()
                var removeEntries:[ChartDataEntry] = []
                for set in chart.data!.dataSets
                {
                    for entry in (set as! ChartDataSet).values where uniqueX.contains(entry.x)
                   {
                       removeEntries.append(entry)
                   }
                }
                ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: chart, duration: 3)
                uniqueX.removeAll()
            }
            return
    
            }*/
    
}

