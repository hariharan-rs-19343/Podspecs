//
//  EventHandler.swift
//  zchart
//
//  Created by Aravinth T on 08/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

@objc
public enum EventHandlerType: Int
{
    case zoomInOut
    
    case sliceout
    case increaseHeight
    case filtering
    case arrowHighlight
    case custom
    
    
    
    case barHighlight
    case barPan
    
    
    case lineHighlight
    case lineLongPress
    case linePan
    
    case scatterHighlight
    case scatterLongPress
    case scatterPan
}


@objc
public protocol EventHandler : NSObjectProtocol {
    
    @objc func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?,_ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint)
    
    @objc func getEventHandlerType() -> EventHandlerType
}

