//
//  RotateAndHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 17/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class RotateAndHighlightHandler: NSObject, EventHandler {
    
    static var prevHigh:Highlight? = nil
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.arrowHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint)
    {
            let loc = touchLocation
        
            if PieHelperFunctions.isInnerCircleTouched(chart: chart, location: loc)
            {
                let entry = PieHelperFunctions.getEntryForInnerCircleTap(pieChart: chart)
                chart.tooltipSelected(entry: entry)
                return
            }
        
            let high = chart.getHighlightByTouchPoint(loc)
        
            if high != nil
            {
                PieHelperFunctions.rotateAndHighlight(location: loc, chart: chart)
            }
    }
        
    
}
