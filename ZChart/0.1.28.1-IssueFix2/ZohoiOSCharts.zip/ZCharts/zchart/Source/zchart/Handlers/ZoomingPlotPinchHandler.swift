//
//  ZoomingPlotPinchHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 08/11/21.
//  Copyright © 2021 zoho. All rights reserved.
//


open class ZoomingPlotPinchHandler:NSObject,EventHandler
{
    
    open var drillState:Bool = false
    
    open var drillStateMatrix:CGAffineTransform? = nil
    
    var scaledMatrix:CGAffineTransform? = nil
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.zoomInOut
    }
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint)
    {
        let barLineChart = chartView
        
        let recognizer = recognizer as! NSUIPinchGestureRecognizer
        
        // width for single point
        let currentFontSize:CGFloat =  getSmallTextSize(chart: chartView)
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            barLineChart.stopDeceleration()
            
            if barLineChart._data !== nil &&
                (barLineChart.pinchZoomEnabled || barLineChart.scaleXEnabled || barLineChart.scaleYEnabled)
            {
                barLineChart._isScaling = true
                
                if barLineChart.pinchZoomEnabled
                {
                    barLineChart._gestureScaleAxis = .both
                }
                else
                {
//                    let x = abs((recognizer.location(in: barLineChart).x) - (recognizer.location(ofTouch: 1, in: barLineChart).x))
//                    let y = abs((recognizer.location(in: barLineChart).y) - (recognizer.location(ofTouch: 1, in: barLineChart).y))
                    var touchLoaction = CGPoint()
                    
                    #if os(iOS)
                        touchLoaction = recognizer.numberOfTouches > 0 ? recognizer.nsuiLocationOfTouch(1, inView: barLineChart) : touchLoaction
                    #endif
                    
                    let x = abs((recognizer.location(in: barLineChart).x) - touchLoaction.x)
                    let y = abs((recognizer.location(in: barLineChart).y) - touchLoaction.y)
                    
                    if barLineChart.scaleXEnabled != barLineChart.scaleYEnabled
                    {
                        barLineChart._gestureScaleAxis = barLineChart.scaleXEnabled ? .x : .y
                    }
                    else
                    {
                        barLineChart._gestureScaleAxis = x > y ? .x : .y
                    }
                }
            }
            
            /// Since translation should be allowed on zoom restriction
            if drillStateMatrix != nil && drillState
            {
                drillStateMatrix?.tx = barLineChart.viewPortHandler.touchMatrix.tx
                drillStateMatrix?.ty = barLineChart.viewPortHandler.touchMatrix.ty
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let maxFontSize:CGFloat = (barLineChart.getPlotOptions(type: .WordCloud) as! WordCloudPlotOptions).maxFontToRestrict
            
            if currentFontSize >= maxFontSize
            {
                if drillState == false
                {
                    ChartUtils.longPressSound()
                    drillState = true
                }
                
            }
            else{
                
                drillState = false
                
                drillStateMatrix = nil
            }
            
            if drillState && drillStateMatrix == nil{
                
                drillStateMatrix = barLineChart.viewPortHandler.touchMatrix
                _  =  CommonHelperFunctions.performPlotPinch(recognizer: recognizer, chart: barLineChart)
                
                //barLineChart.notifyDataSetChanged(redrawRequired: false)
            }
            else{
                let returnMatrix = CommonHelperFunctions.performPlotPinch(recognizer: recognizer, chart: barLineChart)
                //barLineChart.notifyDataSetChanged(redrawRequired: false)
                if returnMatrix != nil{
                    scaledMatrix = returnMatrix
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended ||
            recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            smallTextLayer = nil
            if barLineChart._isScaling
            {
                if drillState
                {
                    if (scaledMatrix?.a)! < (drillStateMatrix?.a)!
                    {
                        drillStateMatrix = scaledMatrix
                    }
                    else{
                    
                        let scaleAnimator = Animator()
                        
                        let scaleAInterpolator = Interpolator.interpolate(a: (scaledMatrix?.a)!, b: (drillStateMatrix?.a)!)
                        let scaleDInterpolator = Interpolator.interpolate(a: (scaledMatrix?.d)!, b: (drillStateMatrix?.d)!)
                        let translateXInterpolator = Interpolator.interpolate(a: (scaledMatrix?.tx)!, b: (drillStateMatrix?.tx)!)
                        let translateYInterpolator = Interpolator.interpolate(a: (scaledMatrix?.ty)!, b: (drillStateMatrix?.ty)!)
                        
                        scaleAnimator.updateBlock = { [unowned barLineChart] in
                            var matrix = self.scaledMatrix
                            matrix?.a = scaleAInterpolator(CGFloat(scaleAnimator.phaseX))
                            matrix?.d = scaleDInterpolator(CGFloat(scaleAnimator.phaseX))
                            matrix?.tx = translateXInterpolator(CGFloat(scaleAnimator.phaseX))
                            matrix?.ty = translateYInterpolator(CGFloat(scaleAnimator.phaseX))
                            let _ = barLineChart._viewPortHandler.refreshPlot(newMatrix: matrix!, chart: barLineChart, invalidate: true)
                            //barLineChart.notifyDataSetChanged(redrawRequired: false)
                        }
                        
                        scaleAnimator.stopBlock = { [unowned scaleAnimator] in
                            scaleAnimator.updateBlock = nil
                        }
                        
                        scaleAnimator.animate(xAxisDuration: 0.2)
                    }
                }
                
                barLineChart._isScaling = false
                
                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chartView)
                
                // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
                barLineChart.calculateOffsets()
                barLineChart.setNeedsDisplay()
                
            }
        }
    }
    var smallTextLayer:WordCloudTextLayer? = nil
    
    func getSmallTextSize(chart:ChartViewBase) -> CGFloat
    {
        let textLayer =  getSmallTextLayer(chart: chart)
        if textLayer == nil
        {
            return CGFloat.greatestFiniteMagnitude
        }
        else
        {
            let value = textLayer?.valueDict["fontSize"] as? CGFloat
            return value ?? CGFloat.greatestFiniteMagnitude
        }
    }
    
    func getSmallTextLayer(chart:ChartViewBase) -> WordCloudTextLayer?
    {
        var smallTextLayerTemp:WordCloudTextLayer? = nil
        
        var smallValue = Double.greatestFiniteMagnitude
        
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            if layer.chartEntry!.y < smallValue
            {
                smallTextLayerTemp = layer
                smallValue = layer.chartEntry!.y
            }
        }
        smallTextLayer = smallTextLayerTemp
        return smallTextLayerTemp
    }
    
}

