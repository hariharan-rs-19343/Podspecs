//
//  DefaultPanHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 14/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//



#if !os(OSX)
    import UIKit
#endif

open class DefaultPanHandler: NSObject, EventHandler {
    


    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }
    
    var isVerticalPan: Bool?
    
    var flag: Bool = true
    

    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart
       
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
     
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            // If drag is enabled and we are in a position where there's something to drag:
            //  * If we're zoomed in, then obviously we have something to drag.
            //  * If we have a drag offset - we always have something to drag
            /*  if barChart.isDragEnabled &&
             (!barChart.hasNoDragOffset || !barChart.isFullyZoomedOut)
             {
             barChart._isDragging = true
             
             barChart._closestDataSetToTouch = barChart.getDataSetByTouchPoint(point:  recognizer.location(ofTouch: 0, in: barChart))
             
             let translation = recognizer.translation(in: barChart)
             let didUserDrag = (barChart is HorizontalBarChartView) ? translation.y != 0.0 : translation.x != 0.0
             
             // Check to see if user dragged at all and if so, can the chart be dragged by the given amount
             if didUserDrag && !barChart.performPanChange(translation: translation)
             {
             if barChart._outerScrollView !== nil
             {
             // We can stop dragging right now, and let the scroll view take control
             barChart._outerScrollView = nil
             barChart._isDragging = false
             }
             }
             else
             {
             if barChart._outerScrollView !== nil
             {
             // Prevent the parent scroll view from scrolling
             barChart._outerScrollView?.isScrollEnabled = false
             }
             }
             
             barChart._lastPanPoint = recognizer.translation(in: barChart)
             }
             else if barChart.isHighlightPerDragEnabled
             {
             // We will only handle highlights on NSUIGestureRecognizerState.Changed
             
             barChart._isDragging = false
             }*/
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = true
            
          
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            
            if barChart._isDragging
            {
                
                if flag {
                    
                    let velocityPoint = recognizer.velocity(in: barChart)
                    
                    isVerticalPan = abs(velocityPoint.y) > abs(velocityPoint.x)
                    
                    flag = false
                }

                let originalTranslation = recognizer.translation(in: barChart)
                let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                
                if barChart.plotTypes.contains(.PackedBubble) || barChart.plotTypes.contains(.WordCloud) || barChart.plotTypes.contains(.GeoHeatMap) || barChart.plotTypes.contains(.Sanky)
                {
                    let _ = CommonHelperFunctions.performPanChangeforPlot(translation: translation, chart: chart)
                }
                else if barChart.plotTypes.contains(.HeatMap) {

                    if let isVerticalPan = isVerticalPan {

                        let trans = isVerticalPan ?
                        CGPoint(x: 0.0, y: originalTranslation.y - barChart._lastPanPoint.y) :
                        CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: 0.0)

                        let _ = CommonHelperFunctions.performPanChange(translation: trans, chart: chart)
                    }
                }
                else{
                    let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chart)
                }
                
                barChart._lastPanPoint = originalTranslation
            }

            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            barChart._isDragging = true
            
            if barChart._isDragging
            {
                if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                {
                    barChart.stopDeceleration()
                    
                    barChart._decelerationLastTime = CACurrentMediaTime()
                    var velocityPoint = recognizer.velocity(in: barChart)
                    
                    if barChart.plotTypes.contains(.HeatMap) && isVerticalPan != nil {
                        velocityPoint = isVerticalPan! ? CGPoint(x: 0.0, y: velocityPoint.y) : CGPoint(x: velocityPoint.x, y: 0.0)
                    }
                    
                    barChart._decelerationVelocity = velocityPoint
                    
                    barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                    barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                }
                
                barChart._isDragging = false
            }
                    
            if barChart._outerScrollView !== nil
            {
                barChart._outerScrollView?.nsuiIsScrollEnabled = true
                barChart._outerScrollView = nil
            }
            
            flag = true
        }
        
    }
}


