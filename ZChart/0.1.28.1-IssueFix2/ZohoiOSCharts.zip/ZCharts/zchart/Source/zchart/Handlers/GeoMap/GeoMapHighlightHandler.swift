//
//  GeoMapHighlightHandler.swift
//  zchart
//
//  Created by Aravinth T on 30/11/21.
//

import Foundation

open class GeoMapHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint)
    {
        GeoMapHelperFunctions.highLightMapEntry(chart: chart, entry: entry)
    }
        
}
