//
//  RadarHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 27/07/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class RadarHighlightHandler: NSObject, EventHandler {

    public static var needRefresh = false
    
    open var pointHighlight = true
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        var entry = entry
        
        var touchLocation = touchLocation
        
        guard let plotOption = chart.getPlotOptions(type: .Radar) as? DialPlotOptions
        else { return }
        
        if chart.isAnimationinProgress()
        {
            return
        }
        
        // To remove previous highlight laayer
        CommonHelperFunctions.removeHighlightLayer(chart: chart)
        
        for layer in ScatterLayer.getAllScatterLayer(chart: chart)
        {
                layer.strokeColor = NSUIColor.lightGray.cgColor
        }
        
        if RadarHighlightHandler.needRefresh
        {
            entry = nil
            RadarHighlightHandler.needRefresh = false
        }
        
        
        if chart.lastSelected != nil && chart.lastSelected!.count > 0 && entry != nil && entryLayer != nil
        {
            if chart.IsEntrySelected(entry: entry)
            {
                entry = nil
            }
            
        }
        
        let distance  = PieHelperFunctions.distance(from: plotOption.centerCircleBox, to: touchLocation)
        
        if entry != nil  && distance <= plotOption.radius {
            
            if pointHighlight
            {
                guard let set = chart.data?.getDataSetForEntry(entry) as? ChartDataSet
                    else { return }
                let entryLocation = CommonHelperFunctions.getPixelForValues(x: entry!.x, y: entry!.y, dataSet: set, chart: chart)
                
                let innerCircleShape = ShapeProperties()
                innerCircleShape.holeColor = nil // Set nil to fill default dataset color
                innerCircleShape.lineWidth = 2
                innerCircleShape.size = CGSize(width: 8.0, height: 8.0)
                innerCircleShape.strokeColor = NSUIColor.clear
                
                let outerCircleShape = ShapeProperties()
                outerCircleShape.holeColor = NSUIColor.white
                outerCircleShape.lineWidth = 2
                outerCircleShape.size = CGSize(width: 16.0, height: 16.0)
                outerCircleShape.strokeColor = nil
            
        
                chart.updateLastSelectedEntry(entry: entry)
                    
                ScatterHelperFunctions.highlightSingleEntry(chart: chart, entry: entry!, point: entryLocation, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
            }
            else{
                
                let layer = RadarHighlightHandler.getAreaLayerInPoint(chart: chart, loc: touchLocation)
                
                if layer != nil
                {
                    entry = layer?.chartEntry
                    chart.updateLastSelectedEntry(entry: entry)
                    chart.datasetSelected = true
                    touchLocation = CommonHelperFunctions.getEntryLocation(chart: chart, entry: entry!)!
                    
                    let lineDataSetOptions =  LineHelperFunctions.getLineDataSetOptions(dataSet: layer!.lineDataSet!)
                    
                    for currentLayer in LineLayer.getAllDataSetLayer(chart: chart)
                    {
                        if currentLayer.lineDataSet === layer?.lineDataSet
                        {
                            currentLayer.fillColor = lineDataSetOptions.fillColor.withAlphaComponent((lineDataSetOptions.fillAlpha)).cgColor
                            continue
                        }
                        currentLayer.fillColor = NSUIColor.gray.withAlphaComponent(0.3).cgColor
                    }
                }
                else{
                    chart.lastSelected = nil
                    chart.resetHighlight()
                    chart.setNeedsDisplay()
                    entry = nil
                }
            }
        
        }
        else{
            chart.lastSelected = nil
            chart.resetHighlight()
            chart.setNeedsDisplay()
            entry = nil
        }
        
        // Tooltip delegate
        chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(touchLocation), entry: entry)
    }
    
    public static func getAreaLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> LineLayer?
    {
        var selectedLayer:LineLayer? = nil
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            if (layer.path?.contains(loc))!
            {
                selectedLayer = (layer)
            }
            
        }
        return selectedLayer
    }
    
}
