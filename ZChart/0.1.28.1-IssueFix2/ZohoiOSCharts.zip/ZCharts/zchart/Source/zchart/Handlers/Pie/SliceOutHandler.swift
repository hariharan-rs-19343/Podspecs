//
//  SliceOutHandler.swift
//  zchart
//
//  Created by Aravinth T on 08/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class SliceOutHandler: NSObject, EventHandler
{
 
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.sliceout
    }

    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint)
    {
        if PieHelperFunctions.isInnerCircleTouched(chart: chart, location: touchLocation)
        {
            let entry = PieHelperFunctions.getEntryForInnerCircleTap(pieChart: chart)
            chart.tooltipSelected(entry: entry)
            return
        }
        
        let pieChart = chart 
        
        let high = pieChart.getHighlightByTouchPoint(touchLocation)
        
        if entryLayer != nil
        {
            let pieLayers = PieLayer.getAllPieLayer(chart: chart)
            
            if pieLayers.count > 1
            {
                PieHelperFunctions.sliceInOut(sliceLayer: entryLayer as! PieLayer, chart: pieChart, duration: 0.3, animation: .linear)
            }
            else{
//                pieChart.lastSelected = entryLayer?.chartEntry
                pieChart.updateLastSelectedEntry(entry: entryLayer?.chartEntry)
            }
        }
        else
        {
            if pieChart.lastSelected != nil && pieChart.lastSelected!.count > 0
            {
                let lastSelectedLayer = PieLayer.getPieLayerForEntry(chart: pieChart, entry: pieChart.lastSelected![0])
                PieHelperFunctions.sliceIn(sliceLayer:lastSelectedLayer!, chart: pieChart, duration: 0.5, completionBlock: nil)
                pieChart.lastSelected = nil
            }
        }
        
        var highForEntry:Highlight? = nil
        if pieChart.lastSelected != nil
        {
            highForEntry =  high
        }
        pieChart.callDelegateToContainer(highlight: highForEntry, entry: (pieChart.lastSelected != nil && pieChart.lastSelected!.count > 0 ) ? pieChart.lastSelected![0] : nil )
        
    }
    
    
    ///********************** Multiple Entry Removal Testing ********************
    /*var uniqueX = Set<String>()
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint)
    {
            if entryLayer != nil
            {
                uniqueX.insert((entry!.xString!))
                return
            }
            else{
            
                var removeEntries:[ChartDataEntry] = []
                for set in chart.data!.dataSets
                {
                    for entry in (set as! ChartDataSet).values where uniqueX.contains(entry.xString!)
                   {
                       removeEntries.append(entry)
                   }
                }
                PieHelperFunctions.removeEntries(entries: removeEntries, chart: chart, duration: 1, animation: .linear)
                uniqueX.removeAll()
            }
            
    }*/
    
}
