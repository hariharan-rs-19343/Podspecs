//
//  CombinedBarLineHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 07/03/19.
//  Copyright © 2019 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class CombinedBarLineHighlightHandler: NSObject, EventHandler {
    
    let lineHighlighter = LineHighlightHandler()
    let barHighlighter = BarHighlightHandler()
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.lineHighlight
    }
    
    func getLineEntry(lineData:ChartData,entry:ChartDataEntry,barLine:ChartViewBase) -> ChartDataEntry?
    {
        let xValue = round(entry.x)
        
        var lineEntry:ChartDataEntry? = lineData.getDataSetForEntry(entry) == nil ? nil : entry
        
        if lineEntry == nil
        {
            
            for lineLayer in LineLayer.getAllDataSetLayer(chart: barLine)
            {
                let entry = lineLayer.lineDataSet?.entryForXValue(xValue, closestToY: Double.nan)
                if entry != nil
                {
                    lineEntry = entry!
                    break
                }
            }
        }
        
        return lineEntry
    }
    
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
      
        let toggleMode = CombinedBarLineDoubleTapHandler.toggleMode
        
        if toggleMode == .Line
        {
            guard let lineData = chart.data,
            let entry = entry
                else { return }
            
            let lineEntry = getLineEntry(lineData: lineData, entry: entry, barLine: chart)
            
            lineHighlighter.execute(chart, entry: lineEntry, entryLayer: entryLayer, recognizer, touchLocation)
        }
        else if toggleMode == .Bar
        {
            barHighlighter.execute(chart, entry: entry, entryLayer: entryLayer, recognizer, touchLocation)
        }
        else{
            if entry != nil{
           
                let lineChart = (chart )
                LineHelperFunctions.removeMagnifyEffect(chart: lineChart)
                
                highlightBarLine(entry: entry!, location: touchLocation, barLine: chart)
                
            
            }
        }
    }
    
    
    public  func highlightBarLine(entry:ChartDataEntry,location:CGPoint, barLine:ChartViewBase)
    {
        
        guard let lineData = (barLine.data),
            let barPlot = barLine.getPlotOptions() as? AxisChartPlotOptions
            else { return }
        
        let quitBlock = {
            CommonHelperFunctions.removeHighlightLayer(chart: barLine)
            
            barLine.lastSelectedHigh = nil
            barLine.datasetSelected = false
            
            barLine.lastSelected = nil
            barPlot.barGroupSelectionEnabled = false
            
            
            barLine.callDelegateToContainer(highlight: nil, entry: nil)
            barLine.setNeedsDisplay()
        }
        
     
        if !barLine.viewPortHandler.isInBoundsX(location.x)
        {
            quitBlock()
            return
        }
        
        let xValue = round(entry.x)
        
        
        let lineEntry:ChartDataEntry? = getLineEntry(lineData: lineData, entry: entry, barLine: barLine)
        
        if barLine.lastSelected != nil && barLine.lastSelected!.count > 0 && floor((barLine.lastSelected![0].x)) == xValue
        {
            quitBlock()
            return
        }
        else
        {
            
            /// Bar
            for layer in BarLayer.getAllBarLayer(chart: barLine)
            {
                if round((layer.chartEntry?.x)!) == xValue
                {
                    layer.opacity = 1
                    layer.fillColor = layer.barDataSet?.color(atIndex: 0).cgColor //barData.highlightColor?.cgColor
                }
                else{
                    layer.opacity = 0.5
                    layer.fillColor = NSUIColor.gray.cgColor
                }
            }
            
//            barLine.lastSelected = entry
            barLine.updateLastSelectedEntry(entry: entry)
            barPlot.barGroupSelectionEnabled = true
            
            
            /// Line
            if lineEntry != nil
            {
                LineHelperFunctions.highlightAllDatasetEntry(entry:lineEntry!, chart: barLine, includeVerticalLine: false)
                
                let lineSet = (lineData.getDataSetForEntry(lineEntry!))!
                
                let lineEntryLocation = barLine.pixelForValues(x: (lineEntry?.x)!, y: (lineEntry?.y)!, axisIndex: lineSet.axisIndex)
                
                let high = barLine.getHighlightByTouchPoint(lineEntryLocation)
                
                barLine.lastHighlighted = high
                
                barLine.callDelegateToContainer(highlight: high, entry: lineEntry)
            }
            
            
        }
     
    }
}
