//
//  HorizontalStackedBarPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 20/07/18.
//  Copyright © 2018 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class HorizontalStackedBarPanHandler: NSObject,EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    
    
    var indexToBarLayer:[Double:BarLayer] = [:]
    
    var totalHeight:CGFloat = 0.0
    
    // 20 % of viewport height
    var maxHeight:CGFloat = 0.0
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart
        let barChartView = barChart
        
        guard let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar,.WaterFall,.BoxPlot]) as? BarPlotOptions //barChart.getPlotOptions(type: .HorizontalBar) as? BarPlotOptions
            else{ return }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: startLoc!)
            
            if barChart.lastSelected != nil && barChart.lastSelected!.count > 0
            {
                startLay = BarLayer.getBarLayerForEntry(chart: barChart, entry: barChart.lastSelected![0])
            }
            
            lastTouched = startLoc
            maxHeight = barChart.viewPortHandler.contentWidth * 0.2
            
            if startLay != nil{
                indexToBarLayer = BarHelperFunctions.getStackIndexToBarLayer(barChart: barChart)
                BarLayer.removeAllValueLayer(chart: barChart)
                totalHeight = getTotalWidthOfSelectedEntry(barChart: barChart )
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            //            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            guard let barData = barChart.data
                else { return }

            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            // **************************************** Vertical Pan Change**************************************************************
            if /*(barChart.lastSelected == startLay?.chartEntry)*/ barChart.IsEntrySelected(entry: startLay?.chartEntry) && verticalMove && !(recognizer.nsuiNumberOfTouches() == 2) && startLay != nil
            {
                trans = recognizer.translation(in: barChart)
                
                if chart.plotTypes.contains(.WaterFall) {
                    WaterFallHelperFunction.disableConnectorLine(chart: chart)
                }
                
                // **************************************** Group Selection **************************************************************
                if barChart.xGroupSelected
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let selectedBarEntry = (barChart.lastSelected![0])
                    
                    let barDataSet = (barChart.data?.dataSets[0] as! ChartDataSet)
                    
                    let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barDataSet)
                    
                    let negativeSum = BarHelperFunctions.getNegativeSum(chart: chart)
                    
                    var bottomYValue = negativeSum[selectedBarEntry.x] == nil ? baseLineValue : negativeSum[selectedBarEntry.x]!
                    
                    bottomYValue = chart.plotTypes.contains(.WaterFall) ? bottomYValue : -(bottomYValue)
                    
                    var bottomXPosition = barChart.pixelForValues(x: bottomYValue, y: 0, axisIndex: barDataSet.axisIndex).x

                    // **************************************** Group Drill **************************************************************
                    if trans.x > 0
                    {
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        let opac:CGFloat!
                        
                        let curHeight:CGFloat!
                        
                        if abs(trans.x) > (maxHeight)
                        {
                            trans.x = (maxHeight)
                        }
                        
                        let origDiff = maxHeight
                        
                        let curDiff =  origDiff - trans.x
                        
                        if curDiff < 0
                        {
                            opac = 0
                            curHeight = 0
                        }
                        else
                        {
                            
                            opac = (1/origDiff)*curDiff
                            
                            curHeight =  ((BarLayer.getAllBarLayer(chart: barChart)[0].barRect?.height)!/origDiff)*curDiff
                            
                            
                        }
                        
                        animationDuration = 0
                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart)
                        {
                            if barChart.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                            {
                                if  (layer.barRect?.minX)! == bottomXPosition && (layer.barRect?.width)! > 0
                                {
                                    BarHelperFunctions.changeBarXPositionAndWidth(barLayer: layer, changeXValue: 0, changeWidth: trans.x, chart: barChart, duration: animationDuration)
                                }
                                else
                                {
                                    BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: trans.x, chart: barChart, duration: animationDuration)
                                    
                                }
                            }
                            else{
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: opac, changeSize: CGSize(width: (layer.barRect?.width)!, height: curHeight), chart: barChart, duration: animationDuration)
                            }
                        }
                        
                    }
                        // **************************************** Group Filter **************************************************************
                    else
                    {
                        if dist >= (totalHeight)
                        {
                            trans.x = -totalHeight
                            animationDuration = 0
                        }
                        
                        let percent = abs(trans.x / totalHeight)
                        
                        if isGroupFilterAllowed(barChart: chart)
                        {
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                if barChart.IsEntryRoundedXSelected(x: round(layer.getBarChartEntry().x))//.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        bottomXPosition = Double((layer.barRect?.minX)!)
                                        
                                        if let medianLayer = MedianLayer.getMedianLayerForEntry(chart: chart, entry: layer.chartEntry!) {
                                            medianLayer.opacity(opacityValue: 0)
                                        }
                                    }
                                    
                                    var xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                    
                                    if layer.barDataSet?.plotType == .WaterFall && !plotOption.isStacked {
                                    
                                        xInterPolator = Interpolator.interpolate(a: layer.barRect!.minX, b: layer.barRect!.minX)
                                    
                                        if layer.chartEntry!.y < 0 {
                                            xInterPolator = Interpolator.interpolate(a: layer.barRect!.minX, b: layer.barRect!.maxX)
                                        }
                                    }
                                    
                                    let widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                    
                                    let newRect = CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent) , height: (layer.barRect?.height)!)
                                    
                                    let newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent) , height: (layer.barRect?.height)!))
                                    
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        
                                        let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: layer,rect: newRect, percent: percent)
                                        
                                        if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: layer.chartEntry!) {
//                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: animationDuration)
                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: animationDuration)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                    
                    // **************************************** Stack Selection **************************************************************
                    
                else //if barChart.lastSelectedStackIndex != -1
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let barWidth = (startLay?.barRect?.size.width)!
                    
                    // **************************************** Stack Drill **************************************************************
                    
                    if trans.x > 0
                    {
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        let heightToDrill = maxHeight
                        
                        if abs(trans.x) > heightToDrill
                        {
                            trans.x = heightToDrill
                        }
                        
                        let percent = abs(trans.x / heightToDrill)
                        
                        
                        var index = -1
                      
                        let barDataSet = (barData.dataSets[0] as! ChartDataSet)
                        
                        let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barDataSet)
                        
                        guard let lastSelectedEntries = barChart.lastSelected,
                            lastSelectedEntries.count > 0,
                            let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0])
                        else { return  }
                        
                        let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)

                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart)
                        {
                            index += 1
                            
                            let layerEntry = layer.chartEntry!
                            
                            let currentDataSetIndex = barData.indexOfDataSet(layer.barDataSet!)
                            
                            let positiveSum = BarHelperFunctions.getPositiveSum(chart: chart)
                            let negativeSum = BarHelperFunctions.getNegativeSum(chart: chart)
                            
                            var topValue = positiveSum[layerEntry.x] == nil ? baseLineValue : positiveSum[layerEntry.x]!
                            var bottomValue = negativeSum[layerEntry.x] == nil ? baseLineValue : -(negativeSum[layerEntry.x]!)
                            
                            if BarHelperFunctions.isStackPercentEnabled(chart: chart)
                            {
                                topValue = 100
                                bottomValue = 0
                            }
                            
                            let topXPosition = barChart.pixelForValues(x: topValue, y: 0, axisIndex: (barDataSet.axisIndex)).x
                            let bottomXPosition = barChart.pixelForValues(x: bottomValue, y: 0, axisIndex: (barDataSet.axisIndex)).x
                            
                            let filterLayer = indexToBarLayer[layerEntry.x]
                            
                            if filterLayer == nil || (filterLayer?.barRect?.width)! == 0
                            {
                                continue
                            }
                            
                            let xInterPolator:((CGFloat) -> CGFloat)
                            let widthInterpolator:((CGFloat) -> CGFloat)
                            
                            if (layer.barRect?.minX)! < (filterLayer?.barRect?.minX)! && currentDataSetIndex != lastSelectedDataSetIndex
                            {
                                xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                
                            }
                            else if currentDataSetIndex == lastSelectedDataSetIndex
                            {
                                
                                xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: (topXPosition - bottomXPosition))
                                
                            }
                            else{
                                
                                xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: topXPosition)
                                widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                
                            }
                            
                            let newRect = CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent), height: (layer.barRect?.height)!)
                            
                            let newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent), height: (layer.barRect?.height)!))
                            
                            CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0)
                            
                        }
                        
                        return
                        
                    }
                        // **************************************** Stack Filter **************************************************************
                    else if dist >= (barWidth)
                    {
                        trans.x = -barWidth
                        animationDuration = 0
                    }
                    
                    if isStackEntryFilterAllowed(barData: barData)
                    {
                        let percent = abs(trans.x / barWidth)
                        
                        BarHelperFunctions.callHorizontalGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: percent)
                    }
                    else{
                        return
                    }
                    
                }
                //                }
            }
                // **************************************** Horizontal Pan Change **************************************************************
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                
                if recognizer.nsuiNumberOfTouches() == 2
                {
                    barChart._isDragging = true
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chart)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        plotOption.barGroupSelectionEnabled = true
                        barChart.xGroupSelected = true
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
            // **************************************** Verical Pan End **************************************************************
            if verticalMove && startLay != nil  && !barChart._isDragging
            {
                let vel = recognizer.velocity(in: barChart)
                
                guard let barData = barChart.data
                    else { return }

                // **************************************** Grouped Selection End  **************************************************************
                if barChart.xGroupSelected
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let selectedBarEntry = (barChart.lastSelected![0])
                    
                    let barDataSet = (barChart.data?.dataSets[0] as! ChartDataSet)
                    
                    let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: barDataSet)
                    
                    let negativeSum = BarHelperFunctions.getNegativeSum(chart: chart)
                    
                    var bottomYValue = negativeSum[selectedBarEntry.x] == nil ? baseLineValue : negativeSum[selectedBarEntry.x]!
                    
                    bottomYValue = chart.plotTypes.contains(.WaterFall) ? bottomYValue : -(bottomYValue)
                    
                    var bottomXPosition = barChart.pixelForValues(x: bottomYValue, y: 0, axisIndex: barDataSet.axisIndex).x

                    // **************************************** Grouped Drill  **************************************************************
                    if trans.x > 0
                    {
                        // **************************************** Drill Performed **************************************************************
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        if abs(trans.x) >= (maxHeight)
                        {
                            trans.x = maxHeight
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                if barChart.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    let newRect = CGRect(x: bottomXPosition , y: (layer.barRect?.minY)!, width: plotOption.roundedRadii + 2.0 , height: (layer.barRect?.height)!)
                                    let newPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: bottomXPosition , y: (layer.barRect?.minY)!, width: 0 , height: (layer.barRect?.height)!))
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                                BarHelperFunctions.drillEntry(barEntry: barChart.lastSelected![0], chart: chart)
                            })
                        }
                            // **************************************** Drill reverted **************************************************************
                        else{
                            trans.x = 0
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let barPath = layer.getPath(rect: layer.barRect!)//UIBezierPath(rect:layer.barRect!)
                                //                                BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: barPath, chart: barChart, duration: animationDuration)
                                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                            }
                            
                        }
                    }
                        // **************************************** Grouped Filter  **************************************************************
                    else
                    {
                        var filtered = true
                        
                        if vel.x < -1200
                        {
                            trans.x = -totalHeight
                            animationDuration = 0.2
                        }
                        else if dist > (totalHeight / 2 ) &&  dist <= (totalHeight )
                        {
                            trans.x = -totalHeight
                            animationDuration = 0.2
                        }
                        else if dist >= (totalHeight)
                        {
                            trans.x = -totalHeight
                            animationDuration = 0
                        }
                        else if dist <= (totalHeight / 2)
                        {
                            filtered = false
                            trans.x = 0
                            animationDuration = 0.2
                        }
                        
                        let percent = abs(trans.x / totalHeight)
                        
                        if isGroupFilterAllowed(barChart: chart)
                        {
                            barChart.interactionAnimationInProgress = true
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart )
                            {
                                if barChart.IsEntryRoundedXSelected(x: round(layer.getBarChartEntry().x))//.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        bottomXPosition = Double((layer.barRect?.minX)!)
                                        
                                        if let medianLayer = MedianLayer.getMedianLayerForEntry(chart: chart, entry: layer.chartEntry!) {
                                            medianLayer.opacity(opacityValue: 0)
                                        }
                                    }
                                    
                                    var xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                    
                                    if layer.barDataSet?.plotType == .WaterFall && !plotOption.isStacked {
                                    
                                        xInterPolator = Interpolator.interpolate(a: layer.barRect!.minX, b: layer.barRect!.minX)
                                    
                                        if layer.chartEntry!.y < 0 {
                                            xInterPolator = Interpolator.interpolate(a: layer.barRect!.minX, b: layer.barRect!.maxX)
                                        }
                                    }
                                    
                                    let widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                    
                                    let newRect = CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent) , height: (layer.barRect?.height)!)
                                    
                                    let newPath = layer.getPath(rect: newRect)
                                    
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                    
                                    if layer.barDataSet?.plotType == .BoxPlot {
                                        
                                        let finalPath = ChartInteractionHelperFunction.preformWhiskersAnimation(layer: layer,rect: newRect, percent: percent)
                                        
                                        if let whiskerLayer = WhiskersLayer.getWhiskersLayerForEntry(chart: chart, entry: layer.chartEntry!) {
//                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: UIBezierPath(cgPath: finalPath), duration: animationDuration)
                                            CommonHelperFunctions.performPathAnim(targetLayer: whiskerLayer, newPath: finalPath, duration: animationDuration)
                                        }
                                    }
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: { [unowned chart] in
                                
                                if filtered
                                {
                                    BarHelperFunctions.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true, chart: barChart)
                                }
                                else {
                                    barChart.interactionAnimationInProgress = false
                                    
                                    if barChart.plotTypes.contains(.WaterFall) {
                                        WaterFallHelperFunction.enableConnectorLine(chart: chart)
                                    }
                                    
                                    if barChart.plotTypes.contains(.BoxPlot) {
                                        if let medianLayer = MedianLayer.getMedianLayerForEntry(chart: chart, entry: (self.startLay?.getBarChartEntry())!) {
                                            medianLayer.opacity(opacityValue: 1)
                                        }
                                    }
                                }
                                
                            })
                        }
                        
                    }
                }
                    // **************************************** Stack Selection End **************************************************************
                else if barChart.lastSelected != nil
                {
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let barWidth = (startLay?.barRect?.size.width)!
                    
                    var animationDuration:TimeInterval = 0
                    
                    // **************************************** Stack Drill  **************************************************************
                    
                    if trans.x > 0
                    {
                        // Height required to drill
                        let heightToDrill = maxHeight
                        
                        // **************************************** Drill Performed  **************************************************************
                        
                        if chart.plotTypes.contains(.BoxPlot) || chart.plotTypes.contains(.WaterFall) {
                            return
                        }
                        
                        if abs(trans.x) >= heightToDrill
                        {
                            let baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: (barData.dataSets[0]))
                            let baseLineYPosition = barChart.pixelForValues(x: baseLineValue, y: 0, axisIndex:  (barData.dataSets[0]).axisIndex).x

                            let percentEnabled = BarHelperFunctions.isStackPercentEnabled(chart: chart)
                            
                            var indexCount = -1
                         
                            guard let lastSelectedEntries = barChart.lastSelected,
                                lastSelectedEntries.count > 0,
                                let lastSelectedSet = barData.getDataSetForEntry(lastSelectedEntries[0])
                                else { return  }
                            
                            let lastSelectedDataSetIndex = barData.indexOfDataSet(lastSelectedSet)
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                indexCount += 1
                                
                                let filterLayer = indexToBarLayer[(layer.chartEntry?.x)!]
                                
                                if filterLayer == nil
                                {
                                    CommonHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: 0, duration: 0.75)
                                    continue
                                }
                                
                                let stackValue = (filterLayer?.chartEntry?.y)!
                                
                                let currentDataSetIndex = barData.indexOfDataSet(layer.barDataSet!)

                                // Current Drilled Stack
                                if currentDataSetIndex == lastSelectedDataSetIndex && !percentEnabled
                                {
                                    let aboveBaseLine = (layer.chartEntry?.y)! > baseLineValue

                                    let xValue:CGFloat
                                    
                                    if aboveBaseLine
                                    {
                                        xValue = baseLineYPosition
                                    }
                                    else{
                                        xValue = baseLineYPosition - (layer.barRect?.width)!
                                    }
                                    
                                    let newRect = CGRect(x: xValue, y: (layer.barRect?.minY)!, width: (layer.barRect?.width)!, height: (layer.barRect?.height)!)
                                    
                                    let toPath = layer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: xValue, y: (layer.barRect?.minY)!, width: (layer.barRect?.width)!, height: (layer.barRect?.height)!))
                                    
                                    //                                    BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: toPath, chart: barChart, duration: 1)
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: toPath, duration: 1)
                                }
                                else if stackValue.isNaN || stackValue == 0
                                {
                                    CommonHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: 0, duration: 0.75)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(1)*CGFloat(1000))), execute: { [unowned barChart] in
                                
                                var setArray:[IChartDataSet] = []
                                for index in 0..<(barData.dataSets.count)
                                {
                                    let dataset = barData.dataSets[index]
                                    if dataset.isVisible && index != lastSelectedDataSetIndex
                                    {
                                        setArray.append(dataset)
                                    }
                                }
                                barChart.lastSelected = nil
                                
                                //CommonHelperFunctions.hideDataSet(selectedDataset: setArray, chart: chart)
                                
                                ChartInteractionHelperFunction.hideDataSetWithAnimation(barChart: barChart, selectedDataset: setArray, animationOptions: .StackedBaralign, animationDuration: 0.3)
                                
                            })
                            
                        }
                            // **************************************** Drill Reverted  **************************************************************
                        else{
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let barPath = layer.getPath(rect: layer.barRect!)//UIBezierPath(rect:layer.barRect!)
                                //                                BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: barPath, chart: barChart, duration: 0)
                                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: 0)
                            }
                        }
                        
                    }
                        
                        // **************************************** Stack Filter  **************************************************************
                    else
                    {
                        if vel.x < -1200
                        {
                            trans.x = -barWidth
                            animationDuration = 0.2
                        }
                        else if dist > (barWidth / 2 ) &&  dist <= (barWidth )
                        {
                            trans.x = -barWidth
                            animationDuration = 0.2
                        }
                        else if dist >= (barWidth)
                        {
                            trans.x = -barWidth
                            animationDuration = 0
                        }
                        else if dist <= (barWidth / 2)
                        {
                            trans.x = 0
                            animationDuration = 0.2
                        }
                        if isStackEntryFilterAllowed(barData:barData)
                        {
                            barChart.interactionAnimationInProgress = true
                            
                            let percent = abs(trans.x / (startLay?.barRect?.width)!)
                            
                            BarHelperFunctions.callHorizontalGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: percent)
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                                
                                let boundingRect = (self.startLay?.path?.boundingBox)!
                                
                                if boundingRect.size.width == 0
                                {
                                    if BarHelperFunctions.isStackPercentEnabled(chart: chart)
                                    {
                                        BarHelperFunctions.callGroupFilterEndAnimation(chartView: barChart, animationDuration: 0.15)
                                        
                                        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(0.15)*CGFloat(1000))), execute: { [unowned chart] in
                                            BarHelperFunctions.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true, chart: chart)
                                        })
                                    }
                                    else{
                                        BarHelperFunctions.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true, chart: chart)
                                    }
                                }
                                else{
                                    barChart.interactionAnimationInProgress = false
                                }
                                
                            })
                        }
                        else{
                            return
                        }
                    }
                    
                }
                
                
            }
                // **************************************** Horizontal Pan End **************************************************************
            else{
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.nsuiIsScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
    
    open func getTotalWidthOfSelectedEntry(barChart:ChartViewBase) -> CGFloat
    {
        var width:CGFloat = 0.0
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            if barChart.IsEntryXSelected(x: layer.getBarChartEntry().x) //layer.getBarChartEntry().x == barChart.lastSelected?.x
            {
                width = width + (layer.barRect?.size.width)!
            }
        }
        
        return width
    }
    
    open func distance(from: CGPoint, to: CGPoint) -> CGFloat
    {
        let dx = from.x - to.x
        let dy = from.y - to.y
        return sqrt(dx * dx + dy * dy)
    }
    
    open func isStackEntryFilterAllowed(barData:ChartData) ->  Bool
    {
        if CommonHelperFunctions.getVisibleSetCount(data: barData) == 1
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    open func isGroupFilterAllowed(barChart:ChartViewBase) -> Bool
    {
        let count = barChart.data?.dataSets[0].entryCount
        if (count)! <= 1
        {
            return false
        }
        else
        {
            return true
        }
    }
}


