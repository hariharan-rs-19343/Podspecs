//
//  RotationTouchHandler.swift
//  zchart
//
//  Created by Aravinth T on 11/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class RotationTouchHandler: NSObject, TouchHandler {

   public func getTouchHandlerType() -> TouchHandlerType
    {
        
        return TouchHandlerType.rotation
    }
    
   public func touchEventBegan(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
        
       #if !os(OSX)
        chartView._tapEventListener?.delaysTouchesBegan = false
       #endif
       
        PieHelperFunctions.beginRotation(touches, withEvent: event, chart: chartView)
    }
    
   public func touchEventMoved(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
        
        PieHelperFunctions.moveRotation(touches, withEvent: event, chart: chartView)
    }
    
   public func touchEventEnded(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
        
        PieHelperFunctions.endRotation(touches, withEvent: event, chart: chartView)
    }
    
   public func touchEventCancelled(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: ChartEntryLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
        
    guard let piePlot = chartView.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
    
        if piePlot._isRotating
        {
            piePlot._isRotating = false
        }

    }
    
    
}
