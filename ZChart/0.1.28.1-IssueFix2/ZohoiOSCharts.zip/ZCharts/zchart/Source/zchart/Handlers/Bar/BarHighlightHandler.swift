//
//  BarHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 19/09/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class BarHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
//        compareYAxisLabelFrame(chart: chart, touchLocation: touchLocation)
        
        let barLineChart = chart
        
        barLineChart.resetHighlight()
        
        BarHelperFunctions.highlightBar(location: touchLocation, bar: barLineChart)
        
        let high = (barLineChart.lastSelected != nil && barLineChart.lastSelected!.count > 0) ? chart.getHighlightByEntry(barLineChart.lastSelected![0]) : nil                 //chart.getHighlightByTouchPoint(touchLocation)
        
        chart.highlightValue( high, callDelegate: true)
        
        /*
//        if barLineChart.viewPortHandler.isInBounds(x: touchLocation.x, y: touchLocation.y){
            
            BarHelperFunctions.highlightBar(location: touchLocation, bar: barLineChart)
            
            let high = (barLineChart.lastSelected != nil && barLineChart.lastSelected!.count > 0) ? chart.getHighlightByEntry(barLineChart.lastSelected![0]) : nil                 //chart.getHighlightByTouchPoint(touchLocation)

            chart.highlightValue( high, callDelegate: false)
            
        }
        else*/ if touchLocation.x < barLineChart.viewPortHandler.contentRect.maxX || touchLocation.y < barLineChart.viewPortHandler.contentRect.maxY
        {
            
            for tick in barLineChart.xAxisRenderer.tickLabels
            {
                if tick.boundPath.contains(touchLocation)
                {
                    if let dataEntry = barLineChart.data?.dataSets[0].entryForString(tick.label){
                        
                        BarHelperFunctions.HighlightByDataEntry(entry: dataEntry, bar: barLineChart)

                        let high = (barLineChart.lastSelected != nil && barLineChart.lastSelected!.count > 0) ? chart.getHighlightByEntry(barLineChart.lastSelected![0]) : nil

                        chart.highlightValue( high, callDelegate: false)

                        break
                    }
                }
            }

        }
        
    }
    
  /*  private func compareYAxisLabelFrame(chart:ChartViewBase,  touchLocation: CGPoint) {
        let axisChart = chart as! BarLineChartViewBase
        
        for yAxis in axisChart.getYAxisArray() where yAxis.isEnabled && yAxis.isVisible {
            
            var rect = getTitleFrame(yAxis: yAxis, axisChart: axisChart)
            if axisChart.isKind(of: HorizontalBarChartView.self) {
                rect = getTitleFrameForHorizontal(yAxis: yAxis, axisChart: axisChart)
            }
            
            let containsPoint = rect.contains(touchLocation)
            
            print("Axis Title ", yAxis.axisTitle, " Frame ", rect, " touch Location ", touchLocation, " contains ", containsPoint)
            let extraPadding:CGFloat = 30
            
            if containsPoint {
                
                let layer = CATextLayer()
                layer.string = yAxis.axisTitle
                let font = yAxis.axisTitleFont
                let color = yAxis.axisTitleColor
                
//                var frame = CGRect.zero
                
//                layer.frame = frame
                
//                let frame = CGRect(x: rect.midX, y: rect.midY - rect.width / 2 , width: rect.height, height: rect.width)
                var frame = CGRect(x: 0, y: 0 , width: rect.height + extraPadding, height: rect.width )
                
                if axisChart.isKind(of: HorizontalBarChartView.self) {
                    frame = CGRect(x: 0, y: 0 , width: rect.width + extraPadding, height: rect.height )
                }
                
                layer.frame = frame
                layer.alignmentMode = CATextLayerAlignmentMode(rawValue: "center")//("center")
                layer.fontSize = font.pointSize
                layer.font = font
                layer.foregroundColor = color.cgColor
                layer.contentsScale = UIScreen.main.scale
                layer.backgroundColor = NSUIColor.lightGray.cgColor
                
                let degrees = 270.0
                let radians = CGFloat(degrees * .pi / 180)
                /*var transform = CATransform3DMakeTranslation(rect.midX - (rect.height + extraPadding) / 2 , rect.midY - (rect.width ) / 2, 0)
                transform = CATransform3DRotate(transform, radians, 0.0, 0.0, 1.0) */
                
                var  transform = CATransform3DIdentity
                if axisChart.isKind(of: HorizontalBarChartView.self) {
                  transform = CATransform3DMakeTranslation(rect.midX - (rect.width + extraPadding) / 2 , rect.midY - (rect.height ) / 2, 0)
                }else {
                    transform = CATransform3DMakeTranslation(rect.midX - (rect.height + extraPadding) / 2 , rect.midY - (rect.width ) / 2, 0)
                    transform = CATransform3DRotate(transform, radians, 0.0, 0.0, 1.0)
                }
                layer.transform =  transform
                
                axisChart.layer.addSublayer(layer)
            }
        }
    }
    
    private func getTitleFrame(yAxis:YAxis,axisChart:BarLineChartViewBase) -> CGRect   {
        
        let viewPortHandler = axisChart.viewPortHandler!
        
        var xPos = CGFloat(0.0)
        
        if yAxis.axisDependency == .left
        {
            xPos = viewPortHandler.offsetLeft  + yAxis.offsetCalculated
        }
        else
        {
            xPos = viewPortHandler.contentRight + yAxis.offsetCalculated
        }
        
        var labelMaxSize = CGSize()
        
        labelMaxSize.height = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).height
        labelMaxSize.width = (viewPortHandler.contentRect.height)*(3/4)
        
        let textWidth = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).width
        let textHeight = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).height
        
        var point = CGPoint()
        point.y = (viewPortHandler.contentRect.midY) - (min(labelMaxSize.width,textWidth)/2)
        
        if yAxis.axisDependency == .left && yAxis.enabled
        {
            point.x = xPos - (yAxis).requiredSize().width + yAxis.xOffset/2
        }
        else if yAxis.axisDependency == .right && yAxis.enabled
        {
            point.x = xPos + (yAxis).requiredSize().width - yAxis.xOffset/2 - textHeight
        }
        
        return CGRect(x: point.x, y: point.y, width: textHeight, height: textWidth)
    }
    
    private func getTitleFrameForHorizontal(yAxis:YAxis,axisChart:BarLineChartViewBase) -> CGRect {
        
        let viewPortHandler = axisChart.viewPortHandler!
        
        let lineHeight = yAxis.labelFont.lineHeight
        let dependency = yAxis.axisDependency
        var yPos: CGFloat = 0.0
        
        if dependency == .left{
            yPos = viewPortHandler.contentTop
        }else {
            yPos = viewPortHandler.contentBottom + lineHeight
        }
        //MultiYAxis
        yPos +=  yAxis.offsetCalculated
        yPos -= lineHeight
        
        
        var labelMaxSize = CGSize()
        
        labelMaxSize.width = (viewPortHandler.contentRect.width)*(3/4)
        
        let textWidth = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).width
        let textHeight = (yAxis.axisTitle).size(withAttributes: [NSAttributedString.Key.font:yAxis.axisTitleFont]).height
        
        yPos -= textHeight / 2 // To Align properly
        
        var point = CGPoint()
        point.x = (viewPortHandler.contentRect.midX) - (min(labelMaxSize.width,textWidth)/2)
        
        if yAxis.axisDependency == .left && yAxis.enabled {
            point.y = yPos - yAxis.getRequiredHeightSpace() + (yAxis.yOffset/2) + (textHeight)
        } else if yAxis.axisDependency == .right && yAxis.enabled {
            point.y = yPos +  yAxis.getRequiredHeightSpace() - (yAxis.yOffset/2) - (textHeight/2)
        }
        
        return CGRect(x: point.x, y: point.y, width: textWidth, height: textHeight)
    } */
    
    
    ///********************** Multiple X Removal Testing ********************
    
    /*var uniqueX = Set<Double>()
        
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {

            var curSelected:BarLayer? = nil
            
            let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar, .HorizontalBar]) as! BarPlotOptions
                   
            if barPlotOptions.isStacked || (chart.data!.dataSetCount) > 1
           {
               curSelected = BarLayer.getBarLayerInPointOriginal(chart: chart ,loc: touchLocation)
               
           }
           else
           {
               curSelected = BarLayer.getBarLayerInPoint(chart: chart ,loc: touchLocation)
           }
            
            if curSelected != nil{
                uniqueX.insert((curSelected?.chartEntry!.x)!)
            }
            else if !(chart.viewPortHandler.isInBoundsX(touchLocation.x)){
                chart.updateDataOrigIndex()
                var removeEntries:[ChartDataEntry] = []
                for set in chart.data!.dataSets
                {
                    for entry in (set as! ChartDataSet).values where uniqueX.contains(entry.x)
                   {
                       removeEntries.append(entry)
                   }
                }
                ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: chart, duration: 3)
                uniqueX.removeAll()
            }
        
            return
        }*/
}
