//
//  CustomRoundedStackedBarLongPressListener.swift
//  zchart
//
//  Created by keerthi-pt4274 on 31/05/22.
//

#if !os(OSX)
    import UIKit
#endif

#if os(iOS)
open class CustomRoundedStackedBarLongPressListener: NSObject,EventHandler {
    
    var prevEntry:ChartDataEntry? = nil
    
    var prevStackedIndex:Int? = -1
    
    var horizontalChart = false
    
    open var layersForX: [Double:[BarLayer]]?
    
    open var cornerRadii: CGSize?
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?,
                 _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint)
    {
        var entryLayer = entryLayer
        
        guard let plotOption = CommonHelperFunctions.getPlotOption(chart: chartView, types: [.Bar]) as? BarPlotOptions
            else { return }
        
        if entryLayer == nil{
            entryLayer = BarLayer.getBarLayerInPoint(chart: chartView, loc: touchLocation)
        }
        
        let bar = chartView
        
        if entryLayer == nil
        {
            if recognizer?.state == .ended
            {
                reloadBar(barChartView: bar)
            }
            return
        }
        
        let high = bar.getHighlightByTouchPoint(touchLocation)
        
        let barLayer = entryLayer as! BarLayer
        
        if recognizer?.state == .began
        {
            reloadBar(barChartView: chartView )
            
            if bar.isRotated
            {
                horizontalChart = true
            }
            
            BarLayer.removeAllValueLayer(chart: bar)
            
            prevEntry = barLayer.getBarChartEntry()
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                var newSize = (layer.barRect?.size)!
                
                if layer.getBarChartEntry().x == barLayer.getBarChartEntry().x
                {
                    if horizontalChart
                    {
                        newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                    }
                    else{
                        newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                    }
                    
                    barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                }
                else
                {
                    
                    if horizontalChart
                    {
                        newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                    }
                    else{
                        newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                    }
                    
                    barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                }
            }
            
            plotOption.barGroupSelectionEnabled = true
            bar.callDelegateToContainer(highlight: high, entry: entry)
            
        }
        else if recognizer?.state == .changed
        {
            if prevEntry!.x == barLayer.getBarChartEntry().x
            {
                let setIndex = bar.data?.indexOfDataSet(barLayer.barDataSet!)
                
                if prevStackedIndex == -1
                {
                    prevStackedIndex = setIndex
                }
                else if prevStackedIndex == setIndex  // Same bar entry and same stack
                {
                    
                }
                else // Same bar entry and different stack
                {
                    prevStackedIndex = setIndex
                    
                    for layer in BarLayer.getAllBarLayer(chart: bar)
                    {
                        var newSize = (layer.barRect?.size)!
                        
                        let layerSetIndex = bar.data?.indexOfDataSet(layer.barDataSet!)
                        
                        if  layerSetIndex == setIndex
                        {
                            if horizontalChart
                            {
                                newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                            }
                            else{
                                newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                            }
                            
                            if layer.getBarChartEntry().x != barLayer.getBarChartEntry().x
                            {
                                if horizontalChart
                                {
                                    newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                                }
                                else{
                                    newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                                }
                            }
                            
                            let color = plotOption.highlightColor?.cgColor
                            if color != nil
                            {
                                layer.fillColor = color
                            }
                            else
                            {
                                let entryIndex = layer.barDataSet?.entryIndex(entry: layer.chartEntry!)
                                layer.fillColor = layer.barDataSet?.color(atIndex: entryIndex!).cgColor
                            }
                            
                            barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                            
                        }
                        else
                        {
                            if horizontalChart
                            {
                                newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                            }
                            else{
                                newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                            }
                            
                            if layer.getBarChartEntry().x == barLayer.getBarChartEntry().x
                            {
                                if horizontalChart
                                {
                                    newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                                }
                                else{
                                    newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                                }
                            }
                            
                            let color = plotOption.nonHighlightColor?.cgColor
                            
                            var changeOpacity:CGFloat
                            
                            if color != nil
                            {
                                layer.fillColor = color
                                changeOpacity = 1.0
                            }
                            else{
                                changeOpacity = 0.5
                                let entryIndex = layer.barDataSet?.entryIndex(entry: layer.chartEntry!)
                                layer.fillColor = layer.barDataSet?.color(atIndex: entryIndex!).cgColor
                            }
                            
                            barSizeOpacityAnimator(barLayer: layer, opacity: changeOpacity, changeSize: newSize, chart: bar, duration: 0.2)
                            
                        }
                    }
                    
                    plotOption.barGroupSelectionEnabled = false
                    bar.callDelegateToContainer(highlight: high, entry: barLayer.getBarChartEntry())
                }
            }
            else
            {
                for layer in BarLayer.getAllBarLayer(chart: bar)
                {
                    var newSize = (layer.barRect?.size)!
                    
                    if layer.getBarChartEntry().x == barLayer.getBarChartEntry().x
                    {
                        
                        if horizontalChart
                        {
                            newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                        }
                        else{
                            newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                        }
                        
                        let color = plotOption.highlightColor?.cgColor
                        if color != nil
                        {
                            layer.fillColor = color
                        }
                        else
                        {
                            let entryIndex = layer.barDataSet?.entryIndex(entry: layer.chartEntry!)
                            layer.fillColor = layer.barDataSet?.color(atIndex: entryIndex!).cgColor
                        }
                        
                        barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                        
                    }
                    else
                    {
                        if horizontalChart
                        {
                            newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                        }
                        else{
                            newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                        }
                        
                        let color = plotOption.nonHighlightColor?.cgColor
                        
                        var changeOpacity:CGFloat
                        
                        if color != nil
                        {
                            layer.fillColor = color
                            changeOpacity = 1.0
                        }
                        else{
                            changeOpacity = 0.5
                            let entryIndex = layer.barDataSet?.entryIndex(entry: layer.chartEntry!)
                            layer.fillColor = layer.barDataSet?.color(atIndex: entryIndex!).cgColor
                        }
                        
                        barSizeOpacityAnimator(barLayer: layer, opacity: changeOpacity, changeSize: newSize, chart: bar, duration: 0.2)
                        
                    }
                }
                
                prevStackedIndex = -1
                
                plotOption.barGroupSelectionEnabled = true
                bar.callDelegateToContainer(highlight: high, entry: barLayer.getBarChartEntry())
                
            }
            
            prevEntry = barLayer.getBarChartEntry()
        }
        else if recognizer?.state == .ended
        {
            // reloadBar(barChartView: bar)
        }
    }
    
    
    func resetBarChanges(barChartView:ChartViewBase)
    {
        guard let plotOption = barChartView.getPlotOptions(type: .Bar) as? BarPlotOptions
        else { return }
        
        prevEntry = nil
        prevStackedIndex = -1
        plotOption.barGroupSelectionEnabled = false
        barChartView.lastSelected = nil
        barChartView.callDelegateToContainer(highlight: nil, entry: nil)
    }
    
    func reloadBar(barChartView:ChartViewBase)
    {
        resetBarChanges(barChartView: barChartView)
        barChartView.setNeedsDisplay()
    }
    
   public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    
}

extension CustomRoundedStackedBarLongPressListener {
    
    func barSizeOpacityAnimator(barLayer:BarLayer,opacity:CGFloat,changeSize:CGSize,chart:ChartViewBase,duration:TimeInterval)
    {
        let barRect = barLayer.barRect!
        
        let newRect = CGRect(x: (barRect.origin.x + ((barRect.size.width - changeSize.width)/2)), y: (barRect.origin.y + ((barRect.size.height - changeSize.height)/2)), width: changeSize.width, height: changeSize.height)
        
        customRoundedRect(layer: barLayer,newRect: newRect)
        
//        let newPath = UIBezierPath(cgPath: barLayer.path!)//barLayer.getPath(rect: newRect)//UIBezierPath(rect: newRect)
        let newPath = barLayer.path as! CGMutablePath
        CommonHelperFunctions.performPathAnim(targetLayer: barLayer, newPath: newPath, duration: duration)
        
        CommonHelperFunctions.performOpacityAnim(targetLayer: barLayer, opacity: opacity, duration: duration)
    
    }
    
    public func customRoundedRect(layer: BarLayer,newRect: CGRect) {
        
        guard let layersForX = self.layersForX,
              let xVal = layer.chartEntry?.x,
              let cornerRadii = self.cornerRadii else{
            return
        }
        
        var positiveLayer: BarLayer?
        var bottomPositiveLayer: BarLayer?
        var negativeLayer: BarLayer?
        var topNegativeLayer: BarLayer?
            
        var bottomPositiveFlag = true
        var topNegativeFlag = true
            
        for index in 0..<layersForX[xVal]!.count {
            let layer = layersForX[xVal]![index]
                
            if bottomPositiveFlag && layer.chartEntry!.y > 0 {
                bottomPositiveFlag = false
                bottomPositiveLayer = layer
            }
                
            if layer.chartEntry!.y > 0 {
                positiveLayer = layer
            }
                
            if topNegativeFlag && layer.chartEntry!.y < 0 {
                topNegativeFlag = false
                topNegativeLayer = layer
            }
                
            if layer.chartEntry!.y < 0 {
                negativeLayer = layer
            }
        }
        
        var cornerOptions: UIRectCorner = []
            
        if negativeLayer == nil && bottomPositiveLayer != nil {
            
            if layer == bottomPositiveLayer {
                if bottomPositiveLayer == positiveLayer {
                    cornerOptions = .allCorners
                }
                else{
                    cornerOptions = [.bottomLeft,.bottomRight]
                }
            }
            
        }
        
        if positiveLayer != nil && layer == positiveLayer{
            cornerOptions = [.topLeft,.topRight]
        }
            
        if positiveLayer == nil && topNegativeLayer != nil {
            
            if layer == topNegativeLayer {
                if topNegativeLayer == negativeLayer {
                    cornerOptions = [.allCorners]
                }
                else {
                    cornerOptions = [.topLeft,.topRight]
                }
            }
        }
        
        if negativeLayer != nil && layer == negativeLayer{
            cornerOptions = [.bottomLeft,.bottomRight]
        }
        
        layer.path = UIBezierPath(roundedRect: newRect, byRoundingCorners: cornerOptions, cornerRadii: cornerRadii).cgPath
    }
    
}
#endif
