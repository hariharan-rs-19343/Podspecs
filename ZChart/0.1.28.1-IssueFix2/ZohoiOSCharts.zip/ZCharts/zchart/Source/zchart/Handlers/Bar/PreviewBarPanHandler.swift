//
//  PreviewPanHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 11/09/19.
//  Copyright © 2019 zoho. All rights reserved.
//


import Foundation
#if !os(OSX)
    import UIKit
#endif

open class PreviewBarPanHandler: NSObject, EventHandler {
    
    open var parentBarChartView:ChartViewBase? = nil
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }
    
    
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = parentBarChartView! //chart as! BarLineChartViewBase
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            // If drag is enabled and we are in a position where there's something to drag:
            //  * If we're zoomed in, then obviously we have something to drag.
            //  * If we have a drag offset - we always have something to drag
            /*  if barChart.isDragEnabled &&
             (!barChart.hasNoDragOffset || !barChart.isFullyZoomedOut)
             {
             barChart._isDragging = true
             
             barChart._closestDataSetToTouch = barChart.getDataSetByTouchPoint(point:  recognizer.location(ofTouch: 0, in: barChart))
             
             let translation = recognizer.translation(in: barChart)
             let didUserDrag = (barChart is HorizontalBarChartView) ? translation.y != 0.0 : translation.x != 0.0
             
             // Check to see if user dragged at all and if so, can the chart be dragged by the given amount
             if didUserDrag && !barChart.performPanChange(translation: translation)
             {
             if barChart._outerScrollView !== nil
             {
             // We can stop dragging right now, and let the scroll view take control
             barChart._outerScrollView = nil
             barChart._isDragging = false
             }
             }
             else
             {
             if barChart._outerScrollView !== nil
             {
             // Prevent the parent scroll view from scrolling
             barChart._outerScrollView?.isScrollEnabled = false
             }
             }
             
             barChart._lastPanPoint = recognizer.translation(in: barChart)
             }
             else if barChart.isHighlightPerDragEnabled
             {
             // We will only handle highlights on NSUIGestureRecognizerState.Changed
             
             barChart._isDragging = false
             }*/
            
            barChart._lastPanPoint = recognizer.translation(in: chart)
            
            barChart._isDragging = true
            
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            
            if barChart._isDragging
            {
                let originalTranslation = recognizer.translation(in: chart)
                let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                
                let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: barChart)
                
                barChart._lastPanPoint = originalTranslation
            }
            
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            barChart._isDragging = true
            
            if barChart._isDragging
            {
                if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                {
                    barChart.stopDeceleration()
                    
                    barChart._decelerationLastTime = CACurrentMediaTime()
                    barChart._decelerationVelocity = recognizer.velocity(in: chart)
                    
                    barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                    barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                }
                
                barChart._isDragging = false
            }
            
            if barChart._outerScrollView !== nil
            {
                barChart._outerScrollView?.nsuiIsScrollEnabled = true
                barChart._outerScrollView = nil
            }
        }
        
    }
}




