//
//  BubbleHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 05/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class BubbleHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
//        var entry = entry
        let bubbleChart = chart
        
        if !bubbleChart.viewPortHandler.isInBoundsX(touchLocation.x)
        {
            bubbleChart.resetHighlight()
            bubbleChart.setNeedsDisplay()
            bubbleChart.lastSelected = nil
            bubbleChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
        
        
       /* if (entry == nil || entry != nil) {
        for textLayer in ChartViewBase.getAllTextLayer(chartView: chart) {
            
            if (textLayer.frame.contains(touchLocation))
            {
                let object =  textLayer.value(forKey: "data")
                if (object != nil) {
                    entry = object as? ChartDataEntry
                    break
                }
            }
        }
        }*/
                
        if entry != nil{
           
            for layer in BubbleLayer.getAllBubbleLayer(chart: bubbleChart)
            {
                if layer.chartEntry == entry
                {
                    guard let dataSetOptions = layer.bubbleDataSet?.dataSetOptions as? AxisChartDataSetOptions
                               else {  return }
                    
                    let entryIndex = layer.bubbleDataSet?.entryIndex(entry: entry!)
                    let holeColor = (((dataSetOptions.shapeProperties.holeColor) == nil) ? (NSUIColor.clear.cgColor) : (dataSetOptions.shapeProperties.holeColor!.cgColor) )
                    layer.fillColor = holeColor
                    layer.strokeColor = layer.bubbleDataSet?.color(atIndex: entryIndex!).cgColor
                }
                else{
                    layer.fillColor = NSUIColor.gray.withAlphaComponent(0.3).cgColor
                    layer.strokeColor = NSUIColor.gray.withAlphaComponent(0.3).cgColor
                }
            }
            
            let dataSet = (chart.data?.getDataSetForEntry(entry))!
            
            let entryLocation = bubbleChart.pixelForValues(x: (entry?.x)!, y: (entry?.y)!, axisIndex: dataSet.axisIndex)
            
            let high = chart.getHighlightByTouchPoint(entryLocation)
            
//            bubbleChart.lastSelected = entry
            bubbleChart.updateLastSelectedEntry(entry: entry)
            
            bubbleChart.callDelegateToContainer(highlight: high, entry: entry)
    
        }
    }
    
    
}

