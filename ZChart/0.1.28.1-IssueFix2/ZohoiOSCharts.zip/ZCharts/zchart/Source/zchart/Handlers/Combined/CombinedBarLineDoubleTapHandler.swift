//
//  CombinedBarLineDoubleTapHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 08/03/19.
//  Copyright © 2019 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class CombinedBarLineDoubleTapHandler: NSObject, EventHandler {
    
    public enum toggleEnum {
        case Combined
        case Bar
        case Line
    }
    
    public static var toggleMode:toggleEnum = .Combined
    
    open var toggleCount = 0
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.lineHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        toggleCount = (toggleCount + 1)%3
        
        switch toggleCount {
            
        case 0:
            CombinedBarLineDoubleTapHandler.toggleMode = .Combined
            chart.drawRenderOrder = [.Bar, .Line]
        case 1:
            CombinedBarLineDoubleTapHandler.toggleMode = .Bar
            chart.drawRenderOrder = [.Line, .Bar]
        case 2:
            CombinedBarLineDoubleTapHandler.toggleMode = .Line
            chart.drawRenderOrder = [.Bar, .Line]
        default:
            CombinedBarLineDoubleTapHandler.toggleMode = .Combined
            chart.drawRenderOrder = [.Bar, .Line]
        }
      
        chart.createRenderers()
        
        for renderer in chart.renderers
        {
            renderer.initBuffers()
        }
        
        chart.setNeedsDisplay()
        
    }
}

