//
//  SingleBarLongPressListener.swift
//  ZCharts
//
//  Created by Aravinth T on 11/10/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class SingleBarLongPressListener: NSObject,EventHandler {
    
    
    var prevLongPressLoc:CGPoint? = nil
    
    var toggleAscending:Bool = true
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        let barChart =  chartView
        
        let location = touchLocation
        
        guard let plotOption = barChart.getPlotOptions(type: .Bar) as? BarPlotOptions
            else { return }
        
        
        if recognizer?.state == .began
        {
            
            barChart.updateBackupData()
            
            prevLongPressLoc = location
            
            BarLayer.removeAllValueLayer(chart: chartView)
            
        }
        else if recognizer?.state == .changed
        {
            
            let dist = location.x - (prevLongPressLoc?.x)!
            
            let allLayer = BarLayer.getAllBarLayer(chart: chartView)
            
            for layer in allLayer
            {
                BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: dist, chart: chartView, duration: 0)
            }
        }
        else if recognizer?.state == .ended
        {
            let dist = location.x - (prevLongPressLoc?.x)!
            
            if abs(dist) < 50
            {
                barChart.setNeedsDisplay()
                return
            }
            
            if dist <= 0
            {
                plotOption.sortInteractionCalled = false
                plotOption.sortAscendingEnabled = true
                self.toggleAscending = true
                restoreChartWithNewData(entries: getOriginalEntriesBasedOnOriginalIndex(barChart: barChart), barChart: barChart)
                //              self.backUpallowed = true
            }
            else
            {
                plotOption.sortInteractionCalled = true
                plotOption.sortAscendingEnabled = self.toggleAscending
                restoreChartWithNewData(entries: getSortedEntries(barChart: barChart), barChart: barChart)
            }
            
            plotOption.barGroupSelectionEnabled = false
            
            barChart.lastSelected = nil
            
            barChart.highlightValue(nil, callDelegate: false)
            
        }
        
    }
    
    
    func getSortedEntries(barChart: ChartViewBase) -> [ChartDataEntry]
    {
        var newEntries:[ChartDataEntry] = []
        
        var nanEntries:[ChartDataEntry] = []
        
        
        for i in 0 ..< (barChart.data?.dataSets[0].entryCount)!            {
            let oldEntry = (barChart.data?.dataSets[0].entryForIndex(i))!
            
            let clonedEntry = oldEntry.copy() as! ChartDataEntry
            
            if clonedEntry.x.isNaN || clonedEntry.y.isNaN
            {
                nanEntries.append(clonedEntry)
                continue
            }
            
            newEntries.append(clonedEntry)
        }
        
        
        if self.toggleAscending
        {
            newEntries.sort { (first:ChartDataEntry, second:ChartDataEntry) -> Bool in
                first.y < second.y
            }
            self.toggleAscending = false
        }
        else
        {
            newEntries.sort { (first:ChartDataEntry, second:ChartDataEntry) -> Bool in
                first.y > second.y
            }
            self.toggleAscending = true
        }
        
        for entries in nanEntries
        {
            newEntries.append(entries)
        }
        
        return newEntries
        
    }
    
    func getOriginalEntriesBasedOnOriginalIndex(barChart:ChartViewBase) -> [ChartDataEntry]
    {
        var newEntries:[ChartDataEntry] = []
        
        
        for i in 0 ..< (barChart.data?.dataSets[0].entryCount)!            {
            let oldEntry = (barChart.data?.dataSets[0].entryForIndex(i))!
            let clonedEntry = oldEntry.copy() as! ChartDataEntry
            newEntries.append(clonedEntry)
        }
        
        newEntries.sort { (first:ChartDataEntry, second:ChartDataEntry) -> Bool in
            ( (first.origIndex)! < (second.origIndex)! )
        }
        
        
        return newEntries
    }
    
    /* func takeBackUp(barChart: BarChartView)
     {
     self.backUpEntries.removeAll()
     
     for i in 0 ..< (barChart.data?.dataSets[0].entryCount)!            {
     let oldEntry = barChart.data?.dataSets[0].entryForIndex(i) as! ChartDataEntry
     backUpEntries.append(oldEntry)
     }
     
     } */
    
    func restoreChartWithNewData(entries: [ChartDataEntry], barChart: ChartViewBase)
    {
        barChart.data?.dataSets[0].clear()
        
        _ = barChart.data?.dataSets[0].resetEntries(entries: entries)
        
        barChart.resetMatricesForDataReload()
        
       /* UIView.animate(withDuration: 0.5, animations: {
            barChart.data?.updateXYValues()
            
            barChart.data?.dataSets[0].calcMinMax()
            
            barChart.data?.notifyDataChanged()
            
            barChart.notifyDataSetChanged(redrawRequired: true)
            
            barChart.animate(xAxisDuration: 0.2, yAxisDuration: 0.2)
        })*/
        
        barChart.data?.updateXYValues()
        
        barChart.data?.dataSets[0].calcMinMax()
        
        barChart.data?.notifyDataChanged()
        
        barChart.notifyDataSetChanged(redrawRequired: true)
        
        barChart.animate(xAxisDuration: 0.2, yAxisDuration: 0.2)
        
    }
    
}
