//
//  SankeyHighlightHandler.swift
//  Pods-ZCharts
//
//  Created by keerthi-pt4274 on 18/10/22.
//

import Foundation

open class SankeyHighlightHandler: NSObject, EventHandler {
    
    var selectedLayers = [SankyLayers]()
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        _ = deselectLayers(chart: chartView, selectedLayer: nil)
        
        if !chartView.viewPortHandler.isInBounds(x: touchLocation.x, y: touchLocation.y) {
            return
        }
        
        let nodeLayers = SankyLayers.getAllNodeLayer(chart: chartView)
        let linkLayers = SankyLayers.getAllLinkLayer(chart: chartView)
        var sankeyLayers = [SankyLayers]()
        sankeyLayers.append(contentsOf: nodeLayers)
        sankeyLayers.append(contentsOf: linkLayers)
        
        if let selectedLayer = SankyLayers.getSankeyLayerForTouchPoint(chart: chartView, loc: touchLocation) {
            
            if deselectLayers(chart: chartView, selectedLayer: selectedLayer) {
                selectedLayers.removeAll()
                return
            }
            else {
                selectedLayers.removeAll()
            }
            
            selectedLayers.append(selectedLayer)
            
            if selectedLayer.type == .Link || selectedLayer.type == .CircularLink {
                
                guard let entry = selectedLayer.chartEntry else {
                    return
                }
                
                addSelectedSourceNode(nodeLayers: nodeLayers, entry: entry)
                addSelectedTragetNode(nodeLayers: nodeLayers, entry: entry)
                
                chartView.delegateToContainer?.chartValueSelected?(chartView, entry: entry)
            }
            else {
                
                guard let dataset = chartView.data?.dataSets[0] else {
                    return
                }
                
                for entryIndex in 0..<dataset.entryCount {
                    
                    guard let entry = dataset.entryForIndex(entryIndex) else {
                        continue
                    }
                    
                    if entry.xString == selectedLayer.nodeName {
                        
                        addSelectedLink(linkLayers: linkLayers, entry: entry)
                        
                        addSelectedTragetNode(nodeLayers: nodeLayers, entry: entry)
                    }
                    
                    if entry.yString == selectedLayer.nodeName {
                        
                        addSelectedLink(linkLayers: linkLayers, entry: entry)
                        
                        addSelectedSourceNode(nodeLayers: nodeLayers, entry: entry)
                    }
                }
            }
            
            for layer in sankeyLayers {
                
                if !selectedLayers.contains(layer)  {
                    layer.opacity = 0.2
                }
            }
            
        }
    }
    
    func deselectLayers(chart: ChartViewBase, selectedLayer: SankyLayers?) -> Bool {
        
        for layer in SankyLayers.getAllSankeyLayer(chart: chart) {
            layer.opacity = 1.0;
        }
        
        if let selectedLayer = selectedLayer {
            
            if selectedLayers.contains(selectedLayer) {
                return true
            }
        }
        
        return false
    }
    
    func addSelectedSourceNode(nodeLayers: [SankyLayers], entry: ChartDataEntry) {
        if let sourceNode = getSourceNodeLayer(nodeLayers: nodeLayers, entry: entry) {
            
            selectedLayers.append(sourceNode)
        }
    }
    
    func addSelectedTragetNode(nodeLayers: [SankyLayers], entry: ChartDataEntry) {
        if let tragetNode = getTragetNodeLayer(nodeLayers: nodeLayers, entry: entry) {
            
            selectedLayers.append(tragetNode)
        }
    }
    
    func addSelectedLink(linkLayers: [SankyLayers], entry: ChartDataEntry) {
        if let linkLayer = getLinkLayerForEntry(linkLayers: linkLayers, entry: entry) {
            selectedLayers.append(linkLayer)
        }
    }
    
    func getSourceNodeLayer(nodeLayers: [SankyLayers], entry: ChartDataEntry) -> SankyLayers? {
        
        guard let entryxString = entry.xString else {
            return nil
        }
        
        for layer in nodeLayers {
            if layer.nodeName == entryxString {
                return layer
            }
        }
        
        return nil
    }
    
    func getTragetNodeLayer(nodeLayers: [SankyLayers], entry: ChartDataEntry) -> SankyLayers? {
        
        guard let entryyString = entry.yString else {
            return nil
        }
        
        for layer in nodeLayers {
            if layer.nodeName == entryyString {
                return layer
            }
        }
        
        return nil
    }
    
    func getLinkLayerForEntry(linkLayers: [SankyLayers], entry: ChartDataEntry) -> SankyLayers? {
        
        for layer in linkLayers
        {
            if layer.chartEntry == entry {
                return layer
            }
        }
        
        return nil
    }
    
}
