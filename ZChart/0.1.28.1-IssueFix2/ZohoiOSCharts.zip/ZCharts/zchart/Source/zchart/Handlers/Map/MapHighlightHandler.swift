//
//  MapHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 31/05/19.
//  Copyright © 2019 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class MapHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        HeatMapHelperFunctions.highLightMapEntry(chart: chart, entry: entry)
        
    }
}

