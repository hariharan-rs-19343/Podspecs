//
//  CustomLongPressHandler.swift
//  ZCharts
//
//  Created by Aravinth T on 11/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class PieLongPressHandler: NSObject,EventHandler
{
    var pieRadChange:CGFloat = 0
    var oldLayer:PieLayer? = nil
    var high:Highlight? = Highlight()
    var oldhigh:Highlight? = Highlight()
    var angle:CGFloat = 0
    
    var startAngle:CGFloat = 0
    var totAngle:CGFloat = 0
    var angleLength:CGFloat = 0
    var absAngle:CGFloat = 0
    var location:CGPoint = CGPoint()
    
    unowned var pieChartInstance:ChartViewBase
    
    public override init() {
        let pieChartInstance = ChartViewBase()
        self.pieChartInstance = pieChartInstance
        super.init()
    }
    
    var changingFactor:CGFloat = 1
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    
   public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
    
        var (selectedHigh, selectedEntry) = CommonHelperFunctions.getHighAndEntryForRecognizer(chart: chartView, recognizer: recognizer!)
    
        let duration:TimeInterval = 0.4
    
        let pieChart = chartView
    
        guard let piePlot = chartView.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
    
        var selectedLayer:PieLayer? = entryLayer as? PieLayer
    
        pieChartInstance = chartView
    
    
        if(PieLayer.getAllPieLayer(chart: pieChart).count <= 1)
        {
            pieChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
    
    
        if recognizer?.state == NSUIGestureRecognizerState.began
        {
            ChartUtils.longPressSound()
            
            if pieChart.lastSelected != nil && pieChart.lastSelected!.count > 0
            {
                let entry = pieChart.lastSelected![0]
                entry.filterEnabled = false
                pieChart.lastSelected = nil
            }
            
            pieRadChange = piePlot.radius
            PieHelperFunctions.resetVelocity(chart: pieChart)
            
            PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: location)
            
            if selectedHigh == nil || selectedEntry == nil { return }
            
            
            oldLayer = selectedLayer
            oldhigh = selectedHigh
            
            PieHelperFunctions.sliceOut(sliceLayer: selectedLayer!, chart: pieChart, duration: 0.3, completionBlock: nil)
            
            for layer in PieLayer.getAllPieLayer(chart: pieChart)
            {
                if layer != selectedLayer
                {
                    PieHelperFunctions.changeRadiusAnimator(sliceLayer: layer, chart: pieChart, duration: 0.2, fromRadius: piePlot.radius, toRadius: piePlot.radius-20, pieCenter: piePlot.centerCircleBox, completionBlock: nil)
                }
            }
            location = (recognizer?.location(in: pieChart))!
            
            high = pieChart.getHighlightByTouchPoint(location)
            
            if high != nil {
                
                angle = PieHelperFunctions.angleForPoint(x: (high?.xPx)! ,y: (high?.yPx)!, center: piePlot.centerCircleBox)
                
                let chartEntry = pieChart.entryForHighlight(high!)
                
                angle = PieHelperFunctions.getMidAngle(chart: pieChart, entry: chartEntry!)
                
                piePlot.arrowShow = false
                
                changingFactor = 21
                
                for layer in PieLayer.getAllPieValueLayer(chart: pieChart)
                {
                    layer.opacity = 0
                }
                
            }
            
            pieChart.callDelegateToContainer(highlight: high, entry: selectedEntry)
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.changed
        {
            
            if selectedLayer == nil || oldLayer == nil { return }
            
            let changeLocation = (recognizer?.location(in: pieChart))!
            
            let layers = PieLayer.getAllPieLayer(chart: pieChart)
            
            let curIndex = layers.firstIndex(of: selectedLayer!)
            
            let oldIndex = layers.firstIndex(of: oldLayer!)
            
            if(abs(curIndex! - oldIndex!) == 1)||((abs(curIndex! - oldIndex!)+1 == layers.count))
            {
                if  pieRadChange > (piePlot.radius-30) //(velocityCalculated < -10 && changingFactor < (pieChart.radius/8)) ||
                {
//                    let generator = UISelectionFeedbackGenerator()
//                    generator.selectionChanged()
                    //TODO FOR OSX
                    #if os(iOS) || os(tvOS)
                    if #available(iOS 10.0, *) {
                        let generator = UISelectionFeedbackGenerator()
                        generator.selectionChanged()
                    } else {
                        // Fallback on earlier versions
                    }
                    #endif

                    PieHelperFunctions.resetVelocity(chart: pieChart)
                    PieHelperFunctions.sampleVelocity(chart: pieChart, touchLocation: changeLocation)
                    PieHelperFunctions.sliceOut(sliceLayer: selectedLayer!, chart: pieChart, duration: 0.2, completionBlock: nil)
                    

                    pieChart.callDelegateToContainer(highlight: selectedHigh, entry: selectedEntry)

                    
                    PieHelperFunctions.sliceIn(sliceLayer: oldLayer!, chart: pieChart, duration: 0.2, completionBlock: nil)
                    
                    PieHelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, chart: pieChart, duration: duration, fromRadius: piePlot.radius, toRadius: piePlot.radius-20, pieCenter: piePlot.centerCircleBox, completionBlock: nil)
                    
                    oldLayer = selectedLayer
                    oldhigh = selectedHigh
                    changingFactor = 21
                }
            }
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.ended
        {
            selectedLayer = oldLayer
            selectedHigh = oldhigh
            
            if selectedLayer == nil {
                oldLayer = nil
                oldhigh = nil
                return
            }
            
            for layer in PieLayer.getAllPieLayer(chart: pieChart)
            {
                if layer != selectedLayer
                {
                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: layer.getInitialPath(pieChart: pieChart, entry: layer.chartEntry!, radius: piePlot.radius), duration: 0.2)
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(210), execute: { [unowned pieChart] in
                for layer in PieLayer.getAllPieValueLayer(chart: pieChart)
                {
                    layer.opacity = 1
                }
            })
            
            selectedEntry = pieChart.entryForHighlight(selectedHigh!)
//            pieChart.lastSelected = selectedEntry
            pieChart.updateLastSelectedEntry(entry: selectedEntry)
            pieChart.callDelegateToContainer(highlight: selectedHigh, entry: selectedEntry)

        }
    
    }
    
}


