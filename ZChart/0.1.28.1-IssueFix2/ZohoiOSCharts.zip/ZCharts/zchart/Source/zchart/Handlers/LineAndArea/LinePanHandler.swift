//
//  LinePanHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 28/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class LinePanHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    var sumChange:CGFloat = 0
    
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.linePan
    }
    
    
    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let lineChart = chart
        
        guard let plotOption = chart.getPlotOptions(type: .Line) as? LinePlotOptions
            else { return }

        
        if recognizer.state == NSUIGestureRecognizerState.began //&& recognizer.nsuiNumberOfTouches() > 0
        {
            
       
            lineChart.stopDeceleration()
            
            if lineChart._data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            lineChart._lastPanPoint = recognizer.translation(in: lineChart)
            
            lineChart._isDragging = false
            
          if recognizer.nsuiNumberOfTouches() > 1//.numberOfTouches > 1
          {
            lineChart._isDragging = true
            
            }
            
     
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {

            
            if recognizer.nsuiNumberOfTouches() > 1//.numberOfTouches > 1
            {
                lineChart._isDragging = true
            }
            
                if lineChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: lineChart)
                    let translation = CGPoint(x: originalTranslation.x - lineChart._lastPanPoint.x, y: originalTranslation.y - lineChart._lastPanPoint.y)
                    
                    let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chart)
                    
                    lineChart._lastPanPoint = originalTranslation
                }
                else if lineChart.isHighlightPerDragEnabled
                {
                    let touchPoint = recognizer.location(in: chart)
                    var high = chart.getHighlightByTouchPoint(touchPoint)
                    
                    var entry:ChartDataEntry? = nil
                    
                    if plotOption.isStacked
                    {
                        let set = (lineChart.data?.dataSets[0])!
                        let xValue  = lineChart.valueForTouchPoint(point: touchPoint,  axisIndex: set.axisIndex).x
                        entry = (set.entryForXValue(Double(xValue), closestToY: Double.nan))!
                       
                        let px = lineChart.getTransformer(axisIndex: set.axisIndex).pixelForValues(x: (entry?.x)!, y: (entry?.y)!)
                        high = Highlight(x: (entry?.x)!, y: (entry?.y)!, xPx: px.x, yPx: px.y, dataSetIndex: 0 , axisIndex: (set.axisIndex))
        
                    }
                    else{
                        if high != nil {
                            entry = chart.entryForHighlight(high!)
                        }
                    }
                    
                    if entry != nil{
                        LineHelperFunctions.highlightAllDatasetEntry(entry: entry!, chart: lineChart, includeVerticalLine: true)
                        chart.callDelegateToContainer(highlight: high, entry: entry)
                    }
                
                }
           
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if recognizer.nsuiNumberOfTouches() > 1//.numberOfTouches > 1
            {
            
                lineChart._isDragging = true
            }

                if lineChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && lineChart.isDragDecelerationEnabled
                    {
                        lineChart.stopDeceleration()
                        
                        lineChart._decelerationLastTime = CACurrentMediaTime()
                        lineChart._decelerationVelocity = recognizer.velocity(in: lineChart)
                        
                        lineChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: lineChart)
                        lineChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                    }
                    
                    lineChart._isDragging = false
                }
                
                if lineChart._outerScrollView !== nil
                {
                    lineChart._outerScrollView?.nsuiIsScrollEnabled = true
                    lineChart._outerScrollView = nil
                }
            
       
            
        }
    }
}
