//
//  BoxPlotHighlightHandler.swift
//  zchart
//
//  Created by keerthi-pt4274 on 12/08/22.
//

import Foundation

open class BoxPlotHighlightHandler: NSObject, EventHandler {
    
    var lastSelectedEntries: [ChartDataEntry] = [ChartDataEntry]()
    
    public func getEventHandlerType() -> EventHandlerType {
        EventHandlerType.barHighlight
    }
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        chartView.resetHighlight()
        
        resetWhiskersProperties(chartView: chartView)
        
        BarHelperFunctions.highlightBar(location: touchLocation, bar: chartView)
//        highlightBoxPlot(location: touchLocation, BoxPlot: chartView)
        
        let high = (chartView.lastSelected != nil && chartView.lastSelected!.count > 0) ? chartView.getHighlightByEntry(chartView.lastSelected![0]) : nil
        
        chartView.highlightValue(high, callDelegate: false, redrawRequired: false)
        
        if chartView.viewPortHandler.isInBounds(x: touchLocation.x, y: touchLocation.y) {
            
            if let highlight = high, let entry = chartView.entryForHighlight(highlight) {
                
                if (chartView.data?.dataSets.count)! > 1 {
                    
                    if let dataset = chartView.data?.getDataSetForEntry(entry) {
                        
                        for entryIndex in 0..<dataset.entryCount {
                            
                            guard let entry = dataset.entryForIndex(entryIndex) else {
                                continue
                            }
                            
                            getHighLightWhiskersLayer(chartView: chartView, entry: entry)
                        }
                    }
                }
                else {
                    getHighLightWhiskersLayer(chartView: chartView, entry: entry)
                }
            }
        }
        
    }
    
    func resetWhiskersProperties(chartView: ChartViewBase) {
        
        if lastSelectedEntries.isEmpty {
            return
        }
        
        guard let plotOption = CommonHelperFunctions.getPlotOption(chart: chartView, types: [.BoxPlot]) as? BoxPlotPlotOptions else {
            return
        }
        
        for entry in lastSelectedEntries {
            
            if let layer = WhiskersLayer.getWhiskersLayerForEntry(chart: chartView, entry: entry) {
            
                layer.lineWidth = plotOption.whiskersStrokeWidth
            }
            
        }
        
        lastSelectedEntries.removeAll()
    }
    
    func getHighLightWhiskersLayer(chartView: ChartViewBase, entry: ChartDataEntry) {
        
        if let layer = WhiskersLayer.getWhiskersLayerForEntry(chart: chartView, entry: entry) {
    
            layer.lineWidth = 3.0
            layer.strokeColor = NSUIColor.black.cgColor
        
            if let entry = layer.chartEntry {
                lastSelectedEntries.append(entry)
            }
        }
        
    }
    
    func highlightBoxPlot(location: CGPoint, BoxPlot: ChartViewBase) {
        
        var curSelected:BarLayer? = nil
        
        guard let barData = BoxPlot.data
            else { return }
        
        let boxPlotPlotOptions = CommonHelperFunctions.getPlotOption(chart: BoxPlot, types: [.BoxPlot]) as! BoxPlotPlotOptions
        
        if (barData.dataSetCount) > 1
        {
            curSelected = BarLayer.getBarLayerInPointOriginal(chart: BoxPlot ,loc: location)
        }
        else
        {
            curSelected = BarLayer.getBarLayerInPoint(chart: BoxPlot ,loc: location)
        }
        
        if curSelected != nil
        {
                
            if BoxPlot.lastSelected != nil && BoxPlot.IsEntrySelected(entry: curSelected?.chartEntry)
            {
                boxPlotPlotOptions.barGroupSelectionEnabled = true
            }
            else{
                boxPlotPlotOptions.barGroupSelectionEnabled = false
            }
            
            curSelected?.fillColor = boxPlotPlotOptions.highlightColor?.cgColor
            
            BoxPlot.updateLastSelectedEntry(entry: curSelected?.chartEntry)
            
            for layer in BarLayer.getAllBarLayer(chart: BoxPlot)
            {
                if curSelected != layer
                {
                    layer.fillColor = boxPlotPlotOptions.nonHighlightColor?.cgColor
                }
                
            }
            
        }
        else
        {
            boxPlotPlotOptions.barGroupSelectionEnabled = false
            
            BoxPlot.lastSelected = nil
            
            if barData.dataSetCount > 1
            {
                curSelected = BarLayer.getBarLayerInPoint(chart: BoxPlot ,loc: location)
                
                if curSelected != nil{
//                    --TO:DO - group selection
                    
//                    boxPlotPlotOptions.barGroupSelectionEnabled = true
//                     BoxPlot.updateLastSelectedEntry(entry: curSelected?.chartEntry)
                }
            }
            
            for layer in BarLayer.getAllBarLayer(chart: BoxPlot)
            {
                layer.fillColor = boxPlotPlotOptions.highlightColor?.cgColor
            }
        }
    }
}
