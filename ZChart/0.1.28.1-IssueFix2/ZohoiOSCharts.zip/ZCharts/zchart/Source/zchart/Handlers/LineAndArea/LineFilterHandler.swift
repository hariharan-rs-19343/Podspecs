//
//  LineFilterHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 13/03/20.
//  Copyright © 2020 zoho. All rights reserved.
//

import Foundation

open class LineFilterHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var enteryLoc:CGPoint? = nil
    var initialLoc: CGPoint = CGPoint()
    var initialEntry: ChartDataEntry? = ChartDataEntry()
    var initialEntryLayer: ChartEntryLayer?
    var lastTouched:CGPoint? = nil
    
    
    open func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let lineChart = chartView
        
        var Entry : ChartDataEntry? = entry
        
        if lineChart.lastSelected != nil && lineChart.lastSelected!.count > 0 && lineChart.datasetSelected
        {
            Entry = lineChart.lastSelected![0]
            print("line.lastSelected")
        }
        else if let _entry = getEntryAboveTouchPoint(location: touchLocation, chart: lineChart)
        {
            Entry = _entry
            print("StepAbove")
        }
        else if let _entry = getEntryBelowTouchPoint(location: touchLocation, chart: lineChart)
        {
            Entry = _entry
            print("StepBottom")
        }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
            lineChart.stopDeceleration()
            
            if lineChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            lineChart._lastPanPoint = recognizer.translation(in: lineChart)
            
            lineChart._isDragging = false
            
            if recognizer.nsuiNumberOfTouches() > 1//.numberOfTouches > 1
            {
                lineChart._isDragging = true
            }
            
            startLoc = touchLocation
            
            let entryLocal:ChartDataEntry? = Entry
            
            initialLoc = recognizer.location(in: lineChart)
            if(entryLocal != nil)
            {
                initialEntry = entryLocal
                
                let set = chartView.data?.getDataSetForEntry(entryLocal)
                for layer in LineLayer.getAllDataSetLayer(chart: lineChart)
                {
                    if((layer.lineDataSet ) === set )
                    {
                        initialEntryLayer = layer
                    }
                }
                //initialEntryLayer = entryLayer
                lineChart._isDragging = false
            }
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed {
            
            if recognizer.nsuiNumberOfTouches() > 1//.numberOfTouches > 1
            {
                lineChart._isDragging = true
            }
            
            if lineChart._isDragging
            {
                let originalTranslation = recognizer.translation(in: lineChart)
                let translation = CGPoint(x: originalTranslation.x - lineChart._lastPanPoint.x, y: originalTranslation.y - lineChart._lastPanPoint.y)
                
                let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chartView)
                
                lineChart._lastPanPoint = originalTranslation
                return
            }
            
//            var xdiff = initialLoc.x - recognizer.location(in: lineChart).x
//            var ydiff = initialLoc.y - recognizer.location(in: lineChart).y
            
            lastTouched = touchLocation
            
            if let initialEntry = initialEntry, let startLoc = startLoc, let lastTouched = lastTouched
            {
                
                guard let dataSet = chartView.data?.getDataSetForEntry(initialEntry),
                let dataOptions = dataSet.dataSetOptions as? LineDataSetOptions,
                      let linePlotOptions = chartView.getPlotOptions(type: dataSet.plotType) as? LinePlotOptions
                    else {
                    return
                }
                
                guard let lineLayer = initialEntryLayer as? LineLayer else {
                    return
                }
                
                let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: dataSet)
                
                let entryIndex = dataSet.entryIndex(entry: initialEntry)
                
                let startValue = lineChart.isRotated ? lineChart.getTransformer(axisIndex: dataSet.axisIndex).valueForTouchPoint(startLoc).x : lineChart.getTransformer(axisIndex: dataSet.axisIndex).valueForTouchPoint(startLoc).y
                
                let endValue = lineChart.isRotated ? lineChart.getTransformer(axisIndex: dataSet.axisIndex).valueForTouchPoint(lastTouched).x : lineChart.getTransformer(axisIndex: dataSet.axisIndex).valueForTouchPoint(lastTouched).y
                
                
                let markerLayer = lineLayer.getMarkerLayerforEntryIndex(entryIndex: entryIndex)
                print("Indexe: \(entryIndex)", endValue , startValue)
                
                //trans.y < 0
//                let incDiff:CGFloat = 0.8
                initialEntry.filterEnabled = true
                initialEntry.barYValue =  (endValue - startValue) //+ ((endValue - startValue)/incDiff)
                
                guard let lineRenderer = CommonHelperFunctions.getRenderer(chart: chartView, types: [dataSet.plotType]) as? LineChartRenderer
                else {
                    return
                }
                
                var newPath:(CGPath,CGPath)!// = LineHelperFunctions.getLinearPathWithNAN(barLineChart: lineChart, dataSet: dataSet , animator: nil, lineRenderer: lineRenderer)
                
                switch dataOptions.mode
                {
                        case .linear: fallthrough
                        case .stepped:
                            if linePlotOptions.isStacked
                            {
                                newPath = LineHelperFunctions.getLinearStackedPathWithNAN(barLineChart: chartView, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                            }
                            else
                            {
                                let _xBounds = lineRenderer._xBounds
                                
        //                      _xBounds.set(chart: lineRenderer.dataProvider!, dataSet: dataSet, animator: animator)
                                
                                newPath = LineHelperFunctions.getLinearPathWithNAN(barLineChart: chartView, fromIndex:_xBounds.min, toIndex:_xBounds.range + _xBounds.min, dataSet: dataSet  , animator: nil, lineRenderer: lineRenderer)

                            }
                            
                        case .cubicBezier:
                            if linePlotOptions.isStacked
                            {
                                newPath = LineHelperFunctions.getCubicStackedDataSetPathWithNAN(barLineChart: chartView, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                            }
                            else{
                                newPath = LineHelperFunctions.getCubicDataSetPathWithNAN(barLineChart: chartView, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                            }
                        
                        case .horizontalBezier:
                            newPath = LineHelperFunctions.getLinearPathWithNAN(barLineChart: chartView, dataSet: dataSet  , animator: nil, lineRenderer: lineRenderer)
                        
                        case .montonic:
                            if linePlotOptions.isStacked
                            {
                                newPath = LineHelperFunctions.getMonotoneStackedDataSetPathWithNAN(barLineChart: chartView, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                            }
                            else{
                                newPath = LineHelperFunctions.getMonotoneDataSetPathWithNAN(barLineChart: chartView, dataSet: dataSet, animator: nil, lineRenderer: lineRenderer)
                            }
                                
                }
                
                
                let point  = lineChart.pixelForValues(isRotated: lineChart.isRotated,x: initialEntry.x, y: initialEntry.y + Double(initialEntry.barYValue), axisIndex: dataSet.axisIndex)
                
                let point1  = lineChart.pixelForValues(isRotated: lineChart.isRotated,x: initialEntry.x, y:initialEntry.y , axisIndex: dataSet.axisIndex)
                
                print("Point.y \(point1.y), Point.x \(point.x) initial.y \(initialEntry.y)")
                
                markerLayer?.path = ShapeFactory.getPath(point: point, shapeInstance: lineDataSetOptions.markerInstance)
                
                initialEntry.filterEnabled = false
                
                lineLayer.path = (newPath.0)
                
                if lineDataSetOptions.isDrawFilledEnabled
                {
                    if let sublayer = lineLayer.sublayers?.first as? CAShapeLayer {
                        sublayer.path = newPath.1
                    }
                }
            
            }
            
            
        } else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if recognizer.nsuiNumberOfTouches() > 1//.numberOfTouches > 1
            {
                
                lineChart._isDragging = true
            }
            
            if lineChart._isDragging
            {
                if recognizer.state == NSUIGestureRecognizerState.ended && lineChart.isDragDecelerationEnabled
                {
                    lineChart.stopDeceleration()
                    
                    lineChart._decelerationLastTime = CACurrentMediaTime()
                    lineChart._decelerationVelocity = recognizer.velocity(in: lineChart)
                    
                    lineChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: lineChart)
                    lineChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                }
                
                lineChart._isDragging = false
                
                if lineChart._outerScrollView !== nil
                {
                    lineChart._outerScrollView?.nsuiIsScrollEnabled = true
                    lineChart._outerScrollView = nil
                }
                
                return
            }
            
            guard let initialEntry = initialEntry else {
                return
            }
           
            if false { //lineChart.xAxis.scaleType != ScaleType.Ordinal {
                
            } else {
                lineChart.updateDataOrigIndex()
                lineChart.interactionAnimationInProgress = true
                
                /*guard let dataSet = chartView.data?.getDataSetForEntry(initialEntry) as? ChartDataSet
                    else {
                    return
                }
                
                let nextEntry = CommonHelperFunctions.getNextGreaterXEntry(set: dataSet, xValue: initialEntry.x, includeYNan: false, chart: lineChart)
                let prevEntry = CommonHelperFunctions.getPrevLesserXEntry(set: dataSet, xValue: initialEntry.x, chart: lineChart)
                
                var toValue =  Double(0)
                   
               if nextEntry != nil && prevEntry != nil {
                   toValue =  ((nextEntry!.y + prevEntry!.y)/2)
                   

               } else if nextEntry != nil {
                   toValue = (nextEntry!.y)
                   
               }
               else if prevEntry != nil {
                   toValue = (prevEntry!.y)
                   
               }
                
                let yValueinterPolator = Interpolator.interpolate(a: initialEntry.barYValue, b: (CGFloat(toValue - initialEntry.y)))
                
                let barEntryAnimator = Animator()
                               
                barEntryAnimator.updateBlock = {
                    initialEntry.filterEnabled = true
                    initialEntry.barYValue = yValueinterPolator(CGFloat(barEntryAnimator.phaseX))
                   
                    lineChart.setNeedsDisplay()
                   
               }
               
               barEntryAnimator.stopBlock = {
                   
                LineHelperFunctions.removeLineEntry(entry: initialEntry, chart: lineChart, duration: 3)
                   
               }
               
                barEntryAnimator.animate(xAxisDuration: 1, easingOption: .linear)*/
                
//                if lineChart.isCombined
//                {
//                    ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: initialEntry, chart: lineChart, duration: 1)
                
                var removeEntries:[ChartDataEntry] = []
                for set in lineChart.data!.dataSets
                {
                   for entry in (set as! ChartDataSet).values where initialEntry.origX == entry.origX
                   {
                       removeEntries.append(entry)
                   }
                }
                ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: lineChart, duration: 1)
//                }
//                else{
//                    LineHelperFunctions.removeLineEntry(entry: initialEntry, chart: lineChart, duration: 1)
//                }
            }
            
        }
        
    }
    
    open func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    

    open func getEntryAboveTouchPoint(location: CGPoint, chart: ChartViewBase) -> ChartDataEntry?
    {

        var lineData = ChartData()
        
        if let _lineData = chart.data
        {
            lineData = _lineData
        }
        else
        {
            return nil
        }
        
        for dataset in lineData.dataSets
        {
            for i in 0..<dataset.entryCount
            {
                guard let entry = dataset.entryForIndex(i), let entryLocation = CommonHelperFunctions.getEntryLocation(chart: chart, entry: entry) else { continue }
                
                if abs(location.x - entryLocation.x) <= 10 && location.y >= entryLocation.y
                {
                    return entry
                }
            }
            
        }
        
        return nil
    }
    
    open func getEntryBelowTouchPoint(location: CGPoint, chart: ChartViewBase) -> ChartDataEntry?
    {
        var lineData = ChartData()
        
        if let _lineData = chart.data
        {
            lineData = _lineData
        }
        else
        {
            return nil
        }
        
        for dataset in lineData.dataSets
        {
            for i in 0..<dataset.entryCount
            {
                guard let entry = dataset.entryForIndex(i), let entryLocation = CommonHelperFunctions.getEntryLocation(chart: chart, entry: entry) else { continue }
                
                if abs(location.x - entryLocation.x) <= 10 && location.y < entryLocation.y
                {
                    return entry
                }
            }
            
        }
        
        return nil
    }
    
}

