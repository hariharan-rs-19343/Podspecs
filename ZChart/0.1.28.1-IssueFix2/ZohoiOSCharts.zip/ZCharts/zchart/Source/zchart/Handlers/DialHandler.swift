//
//  DialHandler.swift
//  zchart
//
//  Created by keerthi-pt4274 on 16/06/22.
//

import Foundation

open class DialHandler: NSObject,EventHandler {
    
    var lastSelectedLayer: DialLevelLayer?
    
    var lastSelectedIndex: Int?
    
    public func getEventHandlerType() -> EventHandlerType {
        EventHandlerType.custom
    }
    
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint){
        
        
        if ((entryLayer?.path?.contains(touchLocation)) != nil) &&  entry != nil {

            let high = chartView.getHighlightByTouchPoint(touchLocation)

            chartView.highlightValue( high, callDelegate: false)
        }
        else{
            chartView.highlightValue(nil, callDelegate: false, redrawRequired: false)
            
            guard let entry = chartView.data?.dataSets[0].entryForIndex(0) else {
                return
            }
            
            let levelLayers = DialLevelLayer.getAllDialLevelLayers(chart: chartView)
            
            let (levelLayer,levelIndex) = getDialLayerInTouchPoint(touchPoint: touchLocation,levelLayers: levelLayers)
            
            levelLayerInOut(chart: chartView, levelLayer: levelLayer, levelIndex: levelIndex)
        }
        
    }
    
    func getDialLayerInTouchPoint(touchPoint: CGPoint,levelLayers: [DialLevelLayer]) -> (DialLevelLayer?,Int){
        
        var layer: DialLevelLayer?
        
        var index = -1
        
        for levelLayerIndex in 0..<levelLayers.count {
            
            if let path = levelLayers[levelLayerIndex].path {
                if path.contains(touchPoint) {
                    layer = levelLayers[levelLayerIndex]
                    index = levelLayerIndex
                    break
                }
            }
        }
        
        return (layer,index)
    }
    
    func levelLayerInOut(chart: ChartViewBase,levelLayer: DialLevelLayer?, levelIndex: Int){
        
        let (innerRadius,radius) = PieHelperFunctions.getInnerOuterLevelRadius(chart: chart)
        
        if let lastSelectedIndex = lastSelectedIndex, let lastSelectedLayer = lastSelectedLayer {
            
            performInOutAnimation(chart: chart, levelLayer: lastSelectedLayer, levelIndex: lastSelectedIndex, innerRadius: innerRadius, radius: radius)
            
            self.lastSelectedIndex = nil
            
            self.lastSelectedLayer = nil
        }
        
        if let layer = levelLayer {
        
            performInOutAnimation(chart: chart, levelLayer: layer, levelIndex: levelIndex, innerRadius: (innerRadius - 2.0), radius: (radius + 2.0))
            
            lastSelectedIndex = levelIndex
            
            lastSelectedLayer = layer
        }
        
    }
    
    func performInOutAnimation(chart: ChartViewBase, levelLayer: DialLevelLayer, levelIndex: Int, innerRadius: Double, radius: Double){
        
        guard let dataSet = chart.data?.dataSets[0],
              let renderer = CommonHelperFunctions.getRenderer(chart: chart, types: [.Dial]) as? DialChartRenderer,
              let levelMarker = dataSet.entryForIndex(0)?.levelMarker
        else {
            return
        }
        
        let levelMarkerValues = PieHelperFunctions.prepareLevelValues(chart: chart, dataset: dataSet,levelMarker: levelMarker)
        
        if var fromVal = levelMarkerValues[safe:levelIndex], var toVal = levelMarkerValues[safe:levelIndex + 1] {
        
            let endPath = PieHelperFunctions.getLevelMarkerPath(chart:chart, dataset: dataSet, entryIndex: 0, fromVal: &fromVal, toVal: &toVal, innerRadius: innerRadius, outerRadius: radius, phaseY: renderer.animator!.phaseY)

//            CommonHelperFunctions.performPathAnim(targetLayer: levelLayer, newPath: UIBezierPath(cgPath: endPath), duration: 0.3, completionBlock: nil)
            CommonHelperFunctions.performPathAnim(targetLayer: levelLayer, newPath: endPath, duration: 0.3, completionBlock: nil)
        }
        
    }
}
