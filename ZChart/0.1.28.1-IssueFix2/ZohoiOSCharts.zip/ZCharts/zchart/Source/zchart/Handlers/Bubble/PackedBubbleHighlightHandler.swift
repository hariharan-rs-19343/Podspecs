//
//  PackedBubbleHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 03/06/20.
//  Copyright © 2020 zoho. All rights reserved.
//


open class PackedBubbleHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let bubbleChart = chart
        
        bubbleChart.setNeedsDisplay()
        
        if entry == nil || entryLayer == nil
        {
            bubbleChart.lastSelected = nil
            bubbleChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
        
        bubbleChart.lastSelected = [entry!]
        
        let high = chart.getHighlightByTouchPoint(touchLocation)
        
        bubbleChart.callDelegateToContainer(highlight: high, entry: entry)
        
    }
    
    
}


