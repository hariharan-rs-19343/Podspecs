//
//  ScatterLongPressHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 05/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

#if !os(OSX)
open class ScatterLongPressHandler: NSObject, EventHandler {
    
    
    var verticalMove:Bool = true
    
    var startHigh:Highlight? = nil
    
    var curHigh:Highlight? = nil
    
    let innerCircleShape = ShapeProperties()
    let outerCircleShape = ShapeProperties()
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterLongPress
    }
    
    
    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUILongPressGestureRecognizer
        
        guard let plotOption = chart.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
        else { return }
        
        if entry == nil || entryLayer == nil
        {
            return
        }
        
        let scatterLayer = entryLayer as! ScatterLayer
        
        plotOption.barGroupSelectionEnabled = true
        
        CommonHelperFunctions.removeHighlightLayer(chart: chart)
        
        ScatterHighlightHandler.needRefresh = true
        
        // Tooltip delegate
        chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(touchLocation), entry: entry)
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            ChartUtils.longPressSound()
            
            innerCircleShape.holeColor = nil // Set nil to fill default dataset color
            innerCircleShape.lineWidth = 2
            innerCircleShape.size = CGSize(width: 12.0, height: 12.0)
            innerCircleShape.strokeColor = NSUIColor.clear
            
            outerCircleShape.holeColor = NSUIColor.white
            outerCircleShape.lineWidth = 2
            outerCircleShape.size = CGSize(width: 20.0, height: 20.0)
            outerCircleShape.strokeColor = nil
            
            for layer in ScatterLayer.getAllScatterLayer(chart: chart)
            {
//                let newPath = UIBezierPath(arcCenter: layer.shapePoint!, radius: 4-(1/2), startAngle: 0, endAngle: 360, clockwise: true)
                
                // Need Performance check
//                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0.2)
                
                CommonHelperFunctions.performLineWidthAnim(targetLayer: layer, newlineWidth: 1, duration: 0.2)
                
                layer.strokeColor = NSUIColor.lightGray.cgColor
            }
 
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleShape: innerCircleShape, outerCircleShape: outerCircleShape)
        }
        
    }
    
}
#endif
