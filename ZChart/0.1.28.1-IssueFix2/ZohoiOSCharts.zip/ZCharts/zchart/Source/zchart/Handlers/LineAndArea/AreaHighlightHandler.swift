//
//  AreaHighlightHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 16/03/18.
//  Copyright © 2018 charts. All rights reserved.
//

open class AreaHighlightHandler: NSObject, EventHandler {
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.lineHighlight
    }
    
    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        
        let lineChart = chart
        
        if !chart.viewPortHandler.isInBoundsX(touchLocation.x)
        {
            lineChart.resetHighlight()
            lineChart.lastSelected = nil
            lineChart.lastSelectedHigh = nil
            chart.setNeedsDisplay()
            lineChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
        
        if entry != nil{

            var entry =  entry
            
            if !((lineChart.getPlotOptions(type: .Area) as? AreaPlotOptions)?.isStacked ?? false)
            {
                entry =  CommonHelperFunctions.getEntryAboveTouchPoint(location: (recognizer?.location(in: chart))!, chart: chart)
            }
            
  
            if entry != nil{
                
                CommonHelperFunctions.removeHighlightLayer(chart: chart)
                
                chart.datasetSelected = true
                chart.updateLastSelectedEntry(entry: entry)
                
                let dataSet = (chart.data?.getDataSetForEntry(entry))!
            
                highlightDataSet(dataSet: dataSet, chart: chart)
                
                let entryLocation = lineChart.pixelForValues(x: (entry?.x)!, y: (entry?.y)!, axisIndex: dataSet.axisIndex)
                
                let high = chart.getHighlightByTouchPoint(entryLocation)
                
                lineChart.lastHighlighted = high
                
                lineChart.callDelegateToContainer(highlight: high, entry: entry)
            }
            
        }
    }
    
     open func highlightDataSet(dataSet:IChartDataSet, chart: ChartViewBase)
    {
        if !dataSet.isHighlightEnabled {
            return
        }
        
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            let gradients = (layer.lineDataSet?.gradients)!
            
            let lineStrokeLayer = LineLayer.getLineStrokeLayer(lineLayer: layer)
            
            if layer.lineDataSet === dataSet
            {
                layer.strokeColor = layer.lineDataSet?.color(atIndex: 0).cgColor
//               layer.fillColor = layer.lineDataSet?.color(atIndex: 0).withAlphaComponent(0.7).cgColor
                if lineStrokeLayer != nil {
                    lineStrokeLayer!.strokeColor = layer.lineDataSet?.color(atIndex: 0).cgColor
                }
                
                if gradients.count > 0 {
                    let highlightGradient = (dataSet.gradient(atIndex: 0))
                    _ = GradientLayerRenderer.updateGradientLayer(container: layer, gradientPath: layer.path!, gradient: highlightGradient, drawMaskEnabled: true)
                }else {
                    if (layer.lineDataSet?.dataSetOptions as? LineDataSetOptions)?.drawFilledEnabled ?? false {
                        layer.fillColor = LineHelperFunctions.getLineDataSetOptions(dataSet: layer.lineDataSet!).fillColor.withAlphaComponent(0.5).cgColor
                    }
                }
                
            }
            else{
                if (layer.lineDataSet?.dataSetOptions as? LineDataSetOptions)?.drawFilledEnabled ?? false {
                    layer.fillColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                }
                
                layer.strokeColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                if lineStrokeLayer != nil {
                    lineStrokeLayer!.strokeColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                }
                
                if gradients.count > 0 {

                let nonHighlightGradient = LinearGradient(colors: [NSUIColor.gray.withAlphaComponent(0.1), NSUIColor.gray.withAlphaComponent(0.1)], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
                    
                 _ = GradientLayerRenderer.updateGradientLayer(container: layer, gradientPath: layer.path!, gradient: nonHighlightGradient, drawMaskEnabled: true)
                }
                
            }
        }
        
    }
    
}
