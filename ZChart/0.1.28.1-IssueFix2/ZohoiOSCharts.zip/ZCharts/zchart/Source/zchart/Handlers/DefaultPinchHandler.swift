//
//  DefaultPinchHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 05/11/18.
//  Copyright © 2018 zoho. All rights reserved.
//

open class DefaultPinchHandler:NSObject,EventHandler
{
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.zoomInOut
    }
    
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint)
    {
        let barLineChart = chartView
        
        let recognizer = recognizer as! NSUIPinchGestureRecognizer
        
    
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            barLineChart.stopDeceleration()
            
            if barLineChart._data !== nil &&
                (barLineChart.pinchZoomEnabled || barLineChart.scaleXEnabled || barLineChart.scaleYEnabled)
            {
                barLineChart._isScaling = true
                
                if barLineChart.pinchZoomEnabled
                {
                    barLineChart._gestureScaleAxis = .both
                }
                else
                {
//                    let x = abs((recognizer.location(in: barLineChart).x) - (recognizer.location(ofTouch: 1, in: barLineChart).x))
//                    let y = abs((recognizer.location(in: barLineChart).y) - (recognizer.location(ofTouch: 1, in: barLineChart).y))
                    
                    var touchLoaction = CGPoint()
                    
                    #if os(iOS)
                        touchLoaction = recognizer.numberOfTouches > 0 ? recognizer.nsuiLocationOfTouch(1, inView: barLineChart) : touchLoaction
                    #endif
                    
                    let x = abs((recognizer.location(in: barLineChart).x) - touchLoaction.x)
                    let y = abs((recognizer.location(in: barLineChart).y) - touchLoaction.y)
                    
                    if barLineChart.scaleXEnabled != barLineChart.scaleYEnabled
                    {
                        barLineChart._gestureScaleAxis = barLineChart.scaleXEnabled ? .x : .y
                    }
                    else
                    {
                        barLineChart._gestureScaleAxis = x > y ? .x : .y
                    }
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended ||
            recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            if barLineChart._isScaling
            {
                barLineChart._isScaling = false
                
                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: barLineChart)
                
                // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
                barLineChart.calculateOffsets()
                barLineChart.updateAxisMinAndMax()
                barLineChart.setNeedsDisplay()
                
            }
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            if barLineChart.plotTypes.contains(.PackedBubble) || barLineChart.plotTypes.contains(.WordCloud) || barLineChart.plotTypes.contains(.GeoHeatMap) ||
                barLineChart.plotTypes.contains(.Sanky)
            {
                _ = CommonHelperFunctions.performPlotPinch(recognizer: recognizer, chart: barLineChart)
            }
            else{
                _ = CommonHelperFunctions.performPinch(recognizer: recognizer, chart: barLineChart)
            }
        }
    }
    
    
    
    
 
    
}

