//
//  CustomBarPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 23/10/17.
//  Copyright © 2017 charts. All rights reserved.
//


#if !os(OSX)
    import UIKit
#endif

open class CustomBarPanHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    var sumChange:CGFloat = 0
    
    
    var baseLineValue = Double(0)
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }

    func changeOpacityForOther(barLayer:BarLayer,opacity:CGFloat,width:CGFloat,chart: ChartViewBase)
    {
        
        
        let allLayers = BarLayer.getAllBarLayer(chart: chart)
        
        //chart.data?.setDrawValues(false)
        
        
        for eachBarLayer in allLayers
            
        {
            
            if eachBarLayer == barLayer
            {
                continue
            }
            
            eachBarLayer.opacity = Float(opacity)
            
            //            eachBarLayer.path = UIBezierPath(rect: CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!)).cgPath
            
            let newRect = CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!)
            
            let path = eachBarLayer.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!))
            
            CommonHelperFunctions.performPathAnim(targetLayer: eachBarLayer, newPath: path, duration: 0)
            
        }
        
        
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart
        
        guard let plotOption = chart.getPlotOptions(type: .Bar) as? BarPlotOptions
        else { return }
        
        if (barChart.data?.maxEntryCountSet?.entryCount)! <= 1
        {
            return
        }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
            sumChange = 0
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: startLoc!)
            lastTouched = startLoc
            
            if startLay != nil
            {
                baseLineValue = CommonHelperFunctions.getBaseLineValue(chart: chart, dataSet: (barChart.data?.getDataSetForEntry(startLay?.chartEntry))!)
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            // If drag is enabled and we are in a position where there's something to drag:
            //  * If we're zoomed in, then obviously we have something to drag.
            //  * If we have a drag offset - we always have something to drag
            /*  if barChart.isDragEnabled &&
             (!barChart.hasNoDragOffset || !barChart.isFullyZoomedOut)
             {
             barChart._isDragging = true
             
             barChart._closestDataSetToTouch = barChart.getDataSetByTouchPoint(point:  recognizer.location(ofTouch: 0, in: barChart))
             
             let translation = recognizer.translation(in: barChart)
             let didUserDrag = (barChart is HorizontalBarChartView) ? translation.y != 0.0 : translation.x != 0.0
             
             // Check to see if user dragged at all and if so, can the chart be dragged by the given amount
             if didUserDrag && !barChart.performPanChange(translation: translation)
             {
             if barChart._outerScrollView !== nil
             {
             // We can stop dragging right now, and let the scroll view take control
             barChart._outerScrollView = nil
             barChart._isDragging = false
             }
             }
             else
             {
             if barChart._outerScrollView !== nil
             {
             // Prevent the parent scroll view from scrolling
             barChart._outerScrollView?.isScrollEnabled = false
             }
             }
             
             barChart._lastPanPoint = recognizer.translation(in: barChart)
             }
             else if barChart.isHighlightPerDragEnabled
             {
             // We will only handle highlights on NSUIGestureRecognizerState.Changed
             
             barChart._isDragging = false
             }*/
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            if curLay != nil && (curLay?.chartEntry == startLay?.chartEntry) && verticalMove
            {
                // BarLayer.removeAllBarValueLayer(chart: chart)
                
                for eachBar in BarLayer.getAllValueLayer(chart: chart)
                {
                    eachBar.opacity = 0
                }
                
                trans = recognizer.translation(in: barChart)
                
                if vel.y > 5 || vel.y < -5 {
                    
                    let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
                    sumChange += trans.y
                    
                    if ll != nil
                    {
                        var curY = (ll?.barRect?.minY)!+trans.y
                        let newPath:CGMutablePath!
                        
                        // Filter
                        if trans.y > 0
                        {
                            if (ll?.path?.boundingBox.height)! <  ((ll?.barRect?.height)!/2)
                            {
                                let curDiff = (ll?.path?.boundingBox.height)! - ((ll?.barRect?.height)!/4)
                                
                                let origDiff = (ll?.barRect?.height)!/4
                                
                                if curDiff <= 0
                                {
                                    ll?.opacity = 0
                                }
                                else
                                {
                                    
                                    let opac = (1/origDiff)*curDiff
                                    ll?.opacity = Float(opac)
                                }
                            }
                            else{
                                ll?.opacity = 1
                            }
                            
                            let height = ((ll?.barRect?.height)! - trans.y) < 0 ? 0 : ((ll?.barRect?.height)! - trans.y)
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height))
                            
                        }
                        else{ // Drill
                            
                            let opac:CGFloat!
                            
                            let curWidth:CGFloat!
                            
                            var height = (ll?.barRect?.height)! + abs(trans.y)
                            
                            
                            // 20 % of viewport height
                            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
                            
                            if abs(trans.y) > maxHeight
                            {
                                height = (ll?.barRect?.height)! + maxHeight
                                
                                curY = (ll?.barRect?.minY)! - maxHeight
                            }
                            
                            let origDiff = maxHeight
                            
                            let curDiff = maxHeight - abs(trans.y)          //(curY - ((ll?.barRect?.minY)! - origDiff))
                            
                            if curDiff < 0
                            {
                                opac = 0
                                curWidth = 0
                            }
                            else
                            {
                                opac = (1/origDiff)*curDiff
                                
                                curWidth =  ((ll?.barRect?.width)!/origDiff)*curDiff
                            }
                            
                            changeOpacityForOther(barLayer: ll!, opacity: opac, width: curWidth, chart: barChart)
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height))
                            
                        }
                        
                        
                        
                        /*let anim = CABasicAnimation(keyPath: "path")
                         anim.fromValue = ll?.path
                         anim.toValue = newPath.cgPath
                         anim.duration = 0
                         anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                         ll?.add(anim, forKey: "path")
                         ll?.path = newPath.cgPath */
                        
                        CommonHelperFunctions.performPathAnim(targetLayer: ll!, newPath: newPath, duration: 0)
                    }
                }
            }
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                {
                    eachBar.opacity = 1
                }
                
                
                if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
                {
                    barChart._isDragging = true
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: chart)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }
                    
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            var flag = true
            var filtered = false
            if recognizer.nsuiNumberOfTouches() == 2 //.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            // 20 % of viewport height
            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
            
            let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: lastTouched!)
            if verticalMove && ll != nil && startLay != nil  && !barChart._isDragging
            {
                let vel = recognizer.velocity(in: barChart)
                let newPath:CGMutablePath!
                let animDur:TimeInterval!
                
                
                if ll != nil && startLay != nil{
                    
                    // Drill
                    if vel.y < -1200 || ((ll?.path?.boundingBox.height)! > (ll?.barRect?.height)!)
                    {
                        
                        if (ll?.path?.boundingBox.height)! == (ll?.barRect?.height)! + maxHeight
                        {
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.minY)! + (ll?.barRect?.height)!, width: (ll?.barRect?.width)!, height: plotOption.roundedRadii + 2.0)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.minY)! + (ll?.barRect?.height)!, width: (ll?.barRect?.width)!, height: 0))
                            
                            for eachBar in BarLayer.getAllBarLayer(chart: chart)
                            {
                                if eachBar == ll
                                {
                                    continue
                                }
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 0, changeSize: CGSize(width: 0, height: (eachBar.barRect?.height)!), chart: chart, duration: 0.4)
                            }
                        }
                        else
                        {
                            flag = false
                            newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                            
                            for eachBar in BarLayer.getAllBarLayer(chart: chart)
                            {
                                if eachBar == ll
                                {
                                    continue
                                }
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 1, changeSize: CGSize(width: (ll?.barRect?.width)!, height: (eachBar.barRect?.height)!), chart: chart, duration: 0.4)
                            }
                            
                        }
                        
                        
                        
                        
                        
                        animDur = 0.4
                    }
                    else if vel.y > 1200  || ((ll?.path?.boundingBox.height)! < ((ll?.barRect?.height)!/2))
                    {
                        barChart.interactionAnimationInProgress = true
                        
                        filtered = true
                        
                        let newRect = CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.midY)!+((ll?.barRect?.height)!/4), width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!/4)
                        
                        newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.midY)!+((ll?.barRect?.height)!/4), width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!/4))
                        
                        let barOpacity = Interpolator.interpolate(a: Double((ll?.opacity)!), b: 0)
                        let opacityAnimator = Animator()
                        
                        opacityAnimator.updateBlock = {
                            ll?.opacity = Float(barOpacity(opacityAnimator.phaseX))
                        }
                        
                        opacityAnimator.stopBlock = { [unowned opacityAnimator] in
                            opacityAnimator.updateBlock = nil
                        }
                        
                        let dur:TimeInterval!
                        
                        if (ll?.path?.boundingBox.height)! < ((ll?.barRect?.height)!/2)
                        {
                            dur = 0.1
                            animDur = 0.3
                        }
                        else{
                            dur = 0.3
                            animDur = 0.5
                        }
                        
                        opacityAnimator.animate(xAxisDuration: dur, easingOption: .linear)
                        
                    }
                    else{
                        flag = false
                        newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                        animDur = 0.3
                    }
                    
                    /* CATransaction.begin()
                     let anim = CABasicAnimation(keyPath: "path")
                     anim.fromValue = ll?.path
                     anim.toValue = newPath.cgPath
                     anim.duration = animDur
                     anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                     CATransaction.setCompletionBlock({
                     if flag{
                     //                            barChart.updateDataOrigIndex()
                     if filtered
                     {
                     barChart.removeEntry(barEntry: ll?.chartEntry!, defaultAnimation: true)
                     }
                     else
                     {
                     barChart.drillEntry(barEntry: ll?.chartEntry!)
                     }
                     }
                     else{
                     for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                     {
                     eachBar.opacity = 1
                     }
                     }
                     })
                     
                     ll?.add(anim, forKey: "path")
                     CATransaction.commit()
                     ll?.path = newPath.cgPath */
                    
                    let completionBlock = {
                        if flag{
                            //                            barChart.updateDataOrigIndex()
                            if filtered
                            {
                                BarHelperFunctions.removeEntry(barEntry: (ll?.chartEntry)!, defaultAnimation: true, chart: chart)
                            }
                            else
                            {
                                BarHelperFunctions.drillEntry(barEntry: (ll?.chartEntry)!, chart: chart)
                            }
                        }
                        else{
                            for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                            {
                                eachBar.opacity = 1
                            }
                        }
                    }
                    CommonHelperFunctions.performPathAnim(targetLayer: ll!, newPath: newPath, duration: animDur, completionBlock: completionBlock)
                }
                
                
            }
            else{
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.nsuiIsScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
}


// Code Change for Segmented Bar
/*
//
//  CustomBarPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 23/10/17.
//  Copyright © 2017 charts. All rights reserved.
//


 #if !os(OSX)
     import UIKit
 #endif

open class CustomBarPanHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    var sumChange:CGFloat = 0
    
    var totalHeight:CGFloat = 0.0
    
    
    var baseLineValue = Double(0)
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }
    
    open func getTotalHeightOfSelectedEntry(barChart:BarChartView) -> CGFloat
    {
        var height:CGFloat = 0.0
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            if layer.getBarChartEntry().x == barChart.lastSelected?.x
            {
                height = height + (layer.barRect?.size.height)!
            }
        }
        
        return height
    }
    
    open func distance(from: CGPoint, to: CGPoint) -> CGFloat
    {
        let dx = from.x - to.x
        let dy = from.y - to.y
        return sqrt(dx * dx + dy * dy)
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart as! BarLineChartViewBase
        let barData = barChart.data as! ChartData
        
        if (barChart.data?.maxEntryCountSet?.entryCount)! <= 1
        {
            return
        }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
            sumChange = 0
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: startLoc!)
            lastTouched = startLoc
            
            if startLay != nil && !(recognizer.numberOfTouches == 2)
            {
                baseLineValue = barChart.getBaseLineValue(dataSet: (barChart.data?.getDataSetForEntry(startLay?.chartEntry))!)
                barChart.lastSelected = startLay?.chartEntry
                totalHeight = getTotalHeightOfSelectedEntry(barChart: barChart as! BarChartView) * (3/4)
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            if recognizer.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            if curLay != nil && (curLay?.chartEntry == startLay?.chartEntry) && verticalMove && !(barChart._isDragging)
            {
                
                barChart.lastSelected = startLay?.chartEntry
                
                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                {
                    eachBar.opacity = 0
                }
                
                trans = recognizer.translation(in: barChart)
                
                if vel.y > 5 || vel.y < -5 {
                    
                    let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
                    sumChange += trans.y
                    
                    if ll != nil
                    {
                        
                        let dist = distance(from: startLoc!, to: curLoc)
                        
                        let barDataSet = (barData.dataSets[0] as! ChartDataSet)
                        
                        let selectedBarEntry = barChart.lastSelected!
                        
                        let bottomYValue = barData.negativeSum[selectedBarEntry.x] == nil ? baseLineValue : barData.negativeSum[selectedBarEntry.x]!
                        
                        let bottomYPosition = barChart.pixelForValues(x: 0, y: -(bottomYValue), axisIndex: barDataSet.axisIndex).y
                        
                        // Filter
                        if trans.y > 0
                        {
                            if dist >= (totalHeight)
                            {
                                trans.y = totalHeight
                            }
                            
                            let percent = (trans.y / totalHeight)
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                            {
                                if layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    let yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: bottomYPosition)
                                    let heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: 0)
                                    let opacityInterpolator = Interpolator.interpolate(a: CGFloat(1), b: CGFloat(0))
                                    
                                    let newPath = UIBezierPath(rect: CGRect(x: (layer.barRect?.minX)!, y: yInterPolator(percent), width: (layer.barRect?.width)!, height: heightInterpolator(percent)))
                                    
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0)
                                    
                                    layer.opacity = Float(opacityInterpolator(percent))
                                }
                            }
                        }
                        else{ // Drill
                            
                            
                            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
                            
                            let opac:CGFloat!
                            
                            let curWidth:CGFloat!
                            
                            if abs(trans.y) > (maxHeight)
                            {
                                trans.y = -(maxHeight)
                            }
                            
                            let origDiff = maxHeight
                            
                            let curDiff =  origDiff + trans.y
                            
                            if curDiff < 0
                            {
                                opac = 0
                                curWidth = 0
                            }
                            else
                            {
                                
                                opac = (1/origDiff)*curDiff
                                
                                curWidth =  ((BarLayer.getAllBarLayer(chart: barChart)[0].barRect?.width)!/origDiff)*curDiff
                                
                                
                            }
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                            {
                                if layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    if  (layer.barRect?.maxY)! == bottomYPosition && (layer.barRect?.height)! > 0
                                    {
                                        BarHelperFunctions.changeBarYPositionAndHeight(barLayer: layer, newYValue: trans.y, chart: barChart, duration: 0)
                                    }
                                    else
                                    {
                                        BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: trans.y, chart: barChart, duration: 0)
                                        
                                    }
                                }
                                else{
                                    BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: opac, changeSize: CGSize(width: curWidth, height: (layer.barRect?.height)!), chart: barChart, duration: 0)
                                }
                            }
                        }
                    }
                }
            }
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                {
                    eachBar.opacity = 1
                }
                
                
                if recognizer.numberOfTouches == 2
                {
                    barChart._isDragging = true
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = barChart.performPanChange(translation: translation)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }
                    
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            if recognizer.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            // 20 % of viewport height
            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
            
            let curLoc = recognizer.location(in: barChart)
            
            let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: lastTouched!)
            if verticalMove && ll != nil && startLay != nil  && !barChart._isDragging
            {
                barChart.lastSelected = ll?.chartEntry
                
                let vel = recognizer.velocity(in: barChart)
                
                let dist = distance(from: startLoc!, to: curLoc)
                
                let barDataSet = (barData.dataSets[0] as! ChartDataSet)
                
                let selectedBarEntry = barChart.lastSelected!
                
                let bottomYValue = barData.negativeSum[selectedBarEntry.x] == nil ? baseLineValue : barData.negativeSum[selectedBarEntry.x]!
                
                let bottomYPosition = barChart.pixelForValues(x: 0, y: -(bottomYValue), axisIndex: barDataSet.axisIndex).y
                
                var animationDuration = 0.0
                
                if ll != nil && startLay != nil{
                    
                    // Drill
                    if trans.y <= 0
                    {
                        
                        // **************************************** Drill Performed **************************************************************
                        if abs(trans.y) >= (maxHeight)
                        {
                            trans.y = maxHeight
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                            {
                                if layer.getBarChartEntry().x == barChart.lastSelected?.x
                                {
                                    let newPath = UIBezierPath(rect: CGRect(x: (layer.barRect?.minX)!, y: bottomYPosition, width: (layer.barRect?.width)!, height: 0))
                                    CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                                barChart.drillEntry(barEntry: barChart.lastSelected!)
                            })
                        }
                            // **************************************** Drill reverted **************************************************************
                        else{
                            trans.y = 0
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let barPath = UIBezierPath(rect:layer.barRect!)
                                
                                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: barPath, duration: animationDuration)
                            }
                            
                        }
                    }
                    else
                    {
                        
                        var filtered = true
                        
                        if vel.y > 1200
                        {
                            trans.y = totalHeight
                            animationDuration = 0.2
                        }
                        else if dist > (totalHeight / 2 ) &&  dist <= (totalHeight )
                        {
                            trans.y = totalHeight
                            animationDuration = 0.2
                        }
                        else if dist >= (totalHeight)
                        {
                            trans.y = totalHeight
                            animationDuration = 0
                        }
                        else if dist <= (totalHeight / 2)
                        {
                            filtered = false
                            trans.y = 0
                            animationDuration = 0.2
                        }
                        
                        let percent = (trans.y / totalHeight)
                        
                        
                        barChart.interactionAnimationInProgress = true
                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                        {
                            if layer.getBarChartEntry().x == barChart.lastSelected?.x
                            {
                                let yInterPolator = Interpolator.interpolate(a: (layer.barRect?.minY)!, b: bottomYPosition)
                                let heightInterpolator = Interpolator.interpolate(a: (layer.barRect?.height)!, b: 0)
                                let opacityInterpolator = Interpolator.interpolate(a: CGFloat(1), b: CGFloat(0))
                                
                                let newPath = UIBezierPath(rect: CGRect(x: (layer.barRect?.minX)!, y: yInterPolator(percent), width: (layer.barRect?.width)!, height: heightInterpolator(percent)))
                                
                                CommonHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                CommonHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: opacityInterpolator(percent), duration: animationDuration)
                            }
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                            
                            if filtered
                            {
                                barChart.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true)
                            }else {
                                barChart.interactionAnimationInProgress = false
                            }
                            
                        })
                    }
                }
                
                
            }
            else{
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = NSUIDisplayLink(target: barChart, selector: #selector(BarLineChartViewBase.decelerationLoop))
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.isScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
}
*/
