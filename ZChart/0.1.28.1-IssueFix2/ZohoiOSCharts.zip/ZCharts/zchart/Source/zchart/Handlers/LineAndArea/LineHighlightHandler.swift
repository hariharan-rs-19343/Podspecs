//
//  LineHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 24/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class LineHighlightHandler: NSObject, EventHandler {
    
    open func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.lineHighlight
    }
    
    open func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        if entry != nil{
           
                let lineChart = chart
                LineHelperFunctions.removeMagnifyEffect(chart: lineChart)
            
                if !chart.viewPortHandler.isInBoundsX(touchLocation.x)
                {
                    CommonHelperFunctions.removeHighlightLayer(chart: chart)
                    lineChart.lastSelectedHigh = nil
                    lineChart.lastSelected = nil
                    lineChart.resetHighlight()
                    lineChart.callDelegateToContainer(highlight: nil, entry: nil)
                    lineChart.setNeedsDisplay()
                    return
                }
            
                LineHelperFunctions.highlightAllDatasetEntry(entry:entry!, chart: chart , includeVerticalLine: true)
            
                let high = chart.getHighlightByTouchPoint(touchLocation)
            
                lineChart.lastHighlighted = high
            
                lineChart.callDelegateToContainer(highlight: high, entry: entry)
          
                //LineHelperFunctions.highlightCurrentDataset(entry: entry!, chart: chart as! BarLineChartViewBase)
               // LineHelperFunctions.highlightArea(chart: chart, entryLayer: entryLayer!,entry:entry)
            
        }
    }
    
    ///********************** Multiple X Removal Testing ********************
    
    /*var uniqueX = Set<Double>()
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        if entry != nil && chart.viewPortHandler.isInBoundsX(touchLocation.x) {
                uniqueX.insert((entry!.x))
                return
        }
        else if !chart.viewPortHandler.isInBoundsX(touchLocation.x)
        {
            chart.updateDataOrigIndex()
            var removeEntries:[ChartDataEntry] = []
            for set in chart.data!.dataSets
            {
                for entry in (set as! ChartDataSet).values where uniqueX.contains(entry.x)
               {
                   removeEntries.append(entry)
               }
            }
            ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: chart, duration: 3)
            uniqueX.removeAll()
        }
    }*/
}
