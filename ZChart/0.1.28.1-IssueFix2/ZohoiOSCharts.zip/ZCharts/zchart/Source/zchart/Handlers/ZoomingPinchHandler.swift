//
//  ZoomingPinchHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 08/03/18.
//  Copyright © 2018 zoho. All rights reserved.
//


open class ZoomingPinchHandler:NSObject,EventHandler
{
    
    open var drillState:Bool = false
    
    open var drillStateMatrix:CGAffineTransform? = nil
    
    var scaledMatrix:CGAffineTransform? = nil
    
    public func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.zoomInOut
    }
    public func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?, _ touchLocation: CGPoint)
    {
        let barLineChart = chartView
        
        let recognizer = recognizer as! NSUIPinchGestureRecognizer
        
        
        // width for single point
        var currentWidth:CGFloat =  CommonHelperFunctions.stepSize(chart: barLineChart, axisIndex: 0)
        if barLineChart.xAxis.scaleType != .Ordinal
        {
            currentWidth =  CommonHelperFunctions.getMaxWidthBetweenEntries(barLine: barLineChart)
        }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            barLineChart.stopDeceleration()
            
            if barLineChart._data !== nil &&
                (barLineChart.pinchZoomEnabled || barLineChart.scaleXEnabled || barLineChart.scaleYEnabled)
            {
                barLineChart._isScaling = true
                
                if barLineChart.pinchZoomEnabled
                {
                    barLineChart._gestureScaleAxis = .both
                }
                else
                {
//                    let x = abs((recognizer.location(in: barLineChart).x) - (recognizer.location(ofTouch: 1, in: barLineChart).x))
//                    let y = abs((recognizer.location(in: barLineChart).y) - (recognizer.location(ofTouch: 1, in: barLineChart).y))
                    
                    var touchLoaction = CGPoint()
                    
                    #if os(iOS)
                        touchLoaction = recognizer.numberOfTouches > 0 ? recognizer.nsuiLocationOfTouch(1, inView: barLineChart) : touchLoaction
                    #endif
                    
                    let x = abs((recognizer.location(in: barLineChart).x) - touchLoaction.x)
                    let y = abs((recognizer.location(in: barLineChart).y) - touchLoaction.y)
                    
                    if barLineChart.scaleXEnabled != barLineChart.scaleYEnabled
                    {
                        barLineChart._gestureScaleAxis = barLineChart.scaleXEnabled ? .x : .y
                    }
                    else
                    {
                        barLineChart._gestureScaleAxis = x > y ? .x : .y
                    }
                }
            }
            
            /// Since translation should be allowed on zoom restriction
            if drillStateMatrix != nil && drillState
            {
                if barLineChart.isRotated {
                    drillStateMatrix?.ty = barLineChart.viewPortHandler.touchMatrix.ty
                }
                else {
                    drillStateMatrix?.tx = barLineChart.viewPortHandler.touchMatrix.tx
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            var widthToAttain = CGFloat.greatestFiniteMagnitude
            
            /*if (barLineChart.data)!.isKind(of: BarLineScatterCandleBubbleChartData.self)
            {
                widthToAttain = (barLineChart.data as! BarLineScatterCandleBubbleChartData).maxWidthZoomRestrictionPixel
            }*/
            
            if (barLineChart.getPlotOptions() is AxisChartPlotOptions)
            {
                widthToAttain = (barLineChart.getPlotOptions() as! AxisChartPlotOptions).maxWidthZoomRestrictionPixel
            }
            
            if currentWidth >= widthToAttain
            {
                if drillState == false
                {
                    ChartUtils.longPressSound()
                    drillState = true
                }
                
            }
            else{
                
                drillState = false
                
                drillStateMatrix = nil
            }
            
            if drillState && drillStateMatrix == nil{
                
                drillStateMatrix = barLineChart.viewPortHandler.touchMatrix
                _  =  CommonHelperFunctions.performPinch(recognizer: recognizer, chart: chartView)
                
                barLineChart.notifyDataSetChanged(redrawRequired: false)
            }
            else{
                let returnMatrix = CommonHelperFunctions.performPinch(recognizer: recognizer, chart: chartView)
                barLineChart.notifyDataSetChanged(redrawRequired: false)
                if returnMatrix != nil{
                    scaledMatrix = returnMatrix
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended ||
            recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            if barLineChart._isScaling
            {
                if drillState && drillStateMatrix != nil && scaledMatrix != nil
                {
                    if barLineChart.isRotated && (scaledMatrix?.d)! < (drillStateMatrix?.d)! || !barLineChart.isRotated && (scaledMatrix?.a)! < (drillStateMatrix?.a)!
                    {
                        drillStateMatrix = scaledMatrix
                    }
                    else{
                    
                        let scaleAnimator = Animator()
                        
                        let scaleInterpolator = barLineChart.isRotated ? Interpolator.interpolate(a: (scaledMatrix?.d)!, b: (drillStateMatrix?.d)!) : Interpolator.interpolate(a: (scaledMatrix?.a)!, b: (drillStateMatrix?.a)!)
                        let translateInterpolator = barLineChart.isRotated ? Interpolator.interpolate(a: (scaledMatrix?.ty)!, b: (drillStateMatrix?.ty)!) : Interpolator.interpolate(a: (scaledMatrix?.tx)!, b: (drillStateMatrix?.tx)!)
                        
                        scaleAnimator.updateBlock = { [unowned barLineChart] in
                            var matrix = self.scaledMatrix
                            if barLineChart.isRotated {
                                matrix?.ty = translateInterpolator(CGFloat(scaleAnimator.phaseX))
                                matrix?.d = scaleInterpolator(CGFloat(scaleAnimator.phaseX))
                            }
                            else {
                                matrix?.tx = translateInterpolator(CGFloat(scaleAnimator.phaseX))
                                matrix?.a = scaleInterpolator(CGFloat(scaleAnimator.phaseX))
                            }
                            let _ = barLineChart._viewPortHandler.refresh(newMatrix: matrix!, chart: barLineChart, invalidate: true)
                            
                            ChartPreprocessor.prepareDataLabelRects(chart: chartView)
                            
                            barLineChart.notifyDataSetChanged(redrawRequired: false)
                            
                            let (min,max) = CommonHelperFunctions.getXMinAndMaxValue(chart: barLineChart)
                            
                            barLineChart.delegateToContainer?.chartXRangeUpdated?(minimum: min, maximum: max, updateLayer: true)
                        }
                        
                        scaleAnimator.stopBlock = { [unowned scaleAnimator] in
                            scaleAnimator.updateBlock = nil
                        }
                        
                        scaleAnimator.animate(xAxisDuration: 0.2)
                    }
                }
                
                barLineChart._isScaling = false
                
//                _ = CommonHelperFunctions.resizeAxisIfNeeded(chart: chartView)
                
                // Range might have changed, which means that Y-axis labels could have changed in size, affecting Y-axis size. So we need to recalculate offsets.
                barLineChart.calculateOffsets()
                barLineChart.setNeedsDisplay()
                
            }
        }
    }
    
    
    func isInBounds(barLineChart:ChartViewBase,xIndex:Double)-> Bool
    {
        let location = barLineChart.pixelForValues(x: xIndex, y: 10, axisIndex: 0)
        
        if barLineChart.viewPortHandler.isInBoundsX(location.x)
        {
            return true
        }
        else{
            return false
        }
        
    }
    
    public func onNoDrill(_ chartView: ChartViewBase, stateMatrix:CGAffineTransform?){
        
        let scaleAnimator = Animator()
        
        if stateMatrix == nil || scaledMatrix == nil {
            return
        }
        
        let scaleInterpolator = Interpolator.interpolate(a: (scaledMatrix?.a)!, b: (stateMatrix?.a)!)
        
        let translateInterpolator = Interpolator.interpolate(a: (scaledMatrix?.tx)!, b: (stateMatrix?.tx)!)
        
        scaleAnimator.updateBlock = {
            
            var matrix = self.scaledMatrix
            
            matrix?.a = scaleInterpolator(CGFloat(scaleAnimator.phaseX))
            
            matrix?.tx = translateInterpolator(CGFloat(scaleAnimator.phaseX))
            
            let _ = chartView._viewPortHandler.refresh(newMatrix: matrix!, chart: chartView, invalidate: true)
            
        }
        
        scaleAnimator.animate(xAxisDuration: 0.5)
        
    }
    
}
