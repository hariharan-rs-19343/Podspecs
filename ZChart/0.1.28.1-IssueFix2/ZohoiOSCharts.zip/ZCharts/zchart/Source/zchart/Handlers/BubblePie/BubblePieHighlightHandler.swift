//
//  BubblePieHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 08/10/21.
//  Copyright © 2021 zoho. All rights reserved.
//

open class BubblePieHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
  
        let bubbleChart = chart
        
        if !bubbleChart.viewPortHandler.isInBoundsX(touchLocation.x)
        {
            bubbleChart.resetHighlight()
            bubbleChart.setNeedsDisplay()
            bubbleChart.lastSelected = nil
            bubbleChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
                
        if entry != nil{
           
            for layer in PieLayer.getAllPieLayer(chart: bubbleChart)
            {
                guard let dataSetOptions = layer.chartDataSet?.dataSetOptions as? AxisChartDataSetOptions
                           else {  return }
                let holeColor = (((dataSetOptions.shapeProperties.holeColor) == nil) ? (NSUIColor.clear) : (dataSetOptions.shapeProperties.holeColor!) )
                if layer.chartEntry?.x == entry?.x && layer.chartEntry?.y == entry?.y
                {
                    layer.fillColor = holeColor.cgColor
                }
                else{
                    layer.fillColor = NSUIColor.gray.withAlphaComponent(0.5).cgColor
                }
            }
            
            let dataSet = (chart.data?.getDataSetForEntry(entry))!
            
            let entryLocation = bubbleChart.pixelForValues(x: (entry?.x)!, y: (entry?.y)!, axisIndex: dataSet.axisIndex)
            
            let high = chart.getHighlightByTouchPoint(entryLocation)
            
//            bubbleChart.lastSelected = entry
            bubbleChart.updateLastSelectedEntry(entry: entry)
            bubbleChart.xGroupSelected = true
            
            bubbleChart.callDelegateToContainer(highlight: high, entry: entry)
    
        }
    }
    
    
}

