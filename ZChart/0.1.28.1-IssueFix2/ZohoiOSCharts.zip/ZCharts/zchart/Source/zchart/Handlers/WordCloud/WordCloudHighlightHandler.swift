//
//  WordCloudHighlightHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 22/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class WordCloudHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barHighlight
    }
    
    /*
     public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint)
     {
         
         if entry != nil
         {
             let viewport = chart.viewPortHandler!

             let dict = (WordCloudTextLayer.getWordLayerForEntry(chart: chart, entry: entry!)?.valueDict)!
             
             let xValue = dict["x"] as! CGFloat
             let yValue = dict["y"] as! CGFloat
             
             let xyValue = chart.plotTransformer.valueForTouchPoint(CGPoint(x: Double(xValue), y: Double(yValue)))
             
             let textRect = (WordCloudTextLayer.getWordTextLayerForEntry(chart: chart, entry: entry!)?.frame)!
             
             var zoomOutNeeded = false
             
             var translateNeeded = false
             
             if textRect.width > viewport.contentWidth || textRect.height > viewport.contentHeight
             {
                 zoomOutNeeded = true
             }
             
             if !(isInBound(frame: textRect, chart: chart))
             {
                 translateNeeded = true
             }
             
             if zoomOutNeeded || translateNeeded
             {
                 let endBlock = { WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: entry) }
                 if zoomOutNeeded
                 {
                     let requiredRangeSize = textRect.applying(chart.plotTransformer.valueToPixelMatrix.inverted())
                     
                     CommonHelperFunctions.zoomAndCenterPlotViewAnimated(chart: chart, xValue: Double(xyValue.x), yValue: Double(xyValue.y), rectSizeToShow: requiredRangeSize, completionBlock: endBlock, duration: 0.3)
                 }
                 else{
                     
                     CommonHelperFunctions.centerPlotView(chart: chart, xValue: Double(xyValue.x), yValue: Double(xyValue.y), animated: true, completionBlock: endBlock, duration: 0.3)
                 }
             }
             else{
                 WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: entry)
             }
         }
         else{
             WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: entry)
         }
     }
     */
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint)
    {
//        var entry = entry
//        for indexValue in 0..<(chart.data?.dataSets[0].entryCount)!
//        {
//            entry = chart.data?.dataSets[0].entryForIndex(indexValue)
//            
//            if let dict = (WordCloudTextLayer.getWordLayerForEntry(chart: chart, entry: entry!)?.valueDict)
//            {
//                continue
//            }
//            break
//        }
//        
        if entry != nil
        {
            let viewport = chart.viewPortHandler!

            var isVisible = true
            
            let layerForEntry = WordCloudTextLayer.getWordLayerForEntry(chart: chart, entry: entry!)
            
            if layerForEntry == nil { isVisible = false }
            
            let dict:[String:Any]!
            
            if isVisible
            {
                dict = (WordCloudTextLayer.getWordLayerForEntry(chart: chart, entry: entry!)?.valueDict)!
            }
            else{
                guard let set = chart.data?.getDataSetForEntry(entry!) as? ChartDataSet,
                      let setIndex = chart.data?.indexOfDataSet(set)
                    else { return }
                
                let entryIndex = set.entryIndex(entry: entry!)
                
                dict = WordCloudHelperFunctions.getDictOfInvisibleWord(chart: chart, setIndex: setIndex, entryIndex: entryIndex)
            }
            
            let xValue = dict["x"] as! CGFloat
            let yValue = dict["y"] as! CGFloat
            
            let xyValue = isVisible ? chart.plotTransformer.valueForTouchPoint(CGPoint(x: Double(xValue), y: Double(yValue))) :  CGPoint(x: xValue, y: yValue)
            
            let textRect:CGRect!
            if isVisible{
                textRect = (WordCloudTextLayer.getWordTextLayerForEntry(chart: chart, entry: entry!)?.frame)!
            }
            else{
                guard let set = chart.data?.getDataSetForEntry(entry!) as? ChartDataSet
                    else { return }
                
                var size = dict["fontSize"] as! CGFloat
                let rotation = dict["rotation"] as! CGFloat
                let valueText:String = dict["text"] as! String
                
                var point = CGPoint(x:xValue, y :yValue)
                
                chart.plotTransformer.pointValueToPixel(&point)
                
                size = size * chart.plotTransformer.valueToPixelMatrix.a
        
                var valueFont = set.valueFont                
                if #available(macOS 10.15, *) {
                    valueFont = set.valueFont.withSize(size)
                } else {
                    // Fallback on earlier versions
                }
                let valueColor = set.color(atIndex: dict["entryIndex"] as! Int)
                let valueAttributes = [NSAttributedString.Key.font: valueFont , NSAttributedString.Key.foregroundColor: valueColor]
            
                let textSize = valueText.size(withAttributes: valueAttributes)
                
                let dummyText:CATextLayer = ChartUtils.drawTextLayer(
                text: valueText,
                point: CGPoint(x: point.x, y: point.y-textSize.height/2),
                align: .center,
                attributes: valueAttributes)
            
                dummyText.transform = CATransform3DMakeRotation(rotation, 0.0, 0.0, 1.0)
            
                textRect = dummyText.frame
            }
            
            var zoomOutNeeded = false
            
            var translateNeeded = false
            
            if textRect.width > viewport.contentWidth || textRect.height > viewport.contentHeight
            {
                zoomOutNeeded = true
            }
            
            if !(isInBound(frame: textRect, chart: chart))
            {
                translateNeeded = true
            }
            
            if zoomOutNeeded || translateNeeded
            {
            
                let fromMatrix = chart.viewPortHandler.touchMatrix
                
                var matrix = CGAffineTransform()
                    
                if zoomOutNeeded
                {
                    let requiredRangeSize = textRect.applying(chart.plotTransformer.valueToPixelMatrix.inverted())

                    let requiredWidthRange = requiredRangeSize.width
                    let requiredHeightRange = requiredRangeSize.height
                
                    let scaleX = chart.viewPortHandler.contentWidth / requiredWidthRange
                    let scaleY = chart.viewPortHandler.contentHeight / requiredHeightRange
                    
                    let scaleValue = min(scaleX,scaleY)
                    
                    matrix = viewport.setZoom(scaleX: scaleValue, scaleY: scaleValue)
                    let _ = CommonHelperFunctions.refreshPlotWithoutRedraw(newMatrix: matrix, chart: chart, invalidate: false)
                }
                
                var pt = xyValue

                chart.plotTransformer.pointValueToPixel(&pt)
                
                pt = CGPoint(x: pt.x - chart.viewPortHandler.contentWidth/2, y: pt.y - chart.viewPortHandler.contentHeight/2)
                
                matrix = viewport.translate(pt: pt)
    //            let _ = viewport.refreshPlot(newMatrix: matrix, chart: chart, invalidate: true)
                
                let scaleAnimator = Animator()
                
                let scaleAInterpolator = Interpolator.interpolate(a: (fromMatrix.a), b: (matrix.a))
                let scaleDInterpolator = Interpolator.interpolate(a: (fromMatrix.d), b: (matrix.d))
                let translateXInterpolator = Interpolator.interpolate(a: (fromMatrix.tx), b: (matrix.tx))
                let translateYInterpolator = Interpolator.interpolate(a: (fromMatrix.ty), b: (matrix.ty))
                
                scaleAnimator.updateBlock = {
                    var matrix = fromMatrix
                    matrix.a = scaleAInterpolator(CGFloat(scaleAnimator.phaseX))
                    matrix.d = scaleDInterpolator(CGFloat(scaleAnimator.phaseX))
                    matrix.tx = translateXInterpolator(CGFloat(scaleAnimator.phaseX))
                    matrix.ty = translateYInterpolator(CGFloat(scaleAnimator.phaseX))
                    let _ = viewport.refreshPlot(newMatrix: matrix, chart: chart, invalidate: true)
                }
                
                scaleAnimator.stopBlock = {
                    WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: entry)
                }
                
                scaleAnimator.animate(xAxisDuration: 0.3)
            }
            else{
                WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: entry)
            }
            
        }
        else{
            WordCloudHelperFunctions.highLightWordEntry(chart: chart, entry: entry)
        }
    }
    
    func isInBound(frame:CGRect, chart:ChartViewBase) -> Bool {
        let viewPortHandler = chart.viewPortHandler!
        
        return viewPortHandler.isInBoundsLeft(frame.origin.x) && viewPortHandler.isInBoundsRight(frame.origin.x + frame.width) && viewPortHandler.isInBoundsTop(frame.origin.y) && viewPortHandler.isInBoundsBottom(frame.origin.y + frame.height)
        
    }
}
