//
//  BarPanHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 19/09/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class BarPanHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    var sumChange:CGFloat = 0
    
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }
    
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
      
            let recognizer = recognizer as! NSUIPanGestureRecognizer
            let barChart = chart
        
            if recognizer.state == NSUIGestureRecognizerState.began //&& recognizer.nsuiNumberOfTouches() > 0
            {
                
                sumChange = 0
                verticalMove = true
                startLoc = recognizer.location(in: barChart)
                startLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: startLoc!)
                lastTouched = startLoc
                
                if startLay != nil{
                    BarHelperFunctions.highlightBar(location: startLoc!, bar: barChart)
                }
                barChart.stopDeceleration()
                
                if barChart._data === nil
                { // If we have no data, we have nothing to pan and no data to highlight
                    return
                }
                
                // If drag is enabled and we are in a position where there's something to drag:
                //  * If we're zoomed in, then obviously we have something to drag.
                //  * If we have a drag offset - we always have something to drag
                if barChart.isDragEnabled &&
                    (!barChart.hasNoDragOffset || !barChart.isFullyZoomedOut)
                {
                    barChart._isDragging = true
                    
                    barChart._closestDataSetToTouch = barChart.getDataSetByTouchPoint(point: recognizer.nsuiLocationOfTouch(0, inView: barChart))
                    
                    let translation = recognizer.translation(in: barChart)
                    let didUserDrag = (barChart.isRotated) ? translation.y != 0.0 : translation.x != 0.0
                    
                    // Check to see if user dragged at all and if so, can the chart be dragged by the given amount
                    if didUserDrag && !(CommonHelperFunctions.performPanChange(translation: translation, chart: barChart))
                    {
                        if barChart._outerScrollView !== nil
                        {
                            // We can stop dragging right now, and let the scroll view take control
                            barChart._outerScrollView = nil
                            barChart._isDragging = false
                        }
                    }
                    else
                    {
                        if barChart._outerScrollView !== nil
                        {
                            // Prevent the parent scroll view from scrolling
                            barChart._outerScrollView?.nsuiIsScrollEnabled = false
                        }
                    }
                    
                    barChart._lastPanPoint = recognizer.translation(in: barChart)
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    // We will only handle highlights on NSUIGestureRecognizerState.Changed
                    
                    barChart._isDragging = false
                }
                
                barChart._isDragging = false
                
                if recognizer.nsuiNumberOfTouches() == 2
                {
                    barChart._isDragging = true
                }
                
            }
            else if recognizer.state == NSUIGestureRecognizerState.changed
            {
                let vel = recognizer.velocity(in: barChart)
                let curLoc = recognizer.location(in: barChart)
                
                if recognizer.nsuiNumberOfTouches() == 2
                {
                    barChart._isDragging = true
                }
                
                curLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: curLoc) //(chart: self, loc: curLoc)
                
                if curLay != nil{
                    lastTouched = curLoc
                }
                
                if curLay != nil && (curLay?.chartEntry == startLay?.chartEntry) && verticalMove
                {
                    trans = recognizer.translation(in: barChart)
                    
                    for eachBar in BarLayer.getAllValueLayer(chart: chart)
                    {
                        eachBar.opacity = 0
                    }
                    
                    if vel.y > 5 || vel.y < -5 {
                        
                        //  let ll = BarLayer.getBarLayerInPoint(chart: self, loc: curLoc)
//                        let changeY = curLoc.y - (startLoc?.y)!
                        let ll = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: curLoc)
                        sumChange += trans.y
                        
                        if ll != nil
                        {
                            let anim = CABasicAnimation(keyPath: "path")
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.minY)!+trans.y, width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!)
                            let newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.minY)!+trans.y, width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!))
                            anim.fromValue = ll?.path
                            anim.toValue = newPath//?.cgPath
                            anim.duration = 0
                            anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
                            ll?.add(anim, forKey: "path")
                            ll?.path = newPath//?.cgPath
                        }
                    }
                }
                else {
                    if curLay != nil   {
                        verticalMove = false
                    }
                    //                if recognizer.nsuiNumberOfTouches() == 1
                    //                {
                    //                    _isDragging = false
                    //                }
                    if recognizer.nsuiNumberOfTouches() == 2
                    {
                       barChart._isDragging = true
                    }
                    
                    if barChart._isDragging
                    {
                        let originalTranslation = recognizer.translation(in: barChart)
                        let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                        
                        let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: barChart)
                        
                        barChart._lastPanPoint = originalTranslation
                    }
                    else if barChart.isHighlightPerDragEnabled
                    {
                        let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                        if selected != nil
                        {
                            BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                        }
                        /* let h = getHighlightByTouchPoint(recognizer.location(in: self))
                         
                         let lastHighlighted = self.lastHighlighted
                         
                         if ((h === nil && lastHighlighted !== nil) ||
                         (h !== nil && lastHighlighted === nil) ||
                         (h !== nil && lastHighlighted !== nil && !h!.isEqual(lastHighlighted)))
                         {
                         self.lastHighlighted = h
                         self.highlightValue(h, callDelegate: true)
                         }*/
                    }
                }
                
            }
            else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
            {
                var flag = true
                if recognizer.nsuiNumberOfTouches() == 2
                {
                    barChart._isDragging = true
                }
                
                let ll = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: lastTouched!)
                if verticalMove && ll != nil && startLay != nil  && !barChart._isDragging
                {
                    let vel = recognizer.velocity(in: barChart)
                    let newPath:CGMutablePath!
                    
                    
                    if ll != nil && startLay != nil{
                        
                        if vel.y < -1200 || (((startLay?.barRect?.maxY)! - (ll?.path?.boundingBox.maxY)!) >= ((ll?.barRect?.height)!/2))
                        {
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: (-1 * (ll?.barRect?.height)!), width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (-1 * (ll?.barRect?.height)!), width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!))
                            
                            
                            let barOpacity = Interpolator.interpolate(a: 1.0, b: -(2.0))
                            let opacityAnimator = Animator()
                            
                            opacityAnimator.updateBlock = { [unowned opacityAnimator] in
                                ll?.opacity = Float(barOpacity(opacityAnimator.phaseX))
                            }
                            
                            opacityAnimator.stopBlock = { [unowned opacityAnimator] in
                                opacityAnimator.updateBlock = nil
                            }
                            
                            opacityAnimator.animate(xAxisDuration: 1, easingOption: .linear)
                        }
                        else if vel.y > 1200 || ((ll?.path?.boundingBox.minY)! > (((ll?.barRect?.height)!/2)+(startLay?.barRect?.minY)!))
                        {
                            
                            let newRect = CGRect(x: (ll?.barRect?.minX)!, y: barChart.frame.height, width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!)
                            
                            newPath = ll?.getPath(rect: newRect)//UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: barChart.frame.height, width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!))
                            
                            for eachBar in BarLayer.getAllBarLayer(chart: chart)
                            {
                                if eachBar == ll
                                {
                                    continue
                                }
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 0, changeSize: CGSize(width: 0, height: (eachBar.barRect?.height)!), chart: chart, duration: 1)
                            }
                        }
                        else{
                            flag = false
                            newPath = startLay?.getPath(rect: (startLay?.barRect)!)//UIBezierPath(rect: (startLay?.barRect)!)
                        }
                        
                        CATransaction.begin()
                        let anim = CABasicAnimation(keyPath: "path")
                        anim.fromValue = ll?.path
                        anim.toValue = newPath//.cgPath
                        anim.duration = 1
                        anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
                        CATransaction.setCompletionBlock({ [unowned self,barChart] in
                            if flag{
//                                barChart.alignBar(barLayer: ll! )
//                                barChart.updateDataOrigIndex()
                                if vel.y < -1200 || (((self.startLay?.barRect?.maxY)! - (ll?.path?.boundingBox.maxY)!) >= ((ll?.barRect?.height)!/2))
                                {
                                    BarHelperFunctions.removeEntry(barEntry: (ll?.chartEntry)!, defaultAnimation: true, chart: barChart)
                                }
                                else if vel.y > 1200 || ((ll?.path?.boundingBox.minY)! > (((ll?.barRect?.height)!/2)+(self.startLay?.barRect?.minY)!))
                                {
                                    BarHelperFunctions.drillEntry(barEntry: (ll?.chartEntry)!, chart: barChart)
                                }
                            }
                            else{
                                
                                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                                {
                                    eachBar.opacity = 1
                                }
                            }
                        })
                        
                        ll?.add(anim, forKey: "path")
                        CATransaction.commit()
                        ll?.path = newPath//.cgPath
                    }
                    
                    
                }
                else{
                    if barChart._isDragging
                    {
                        if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                        {
                            barChart.stopDeceleration()
                            
                            barChart._decelerationLastTime = CACurrentMediaTime()
                            barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                            
                            barChart._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barChart)
                            barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                            
                        }
                        
                        barChart._isDragging = false
                    }
                    
                    if barChart._outerScrollView !== nil
                    {
                        barChart._outerScrollView?.nsuiIsScrollEnabled = true
                        barChart._outerScrollView = nil
                    }
                }
            }
        
    }
}
