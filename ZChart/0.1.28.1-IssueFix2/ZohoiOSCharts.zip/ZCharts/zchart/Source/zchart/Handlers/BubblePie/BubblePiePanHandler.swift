//
//  BubblePiePanHandler.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 20/10/21.
//  Copyright © 2021 zoho. All rights reserved.
//


#if !os(OSX)
    import UIKit
#endif

open class BubblePiePanHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterPan
    }
    
    var startLoc:CGPoint!
    var startEntry:ChartDataEntry!
    var startLayer:ChartEntryLayer!
    
    var yValueToMove:CGFloat = 0
    
    var allOtherBubbleLayerAtSameIndex:[PieLayer]!
    
    var verticalPan = false
    var horizontalPan = false
    
    var highlighted = false
    
    var movingUp = false
    
    var allowed = true
    
    func deselect(chart:ChartViewBase)
    {
        chart.lastSelected = nil
//        plotOption.barGroupSelectionEnabled = false
        chart.resetHighlight()
        chart.callDelegateToContainer(highlight: nil, entry: nil)
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: NSUIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barLine = chart
        let trans = recognizer.translation(in: barLine)
        
        guard let plotOption = chart.getPlotOptions(type: .BubblePie) as? BubblePiePlotOptions,
            let renderer = CommonHelperFunctions.getRenderer(chart: barLine, types: [.BubblePie]) as? BubblePieChartRenderer
        else { return }
        
        if renderer.entryDeleted == true  || recognizer.nsuiNumberOfTouches() > 1 || (barLine.customAnimationInProgress)
        {   startEntry = nil
            return
        }
        
        if entry == nil || entryLayer == nil
        {
            barLine._isDragging = true
        }

        if recognizer.state == NSUIGestureRecognizerState.began //&& recognizer.nsuiNumberOfTouches() > 0
        {
            barLine.stopDeceleration()
            
            
            if barLine.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barLine._lastPanPoint = recognizer.translation(in: barLine)
            
            barLine._isDragging = false
            
            
            if (barLine.data?.getDataSetForEntry(entry) == nil)
            {
                startEntry = nil
                return
            }
            startLoc = CommonHelperFunctions.getEntryLocation(chart: chart , entry: entry!)
            startEntry = entry
            startLayer = entryLayer as? PieLayer
            
            
    
            
            if barLine.lastSelected != nil && barLine.lastSelected!.count > 0
            {
                if CommonHelperFunctions.getHighlightLayer(chart: barLine).count != 0
                {
                    highlighted = true
                    startLoc = CommonHelperFunctions.getEntryLocation(chart: barLine, entry: barLine.lastSelected![0])
                    startEntry = barLine.lastSelected![0]
                }
                else{
                    barLine.lastSelected = nil
//                    plotOption.barGroupSelectionEnabled = false
                    chart.resetHighlight()
                }
            }
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            
            if !barLine._isDragging {
                // Detecting vertical pan - once detected no change to horizontal
                if abs(trans.y) > 10 && abs(trans.x) < 10 && !verticalPan && !horizontalPan
                {
                    
                    if startEntry == nil
                    {
                        return
                    }
                    
                    verticalPan = true
                    
                    let maxEntryLocation = getMaximumEntryLocation(barLine: barLine)
                    
                    yValueToMove =  (chart.viewPortHandler.contentBottom - maxEntryLocation.y + plotOption.maximumShapeSizeInPixel) / 2
                    
                }
                else if abs(trans.x) > 10 && abs(trans.y) < 10 && !horizontalPan && !verticalPan
                {
                    if startEntry == nil
                    {
                        return
                    }
                    
                    horizontalPan = true
                    
                    let maxEntryLocation = getMaximumEntryLocation(barLine: barLine)
                    
                    yValueToMove =  (maxEntryLocation.x + plotOption.maximumShapeSizeInPixel - chart.viewPortHandler.contentLeft) / 2
                }
            }
            
            if verticalPan
            {
                if barLine.isRotated {
                    barLine._isDragging = true
                    verticalPan = false
                }
                else {
                    barLine._isDragging = false
                    isGoingToDrilled(chart: chart, plotOption: plotOption, trans: trans)
                }
            }
            else if horizontalPan{
                
                if barLine.isRotated {
                    barLine._isDragging = false
                    isGoingToDrilled(chart: chart, plotOption: plotOption, trans: trans)
                }
                else {
                    barLine._isDragging = true
                    horizontalPan = false
                }
            }
            
            if verticalPan || horizontalPan
            {
                if (chart.isRotated && trans.x > 0) || (!chart.isRotated && trans.y < 0) || movingUp
                {
                    // All entry highlighted case - not allowing up
                    if chart.xGroupSelected//plotOption.barGroupSelectionEnabled
                    {
                        CommonHelperFunctions.getHighlightLayer(chart: barLine)[safe:0]?.position = CGPoint(x: 0, y: 0 )
                        return
                    }
                    
                    if allowed && (!chart.isRotated && trans.y < 0 || chart.isRotated && trans.x > 0)
                    {
                        allowed = false
                        
                        
                        for layer in PieLayer.getAllPieLayer(chart: chart)
                        {
                            if layer.chartEntry?.x == startEntry?.x && layer.chartEntry?.y == startEntry?.y   //if layer.chartEntry == startEntry
                            {
                                continue
                            }
                            CommonHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: 0, duration: 0.5)
                            
                            layer.fillColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
                        }
                        
                    }
                    
                    // Exponential increment
                    var yValue = chart.isRotated ? abs(3*trans.x) : abs(3*trans.y)

                    if yValue > yValueToMove
                    {
                        yValue = yValueToMove
                    }
                    
                    // Restrict moving down
                    if (chart.isRotated && trans.x < 0) || !chart.isRotated && trans.y > 0
                    {
                        yValue = 0
                    }
                    
                    var newPoint = startLoc
                    
                    if barLine.isRotated {
                        newPoint?.x += yValue
                    }
                    else {
                        newPoint?.y -= yValue
                    }
                    
                    
                    if highlighted
                    {
                        // Circle
                        CommonHelperFunctions.getHighlightLayer(chart: barLine)[0].sublayers![1].position = chart.isRotated ? CGPoint(x: 0 - yValue, y: 0) : CGPoint(x: 0, y: 0 - yValue)
                        
                        // Horizontal Line
//                        LineHelperFunctions.getHighlightLayer(chart: barLine)[0].sublayers![0].sublayers![0].position = CGPoint(x: 0, y: 0 - yValue)
  
                    }
                    else{
                        /*let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                        CommonHelperFunctions.performPathAnim(targetLayer: startLayer, newPath: newPath, duration: 0)*/
                        if let startLayer = startLayer {
                            for layer in PieLayer.getPieLayersForEntryXY(chart: barLine, entry: startLayer.chartEntry!)
                            {
                                if barLine.isRotated {
                                    layer.position.x = yValue
                                }
                                else {
                                    layer.position.y = -yValue
                                }
                            }
                        }
                        //CommonHelperFunctions.performPositionAnim(targetLayer: startLayer, point: newPoint!, duration: 0.1)
                    }

                }
                else if !movingUp {         // Moving Down Case
                    
                    let yValue = chart.isRotated ? abs(3*trans.x) : abs(3*trans.y)
                    
                    if highlighted
                    {
                        if !chart.xGroupSelected//!plotOption.barGroupSelectionEnabled
                        {
                            return
                        }
                        else{
                            CommonHelperFunctions.getHighlightLayer(chart: barLine)[0].position = chart.isRotated ? CGPoint(x: 0 + yValue, y: 0) : CGPoint(x: 0, y: 0 + yValue)
                        }
                        
                    }
                    else{
                        for target in allOtherBubbleLayerAtSameIndex
                        {
                            var newPoint = CommonHelperFunctions.getPixelForValues(isRotated: barLine.isRotated, x: target.chartEntry!.x, y: target.chartEntry!.y, dataset: target.chartDataSet!, chart: barLine)
                            
                            if chart.isRotated {
                                newPoint.x -= yValue
                                
                                target.position.x = -yValue
                            }
                            else {
                                newPoint.y += yValue
                                
                                target.position.y = yValue
                            }
                        }
                    }
                    
                    
                }
                
            }
            else    // Scroll
          {
            if barLine.lastSelected != nil
            {
                deselect(chart: barLine)
            }
            
            let originalTranslation = recognizer.translation(in: barLine)
            let translation = CGPoint(x: originalTranslation.x - barLine._lastPanPoint.x, y: originalTranslation.y - barLine._lastPanPoint.y)
            
            let _ = CommonHelperFunctions.performPanChange(translation: translation, chart: barLine)
            
            barLine._lastPanPoint = originalTranslation
            }
     
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if verticalPan || horizontalPan
            {
                if startEntry == nil
                {
                    return
                }
                
                if movingUp
                {
                    // Check for drill condition
                    if !chart.isRotated && abs(trans.y*3) >= yValueToMove && trans.y < 0 || chart.isRotated && abs(trans.x*3) >= yValueToMove && trans.x > 0
                    {
                        barLine.curLevel += 1
                        barLine.delegateToContainer?.chartValueDrillPerformed!(barLine, entry: startEntry, level: barLine.curLevel)
//                        barLine.chartActionListener?.drillPerformed!(chartView: barLine, selectedEntry: startEntry,index: barLine.curLevel)
                    }
                    
                    barLine.setNeedsDisplay()
                }
                else{
                  
                    var filterAllowed = true
                    for set in (barLine.data?.dataSets)!
                    {
                        if set.isVisible
                        {
                            let startX =  (set.entryForXValue(-Double.greatestFiniteMagnitude, closestToY: Double.nan))?.x
                            let endX = (set.entryForXValue(Double.greatestFiniteMagnitude, closestToY: Double.nan))?.x
                            if startX == endX && startX == startEntry.x
                            {
                                filterAllowed = false
                                
                            }
                        }
                    }
                    
                    
                    let currentYValue = chart.isRotated ? abs(3*trans.x) : abs(3*trans.y)
                    
                    // Check for filter condition
                    if filterAllowed && currentYValue >= yValueToMove && trans.y > 0 || trans.x < 0
                    {
                        barLine.interactionAnimationInProgress = true

                        let percent = currentYValue / (yValueToMove*2)
                        
                        barLine.updateDataOrigIndex()
                        
                        var removeEntries:[ChartDataEntry] = []
                        for set in chart.data!.dataSets
                        {
                            for entry in (set as! ChartDataSet).values where self.startEntry.origX == entry.origX
                           {
                               removeEntries.append(entry)
                           }
                        }
                        
                        // isFullyHidden
                        if percent < 1
                        {
                            let duration = Double(1 - percent)
                            
                            if highlighted
                            {
                                let highLayer = CommonHelperFunctions.getHighlightLayer(chart: barLine)[0]
                                CommonHelperFunctions.performPositionAnim(targetLayer: highLayer, point: CGPoint(x: 0, y: 0 + (yValueToMove*4)), duration: duration)
                            }
                            else{
                                for target in allOtherBubbleLayerAtSameIndex
                                {
                                    var newPoint = CommonHelperFunctions.getPixelForValues(isRotated: barLine.isRotated, x: target.chartEntry!.x, y: target.chartEntry!.y, dataset: target.chartDataSet!, chart: barLine)
                                    
                                    if chart.isRotated {
                                        newPoint.x += (yValueToMove*2)
                                        
                                        CommonHelperFunctions.performPositionAnim(targetLayer: target, point: CGPoint(x: yValueToMove*2, y: 0), duration: duration)
                                    }
                                    else {
                                        newPoint.y += (yValueToMove*2)
                                        
                                        CommonHelperFunctions.performPositionAnim(targetLayer: target, point: CGPoint(x: 0, y: yValueToMove*2), duration: duration)
                                    }
                                }
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(duration*1100)), execute: {
                                
//                                ChartInteractionHelperFunction.alignScatterBubble(axisChartBase: barLine, chartEntry: self.startEntry, type: ChartType.Scatter)
//                                ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: self.startEntry, chart: barLine, duration: 0.5)
                                
                                ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: barLine, duration: 0.5)
                            })
                            
                        }
                        else{
//                            ChartInteractionHelperFunction.alignScatterBubble(axisChartBase: barLine, chartEntry: self.startEntry, type: ChartType.Scatter)
//                            ChartInteractionHelperFunction.removeEntriesAtXWithAnimation(entry: self.startEntry, chart: barLine, duration: 0.5)
                            ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: barLine, duration: 0.5)
                        }
                    }
                    else{
                        
                        barLine.setNeedsDisplay()
                    }
                    
                  
                }
                allowed = true
                movingUp = false
            }
            else{
                    barLine._isDragging = true
                
                    if recognizer.state == NSUIGestureRecognizerState.ended && barLine.isDragDecelerationEnabled
                    {
                        barLine.stopDeceleration()
                        
                        barLine._decelerationLastTime = CACurrentMediaTime()
                        barLine._decelerationVelocity = recognizer.velocity(in: barLine)
                        
                        barLine._decelerationDisplayLink = CommonHelperFunctions.getAxisScrollDecelerationLoop(chart: barLine)
                        barLine._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoop.Mode.common)
                        
                    }
                
                    barLine._isDragging = false
                
                
                    if barLine._outerScrollView !== nil
                    {
                        barLine._outerScrollView?.nsuiIsScrollEnabled = true
                        barLine._outerScrollView = nil
                    }
                
            }
            // To all
            verticalPan = false
            horizontalPan = false
            highlighted = false
            deselect(chart: barLine)
        }
    }
    
    func isGoingToDrilled(chart: ChartViewBase, plotOption: AxisChartPlotOptions, trans: CGPoint) {
        
        if  highlighted
        {
            if !chart.xGroupSelected//!plotOption.barGroupSelectionEnabled
            {
                yValueToMove = startLoc.y - 6 - chart.viewPortHandler.contentTop
                movingUp = true
            }
        }
        else{
            
            if chart.isRotated {
                if trans.x > 0 {
                    yValueToMove = chart.viewPortHandler.contentRight - (startLoc.x - plotOption.maximumShapeSizeInPixel)
                    movingUp = true
                }
            }
            else {
                if trans.y < 0
                {
                    yValueToMove = startLoc.y + plotOption.maximumShapeSizeInPixel - chart.viewPortHandler.contentTop
                    movingUp = true
                }
            }
        }
    }
    
    func getMaximumEntryLocation(barLine: ChartViewBase) -> CGPoint {
        
        if startEntry == nil {
            return CGPoint()
        }
        
        if let starLocEntry = barLine.getEntryByTouchPoint(point: startLoc) {
            startLayer = PieLayer.getPieLayerForEntry(chart: barLine, entry: starLocEntry)
        }
        
        let otherEntriesAtSameIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: startEntry,includeNan:false, chart: barLine)
        
        var maxEntry = startEntry
        
        allOtherBubbleLayerAtSameIndex = []
        
        // find entry at the top - maxY value
        for entry in otherEntriesAtSameIndex
        {
            if let layer = PieLayer.getPieLayerForEntry(chart: barLine, entry: entry) {
                if !highlighted
                {
                    allOtherBubbleLayerAtSameIndex.append(layer)
                }
                else{
                    layer.opacity = 0
                }
                
                if  entry.y > (maxEntry?.y)!
                {
                    maxEntry = entry
                }
            }
        }
        
        return CommonHelperFunctions.getEntryLocation(chart: barLine, entry: maxEntry!)!
    }
}
