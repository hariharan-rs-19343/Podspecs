//
//  BubblePieValueFormatter.swift
//  Pods
//
//  Created by Keerthivass B S on 09/07/24.
//

open class BubblePieValueFormatter: ValueFormatter {
    
    
    public override func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
        
        guard let chart = chartView, let datasets = chart.data?.dataSets else {
            return String(value)
        }
        
        let sliceVal = ((entry.plotData as? Double) ?? 0.0).isNaN ? 0.0 : (entry.plotData as? Double) ?? 0.0
        
        var totalSum = 0.0
        
        for dataset in datasets {
            
            for e in dataset.entriesForXValue(entry.x) {
                
                if e.y == entry.y {
                    let sliceVal = ((e.plotData as? Double) ?? 0.0).isNaN ? 0.0 : (e.plotData as? Double) ?? 0.0
                    totalSum += sliceVal
                }
            }
        }
        
        return totalSum == 0 ? String(value) : String(Double(round(10*(sliceVal / totalSum) * 100)/10)) + "%"
        
    }
}
