//
//  AxisValueFormatter.swift
//  zchart
//
//  Created by Aravinth T on 23/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class ValueFormatter : NSObject, IAxisValueFormatter, IValueFormatter {
    
    public func getFormattedTextforValue(value:Double, type: FieldType, data:AnyObject?) -> String {
        var finalData:AnyObject = value as AnyObject
        
        if self.fetchValueFromData {
            let data = data
            if data != nil {
                finalData = data!
            }
        }
        
        return formatValue(finalData: finalData)
//        switch(type)
//        {
//            case .x:
//                return String(value)
//                
//            case .y:
//                return String(value)
//        }
    }
    public func getFormattedTextforLabel(label: String, type: FieldType, data:AnyObject?) -> String {
        return label
    }
    
    public func getFormattedValue(stackSum: Double, entryX: Double) -> String {
        return String(stackSum)
    }
    
    
    weak var chartView:ChartViewBase? = nil
        
    open var formatter:Formatter? = nil
    
    open var fetchValueFromData:Bool = false
    
    public typealias DataLabelBlock = (
        _ value: Double,
        _ entry: ChartDataEntry,
        _ dataSetIndex: Int,
        _ viewPortHandler: ViewPortHandler?) -> String
    
    open var dataLabelblock: DataLabelBlock?
    
    public typealias AxisBlock = (
        _ value: Double,
        _ axis: AxisBase?) -> String
    
    open var axisblock: AxisBlock?
    
    public init(chart:ChartViewBase) {
        super.init()
        self.chartView = chart
    }
    
    public init(formatter: Formatter,chart:ChartViewBase) {
        super.init()
        self.formatter = formatter
        self.chartView = chart
    }
    
    //For axis data
    public func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        
        guard let axis = axis,
              let axisChart = chartView,
              let axisChartData = axisChart.data
            else { return " " }
        
        if axisblock != nil
        {
            return axisblock!(value, axis)
        }
        else
        {
            var finalData:AnyObject = value as AnyObject
            
            /*if self.fetchValueFromData {
                let data = chartView?.data?._dataSets[0].entryForIndex(Int(abs(Int(value)) % (chartView?.data?.dataSets[0].entryCount)!))?.data
                if data != nil {
                    finalData = data!
                }
            }*/
            
            if axis.scaleType == ScaleType.Ordinal // Handled Ordinal Data Type
            {
                if (axis.isKind(of: XAxis.self))
                {
                    guard let xString  = axisChartData.xString,
                          xString.count > 0
                        else { return " "}
                
                    finalData = xString[ChartUtils.doubleToIntSafeCast(value:value)%(xString.count)] as AnyObject
                    
                }
                else{
//                    let dependency = (axis as! YAxis).axisDependency
                    guard let axisIndex = (axis as? YAxis)?.axisIndex,
                          let yString = axisChartData.yString,
                          let stringArray = yString[axisIndex],
                          stringArray.count > 0
                        else { return " " }
                    
//                    let stringArray = (chartView?.data?.yString![dependency]!)!
//                    let stringArray = (chartView?.data?.yString![dependency]![axisIndex])!
                    
                    finalData = (stringArray[ChartUtils.doubleToIntSafeCast(value:abs(value))%(stringArray.count)]) as AnyObject
                    
                }
                
            }
            
            return self.formatValue(finalData: finalData)
        }
    }
    
    public func getFormattedValue(entry:ChartDataEntry) -> String {
        return entry.xString ?? ""
    }
    
    //TimeScale
    public func stringForValue(_ value: Double, axis: AxisBase?, intervalType: TimeScaleIntervalType) -> String {
        
//            let newVal = value / 1000 //To convert milliseconds to seconds
        
            let timeScale = (axis?.scaleTypeProtocol as! TimeScale)
        
            if timeScale.timeScaleType == TimeScaleType.Auto || self.formatter == nil {
               
                var dateFormatter:DateFormatter? = nil
                
                if dateFormatter == nil {
                     dateFormatter = DateFormatter()
                }else {
                    dateFormatter = (self.formatter as! DateFormatter)
                }
                
                //        dateFormatter.dateFormat = "dd MMM HH:mm"
                
                if dateFormatter?.dateFormat == "" {
                    
                    switch intervalType {
                        
                    case .YEAR:
                        dateFormatter?.dateFormat = "yyyy"
                    case .ABSQUARTER:
                        dateFormatter?.dateFormat = "qqq yyyy"
                    case .ABSMONTH:
                        dateFormatter?.dateFormat = "MMM yyyy"
                    case .ABSWEEK:
                        dateFormatter?.dateFormat = "w YYYY "
                    case .ABSDAY:
                        dateFormatter?.dateFormat = "eeee"
                    case .ABSHOUR:
                        dateFormatter?.dateFormat = "HH:mm:ss"
                    case .ABSMINUTE:
                        dateFormatter?.dateFormat = "HH:mm:ss"
                    case .ABSSECOND:
                        dateFormatter?.dateFormat = "HH:mm:ss"
                    case .ABSNANOSECOND:
                        dateFormatter?.dateFormat = "HH:mm:ss"
                    case .DATETIME:
                        dateFormatter?.dateFormat = "dd-MM-yyyy HH:mm:ss"
                    case .DATE:
                        dateFormatter?.dateFormat = "dd/MM/yyyy"
                        
                    }
                }
                
                if self.formatter == nil {
                    self.formatter = dateFormatter
                }
            }
        
          return formatValue(finalData: value as AnyObject)
    }
    
    fileprivate func formatValue(finalData:AnyObject)  -> String {
        
        var finalStringToReturn:String? = nil
        
        if self.formatter == nil {
            if finalData.isKind(of: NSNumber.self){
                
                let valueNumber = finalData as! Double
                finalStringToReturn = String(Double(round(10*valueNumber)/10)) 

                if (chartView?.plotTypes.contains(.Bar))!
                {
                    guard let barPlotOption = chartView?.getPlotOptions(type: .Bar) as? BarPlotOptions
                    else { return finalStringToReturn!}
                    if barPlotOption.stackedPercentEnabled
                    {
                        finalStringToReturn = finalStringToReturn! + "%"
                    }
                }
                
            }else {
                
                finalStringToReturn = (finalData as! String)
                
            }
        }
        
        if self.formatter != nil {
            
            if (self.formatter?.isKind(of: NumberFormatter.self))! {
                
                let numberFormatter = formatter as! NumberFormatter
                finalStringToReturn = numberFormatter.string(from: finalData as! NSNumber)!
                
            } else if (self.formatter?.isKind(of: DateFormatter.self))! {
                
                let dateFormatter = formatter as! DateFormatter
                
                let value = Double(String(describing: finalData))!
                let newVal = value / 1000 //To convert milliseconds to seconds
                let newData = NSNumber(value: newVal)
                
                let date = Date(timeIntervalSince1970: TimeInterval(newData))
//                let date = Date(timeIntervalSince1970: TimeInterval(finalData as! NSNumber))
                finalStringToReturn = dateFormatter.string(from: date)
                
            }
            else if (self.formatter?.isKind(of: SIUnitFormatter.self))! {
                
//                finalStringToReturn = (formatter?.string(for: finalData))!
                let siUnitFormatter = formatter as! SIUnitFormatter
                finalStringToReturn = siUnitFormatter.string(from: finalData as! NSNumber)!
            }
            
        }
        
        return finalStringToReturn!
    }
    
    public func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
        
        if dataLabelblock != nil
        {
            return dataLabelblock!(value, entry, dataSetIndex, viewPortHandler)
        }
        else
        {
            var finalData:AnyObject = value as AnyObject
            
            if self.fetchValueFromData {
                let data = entry.data
                if data != nil {
                    finalData = data!
                }
            }
            
            return formatValue(finalData: finalData)
        }
    }
}
