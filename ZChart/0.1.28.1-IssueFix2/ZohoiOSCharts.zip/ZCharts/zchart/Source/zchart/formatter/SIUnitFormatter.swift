//
//  SIUnitFormatter.swift
//  zchart
//
//  Created by Aravinth T on 23/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class SIUnitFormatter : NumberFormatter {
    
    /// Suffix to be appended after the values.
    ///
    /// **default**: suffix: ["", "k", "m", "b", "t"]
    public var suffix = ["", "K", "M", "B", "T"]
    
    /// An appendix text to be added at the end of the formatted value.
    public var appendix: String?
    
//    public init(appendix: String? = nil) {
//
//        super.init()
//        self.appendix = appendix
//    }
    
    public override init()
    {
        super.init()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
   /* open override func string(for obj: Any?) -> String? {
        
        let value = obj as! Double
        
        return self.format(value: value)
    }
    
    fileprivate func format(value: Double) -> String {
        
        var sig = value
        var length = 0
        let maxLength = suffix.count - 1
        
        while sig >= 1000.0 && length < maxLength {
            sig /= 1000.0
            length += 1
        }
        
        let tempString = String(format: "%g", sig)
        let tempDouble = Double(tempString)
    
        self.positiveSuffix = suffix[length]
        self.negativeSuffix = suffix[length]
  
        let r = super.string(from: tempDouble! as NSNumber)
        
//       var r = String(format: "%2.f", sig) + suffix[length]

//        var r = String(format: "%g", sig) + suffix[length]
        
        if let appendix = appendix {
            //r += appendix
        }
        
        return r!
    }
    */
    
    open override func string(from number: NSNumber) -> String? {
        
        var sig = Double(number)
        var length = 0
        let maxLength = suffix.count - 1
        
        while (sig <= -1000.0 || sig >= 1000.0) && length < maxLength {
            sig /= 1000.0
            length += 1
        }
        
        let tempString = String(format: "%g", sig)
        let tempDouble = Double(tempString)

        self.positiveSuffix = suffix[length]
        self.negativeSuffix = suffix[length]
        
        let r = super.string(from: tempDouble! as NSNumber)
        
        return r!
    }
  
}
