//
//  ICenterTextFormatter.swift
//  Charts
//
//  Created by Mohammed Musthafa A K on 21/07/17.
//
//

#if !os(OSX)
    import UIKit
#endif

public protocol ICenterTextFormatter : NSObjectProtocol
{
    func stringForValue(highlightedEntry: ChartDataEntry, chart: ChartViewBase) -> String
}
