//
//  BarLabelValueFormatter.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 06/10/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif


public class BarLabelValueFormatter:NSObject, IAxisValueFormatter
{
    
    let chartView:ChartViewBase?
    

    public init(chart:ChartViewBase)
    {
        self.chartView = chart
    }
    
   public func stringForValue(_ value: Double,axis: AxisBase?) -> String
    {
        var replaceString:String = ""
        
        if axis?.scaleType == ScaleType.Ordinal
        {
                if (axis?.isKind(of: XAxis.self))!
                {
                    replaceString = (chartView?.data?.xString![ChartUtils.doubleToIntSafeCast(value:value)%(chartView?.data?.xString!.count)!])!
                    
                }
                else{
//                    let dependency = (axis as! YAxis).axisDependency
                    let axisChart = chartView!
                    let axisIndex = axisChart.getAxisIndex(axis: axis as! YAxis)!
                    
//                    let stringArray = (chartView?.data?.yString![dependency]![axisIndex]!)!
                    let stringArray = (chartView?.data?.yString![axisIndex]!)!
                    replaceString = (stringArray[ChartUtils.doubleToIntSafeCast(value:abs(value))%(stringArray.count)])
                   
                }
        }
        else{
            replaceString = String(describing: value)

        }
        
        return replaceString
    }
    
}
