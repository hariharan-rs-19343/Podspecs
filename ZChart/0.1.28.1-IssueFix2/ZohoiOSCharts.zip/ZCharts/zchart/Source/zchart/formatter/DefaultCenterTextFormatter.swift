//
//  DefaultCenterTextFormatter.swift
//  Charts
//
//  Created by Mohammed Musthafa A K on 21/07/17.
//
//

#if !os(OSX)
    import UIKit
#endif

public class DefaultCenterTextFormatter : NSObject, ICenterTextFormatter
{
    public func stringForValue(highlightedEntry: ChartDataEntry, chart: ChartViewBase) -> String {
        
        
        let pieChart = chart
        
        for set in pieChart.data!.dataSets
        {
            if set.isVisible && set.entryCount > 0
            {
       
                let entryCount = set.entryCount
                
                let dataSet = pieChart.data?.dataSets[0]
                
                var sum = 0.0
                
                var count = 0.0
                
                for j in 0 ..< entryCount
                {
                    let chartEntry = dataSet?.entryForIndex(j)
                    
                    if (chartEntry?.y.isNaN)!
                    {
                        continue
                    }
                    
                    if (chartEntry?.enabled)!
                    {
                        count += 1
                        sum += (chartEntry?.y)!
                    }
                    
                }
                
                var slicePercent = 0.0
                slicePercent = ( highlightedEntry.y/sum ) * 100.0
                
                return String(format:"%.1f", (slicePercent)) + " %"
              
            }
                    
        }
        
        return " "
        
    }
}
