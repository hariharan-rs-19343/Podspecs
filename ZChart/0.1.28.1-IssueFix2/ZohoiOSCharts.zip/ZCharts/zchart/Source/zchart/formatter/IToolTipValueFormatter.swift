//
//  IToolTipValueFormatter.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public protocol IToolTipValueFormatter : NSObjectProtocol
{
    func stringForValue(value: String) -> String
}
