//
//  DefaultToolTipValueFormatter.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class DefaultToolTipValueFormatter : NSObject, IToolTipValueFormatter
{
   public func stringForValue(value: String) -> String {
        return value
    }
}
