//
//  ContainerLayout.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
import UIKit
#endif

public class ContainerLayout: NSObject {
    
    public static func activateConstraintsForTitleView(titleView: TitleView)
    {
        let leadingAnchor = titleView.leadingAnchor
        let trailingAnchor = titleView.trailingAnchor
        let topAnchor = titleView.topAnchor
        let heightAnchor = titleView.heightAnchor
        let widthAnchor = titleView.widthAnchor
        let centerXAnchor = titleView.centerXAnchor
        
        let mainTitle = titleView.mainTitle
        let subTitle = titleView.subTitle
        let lineView = titleView.lineDesign
        
        var mainTitleHeightFactor:CGFloat = 0.58
        var subTitleHeightFactor:CGFloat = 0.38
        var lineHeightFactor:CGFloat = 0.04
        
        if !mainTitle.enable{
            subTitleHeightFactor = subTitleHeightFactor + mainTitleHeightFactor
            mainTitleHeightFactor = 0.0
        }
        
        if !subTitle.enable {
            mainTitleHeightFactor = mainTitleHeightFactor + subTitleHeightFactor
            subTitleHeightFactor = 0.0
        }
        
        if !titleView.showView {
            lineHeightFactor = 0.0
        }
        
        //Title
        let mainTitleCenterxAnchor = mainTitle.centerXAnchor.constraint(equalTo: centerXAnchor)
        let mainTitleTopAnchor = mainTitle.topAnchor.constraint(equalTo: topAnchor)
        let mainTitleHeightAnchor = mainTitle.heightAnchor.constraint(equalTo: heightAnchor, multiplier: mainTitleHeightFactor)
        let mainTitleWidthAnchor = mainTitle.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.90)
        
        
        
        //Legend
        let subTitleCenterXAnchor = subTitle.centerXAnchor.constraint(equalTo: centerXAnchor)
        let subTitleTopAnchor = subTitle.topAnchor.constraint(equalTo: mainTitle.bottomAnchor)
        let subTitleHeightAnchor = subTitle.heightAnchor.constraint(equalTo: heightAnchor, multiplier: subTitleHeightFactor)
        let subTitleWidthAnchor = subTitle.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.90)
        
        // Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let lineTopAnchor = lineView.topAnchor.constraint(equalTo: subTitle.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineHeightFactor)
        
        
        
        if titleView.oldConstraints.count > 0 {
            NSLayoutConstraint.deactivate(titleView.oldConstraints)
            //titleView.removeConstraints(titleView.oldConstraints)
        }
        
        titleView.oldConstraints = [ mainTitleWidthAnchor,mainTitleCenterxAnchor, mainTitleTopAnchor, mainTitleHeightAnchor,
                                     subTitleWidthAnchor, subTitleCenterXAnchor, subTitleTopAnchor, subTitleHeightAnchor,
                                     lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor]
        
        //titleView.addConstraints(titleView.oldConstraints)
        NSLayoutConstraint.activate(titleView.oldConstraints)
        
    }
    
  /*  static func constraintsForHorizontalLegendLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
        
        let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = containerView.widthAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        var legendViewHeightFactor:CGFloat = 0.15
        var legendViewWidthFactor:CGFloat = 0.4
        
        if !legendView.showView {
             legendViewWidthFactor = 0.0
             legendViewHeightFactor = 0.0
        }
        else if legendView.position == .left || legendView.position == .right
        {
            legendViewHeightFactor = totalHeightPercent
        }
        else
        {
           totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        }
        
        
        var lineViewHeightFactor:CGFloat = 0.02
        if !legendView.showView {
                lineViewHeightFactor = 0.0
        }
        
        if legendView.position == .left || legendView.position == .right
        {
             lineViewHeightFactor = 0.0
        }
        else
        {
            totalHeightPercent = totalHeightPercent - lineViewHeightFactor
        }

        
       
        
        var tooltipViewHeightFactor:CGFloat = 0.74
        var tooltipViewWidthFactor:CGFloat = 0.5
        
        
        
        if !toolTipView.showView {
            tooltipViewHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        else if legendView.position == .left || legendView.position == .right
        {
            tooltipViewHeightFactor = 0.15
            tooltipViewWidthFactor = 0.6
            totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
            totalWidthPercent = tooltipViewWidthFactor
        }
        else
        {
            tooltipViewHeightFactor = totalHeightPercent
            totalWidthPercent = totalWidthPercent - tooltipViewWidthFactor
        }
        
        
        var chartViewHeightFactor:CGFloat = 0.74
        var chartViewWidthFactor:CGFloat = 0.5
        
        if legendView.position == .left || legendView.position == .right
        {
            chartViewHeightFactor = 0.74
            chartViewWidthFactor = 0.6
        }

        
        if !chartView.showView {
            chartViewHeightFactor = 0.0
        }else {
            chartViewHeightFactor = totalHeightPercent
            chartViewWidthFactor = totalWidthPercent
            
        }
        
        totalHeightPercent = totalHeightPercent - chartViewHeightFactor
        totalWidthPercent = totalWidthPercent - chartViewWidthFactor
     
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        
        //Legend
        var legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)

        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
        var tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        let tooltipWidthAnchor = toolTipView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: tooltipViewWidthFactor)
        
        
        //Chart
        var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
        var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var chartTopAnchor = chartView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: chartViewWidthFactor)
        
        let centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        let widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        var heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 3/3 )
      
        
        
        //TooltipContentView
        let toolTipContentViewCenterX = toolTipView.contentView.centerXAnchor.constraint(equalTo: toolTipView.centerXAnchor)
        let toolTipContentViewCenterY = toolTipView.contentView.centerYAnchor.constraint(equalTo: toolTipView.centerYAnchor)
        let toolTipContentViewHeight  = toolTipView.contentView.heightAnchor.constraint(equalTo: toolTipView.heightAnchor, multiplier: 2/3)
        
        let toolTipContentViewWidth  = toolTipView.contentView.widthAnchor.constraint(equalTo: toolTipView.widthAnchor, multiplier: (85/100))
        
        
        if legendView.position == .bottom
        {
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            chartTopAnchor = chartView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        }
        else if legendView.position == .left
        {
            
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: toolTipView.leadingAnchor)
            
            tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
            tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
            chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            
            heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/5 )
            
        }
        else if legendView.position == .right
        {
            tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
            tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
            chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
            
            heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/5 )
            
        }
        
        
        var allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,tooltipWidthAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor, chartWidthAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
             centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
             toolTipContentViewCenterX,toolTipContentViewCenterY,toolTipContentViewHeight,toolTipContentViewWidth]
        
        if legendView.position == .left || legendView.position == .right
        {
            allConstraints =
                [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
                 legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor, legendWidthAnchor,
                 tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,
                 chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor,
                 centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
                 toolTipContentViewCenterX,toolTipContentViewCenterY,toolTipContentViewHeight,toolTipContentViewWidth]
        }
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    } */
#if !os(OSX)
    public static func constraintsForHorizontalLegendLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
//        let emptyView = containerView.emptyViewToAddScroll
         let drillDownView = containerView.drillDownView
        
       /* let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = containerView.widthAnchor */
        
        
        let heightAnchor = containerView.heightAnchor
        
        let scrollContentView = containerView//.scrollContentView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
        
//        let centerXAnchor = scrollContentView.centerXAnchor
        let widthAnchor = scrollContentView.widthAnchor
//        let bottomAnchor = scrollContentView.bottomAnchor

        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
//        var legendViewHeightFactor:CGFloat = 0.15
        
        containerView.legendHeightFactor = 0.15
        
        var legendViewWidthFactor:CGFloat = 0.4
        
        if !legendView.showView {
            legendViewWidthFactor = 0.0
//            legendViewHeightFactor = 0.0
            containerView.legendHeightFactor = 0.0
        }
        else if legendView.position == .left || legendView.position == .right
        {
//            legendViewHeightFactor = totalHeightPercent
            containerView.legendHeightFactor = totalHeightPercent
        }
        else
        {
//            totalHeightPercent = totalHeightPercent - legendViewHeightFactor
            totalHeightPercent = totalHeightPercent - containerView.legendHeightFactor!
        }
        
        
        var lineViewHeightFactor:CGFloat = 0.02
        if !legendView.showView || !(lineView.showView) {
            lineViewHeightFactor = 0.0
        }
        
        if legendView.position == .left || legendView.position == .right
        {
            lineViewHeightFactor = 0.0
        }
        else
        {
            totalHeightPercent = totalHeightPercent - lineViewHeightFactor
        }
        
        
        
        
//        var tooltipViewHeightFactor:CGFloat = 0.74
        containerView.tooltipHeightFactor = 0.74
        var tooltipViewWidthFactor:CGFloat = 0.5
        
        
        
        if !toolTipView.showView {
//            tooltipViewHeightFactor = 0.0
            containerView.tooltipHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        else if legendView.position == .left || legendView.position == .right
        {
//            tooltipViewHeightFactor = 0.15
             containerView.tooltipHeightFactor = 0.15
            tooltipViewWidthFactor = 0.6
//            totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
            totalHeightPercent = totalHeightPercent - containerView.tooltipHeightFactor!
            totalWidthPercent = tooltipViewWidthFactor
        }
        else
        {
//            tooltipViewHeightFactor = totalHeightPercent
            containerView.tooltipHeightFactor = totalHeightPercent
            totalWidthPercent = totalWidthPercent - tooltipViewWidthFactor
        }
        
        
//        var chartViewHeightFactor:CGFloat = 0.74
        
        containerView.chartHeightFactor = 0.74
        
        var chartViewWidthFactor:CGFloat = 0.5
        
        if legendView.position == .left || legendView.position == .right
        {
//            chartViewHeightFactor = 0.74
            containerView.chartHeightFactor = 0.74
            chartViewWidthFactor = 0.6
        }
        
        
        if !chartView.showView {
//            chartViewHeightFactor = 0.0
            containerView.chartHeightFactor = 0.0
        }else {
//            chartViewHeightFactor = totalHeightPercent
            containerView.chartHeightFactor = totalHeightPercent
            chartViewWidthFactor = totalWidthPercent
        }
        
        if containerView.drillDownHeightFactor > 0
        {
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
            
        }
        else
        {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
//       totalHeightPercent = totalHeightPercent - chartViewHeightFactor
        totalHeightPercent = totalHeightPercent - containerView.chartHeightFactor!
        totalWidthPercent = totalWidthPercent - chartViewWidthFactor
        
        
        
        Log.debug("Landscape :: Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend H d W \(containerView.legendHeightFactor!)  \(legendViewWidthFactor) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!) Chart Width \(chartViewWidthFactor)")
        
         NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        //DrillFilter
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        
        //Legend
        var legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
//        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
    
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)
        
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
        var tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
//        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier:  containerView.tooltipHeightFactor!)

        let tooltipWidthAnchor = toolTipView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: tooltipViewWidthFactor)
        
        
        
        //Chart
        var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
        var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var chartTopAnchor = chartView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
//        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        
        let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: chartViewWidthFactor)
        
        var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        var heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 3/3 )
        
        if legendView.type == .continous {
            centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
            centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
            widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
            heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/2)
        }
        
        
        //TooltipContentView
        let toolTipContentViewCenterX = toolTipView.contentView.centerXAnchor.constraint(equalTo: toolTipView.centerXAnchor)
        let toolTipContentViewCenterY = toolTipView.contentView.centerYAnchor.constraint(equalTo: toolTipView.centerYAnchor)
        let toolTipContentViewHeight  = toolTipView.contentView.heightAnchor.constraint(equalTo: toolTipView.heightAnchor, multiplier: 2/3)
        
        let toolTipContentViewWidth  = toolTipView.contentView.widthAnchor.constraint(equalTo: toolTipView.widthAnchor, multiplier: (85/100))
        
        
        if legendView.position == .bottom
        {
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
            chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
            lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        }
        else if legendView.position == .left
        {
            
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: toolTipView.leadingAnchor)
            
            tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
            tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
            
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
            chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            
            heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/5 )
            
        }
        else if legendView.position == .right
        {
            tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
            tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
            chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
            
            heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/5 )
            
        }
        
        
        
        var allConstraints:[NSLayoutConstraint] =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor ,tooltipWidthAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor, chartWidthAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
             centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
             toolTipContentViewCenterX,toolTipContentViewCenterY,toolTipContentViewHeight,toolTipContentViewWidth]
        
        if legendView.position == .left || legendView.position == .right
        {
            allConstraints =
                [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
                 legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor, legendWidthAnchor,
                 tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor ,
                 chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor,
                 centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
                 toolTipContentViewCenterX,toolTipContentViewCenterY,toolTipContentViewHeight,toolTipContentViewWidth]
        }
        
        
      /*  let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
        var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
        let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
        
        
        if legendView.position == .bottom
        {
        }
        else
        {
            emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
        }
        
        let emptyViewConstraints = [emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor]
        
        allConstraints.append(contentsOf: emptyViewConstraints) */
        
        allConstraints.append(contentsOf: [ drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor])
        
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    }

/*
    static func constraintsForHorizontalLegendPortrait(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
     
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
        let emptyView = containerView.emptyViewToAddScroll
        
        /*let leadingAnchor = containerView.leadingAnchor
         let trailingAnchor = containerView.trailingAnchor
         let topAnchor = containerView.topAnchor
         let heightAnchor = containerView.heightAnchor*/
        
        let heightAnchor = containerView.heightAnchor
        
        let scrollContentView = containerView.scrollContentView

        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
        
        let centerXAnchor = scrollContentView.centerXAnchor
        let widthAnchor = scrollContentView.widthAnchor
        let bottomAnchor = scrollContentView.bottomAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        var legendViewHeightFactor:CGFloat = 0.08
        if !legendView.showView {
            legendViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        
        
        var lineViewHeightFactor:CGFloat = 0.02
        if !legendView.showView {
            lineViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor
        
        
        var tooltipViewHeightFactor:CGFloat = 0.15
        
        if !toolTipView.showView {
            tooltipViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        
        var chartViewHeightFactor:CGFloat = 0.63
        if !chartView.showView {
            chartViewHeightFactor = 0.0
        }else {
            chartViewHeightFactor = totalHeightPercent
        }
        
        totalHeightPercent = totalHeightPercent - chartViewHeightFactor

     
        var constraints:[NSLayoutConstraint] = []
        
        //Title
//        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
//        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleCenterXAnchor = titleView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let titleWidthAnchor = titleView.widthAnchor.constraint(equalTo: widthAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        
        //Legend
//        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
//        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let legendCenterXAnchor = legendView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        
        //Line
//        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
//        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        
        let lineCenterXAnchor = lineView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let lineWidthAnchor = lineView.widthAnchor.constraint(equalTo: widthAnchor)
        var lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
//        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
//        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        
        let tooltipCenterXAnchor = toolTipView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let tooltipWidthAnchor = toolTipView.widthAnchor.constraint(equalTo: widthAnchor)
        
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        
        
        //Chart
        
//        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
//        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        
        let chartCenterXAnchor = chartView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor)
        
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        
        if legendView.position == .bottom
        {
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        }
        
        
        let centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        let widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        let heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
        
        
        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
     /*   let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
             centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
             toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom ] */
        
        let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
        var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
        let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
        
        
        if legendView.position == .bottom
        {
            //            let legendBottomAnchor = legendView.bottomAnchor.constraint(equalTo: bottomAnchor)
            //            allConstraints.append(legendBottomAnchor)
        }
        else
        {
            //            let chartBottomAnchor = chartView.bottomAnchor.constraint(equalTo: bottomAnchor)
            //             allConstraints.append(chartBottomAnchor)
            emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            
        }
        
        let allConstraints =
            [titleCenterXAnchor, titleWidthAnchor, titleTopAnchor, titleHeightAnchor,
             legendCenterXAnchor, legendWidthAnchor, legendTopAnchor, legendHeightAnchor,
             tooltipCenterXAnchor, tooltipWidthAnchor, tooltipTopAnchor, tooltipHeightAnchor,
             chartCenterXAnchor, chartWidthAnchor, chartTopAnchor, chartHeightAnchor,
             lineCenterXAnchor, lineWidthAnchor, lineTopAnchor, lineHeightAnchor,
             centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
             toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
             emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor
             ]
        
     
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    }
*/
    
    public static func constraintsForHorizontalLegendPortrait(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        Log.info("In Contianer Layout")
        
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
//        let emptyView = containerView.emptyViewToAddScroll
        let drillDownView = containerView.drillDownView
        
        /*let leadingAnchor = containerView.leadingAnchor
         let trailingAnchor = containerView.trailingAnchor
         let topAnchor = containerView.topAnchor
         let heightAnchor = containerView.heightAnchor*/
        
        let heightAnchor = containerView.heightAnchor
        
        let scrollContentView = containerView//.scrollContentView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
        
//        let centerXAnchor = scrollContentView.centerXAnchor
//        let widthAnchor = scrollContentView.widthAnchor
//        let bottomAnchor = scrollContentView.bottomAnchor
        
        var totalHeightPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
//        var legendViewHeightFactor:CGFloat = 0.08
//        legendViewHeightFactor = 0.20
        
        containerView.legendHeightFactor = 0.08
        
        if !legendView.showView {
//            legendViewHeightFactor = 0.0
            containerView.legendHeightFactor = 0.0
        }
//        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        totalHeightPercent = totalHeightPercent - containerView.legendHeightFactor!
        
        
        var lineViewHeightFactor:CGFloat = 0.02
                if !legendView.showView || !(lineView.showView) {
                   lineViewHeightFactor = 0.0
               }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor
        
        
//        var tooltipViewHeightFactor:CGFloat = 0.15
        containerView.tooltipHeightFactor = 0.19

        if !toolTipView.showView {
//            tooltipViewHeightFactor = 0.0
            containerView.tooltipHeightFactor = 0.0
        }
//        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        totalHeightPercent = totalHeightPercent - containerView.tooltipHeightFactor!
        
        containerView.chartHeightFactor = 0.63
//        containerView.chartHeightFactor = 0.51
//        var chartViewHeightFactor:CGFloat = 0.63
        if !chartView.showView {
//            chartViewHeightFactor = 0.0
            containerView.chartHeightFactor = 0.0
        }else {
//            chartViewHeightFactor = totalHeightPercent
             containerView.chartHeightFactor = totalHeightPercent
        }
        
        if containerView.drillDownHeightFactor > 0
        {
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
            
        }
        else
        {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
        totalHeightPercent = totalHeightPercent - containerView.chartHeightFactor!
        
        Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
        
         NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
//        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
       
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
        
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
//        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
         containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
        
        
        //DrillFilter
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        //Chart
        
        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
//        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
//        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        
        
        if legendView.position == .bottom
        {
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        }

        
        var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        var heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 2/3 )
        
        if legendView.type == .continous {
            centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
            centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
            widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
            heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1)
        }
        
        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor,   containerView.legendViewHeightAnchor, //legendHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor, // tooltipHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor,// chartHeightAnchor,
                containerView.chartViewHeightAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
              centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
              toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
              drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor]
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
      /*  let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
        var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
        let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
        
        
        if legendView.position == .bottom
        {
        }
        else
        {
            emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
        }
        
        let emptyViewConstraints = [emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor]

         constraints.append(contentsOf: emptyViewConstraints) */
        
        
        return constraints
    }
    
    
    public static func constraintsForVerticalLegendPortrait(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        Log.info("Contianer Layout : Vertical Legend , Portrait Mode")
        
        let titleView = containerView.titleView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let legendView = containerView.legendView
         let lineView = containerView.lineView
//        let emptyView = containerView.emptyViewToAddScroll
        let drillDownView = containerView.drillDownView
        
        /*let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor*/
        
        
        let heightAnchor = containerView.heightAnchor
        
        let scrollContentView = containerView//.scrollContentView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
//        let centerXAnchor = scrollContentView.centerXAnchor
//        let widthAnchor = scrollContentView.widthAnchor
//        let bottomAnchor = scrollContentView.bottomAnchor

        
        
        var totalHeightPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        
//        var tooltipViewHeightFactor:CGFloat = 0.10
        containerView.tooltipHeightFactor = 0.10
        if !toolTipView.showView {
//            tooltipViewHeightFactor = 0.0
            containerView.tooltipHeightFactor = 0.0
        }
        
//        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        totalHeightPercent = totalHeightPercent - containerView.tooltipHeightFactor!
        
//        var legendViewHeightFactor:CGFloat = 0.24
        containerView.legendHeightFactor = 0.24
        if !legendView.showView {
//            legendViewHeightFactor = 0.0
            containerView.legendHeightFactor = 0.0
        }
//        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        totalHeightPercent = totalHeightPercent - containerView.legendHeightFactor!
        
        var lineViewHeightFactor:CGFloat = 0.02
               if !legendView.showView || !(lineView.showView){
                    lineViewHeightFactor = 0.0
                }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor

        
        //var chartViewHeightFactor:CGFloat = 0.5
//        let chartViewHeightFactor = totalHeightPercent
        containerView.chartHeightFactor = totalHeightPercent
        
        if containerView.drillDownHeightFactor > 0
        {
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
            
        }
        else
        {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
        Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
        
        NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
        
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
//        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
      containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
        
        
        //DrilFilter
        
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        
        //Chart
        
        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
//        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
//        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
//        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
        
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        if legendView.position == .top
        {
            legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            
            lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
            
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        }
        
        let centerXLegendCollection = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegendCollection = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        var widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 2/3)
        if (legendView.legend.legendRenderType == .zigzag) {
            widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/3)
        }
        let heightLegendCollection = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor)

        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 10)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
              centerXLegendCollection!, centerYLegendCollection!, widthLegendCollection!, heightLegendCollection!,
              toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
              drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor]
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
     /*   let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
        var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
        let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
        
        
        if legendView.position == .bottom
        {
        }
        else
        {
            emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
        }
        
        let emptyViewConstraints = [emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor]
        
        constraints.append(contentsOf: emptyViewConstraints) */

        
        
        return constraints
    }
    
    public static func constraintsForVerticalLegendLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        Log.info("Contianer Layout : Vertical Legend , Landscape Mode")
        
        let titleView = containerView.titleView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let legendView = containerView.legendView
//        let emptyView = containerView.emptyViewToAddScroll
        let drillDownView = containerView.drillDownView
        
        /*let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = containerView.widthAnchor */
        
        
        let heightAnchor = containerView.heightAnchor
        
        let scrollContentView = containerView//.scrollContentView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
//        let centerXAnchor = scrollContentView.centerXAnchor
        let widthAnchor = scrollContentView.widthAnchor
//        let bottomAnchor = scrollContentView.bottomAnchor

        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.15
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        
        //var legendViewHeightFactor:CGFloat = 0.85
//        var legendViewHeightFactor:CGFloat = totalHeightPercent
        containerView.legendHeightFactor = totalHeightPercent
        var legendViewWidthFactor:CGFloat = 0.4
        if !legendView.showView {
//            legendViewHeightFactor = 0.0
            containerView.legendHeightFactor = 0.0
            legendViewWidthFactor = 0.0
        }
        //totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        totalWidthPercent = totalWidthPercent - legendViewWidthFactor
        
        
//        var tooltipViewHeightFactor:CGFloat = 0.15
         containerView.tooltipHeightFactor = 0.15
        var tooltipViewWidthFactor:CGFloat = 0.6
        if !toolTipView.showView {
//            tooltipViewHeightFactor = 0.0
              containerView.tooltipHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        
//        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
       totalHeightPercent = totalHeightPercent -  containerView.tooltipHeightFactor!
       
        
        //var chartViewHeightFactor:CGFloat = 0.75, chartViewWidthFactor = 0.6
//        let chartViewHeightFactor = totalHeightPercent
        containerView.chartHeightFactor = totalHeightPercent
        let chartViewWidthFactor = totalWidthPercent
        
        if containerView.drillDownHeightFactor > 0
        {
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
            
        }
        else
        {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
        Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
        Log.debug("Legend Height \(containerView.legendHeightFactor!) Width \(legendViewWidthFactor)")
        Log.debug("Tooltip Height \(containerView.tooltipHeightFactor!) Width \(tooltipViewWidthFactor)")
        Log.debug("Chart Height \(containerView.chartHeightFactor!)  Width \(chartViewWidthFactor )")
        
        NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
        
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        //DrilFilter
        
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        
        
        //Legend
        var legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: toolTipView.leadingAnchor)
        let legendTopAnchor = legendView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
//        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)
        
        
        //Tooltip
        var tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
        var tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
//        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
        
        // let tooltipWidthAnchor = toolTipView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: tooltipViewWidthFactor)
        
        
        
        //Chart
        var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
        var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
//        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        // let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: chartViewWidthFactor)
        
        
        if legendView.position == .right
        {
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
            tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
        }
        
        let topLegendCollection = legendView.collectionView?.topAnchor.constraint(equalTo: legendView.topAnchor, constant: 20)
        let centerXLegendCollection = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegendCollection = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        var widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 2/3)
        if (legendView.legend.legendRenderType == .zigzag) {
            widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/3)
        }
        let heightLegendCollection = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor)

        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 5)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor, constant: -5)
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor, legendWidthAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor,
             centerXLegendCollection!, centerYLegendCollection!, widthLegendCollection!, heightLegendCollection!,topLegendCollection!,
               toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
                drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor]
        
        constraints.append(contentsOf:  allConstraints)
        
        
    /*    let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
        let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
        var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
        let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
        
        
        if legendView.position == .bottom
        {
        }
        else
        {
            emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
        }
        
        let emptyViewConstraints = [emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor]
        
        constraints.append(contentsOf: emptyViewConstraints) */

        
        return constraints
    }
    
    public static func constraintsForPortraitAxisChart(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        Log.info("In Contianer Layout::Portrait::AxisChart ")
        
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
        let overview = containerView.overviewView
       
        let drillDownView = containerView.drillDownView
        
        
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = containerView.widthAnchor
        
        let scrollContentView = containerView//.scrollContentView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
//        containerView.legendHeightFactor = 0.08
//        containerView.legendHeightFactor = 0.15
        
        containerView.legendHeightFactor = 0.08
        
        if containerView.legendToolTipToggleEnabled
        {
            containerView.legendHeightFactor = 0.15
        }
        
        if !containerView.isPortraitOrientation()
        {
          containerView.legendHeightFactor = 0.14
        }
        
        if !legendView.showView {
            containerView.legendHeightFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent - containerView.legendHeightFactor!
        
        
        var lineViewHeightFactor:CGFloat = 0.02
        if !legendView.showView || !(lineView.showView)  {
            lineViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor
        
        containerView.tooltipHeightFactor = 0.19
        
        if !toolTipView.showView {
            containerView.tooltipHeightFactor = 0.0
        }

        totalHeightPercent = totalHeightPercent - containerView.tooltipHeightFactor!
        
        var overviewWidthFactor = totalWidthPercent
        
        if overview.showView {
            
            if overview.position == .bottom {
                if let overviewHeightFactor = containerView.overviewHeightFactor{
                    totalHeightPercent -= overviewHeightFactor
                }
            }
            else {
                if let widthFactor = containerView.overviewWidthFactor {
                    totalWidthPercent -= widthFactor
                    overviewWidthFactor = widthFactor
                }
            }
            
            containerView.overviewHeightFactor = 0.08
        }
        else {
            containerView.overviewHeightFactor = 0.0
            overviewWidthFactor = 0.0
        }
        
        containerView.chartHeightFactor = 0.63
        
        if !chartView.showView {
            containerView.chartHeightFactor = 0.0
        }else {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
        
        if containerView.drillDownHeightFactor > 0
        {
            
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.tooltipViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.tooltipHeightFactor = containerView.tooltipHeightFactor! - containerView.drillDownHeightFactor
            
        }
      
        
        totalHeightPercent = totalHeightPercent - containerView.chartHeightFactor!
        
        Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
        
        NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor,containerView.legendViewHeightAnchor,containerView.overviewHeightAnchor])
    
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
        
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
        
        //DrillFilter
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        //overview
        var overviewLeadingAnchor = overview.leadingAnchor.constraint(equalTo: leadingAnchor)
        var overviewTrailingAnchor = overview.trailingAnchor.constraint(equalTo: trailingAnchor)
        var overviewTopAnchor = overview.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        containerView.overviewHeightAnchor = overview.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.overviewHeightFactor!)
        
        
        //Chart
        
        var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        
        if overview.position != .bottom {
            
            if overview.position == .left {
                overviewTrailingAnchor = overview.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
                
                chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: overview.trailingAnchor)
            }
            
            if overview.position == .right {
                overviewLeadingAnchor = overview.leadingAnchor.constraint(equalTo: chartView.trailingAnchor)
                
                chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: overview.leadingAnchor)
            }
            
            overviewTopAnchor = overview.topAnchor.constraint(equalTo: chartView.topAnchor)
            
            containerView.overviewHeightAnchor = overview.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        }
        
        if legendView.position == .bottom && !containerView.legendToolTipToggleEnabled
        {
            tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
            lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            legendTopAnchor = legendView.topAnchor.constraint(equalTo: overview.bottomAnchor)
        }
        
        
        var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
//        var heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/3)
        
        var  heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 2/3 )
        
        //        heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
        
        if containerView.legendToolTipToggleEnabled
        {
            heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/2)
        }
        
        if containerView.currentOrientation == .Landscape
        {
         heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
        }
        
        if legendView.type == .continous {
            centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
            centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
            widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
            heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/2)
        }
        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        var allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor,   containerView.legendViewHeightAnchor, //legendHeightAnchor,
                tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor, //tooltipHeightAnchor,
                chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor,// chartHeightAnchor,
                containerView.chartViewHeightAnchor,
                lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
                centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
                toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
             drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor, overviewLeadingAnchor, overviewTrailingAnchor, overviewTopAnchor, containerView.overviewHeightAnchor]
        
        if overview.position == .left || overview.position == .right {
            
            let overviewWidthAnchor = overview.widthAnchor.constraint(equalTo: widthAnchor, multiplier: overviewWidthFactor)
            
            allConstraints.append(overviewWidthAnchor)
        }
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
        
        return constraints
    }

    public static func constraintsForColorAxisLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        Log.info("Contianer Layout : Vertical Legend , Landscape Mode")
        
        let titleView = containerView.titleView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let legendView = containerView.legendView
        let drillDownView = containerView.drillDownView
        
        
        let scrollContentView = containerView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = scrollContentView.widthAnchor
        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.15
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        
        containerView.tooltipHeightFactor = 0.19
        var tooltipViewWidthFactor:CGFloat = 1
        if !toolTipView.showView {
            containerView.tooltipHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent -  containerView.tooltipHeightFactor!
        
        
        containerView.legendHeightFactor = totalHeightPercent
        
        var legendViewWidthFactor:CGFloat = legendView.position == .left || legendView.position == .right ? 0.2 : 1.0
        
        var legendViewHeightFactor:CGFloat = 0.14
        
        if !legendView.showView {
            containerView.legendHeightFactor = 0.0
            legendViewWidthFactor = 0.0
            legendViewHeightFactor = 0.0
        }
        
        if legendView.position == .left || legendView.position == .right {
            
            totalWidthPercent = totalWidthPercent - legendViewWidthFactor
            
        }
        else {
            if containerView.legendHeightFactor != 0 {
                containerView.legendHeightFactor = legendViewHeightFactor
            }
            totalHeightPercent -= legendViewHeightFactor
        }
        
        
     
        
        containerView.chartHeightFactor = totalHeightPercent
        let chartViewWidthFactor = totalWidthPercent
        
        if containerView.drillDownHeightFactor > 0
        {
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
            
        }
        else
        {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
        Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
        Log.debug("Legend Height \(containerView.legendHeightFactor!) Width \(legendViewWidthFactor)")
        Log.debug("Tooltip Height \(containerView.tooltipHeightFactor!) Width \(tooltipViewWidthFactor)")
        Log.debug("Chart Height \(containerView.chartHeightFactor!)  Width \(chartViewWidthFactor )")
        
        NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
        
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
        
        //DrilFilter
        
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        //Legend
        var legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)
        
        
      
        
        
        //Chart
        var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
        var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        
        
        
        if legendView.position == .right
        {
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: chartView.trailingAnchor)
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
        }
        
        var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        var  heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
        
        if legendView.type == .continous {
            centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
            centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
            widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
            heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 0.8)
        }
        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        var toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 5)
        var toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor, constant: -5)
        
        if legendView.position == .top || legendView.position == .bottom {
            
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            if legendView.position == .top {
                
                legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
                
                tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
            }
            else {
                
                tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
                
                legendTopAnchor = legendView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            }
            
            if legendView.type == .continous {
                centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
                centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
                widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
                heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1)
            }
            
            toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
            toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        }
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor, legendWidthAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor,
                centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
                toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
                drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor]
        
        constraints.append(contentsOf:  allConstraints)
        
        return constraints
    }
#endif
    
    // For spinwheel pie
    /*static func constraintsForColorAxisLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
     {
     
     Log.info("Contianer Layout : Vertical Legend , Landscape Mode")
     
     let titleView = containerView.titleView
     let toolTipView = containerView.toolTipView
     let chartView = containerView.chartView
     let legendView = containerView.legendView
     let drillDownView = containerView.drillDownView
     
     
     let scrollContentView = containerView
     
     let leadingAnchor = scrollContentView.leadingAnchor
     let trailingAnchor = scrollContentView.trailingAnchor
     let topAnchor = scrollContentView.topAnchor
     let heightAnchor = containerView.heightAnchor
     let widthAnchor = scrollContentView.widthAnchor
     
     //        let centerXAnchor = scrollContentView.centerXAnchor
     //        let bottomAnchor = scrollContentView.bottomAnchor
     
     
     var totalHeightPercent:CGFloat = 1.0
     var totalWidthPercent:CGFloat = 1.0
     
     var titleViewHeightFactor:CGFloat = 0.15
     if !titleView.showView {
     titleViewHeightFactor = 0.0
     }
     
     totalHeightPercent = totalHeightPercent - titleViewHeightFactor
     
     containerView.legendHeightFactor = totalHeightPercent
     
     var legendViewWidthFactor:CGFloat = 0.2
     
     if !legendView.showView {
     containerView.legendHeightFactor = 0.0
     legendViewWidthFactor = 0.0
     }
     
     totalWidthPercent = totalWidthPercent - legendViewWidthFactor
     
     
     containerView.tooltipHeightFactor = 0.15
     var tooltipViewWidthFactor:CGFloat = 0.8
     if !toolTipView.showView {
     containerView.tooltipHeightFactor = 0.0
     tooltipViewWidthFactor = 0.0
     }
     
     totalHeightPercent = totalHeightPercent -  containerView.tooltipHeightFactor!
     
     
     containerView.chartHeightFactor = totalHeightPercent
     let chartViewWidthFactor = totalWidthPercent
     
     if containerView.drillDownHeightFactor > 0
     {
     NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
     
     containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
     containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
     
     }
     else
     {
     containerView.chartHeightFactor = totalHeightPercent
     }
     
     Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
     Log.debug("Legend Height \(containerView.legendHeightFactor!) Width \(legendViewWidthFactor)")
     Log.debug("Tooltip Height \(containerView.tooltipHeightFactor!) Width \(tooltipViewWidthFactor)")
     Log.debug("Chart Height \(containerView.chartHeightFactor!)  Width \(chartViewWidthFactor )")
     
     NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
     
     
     var constraints:[NSLayoutConstraint] = []
     
     //Title
     let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
     let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
     let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
     let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
     
     //DrilFilter
     
     let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
     let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
     let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
     
     
     //Legend
     var legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
     var legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: toolTipView.leadingAnchor)
     let legendTopAnchor = legendView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
     containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
     let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)
     
     
     //Tooltip
     var tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
     var tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
     let tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
     containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
     
     
     //Chart
     var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
     var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
     let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
     //        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
     containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
     // let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: chartViewWidthFactor)
     
     
     if legendView.position == .right
     {
     legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
     legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
     
     tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
     tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
     
     chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
     chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
     }
     
     //        let topLegendCollection = legendView.collectionView?.topAnchor.constraint(equalTo: legendView.topAnchor, constant: 20)
     //        var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
     //        let centerYLegendCollection = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
     //
     //        let widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/3)
     //        let heightLegendCollection = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor)
     
     var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
     var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
     var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
     var  heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
     
     if legendView.type == .continous {
     centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
     centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
     widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
     heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1/2)
     }
     
     //TooltipContentView
     let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
     let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
     let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 5)
     let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor, constant: -5)
     
     let allConstraints =
     [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
     legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor, legendWidthAnchor,
     tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor,
     chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor,
     //             centerXLegendCollection!, centerYLegendCollection!, widthLegendCollection!, heightLegendCollection!,topLegendCollection!,
     centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
     toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
     drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor]
     
     constraints.append(contentsOf:  allConstraints)
     
     
     /*    let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
     let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
     var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
     let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
     let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
     
     
     if legendView.position == .bottom
     {
     }
     else
     {
     emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
     }
     
     let emptyViewConstraints = [emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor]
     
     constraints.append(contentsOf: emptyViewConstraints) */
     
     
     return constraints
     }*/
    
}

extension ContainerLayout {
#if os(OSX)
    public static func constraintsForHorizontalLegendPortrait(containerView:ChartContainer) -> [NSLayoutConstraint]
        {
            
            Log.info("In Contianer Layout")
            
            print(containerView.chartView.frame)
            
            let titleView = containerView.titleView
            let legendView = containerView.legendView
            let toolTipView = containerView.toolTipView
            let chartView = containerView.chartView
            let lineView = containerView.lineView
    //        let emptyView = containerView.emptyViewToAddScroll
            let overview = containerView.overviewView
            let drillDownView = containerView.drillDownView
            
            /*let leadingAnchor = containerView.leadingAnchor
             let trailingAnchor = containerView.trailingAnchor
             let topAnchor = containerView.topAnchor
             let heightAnchor = containerView.heightAnchor*/
            
            let heightAnchor = containerView.heightAnchor
            
            let scrollContentView = containerView//.scrollContentView
            
            let leadingAnchor = scrollContentView.leadingAnchor
            let trailingAnchor = scrollContentView.trailingAnchor
            let topAnchor = scrollContentView.topAnchor
            let widthAnchor = containerView.widthAnchor
            
    //        let centerXAnchor = scrollContentView.centerXAnchor
    //        let widthAnchor = scrollContentView.widthAnchor
    //        let bottomAnchor = scrollContentView.bottomAnchor
            
            var totalHeightPercent:CGFloat = 1.0
            var totalWidthPercent:CGFloat = 1.0
            
            var titleViewHeightFactor:CGFloat = 0.1
            if !titleView.showView {
                titleViewHeightFactor = 0.0
            }
            totalHeightPercent = totalHeightPercent - titleViewHeightFactor
            
    //        var legendViewHeightFactor:CGFloat = 0.08
    //        legendViewHeightFactor = 0.20
            
            containerView.legendHeightFactor = 0.08
            
            if !legendView.showView {
    //            legendViewHeightFactor = 0.0
                containerView.legendHeightFactor = 0.0
            }
    //        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
            totalHeightPercent = totalHeightPercent - containerView.legendHeightFactor!
            
            
            var lineViewHeightFactor:CGFloat = 0.02
                    if !legendView.showView || !(lineView.showView) {
                       lineViewHeightFactor = 0.0
                   }
            totalHeightPercent = totalHeightPercent - lineViewHeightFactor
            
            
    //        var tooltipViewHeightFactor:CGFloat = 0.15
            containerView.tooltipHeightFactor = 0.19

            if !toolTipView.showView {
    //            tooltipViewHeightFactor = 0.0
                containerView.tooltipHeightFactor = 0.0
            }
    //        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
            totalHeightPercent = totalHeightPercent - containerView.tooltipHeightFactor!
            
            //OVERVIEW
            var overviewWidthFactor = totalWidthPercent
            
            if overview.showView {
                
                if overview.position == .bottom {
                    if let overviewHeightFactor = containerView.overviewHeightFactor{
                        totalHeightPercent -= overviewHeightFactor
                    }
                }
                else {
                    if let widthFactor = containerView.overviewWidthFactor {
                        totalWidthPercent -= widthFactor
                        overviewWidthFactor = widthFactor
                    }
                }
                
                containerView.overviewHeightFactor = 0.08
            }
            else {
                containerView.overviewHeightFactor = 0.0
                overviewWidthFactor = 0.0
            }

            
            containerView.chartHeightFactor = 0.63
    //        containerView.chartHeightFactor = 0.51
    //        var chartViewHeightFactor:CGFloat = 0.63
            if !chartView.showView {
    //            chartViewHeightFactor = 0.0
                containerView.chartHeightFactor = 0.0
            }else {
    //            chartViewHeightFactor = totalHeightPercent
                 containerView.chartHeightFactor = totalHeightPercent
            }
            
            if containerView.drillDownHeightFactor > 0
            {
                NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
                
                containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
                containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
                
            }
            else
            {
                containerView.chartHeightFactor = totalHeightPercent
            }
            
            totalHeightPercent = totalHeightPercent - containerView.chartHeightFactor!
            
            Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
            
             NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor,containerView.overviewHeightAnchor])
            
            var constraints:[NSLayoutConstraint] = []
            
            //Title
            let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
            let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
            let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
            let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
            
            
            
            //Legend
            let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
            let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
            var legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
    //        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
           
            containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
            
            
            //Line
            let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
            let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
            var lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
            let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
            
            
            
            //Tooltip
            let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
            let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
            var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
    //        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
             containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
            
            
            //DrillFilter
            let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
            let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
            let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            
            //overview
            var overviewLeadingAnchor = overview.leadingAnchor.constraint(equalTo: leadingAnchor)
            var overviewTrailingAnchor = overview.trailingAnchor.constraint(equalTo: trailingAnchor)
            var overviewTopAnchor = overview.topAnchor.constraint(equalTo: lineView.bottomAnchor)
            containerView.overviewHeightAnchor = overview.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.overviewHeightFactor!)
            
            //Chart
            
            var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
    //        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            let chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
    //        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
            containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
            
            if overview.position != .bottom {
                
                if overview.position == .left {
                    overviewTrailingAnchor = overview.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
                    
                    chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: overview.trailingAnchor)
                }
                
                if overview.position == .right {
                    overviewLeadingAnchor = overview.leadingAnchor.constraint(equalTo: chartView.trailingAnchor)
                    
                    chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: overview.leadingAnchor)
                }
                
                overviewTopAnchor = overview.topAnchor.constraint(equalTo: chartView.topAnchor)
                
                containerView.overviewHeightAnchor = overview.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
            }
            
            
            if legendView.position == .bottom
            {
                tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
                lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
//                legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
                legendTopAnchor = legendView.topAnchor.constraint(equalTo: overview.bottomAnchor)
            }

            
            var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
            var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
            
            //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
            var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
            var heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 2/3 )
        
        #if os(OSX)
            if legendView.type == .discrete {
                centerXLegColl =  legendView.scrollView!.leadingAnchor.constraint(equalTo: legendView.leadingAnchor)
                centerYLegColl =  legendView.scrollView!.trailingAnchor.constraint(equalTo: legendView.trailingAnchor)
                widthLegColl =   legendView.scrollView!.topAnchor.constraint(equalTo: legendView.topAnchor)
                heightLegColl =   legendView.scrollView!.bottomAnchor.constraint(equalTo: legendView.bottomAnchor)
            }
        #endif
            if legendView.type == .continous {
                centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
                centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
                widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
                heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1)
            }
        
            
    //            allConstraints.append(contentsOf: [
    //            legendView.collectionView!.leadingAnchor.constraint(equalTo: legendView.leadingAnchor),
    //            legendView.collectionView!.trailingAnchor.constraint(equalTo: legendView.trailingAnchor),
    //            legendView.collectionView!.topAnchor.constraint(equalTo: legendView.topAnchor),
    //            legendView.collectionView!.bottomAnchor.constraint(equalTo: legendView.bottomAnchor)])

            
            //TooltipContentView
            let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
            let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
            let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
            let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
            
            
            let allConstraints =
                [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
                 legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor,   containerView.legendViewHeightAnchor, //legendHeightAnchor,
                 tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor, // tooltipHeightAnchor,
                 chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor,// chartHeightAnchor,
                    containerView.chartViewHeightAnchor,
                 lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
                  centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
                  toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
                  drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor, overviewLeadingAnchor, overviewTrailingAnchor, overviewTopAnchor, containerView.overviewHeightAnchor]
            
            if (titleView.showView) {
                constraints.append(contentsOf: ContainerLayout.getConstraintsForTitleView(titleView: titleView))
            }
            
            if overview.position == .left || overview.position == .right {
                
                let overviewWidthAnchor = overview.widthAnchor.constraint(equalTo: widthAnchor, multiplier: overviewWidthFactor)
                
                constraints.append(overviewWidthAnchor)
            }
            
            constraints.append(contentsOf:  allConstraints)
            
            
          /*  let emptyViewCenterXAnchor = emptyView.centerXAnchor.constraint(equalTo: centerXAnchor)
            let emptyViewWidthAnchor = emptyView.widthAnchor.constraint(equalTo: widthAnchor)
            var emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
            let emptyViewBottomAnchor = emptyView.bottomAnchor.constraint(equalTo: bottomAnchor)
            let emptyViewHeightAnchor = emptyView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: 0.01)
            
            
            if legendView.position == .bottom
            {
            }
            else
            {
                emptyViewTopAnchor = emptyView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            }
            
            let emptyViewConstraints = [emptyViewCenterXAnchor,emptyViewWidthAnchor,emptyViewTopAnchor,emptyViewBottomAnchor,emptyViewHeightAnchor]

             constraints.append(contentsOf: emptyViewConstraints) */
            
            
            return constraints
        }
    
    public static func constraintsForColorAxisVertical(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        Log.info("Contianer Layout : Vertical Legend , Landscape Mode")
        
        let titleView = containerView.titleView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let legendView = containerView.legendView
        let drillDownView = containerView.drillDownView
        
        
        let scrollContentView = containerView
        
        let leadingAnchor = scrollContentView.leadingAnchor
        let trailingAnchor = scrollContentView.trailingAnchor
        let topAnchor = scrollContentView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = scrollContentView.widthAnchor
        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.15
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        
        containerView.tooltipHeightFactor = 0.19
        var tooltipViewWidthFactor:CGFloat = 1
        if !toolTipView.showView {
            containerView.tooltipHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent -  containerView.tooltipHeightFactor!
        
        
        containerView.legendHeightFactor = totalHeightPercent
        
        var legendViewWidthFactor:CGFloat = 0.2
        
        var legendViewHeightFactor:CGFloat = 0.14
        
        if !legendView.showView {
            containerView.legendHeightFactor = 0.0
            legendViewWidthFactor = 0.0
        }
        
        if legendView.position == .left || legendView.position == .right {
            
            totalWidthPercent = totalWidthPercent - legendViewWidthFactor
            
        }
        else {
            if containerView.legendHeightFactor != 0 {
                containerView.legendHeightFactor = legendViewHeightFactor
            }
            totalHeightPercent -= legendViewHeightFactor
            legendViewWidthFactor = 1.0
        }
        
        
     
        
        containerView.chartHeightFactor = totalHeightPercent
        let chartViewWidthFactor = totalWidthPercent
        
        if containerView.drillDownHeightFactor > 0
        {
            NSLayoutConstraint.deactivate([containerView.drillDownHeightAnchor, containerView.chartViewHeightAnchor])
            
            containerView.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: containerView.heightAnchor, multiplier: containerView.drillDownHeightFactor)
            containerView.chartHeightFactor = containerView.chartHeightFactor! - containerView.drillDownHeightFactor
            
        }
        else
        {
            containerView.chartHeightFactor = totalHeightPercent
        }
        
        Log.debug("Total Percent \(totalHeightPercent) Title \(titleViewHeightFactor) Legend \(containerView.legendHeightFactor!) Tooltip \(containerView.tooltipHeightFactor!) Chart \(containerView.chartHeightFactor!)")
        Log.debug("Legend Height \(containerView.legendHeightFactor!) Width \(legendViewWidthFactor)")
        Log.debug("Tooltip Height \(containerView.tooltipHeightFactor!) Width \(tooltipViewWidthFactor)")
        Log.debug("Chart Height \(containerView.chartHeightFactor!)  Width \(chartViewWidthFactor )")
        
        NSLayoutConstraint.deactivate([containerView.tooltipViewHeightAnchor, containerView.chartViewHeightAnchor,containerView.legendViewHeightAnchor])
        
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        var tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        containerView.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.tooltipHeightFactor!)
        
        //DrilFilter
        
        let drillDownLeadingAnchor = drillDownView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let drillDownTrailingAnchor = drillDownView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let drillDownTopAnchor = drillDownView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        //Legend
        var legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        var legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
        var legendTopAnchor = legendView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
        containerView.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.legendHeightFactor!)
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)
        
        
      
        
        
        //Chart
        var chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
        var chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: drillDownView.bottomAnchor)
        containerView.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: containerView.chartHeightFactor!)
        
        
        
        if legendView.position == .right
        {
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: chartView.trailingAnchor)
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: legendView.leadingAnchor)
        }
        
        var centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        var centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        var widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        var  heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
        
        if legendView.type == .continous {
            centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
            centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
            widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
            heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 0.8)
        }
        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 25)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -25)
        var toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 5)
        var toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor, constant: -5)
        
        if legendView.position == .top || legendView.position == .bottom {
            
            legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
            legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
            chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
            
            if legendView.position == .top {
                
                legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
                
                tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
            }
            else {
                
                tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
                
                legendTopAnchor = legendView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
            }
            
            if legendView.type == .continous {
                centerXLegColl = legendView.rangeSlider?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
                centerYLegColl = legendView.rangeSlider?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
                widthLegColl = legendView.rangeSlider?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/4)
                heightLegColl = legendView.rangeSlider?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 1)
            }
            
            toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
            toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        }
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, containerView.legendViewHeightAnchor, legendWidthAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, containerView.tooltipViewHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, containerView.chartViewHeightAnchor,
                centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
                toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom,
                drillDownLeadingAnchor, drillDownTrailingAnchor, drillDownTopAnchor, containerView.drillDownHeightAnchor]
        
        constraints.append(contentsOf:  allConstraints)
        
        return constraints
    }
    
    public static func getConstraintsForTitleView(titleView: TitleView) -> [NSLayoutConstraint]
    {
        let leadingAnchor = titleView.leadingAnchor
        let trailingAnchor = titleView.trailingAnchor
        let topAnchor = titleView.topAnchor
        let heightAnchor = titleView.heightAnchor
        let widthAnchor = titleView.widthAnchor
        let centerXAnchor = titleView.centerXAnchor
        
        let mainTitle = titleView.mainTitle
        let subTitle = titleView.subTitle
        let lineView = titleView.lineDesign
        
        var mainTitleHeightFactor:CGFloat = 0.58
        var subTitleHeightFactor:CGFloat = 0.38
        var lineHeightFactor:CGFloat = 0.04
        
        if !mainTitle.enable{
            subTitleHeightFactor = subTitleHeightFactor + mainTitleHeightFactor
            mainTitleHeightFactor = 0.0
        }
        
        if !subTitle.enable {
            mainTitleHeightFactor = mainTitleHeightFactor + subTitleHeightFactor
            subTitleHeightFactor = 0.0
        }
        
        if !titleView.showView {
            lineHeightFactor = 0.0
        }
        
        //Title
        let mainTitleCenterxAnchor = mainTitle.centerXAnchor.constraint(equalTo: centerXAnchor)
        let mainTitleTopAnchor = mainTitle.topAnchor.constraint(equalTo: topAnchor)
        let mainTitleHeightAnchor = mainTitle.heightAnchor.constraint(equalTo: heightAnchor, multiplier: mainTitleHeightFactor)
        let mainTitleWidthAnchor = mainTitle.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.90)
        
        
        
        //Legend
        let subTitleCenterXAnchor = subTitle.centerXAnchor.constraint(equalTo: centerXAnchor)
        let subTitleTopAnchor = subTitle.topAnchor.constraint(equalTo: mainTitle.bottomAnchor)
        let subTitleHeightAnchor = subTitle.heightAnchor.constraint(equalTo: heightAnchor, multiplier: subTitleHeightFactor)
        let subTitleWidthAnchor = subTitle.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.90)
        
        // Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let lineTopAnchor = lineView.topAnchor.constraint(equalTo: subTitle.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineHeightFactor)
        
        
        
//        if titleView.oldConstraints.count > 0 {
//            NSLayoutConstraint.deactivate(titleView.oldConstraints)
//            //titleView.removeConstraints(titleView.oldConstraints)
//        }
        
        titleView.oldConstraints = [ mainTitleWidthAnchor,mainTitleCenterxAnchor, mainTitleTopAnchor, mainTitleHeightAnchor,
                                     subTitleWidthAnchor, subTitleCenterXAnchor, subTitleTopAnchor, subTitleHeightAnchor,
                                     lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor]
        
        //titleView.addConstraints(titleView.oldConstraints)
//        NSLayoutConstraint.activate(titleView.oldConstraints)
        return titleView.oldConstraints
    }
    #endif
}
