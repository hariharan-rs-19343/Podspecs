//
//  ChartContainer.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

@objc
public protocol ContainerDelegate : LegendViewDelegate, TooltipViewDelegate
{
    @objc optional func filterEntrySelected(entry: [ChartDataEntry]?)
    
    @objc optional func drillEntrySelected(entry: ChartDataEntry, level: Int)
}

@objc
public protocol ChartContainerDelegate
{
    @objc optional func getConstraints(containerView:ChartContainer) -> [NSLayoutConstraint]

}

//open class ChartContainer: NSUIView, ChartViewDelegate, LegendViewDelegate, TooltipViewDelegate, DrillFilterMenuDataSource, DrillFilterMenuDelegate {
open class ChartContainer: NSUIView, ChartViewDelegate, LegendViewDelegate, TooltipViewDelegate,DrillFilterMenuDataSource, DrillFilterMenuDelegate {
//open class ChartContainer: NSUIView, ChartViewDelegate, LegendViewDelegate, TooltipViewDelegate, UIScrollViewDelegate, DrillFilterMenuDataSource, DrillFilterMenuDelegate {
    
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
    
    //var _spinAnimator: Animator!
    
//  var firstTime:Bool = true
    
    weak open var chartViewDelegate:ChartViewDelegate? = nil
    
    weak open var chartContainerDelegate:ChartContainerDelegate? = nil
    
    open var currentOrientation:Orientation = .Undefined
    
    var installedConstraints:[NSLayoutConstraint] = []
    
    public let titleView = TitleView()
    
    public let toolTipView = ToolTipCollectionView()
    
    public let legendView = LegendView()
    
    public let chartView = ChartView()
    
    public let lineView = LineView()
    
    public let overviewView = OverviewView()
    
    var legendEntries:[LegendEntry]? = []
    
    /*public let scrollView = ChartContainerScrollView()
    
    public let scrollContentView = UIView()
    
    open let emptyViewToAddScroll = UIView() */
    
    public let drillDownView = DrillFilterMenuView()
    
    open var drillDownHeightAnchor:NSLayoutConstraint = NSLayoutConstraint()
    
    open var chartViewHeightAnchor:NSLayoutConstraint = NSLayoutConstraint()
    
    open var legendViewHeightAnchor:NSLayoutConstraint = NSLayoutConstraint()
    
    open var tooltipViewHeightAnchor:NSLayoutConstraint = NSLayoutConstraint()
    
    open var overviewHeightAnchor:NSLayoutConstraint = NSLayoutConstraint()
    
    open var chartHeightFactor:CGFloat? = nil
    
    open var legendHeightFactor:CGFloat? = nil
    
    open var tooltipHeightFactor:CGFloat? = nil
    
    open var overviewHeightFactor:CGFloat? = nil
    
    open var overviewWidthFactor:CGFloat? = nil
    
    
    open var legend:ChartLegendObject
    {
        get {
            return self.legendView.legend
        }
    }
    
    open var tooltip:ChartTooltip {
        get {
            return self.toolTipView.tooltip
        }
    }
    
    open var title:ChartTitle {
//        set{
//            self.titleView.title = newValue
//        }
        get {
            return self.titleView.title
        }
    }
    
    open var overview:OverViewObject
    {
        get {
            return self.overviewView.overview
        }
    }
    
    open weak var delegateToChartView:ContainerDelegate? = nil
    
//    var longPressRecognizer:UILongPressGestureRecognizer!
    
    var _legendToolTipToggleEnabled:Bool = false
    
    open var legendToolTipToggleEnabled:Bool
    {
        set
        {
            self._legendToolTipToggleEnabled = newValue
            
            if self._legendToolTipToggleEnabled
            {
              self.toolTipView.showView = false
            }
        }
        get
        {
            return self._legendToolTipToggleEnabled
        }
    }
    
  /*  open var menuControl:MenuOptionsView?
    
    open var enableMenu:Bool{
        set(newValue)
        {
            if newValue == true
            {
                menuControl = MenuOptionsView()
//                self.menuControl?.layer.opacity = 0
                /*self.scrollView.isScrollEnabled = true */
            }
        }
        get{
            return false
        }
    }

    var refreshControl: UIRefreshControl! */
    
    open var isAxisChart:Bool = true
    
    open var chart: ChartViewBase {
        get {
            return chartView.chart
        }
    }
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        lineView.chartContainer = self
        Log.info("Initial Bound \(self.bounds) Frame \(self.frame)")
        self.translatesAutoresizingMaskIntoConstraints = false
        addContentViews()
        
        //        _spinAnimator = Animator()
        //        _spinAnimator.delegate = self
        
        //      longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressGestureRecognized(_:)))
        //      self.addGestureRecognizer(longPressRecognizer)
        
        self.addObserver(self, forKeyPath: "bounds", options: .new, context: nil)
        self.addObserver(self, forKeyPath: "frame", options: .new, context: nil)
        
       
    }
    
    deinit
    {
        self.removeObserver(self, forKeyPath: "bounds")
        self.removeObserver(self, forKeyPath: "frame")
    }
    
    open override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?)
    {
        if keyPath == "bounds" || keyPath == "frame"
        {
            Log.info("Observer for Key \(keyPath!) called \(self.bounds) \(self.frame)")
            #if os(iOS) || os(tvOS)
            self.setNeedsUpdateConstraints()
            #elseif os(OSX)
            self.needsUpdateConstraints = true
            #endif
            
            chartView.chart.layoutUpdate()
            
            titleView.reloadTitles()
            chartView.chart.setNeedsDisplay()
        }
    }
    
    
    public convenience init() {
        self.init(frame: CGRect.zero)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @available(*, deprecated, message: "use conatinerview.chart instead")
    public func initializeChart() -> ChartViewBase
    {
        let chartObj = chartView.initializeChart()
        chartObj.delegateToContainer = self
        
        self.delegateToChartView = self.chartView.chart
        
        return chartObj
    }
    
    public func initializeChart(chart:ChartViewBase) -> Bool
    {
        let chartObj = chartView.initializeChart(chart:chart)
        chartObj.delegateToContainer = self
        
        self.delegateToChartView = self.chartView.chart
        
        return true
    }
    
    func addContentViews()
    {
        _ = initializeChart()
   /*     scrollView.backgroundColor = NSUIColor.clear
    
        scrollContentView.backgroundColor = NSUIColor.clear
        
        scrollView.delaysContentTouches = false
        scrollView.canCancelContentTouches = false
        
        
        scrollView.showsVerticalScrollIndicator = false
        scrollView.isScrollEnabled = false
        
        scrollView.delegate = self
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        
        scrollContentView.translatesAutoresizingMaskIntoConstraints = false
        
        refreshControl = UIRefreshControl()
        scrollView.addSubview(refreshControl)
//        scrollView.refreshControl = refreshControl
        refreshControl.tintColor = NSUIColor.clear
        
        
        self.addSubview(scrollView)
        
        scrollView.addSubview(scrollContentView) */
        
        
//        initScrollViewConstraints()
        
        titleView.backgroundColor = NSUIColor.clear
        
        toolTipView.nsuiLayer?.backgroundColor = NSUIColor.clear.cgColor//.backgroundColor = NSUIColor.clear
        
        legendView.nsuiLayer?.backgroundColor = NSUIColor.clear.cgColor//.backgroundColor = NSUIColor.clear
        
        overviewView.backgroundColor = NSUIColor.clear
        
        chartView.backgroundColor = NSUIColor.clear
        
//        emptyViewToAddScroll.backgroundColor = NSUIColor.clear
        
        drillDownView.nsuiLayer?.backgroundColor = NSUIColor.clear.cgColor//.backgroundColor = NSUIColor.clear
        
        titleView.translatesAutoresizingMaskIntoConstraints = false
        toolTipView.translatesAutoresizingMaskIntoConstraints = false
        legendView.translatesAutoresizingMaskIntoConstraints = false
        chartView.translatesAutoresizingMaskIntoConstraints = false
        lineView.translatesAutoresizingMaskIntoConstraints = false
//        emptyViewToAddScroll.translatesAutoresizingMaskIntoConstraints = false
        drillDownView.translatesAutoresizingMaskIntoConstraints = false
        overviewView.translatesAutoresizingMaskIntoConstraints = false
        
      /*  scrollContentView.addSubview(titleView)
        
        scrollContentView.addSubview(legendView)
        
        scrollContentView.addSubview(toolTipView)
        
        scrollContentView.addSubview(chartView)
        
        scrollContentView.addSubview(lineView)
        
        scrollContentView.addSubview(emptyViewToAddScroll)
        
        scrollContentView.addSubview(drillDownView) */
        
        self.addSubview(titleView)
        
        self.addSubview(legendView)
        
        self.addSubview(toolTipView)
        
        self.addSubview(chartView)
        
        self.addSubview(lineView)
        
        self.addSubview(drillDownView)
        
        self.addSubview(overviewView)
        
//        legendView.collectionView?.dataSource = self
        legendView.delegate = self
        
        toolTipView.delegateToContainer = self
        
        drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.0)
        drillDownView.dataSource = self
        drillDownView.delegate = self
        
        chartViewHeightAnchor  = chartView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.63)
        
        legendViewHeightAnchor  = legendView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.08)
        legendHeightFactor = 0.08
        
        tooltipHeightFactor = 0.15
        tooltipViewHeightAnchor  = toolTipView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: self.tooltipHeightFactor!)
        
        overviewHeightAnchor  = overviewView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.08)
        overviewHeightFactor = 0.08
        overviewWidthFactor = 0.2
        
        overview.notifyChartViewCreated = { [weak self] in
            if let self = self, self.overview.overviewEnabled {
                self.overview.chartView?.delegateToContainer = self
                self.overviewView.rangeSlider?.delegate = self
            }
        }
        
    }
    
   
    /*
    func initScrollViewConstraints()
    {
     
        scrollView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        
        scrollContentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        scrollContentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        scrollContentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        scrollContentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        
        scrollContentView.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        
    } */
    
    override open func updateConstraints() {
        
        Log.info("Bound \(self.bounds) \(self.frame)")
        Log.info("In Update Constraints: Device Orient \(currentOrientation)  Leg Orient \(legend.legendOrientation)")
        
        if self.installedConstraints.count > 0
        {
            NSLayoutConstraint.deactivate(self.installedConstraints)
        }
        
        if chartContainerDelegate != nil && chartContainerDelegate?.getConstraints != nil
        {
            self.installedConstraints = (chartContainerDelegate?.getConstraints?(containerView: self))!
        }
        else{
            if self.isPortraitOrientation() && (self.currentOrientation != .Portrait || self.currentOrientation == .Undefined){
                
                self.currentOrientation = .Portrait
                self.installedConstraints = getConstraints()
                
            }
            else if !self.isPortraitOrientation() && (self.currentOrientation == .Portrait || self.currentOrientation == .Undefined) {
                
                self.currentOrientation = .Landscape
                self.installedConstraints = getConstraints()
            }
        }
        
        NSLayoutConstraint.activate(self.installedConstraints)
        
        super.updateConstraints()
        
    }
    
    func isPortraitOrientation() -> Bool
    {
        return  (self.bounds.size.height > self.bounds.size.width) // UIDevice.current.orientation.isFlat || UIDevice.current.orientation.isPortrait ||
    }
    
    func getConstraints() -> [NSLayoutConstraint] {
        
        Log.info("Device Orient \(currentOrientation)  Leg Orient \(legend.legendOrientation)")
        
        let axisChart = isAxisChart
        
        var constraints:[NSLayoutConstraint] = []
        
        // To set Portrait Orientation
        self.chartView.chart.isVertical = true
        
        #if os(OSX)
        constraints = ContainerLayout.constraintsForHorizontalLegendPortrait(containerView: self)
        for c in constraints{
            c.priority = .defaultLow
        }
        #endif
        
        #if !os(OSX)
        if currentOrientation == .Landscape && self.chartView.chart.colorAxis.enabled
        {
            constraints = ContainerLayout.constraintsForColorAxisLandscape(containerView: self)
            return  constraints
        }
        
        if axisChart
        {
            constraints = ContainerLayout.constraintsForPortraitAxisChart(containerView: self)
        }
        else
        {
            constraints = ContainerLayout.constraintsForHorizontalLegendPortrait(containerView: self)
            
            if currentOrientation == .Portrait
            {
                
                if legend.legendOrientation == .Vertical
                {
                    constraints = ContainerLayout.constraintsForVerticalLegendPortrait(containerView: self)
                }
            } else if currentOrientation == .Landscape
            {
                if legend.legendOrientation == .Vertical
                {
                    constraints = ContainerLayout.constraintsForVerticalLegendLandscape(containerView: self)
                } else if legend.legendOrientation == .Horizontal
                {
                    constraints = ContainerLayout.constraintsForHorizontalLegendLandscape(containerView: self)
                    //To set Landscape Orientation
                    self.chartView.chart.isVertical = false
                }
            }
            
        }
        #endif
        
        return constraints
    }
    
    
    // MARK: -  ChartView Delegates
    
    public func chartDataNil(chartView: ChartViewBase) {
        if chartViewDelegate != nil
        {
            chartViewDelegate?.chartDataNil?(chartView: chartView)
        }
    }
    
    public func chartCheckNoDataAvailable(chartView: ChartViewBase) -> Bool {
        
        if chartViewDelegate != nil  && (chartViewDelegate!.chartCheckNoDataAvailable != nil)
        {
            return chartViewDelegate!.chartCheckNoDataAvailable!(chartView: chartView)
        }
        return false
    }
    
    public func chartBufferLoadedBeforeDraw(chartView: ChartViewBase) -> Bool {
        if chartViewDelegate != nil && (chartViewDelegate!.chartBufferLoadedBeforeDraw != nil)
        {
            return chartViewDelegate!.chartBufferLoadedBeforeDraw!(chartView: chartView)
        }
        return false
    }
    
    public func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        if chartViewDelegate != nil
        {
            chartViewDelegate?.chartValueSelected?(chartView, entry: entry, highlight: highlight)
        }
        if toolTipView.showView
        {
        toolTipView.reloadData(entry: entry)
        self.toggleTooltipAndLegendView(showTooltip: true)
        }
    }
    
    public func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry) {
        if chartViewDelegate != nil
        {
            chartViewDelegate?.chartValueSelected?(chartView, entry: entry)
        }
        if toolTipView.showView
        {
        toolTipView.reloadData(entry: entry)
        self.toggleTooltipAndLegendView(showTooltip: true)
        }
    }
    
    public func chartValueNothingSelected(_ chartView: ChartViewBase) {
        if chartViewDelegate != nil{
            chartViewDelegate?.chartValueNothingSelected?(chartView)
        }
        if toolTipView.showView
        {
        self.toolTipView.oldEntry = nil
        self.toolTipView.reloadData(entry: nil)
        self.toggleTooltipAndLegendView(showTooltip: false)
        }
    }
    
    public func chartValueLongPressed(_ chartView: ChartViewBase, entry: ChartDataEntry) {
        if chartViewDelegate != nil{
            chartViewDelegate?.chartValueLongPressed?(chartView, entry: entry)
        }
    }
    
    public func chartScaled(_ chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat) {
        if chartViewDelegate != nil{
            chartViewDelegate?.chartScaled?(chartView, scaleX: scaleX, scaleY: scaleY)
        }
        
        if overview.overviewEnabled {
            
            let (min,max) = CommonHelperFunctions.getXMinAndMaxValue(chart: chartView)
            
            overviewView.chartXRangeUpdated(chartView, minimum: min, maximum: max, updateLayer: false)
            
            overviewView.updateRangeSlider()
        }
    }
    
    public func chartTranslated(_ chartView: ChartViewBase, dX: CGFloat, dY: CGFloat) {
        if chartViewDelegate != nil{
            chartViewDelegate?.chartTranslated?(chartView, dX: dX, dY: dY)
        }
        
        if overview.overviewEnabled {
            
            let (min,max) = CommonHelperFunctions.getXMinAndMaxValue(chart: chartView)
            
            overviewView.chartXRangeUpdated(chartView, minimum: min, maximum: max, updateLayer: false)
            
            overviewView.updateRangeSlider()
        }
    }
    
    public func chartValueRemoved(_ chartView: ChartViewBase, entries: [ChartDataEntry]?, dataSets: [ChartDataSet]?, dataSetRemoved: Bool, showTrackerView: Bool) {
        
        if chartViewDelegate != nil{
            chartViewDelegate?.chartValueRemoved?(chartView, entries: entries, dataSets: dataSets, dataSetRemoved: dataSetRemoved, showTrackerView: showTrackerView)
        }
        
        guard let chartData = chartView.data, chartData.getDataSetForPlotType(plotType: .Sanky).isEmpty else {
            return
        }
        
        var index = -1
        
        if entries == nil || entries!.count == 0 {
            if let dataSets = dataSets, !dataSets.isEmpty {
                index = (chartData.indexOfDataSet(dataSets[0]))
            }
        }
        else {
            index = (chartData.getDataSetForEntry(entries![0])?.entryIndex(entry: entries![0])) ?? 0
        }
        
        self.toolTipView.oldEntry = nil
        self.toolTipView.reloadData(entry: nil)
      
        if drillDownView.showView && showTrackerView
        {
            if index == -1 {
                return
            }
            
            if let entries = entries {
                filterMenuEntryAdded(chartView, entry: entries, level: index)
            }
        }
        else
        {
            if legendToolTipToggleEnabled
            {
                toggleTooltipAndLegendView(showTooltip: false)
            }
            
            #if !os(OSX)
            if self.legendView.showView
            {
                if let dataSets = dataSets, !dataSets.isEmpty {
                    index = CommonHelperFunctions.legendCellIndexForDataSet(chart: chartView, dataset: dataSets[0])
                }
                
                if index == -1 {
                    return
                }
                
                let indexPath = IndexPath(item: index, section: 0)
                
                self.legendView.collectionView?.scrollToItem(at: indexPath, at: [ .centeredHorizontally, .centeredVertically], animated: false)
                
                var cell = self.legendView.collectionView?.cellForItem(at: indexPath)
                
                if cell == nil{
                    self.legendView.collectionView?.layoutIfNeeded()
                    cell = self.legendView.collectionView?.cellForItem(at: indexPath)
                }
                
                if cell == nil
                {
                    self.legendView.collectionView?.reloadData()
                    self.legendView.collectionView?.layoutIfNeeded()
                    cell = self.legendView.collectionView?.cellForItem(at: indexPath)
                }
                
                let legendCell = cell as! LegendCell
                
                legendCell.labelView.alpha = 0.1
                legendCell.formView.alpha = 0.1
                
                legendCell.entry?.enabled = false
                
                for currentEntry in entries ?? []
                {
                    currentEntry.enabled = false
                }
            }
            #endif
            
            #if os(OSX)
            if self.legendView.showView
            {
                if let dataSets = dataSets, !dataSets.isEmpty {
                    index = CommonHelperFunctions.legendCellIndexForDataSet(chart: chartView, dataset: dataSets[0])
                }
                
                if index == -1 {
                    return
                }
                
                let indexPath = IndexPath(item: index, section: 0)
                
                self.legendView.collectionView?.scrollToItems(at: Set([indexPath]), scrollPosition: [.centeredHorizontally,.centeredVertically])
                
                var cell = self.legendView.collectionView?.item(at: indexPath)
                
                if cell == nil{
                    self.legendView.collectionView?.layout()
                    cell = self.legendView.collectionView?.item(at: indexPath)
                }
                
                if cell == nil
                {
                    self.legendView.collectionView?.reloadData()
                    self.legendView.collectionView?.layout()
                    cell = self.legendView.collectionView?.item(at: indexPath)
                }
                
                let legendCell = cell as! LegendCell
                
                legendCell.legendCellView?.legendEntry?.enabled = false
                
                for subLayer in (legendCell.legendCellView?.layer?.sublayers)!
                {
                    subLayer.opacity = 0.1
                }
                
                for currentEntry in entries ?? []
                {
                    currentEntry.enabled = false
                }
            }
            #endif

        }
        
        if overview.overviewEnabled {
            overviewView.chartValueUpdated(chart: chartView)
        }
        
    }
    
    public func chartValueAdded(chartView: ChartViewBase, entries: [ChartDataEntry]?, dataSets: [ChartDataSet]?, dataSetAdded: Bool) {
        if chartViewDelegate != nil{
            chartViewDelegate?.chartValueAdded?(chartView: chartView, entries: entries, dataSets: dataSets, dataSetAdded: dataSetAdded)
        }
        if toolTipView.showView
        {
            self.toolTipView.oldEntry = nil
            self.toolTipView.reloadData(entry: nil)
            self.toggleTooltipAndLegendView(showTooltip: false)
        }
        if overview.overviewEnabled {
            overviewView.chartValueUpdated(chart: chartView)
        }
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        
        //remove all existing filter menu entries
        if chartViewDelegate != nil{
            chartViewDelegate?.chartValueDrillPerformed?(chartView, entry: entry, level: level)
        }
       if drillDownView.showView
       {
        self.toolTipView.oldEntry = nil
        self.toolTipView.reloadData(entry: nil)
        
        let menuEntriesToRemove = getFilterMenuEntriesToRemoveForDrill()
        
        let count = menuEntriesToRemove.count
        
        if count > 0
        {
            for i in 0 ..< count
            {
                let indexToRemove = self.drillDownView.scrollContentView.subviews.firstIndex(of: menuEntriesToRemove[i])
                
                let removed = self.drillFilterEntryList.remove(at: indexToRemove!)
                
                for entry in removed.chartDataEntry
                {
                    entry.filterEnabled = false
                }
                
            }
        }
        var  drillEntryArray:[ChartDataEntry] = []
        drillEntryArray.append(entry)
        let drillEntry = prepareDrillFilterEntry(chartView: chartView, entry: drillEntryArray, level: level, menuType: .drill)
        drillFilterEntryList.append(drillEntry)
        
        toggleDrillFilterMenuView()
        
        self.drillDownView.refreshData()
        }
        
    }
    
    public func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        if chartViewDelegate != nil{
            chartViewDelegate?.drillReverted?(chartView: chartView, selectedEntry: selectedEntry, index: index)
        }
    }
    
    
    public func legendReloaded(_ chartView: ChartViewBase, _ legendEntries: [LegendEntry]?) {
        
        if chartViewDelegate != nil{
            if chartViewDelegate?.legendReloaded != nil {
                chartViewDelegate?.legendReloaded?(chartView, legendEntries)
                return
            }
        }
        
        
        if legendEntries != nil && (legendEntries?.count)! > 0 && legendView.showView
        {
            Log.info("Legend Notification received")
            if legendView.type == .continous {
                legendView.rangeSlider?.legendEntries = legendEntries!
                #if os(OSX)
                legendView.rangeSlider?.needsLayout = true//ONLY FOR MAC
                #endif
            }
            else {
//                legendView.calculateMaxCellSize(entries: legendEntries!)
//                legendView.collectionView?.reloadData()
                if let legendEntries = legendEntries {
                    legendView.reload(legendEntries: legendEntries)
                }
            }
        }
    }
    
    public func chartProcessedBeforeDraw(_ chartView: ChartViewBase, redrawRequired: Bool) {
        
        if chartViewDelegate != nil {
            chartViewDelegate?.chartProcessedBeforeDraw?(chartView, redrawRequired: redrawRequired)
        }
        
        if overview.overviewEnabled {
            
            if chartView === chart {
                
                if chartView.isRotated {
                    if overviewView.offsets.topOffset == nil && overviewView.offsets.bottomOffset == nil {
                        overviewView._offsets.topOffset = chartView.viewPortHandler.offsetTop
                        overviewView._offsets.bottomOffset = chartView.viewPortHandler.offsetBottom
                    }
                }
                else {
                    if overviewView.offsets.leftOffset == nil && overviewView.offsets.rightOffset == nil {
                        overviewView._offsets.leftOffset = chartView.viewPortHandler.offsetLeft
                        overviewView._offsets.rightOffset = chartView.viewPortHandler.offsetRight
                    }
                }
                
                overviewView.updateConstraints()
                
                let (min,max) = CommonHelperFunctions.getXMinAndMaxValue(chart: chartView)
                
                overviewView.chartXRangeUpdated(chart, minimum: min, maximum: max, updateLayer: false)
            }
            else {
                if let plotoptions = chartView.getPlotOptions() as? AxisChartPlotOptions, plotoptions.maxWidthZoomRestrictionPixel != CGFloat.greatestFiniteMagnitude {
                    
                    var currentOnePointWidth = CommonHelperFunctions.stepSize(chart: chartView, axisIndex: 0)
                    
                    if chartView.xAxis.scaleType != .Ordinal
                    {
                        currentOnePointWidth =  CommonHelperFunctions.getMaxWidthBetweenEntriesAcrossAllVisibleData(barLine: chartView)
                    }
                    
                    let requiredScale = plotoptions.maxWidthZoomRestrictionPixel / currentOnePointWidth
                    
                    overviewView.rangeSlider?.maximumSelectableRange = chartView.xAxis.axisRange / requiredScale
                }
            }
        }
    }
    
    public func chartXRangeUpdated(minimum: Double, maximum: Double, updateLayer: Bool) {
        
        if chartViewDelegate != nil {
            chartViewDelegate?.chartXRangeUpdated?( minimum: minimum, maximum: maximum, updateLayer: updateLayer)
        }
        
        if overview.overviewEnabled {
            overviewView.chartXRangeUpdated(chart, minimum: minimum, maximum: maximum, updateLayer: updateLayer)
        }
    }
    
    
    
    
    //------ DataSource for Legend ------------//
    /*
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //return legendEntries!.count
        return self.chartView.chart.legend.entries.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let entries = self.chartView.chart.legend.entries
        
        let entry = entries[indexPath.item]
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LegendCell", for: indexPath) as! LegendCell
        
        cell.legendOrientation = legend.legendOrientation
        cell.entry = entry
        cell.delegate = self.legendView
        cell.legend = legend
        
        if self.legend.legendForm == .Custom && self.legend.customPath != nil
        {
            cell.shapeLayer.path = self.legend.customPath!(cell.shapeLayer.bounds)
        }
        else if self.legend.legendForm == .Square
        {
            cell.shapeLayer.path = UIBezierPath(rect: cell.shapeLayer.bounds).cgPath
        }
        else
        {
            cell.shapeLayer.path = UIBezierPath(ovalIn: cell.shapeLayer.bounds).cgPath
        }
        
        if (legend.formCornerRadius != 0) {
            cell.shapeLayer.cornerRadius = legend.formCornerRadius
            cell.shapeLayer.masksToBounds = true
        }
        
        let text = entry.label
        cell.labelView.text = text
        cell.labelView.font = self.legend.legendFont
        cell.labelView.alpha = 1.0
        cell.formView.alpha = 1.0
        
        
        
//        cell.shapeLayer.fillColor = entry.formColor?.cgColor
        cell.shapeLayer.fillColor = entry.colors?[0].cgColor
        cell.labelView.textColor = self.legend.legendTextColor
        
        
        if entry.enabled
        {
//            cell.shapeLayer.fillColor = entry.formColor?.cgColor
            cell.shapeLayer.fillColor = entry.colors?[0].cgColor
            cell.labelView.textColor = self.legend.legendTextColor
            //cell.alpha = 1.0
        }
        else
        {
            cell.labelView.alpha = 0.1
            cell.formView.alpha = 0.1
        }
        
        //To Add a Mask on Legend View//TMP// Have to call on when the collection view loaded the content size and init frame
        legendView.addMask()
        
        return cell
    }
    */
    //------------------LegendViewDelegate---------------//
    
    // MARK: -  Legend Delegates
    
//    public func legendSelected(indexPath: IndexPath) {
//        self.delegateToChartView?.legendSelected!(indexPath: indexPath)
//    }
//
//    public func legendLongPressed(indexPath: IndexPath) {
//        self.delegateToChartView?.legendLongPressed?(indexPath: indexPath)
//    }
    
    public func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
        self.delegateToChartView?.legendEnabled!(indexPath: indexPath, entry: entry)
    }
    
    public func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        self.delegateToChartView?.legendDisabled!(indexPath: indexPath, entry: entry)
    }
    
    public func legendRangeSelected(minimum: Double, maximum: Double) {
        self.delegateToChartView?.legendRangeSelected!(minimum: minimum, maximum: maximum)
    }
    
    //------------------LegendViewDelegate---------------//
    
    //------------------LegendViewDelegate---------------//
    
    
    func removeLine()
    {
        if !legendView.showView
        {
            if let sublayers = lineView.nsuiLayer?.sublayers {
                
                for child in sublayers
                {
                    child.removeFromSuperlayer()
                }
                
            }
        }
    }
    
    
    //------------------TooltipViewDelegate---------------//
    
    public func tooltipSelected(entry: ChartDataEntry?) {
        self.delegateToChartView?.tooltipSelected!(entry: entry)
    }
    
    //------------------TooltipViewDelegate---------------//
    
    public func gestureRecognizer(_ gestureRecognizer: NSUIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: NSUIGestureRecognizer) -> Bool {
        return true
    }
    
      
    
    //=================== MENU VIEW ========================//
    
    //------------------- Menu --------------------------//
    /*
    var onetime:Bool = true
    
    var lastItemIndex:Int? = nil
    
    var curItemIndex:Int? = nil
    
    func loadCustomRefreshContents() {
        
//        self.menuControl?.layer.opacity = 0
        
        for sub in (menuControl?.subviews)!
        {
            sub.removeFromSuperview()
        }
        
        for sub in refreshControl.subviews
        {
            sub.removeFromSuperview()
        }
        
        menuControl?.entries.removeAll()
        
        menuControl?.frame = refreshControl.bounds
        
        menuControl?.addViews()
        
        refreshControl.addSubview(menuControl!)
     
    }
    
    public func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
     
       // scrollView.setContentOffset(CGPoint.zero, animated: true)
        
        /*if menuControl != nil
        {
            if refreshControl.isRefreshing && !self.onetime
            {
                
               hideRefreshControl()
                
           /*     for sub in refreshControl.subviews
                {
                    sub.removeFromSuperview()
                }
                onetime = true
                
                menuControl?.menudelegate?.selectedItem!(model: (menuControl?.models[itemIndex!])!) */
            }
        } */
        
    }
    
    
    func hideRefreshControl()
    {
       
//       self.refreshControl.endRefreshing()
     
        DispatchQueue.main.async { self.refreshControl.endRefreshing() }//TO AVOID ERRORS
        
        UIView.animate(withDuration: 1.0, animations: {
            
//            self.menuControl?.transform = CGAffineTransform(scaleX: 0.25, y: 0.25)
//             self.menuControl?.layer.opacity = 0.5
            
            self.menuControl?.layer.opacity = 0.0
            
        }, completion: { finish in
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveLinear, animations: {
                
                //REMOVED ITS SUBVIEW AT THE END
                for sub in (self.menuControl?.subviews)!
                {
                    sub.removeFromSuperview()
                }
                
                for sub in self.refreshControl.subviews
                {
                    sub.removeFromSuperview()
                }
//                self.menuControl?.transform = CGAffineTransform.identity
                
                self.onetime = true
                
                self.menuLoaded = false
                
                
                self.menuControl?.menudelegate?.selectedItem!(model: (self.menuControl?.models[self.lastItemIndex!])!)
                
                self.menuControl?.layer.opacity = 0
                
//                self.menuControl?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                
            }, completion: nil)  }
            
            
        )
        

    }
    
    var initLocation:CGPoint? = nil
    
    var lastLocation:CGPoint? = nil
    
    var firstTime:Bool = true
    
    var itemWidthDiff:CGFloat = 80.0
    
    let itemWidthMin:CGFloat = 20.0
    
    var circleRadius:CGFloat = 50.0
    
    
    public func highlightItem(_ gesture: UIPanGestureRecognizer)
    {
        let location = gesture.location(in: scrollView)
        
        let tempEntries = menuControl?.entries
        
        let itemwidth = scrollView.bounds.size.width / (CGFloat)((tempEntries?.count)!)
        
        if curItemIndex != nil {
            
            if (menuControl?.models[curItemIndex!])?.type == .image
            {
                //menuControl?.entries[curItemIndex!].subviews[0].backgroundColor = NSUIColor.clear
                
//                let currentImageView =  menuControl?.entries[self.curItemIndex!].subviews[1] as! UIImageView
                
//                currentImageView.tintColor = NSUIColor.black
                
            }
            else{
                menuControl?.entries[curItemIndex!].backgroundColor = NSUIColor.clear
            }
        }
        
        let curX = location.x
        
        if (gesture.state == UIGestureRecognizerState.changed || gesture.state == UIGestureRecognizerState.began) && firstTime
        {
            
            clearColorLayer()
            
            itemWidthDiff = itemwidth / 2
            
            initLocation = location
            
            lastLocation = location
            
            firstTime = false
            
            curItemIndex = (Int((initLocation?.x)!/itemwidth))
            
            lastItemIndex = nil
            
        }
        
        if curX >= (lastLocation?.x)! && (curX - (lastLocation?.x)!) > itemWidthDiff
        {
            let temp =  (curX - (lastLocation?.x)!)/itemWidthDiff
            
            curItemIndex = (curItemIndex! +  ChartUtils.doubleToIntSafeCast(value:temp))
            
            if curItemIndex! >= (tempEntries?.count)!
            {
                curItemIndex = (tempEntries?.count)! - 1
            }
            else if curItemIndex! < 0
            {
                curItemIndex = 0
            }
            
        }
        else if curX < (lastLocation?.x)! && ((lastLocation?.x)! - curX) > itemWidthDiff
        {
            let temp =  ((lastLocation?.x)! - curX )/itemWidthDiff
            
            curItemIndex = (curItemIndex! -  ChartUtils.doubleToIntSafeCast(value:temp))
            
            if curItemIndex! >= (tempEntries?.count)!
            {
                curItemIndex = (tempEntries?.count)! - 1
            }
            else if curItemIndex! < 0
            {
                curItemIndex = 0
            }
            
        }
        
        
        if (menuControl?.models[curItemIndex!])?.type == .image
        {
                drawCirle(curX: curX)
            
            /*   menuControl?.entries[self.curItemIndex!].subviews[0].layer.cornerRadius = (menuControl?.entries[curItemIndex!].subviews[0].frame.height)!/2 */
            
        }
        else{
            
            menuControl?.entries[curItemIndex!].backgroundColor = menuControl?.selectionColor
            
            menuControl?.entries[curItemIndex!].layer.cornerRadius = (menuControl?.entries[curItemIndex!].frame.height)!/2
        }
        
        
//        let currentImageView =  menuControl?.entries[self.curItemIndex!].subviews[1] as! UIImageView
//        
//        currentImageView.tintColor = NSUIColor.white
        
        if lastItemIndex != nil && lastItemIndex != curItemIndex
        {
            lastLocation = location
            
            let lastImageView =  menuControl?.entries[self.lastItemIndex!].subviews[1] as! UIImageView
            
            lastImageView.tintColor = NSUIColor.black
        }
        
        
        lastItemIndex = curItemIndex
        
        
        
        if gesture.state == UIGestureRecognizerState.ended
        {
            
            firstTime = true
            initLocation = nil
            lastLocation = nil
        }
        
    }
    
    func changeColorOfCurrentIndex()
    {
        let currentImageView =  menuControl?.entries[self.curItemIndex!].subviews[1] as! UIImageView
        
        currentImageView.tintColor = NSUIColor.white
        
    }


    func getFrameOfCurrent() -> CGRect   {
        
        if curItemIndex == nil && (menuControl?.entries.count)! > 0
        {
            curItemIndex = (menuControl?.entries.count)! / 2
        }
        
        let index = curItemIndex!
        
        let tempEntries = menuControl?.entries
        
        //let menuWidth = (menuControl?.bounds.size.width)! / (CGFloat)((tempEntries?.count)!)
        let menuWidth = (scrollView.bounds.size.width) / (CGFloat)((tempEntries?.count)!)
        
        let menuHeight = menuControl?.bounds.size.height
        
        let x = (CGFloat(index) * menuWidth)
        
        let y:CGFloat = 0.0
        
        let rect = CGRect(x: x, y: y, width: menuWidth, height: menuHeight!)
        
        return rect
    }
    
    func getBoundOfCurrent() -> CGRect
    {
         let rect = getFrameOfCurrent()
        
         let bound = CGRect(x: 0, y: 0, width: rect.size.width, height: rect.size.height)
        
         return bound
    }
    
    func getMidPointOfCurrent() -> CGPoint
    {
        let rect = getFrameOfCurrent()
        
        let point = CGPoint(x: rect.midX, y: rect.midY)
        
        return point
    }
    
    
    func createCircleLayer() -> CAShapeLayer
    {
        
        let midPoint = getMidPointOfCurrent()
        
        let newX = (midPoint.x - circleRadius/2)
        
        let rect = CGRect(x: newX, y: 0, width: circleRadius, height: circleRadius)
        
        let path = UIBezierPath(ovalIn: rect)
        
        var layer:CAShapeLayer? = getCAShapeLayerFromMenuView()
        
        if layer == nil
        {
            layer = CAShapeLayer()
            
            layer?.bounds = rect
          
            layer?.position = getMidPointOfCurrent()
            
            layer?.path = path.cgPath
            layer?.fillColor = menuControl?.selectionColor.cgColor
           
            menuControl?.layer.addSublayer(layer!)
            
        }
        else
        {
            
        }
        
        return layer!
    }
    
    
    
    func createPath() -> UIBezierPath
    {
        let rect = getFrameOfCurrentCircle()
        
        let path = UIBezierPath(ovalIn: rect)
        
        
        return path
    }
    
    func getFrameOfCurrentCircle() -> CGRect
    {
        let midPoint = getMidPointOfCurrent()
        
        let newX = (midPoint.x - circleRadius/2)
        
        let rect = CGRect(x: newX, y: 0, width: circleRadius, height: circleRadius)
        
        return rect
    }
    
    func isIndexOnBoundary() -> Bool
    {
        var allowedToExpand = true
        
        let tempEntries = menuControl?.entries
        
        if curItemIndex! == (tempEntries?.count)! - 1 || curItemIndex! == 0
        {
           allowedToExpand = false
        }
        
        return allowedToExpand
    }

    func drawCirle(curX:CGFloat)
    {
         let tempEntries = menuControl?.entries

        let layer = createCircleLayer()
        
        if (curX >= (lastLocation?.x)! && (curX - (lastLocation?.x)!) > itemWidthDiff) || (curX < (lastLocation?.x)! && ((lastLocation?.x)! - curX) > itemWidthDiff)
        {
              animatePathChange(layer: layer, path: createPath(), animated: true)
        }
        else if curX >= (lastLocation?.x)! && (curX - (lastLocation?.x)!) < itemWidthDiff && (curX - (lastLocation?.x)!) > itemWidthMin
        {
            
            let diff = (curX - (lastLocation?.x)!)
            
            let newRect = getFrameOfCurrentCircle()
            
            var rect = CGRect(x: newRect.origin.x, y: newRect.origin.y, width: (newRect.size.width + diff), height: (newRect.size.height))
            
            if curItemIndex! == (tempEntries?.count)! - 1
            {
                rect = newRect
            }
            
            let path = UIBezierPath(ovalIn: rect)
            
            animatePathChange(layer: layer, path: path)
            
        }
        else if curX < (lastLocation?.x)! && ((lastLocation?.x)! - curX) < itemWidthDiff && ((lastLocation?.x)! - curX) > itemWidthMin
        {
            
            let diff = ((lastLocation?.x)! - curX)
            
            let newRect = getFrameOfCurrentCircle()
            
            var rect = CGRect(x: (newRect.origin.x + circleRadius), y: newRect.origin.y, width: -(newRect.size.width + diff), height: (newRect.size.height))
            
            
            if curItemIndex! == 0
            {
                rect = CGRect(x: (newRect.origin.x + circleRadius), y: newRect.origin.y, width: -(newRect.size.width), height: (newRect.size.height))
            }
            
            
            let path = UIBezierPath(ovalIn: rect)
            
            animatePathChange(layer: layer, path: path)

        }
        

    }
    
    
    func clearColorLayer()
    {

        let layer =  getCAShapeLayerFromMenuView()
        
        if layer != nil
        {
            layer?.removeFromSuperlayer()
        }
        
    }
    
    
    func getCAShapeLayerFromMenuView() -> CAShapeLayer?
    {
        let layers = menuControl?.layer.sublayers
        
        var caShapeLayer:CAShapeLayer? = nil
        
        if layers != nil && (layers?.count)! > 0
        {
            
            for layer  in layers!
            {
                if layer.isKind(of: CAShapeLayer.self)
                {
                    caShapeLayer = layer as! CAShapeLayer
                    break
                }
                
            }
            
        }
        
        return caShapeLayer

    }

    
    func  animatePathChange(layer:CAShapeLayer, path:UIBezierPath)  {
        
//        CATransaction.begin()
//        
//        let anim = CABasicAnimation(keyPath: "path")
//        
//        anim.fromValue = layer.path
//        anim.toValue = path.cgPath
//        anim.duration = 0
//        anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
//        CATransaction.setCompletionBlock(nil)
//        layer.add(anim, forKey: "path")
//        anim.isRemovedOnCompletion = false
//        CATransaction.commit()
        
        layer.path = path.cgPath

    }
    
    func  animatePathChange(layer:CAShapeLayer, path:UIBezierPath, animated:Bool)  {
        
        if animated
        {
            let completionBlock = {
                self.changeColorOfCurrentIndex()
            }

            
            CATransaction.begin()
            
            let anim = CABasicAnimation(keyPath: "path")
            
            anim.fromValue = layer.path
            anim.toValue = path.cgPath
            anim.duration = 0
            anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
            CATransaction.setCompletionBlock(completionBlock)
            layer.add(anim, forKey: "path")
           // anim.isRemovedOnCompletion = false
            CATransaction.commit()
            layer.path = path.cgPath
        }
        else
        {
            layer.path = path.cgPath
        }
    
        
    }

    func reloadMenu(_ scrollView: UIScrollView)
    {
        if !menuLoaded
        {
            
            loadCustomRefreshContents()
     
//            self.menuControl?.transform = CGAffineTransform(scaleX: 0.25, y: 0.25)
            
            self.menuControl?.layer.opacity = 0.0
                
            menuLoaded = true
            
            
            UIView.animate(withDuration: 1.0, animations: {
                
                //                      self.menuControl?.transform = CGAffineTransform(scaleX: 0.25, y: 0.25)
                
                
                self.menuControl?.layer.opacity = 1.0
                
                 self.changeColorOfCurrentIndex() // TO CHECK IN
                
            }, completion: { finish in
                
                UIView.animate(withDuration: 1.0, delay: 0, options: .curveLinear, animations: {
                    
//                    self.menuControl?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                    
                    self.menuControl?.layer.opacity = 1.0
                    
                    self.onetime = false
                    
                     self.changeColorOfCurrentIndex() // TO CHECK IN
                    
                }, completion: nil)  }
                
            )
        }

    }
    
    var menuLoaded:Bool = false
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
//         refreshControl.removeFromSuperview()
        
        if menuControl != nil
        {
            
            
            if self.onetime && (self.refreshControl.frame.origin.y < -(self.refreshControl.bounds.size.height + 5))
            {
                self.refreshControl.beginRefreshing()
            }
            
            if self.refreshControl.bounds.width > 0 && getCAShapeLayerFromMenuView() == nil
            {
                menuControl?.frame = refreshControl.bounds
                
                menuControl?.initializeForTemp()
                
                let _ = createCircleLayer()
               
                self.scrollView.panGestureRecognizer.addTarget(self, action: #selector(self.highlightItem))
                
                
            }
            
            
            if refreshControl.isRefreshing
            {
                if onetime
                {
                    
                     reloadMenu(scrollView)
                   /* loadCustomRefreshContents()

                    
                    self.menuControl?.transform = CGAffineTransform(scaleX: 0.25, y: 0.25)
                
                    
                    self.scrollView.panGestureRecognizer.addTarget(self, action: #selector(self.highlightItem))

                    
                   UIView.animate(withDuration: 1.0, animations: {
                        
//                      self.menuControl?.transform = CGAffineTransform(scaleX: 0.25, y: 0.25)
                        
                    }, completion: { finish in
                        
                        UIView.animate(withDuration: 1.0, delay: 0, options: .curveLinear, animations: {
                            
                       self.menuControl?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                            
                        self.onetime = false
                        
                        }, completion: nil)  }
                        
                    ) */


                }
            }
            
            if !self.onetime && self.refreshControl.isRefreshing && (self.refreshControl.frame.origin.y > -(self.refreshControl.bounds.size.height ))
            {
                hideRefreshControl()
            }
        }
        
    }
    
    */
    
    // ===================DRILL / FILTER MENU VIEW ===================//
    
    var drillDownViewVisible:Bool = false
    
    open var drillDownHeightFactor:CGFloat = 0.00
    
    var drillFilterEntryList:[DrillFilterMenuEntry] = []
    
    public func prepareDrillFilterMenuEntries() -> [DrillFilterMenuEntry] {
        return drillFilterEntryList
    }
    
    
    func removeDrillFilterMenuEntries(menuEntriesToRemove:[DrillFilterMenuEntryView])
    {
        let count = menuEntriesToRemove.count
        
        if count == 0
        {
            return
        }
        
        for i in 0 ..< count
        {
            removeEntryFromDrillView(viewToRemove: menuEntriesToRemove[i])
        }
    }
    
    func getFilterMenuEntriesToRemoveForDrill() -> [DrillFilterMenuEntryView]
    {
        var menuEntriesToDelete:[DrillFilterMenuEntryView] = []
        let menuSubViews = self.drillDownView.scrollContentView.subviews
        let count = menuSubViews.count
        if count == 0
        {
            return menuEntriesToDelete
        }
        
        
        for i in stride(from: count-1, through: 0, by: -1)
        {
            let subView = menuSubViews[i]
            let drillFilterMenuEntryView = subView as! DrillFilterMenuEntryView
            if drillFilterMenuEntryView.menuType == DrillFilterMenuType.filter
            {
                menuEntriesToDelete.append(drillFilterMenuEntryView)
            }
        }
        
        
        return menuEntriesToDelete
    }
    
    func getDrillMenuEntriesToRemoveForSelection(viewToRemove:DrillFilterMenuEntryView) -> [DrillFilterMenuEntryView]
    {
        var menuEntriesToDelete:[DrillFilterMenuEntryView] = []
        
        if viewToRemove.menuType == DrillFilterMenuType.filter
        {
            return menuEntriesToDelete
        }
        
        let menuSubViews = self.drillDownView.scrollContentView.subviews
        
        let indexToRemove = menuSubViews.firstIndex(of: viewToRemove)
        
        if indexToRemove == menuSubViews.count - 1
        {
            return menuEntriesToDelete
        }
        
        for i in stride(from: menuSubViews.count - 1, through: (indexToRemove! + 1), by: -1)
        {
            let subView = menuSubViews[i]
            let drillFilterMenuEntryView = subView as! DrillFilterMenuEntryView
            menuEntriesToDelete.append(drillFilterMenuEntryView)
        }
        
        return menuEntriesToDelete
    }
    
    public func drillFilterMenuSelected(drillFilterMenuEntryView: DrillFilterMenuEntryView) {
        
        
        let entry = drillFilterMenuEntryView.drillFilterMenuEntry?.chartDataEntry
        
        if drillFilterMenuEntryView.drillFilterMenuEntry?.menuType == .filter
        {
            removeEntryFromDrillView(viewToRemove: drillFilterMenuEntryView)
            
            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(0.2*1000)), execute: {
                
                self.toggleDrillFilterMenuView()
                
                DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(0.2*1000)), execute: {
                    
                    self.delegateToChartView?.filterEntrySelected!(entry: entry)
                })
            })
        }
        else
        {
            let menuEntriesToRemove = getDrillMenuEntriesToRemoveForSelection(viewToRemove: drillFilterMenuEntryView)
            
            removeOtherEntriesFromDrillView(menuEntriesToRemove: menuEntriesToRemove, viewToRemove: drillFilterMenuEntryView)
            
            self.delegateToChartView?.drillEntrySelected!(entry: entry![0], level: (drillFilterMenuEntryView.drillFilterMenuEntry?.dataLevel)!)
            
            self.chartViewDelegate?.drillReverted?(chartView: self.chartView.chart, selectedEntry: entry![0], index: (drillFilterMenuEntryView.drillFilterMenuEntry?.dataLevel)!)
            
            toggleDrillFilterMenuView()
        }
        
    }
    

    func filterMenuEntryAdded(_ chartView: ChartViewBase, entry: [ChartDataEntry], level: Int)
    {
        
        let drillEntry = prepareDrillFilterEntry(chartView: chartView, entry: entry, level: level, menuType: .filter)
        drillFilterEntryList.append(drillEntry)
        
        toggleDrillFilterMenuView()
        
        self.drillDownView.refreshData()
        
    }
    
    func removeEntryFromDrillView(viewToRemove: DrillFilterMenuEntryView)
    {
        
        let indexToRemove = self.drillDownView.scrollContentView.subviews.firstIndex(of: viewToRemove)
        
        let subViews = self.drillDownView.scrollContentView.subviews
        let subViewCount = subViews.count
        
        let _ = self.drillFilterEntryList.remove(at: indexToRemove!)
        
        #if os(OSX)
        NSAnimationContext.runAnimationGroup({ context in
            context.duration = 0.2
            viewToRemove.animator().alphaValue = 0
        }) {
            
            var oldConstraint:NSLayoutConstraint? = nil
            var newConstraint:NSLayoutConstraint? = nil
            
            
            if indexToRemove == 0 && subViewCount == 1
            {
                //JUST REMOVE THE ELEMENT
            }
            else
            {
                self.drillDownView.addViews(drillEntryList: self.drillFilterEntryList)
            }
            /*else if indexToRemove == 0 && subViewCount > 1
            {
                
                let nextView = subViews[indexToRemove! + 1]
                
                oldConstraint =  nextView.leadingAnchor.constraint(equalTo: viewToRemove.trailingAnchor, constant: 10)
                
                newConstraint = nextView.leadingAnchor.constraint(equalTo: self.drillDownView.scrollContentView.leadingAnchor, constant: 10)
            }
            else if indexToRemove == subViewCount - 1 && subViewCount > 1
            {
                let previousView = subViews[indexToRemove! - 1]
                
                newConstraint = previousView.trailingAnchor.constraint(equalTo: self.drillDownView.scrollContentView.trailingAnchor, constant: -10)
                
            }
            else
            {
                
                let previousView = subViews[indexToRemove! - 1]
                
                let nextView = subViews[indexToRemove! + 1]
                
                oldConstraint =  nextView.leadingAnchor.constraint(equalTo: viewToRemove.trailingAnchor, constant: 10)
                
                newConstraint = nextView.leadingAnchor.constraint(equalTo: previousView.trailingAnchor, constant: 10)
                
                
            }
            
            
            //            let oldConstraint =  nextView.leadingAnchor.constraint(equalTo: viewToRemove.trailingAnchor, constant: 10)
          
            //            let newConstraint = nextView.leadingAnchor.constraint(equalTo: previousView.trailingAnchor, constant: 10)
            
            //            viewToRemove.widthAnchor.constraint(equalToConstant: 0).isActive = true
            
            if oldConstraint != nil
            {
                NSLayoutConstraint.deactivate([oldConstraint!])
            }
            if newConstraint != nil
            {
                NSLayoutConstraint.activate([newConstraint!])
            }*/
            
            
            NSAnimationContext.runAnimationGroup({ context in
                
                context.duration = 1.0
                
                self.drillDownView.layoutSubtreeIfNeeded()
                
                viewToRemove.removeFromSuperview()
            })
        }
        #endif
        
        #if os(iOS)
        UIView.animate(withDuration: 0.2, animations: {
            viewToRemove.alpha = 0
        }) { (finished) in
            
            var oldConstraint:NSLayoutConstraint? = nil
            var newConstraint:NSLayoutConstraint? = nil
            
            
            if indexToRemove == 0 && subViewCount == 1
            {
                //JUST REMOVE THE ELEMENT
            }
            else if indexToRemove == 0 && subViewCount > 1
            {
                
                let nextView = subViews[indexToRemove! + 1]
                
                oldConstraint =  nextView.leadingAnchor.constraint(equalTo: viewToRemove.trailingAnchor, constant: 10)
                
                newConstraint = nextView.leadingAnchor.constraint(equalTo: self.drillDownView.scrollContentView.leadingAnchor, constant: 10)
            }
            else if indexToRemove == subViewCount - 1 && subViewCount > 1
            {
                let previousView = subViews[indexToRemove! - 1]
                
                newConstraint = previousView.trailingAnchor.constraint(equalTo: self.drillDownView.scrollContentView.trailingAnchor, constant: -10)
                
            }
            else
            {
                
                let previousView = subViews[indexToRemove! - 1]
                
                let nextView = subViews[indexToRemove! + 1]
                
                oldConstraint =  nextView.leadingAnchor.constraint(equalTo: viewToRemove.trailingAnchor, constant: 10)
                
                newConstraint = nextView.leadingAnchor.constraint(equalTo: previousView.trailingAnchor, constant: 10)
                
                
            }
            
            
            //            let oldConstraint =  nextView.leadingAnchor.constraint(equalTo: viewToRemove.trailingAnchor, constant: 10)
          
            //            let newConstraint = nextView.leadingAnchor.constraint(equalTo: previousView.trailingAnchor, constant: 10)
            
            //            viewToRemove.widthAnchor.constraint(equalToConstant: 0).isActive = true
            
            if oldConstraint != nil
            {
                NSLayoutConstraint.deactivate([oldConstraint!])
            }
            if newConstraint != nil
            {
                NSLayoutConstraint.activate([newConstraint!])
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                
                self.drillDownView.layoutIfNeeded()
                
                viewToRemove.removeFromSuperview()
            })
            
        }
        #endif
    }
    
    
    func removeOtherEntriesFromDrillView(menuEntriesToRemove:[DrillFilterMenuEntryView], viewToRemove: DrillFilterMenuEntryView)
    {
        
        for menuEntry in menuEntriesToRemove
        {
            let otherToRemoveIndex = self.drillDownView.scrollContentView.subviews.firstIndex(of: menuEntry)
            let drillFilterMenuEntry = self.drillFilterEntryList.remove(at: otherToRemoveIndex!)
            if menuEntry.menuType == DrillFilterMenuType.filter
            {
                for entry in drillFilterMenuEntry.chartDataEntry
                {
                    entry.filterEnabled = false
                }
            }
        }
        
        let indexToRemove = self.drillDownView.scrollContentView.subviews.firstIndex(of: viewToRemove)
        let _ = self.drillFilterEntryList.remove(at: indexToRemove!)
        let subViews = self.drillDownView.scrollContentView.subviews
        let subViewCount = subViews.count
        let othersCount = menuEntriesToRemove.count
        
        #if os(OSX)
        NSAnimationContext.runAnimationGroup({ context in
            context.duration = 0.5
            for menuEntry in menuEntriesToRemove
            {
                menuEntry.animator().alphaValue = 0
            }
            viewToRemove.animator().alphaValue = 0
        }) {
            
            let oldConstraint:NSLayoutConstraint? = nil
            var newConstraint:NSLayoutConstraint? = nil
            
            
            if indexToRemove == subViewCount - 1 && subViewCount > 1 || (indexToRemove! > 0 && indexToRemove! <= (subViewCount - (othersCount + 1)))
            {
                let previousView = subViews[indexToRemove! - 1]
                
                newConstraint = previousView.trailingAnchor.constraint(equalTo: self.drillDownView.scrollContentView.trailingAnchor, constant: -10)
                
            }
            
            if oldConstraint != nil
            {
                NSLayoutConstraint.deactivate([oldConstraint!])
            }
            if newConstraint != nil
            {
                NSLayoutConstraint.activate([newConstraint!])
            }
            
            NSAnimationContext.runAnimationGroup({ context in
                
                context.duration = 1.0
                
                self.drillDownView.layoutSubtreeIfNeeded()
                
                for menuEntry in menuEntriesToRemove
                {
                    menuEntry.removeFromSuperview()
                }
                
                viewToRemove.removeFromSuperview()
            })
        }
        #endif
        
        #if os(iOS) || os(tvOS)
        UIView.animate(withDuration: 0.5, animations: {
            for menuEntry in menuEntriesToRemove
            {
                menuEntry.alpha = 0
            }
            viewToRemove.alpha = 0
        }) { (finished) in
            
            let oldConstraint:NSLayoutConstraint? = nil
            var newConstraint:NSLayoutConstraint? = nil
            
            
            if indexToRemove == subViewCount - 1 && subViewCount > 1 || (indexToRemove! > 0 && indexToRemove! <= (subViewCount - (othersCount + 1)))
            {
                let previousView = subViews[indexToRemove! - 1]
                
                newConstraint = previousView.trailingAnchor.constraint(equalTo: self.drillDownView.scrollContentView.trailingAnchor, constant: -10)
                
            }
            
            if oldConstraint != nil
            {
                NSLayoutConstraint.deactivate([oldConstraint!])
            }
            if newConstraint != nil
            {
                NSLayoutConstraint.activate([newConstraint!])
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                
                self.drillDownView.layoutIfNeeded()
                
                for menuEntry in menuEntriesToRemove
                {
                    menuEntry.removeFromSuperview()
                }
                
                viewToRemove.removeFromSuperview()
            })
            
        }
        #endif
    }
    
    func prepareDrillFilterEntry(chartView: ChartViewBase, entry: [ChartDataEntry], level: Int, menuType: DrillFilterMenuType) -> DrillFilterMenuEntry
    {
        let drillFilterMenu = DrillFilterMenuEntry()
        drillFilterMenu.chartData = chartView.data
        drillFilterMenu.chartDataEntry = entry
        drillFilterMenu.dataLevel = level
        drillFilterMenu.dataSetIndex = 0
        drillFilterMenu.menuType = menuType
        
        return drillFilterMenu
    }
    
    func toggleDrillFilterMenuView()
    {
        var toOpacityVal:Float = 1.0
        
        self.currentOrientation = .Undefined
        
        var showView:Bool = true
        
        if !drillDownViewVisible && self.drillFilterEntryList.count > 0
        {
            showView = true
        }
        
        if self.drillFilterEntryList.count == 0 && drillDownViewVisible
        {
            showView = false
        }
        
        
        if !drillDownViewVisible && showView //TO SHOW
        {
            self.drillDownView.nsuiLayer?.opacity = 0
            drillDownViewVisible = true
            toOpacityVal = 1.0
            Log.info("SHOW DRILLVIEW Chart value selected \(self.bounds)")
            
            
            NSLayoutConstraint.deactivate([self.drillDownHeightAnchor, self.tooltipViewHeightAnchor])
            
//            self.drillDownHeightAnchor.constant = (0.08 * self.bounds.size.height)
            drillDownHeightFactor = 0.06
            self.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: drillDownHeightFactor)
            
            if toolTipView.showView
            {
                self.tooltipHeightFactor = (self.tooltipHeightFactor! - self.drillDownHeightFactor)
                
                self.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipHeightFactor!)
            }
            
            NSLayoutConstraint.activate([drillDownHeightAnchor, self.tooltipViewHeightAnchor])
//            #if !os(OSX)
            self.updateConstraints()
//            #endif
        }
        else if !showView //TO HIDE
        {
            Log.info("HIDE DRILLVIEW Chart value selected \(self.bounds)")
            self.drillDownView.nsuiLayer?.opacity = 1.0
            drillDownViewVisible = false
            toOpacityVal = 0.0
            
            NSLayoutConstraint.deactivate([self.drillDownHeightAnchor, self.tooltipViewHeightAnchor])
            if toolTipView.showView
            {
                self.tooltipHeightFactor = (self.tooltipHeightFactor! + self.drillDownHeightFactor)
                
                self.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipHeightFactor!)
            }
            
            
            drillDownHeightFactor = 0.0
//            self.drillDownHeightAnchor.constant = 0.0
            self.drillDownHeightAnchor = drillDownView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: drillDownHeightFactor)
            
            NSLayoutConstraint.activate([drillDownHeightAnchor, self.tooltipViewHeightAnchor])
//            #if !os(OSX)
            self.updateConstraints()
//            #endif
        }
        
        //        self.layoutIfNeeded()
        
        #if os(iOS) || os(tvOS)
        UIView.animate(withDuration: 0.2, delay: 0, options: .allowUserInteraction, animations: {
            //
           // self.layoutIfNeeded()
            
            self.drillDownView.layer.opacity = toOpacityVal
            
        }, completion: { finish in
            //            self.setNeedsUpdateConstraints()
            
        }
        )
        #else
        // NSView fade-out animation
        NSAnimationContext.runAnimationGroup({ context in
            // 1 second animation
            context.duration = 0.2

            // The view will animate to alphaValue 0
//            self.drillDownView.animator().alphaValue = CGFloat(toOpacityVal)
            self.drillDownView.nsuiLayer?.opacity = toOpacityVal
        }) {
            // Handle completion
        }
        #endif
        
        
    }
    
    // ===================DRILL / FILTER MENU VIEW ===================//
    
    
    func toggleTooltipAndLegendView(showTooltip:Bool)
    {
        
        if !self.legendToolTipToggleEnabled
        {
            return
        }
        
        var toggleRequired:Bool = true
        var tooltipOpacityVal:Float = 1.0
        var legendOpacityVal:Float = 1.0
        
        if showTooltip
        {
            if self.toolTipView.showView
            {
                toggleRequired = false
            }
            else
            {
                self.toolTipView.showView = true
                self.legendView.showView = false
            }
        }
        else
        {
            if !self.toolTipView.showView
            {
                toggleRequired = false
            }
            else
            {
                self.toolTipView.showView = false
                self.legendView.showView = true
            }
        }
        
        if !toggleRequired
        {
           return
        }
    
        //NSLayoutConstraint.deactivate([self.tooltipViewHeightAnchor,  self.chartViewHeightAnchor,self.legendViewHeightAnchor])
        NSLayoutConstraint.deactivate([self.tooltipViewHeightAnchor, self.legendViewHeightAnchor])
        
        if self.toolTipView.showView
        {
            self.toolTipView.nsuiLayer?.opacity = 0
            self.legendView.nsuiLayer?.opacity = 1
            
            tooltipOpacityVal = 1
            legendOpacityVal = 0
            
            self.tooltipHeightFactor = 0.15
            //self.chartHeightFactor = self.chartHeightFactor! - (self.tooltipHeightFactor!)
            
            //self.chartHeightFactor = self.chartHeightFactor! + (self.legendHeightFactor!)
            self.legendHeightFactor = 0.0
            
        }
        else
        {
            self.toolTipView.nsuiLayer?.opacity = 1
            self.legendView.nsuiLayer?.opacity = 0
            
            tooltipOpacityVal = 0
            legendOpacityVal = 1
           
//            self.legendHeightFactor = 0.08
            self.legendHeightFactor = 0.15
            
            if !self.isPortraitOrientation()
            {
                self.legendHeightFactor = 0.14
            }
            
            //self.chartHeightFactor = self.chartHeightFactor! - (self.legendHeightFactor!)
            
            //self.chartHeightFactor = self.chartHeightFactor! + (self.tooltipHeightFactor!)
            self.tooltipHeightFactor = 0.0
            
        }

        self.tooltipViewHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: tooltipHeightFactor!)

        self.legendViewHeightAnchor = legendView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: legendHeightFactor!)

        //self.chartViewHeightAnchor = chartView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: chartHeightFactor!)
        
        //NSLayoutConstraint.activate([self.tooltipViewHeightAnchor, self.chartViewHeightAnchor,self.legendViewHeightAnchor])
        NSLayoutConstraint.activate([self.tooltipViewHeightAnchor ,self.legendViewHeightAnchor])
        
    
        
        /*UIView.animate(withDuration: 1, delay: 0, options: .allowUserInteraction, animations: {
            
            //(self.chartView.chart as! BarLineChartViewBase).includeLayer = false
            
            self.layoutIfNeeded()
        
            self.legendView.layer.opacity = legendOpacityVal
            
            self.toolTipView.layer.opacity = tooltipOpacityVal
            
            self.lineView.layer.opacity = legendOpacityVal
            
            
        }, completion: { finish in
            
            //(self.chartView.chart as! BarLineChartViewBase).includeLayer = true
    
            //self.chartView.chart.setNeedsDisplay()
            
        }
       )*/
        
        #if !os(OSX)
        self.layoutIfNeeded()
        #else
        self.layoutSubtreeIfNeeded()
        #endif
            
    
        self.legendView.nsuiLayer?.opacity = legendOpacityVal
        
        self.toolTipView.nsuiLayer?.opacity = tooltipOpacityVal
        
        self.lineView.nsuiLayer?.opacity = legendOpacityVal
        
    }
    
    

     //=================== MENU VIEW ========================//
    
    /* func legendSelected(indexPath: IndexPath)P
     {
     
     let entries = self.chartView.chart.legend.entries
     let entry = entries[indexPath.item]
     
     if entry.enabled
     {
     
     
     let pieChart = self.chartView.chart as! PieChartView
     let rotAngle = pieChart.rotationAngle
     let drawAngle = pieChart.drawAngles[indexPath.item]
     let absAngle = pieChart.absoluteAngles[indexPath.item]
     
     
     
     let endAngle = rotAngle + absAngle
     
     
     let startAngle = (endAngle - drawAngle)
     
     var midAngle:CGFloat =  ((startAngle + endAngle) / 2.0)
     
     
     
     if midAngle > 360
     {
     midAngle = midAngle - 360
     }
     
     let pt = pieChart.getPosition(center: pieChart.centerCircleBox, dist: pieChart.radius/2, angle: midAngle)
     
     let high = pieChart.getHighlightByTouchPoint(pt)
     
     if high != nil {
     pieChart.pieType.taprotate(high: high!,location: pt,rotation: false,addangle:0)
     }
     
     
     
     
     
     }
     
     }
     
     open func animatorUpdated(_ chartAnimator: Animator)
     {
     let pieChart = self.chartView.chart as! PieChartView
     pieChart.calcMinMax()
     pieChart.setNeedsDisplay()
     
     }
     
     open func animatorStopped(_ chartAnimator: Animator)
     {
     
     }
     
     
     func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
   
     let pieChart = self.chartView.chart as! PieChartView
     
     let dataSet = self.chartView.chart.data?.dataSets[0]
     let chartEntry = dataSet?.entryForIndex(indexPath.item)
     
     
     chartEntry?.enabled = true
     
     
     if _spinAnimator != nil
     {
     _spinAnimator.stop()
     }
     
     let originalVal:CGFloat = CGFloat((chartEntry?.oldValue)!)
     
     _spinAnimator = Animator()
     _spinAnimator.delegate = self
     
     _spinAnimator.updateBlock = {
     chartEntry?.y = Double((originalVal * CGFloat(self._spinAnimator.phaseX)) + CGFloat(0))
     pieChart.data?.setDrawValues(false)
     pieChart.highlightValue(nil, callDelegate: true)
     
     }
     _spinAnimator.stopBlock = {
     self._spinAnimator = nil
     pieChart.pieType.rotationStops()
     }
     
     _spinAnimator.animate(xAxisDuration: 1, easingOption: .linear)
     
     
     }
     
     func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
  
     let pieChart = self.chartView.chart as! PieChartView
     
     let dataSet = self.chartView.chart.data?.dataSets[0]
     let chartEntry = dataSet?.entryForIndex(indexPath.item)
     
     chartEntry?.enabled = false
     
     if _spinAnimator != nil
     {
     _spinAnimator.stop()
     }
     
     let originalVal:CGFloat = CGFloat((chartEntry?.y)!)
     
     
     _spinAnimator = Animator()
     _spinAnimator.delegate = self
     
     
     _spinAnimator.updateBlock = {
     chartEntry?.y = Double(originalVal - (originalVal * CGFloat(self._spinAnimator.phaseX)))
     pieChart.highlightValue(nil, callDelegate: true)
     pieChart.data?.setDrawValues(false)
     
     }
     
     _spinAnimator.stopBlock = {
     self._spinAnimator = nil
     pieChart.calcMinMax()
     pieChart.setNeedsDisplay()
     pieChart.pieType.rotationStops()
     
     }
     
     _spinAnimator.animate(xAxisDuration: 1, easingOption: .linear)
     
     
     } */
    
    //------------------LegendViewDelegate---------------//
    
}

extension ChartContainer: RangeSliderDelegate {
    
    public func rangeSelected(minimum: Double, maximum: Double) {
        
        var min = minimum
        var max = maximum
        
        
        if minimum < chartView.chart.xAxis.axisMinimum {
            min = chartView.chart.xAxis.axisMinimum
        }
            
        if maximum > chartView.chart.xAxis.axisMaximum {
            max = chartView.chart.xAxis.axisMaximum
        }
        
        if minimum > chartView.chart.xAxis.axisMaximum {
            min = chartView.chart.xAxis.axisMaximum
        }

        if maximum < chartView.chart.xAxis.axisMinimum {
            max = chartView.chart.xAxis.axisMinimum
        }
        
        chartView.chart.showViewRange(from: min, to: max)
    }
    
}


public enum Orientation
{
    case Undefined
    case Portrait
    case Landscape
}

public enum LegendOrientation
{
    case Horizontal
    case Vertical
}

public enum LegendRenderType
{
    case step
    case zigzag
}

public enum LegendPosition
{
    case top
    case bottom
    case left
    case right
}

public enum OverviewPosition
{
    case bottom
    case left
    case right
}


/*open class ChartContainerScrollView : UIScrollView
{
    open override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        
        let view = super.hitTest(point, with: event)
        
        if (view?.isKind(of: ChartViewBase.self))!
        {
            self.isScrollEnabled = false
        }
        else
        {
            self.isScrollEnabled = false
        }
        
        return view
 }
} */
