//
//  LineView.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 17/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif


open class LineView: NSUIView
{
    weak var titleView:TitleView?
    weak var chartContainer:ChartContainer?
    
    fileprivate var _showView = true
    
    open var showView:Bool
    {
        set
        {
            self._showView = newValue
        }
        get
        {
            return self._showView
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        // self.addLine(frame: CGRect.zero)
    }
    
    
    
    required public init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
  
    func addLine(frame:CGRect)
    {
   
        if let sublayers = self.nsuiLayer?.sublayers {
            
            for child in sublayers
            {
                child.removeFromSuperlayer()
            }
            
        }
        
        
        self.frame = frame

        let path = CGMutablePath()//UIBezierPath()
        path.move(to: CGPoint(x: (5/100)*self.bounds.width, y: self.bounds.height/2))
        path.addLine(to: CGPoint(x: self.bounds.width - ((5/100)*self.bounds.width), y: self.bounds.height/2))
        /*path.move(to: CGPoint(x: 0, y: self.bounds.height/2))
        path.addLine(to: CGPoint(x: self.bounds.width, y: self.bounds.height/2))*/
        
        //design path
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path//.cgPath
        shapeLayer.strokeColor = NSUIColor.gray.withAlphaComponent(0.3).cgColor
        shapeLayer.lineWidth = 1.0
        
        if showView
        {
            self.nsuiLayer?.addSublayer(shapeLayer)
        }
    }
    
#if os(OSX)
    override open func layout() {
        addSubViews()
    }
#elseif os(iOS) || os(tvOS)
    override open func layoutSubviews() {
        addSubViews()
    }
#endif
    
    fileprivate func addSubViews() {
        addLine(frame: self.frame)
        
        titleView?.removeLine()
        chartContainer?.removeLine()
    }
    
}
