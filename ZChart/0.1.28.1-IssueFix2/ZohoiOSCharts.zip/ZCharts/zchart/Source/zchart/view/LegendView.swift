//
//  LegendView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

@objc
 public protocol LegendViewDelegate
 {
/* @objc optional func legendSelected(indexPath: IndexPath)
    
   @objc optional func legendLongPressed(indexPath: IndexPath)*/
 
 @objc optional func legendDisabled(indexPath: IndexPath, entry: LegendEntry)
 
 @objc optional func legendEnabled(indexPath: IndexPath, entry: LegendEntry)
    
 @objc optional func legendRangeSelected(minimum:Double,maximum:Double)
 
 }

#if os(iOS) || os(tvOS)
public class LegendView: UIView,UICollectionViewDelegateFlowLayout, LegendCellDelegate, UIGestureRecognizerDelegate, RangeSliderDelegate {
    
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
    
    open var legend:ChartLegendObject = ChartLegendObject()
    
    open weak var delegate: LegendViewDelegate?
    
    let maskLayer = CAGradientLayer()
    
    var legendEntries:[LegendEntry]? = nil
    
    open var position:LegendPosition
    {
        set
        {
            self.legend.legendPosition = newValue
        }
        get
        {
            return self.legend.legendPosition
        }
    }
    
    open var showView:Bool
    {
        set
        {
            self.legend.legendEnabled = newValue
        }
        get
        {
            return self.legend.legendEnabled
        }
    }
    
    open var type:LegendType {
        set
        {
            self.legend.type = newValue
        }
        get
        {
            return self.legend.type
        }
    }
    
    var onScroll = false
    
    fileprivate var sectionInsets = UIEdgeInsets(top: 10.0, left: 20.0, bottom: 10.0, right: 20.0)
    
    fileprivate var sectionMinimumLineSpacing:CGFloat = 10.0
    
    fileprivate var minimumInteritemSpacing:CGFloat = 10.0
    
    open var collectionView:UICollectionView? = nil
    
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    
    var maxCellSize:CGSize = CGSize.zero
    
    var panUpGestureRecognizer: UIPanGestureRecognizer!
    
    var longPressRecognizer: UILongPressGestureRecognizer!
    
    var tapRecognizer:UITapGestureRecognizer!
    
    open var rangeSlider:RangeSlider? = nil
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.initialize()
    }
    
    required public init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func resetOrientation()
    {
        
        if self.legend.legendOrientation == .Horizontal
        {
            
            maskLayer.startPoint = CGPoint(x: 0, y: 0.5)
            maskLayer.endPoint = CGPoint(x:1, y:0.5)
            
            let layout =  layout//self.collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
            layout.scrollDirection = .horizontal
            
            
            sectionInsets = UIEdgeInsets(top: 5.0, left: 20.0, bottom: 5.0, right: 20.0)
            
            sectionMinimumLineSpacing = 5
            
            self.collectionView?.collectionViewLayout = layout
            
            Log.info("Horizontal Orientation ")
            
        }
        else
        {
            
            maskLayer.startPoint = CGPoint(x: 0.5, y: 0)
            maskLayer.endPoint = CGPoint(x:0.5, y:1)
            
            if (legend.legendRenderType == .zigzag){
                collectionView?.collectionViewLayout = ZCollectionViewLayout()
            }
                                                
            sectionInsets = UIEdgeInsets(top: 20.0, left: 20.0, bottom: 20.0, right: 20.0)
            
            sectionMinimumLineSpacing = 10
            
            if let layout =  self.collectionView?.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .vertical
                layout.minimumInteritemSpacing = minimumInteritemSpacing
                layout.sectionInset = sectionInsets
            }
            
            Log.info("Vertical Orientation ")
            
        }
        
    }
    
    func isPortraitOrientation() -> Bool
    {
        return UIDevice.current.orientation.isPortrait
    }
    
    func initialize()
    {
        
        
        collectionView  = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        
        self.addSubview(collectionView!)
        
        collectionView?.translatesAutoresizingMaskIntoConstraints = false
        
        resetOrientation()
        
        collectionView?.backgroundColor = NSUIColor.clear
        
        collectionView?.delegate = self
        
        collectionView?.dataSource = self
        
        collectionView?.register(LegendCell.self, forCellWithReuseIdentifier: "LegendCell")
        
        //  panUpGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
        
        longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressed))
        
        
        // longPressRecognier.minimumPressDuration = 0.5
        
        longPressRecognizer?.delegate = self
        
//        collectionView?.showsHorizontalScrollIndicator = false
        
        // panUpGestureRecognizer?.delegate = self
        
        collectionView?.addGestureRecognizer(longPressRecognizer)
        
        //  collectionView?.addGestureRecognizer(tapRecognizer)
        
        // collectionView?.addGestureRecognizer(panUpGestureRecognizer)
        
        
        self.legend.orientationChangedClosure = { [weak self] in
            guard let selfReference = self else {
                return
            }
            selfReference.resetOrientation()
        }
        
        self.legend.typeChangedClosure = { [weak self] in
            guard let selfReference = self else {
                return
            }
            selfReference.changeLegendType()
        }
    }
    
    fileprivate func changeLegendType() {
        collectionView?.removeFromSuperview()
        collectionView = nil
        
        rangeSlider?.removeFromSuperview()
        rangeSlider = nil
        
        if type == .continous {
            rangeSlider = RangeSlider(frame: CGRect.zero)
            self.addSubview(rangeSlider!)
            rangeSlider?.translatesAutoresizingMaskIntoConstraints = false
            rangeSlider?.delegate = self
            rangeSlider?.thumbShape.shapeType = .circle
            
            rangeSlider?.unHighlightShape.shapeType = .Rect
            rangeSlider?.unHighlightShape.holeColor = NSUIColor(white: 0.9, alpha: 1.0)
            rangeSlider?.unHighlightShape.strokeColor = NSUIColor.darkGray
            
            let centerXAnchor = rangeSlider!.centerXAnchor.constraint(equalTo: self.centerXAnchor)
            let centerYAnchor = rangeSlider!.centerYAnchor.constraint(equalTo: self.centerYAnchor)
            let heightAnchor = rangeSlider!.heightAnchor.constraint(equalToConstant: self.bounds.height )
            let widthAnchor = rangeSlider!.widthAnchor.constraint(equalToConstant: self.bounds.width )
    
            NSLayoutConstraint.activate([centerXAnchor,centerYAnchor,heightAnchor, widthAnchor])
        }else {
            
            self.initialize()
            
        }
    }
    
    public func rangeSelected(minimum: Double, maximum: Double) {
        self.delegate?.legendRangeSelected!(minimum: minimum, maximum: maximum)
    }
    
    // --------------UICollectionViewDelegateFlowLayout------------------------- //
    public func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var height = collectionView.frame.size.height - sectionInsets.top - sectionInsets.bottom
        
        if indexPath.item == 0
        {
            totalCellWidth = CGFloat(0)
            totalCellHeight = CGFloat(0)
        }
        
        _ = CGSize(width: maxCellSize.width, height: height)
        
        let entry = legendEntries?[indexPath.item]
        
        if entry == nil
        {
            return maxCellSize
        }
        
        let text = legend.legendFormatter?.getFromattedValue?(legendEntry: entry!) ?? entry!.label
        
        if text == nil {
            return CGSize(width: totalCellWidth, height: totalCellHeight)
        }
        
        let size: CGSize = (text)!.size(withAttributes: [NSAttributedString.Key.font: self.legend.legendFont])
        
//        let newHeight = maxCellSize.height + sectionInsets.top //+ sectionInsets.bottom
//
//        let newWidth = size.width + newHeight + legend.formLabelSpacing
        
        if self.legend.legendOrientation == .Horizontal
        {
            let newHeight = height
            
            let newWidth = size.width + newHeight + legend.formLabelSpacing
            
            //return newSize
//            return CGSize(width: newWidth, height: height)
            totalCellWidth += newWidth
            totalCellHeight += newHeight
            return CGSize(width: newWidth, height: newHeight)
        }
        else{
            //return maxCellSize
            height = maxCellSize.height //+ maxCellSize.height / 2
            var newSize = CGSize(width: maxCellSize.width + height, height: height)
//            return CGSize(width: maxCellSize.width, height: height)
            if (legend.legendRenderType == .zigzag) {
                newSize.width = size.width + height
            }
            newSize.width = newSize.width + legend.formLabelSpacing
            totalCellWidth += newSize.width
            totalCellHeight += newSize.height
            return newSize
        }
    }
    
    var totalCellWidth = CGFloat(0)
    var totalCellHeight = CGFloat(0)
    
    //3
    public func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        
        if legendEntries != nil
        {
                let cellCount = CGFloat(legendEntries!.count)
                if cellCount > 0 {
                    
                    if self.legend.legendOrientation == .Horizontal
                    {
                        let contentWidth = collectionView.frame.size.width - collectionView.contentInset.left - collectionView.contentInset.right

                        if ((totalCellWidth) < contentWidth) {
                            let padding = (contentWidth - (totalCellWidth)) / 2.0
                            return  UIEdgeInsets(top: sectionInsets.top, left: padding, bottom: sectionInsets.bottom, right: 0)
                        }
                    }
                    else
                    {
                        let contentHeight = collectionView.frame.size.height - collectionView.contentInset.top - collectionView.contentInset.bottom

                        if ((totalCellHeight) < contentHeight) {
                            let padding = (contentHeight - (totalCellHeight)) / 2.0
                            return  UIEdgeInsets(top: padding, left: sectionInsets.left, bottom: 0, right: sectionInsets.right)
                        }
                    }
                }
        }
         
         return sectionInsets
    }
    
    // 4
    public func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        //return sectionInsets.left
        return sectionMinimumLineSpacing
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return minimumInteritemSpacing
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = indexPath.item
        let tappedCell:LegendCell
        let animated = true
        self.collectionView?.selectItem(
            at: IndexPath(item: item, section: 0),
            animated: animated,
            scrollPosition: UICollectionView.ScrollPosition())
        self.scrollToItem(item, animated: animated)
        
        if delegate != nil
            
        {   tappedCell = self.collectionView?.cellForItem(at: indexPath) as! LegendCell
            if tappedCell.labelView.alpha == 1.0
            {
                disableCell(cell: tappedCell)
            }
            else{
                enableCell(cell: tappedCell)
            }
            //            delegate?.legendSelected!(indexPath: indexPath)
        }
        
        
        /*self.selectedItem = item
         if notifySelection {
         self.delegate?.pickerView?(self, didSelectItem: item)
         } */
    }
    
    public func scrollToItem(_ item: Int, animated: Bool = false) {
        
        var position:UICollectionView.ScrollPosition = .centeredHorizontally
        
        if self.legend.legendOrientation == .Vertical {
            position = .centeredVertically
        }
        
        self.collectionView?.scrollToItem(
            at: IndexPath(
                item: item,
                section: 0),
            at: position,
            animated: animated)
        
    }
    // --------------UICollectionViewDelegateFlowLayout------------------------- //
    
    
    // ---------------------LegendCellDelegate------------------------- //
    
    func legendEnabled(entry: LegendEntry, indexPath: IndexPath)
    {
        if delegate != nil
        {
            delegate?.legendEnabled!(indexPath: indexPath, entry: entry)
        }
        
    }
    
    func legendDisabled(entry: LegendEntry, indexPath: IndexPath)
    {
        if delegate != nil
        {
            delegate?.legendDisabled!(indexPath: indexPath, entry: entry)
        }
        
    }
    
    
    func indexPathForCell(cell: UICollectionViewCell) -> IndexPath {
        return (self.collectionView?.indexPath(for: cell))!
    }
    // ---------------------LegendCellDelegate------------------------- //
    
    
    func calculateMaxCellSize(entries: [LegendEntry])
    {
        var maxWidth:CGFloat = 0.0
        var maxHeight:CGFloat = 0.0
        
        self.legendEntries = entries
        
        for entry in entries
        {
            let text = legend.legendFormatter?.getFromattedValue?(legendEntry: entry) ?? entry.label
            
            if text == nil {
                continue
            }
            
            let size: CGSize = (text)!.size(withAttributes: [NSAttributedString.Key.font: self.legend.legendFont])
        
            if size.width > maxWidth
            {
                maxWidth = size.width
            }
            
            if size.height > maxHeight
            {
                maxHeight = size.height
            }
            
        }
        
        //maxWidth = maxWidth + maxHeight + maxHeight // To include legend form
        
        //maxWidth = maxWidth + maxHeight  // To include legend form
        
        maxCellSize = CGSize(width: maxWidth, height: maxHeight)
        
    }
    
    
    @objc func longPressed(_ gesture: UILongPressGestureRecognizer)
    {
        
        if gesture.state == UIGestureRecognizer.State.began
        {
            let longPressedGesture = gesture // as! UILongPressGestureRecognizer
            
            let location = longPressedGesture.location(in: self.collectionView)
            
            let indexPath = self.collectionView?.indexPathForItem(at: location)
            
            if delegate != nil && indexPath != nil
            {
//                delegate?.legendLongPressed!(indexPath: indexPath!)
            }
            

            return
        }
        
         }
    
   
    
    
    //----------------------- Pan Recognizer ----------------------------//
    
    var _last_cell:LegendCell? = nil
    var _last_cell_frame:CGRect? = nil
    
    
    internal func handlePan(_ gesture: UIGestureRecognizer)
    {
        
        if (!gesture.isKind(of: UIPanGestureRecognizer.self)) {
            return
        }
        
        let panRecognizer = gesture as! UIPanGestureRecognizer
        
        
        let location = panRecognizer.location(in: self.collectionView)
        //let swipeLocation = gesture.location(in: self.collectionView)
        let indexPath = self.collectionView?.indexPathForItem(at: location)
        
        let velocity = panRecognizer.velocity(in: self)
        
        //let location = panRecognizer.location(in: self.collectionView)
        
        if (gesture.state == .began)
        {
            // Start of the gesture.
            // You could remove any layout constraints that interfere
            // with changing of the position of the content view.
        }
            
        else if (gesture.state == .changed)
        {
            
            if !(indexPath != nil)
            {
                return
            }
            
            let swipedCell = self.collectionView?.cellForItem(at: indexPath!) as! LegendCell
            
            
            
            if _last_cell_frame == nil
            {
                _last_cell=swipedCell
                _last_cell_frame = swipedCell.frame
            }
            
            if _last_cell != nil && _last_cell != swipedCell
            {
                return
            }
            
            swipedCell.contentView.clipsToBounds = false
            
            var frame = swipedCell.frame;
            
            if velocity.y < 0 && self.legend.legendOrientation == .Horizontal
            {
                frame.origin.y = location.y - (_last_cell_frame?.size.height)!;
            }
            else if velocity.y > 0 && self.legend.legendOrientation == .Horizontal
            {
                frame.origin.y = location.y + (_last_cell_frame?.size.height)! / 2 ;
            }
            else if velocity.x < 0 && self.legend.legendOrientation == .Vertical
            {
                frame.origin.x = location.x - (_last_cell_frame?.size.width)!;
            }
            else if velocity.x > 0 && self.legend.legendOrientation == .Vertical
            {
                frame.origin.x = location.x + (_last_cell_frame?.size.width)! / 2 ;
            }
            
            swipedCell.frame = frame;
            //            let denom = swipedCell.contentView.bounds.size.height + fabs(location.y);
            //            let percent = swipedCell.contentView.bounds.size.height / denom;
            //            swipedCell.alpha = percent;
            
        }
            
        else if (gesture.state == .ended)
        {
            
            if _last_cell == nil
            {
                return
            }
            
            if self._last_cell_frame == nil{
                return
            }
            
            /*
             Naïve solution: If the bottom edge of the swipeableRect needs to cross
             the top of the bounding contentView and also needs to be
             fast enough for the swipe to work.
             */
            UIView.animate(withDuration: 0.5,
                           delay: 0,
                           usingSpringWithDamping: 0.33,
                           initialSpringVelocity: 0.0,
                           //options: UIViewAnimationOptions(),
                options: .curveLinear,
                animations: { [weak self]() -> Void in
                    
                    self?._last_cell?.frame = (self?._last_cell_frame!)!
                    
                    if self?.legend.legendOrientation == .Horizontal
                    {
                        if location.y > (self?._last_cell_frame?.origin.y)!
                        {
                            self?.enableCell(cell: (self?._last_cell)!)
                        }
                        else {
                            self?.disableCell(cell: (self?._last_cell)!)
                        }
                    }
                    else
                    {
                        
                        if location.x > (self?._last_cell_frame?.origin.x)!
                        {
                            self?.disableCell(cell: (self?._last_cell)!)
                        }
                        else {
                            self?.enableCell(cell: (self?._last_cell)!)
                        }
                        
                    }
                    
                    
                    
                }, completion: nil)
            
            _last_cell = nil
            _last_cell_frame = nil
            
        }
        
    }
    
    func enableCell(cell : LegendCell)
    {
        cell.enableCell()
    }
    
    func disableCell(cell : LegendCell)
    {
        var legendCount = 0
        
        for entry in legendEntries!
        {
            if entry.enabled
            {
                legendCount += 1
            }
        }
        
        
       if (legendCount > 1)
       {
        cell.disableCell()
        }
    }
    
    
    //    override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
    //
    //        if (!gestureRecognizer.isKind(of: UIPanGestureRecognizer.self)) {
    //            return false
    //        }
    //        let panRecognizer = gestureRecognizer as! UIPanGestureRecognizer
    //
    //        let translation = panRecognizer.translation(in: self.collectionView)
    //
    //
    //
    //        if self.legend.legendOrientation == .Horizontal
    //        {
    //            if abs(translation.x) > 0
    //            {
    //                return false
    //            }
    //
    //            return abs(translation.x) < abs(translation.y)
    //        }
    //        else
    //        {
    //            if abs(translation.y) > 0
    //            {
    //                return false
    //            }
    //
    //            return abs(translation.y) < abs(translation.x)
    //        }
    //
    //    }
    
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.onScroll = true
        self.stoppedScrolling(scrollView: scrollView)
    }
    
    
    func stoppedScrolling(scrollView: UIScrollView)
    {
        
        let transparent = NSUIColor.clear.cgColor
        let opaque = NSUIColor.black.cgColor
        var startPoint:CGFloat = scrollView.contentOffset.x
        var currentOffsetValue:CGFloat = scrollView.bounds.size.width
        var totalValue:CGFloat = scrollView.contentSize.width
        
        if self.legend.legendOrientation == .Vertical
        {
            startPoint = scrollView.contentOffset.y
            currentOffsetValue = scrollView.bounds.size.height
            totalValue = scrollView.contentSize.height
        }
        
        if startPoint + currentOffsetValue == currentOffsetValue
        {
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
            
        }
        else if startPoint + currentOffsetValue == totalValue
        {
            maskLayer.colors = [transparent, opaque, opaque]
            maskLayer.locations = [0,0.2,1]
            
        }
        else
        {
            maskLayer.colors = [transparent, opaque, opaque,transparent]
            maskLayer.locations = [0,0.2,0.8,1]
            
        }
    }
    
    func addMask()
    {
        if !onScroll {
            if ((collectionView?.contentSize.width)! > self.bounds.size.width && self.legend.legendOrientation == .Horizontal) || ((collectionView?.contentSize.height)! > self.bounds.size.height && self.legend.legendOrientation == .Vertical) && self.layer.mask == nil
            {
                let transparent = NSUIColor.clear.cgColor
                let opaque = NSUIColor.black.cgColor
                
                let parentLayer = CALayer()
                parentLayer.frame = self.bounds
                
                maskLayer.frame = CGRect(x: self.bounds.origin.x, y: 0, width: self.bounds.size.width, height: self.bounds.size.height)
                
                maskLayer.colors = [opaque, opaque, transparent]
                maskLayer.locations = [0,0.8,1]
                parentLayer.addSublayer(maskLayer)
                self.layer.mask = parentLayer
            }
            else
            {
                self.layer.mask = nil
            }
        }
    }
    
    
    override public func layoutSubviews() {
        
        if self.type == .discrete {
          addMask()
        }
//        addMask()
    }
    
    //----------------------- Pan Recognizer ----------------------------//
}

//public enum LegendForm
//{
//    case Circle
//    case Square
//    case Custom
//}
//
//open class ChartLegendObject : NSObject {
//
//    public override init()
//    {
//        super.init()
//    }
//
//    open var legendEnabled:Bool = true
//
//    open var legendOrientation:LegendOrientation = .Horizontal {
//        didSet {
//            self.notifyOrientationChanged()
//        }
//    }
//
//    open var legendRenderType:LegendRenderType = .step {
//        didSet {
//            self.notifyOrientationChanged()
//        }
//    }
//
//    open var legendFormCustomEnabled:Bool = false
//
//    /// The size of the legend forms
//    open var legendFormSize = CGFloat(10.0)
//
//    open var legendFormatter: LegendValueFormatter? = nil
//
//    open var legendFont:UIFont = UIFont.systemFont(ofSize: 15)
//
//    open var legendPosition:LegendPosition = .top
//
//    open var legendTextColor:NSUIColor = NSUIColor.black
//
//    open var formLabelSpacing:CGFloat = 5
//
//    open var formCornerRadius:CGFloat = 0
//
//    open var customPath:((CGRect)->CGPath)?
//
//    open var customFormShape:ShapeProperties? = nil
//
//    var orientationChangedClosure: (()->())?
//
//    var typeChangedClosure: (()->())?
//
//    func notifyOrientationChanged(){
//        self.orientationChangedClosure?()
//    }
//
//    func notifyTypeChanged(){
//        self.typeChangedClosure?()
//    }
//
//    open var type:LegendType = .discrete {
//        didSet {
//            self.notifyTypeChanged()
//        }
//    }
//
//}
//
//public enum LegendType
//{
//    case continous
//    case discrete
//}

class CollectionViewRow {
    var attributes = [UICollectionViewLayoutAttributes]()
    var spacing: CGFloat = 0

    init(spacing: CGFloat) {
        self.spacing = spacing
    }

    func add(attribute: UICollectionViewLayoutAttributes) {
        attributes.append(attribute)
    }

    var rowWidth: CGFloat {
        return attributes.reduce(0, { result, attribute -> CGFloat in
            return result + attribute.frame.width
        }) + CGFloat(attributes.count - 1) * spacing
    }

    func centerLayout(collectionViewWidth: CGFloat) {
        let padding = (collectionViewWidth - rowWidth) / 2
        var offset = padding
        for attribute in attributes {
            attribute.frame.origin.x = offset
            offset += attribute.frame.width + spacing
        }
    }
    
    func leftAlignment(collectionViewWidth: CGFloat, leftPadding: CGFloat) {
        
        guard let first = attributes.first else {
            return
        }
        
        var offset:CGFloat = leftPadding
        
        for attribute in attributes {
            attribute.frame.origin.x = offset
            offset += attribute.frame.width + spacing
        }
    }
}

class ZCollectionViewLayout: UICollectionViewFlowLayout {
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        guard let attributes = super.layoutAttributesForElements(in: rect) else {
            return nil
        }

        var rows = [CollectionViewRow]()
        var currentRowY: CGFloat = -1

        for attribute in attributes {
            if let attribute = attribute.copy() as? UICollectionViewLayoutAttributes {
                if currentRowY != attribute.frame.midY {
                    currentRowY = attribute.frame.midY
                    rows.append(CollectionViewRow(spacing: minimumInteritemSpacing))
                }
                rows.last?.add(attribute: attribute)
            }
        }

//        rows.forEach { $0.centerLayout(collectionViewWidth: collectionView?.frame.width ?? 0) }
        
        rows.forEach { $0.leftAlignment(collectionViewWidth: collectionView?.frame.width ?? 0, leftPadding :sectionInset.left ) }
        return rows.flatMap { $0.attributes }
    }
}

extension LegendView: UICollectionViewDataSource {
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        guard let legendEntries = legendEntries else
        {
            return 0
        }
        return legendEntries.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        guard let entries = legendEntries else
        {
            return collectionView.dequeueReusableCell(withReuseIdentifier: "LegendCell", for: indexPath)
        }
        
        let entry = entries[indexPath.item]
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LegendCell", for: indexPath) as! LegendCell
        
        cell.legendOrientation = legend.legendOrientation
        cell.entry = entry
        cell.delegate = self
        cell.legend = legend
        cell.textHeight = maxCellSize.height
        
        cell.legendInit()
        
        let newRect = CGRect(origin: CGPoint(), size: cell.shapeLayer.bounds.size)
        
        if self.legend.legendFormCustomEnabled && self.legend.customFormShape != nil
        {
            cell.shapeLayer.bounds = newRect
            
            _ = CommonHelperFunctions.drawFormShapeLayer(shapeProperties: self.legend.customFormShape!, entry: entry, currentLayer: cell.shapeLayer)
        
//            cell.shapeLayer.path = self.legend.customPath!(cell.shapeLayer.bounds)
        }
        else
        {
            cell.shapeLayer.path = UIBezierPath(ovalIn: newRect).cgPath
            
            cell.shapeLayer.fillColor = entry.colors?[0].cgColor
        }
        
        if (legend.formCornerRadius != 0) {
            cell.shapeLayer.cornerRadius = legend.formCornerRadius
            cell.shapeLayer.masksToBounds = true
        }
        
        let text = legend.legendFormatter?.getFromattedValue?(legendEntry: entry) ?? entry.label
        cell.labelView.text = text
        cell.labelView.font = legend.legendFont
        cell.labelView.alpha = 1.0
        cell.formView.alpha = 1.0
        
        
        
//        cell.shapeLayer.fillColor = entry.formColor?.cgColor
//        cell.shapeLayer.fillColor = entry.colors?[0].cgColor
        cell.labelView.textColor = legend.legendTextColor

        
        
        if entry.enabled
        {
//            cell.shapeLayer.fillColor = entry.formColor?.cgColor
//            cell.shapeLayer.fillColor = entry.colors?[0].cgColor
            cell.labelView.textColor = legend.legendTextColor
            //cell.alpha = 1.0
        }
        else
        {
            cell.labelView.alpha = 0.1
            cell.formView.alpha = 0.1
        }
        
        //To Add a Mask on Legend View//TMP// Have to call on when the collection view loaded the content size and init frame
        addMask()
        
        return cell
    }
}

extension LegendView{
    
    public func reload(legendEntries: [LegendEntry]){
        
        self.legendEntries = legendEntries
        
        calculateMaxCellSize(entries: self.legendEntries!)
        
        collectionView?.reloadData()
    }
    
}

#endif

#if os(OSX)
public class LegendView: NSView {
    
    open var legend:ChartLegendObject = ChartLegendObject()
    
    open weak var delegate: LegendViewDelegate?
    
    let maskLayer = CAGradientLayer()
    
    var legendEntries:[LegendEntry]? = nil
    
    open var scrollView:NSScrollView? = nil
    
    open var collectionView:NSCollectionView? = nil
    
    let layout: NSCollectionViewFlowLayout = NSCollectionViewFlowLayout()
    
//    var maxCellSize:CGSize = CGSize.zero

    open var rangeSlider:RangeSlider? = nil
    
    open var position:LegendPosition
    {
        set
        {
            self.legend.legendPosition = newValue
        }
        get
        {
            return self.legend.legendPosition
        }
    }
    
    open var showView:Bool
    {
        set
        {
            self.legend.legendEnabled = newValue
        }
        get
        {
            return self.legend.legendEnabled
        }
    }
    
    open var type:LegendType {
        set
        {
            self.legend.type = newValue
        }
        get
        {
            return self.legend.type
        }
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.initialize()
    }
    
    required public init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    public func reload(legendEntries: [LegendEntry]){
        
        self.legendEntries = legendEntries
        
//        calculateMaxCellSize(entries: self.legendEntries!)
        
        collectionView?.reloadData()
    }

    
    func initialize()
    {
        collectionView = NSCollectionView()
        collectionView!.dataSource = self
        collectionView!.delegate = self
        collectionView!.collectionViewLayout = layout
        collectionView!.allowsEmptySelection = false
        collectionView!.allowsMultipleSelection = true
        collectionView!.backgroundColors = [.clear]
        collectionView!.isSelectable = true
//        collectionView.backgroundColors = [NSColor.systemCyan]
        
        collectionView!.register(
          LegendCell.self,
          forItemWithIdentifier: NSUserInterfaceItemIdentifier(rawValue: "LegendCell")
        )
        
        collectionView?.translatesAutoresizingMaskIntoConstraints = false
        
        scrollView = NSScrollView()
        scrollView!.documentView = collectionView
        self.addSubview(scrollView!)
        scrollView!.translatesAutoresizingMaskIntoConstraints = false
        
        
//        resetOrientation()
//
//
//
//        self.legend.orientationChangedClosure = {
//            self.resetOrientation()
//        }
        
        self.legend.typeChangedClosure = {
            self.changeLegendType()
        }
    }
    
    fileprivate func changeLegendType() {
        
        scrollView?.removeFromSuperview()
        scrollView = nil
        
        collectionView?.removeFromSuperview()
        collectionView = nil
        
        rangeSlider?.removeFromSuperview()
        rangeSlider = nil
        
        if type == .continous {
            rangeSlider = RangeSlider(frame: CGRect.zero)
            self.addSubview(rangeSlider!)
            rangeSlider?.translatesAutoresizingMaskIntoConstraints = false
            rangeSlider?.delegate = self
            
            rangeSlider?.thumbShape.shapeType = .circle
            
            rangeSlider?.unHighlightShape.shapeType = .Rect
            rangeSlider?.unHighlightShape.holeColor = NSUIColor(white: 0.9, alpha: 1.0)
            rangeSlider?.unHighlightShape.strokeColor = NSUIColor.darkGray
            
            let centerXAnchor = rangeSlider!.centerXAnchor.constraint(equalTo: self.centerXAnchor)
            let centerYAnchor = rangeSlider!.centerYAnchor.constraint(equalTo: self.centerYAnchor)
            let heightAnchor = rangeSlider!.heightAnchor.constraint(equalToConstant: self.bounds.height )
            let widthAnchor = rangeSlider!.widthAnchor.constraint(equalToConstant: self.bounds.width )
    
//            NSLayoutConstraint.activate([centerXAnchor,centerYAnchor,heightAnchor, widthAnchor])
        }else {
            
            self.initialize()
            
        }
    }
    
   
}

extension LegendView : NSCollectionViewDataSource {
    
    public func collectionView(_ collectionView: NSCollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let legendEntries = legendEntries else
        {
            return 0
        }
        return legendEntries.count
    }
    
    
    public func collectionView(_ collectionView: NSCollectionView, itemForRepresentedObjectAt indexPath: IndexPath) -> NSCollectionViewItem {
        
        let cell = collectionView.makeItem(
          withIdentifier: NSUserInterfaceItemIdentifier(rawValue: "LegendCell"),
          for: indexPath
        ) as! LegendCell
        
        guard let legendEntries = legendEntries else
        {
            return cell
        }
                
        
        cell.legendCellView?.legendEntry = legendEntries[indexPath.item]
        cell.legendCellView?.legend = legend
        return cell
    }
    
}

extension LegendView : NSCollectionViewDelegateFlowLayout {
    
    public func collectionView(_ collectionView: NSCollectionView, layout collectionViewLayout: NSCollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> NSSize {
        
        let entry = legendEntries![indexPath.item]
                
        let attributes = [NSAttributedString.Key.font:  self.legend.legendFont]
        let rect = entry.label!.boundingRect(with: NSSize.zero, options: [.usesLineFragmentOrigin,.truncatesLastVisibleLine], attributes: attributes, context: nil)
                    var size = rect.size
        size.width += self.legend.formLabelSpacing
        size.width += size.height
        
      return size
        
    }
    
    public func collectionView(_ collectionView: NSCollectionView, didSelectItemsAt indexPaths: Set<IndexPath>) {
        
        guard let indexPath = indexPaths.first,
        let cell = collectionView.item(at: indexPath) as? LegendCell else {
          return
        }
                
        guard let shapeLayer = (cell.legendCellView!.layer!.sublayers![0]) as? CAShapeLayer,
              let legendEntry = cell.legendCellView!.legendEntry else {
            return
        }

        if (legendEntry.enabled) {
            shapeLayer.fillColor = NSColor.gray.cgColor
            legendEntry.enabled = false
            delegate?.legendDisabled?(indexPath: indexPath, entry: legendEntry)
            
            for subLayer in (cell.legendCellView?.layer?.sublayers)!
            {
                subLayer.opacity = 0.1
            }
        }else {
            shapeLayer.fillColor = legendEntry.colors?[0].cgColor
            legendEntry.enabled = true
            delegate?.legendEnabled?(indexPath: indexPath, entry: legendEntry)
            
            for subLayer in (cell.legendCellView?.layer?.sublayers)!
            {
                subLayer.opacity = 1
            }
        }
        
        collectionView.deselectItems(at: indexPaths)
        
    }
}

extension LegendView : RangeSliderDelegate {
    public func rangeSelected(minimum: Double, maximum: Double) {
        self.delegate?.legendRangeSelected!(minimum: minimum, maximum: maximum)
    }
}

#endif

public enum LegendForm
{
    case Circle
    case Square
    case Custom
}

open class ChartLegendObject : NSObject {
    
    public override init()
    {
        super.init()
    }
    
    open var legendEnabled:Bool = true
    
    open var legendOrientation:LegendOrientation = .Horizontal {
        didSet {
            self.notifyOrientationChanged()
        }
    }
    
    open var legendRenderType:LegendRenderType = .step {
        didSet {
            self.notifyOrientationChanged()
        }
    }
    
    open var legendFormCustomEnabled:Bool = false
    
    /// The size of the legend forms
    open var legendFormSize = CGFloat(10.0)
    
    open var legendFormatter: LegendValueFormatter? = nil
    
    open var legendFont:NSUIFont = NSUIFont.systemFont(ofSize: 15)
    
    open var legendPosition:LegendPosition = .top
    
    open var legendTextColor:NSUIColor = NSUIColor.black
    
    open var formLabelSpacing:CGFloat = 5
    
    open var formCornerRadius:CGFloat = 0
    
    open var customPath:((CGRect)->CGPath)?
    
    open var customFormShape:ShapeProperties? = nil
    
    var orientationChangedClosure: (()->())?
    
    var typeChangedClosure: (()->())?
    
    func notifyOrientationChanged(){
        self.orientationChangedClosure?()
    }
    
    func notifyTypeChanged(){
        self.typeChangedClosure?()
    }
    
    open var type:LegendType = .discrete {
        didSet {
            self.notifyTypeChanged()
        }
    }
    
}

public enum LegendType
{
    case continous
    case discrete
}
