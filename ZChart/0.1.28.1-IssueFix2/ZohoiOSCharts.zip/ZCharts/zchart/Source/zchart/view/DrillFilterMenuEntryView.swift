//
//  DrillFilterMenuEntryView.swift
//  zchart
//
//  Created by Aravinth T on 03/10/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class DrillFilterMenuEntryView: NSUIView {
    
    open var menuType:DrillFilterMenuType? = nil
    
    open var drillFilterMenuEntry:DrillFilterMenuEntry? = nil
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    public convenience init(frame:CGRect,drillFilterEntry:DrillFilterMenuEntry) {
        self.init(frame: frame)
        self.drillFilterMenuEntry = drillFilterEntry
        self.menuType = self.drillFilterMenuEntry?.menuType
        addViews()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    #if os(iOS)
    let labelView = UILabel()
    let drawView =  NSUIView()
    #else
    let labelView = DrillFilterTextField()
    let drawView =  DrillFilterDrawView()
    #endif
    
    let ellipseLayer = CAShapeLayer()
//    let drawView = NSUIView()
    let drawLayer = CAShapeLayer()
    
    func addViews()
    {
        
        self.addSubview(labelView)
        self.addSubview(drawView)
        #if os(OSX)
        self.wantsLayer = true
        drawView.wantsLayer = true
        labelView.wantsLayer = true
        #endif
        
//        let text = "Vibrant "
        var text:String = ""
        
       /* var uniqueText = Set<String>()
        
        for entry in drillFilterMenuEntry!.chartDataEntry
        {
            if entry.xString != nil{
                uniqueText.insert(entry.xString!)
            }
            else{
                uniqueText.insert(String(describing: (entry.x)))
            }
        }
        
        for xString in uniqueText
        {
            text += xString + ", "
        }
        let endIndex = text.index(text.endIndex, offsetBy: -2)
        
        text = String(text[..<endIndex])*/
        
        text = DrillFilterMenuEntryView.getText(drillFilterMenuEntry: drillFilterMenuEntry!)
        
        let font = NSUIFont.systemFont(ofSize: 10)
        
        #if os(iOS)
        labelView.text = text //+ " : " + String(describing: drillFilterMenuEntry?.chartDataEntry?.y)
        labelView.textAlignment = .left
        #else
        drawView.wantsLayer = true
        labelView.stringValue = text //+ " : " + String(describing: drillFilterMenuEntry?.chartDataEntry?.y)
        labelView.alignment = .left
        labelView.backgroundColor = .clear
        labelView.isBezeled = false
        labelView.isEditable = false
        labelView.cell = VerticallyCenteredTextFieldCell(textCell: text)
        labelView.isUserInteractionEnabled = false
        drawView.isUserInteractionEnabled = false
        #endif
        
        labelView.font = font
        
        drawLayer.fillColor = NSUIColor.lightGray.cgColor
        drawLayer.strokeColor = NSUIColor.darkGray.cgColor
        drawView.nsuiLayer?.addSublayer(drawLayer)
        
    #if os(iOS)
        self.translatesAutoresizingMaskIntoConstraints = false
        labelView.translatesAutoresizingMaskIntoConstraints = false
        drawView.translatesAutoresizingMaskIntoConstraints = false
        /*
         drawView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5).isActive = true
         drawView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
         drawView.widthAnchor.constraint(equalToConstant: 10).isActive = true
         //        drawView.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5).isActive = true
         drawView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
         
         labelView.leadingAnchor.constraint(equalTo: drawView.trailingAnchor, constant: 3).isActive = true
         labelView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
         labelView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 3/4).isActive = true
         //        labelView.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 3/4).isActive = true
         */
        if menuType != nil && menuType == DrillFilterMenuType.filter
        {
            drawView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 5).isActive = true
            drawView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
            drawView.widthAnchor.constraint(equalToConstant: 10).isActive = true
            drawView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.75).isActive = true
            
            labelView.leadingAnchor.constraint(equalTo: drawView.trailingAnchor, constant: 3).isActive = true
            labelView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
            labelView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1).isActive = true
            
        }
        else
        {
            #if os(iOS)
            labelView.textAlignment = .center
            #else
            labelView.alignment = .center
            #endif
            
            labelView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 3).isActive = true
            labelView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
            labelView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1).isActive = true
            
            
            
            drawView.leadingAnchor.constraint(equalTo: labelView.trailingAnchor).isActive = true
            drawView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
            drawView.widthAnchor.constraint(equalToConstant: 10).isActive = true
            drawView.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 0.75).isActive = true
            
        }
        
        let textSize =  DrillFilterMenuEntryView.getTextSize(text: text, font: font)
        
        var labelWidth = textSize.width + 10
        
        var totalWidth = labelWidth + 20
        
        if self.menuType != nil && menuType == DrillFilterMenuType.drill
        {
            labelWidth = textSize.width + 10
            
            totalWidth = labelWidth + 18
        }
        
        self.widthAnchor.constraint(equalToConstant: totalWidth).isActive = true
        labelView.widthAnchor.constraint(equalToConstant: labelWidth).isActive = true
    #elseif os(OSX)
        
        let textSize =  DrillFilterMenuEntryView.getTextSize(text: text, font: font)
        if menuType != nil && menuType == DrillFilterMenuType.filter
        {
            drawView.frame = CGRect(x: 0, y: self.bounds.height / 4.0, width: 15, height: self.bounds.height * 0.5)
            labelView.frame = CGRect(x: 15, y: self.bounds.height / 4.0, width: textSize.width + 10.0, height: self.bounds.height * 0.5)
        }
        else
        {
            //TODO FRAME SETTING
            labelView.alignment = .center
            drawView.frame = CGRect(x: 10, y: self.bounds.height / 4.0, width: 15, height: self.bounds.height * 0.5)
            labelView.frame = CGRect(x: 20, y: self.bounds.height / 4.0, width: textSize.width + 10.0, height: self.bounds.height * 0.5)
        }
        
    #endif
        
    }
    
    public static func getTextSize(text: String, font: NSUIFont) -> CGSize
    {
        let fontAttributes = [NSAttributedString.Key.font: font] // it says name, but a UIFont works
        let size = (text as NSString).size(withAttributes: fontAttributes)
        return size
    }
    
    #if os(iOS)
    open override func layoutSubviews() {
        layoutMyviews()
    }
    #else
    open override func layout() {
        layoutMyviews()
    }
    #endif
    
     func layoutMyviews() {
        
        
        let heightOfDrawView = 0.75 * (self.bounds.size.height)
        
        var bPath = CGMutablePath() // UIBezierPath()
        
        let diff:CGFloat = 1.5
        
        if menuType != nil && menuType == DrillFilterMenuType.filter
        {
//            bPath = UIBezierPath(ovalIn: CGRect(x: 0, y: (heightOfDrawView/2)-((10 - diff)/2), width: 10 - diff, height: 10 - diff ))
            #if os(iOS)
            bPath = CGMutablePath(ellipseIn: CGRect(x: 0, y: (heightOfDrawView/2)-((10 - diff)/2), width: 10 - diff, height: 10 - diff ), transform: nil)
            #elseif os(OSX)
            bPath = CGMutablePath(ellipseIn: CGRect(x: self.drawView.bounds.width / 4.0, y: self.drawView.bounds.height / 2.0 - self.drawView.bounds.width / 4.0, width: self.drawView.bounds.width / 2.0, height: self.drawView.bounds.width / 2.0 ), transform: nil)
            #endif
            self.backgroundColor = NSUIColor.clear
        }
        else
        {
//            ellipseLayer.path =  UIBezierPath(roundedRect: CGRect(x: 0, y: (self.bounds.height/2) - 12, width: self.bounds.width, height: min(self.bounds.height,24)), cornerRadius: heightOfDrawView * (3/4)).cgPath
            //UIBezierPath(ovalIn: CGRect(x: 0, y: (self.bounds.height/2) - 13, width: self.bounds.width, height: min(self.bounds.height,25))).cgPath // UIBezierPath(rect: self.bounds).cgPath
            
            
            ellipseLayer.path =  CGMutablePath(roundedRect:CGRect(x: 0, y: (self.bounds.height/2) - 12, width: self.bounds.width, height: min(self.bounds.height,24)) , cornerWidth: heightOfDrawView * (3/4), cornerHeight: heightOfDrawView * (3/4), transform: nil)
            
            
            /// New Rounded Rect Code
            #if os(OSX)
            let rectFrame = CGRect(x: min(self.bounds.width*(1/4),5), y: (self.bounds.height/2) - 12, width: self.bounds.width - min(self.bounds.width*(1/4),5), height: min(self.bounds.height,24))
            #else
            let rectFrame = CGRect(x: 0, y: (self.bounds.height/2) - 12, width: self.bounds.width, height: min(self.bounds.height,24))
            #endif
            
            let heightValue = min(self.bounds.height,24)
            
            let cornerRadius: CGFloat = 10

            let path = createRoundedRect(rect: rectFrame, cornerRadius: cornerRadius)

            ellipseLayer.path = path
            
            // ******************

            
            //            let color = UIColor.init(red: 128, green: 128, blue: 128, alpha: 1.0)
            
            ellipseLayer.fillColor = NSUIColor.lightGray.withAlphaComponent(0.3).cgColor
            ellipseLayer.strokeColor = NSUIColor.lightGray.withAlphaComponent(0.3).cgColor
            
            self.nsuiLayer?.addSublayer(ellipseLayer)
            
            #if os(OSX)
            let mid = (heightValue/2)
            let xHeight = max((heightValue/4),5)
            #else
            let mid = (heightOfDrawView/2)
            let xHeight = max((heightValue/4),5)
            #endif
            bPath.move(to: CGPoint(x: 0+diff, y: mid - (xHeight/2)))
            bPath.addLine(to: CGPoint(x: 10 - diff, y: mid + (xHeight/2)))
            
            bPath.move(to: CGPoint(x: 0+diff, y: mid + (xHeight/2)))
            bPath.addLine(to: CGPoint(x: 10 - diff, y: mid - (xHeight/2)))
//            #else
//            bPath.move(to: CGPoint(x: 0+diff, y:  (heightOfDrawView/4) + diff))
//            bPath.addLine(to: CGPoint(x: 10 - diff, y: (heightOfDrawView/4) + 10 - diff))
//
//            bPath.move(to: CGPoint(x: 0+diff, y: (heightOfDrawView/4) + 10 - diff))
//            bPath.addLine(to: CGPoint(x: 10 - diff, y: (heightOfDrawView/4) + diff))
//            #endif
            
            bPath.closeSubpath()// .close()
        }
        
        drawLayer.path = bPath//.cgPath
        
    }
    
    func createRoundedRect(rect:CGRect,cornerRadius:CGFloat) -> CGMutablePath
    {
        let path = CGMutablePath()
        path.move(to: CGPoint(x: rect.minX + cornerRadius, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX - cornerRadius, y: rect.minY))
        path.addArc(center: CGPoint(x: rect.maxX - cornerRadius, y: rect.minY + cornerRadius), radius: cornerRadius, startAngle: -CGFloat.pi / 2, endAngle: 0, clockwise: false)
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - cornerRadius))
        path.addArc(center: CGPoint(x: rect.maxX - cornerRadius, y: rect.maxY - cornerRadius), radius: cornerRadius, startAngle: 0, endAngle: CGFloat.pi / 2, clockwise: false)
        path.addLine(to: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY))
        path.addArc(center: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY - cornerRadius), radius: cornerRadius, startAngle: CGFloat.pi / 2, endAngle: CGFloat.pi, clockwise: false)
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + cornerRadius))
        path.addArc(center: CGPoint(x: rect.minX + cornerRadius, y: rect.minY + cornerRadius), radius: cornerRadius, startAngle: CGFloat.pi, endAngle: -CGFloat.pi / 2, clockwise: false)
        path.closeSubpath()
        return path
    }
    
    public static func getText(drillFilterMenuEntry: DrillFilterMenuEntry) -> String
    {
        var text:String = ""
        
        var uniqueText = Set<String>()
        
        for entry in drillFilterMenuEntry.chartDataEntry
        {
            if entry.xString != nil{
                uniqueText.insert(entry.xString!)
            }
            else{
                uniqueText.insert(String(describing: (entry.x)))
            }
        }
        
        for xString in uniqueText
        {
            text += xString + ", "
        }
        let endIndex = text.index(text.endIndex, offsetBy: -2)
        
        text = String(text[..<endIndex])
        
        return text
    }
    
    public static func getViewSize(drillFilterMenuEntry: DrillFilterMenuEntry) -> CGSize {
        var size = CGSize.zero
        let font = NSUIFont.systemFont(ofSize: 10)
        let text = getText(drillFilterMenuEntry: drillFilterMenuEntry)
        let textSize = getTextSize(text: text, font: font)
        size.width = (15.0  + textSize.width + 10.0)
        size.height = textSize.height
        if drillFilterMenuEntry.menuType == .drill
        {
            size.width += 10//28
        }
        return size
    }
}

public enum DrillFilterMenuType
{
    case drill
    case filter
}

#if os(OSX)
open class DrillFilterDrawView : NSUIView {
    
    
    open override func hitTest(_ point: NSPoint) -> NSView? {
        if (isUserInteractionEnabled) {
            return super.hitTest(point)
        }
            return nil
      }
    
    public var isUserInteractionEnabled: Bool = true
}

open class DrillFilterTextField : NSTextField {
    open override func hitTest(_ point: NSPoint) -> NSView? {
        if (isUserInteractionEnabled) {
            return super.hitTest(point)
        }
            return nil
      }
    
    public var isUserInteractionEnabled: Bool = true
}

open class VerticallyCenteredTextFieldCell: NSTextFieldCell {
    
    fileprivate var isEditingOrSelecting : Bool = false
    
    open override func drawingRect(forBounds rect: NSRect) -> NSRect {
        let rect = super.drawingRect(forBounds: rect)
        
        if !isEditingOrSelecting {
            let size = cellSize(forBounds: rect)
            return NSRect(x: rect.minX, y: rect.minY + (rect.height - size.height) / 2, width: rect.width, height: size.height)
        }
        
        return rect
    }
    
    open override func select(withFrame rect: NSRect, in controlView: NSView, editor textObj: NSText, delegate: Any?, start selStart: Int, length selLength: Int) {
        let aRect = self.drawingRect(forBounds: rect)
        isEditingOrSelecting = true
        super.select(withFrame: aRect, in: controlView, editor: textObj, delegate: delegate, start: selStart, length: selLength)
        isEditingOrSelecting = false
    }
    
    open override func edit(withFrame rect: NSRect, in controlView: NSView, editor textObj: NSText, delegate: Any?, event: NSEvent?) {
        let aRect = self.drawingRect(forBounds: rect)
        isEditingOrSelecting = true
        super.edit(withFrame: aRect, in: controlView, editor: textObj, delegate: delegate, event: event)
        isEditingOrSelecting = false
    }
    
}


#endif
