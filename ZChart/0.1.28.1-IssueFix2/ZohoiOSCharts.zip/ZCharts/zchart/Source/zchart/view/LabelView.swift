//
//  LabelView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
import UIKit
#endif

#if os(iOS) || os(tvOS)
open class LabelView: UILabel {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.enable = true
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.enable = true
    }
    
    var hideEnabled:Bool = false
    
    var enable:Bool {
        set {
            self.hideEnabled = !newValue
        }
        get {
            return  !self.hideEnabled
        }
    }
    
    

}
#endif
#if os(OSX)
open class LabelView: NSTextView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.enable = true
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override init(frame frameRect: NSRect, textContainer container: NSTextContainer?) {
        super.init(frame: frameRect, textContainer: container)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.enable = true
//        self.isBezeled = false
        self.isEditable = false
    }
    
    var hideEnabled:Bool = false
    
    var enable:Bool {
        set {
            self.hideEnabled = !newValue
        }
        get {
            return  !self.hideEnabled
        }
    }
    
    open var text:String {
        set {
//            self.stringValue = newValue
            self.string = newValue
        }
        get {
//            return self.stringValue
            return self.string
        }
    }
    
    open var textAlignment:NSTextAlignment {
        set {
            self.alignment = newValue
        }
        get {
            return self.alignment
        }
    }

}
#endif
