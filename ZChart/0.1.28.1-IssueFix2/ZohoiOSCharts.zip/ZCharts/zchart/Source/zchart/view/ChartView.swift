//
//  ChartView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class ChartView: NSUIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    var showView:Bool
    {
        get
        {
            return true
        }
    }

    fileprivate var _chart:ChartViewBase? = nil
    
    open var chart:ChartViewBase
    {
        get
        {
            return _chart!
        }
    }
    
   func initializeChart() -> ChartViewBase
    {
        _chart = {
            class SubChartViewBase: ChartViewBase {
                
                override func notifyDataSetChanged(redrawRequired: Bool) {
                    
                    super.notifyDataSetChanged(redrawRequired: redrawRequired)

                    delegateToContainer?.chartProcessedBeforeDraw?(self, redrawRequired: redrawRequired)
                }
            }
            return SubChartViewBase()
        }()
        
        setConstraints()
        
        return _chart!
    }
    
    func initializeChart(chart:ChartViewBase) -> ChartViewBase
    {
        _chart = chart
        setConstraints()
        
        return _chart!
    }
    
    func setConstraints()
    {
        for view in self.subviews{
            view.removeFromSuperview()
        }
        self.addSubview(_chart!)
        
        _chart?.translatesAutoresizingMaskIntoConstraints = false
        
        let centerX = _chart?.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        let centerY = _chart?.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        let width = _chart?.widthAnchor.constraint(equalTo: self.widthAnchor)
        let height = _chart?.heightAnchor.constraint(equalTo: self.heightAnchor)
        
        let oldConstraints:[NSLayoutConstraint] = [centerX!, centerY!, width!, height!]
        NSLayoutConstraint.activate(oldConstraints)
    }
    
}

@objc
public enum ChartType : Int, Codable
{
    case Pie
    case Dial
    case Bar
    case Mekko
    case Sanky
    case Line
    case Area
    case LineRange
    case Scatter
    case Bubble
    case PackedBubble
    case Funnel
    case HeatMap
    case Combined
    case Bullet
    case Radar
    case WordCloud
    case BubblePie
    case GeoHeatMap
    case WaterFall
    case BoxPlot
    case HorizontalBarRange
}

