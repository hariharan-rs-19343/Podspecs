//
//  TitleView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif
open class TitleView: NSUIView {

    open var title:ChartTitle = ChartTitle()
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    open var lineDesign:LineView = LineView()
    
    open var showView:Bool {
        set {
            self.title.titleEnabled = newValue
        }
        get {
            return self.title.titleEnabled
        }
    }
    
    open var mainTitle:LabelView = LabelView()
    
    open var subTitle:LabelView = LabelView()
    
    var oldConstraints:[NSLayoutConstraint] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        lineDesign.titleView = self
        self.addTitles()
        
        self.title.mainTitleSettings.valueDidChangeClosure = { [weak self] in
            guard let selfReference = self else {
                return
            }
            selfReference.reloadTitleProps()
        }
        
        self.title.subTitleSettings.valueDidChangeClosure = { [weak self] in
            guard let selfReference = self else {
                return
            }
            selfReference.reloadTitleProps()
        }
        
        self.title.layoutChangedClosure = { [weak self] in
            guard let selfReference = self else {
                return
            }
            selfReference.reloadTitles()
        }
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func reloadTitleProps(){
        
        mainTitle.font = self.title.mainTitleSettings.font
        if self.title.mainTitleSettings.text != nil {
            mainTitle.text = self.title.mainTitleSettings.text
        }
        mainTitle.textAlignment = self.title.mainTitleSettings.alignment
        mainTitle.textColor = self.title.mainTitleSettings.color
        
        
        subTitle.font = self.title.subTitleSettings.font
        if self.title.subTitleSettings.text != nil {
            subTitle.text = self.title.subTitleSettings.text
        }
        subTitle.textAlignment = self.title.subTitleSettings.alignment
        subTitle.textColor = self.title.subTitleSettings.color
        
    }
    
    func addTitles()
    {
        self.title.mainTitleSettings.font = NSUIFont.systemFont(ofSize: 16)
        self.title.mainTitleSettings.text = "IOS Chart"
        self.title.mainTitleSettings.alignment = .center
        
        self.title.subTitleSettings.font = NSUIFont.systemFont(ofSize: 10)
        self.title.subTitleSettings.text = "Welcome to Zoho IOS Chart"
        self.title.subTitleSettings.alignment = .center
        
        mainTitle.translatesAutoresizingMaskIntoConstraints = false
        subTitle.translatesAutoresizingMaskIntoConstraints = false
        lineDesign.translatesAutoresizingMaskIntoConstraints = false
        
        
        self.addSubview(mainTitle)
        self.addSubview(subTitle)
        self.addSubview(lineDesign)
        
        reloadTitles()
        
        reloadTitleProps()
    }
    
    func removeLine()
    {
        if !showView
        {
        if let sublayers = lineDesign.nsuiLayer?.sublayers {
            
            for child in sublayers
            {
                child.removeFromSuperlayer()
            }
            
        }
        }
    }
    
    func reloadTitles()
    {
        self.mainTitle.enable = self.title.mainTitleEnabled
        self.subTitle.enable = self.title.subTitleEnabled
        #if !os(OSX)
        ContainerLayout.activateConstraintsForTitleView(titleView: self)
        #endif
    }
    
}

open class ChartTitle : NSObject
{
    public override init()
    {
        super.init()
    }
    
    open var titleEnabled:Bool = true
    
    open var mainTitleEnabled:Bool = true {
        didSet {
            self.notifyLayoutChanged()
        }
    }
    
    open var subTitleEnabled:Bool = true {
        didSet {
            self.notifyLayoutChanged()
        }
    }
    
    open var mainTitleSettings:TextSettings = TextSettings()
    
    open var subTitleSettings:TextSettings = TextSettings()
    
    var layoutChangedClosure: (()->())?
    
    func notifyLayoutChanged(){
        self.layoutChangedClosure?()
    }
    
}
