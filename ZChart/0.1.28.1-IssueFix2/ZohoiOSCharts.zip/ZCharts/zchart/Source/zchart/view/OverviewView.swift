//
//  OverviewView.swift
//  zchart
//
//  Created by keerthi-pt4274 on 15/03/23.
//

#if !os(OSX)
import UIKit
#endif

public class OverviewView: NSUIView {
    
    open var overview = OverViewObject()
    
    open var showView:Bool
    {
        set
        {
            overview.overviewEnabled = newValue
        }
        get
        {
            return overview.overviewEnabled
        }
    }
    
    open var position:OverviewPosition
    {
        set
        {
            overview.overviewPosition = newValue
        }
        get
        {
            return overview.overviewPosition
        }
    }

    open var rangeSlider:RangeSlider?
    
    open var offsets: Offsets = Offsets() {
        
        didSet {
            updateConstraints()
        }
    }
    
    internal var _offsets = Offsets()
    
    open var enableHighlightChart = true
    
    fileprivate var initialRange = true
    
    fileprivate var layoutConstraints: [NSLayoutConstraint] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        initialize()
        layoutChanged()
    }
    
    required public init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initialize() {
        
        if let chartView = overview.chartView {
            
            initialRange = true
            
            self.addSubview(chartView)
            chartView.translatesAutoresizingMaskIntoConstraints = false
            #if !os(OSX)
            chartView.isUserInteractionEnabled = false
            #endif
            chartView.rendererDelegate = self
            
            rangeSlider = RangeSlider(frame: CGRect.zero)
            self.addSubview(rangeSlider!)
            rangeSlider?.translatesAutoresizingMaskIntoConstraints = false
            
            rangeSlider?.trackLayer.fillColor = NSUIColor.clear.cgColor
            rangeSlider?.trackerHeightInPercentage = 1.0
            rangeSlider?.trackerWidthInPercentage = 1.0

            rangeSlider?.thumbShape.shapeType = .thumbNail
            rangeSlider?.thumbShape.lineWidth = 2
            
            _offsets.reset()
            
            updateConstraints()
        }
    }
    
    func layoutChanged() {
        
        overview.layoutChangedClosure = { [weak self] in
            guard let selfReference = self else {
                return
            }
            selfReference.initialize()
        }
    }
    
    public func calcMinMax(chart: ChartViewBase) {
        
        let minVal = chart.xAxis.isInverted ? chart.xAxis._axisMaximum : chart.xAxis._axisMinimum
        
        rangeSlider?.minimumValue = minVal
        
        let maxVal = chart.xAxis.isInverted ? chart.xAxis._axisMinimum : chart.xAxis._axisMaximum
        
        rangeSlider?.maximumValue = maxVal
    }
    
    open func updateValues(minimumValue: CGFloat, maximumValue: CGFloat, updateLayer: Bool) {
        
        rangeSlider?.value1 = minimumValue
        
        rangeSlider?.value2 = maximumValue
        
        if updateLayer {
            updateRangeSlider()
        }
        
    }
    
    public override func updateConstraints() {
        
        super.updateConstraints()
        
        self.removeConstraints(layoutConstraints)
        
        if let chartView = overview.chartView {
            
            layoutConstraints = [
                chartView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: (offsets.leftOffset ?? _offsets.leftOffset) ?? 0.0),
                chartView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -((offsets.rightOffset ?? _offsets.rightOffset) ?? 0.0)),
                chartView.topAnchor.constraint(equalTo: self.topAnchor, constant: (offsets.topOffset ?? _offsets.topOffset) ?? 0.0),
                chartView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -((offsets.bottomOffset ?? _offsets.bottomOffset) ?? 0.0))
            ]
            
            if let rangeSlider = rangeSlider {
                layoutConstraints.append(contentsOf: [
                    rangeSlider.leadingAnchor.constraint(equalTo: chartView.leadingAnchor),
                    rangeSlider.trailingAnchor.constraint(equalTo: chartView.trailingAnchor),
                    rangeSlider.topAnchor.constraint(equalTo: chartView.topAnchor),
                    rangeSlider.bottomAnchor.constraint(equalTo: chartView.bottomAnchor)
                    
                ])
            }
            
            self.addConstraints(layoutConstraints)
        }
    }
    
    func chartValueUpdated(chart: ChartViewBase) {
        
        guard let chartView = overview.chartView else {
            return
        }
        
        chartView.notifyDataSetChanged(redrawRequired: true)
        
        calcMinMax(chart: chartView)
        
        updateRangeSlider()
    }
    
    open func updateRangeSlider() {
        
        #if os(iOS) || os(tvOS)
            rangeSlider?.layoutSubviews()
        #endif
        #if os(OSX)
            rangeSlider?.layout()
        #endif
    }
    
    public func chartXRangeUpdated(_ chartView: ChartViewBase, minimum: CGFloat, maximum: CGFloat, updateLayer: Bool) {
        
        guard let overviewChart = overview.chartView else {
            return
        }
        
        if initialRange {
            
            calcMinMax(chart: overviewChart)
            
            initialRange = false
        }
        
        if let plotOptions = chartView.getPlotOptions() as? AxisChartPlotOptions {
            
            if plotOptions.maxWidthZoomRestrictionPixel != CGFloat.greatestFiniteMagnitude &&
                CommonHelperFunctions.stepSize(chart: chartView, axisIndex: 0) > plotOptions.maxWidthZoomRestrictionPixel {
                    
                    let (min,max) = CommonHelperFunctions.getXMinAndMaxValue(chart: chartView)
                    
                    rangeSlider?.maximumSelectableRange = max - min
            }
        }
        
        if chartView.xAxis.minRangeToShow != .greatestFiniteMagnitude {
            rangeSlider?.maximumSelectableRange = chartView.xAxis.minRangeToShow
        }
        
        if chartView.xAxis.maxRangeToShow != -.greatestFiniteMagnitude {
            rangeSlider?.minimumSelectableRange = chartView.xAxis.maxRangeToShow
        }
        
        let minVal = max(minimum,overviewChart.xAxis.axisMinimum)
        let maxVal = min(maximum,overviewChart.xAxis.axisMaximum)
        
        updateValues(minimumValue: minVal, maximumValue: maxVal, updateLayer: updateLayer)
    }
    
    func reloadLayer() {
        
        if !showView {
            self.nsuiLayer?.sublayers?.removeAll()
        }
    }
}

extension OverviewView: RendererDelegate {
    
    public func drawOthers(_ chartView: ChartViewBase) {
        
        guard let plotView = chartView.plotView, let rangeSlider = rangeSlider else {
            return
        }
        
        if rangeSlider.unHighlightShape.shapeType == .Default {
            
            if rangeSlider.plotLayer == nil {
                rangeSlider.plotLayer = CALayer()
            }
            else {
                rangeSlider.plotLayer?.sublayers?.removeAll()
            }
            
            if let subLayers = plotView.nsuiLayer?.sublayers {
                for layer in subLayers {
                    
                    guard let layer = layer as? ChartEntryLayer else {
                        continue
                    }
                    
                    let tempLayer = CAShapeLayer(layer: layer)
                    tempLayer.fillColor = rangeSlider.unHighlightShape.holeColor?.cgColor
                    tempLayer.strokeColor = rangeSlider.unHighlightShape.strokeColor?.cgColor
                    
                    if let path = layer.path {
                        tempLayer.path = path
                        rangeSlider.plotLayer?.addSublayer(tempLayer)
                    }
                }
            }
            updateRangeSlider()
        }
    }
}

open class OverViewObject: NSObject {
    
    public override init()
    {
        super.init()
    }
    
    open var chartView: ChartViewBase?
    
    open var overviewPosition: OverviewPosition = .bottom
    
    fileprivate var _overviewEnabled = false
    
    open var overviewEnabled: Bool = false {
        
        didSet{
            if overviewEnabled {
                
                chartView = {
    
                    class SubOverviewChartViewBase: ChartViewBase {
    
                        override func notifyDataSetChanged(redrawRequired: Bool) {
    
                            super.notifyDataSetChanged(redrawRequired: redrawRequired)
                            
                            delegateToContainer?.chartProcessedBeforeDraw?(self, redrawRequired: redrawRequired)
                        }
                    }
    
                    return SubOverviewChartViewBase()
                }()
                
                notifyLayoutChanged()
                notifyChartViewCreated?()
            }
            else {
                chartView = nil
            }
        }
    }
    
    internal var notifyChartViewCreated: (()->())?
    
    var layoutChangedClosure: (()->())?
    
    func notifyLayoutChanged(){
        self.layoutChangedClosure?()
    }
}
