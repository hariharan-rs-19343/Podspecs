//
//  DrillFilterMenuView.swift
//  zchart
//
//  Created by Aravinth T on 03/10/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class DrillFilterMenuView: NSUIView
{
    
    open var showView:Bool = true
    
    public let scrollView = NSUIScrollView()
    
    public let scrollContentView = NSUIView()
    
    weak open var dataSource:DrillFilterMenuDataSource? = nil
    
    weak open var delegate:DrillFilterMenuDelegate? = nil
    
    public convenience init()
    {
        self.init(frame: CGRect.zero)
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        addContentView()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addContentView()
    {
        
        
        let _tapGestureRecognizer = NSUITapGestureRecognizer(target: self, action: #selector(self.tapGestureRecognized(_:)))
        self.addGestureRecognizer(_tapGestureRecognizer)
        
        
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = NSUIColor.clear
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.backgroundColor = NSUIColor.clear
        #if os(OSX)
        scrollView.wantsLayer = true
        scrollContentView.wantsLayer = true
        scrollView.hasHorizontalScroller = true
        
       /* let clipView = NSClipView()
        clipView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.contentView = clipView
        
        scrollView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .left, relatedBy: .equal, toItem: scrollView, attribute: .left, multiplier: 1.0, constant: 0))
        scrollView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .top, relatedBy: .equal, toItem: scrollView, attribute: .top, multiplier: 1.0, constant: 0))
        scrollView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .right, relatedBy: .equal, toItem: scrollView, attribute: .right, multiplier: 1.0, constant: 0))
        scrollView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .bottom, relatedBy: .equal, toItem: scrollView, attribute: .bottom, multiplier: 1.0, constant: 0))
        scrollContentView.wantsLayer = true
        
        clipView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .left, relatedBy: .equal, toItem: scrollContentView, attribute: .left, multiplier: 1.0, constant: 0))
        clipView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .top, relatedBy: .equal, toItem: scrollContentView, attribute: .top, multiplier: 1.0, constant: 0))
        clipView.addConstraint(NSLayoutConstraint(item: clipView, attribute: .bottom, relatedBy: .equal, toItem: scrollContentView, attribute: .bottom, multiplier: 1.0, constant: 0))*/
#endif
        scrollContentView.translatesAutoresizingMaskIntoConstraints = false
        scrollContentView.backgroundColor = NSUIColor.clear
        
        
        self.addSubview(scrollView)
        
        #if os(iOS)
        scrollView.addSubview(scrollContentView)
        #elseif os(OSX)
        scrollView.documentView = scrollContentView
        #endif
        
       
        
        initScrollViewConstraints()
        
    }
    
    func initScrollViewConstraints()
    {
        
        scrollView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        
#if os(iOS)
        scrollContentView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        scrollContentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        scrollContentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        scrollContentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        
        scrollContentView.heightAnchor.constraint(equalTo: self.heightAnchor).isActive = true
        #endif
    }
    
    
    func refreshData() {
        
        if dataSource == nil
        {
            return
        }
        
        let drillEntryList = dataSource?.prepareDrillFilterMenuEntries()
        
        addViews(drillEntryList: drillEntryList!)

        if (self.scrollView.contentSize.width > self.scrollView.bounds.size.width )
        {
            let contentOffset = CGPoint(x: self.scrollView.contentSize.width - self.scrollView.bounds.size.width, y: 0)
//            self.scrollView.setContentOffset(contentOffset, animated: true)
            self.scrollView.contentOffset = contentOffset
        }
        
    }
    
#if !os(OSX)
    func addViews(drillEntryList:[DrillFilterMenuEntry])
    {
        let childViewArray = scrollContentView.subviews
        for child in childViewArray
        {
            child.removeFromSuperview()
        }
        
        var oldView:NSUIView!
        
        let count =  drillEntryList.count
        
        for i in 0 ..< count
        {
            let view = DrillFilterMenuEntryView(frame: .zero, drillFilterEntry: drillEntryList[i])
            view.translatesAutoresizingMaskIntoConstraints = false
            
            scrollContentView.addSubview(view)
            
            view.centerYAnchor.constraint(equalTo: scrollContentView.centerYAnchor).isActive = true
            view.heightAnchor.constraint(equalTo: scrollContentView.heightAnchor, multiplier: 1).isActive = true
            
            
            if i == 0
            {
                view.leadingAnchor.constraint(equalTo: scrollContentView.leadingAnchor, constant: 10).isActive = true
            }
            else
            {
                view.leadingAnchor.constraint(equalTo: oldView.trailingAnchor, constant: 10).isActive = true
            }
            
            if i == count - 1
            {
                view.trailingAnchor.constraint(equalTo: scrollContentView.trailingAnchor, constant: -10).isActive = true
            }
            
            oldView = view
            
            
            if i == count - 1
            {
                view.backgroundColor = NSUIColor.clear
                
                view.nsuiLayer?.opacity = 0
                
                #if os(iOS) || os(tvOS)
                UIView.animate(withDuration: 0.3, delay: 0.1, options: .curveLinear, animations: {
                    
                    view.layer.opacity = 1.0
                }, completion: nil)
                #else
                
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { //delays 1 second
//                  //code to delay
//
//                }
                
                // NSView move animation
                NSAnimationContext.runAnimationGroup({ context in
                    
                    context.duration = 0.3
                                            
                    view.nsuiLayer?.opacity = 1.0
//                        view.animator().alphaValue = 1.0
                }) {
                    // Handle completion
                }
                #endif
            }
            else
            {
                view.backgroundColor = NSUIColor.clear
            }
            
        }
        
    }
#else
    func getDrillFilterMenuEntrySize(drillEntryList:[DrillFilterMenuEntry]) -> [CGSize] {
        var sizeArray:[CGSize] = []
        for drillFilterMenuEntry in drillEntryList {
            sizeArray.append(DrillFilterMenuEntryView.getViewSize(drillFilterMenuEntry: drillFilterMenuEntry))
        }
        return sizeArray
    }
    
    func addViews(drillEntryList:[DrillFilterMenuEntry])
    {
        guard let containerView:ChartContainer = (self.superview as? ChartContainer) else {
            return
        }
        
        let childViewArray = scrollContentView.subviews
        for child in childViewArray
        {
            child.removeFromSuperview()
        }
        let viewHeight = containerView.drillDownHeightFactor * containerView.bounds.height
        
        let sizeArray = getDrillFilterMenuEntrySize(drillEntryList: drillEntryList)
        
        var contentSize = CGSize(width:0.0, height: viewHeight)
        
//        scrollContentView.setFrameSize(CGSize(width: 1600, height: 38))
        
        var oldView:NSUIView!
        
        let count =  drillEntryList.count
        var originX = 0.0
        for i in 0 ..< count
        {
            let size = sizeArray[i]
            if (i > 0) {
                originX = sizeArray[i-1].width + originX
            }
            let frame = CGRect(x: originX, y: 0, width: size.width, height: max(contentSize.height, size.height))
            contentSize.width = contentSize.width + frame.width
            contentSize.height = contentSize.height > frame.height ? contentSize.height : frame.height
            
            let view = DrillFilterMenuEntryView(frame: frame, drillFilterEntry: drillEntryList[i])
            scrollContentView.addSubview(view)
            oldView = view
        }
        scrollContentView.setFrameSize(contentSize)
        scrollView.documentView = scrollContentView
    }
#endif
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        if recognizer.state == NSUIGestureRecognizerState.ended
        {
            let view = recognizer.view
            let loc = recognizer.location(in: view)
            #if os(iOS) || os(tvOS)
            let subview = view?.hitTest(loc, with: nil)
            #else
//            let subview = view?.hitTest(loc)
            let subview = self.scrollView.hitTest(loc)
            #endif
            
            if subview != nil && (subview?.isKind(of: DrillFilterMenuEntryView.self))!
            {
                let drillFilterMenuEntryView = subview as! DrillFilterMenuEntryView
                
                drillFilterMenuEntryView.drillFilterMenuEntry?.dataLevel = scrollContentView.subviews.firstIndex(of: subview!)
                
                if self.delegate != nil
                {
                    self.delegate?.drillFilterMenuSelected(drillFilterMenuEntryView: drillFilterMenuEntryView)
                }
                
            }
        }
    }

}

