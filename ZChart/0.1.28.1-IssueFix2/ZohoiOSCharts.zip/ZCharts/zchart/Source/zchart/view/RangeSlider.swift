//
//  RangeSlider.swift
//  zchart
//
//  Created by Aravinth T on 25/04/19.
//  Copyright © 2019 zoho. All rights reserved.
//

import Foundation
#if !os(OSX)
    import UIKit
#endif
import QuartzCore

@objc
public protocol RangeSliderDelegate
{
    @objc optional func rangeSelected(minimum:Double,maximum:Double)
}

open class RangeSlider: NSUIView {
    
    let trackLayer = TrackLayer()
    
    let thumbLayer1 = ThumbLayer()
    
    let thumbLayer2 = ThumbLayer()
    
    open var plotLayer: CALayer?
    
    var previousLocation = CGPoint()
    
    open weak var delegate:RangeSliderDelegate? = nil
    
    var minimumValue: Double = 0.0
    
    var maximumValue: Double = 1.0
    
    var value1: Double = 0.0
    
    var value2: Double = 0.0
    
    var minimumSelectableRange = Double.greatestFiniteMagnitude
    
    var maximumSelectableRange = -Double.greatestFiniteMagnitude
    
    var legendEntries:[LegendEntry] = [] {
        didSet {
            if value1 == value2 && value1 == 0
            {
               updateMinMaxValues()
            }
            
        }
    }
    
    var colors:[NSUIColor] = []
    
    var values:[Double] = []
    
    open var trackerHeightInPercentage = 0.2
    
    open var trackerWidthInPercentage = 0.9
    
    open var thumbSize:CGFloat = 20
    
    @available(*, deprecated, message: "use trackerWidthInPercentage instead")
    var trackLayerSize:CGFloat = 10
    
    public var tickLabelcolor = NSUIColor.black
        
    public var tickLabelFont:NSUIFont = NSUIFont.systemFont(ofSize: 10)
    
    public var tickMarkercolor = NSUIColor.black
    
    lazy open var thumbShape = ShapeProperties()
    
    lazy open var highlightShape = ShapeProperties()
    
    lazy open var unHighlightShape = ShapeProperties()
    
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        #if os(OSX)
        self.wantsLayer = true
        #endif
        trackLayer.rangeSlider = self
        trackLayer.contentsScale = NSUIScreen().nsuiScale //UIScreen.main.scale
        nsuiLayer?.addSublayer(trackLayer)
        
        thumbLayer1.rangeSlider = self
        thumbLayer1.contentsScale = NSUIScreen().nsuiScale //UIScreen.main.scale
        nsuiLayer?.addSublayer(thumbLayer1)
        
        
        thumbLayer2.rangeSlider = self
        thumbLayer2.contentsScale = NSUIScreen().nsuiScale //UIScreen.main.scale
        nsuiLayer?.addSublayer(thumbLayer2)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
#if os(iOS) || os(tvOS)
    override open func layoutSubviews() {
        updateSubviews()
    }
#endif
#if os(OSX)
    open override func layout() {
        updateSubviews()
    }
#endif
    
   fileprivate func updateSubviews() {
        
        trackLayer.drawLayer(parentBound: self.bounds)
        
        trackLayer.addOrUpdateRangeGradientLayer()
        trackLayer.drawTickLabels()
        
        thumbLayer1.drawLayer(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: value1)))
        thumbLayer2.drawLayer(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: value2)))
    }
    
    func isVertical() -> Bool
    {
        return  (self.bounds.size.height > self.bounds.size.width)
    }
    
    fileprivate func updateMinMaxValues() {
        
        guard legendEntries.count > 0 else {
            return
        }
        
        if legendEntries.count == 1 && legendEntries[0].type == .linear {
            updateValuesForLinear(legendEntry: legendEntries[0])
        }else {
            updateValuesForDiscreteType(legendEntries: legendEntries)
        }
    }
    
    fileprivate func updateValuesForLinear(legendEntry: LegendEntry) {
        let values = legendEntry.value as! [Double]
        self.minimumValue = values[0]
        self.value1 = values[0]
        self.maximumValue = values[values.count - 1]
        self.value2 = values[values.count - 1]
        self.colors = legendEntry.colors!
        self.values = legendEntry.value as! [Double]
    }
    
    fileprivate func updateValuesForDiscreteType(legendEntries: [LegendEntry]) {
        let legendCount = legendEntries.count
        
        for i in stride(from: 0, through: legendCount, by: 1) {
            values.append(Double(i))
            if i > 0 && i < legendCount {
                values.append(Double(i))
            }
            
            if i < legendCount {
                colors.append(legendEntries[i].formColor!)
                colors.append(legendEntries[i].formColor!)
            }
        }
        
        self.minimumValue = values[0]
        self.value1 = values[0] + 0.5
        self.maximumValue = values[values.count - 1]
        self.value2 = values[values.count - 1] - 0.5
    }
    
    
    func positionForValue(value: Double) -> Double {
        
        //        let widthDouble = Double(thumbWidth)
        //        return Double(bounds.width - thumbWidth) * (value - minimumValue) /
        //            (maximumValue - minimumValue) + Double(thumbWidth / 2.0)
        
        if maximumValue == minimumValue
        {
            return minimumValue
        }
        let position:Double
        if isVertical()
        {
            position = Double(trackLayer.path!.boundingBoxOfPath.height) * (value - minimumValue) /
                (maximumValue - minimumValue)
        }
        else{
            position = Double(trackLayer.path!.boundingBoxOfPath.width) * (value - minimumValue) /
                (maximumValue - minimumValue)
        }
        return position
    }
    
    open override func nsuiTouchesBegan(_ touches: Set<NSUITouch>, withEvent: NSUIEvent?) {
        guard let touch = touches.first
            else { return }
        
        startTouch(location: touch.location(in: self))
    }
    
    open override func nsuiTouchesMoved(_ touches: Set<NSUITouch>, withEvent: NSUIEvent?) {
        
        guard let touch = touches.first
            else { return }
        
        moveTouch(location: touch.location(in: self))
    }
    
    open override func nsuiTouchesEnded(_ touches: Set<NSUITouch>, withEvent: NSUIEvent?)
    {
        
        guard let touch = touches.first
            else { return }
        
        endTouch(location: touch.location(in: self))
    }
    
    #if os(OSX)
    open override func mouseDown(with theEvent: NSEvent)
    {
        startTouch(location: self.convert(theEvent.locationInWindow, from: nil))
    }
    open override func mouseDragged(with theEvent: NSEvent)
    {
        moveTouch(location: self.convert(theEvent.locationInWindow, from: nil))
    }
    open override func mouseUp(with theEvent: NSEvent)
    {
        endTouch(location: self.convert(theEvent.locationInWindow, from: nil))
    }
    #endif

    
    func startTouch(location: NSPoint) {
        
        previousLocation = location
        
        var thumb1IsLower = false
        var thumb2IsLower = false
        
        if isVertical() {
            if thumbLayer1.frame.origin.y > thumbLayer2.frame.origin.y {
                thumb2IsLower = true
            }
            else {
                thumb1IsLower = true
            }
        }
        else {
            if thumbLayer1.frame.origin.x > thumbLayer2.frame.origin.x {
                thumb2IsLower = true
            }
            else {
                thumb1IsLower = true
            }
        }
        
        // Hit test the thumb layers
        if isTouchPointInthumbPosition(touchPoint: previousLocation, thumbLayer: thumbLayer1, isLowerThumb: thumb1IsLower) {
            thumbLayer1.highlighted = true
        } else if isTouchPointInthumbPosition(touchPoint: previousLocation, thumbLayer: thumbLayer2, isLowerThumb: thumb2IsLower) {
            thumbLayer2.highlighted = true
        }
        if isTouchPointInHighlightPosition(touchPoint: previousLocation, lowerThumbLayer: getLowerThumbLayer(), upperThumbLayer: getUpperThumbLayer())
        {
            thumbLayer1.highlighted = true
            thumbLayer2.highlighted = true
        }
    }
    
    func moveTouch(location:NSPoint) {
        
        let location = location
        
        // 1. Determine by how much the user has dragged
        let deltaLocation = isVertical() ?  Double(location.y - previousLocation.y) : Double(location.x - previousLocation.x)
        let deltaValue = isVertical() ? (maximumValue - minimumValue) * deltaLocation / Double(bounds.height) : (maximumValue - minimumValue) * deltaLocation / Double(bounds.width - bounds.height)
        
        previousLocation = location
        
        if thumbLayer1.highlighted && thumbLayer2.highlighted
        {
            updateThumbToSelectedRange(deltaValue: deltaValue)
        }
        else {
            if thumbLayer1.highlighted
            {
                
                if value1 + deltaValue > value2
                {
                    thumbLayer1.highlighted = false
                    thumbLayer2.highlighted = true
                }
            }
            else if thumbLayer2.highlighted
            {
                if value2 + deltaValue < value1
                {
                    thumbLayer1.highlighted = true
                    thumbLayer2.highlighted = false
                }
            }
            
            if  thumbLayer1.highlighted
            {
                let value = value1
                updateValue1(withDiff: deltaValue)
                if isSelectedRangeIsInMaxRangeBound() && isSelectedRangeIsInMinRangeBound() {
    
                    thumbLayer1.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: value1)), animated: false)
                }
                else {
                    value1 = value
                    updateThumbToSelectedRange(deltaValue: deltaValue)
                }
            }
            else if thumbLayer2.highlighted
            {
                let value = value2
                updateValue2(withDiff: deltaValue)
                if isSelectedRangeIsInMaxRangeBound() && isSelectedRangeIsInMinRangeBound() {
                    thumbLayer2.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: value2)), animated: false)
                }
                else {
                    value2 = value
                    updateThumbToSelectedRange(deltaValue: deltaValue)
                }
            }
        }
        
        callDelegate()
        
    }
    
    func endTouch(location:NSPoint) {
        
        if !isLinearLegendType() {
            animateThumbLayersOnEnd()
        }
        
        thumbLayer1.highlighted = false
        thumbLayer2.highlighted = false
    }
    
    
    func updateThumbToSelectedRange(deltaValue: Double) {
        
        let lowerValue = getLowerValue()
        let upperValue = getUpperValue()
        
        let (minVal,maxVal) = getMinMaxValues()
        
        if deltaValue < 0 {
                    
            let newLowerValue = boundValue(deltaValue + lowerValue, toLowerValue: minVal, upperValue: maxVal)
                    
            if ((lowerValue + deltaValue) < minVal) {
                let diff = lowerValue - newLowerValue
                updateUpperValue(withDiff: -diff)
            }else {
                updateUpperValue(withDiff: deltaValue)
            }
                    
            updateLowerValue(withDiff: deltaValue)
                    
        } else {
                    
            let newUpperValue = boundValue(upperValue + deltaValue, toLowerValue: lowerValue, upperValue: maxVal)
                    
            if ((upperValue + deltaValue) > maxVal) {
                let diff = newUpperValue - upperValue
                updateLowerValue(withDiff: diff)
            }else {
                updateLowerValue(withDiff: deltaValue)
            }
            updateUpperValue(withDiff: deltaValue)
        }
        
        thumbLayer1.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: value1)), animated: false)
        
        thumbLayer2.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: value2)), animated: false)
    }
    
    func animateThumbLayersOnEnd() {
        
        var lowerValue = getLowerValue()
        var upperValue = getUpperValue()
        
        let lowerThumbLayer = getLowerThumbLayer()
        let upperThumbLayer = getUpperThumbLayer()
        
        let delta:Double = 0.5
        
        if lowerThumbLayer.highlighted && upperThumbLayer.highlighted {
            
            if upperValue >= maximumValue {
                upperValue = maximumValue - 1
                lowerValue = max(lowerValue - 1, minimumValue )
            }
            
            if lowerValue <= minimumValue {
                lowerValue = minimumValue
                upperValue = min(ceil(upperValue), maximumValue - 1)
            }
            
            if lowerValue > minimumValue {
                lowerValue = floor(lowerValue)
            }
            
            if upperValue < maximumValue {
                upperValue = floor(upperValue)
            }
            
            lowerValue += delta
            upperValue += delta
            
            replaceLowerValue(withValue: lowerValue)
            replaceUpperValue(withValue: upperValue)
            
            lowerThumbLayer.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: getLowerValue())), animated: true)
            
            upperThumbLayer.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: getUpperValue())), animated: true)
            
            callDelegate()
            
        } else if lowerThumbLayer.highlighted {
            
            if lowerValue > minimumValue {
                lowerValue = floor(lowerValue)
            }
            lowerValue += delta
            replaceLowerValue(withValue: lowerValue)
            
            lowerThumbLayer.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: getLowerValue())), animated: true)
        }
        else if upperThumbLayer.highlighted {
            
            if upperValue < maximumValue {
                upperValue = ceil(upperValue)
            }
            upperValue -= delta
            replaceUpperValue(withValue: upperValue)
            
            upperThumbLayer.updatePosition(parentBound: trackLayer.getBoundingBox(), thumbPoint: CGFloat(positionForValue(value: getUpperValue())), animated: true)
        }
        
    }

    
    fileprivate func callDelegate() {
        
        var lowerValue = getLowerValue()
        var upperValue = getUpperValue()
        
        if !isLinearLegendType() {
            
            if lowerValue > minimumValue {
                lowerValue = floor(lowerValue)
            }
            
            if upperValue < maximumValue {
                upperValue = floor(upperValue)
            } else {
                upperValue = maximumValue - 1
            }
            
        }
        
        self.delegate?.rangeSelected!(minimum: lowerValue, maximum: upperValue)
        
    }
    
    func isTouchPointInHighlightPosition(touchPoint:CGPoint,lowerThumbLayer:ThumbLayer,upperThumbLayer:ThumbLayer) -> Bool {
        
        guard let trackerBounds = trackLayer.path?.boundingBox else {
            return false
        }
        
        var touchPosition = touchPoint
        
        var newRect = CGRect(x: lowerThumbLayer.frame.maxX, y: trackerBounds.origin.y, width: upperThumbLayer.frame.minX - lowerThumbLayer.frame.maxX, height: trackerBounds.height)
       
        if isVertical()
        {
            newRect = CGRect(x: trackerBounds.origin.x, y: lowerThumbLayer.frame.maxY, width: trackerBounds.width, height: upperThumbLayer.frame.minY - lowerThumbLayer.frame.maxY)
        }
        
        if newRect.contains(touchPosition) {
            return true
        }
        
        return false
    }
    
    func isTouchPointInthumbPosition(touchPoint:CGPoint,thumbLayer:ThumbLayer, isLowerThumb: Bool) -> Bool {
        
        var origin = thumbLayer.frame.origin
        var size = thumbLayer.frame.size
        
        var touchPosition = touchPoint
               
        if isVertical() {
            if isLowerThumb {
                origin.y -= thumbLayer.frame.width
            }
            size.height += thumbLayer.frame.width
            touchPosition.x = thumbLayer.frame.minX
        }
        else {
            if isLowerThumb {
                origin.x -= thumbLayer.frame.width
            }
            size.width += thumbLayer.frame.width
            touchPosition.y = thumbLayer.frame.minY
        }
               
        return CGRect(origin: origin, size: size).contains(touchPosition)
    }
    
    fileprivate func isLinearLegendType() -> Bool {
        
        var isLinear:Bool = true
        
        if legendEntries.count > 0 && (legendEntries[0].type == .range || legendEntries[0].type == .discrete) {
            isLinear = false
        }
        
        return isLinear
    }
    
    func boundValue(_ value: Double, toLowerValue lowerValue: Double, upperValue: Double) -> Double {
        return min(max(value, lowerValue), upperValue)
    }
    
    func getLowerThumbLayer() -> ThumbLayer {
        
        if isVertical() {
            if thumbLayer1.frame.origin.y <= thumbLayer2.frame.origin.y {
                return thumbLayer1
            }
        }
        else {
            if thumbLayer1.frame.origin.x <= thumbLayer2.frame.origin.x {
                return thumbLayer1
            }
        }
        return thumbLayer2
    }
    
    func getUpperThumbLayer() -> ThumbLayer {
        
        if isVertical() {
            if thumbLayer2.frame.origin.y >= thumbLayer1.frame.origin.y {
                return thumbLayer2
            }
        }
        else {
            if thumbLayer2.frame.origin.x >= thumbLayer1.frame.origin.x {
                return thumbLayer2
            }
        }
        return thumbLayer1
    }
    
    func getLowerValue() -> Double {
        return value1
    }
    
    func getUpperValue() -> Double {
        return value2
    }
    
    fileprivate func updateUpperValue(withDiff delta: Double) {
        updateValue2(withDiff: delta)
    }
    
    fileprivate func updateLowerValue(withDiff delta: Double) {
        updateValue1(withDiff: delta)
    }
    
    fileprivate func replaceUpperValue(withValue value: Double) {
        replaceValue2(withValue: value)
    }
    
    fileprivate func replaceLowerValue(withValue value: Double) {
        replaceValue2(withValue: value)
    }
    
    fileprivate func updateValue1(withDiff delta: Double) {
        value1 += delta
        //        value1 = boundValue(value1, toLowerValue: minimumValue, upperValue: maximumValue)
        replaceValue1(withValue: value1)
    }
    
    fileprivate func updateValue2(withDiff delta: Double) {
        value2 += delta
        //        value2 = boundValue(value2, toLowerValue: minimumValue, upperValue: maximumValue)
        replaceValue2(withValue: value2)
    }
    
    fileprivate func replaceValue2(withValue value:Double) {
        let (minVal,maxVal) = getMinMaxValues()
        value2 = boundValue(value, toLowerValue: minVal, upperValue: maxVal)
    }
    
    fileprivate func replaceValue1(withValue value:Double) {
        let (minVal,maxVal) = getMinMaxValues()
        value1 = boundValue(value, toLowerValue: minVal, upperValue: maxVal)
    }
    
    fileprivate func isSelectedRangeIsInMaxRangeBound() -> Bool {
        
            return abs(value1 - value2) >= maximumSelectableRange
    }
    
    fileprivate func isSelectedRangeIsInMinRangeBound() -> Bool {
            return abs(value1 - value2) <= minimumSelectableRange
    }
    
    func getMinMaxValues() -> (Double,Double){
        return (min(minimumValue,maximumValue),max(minimumValue,maximumValue))
    }
    
}

class TrackLayer : CAShapeLayer {
    
    weak var rangeSlider: RangeSlider?
    
    func drawLayer(parentBound: CGRect) {
        
        guard let rangeSlider = rangeSlider else {
            return
        }
        
        let trackerBound:CGRect
        
        let size = CGSize(width: parentBound.width * rangeSlider.trackerWidthInPercentage, height: parentBound.height * rangeSlider.trackerHeightInPercentage)
        
        let origin = CGPoint(x: parentBound.midX - size.width / 2.0, y: parentBound.midY - size.height / 2.0)

        trackerBound  = CGRect(origin: origin, size: size)
        
        let curvaceousness:CGFloat = 0
        
        let cornerRadius = trackerBound.height * curvaceousness / 2.0
        
        let path = CGMutablePath(roundedRect: trackerBound, cornerWidth: cornerRadius, cornerHeight: cornerRadius, transform: nil)
        self.path = path
        
        if let plotLayer = rangeSlider.plotLayer {
            
            plotLayer.frame = trackerBound
            
            plotLayer.backgroundColor = NSUIColor.clear.cgColor
            
            self.addSublayer(plotLayer)
        }
    }
    
    func addOrUpdateRangeGradientLayer() {
        
        guard let rangeSlider = rangeSlider else {
            return
        }
        
        let isVertical = rangeSlider.isVertical()
        
        var gradientCALayer:CALayer? = getGradientLayer(layer: self)
        
        var gradientLayer:CAGradientLayer? = nil
        
        if gradientCALayer == nil {
            gradientLayer = CAGradientLayer()
            gradientCALayer = gradientLayer
            self.addSublayer(gradientLayer!)
        }else {
            //For now no need to update anything on Actual Gradient values
            gradientLayer = (gradientCALayer as! CAGradientLayer)
//            gradientLayer!.frame = (self.path?.boundingBox)!
//            return
        }
        
        if let gradientLayer = gradientLayer {
            
            if isVertical
            {
                gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
                gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
            }
            else{
                gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
                gradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
            }
            
            
            gradientLayer.locations = prepareColorLocations() as [NSNumber] //[0,0.2,0.8,1]
            gradientLayer.colors = prepareColors() // [NSUIColor.red.cgColor, NSUIColor.green.cgColor, NSUIColor.blue.cgColor, NSUIColor.yellow.cgColor]
            
            gradientLayer.frame = (self.path?.boundingBox)!
            
            let maskLayer = CAShapeLayer()
            maskLayer.path = self.path
            maskLayer.position = CGPoint(x: -gradientLayer.frame.origin.x, y: -gradientLayer.frame.origin.y)
            gradientLayer.mask = maskLayer
        }
    }
    
    func updateTrackerLayer() {
        
        guard let rangeSlider = rangeSlider else {
            return
        }
        
        let (minVal,maxVal) = rangeSlider.getMinMaxValues()
        
        createAndUpdateHighlightLayer(value: .HighlightLayer, key: "highlightLayer", shapeProperties: rangeSlider.highlightShape, lowerValue: rangeSlider.getLowerValue(), upperValue: rangeSlider.getUpperValue())
        
        createAndUpdateHighlightLayer(value: .UnHighlightLayer1, key: "UnHighlightLayer", shapeProperties: rangeSlider.unHighlightShape, lowerValue: minVal, upperValue: rangeSlider.getLowerValue())
        
        createAndUpdateHighlightLayer(value: .UnHighlightLayer2, key: "UnHighlightLayer", shapeProperties: rangeSlider.unHighlightShape, lowerValue: rangeSlider.getUpperValue(), upperValue: maxVal)
    }
    
    func createAndUpdateHighlightLayer(value: layerType, key: String, shapeProperties: ShapeProperties, lowerValue: Double, upperValue: Double) {
        
        let highlightLayer = getHighlightLayerBy(value: value, key: key)
        
        addHighlightLayer(highlightLayer: highlightLayer, lowerValue: lowerValue, upperValue: upperValue,shapeProperties: shapeProperties)
        
    }
    
    func addHighlightLayer(highlightLayer: CAShapeLayer?, lowerValue: Double, upperValue: Double,shapeProperties:ShapeProperties ) {
        
        if shapeProperties.shapeType == .Default {
            return
        }
        
        let rect = getUpdatedBound(lowerValue: lowerValue, upperValue: upperValue)
        
        if let highlightLayer = highlightLayer {
            
            highlightLayer.frame = rect
            
            highlightLayer.bounds = highlightLayer.frame
            
            shapeProperties.size = rect.size
            
            _ = CommonHelperFunctions.drawShapeLayerGeneric(shapeProperties: shapeProperties, entry: nil, currentLayer: highlightLayer)
        }
    }
    
    func getUpdatedBound(lowerValue: Double, upperValue: Double) -> CGRect {
        
        guard let rangeSlider = rangeSlider else {
            return CGRect()
        }
        
        let bound = getBoundingBox()
        
        var size = bound.size
        
        var origin = bound.origin
        
        let positionForUpper = CGFloat(rangeSlider.positionForValue(value: upperValue))
        
        let positionForLower =  CGFloat(rangeSlider.positionForValue(value: lowerValue))
        
        if rangeSlider.isVertical() {
            size.height = positionForUpper - positionForLower
            origin.y += positionForLower
        }
        else {
            size.width = positionForUpper - positionForLower
            origin.x += positionForLower
        }
        
        return CGRect(origin: origin, size: size)
    }
    
    func getBoundingBox() -> CGRect
    {
        let bound = (self.path?.boundingBox)!
        return bound //CGRect(origin: CGPoint.zero, size: bound.size)
    }
    
    func addMaskLayer() {
        
        guard let rangeSlider = rangeSlider, let plotLayer = rangeSlider.plotLayer else {
            return
        }
        
        let positionForUpper = CGFloat(rangeSlider.positionForValue(value: rangeSlider.getUpperValue()))
        
        let positionForLower =  CGFloat(rangeSlider.positionForValue(value: rangeSlider.getLowerValue()))
        
        let (min,max) = (min(positionForLower,positionForUpper),max(positionForLower,positionForUpper))
        
        let trackerLayerBounds = getBoundingBox()
        
        let path = CGMutablePath()
        
        if rangeSlider.isVertical() {
            
            let lowerHeight = min - trackerLayerBounds.minY
            
            path.addRect(CGRect(origin: trackerLayerBounds.origin, size: CGSize(width: trackerLayerBounds.width, height: lowerHeight)))
            
            let upperHeight = trackerLayerBounds.maxY - max
            
            path.addRect(CGRect(origin: CGPoint(x: trackerLayerBounds.minX, y: max), size: CGSize(width: trackerLayerBounds.width, height: upperHeight)))
        }
        else {
            let lowerWidth = min - trackerLayerBounds.minX
            
            path.addRect(CGRect(origin: trackerLayerBounds.origin, size: CGSize(width: lowerWidth, height: trackerLayerBounds.height)))
            
            let upperWidth = trackerLayerBounds.maxX - max
            
            path.addRect(CGRect(origin: CGPoint(x: max, y: trackerLayerBounds.minY), size: CGSize(width: upperWidth, height: trackerLayerBounds.height)))
        }
        
        updateMaskLayer(path: path, layer: plotLayer)
    }
    
    
    fileprivate func updateMaskLayer(path:CGPath,layer:CALayer) {
            
        let maskLayer = CAShapeLayer()
        
        maskLayer.path = path

        layer.mask = maskLayer
        
    }
    
    func getHighlightLayerBy(value: layerType, key: String) -> CAShapeLayer? {
        
        guard let rangeSlider = rangeSlider else {
            return nil
        }
        
        var highlightCALayer = getHighlightLayer(layer: rangeSlider.nsuiLayer!, key: key, value: value)
        
        if highlightCALayer == nil {
            
            highlightCALayer = HighlightLayer()
            
            rangeSlider.nsuiLayer?.addSublayer(highlightCALayer!)
        }
        
        highlightCALayer?.setValue(value, forKey: key)
        
        return highlightCALayer as? CAShapeLayer
    }
    
    func getHighlightLayer(layer: CALayer, key: String, value: layerType) -> CALayer?
    {
        
        guard let subLayers = layer.sublayers else {
            return nil
        }
        
        for subLayer in subLayers
        {
            if subLayer.isKind(of: HighlightLayer.self)
            {
                
                guard let type = (subLayer.value(forKey:key) as? TrackLayer.layerType), type == value else {
                    continue
                }
                
                return subLayer
            }
        }
        
        return nil
    }
    
    func getGradientLayer(layer: CALayer) -> CALayer? {
        
        guard let sublayers = layer.sublayers else {
            return nil
        }
        
        for sublayer in sublayers {
            
            if sublayer.isKind(of: CAGradientLayer.self) {
                return sublayer
            }
        }
        
        return nil
    }
    
    //Need to change based on legend type - discrete , range & etc
    func prepareColorLocations() -> [CGFloat] {
        guard  let rangeSlider = self.rangeSlider else {
            return []
        }
        var locations:[CGFloat] = []
        let values = rangeSlider.values
        
        let diffValue = (rangeSlider.maximumValue) - (rangeSlider.minimumValue)
        
        for value in values {
            var location = CGFloat((value - (rangeSlider.minimumValue)) / (diffValue))
            if location.isNaN
            {
                location = CGFloat(rangeSlider.minimumValue)
            }
            locations.append(location)
        }
        
        return locations
    }
    
    func prepareColors() -> [CGColor] {
        
        guard  let rangeSlider = self.rangeSlider else {
            return []
        }
        
        var cgColors:[CGColor] = []
        for color in rangeSlider.colors {
            cgColors.append(color.cgColor)
        }
        return cgColors
    }
    
    fileprivate func getValuePositions() -> [CGFloat] {
        
        var valuePositions:[CGFloat] = []
        
        guard  let rangeSlider = rangeSlider,
            rangeSlider.legendEntries.count > 0
            else {
                return valuePositions
        }
        
        let boundingBox = getBoundingBox()
        
        let origin = boundingBox.origin
        
        let size = boundingBox.size
        
        let width = size.width
        
        if rangeSlider.isLinearLegendType()
        {
            let stopPoints = rangeSlider.values
            
            let colorLocations = prepareColorLocations()
            
            for i in 0 ..< stopPoints.count {
                
                let position = colorLocations[i]
                
                let originValue = rangeSlider.isVertical() ?  size.height * position + origin.y : width * position + origin.x
                
                valuePositions.append(originValue)
            }
        }
        else
        {
            let count = rangeSlider.legendEntries.count
            
            let cellWidth = rangeSlider.isVertical() ?  size.height / CGFloat(count) : size.width / CGFloat(count)
            
            var prevPositionValue:CGFloat = 0
            
            for _ in 0 ..< count {
                
                let originValue = rangeSlider.isVertical() ? prevPositionValue + cellWidth / 2 + origin.y : prevPositionValue + cellWidth / 2 + origin.x
                
                valuePositions.append(originValue)
                
                prevPositionValue = prevPositionValue + cellWidth
            }
        }
        
        return valuePositions
    }
    
    func drawTickLabels() {
        
        guard  let rangeSlider = rangeSlider else {
            return
        }
        
        removeAllTextAndTickLayers()
        
        let boundingBox = getBoundingBox()
        
        let font = rangeSlider.tickLabelFont
        
        let fontColor = rangeSlider.tickLabelcolor
        
        let attribites = [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: fontColor]
        
        let dummyText = "Text"
        
        let valuePosition = getValuePositions()
        
        if rangeSlider.isVertical()
        {
            let xPosition = boundingBox.minX
            
            let threshold = (dummyText.size(withAttributes: attribites).height / 2)//max(CGFloat(rangeSlider.thumbSize / 2), boundingBox.width/2, (dummyText.size(withAttributes: attribites).height / 2) + boundingBox.width/2)
            
            let originX = boundingBox.minX - threshold
            
            for i in 0 ..< valuePosition.count {
                
                let position = valuePosition[i]
                let text = getLabel(index: i)!
                let textSize = text.size(withAttributes: attribites)
                let originY = position - textSize.height / 2.0
                
                let textFrame = CGRect(x: originX - textSize.width, y: originY, width: textSize.width, height: textSize.height)
                self.addSublayer(createTextLayer(text: text, frame: textFrame, fontColor: fontColor, font: font))
                
                let lineStart = CGPoint(x: xPosition, y: position)
                let lineEnd = CGPoint(x: xPosition - dummyText.size(withAttributes: attribites).height / 3, y: position)
                self.addSublayer(createTickMarkLayer(startPoint: lineStart, endPoint: lineEnd))
            }
        }
        else{
        
            let yPosition = boundingBox.maxY//origin.y + CGFloat(rangeSlider.thumbSize / 2)
            
            let originY = yPosition + dummyText.size(withAttributes: attribites).height / 2
            
            for i in 0 ..< valuePosition.count {
                
                let position = valuePosition[i]
                let text = getLabel(index: i)!
                let textSize = text.size(withAttributes: attribites)
                let originX = position - textSize.width / 2.0
                
                let textFrame = CGRect(x: originX, y: originY, width: textSize.width, height: textSize.height)
                self.addSublayer(createTextLayer(text: text, frame: textFrame, fontColor: fontColor, font: font))
                
                let lineStart = CGPoint(x: position, y: yPosition)
                let lineEnd = CGPoint(x: position, y: yPosition + dummyText.size(withAttributes: attribites).height / 3)
                self.addSublayer(createTickMarkLayer(startPoint: lineStart, endPoint: lineEnd))
            }
        }
    }
    
    func getLabel(index:Int) -> String? {
        
        var label:String? = nil
        
        guard  let rangeSlider = rangeSlider else {
            return label
        }
        
        if rangeSlider.isLinearLegendType() {
            label = String(rangeSlider.values[index])
        } else {
            label = rangeSlider.legendEntries[index].label
        }
        return label
    }
    
    fileprivate func removeAllTextAndTickLayers() {
        guard let childLayers = self.sublayers else {
            return
        }
        
        for child in childLayers {
            if child.isKind(of: CATextLayer.self) || child.isKind(of: CAShapeLayer.self) {
                child.removeFromSuperlayer()
            }
        }
        
    }
    
    fileprivate func createTextLayer(text:String, frame:CGRect, fontColor:NSUIColor, font:NSUIFont) -> CATextLayer {
        let layer = CATextLayer()
        layer.string = text
        layer.frame = frame
        layer.alignmentMode = convertToCATextLayerAlignmentMode("center")
        layer.fontSize = font.pointSize
        layer.font = font
        layer.foregroundColor = fontColor.cgColor
        layer.contentsScale = NSUIMainScreen()!.nsuiScale
        return layer
    }
    
    fileprivate func createTickMarkLayer(startPoint:CGPoint, endPoint:CGPoint) -> CAShapeLayer {
        let lineLayer = CAShapeLayer()
        let path = CGMutablePath()
        path.move(to: startPoint)
        path.addLine(to: endPoint)
        path.closeSubpath()//.close()
        lineLayer.path = path//.cgPath
        lineLayer.strokeColor = rangeSlider?.tickMarkercolor.cgColor
        return lineLayer
    }
    
    fileprivate func convertToCATextLayerAlignmentMode(_ input: String) -> CATextLayerAlignmentMode {
        return CATextLayerAlignmentMode(rawValue: input)
    }
    
    enum layerType {
        case HighlightLayer
        case UnHighlightLayer1
        case UnHighlightLayer2
    }
}

class ThumbLayer : CAShapeLayer
{
    var radius:CGFloat = 30
    
    weak var rangeSlider: RangeSlider?
    
    var highlighted:Bool = false
    
    func drawLayer(parentBound: CGRect, thumbPoint:CGFloat)
    {
        guard  let rangeSlider = self.rangeSlider else {
            return
        }
        
        self.zPosition = 1
        
        var size = CGSize(width: rangeSlider.thumbSize, height: parentBound.height)
        
        if rangeSlider.isVertical() {
            size = CGSize(width: rangeSlider.thumbSize, height: parentBound.width)
        }
        
        self.bounds.size = size
        
        rangeSlider.thumbShape.size = size
        
        _ = CommonHelperFunctions.drawShapeLayerGeneric(shapeProperties: rangeSlider.thumbShape, entry: nil, currentLayer: self)
        
        updatePosition(parentBound: parentBound, thumbPoint: thumbPoint, animated: false)
    }
    
    func updatePosition(parentBound: CGRect, thumbPoint:CGFloat, animated: Bool) {
        
        guard  let rangeSlider = self.rangeSlider else {
            return
        }
        
        let xPosition = rangeSlider.isVertical() ? parentBound.midX : parentBound.origin.x + thumbPoint
        let yPosition = rangeSlider.isVertical() ? parentBound.origin.y + thumbPoint : parentBound.midY
        let endPosition = CGPoint(x: xPosition, y: yPosition)
        
        if animated {
            CATransaction.begin()
            
            let anim = CABasicAnimation(keyPath: "position")
            
            anim.fromValue = self.position
            
            anim.toValue = endPosition
            
            anim.duration = 0.5
            
            anim.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
            
            self.add(anim, forKey: "position")
            
            CATransaction.commit()
        }
        
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        self.position = endPosition
        rangeSlider.trackLayer.updateTrackerLayer()
        rangeSlider.trackLayer.addMaskLayer()
        CATransaction.commit()
    }
}
