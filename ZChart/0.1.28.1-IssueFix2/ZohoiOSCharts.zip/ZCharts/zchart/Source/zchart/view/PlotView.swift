//
//  PlotView.swift
//  zchart
//
//  Created by Aravinth T on 30/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

class PlotView: NSUIView {

    weak var chartViewBase:ChartViewBase? = nil
    
    init(frame: CGRect, chart: ChartViewBase) {
        super.init(frame: frame)
        self.chartViewBase = chart
        
//        if chart.isKind(of: BarLineChartViewBase.self)
//        {
            self.drawMaskLayer()
//        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func drawMaskLayer()
    {
        
        guard let chart = chartViewBase else {
            return
        }
        
        var rect = chart._viewPortHandler.contentRect
        
        if chart.isPlotBeyondAxisLine {
            
            var size = CommonHelperFunctions.maxPixelSizeOfPlot(chart: chart)
            
            size = size > 0.0 ? size / 2.0 : 0.0
            
            rect = CGRect(origin: chart._viewPortHandler.contentRect.origin, size: CGSize(width: chart._viewPortHandler.contentRect.width, height: chart._viewPortHandler.contentRect.height + size))
        }
        
        let maskLayer = CAShapeLayer()
        
        let path = CGMutablePath(rect: rect, transform: nil)//let path = UIBezierPath(rect: rect)
        
        maskLayer.path = path//.cgPath
        
        self.backgroundColor = NSUIColor.clear
        
        self.nsuiLayer?.mask = maskLayer

    }
    
}
