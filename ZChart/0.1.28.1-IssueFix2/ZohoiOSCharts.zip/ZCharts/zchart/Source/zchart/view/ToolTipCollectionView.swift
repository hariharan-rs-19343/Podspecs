//
//  ToolTipCollectionView.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 14/02/18.
//  Copyright © 2018 zoho. All rights reserved.
//

@objc
public protocol TooltipViewDelegate
{
    @objc optional func tooltipSelected(entry: ChartDataEntry?)
}

#if os(iOS) || os(tvOS)
open class ToolTipCollectionView:UIView,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    open var tooltip:ChartTooltip = ChartTooltip()
    
    open var contentView:contentUIView!
    
    open var tooltipContentSize:CGSize!
    
    var toolTipContentView:UICollectionView!
    
    var allowed:Bool = true
    
    weak var delegateToContainer:TooltipViewDelegate? = nil
    
    weak var oldEntry:ChartDataEntry? = nil
    
    open var showView:Bool
        {
        set {
            self.tooltip.tooltipEnabled = newValue
        }
        get {
            return self.tooltip.tooltipEnabled
        }
    }
    
    let maskLayer = CAGradientLayer()
    
    var itemInterSpace:CGFloat = 50
    
    var allConstraints:[NSLayoutConstraint] = []

    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.initialize()
    }
    
    
    required public init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize()
    {
        contentView = contentUIView()
        
        contentView.addDelegate(toolTip: self)
        
        toolTipContentView  = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        
        self.addSubview(contentView)
        
        contentView.addSubview(toolTipContentView)
        
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
        toolTipContentView.translatesAutoresizingMaskIntoConstraints = false
        
        resetOrientation()
        
        toolTipContentView.backgroundColor = NSUIColor.clear
        
        toolTipContentView.delegate = self
        
        toolTipContentView.dataSource = self
        
        toolTipContentView.register(ToolTipItemCell.self, forCellWithReuseIdentifier: "ToolTipItemCell")
        
        let _tapGestureRecognizer = NSUITapGestureRecognizer(target: self, action: #selector(self.tapGestureRecognized(_:)))
        
        self.addGestureRecognizer(_tapGestureRecognizer)
        
        self.tooltip.typeChangedClosure = { [weak self] in
            
            guard let selfReference = self else {
                return
            }
            selfReference.resetOrientation()
        }
        
    }
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        if recognizer.state == NSUIGestureRecognizerState.ended
        {
            delegateToContainer?.tooltipSelected!(entry: oldEntry)
        }
    }
    
    
    func reloadData(entry: ChartDataEntry?)
    {
        self.oldEntry = entry
        
        validateConstraints()
        
        toolTipContentView.reloadData()
        
        toolTipContentView.layoutIfNeeded()
        
        addMask()
       
    }
    
    func validateConstraints()
    {
        
        currentEntries = self.tooltip._toolTipEntryGenerator.prepareToolTipEntries(entry: oldEntry)
        
        var maxWidth:CGFloat = 0
        var maxHeight:CGFloat = 0
        
        for entry in currentEntries {
            
            let labelText = entry.label
            let valueText = entry.value
            
            let labelSize = (labelText).size(withAttributes: [NSAttributedString.Key.font: entry.labelFont])
            let valueSize = (valueText).size(withAttributes: [NSAttributedString.Key.font: entry.valueFont])
            
            if self.tooltip.toolTipType == .Centered
            {
                maxWidth  += max(labelSize.width, valueSize.width) + 5
                
                maxHeight = labelSize.height + valueSize.height + 20
            }
            else{
                maxHeight += max(labelSize.height,valueSize.height) + 5
            }
            
            if currentEntries.count > 1
            {
                    maxWidth += itemInterSpace
            }
            
            
        }
        
        tooltipContentSize = CGSize(width: maxWidth, height: maxHeight)
        
        if contentView.bounds.height == 0
        {
            maxHeight = 0
        }
       
        if allConstraints.count > 0
        {
            NSLayoutConstraint.deactivate(allConstraints)
        }
        
        
        if (maxHeight >= contentView.bounds.height && self.tooltip.toolTipType == .leftRight) || (maxWidth >= contentView.bounds.width && self.tooltip.toolTipType == .Centered)
        {
            
           tooltipContentSize.width = tooltipContentSize.width - itemInterSpace

            //TooltipContentView
            let toolTipcontentViewLeading = toolTipContentView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
            let toolTipcontentViewTrailing = toolTipContentView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            let toolTipcontentViewTop = toolTipContentView.topAnchor.constraint(equalTo: contentView.topAnchor)
            let toolTipcontentViewBottom = toolTipContentView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
            
            allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom]
            
        }
        else{
           
            if self.tooltip.leftAlignEnabled
            {
                tooltipContentSize = contentView.bounds.size
                
                //TooltipContentView
                let toolTipcontentViewLeading = toolTipContentView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
                let toolTipcontentViewTrailing = toolTipContentView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
                let toolTipcontentViewTop = toolTipContentView.topAnchor.constraint(equalTo: contentView.topAnchor)
                let toolTipcontentViewBottom = toolTipContentView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
                
                allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom]
            }
            else if self.tooltip.toolTipType == .leftRight
            {
                
                //TooltipContentView
                let toolTipcontentViewLeading = toolTipContentView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
                let toolTipcontentViewTrailing = toolTipContentView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
                let toolTipcontentViewCenterY = toolTipContentView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
                let toolTipcontentViewHeight = toolTipContentView.heightAnchor.constraint(equalToConstant: maxHeight)
                
               allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewCenterY,toolTipcontentViewHeight]
    
            }
            else{
                
                //TooltipContentView
                let toolTipcontentViewCenterX = toolTipContentView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor)
                let toolTipcontentViewCenterY = toolTipContentView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
                let toolTipcontentViewWidth = toolTipContentView.widthAnchor.constraint(equalToConstant: maxWidth)
                let toolTipcontentViewHeight = toolTipContentView.heightAnchor.constraint(equalToConstant: maxHeight)
                
               allConstraints = [toolTipcontentViewCenterX,toolTipcontentViewCenterY,toolTipcontentViewWidth,toolTipcontentViewHeight]
                
            }
        }
        
        NSLayoutConstraint.activate(allConstraints)
        
        toolTipContentView.updateConstraints()

    }

    func resetOrientation()
    {
            
            if  self.tooltip.toolTipType == .Centered
            {
                let layout =  toolTipContentView.collectionViewLayout as! UICollectionViewFlowLayout
                layout.scrollDirection = .horizontal
                layout.minimumInteritemSpacing = itemInterSpace
                
                
                maskLayer.startPoint = CGPoint(x: 0, y: 0.5)
                maskLayer.endPoint = CGPoint(x:1, y:0.5)
            }
            else
            {
                let layout =  toolTipContentView.collectionViewLayout as! UICollectionViewFlowLayout
                layout.scrollDirection = .vertical
                
                maskLayer.startPoint = CGPoint(x: 0.5, y: 0)
                maskLayer.endPoint = CGPoint(x:0.5, y:1)
            }
    
    }

    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        let transparent = NSUIColor.clear.cgColor
        let opaque = NSUIColor.black.cgColor
        var startPoint:CGFloat = scrollView.contentOffset.x
        var currentOffsetValue:CGFloat = scrollView.bounds.size.width
        var totalValue:CGFloat = scrollView.contentSize.width
        
        if self.tooltip.toolTipType == .leftRight
        {
            startPoint = scrollView.contentOffset.y
            currentOffsetValue = scrollView.bounds.size.height
            totalValue = scrollView.contentSize.height
        }
        
        if startPoint + currentOffsetValue == totalValue
        {
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
        }
        else if startPoint <= 0
        {
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
            
        }
        else if startPoint + currentOffsetValue >= floor(totalValue)
        {
            maskLayer.colors = [transparent, opaque, opaque]
            maskLayer.locations = [0,0.2,1]
            
        }
        else
        {
            maskLayer.colors = [transparent, opaque, opaque,transparent]
            maskLayer.locations = [0,0.2,0.8,1]
            
        }
    }
    
    func addMask()
    {
        if ((tooltipContentSize.width) > contentView.bounds.size.width && self.tooltip.toolTipType == .Centered) || ((tooltipContentSize.height) > contentView.bounds.size.height && self.tooltip.toolTipType == .leftRight)
        {
            
            let transparent = NSUIColor.clear.cgColor
            let opaque = NSUIColor.black.cgColor
            
            let parentLayer = CALayer()
            parentLayer.frame = contentView.bounds
            
            maskLayer.frame = CGRect(x: contentView.bounds.origin.x, y: 0, width: contentView.bounds.size.width, height: contentView.bounds.size.height)
            
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.8,1]
            parentLayer.addSublayer(maskLayer)
            contentView.layer.mask = parentLayer
            
        }
        else{
            contentView.layer.mask = nil
        }
        
    }
    
    var currentEntries:[ToolTipEntry] = []
    
    // --------------UICollectionViewDataSource------------------------- //
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return currentEntries.count
    }
    
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let tooltipCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ToolTipItemCell", for: indexPath) as! ToolTipItemCell

        let entry = currentEntries[indexPath.item]

        if entry.labelAttributedString != nil
        {
            tooltipCell.label.attributedText = entry.labelAttributedString
        }
        else{
            tooltipCell.label.text = entry.label
            tooltipCell.label.textColor = entry.labelTextColor
        }
        tooltipCell.label.font = entry.labelFont
        tooltipCell.label.textAlignment = entry.labelTextAlignment
        
        if entry.valueAttributedString != nil
        {
            tooltipCell.value.attributedText = entry.valueAttributedString
        }
        else{
            tooltipCell.value.text = entry.value
            tooltipCell.value.textColor = entry.valueTextColor
        }
        tooltipCell.value.font = entry.valueFont
        tooltipCell.value.textAlignment = entry.valueTextAlignment
        
        
        tooltipCell.constraintsUpdate(tooltip:self.tooltip.toolTipType)
        
        return tooltipCell

    }
    
    
    
    // --------------UICollectionViewDelegateFlowLayout------------------------- //
    public func collectionView(_ collectionView: UICollectionView,
                               layout collectionViewLayout: UICollectionViewLayout,
                               sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let entry = currentEntries[indexPath.item]
        
        let labelText = entry.label
        let valueText = entry.value
        
        let labelSize = (labelText).size(withAttributes: [NSAttributedString.Key.font: entry.labelFont])
        let valueSize = (valueText).size(withAttributes: [NSAttributedString.Key.font: entry.valueFont])
        
        
        let maxWidth:CGFloat
        let maxHeight:CGFloat
        
        if self.tooltip.toolTipType == .Centered
        {
            maxWidth = max(labelSize.width, valueSize.width) + 5
            maxHeight = min(collectionView.frame.height,(labelSize.height + valueSize.height + 20))
        }
        else{
            maxWidth = toolTipContentView.bounds.width
            maxHeight = max(labelSize.height,valueSize.height) + 5
        }
        
        return CGSize(width: maxWidth, height: maxHeight)
    }
    
    func maskAndReload()
    {
        reloadData(entry: oldEntry)

    }

    

}
#endif

open class contentUIView:NSUIView{
    
    weak var toolTipDelegate:ToolTipCollectionView? = nil
    
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func addDelegate(toolTip:ToolTipCollectionView)
    {
        let toolTipDelegate = toolTip
        self.toolTipDelegate = toolTipDelegate

    }
    
#if os(iOS) || os(tvOS)
    open override func layoutSubviews() {
        
        toolTipDelegate?.maskAndReload()
        
    }
#endif
#if os(OSX)
    open override func layout() {
        
        toolTipDelegate?.maskAndReload()
        
    }
#endif
}

public enum ToolTipType
{
    case Centered
    case leftRight
}

open class ChartTooltip : NSObject
{
    public override init()
    {
        super.init()
    }
    
    open var tooltipEnabled:Bool = true
    
    open var leftAlignEnabled:Bool = false
    
    open var toolTipType:ToolTipType = .leftRight {
        didSet {
            self.notifyTypeChanged()
        }
    }
    
    weak open var toolTipEntryGenerator:IToolTipEntryGenerator?
    
    fileprivate let defaultToolTipEntryGenerator = DefaultToolTipEntryGenerator()
    
    internal var _toolTipEntryGenerator:IToolTipEntryGenerator {
        
        get {
            if toolTipEntryGenerator == nil {
                return defaultToolTipEntryGenerator
            }
            else {
                return toolTipEntryGenerator!
            }
        }
        set {
            toolTipEntryGenerator = newValue
        }
    }
    
    var typeChangedClosure: (()->())?
    
    func notifyTypeChanged(){
        self.typeChangedClosure?()
    }
    
}


#if os(OSX)
open class ToolTipCollectionView:NSView,NSCollectionViewDataSource,NSCollectionViewDelegateFlowLayout,NSCollectionViewDelegate
{
    open var tooltip:ChartTooltip = ChartTooltip()
    
    open var contentView:contentUIView!
    
    open var tooltipContentSize:CGSize!
    
    var toolTipContentView:NSCollectionView!
    
    var allowed:Bool = true
    
    weak var delegateToContainer:TooltipViewDelegate? = nil
    
    weak var oldEntry:ChartDataEntry? = nil
    
    open var showView:Bool
        {
        set {
            self.tooltip.tooltipEnabled = newValue
        }
        get {
            return self.tooltip.tooltipEnabled
        }
    }
    
    let maskLayer = CAGradientLayer()
    
    var itemInterSpace:CGFloat = 50
    
    var allConstraints:[NSLayoutConstraint] = []

    let layout: NSCollectionViewFlowLayout = NSCollectionViewFlowLayout()
    
    open var tooltipScrollView:NSScrollView = NSScrollView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.initialize()
    }
    
    
    required public init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize()
    {
        self.wantsLayer = true
        contentView = contentUIView()
        contentView.wantsLayer = true
        contentView.addDelegate(toolTip: self)
//        toolTipContentView  = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(contentView)
        
        
        
        toolTipContentView = NSCollectionView()
        toolTipContentView.dataSource = self
        toolTipContentView.delegate = self
        toolTipContentView.collectionViewLayout = layout
        toolTipContentView.allowsEmptySelection = false
        toolTipContentView.allowsMultipleSelection = true
        toolTipContentView.backgroundColors = [.clear]
        toolTipContentView.isSelectable = true
        
        toolTipContentView!.register(
          ToolTipItemCell.self,
          forItemWithIdentifier: NSUserInterfaceItemIdentifier(rawValue: "ToolTipItemCell")
        )

        toolTipContentView.translatesAutoresizingMaskIntoConstraints = false
        
        tooltipScrollView = NSScrollView()
        tooltipScrollView.documentView = toolTipContentView
        contentView.addSubview(tooltipScrollView)
        tooltipScrollView.translatesAutoresizingMaskIntoConstraints = false
    
//        contentView.addSubview(toolTipContentView)
        
        
        
        
        
        
        
//        toolTipContentView.backgroundColor = NSUIColor.clear
//
//        toolTipContentView.delegate = self
//
//        toolTipContentView.dataSource = self
//
//        toolTipContentView.register(ToolTipItemCell.self, forCellWithReuseIdentifier: "ToolTipItemCell")
        
        let _tapGestureRecognizer = NSUITapGestureRecognizer(target: self, action: #selector(self.tapGestureRecognized(_:)))
        
        self.addGestureRecognizer(_tapGestureRecognizer)
        
        
        
        
        resetOrientation()
        
        self.tooltip.typeChangedClosure = {
            self.resetOrientation()
        }
        
    }
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        if recognizer.state == NSUIGestureRecognizerState.ended
        {
            delegateToContainer?.tooltipSelected!(entry: oldEntry)
        }
    }
    
    
    func reloadData(entry: ChartDataEntry?)
    {
        self.oldEntry = entry
        
        validateConstraints()
        
        toolTipContentView.reloadData()
        
//        toolTipContentView.layoutIfNeeded()
        
        tooltipScrollView.layoutSubtreeIfNeeded()
        
//        addMask()
       
    }
    
    func validateConstraints()
    {
        currentEntries = self.tooltip._toolTipEntryGenerator.prepareToolTipEntries(entry: oldEntry)
        
        var maxWidth:CGFloat = 0
        var maxHeight:CGFloat = 0
        
        for entry in currentEntries {
            
            let labelText = entry.label
            let valueText = entry.value
            
            let labelSize = (labelText).size(withAttributes: [NSAttributedString.Key.font: entry.labelFont])
            let valueSize = (valueText).size(withAttributes: [NSAttributedString.Key.font: entry.valueFont])
            
            if self.tooltip.toolTipType == .Centered
            {
                maxWidth  += max(labelSize.width, valueSize.width) + 5
                
                maxHeight = labelSize.height + valueSize.height + 20
            }
            else{
                maxHeight += max(labelSize.height,valueSize.height) + 5
            }
            
            if currentEntries.count > 1
            {
                    maxWidth += itemInterSpace
            }
            
            
        }
        
        tooltipContentSize = CGSize(width: maxWidth, height: maxHeight)
        
        if contentView.bounds.height == 0
        {
            maxHeight = 0
        }
       
        if allConstraints.count > 0
        {
            NSLayoutConstraint.deactivate(allConstraints)
        }
        
        
        if (maxHeight >= contentView.bounds.height && self.tooltip.toolTipType == .leftRight) || (maxWidth >= contentView.bounds.width && self.tooltip.toolTipType == .Centered)
        {
            
           tooltipContentSize.width = tooltipContentSize.width - itemInterSpace

            //TooltipContentView
            let toolTipcontentViewLeading = tooltipScrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
            let toolTipcontentViewTrailing = tooltipScrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
            let toolTipcontentViewTop = tooltipScrollView.topAnchor.constraint(equalTo: contentView.topAnchor)
            let toolTipcontentViewBottom = tooltipScrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
            
            allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom]
            
        }
        else{
           
            if self.tooltip.leftAlignEnabled
            {
                tooltipContentSize = contentView.bounds.size
                
                //TooltipContentView
                let toolTipcontentViewLeading = tooltipScrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
                let toolTipcontentViewTrailing = tooltipScrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
                let toolTipcontentViewTop = tooltipScrollView.topAnchor.constraint(equalTo: contentView.topAnchor)
                let toolTipcontentViewBottom = tooltipScrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
                
                allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom]
            }
            else if self.tooltip.toolTipType == .leftRight
            {
                
                //TooltipContentView
                let toolTipcontentViewLeading = tooltipScrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor)
                let toolTipcontentViewTrailing = tooltipScrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
                let toolTipcontentViewCenterY = tooltipScrollView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
                let toolTipcontentViewHeight = tooltipScrollView.heightAnchor.constraint(equalToConstant: maxHeight)
              
                
              
              
//                let toolTipcontentViewCenterY = toolTipContentView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
//                let toolTipcontentViewHeight = toolTipContentView.heightAnchor.constraint(equalToConstant: maxHeight)
//
               allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewCenterY,toolTipcontentViewHeight]
                
               allConstraints = [toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewCenterY,toolTipcontentViewHeight]
    
            }
            else{
                
                //TooltipContentView
                let toolTipcontentViewCenterX = tooltipScrollView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor)
                let toolTipcontentViewCenterY = tooltipScrollView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
                let toolTipcontentViewWidth = tooltipScrollView.widthAnchor.constraint(equalToConstant: maxWidth)
                let toolTipcontentViewHeight = tooltipScrollView.heightAnchor.constraint(equalToConstant: maxHeight)
                
               allConstraints = [toolTipcontentViewCenterX,toolTipcontentViewCenterY,toolTipcontentViewWidth,toolTipcontentViewHeight]
                
            }
        }
        
        NSLayoutConstraint.activate(allConstraints)
        
        toolTipContentView.updateConstraints()

    }

    func resetOrientation()
    {
            
            if  self.tooltip.toolTipType == .Centered
            {
                let layout =  toolTipContentView.collectionViewLayout as! NSCollectionViewFlowLayout
                layout.scrollDirection = .horizontal
                layout.minimumInteritemSpacing = itemInterSpace
                
                
                maskLayer.startPoint = CGPoint(x: 0, y: 0.5)
                maskLayer.endPoint = CGPoint(x:1, y:0.5)
            }
            else
            {
                let layout =  toolTipContentView.collectionViewLayout as! NSCollectionViewFlowLayout
                layout.scrollDirection = .vertical
                
                maskLayer.startPoint = CGPoint(x: 0.5, y: 0)
                maskLayer.endPoint = CGPoint(x:0.5, y:1)
            }
    
    }

    
   /* public func scrollViewDidScroll(_ scrollView: NSScrollView) {
        
        let transparent = NSUIColor.clear.cgColor
        let opaque = NSUIColor.black.cgColor
        var startPoint:CGFloat = scrollView.contentOffset.x
        var currentOffsetValue:CGFloat = scrollView.bounds.size.width
        var totalValue:CGFloat = scrollView.contentSize.width
        
        if self.tooltip.toolTipType == .leftRight
        {
            startPoint = scrollView.contentOffset.y
            currentOffsetValue = scrollView.bounds.size.height
            totalValue = scrollView.contentSize.height
        }
        
        if startPoint + currentOffsetValue == totalValue
        {
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
        }
        else if startPoint <= 0
        {
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
            
        }
        else if startPoint + currentOffsetValue >= floor(totalValue)
        {
            maskLayer.colors = [transparent, opaque, opaque]
            maskLayer.locations = [0,0.2,1]
            
        }
        else
        {
            maskLayer.colors = [transparent, opaque, opaque,transparent]
            maskLayer.locations = [0,0.2,0.8,1]
            
        }
    }*/
    
    func addMask()
    {
        if ((tooltipContentSize.width) > contentView.bounds.size.width && self.tooltip.toolTipType == .Centered) || ((tooltipContentSize.height) > contentView.bounds.size.height && self.tooltip.toolTipType == .leftRight)
        {
            
            let transparent = NSUIColor.clear.cgColor
            let opaque = NSUIColor.black.cgColor
            
            let parentLayer = CALayer()
            parentLayer.frame = contentView.bounds
            
            maskLayer.frame = CGRect(x: contentView.bounds.origin.x, y: 0, width: contentView.bounds.size.width, height: contentView.bounds.size.height)
            
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.8,1]
            parentLayer.addSublayer(maskLayer)
            contentView.layer?.mask = parentLayer
            
        }
        else{
            contentView.layer?.mask = nil
        }
        
    }
    
    var currentEntries:[ToolTipEntry] = []
    
    // --------------UICollectionViewDataSource------------------------- //
    public func collectionView(_ collectionView: NSCollectionView, numberOfItemsInSection section: Int) -> Int {
    
        return currentEntries.count
    }

    
    
    public func collectionView(_ collectionView: NSCollectionView, itemForRepresentedObjectAt indexPath: IndexPath) -> NSCollectionViewItem {
        
        let tooltipCell = collectionView.makeItem(
          withIdentifier: NSUserInterfaceItemIdentifier(rawValue: "ToolTipItemCell"),
          for: indexPath
        ) as! ToolTipItemCell
        
        let entry = currentEntries[indexPath.item]

      /*  if entry.labelAttributedString != nil
        {
            tooltipCell.label.attributedText = entry.labelAttributedString
        }
        else{
            tooltipCell.label.text = entry.label
            tooltipCell.label.textColor = entry.labelTextColor
        }
        tooltipCell.label.font = entry.labelFont
        tooltipCell.label.textAlignment = entry.labelTextAlignment
        
        if entry.valueAttributedString != nil
        {
            tooltipCell.value.attributedText = entry.valueAttributedString
        }
        else{
            tooltipCell.value.text = entry.value
            tooltipCell.value.textColor = entry.valueTextColor
        }
        tooltipCell.value.font = entry.valueFont
        tooltipCell.value.textAlignment = entry.valueTextAlignment
        
        
        tooltipCell.constraintsUpdate(tooltip:self.tooltip.toolTipType)*/
        
        tooltipCell.toolTipItemCellView?.tooltipEntry = entry
        
        tooltipCell.toolTipItemCellView?.chartToolTip = tooltip
        
        return tooltipCell

    }
    
    
    
    // --------------UICollectionViewDelegateFlowLayout------------------------- //
    
    public func collectionView(_ collectionView: NSCollectionView, layout collectionViewLayout: NSCollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> NSSize {
        
        let entry = currentEntries[indexPath.item]
        
        let labelText = entry.label
        let valueText = entry.value
        
        let labelSize = (labelText).size(withAttributes: [NSAttributedString.Key.font: entry.labelFont])
        let valueSize = (valueText).size(withAttributes: [NSAttributedString.Key.font: entry.valueFont])
        
        
        let maxWidth:CGFloat
        let maxHeight:CGFloat
        
        if self.tooltip.toolTipType == .Centered
        {
            maxWidth = max(labelSize.width, valueSize.width) + 5
            maxHeight = min(collectionView.frame.height,(labelSize.height + valueSize.height + 20))
        }
        else{
            maxWidth = toolTipContentView.bounds.width
            maxHeight = max(labelSize.height,valueSize.height) + 5
        }
        
        return CGSize(width: maxWidth, height: maxHeight)
    }
    
    func maskAndReload()
    {
        reloadData(entry: oldEntry)

    }

    

}
#endif
