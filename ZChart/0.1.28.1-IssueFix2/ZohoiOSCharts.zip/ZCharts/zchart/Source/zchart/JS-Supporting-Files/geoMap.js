

var projection;

var geoPath;


function initGeoObject(geoJSON, x, y, width, height,projectionName) {

//    projection = d3.geoMercator().fitExtent([[x,y],[width,height]], geoJSON);
    
    projection = d3[projectionName]().fitExtent([[x,y],[width,height]], geoJSON);
    
//    projection = d3.geoAlbersUsa().fitExtent([[x,y],[width,height]], geoJSON);

    geoPath = d3.geoPath().projection(projection);

}

function getFeatures(topologyJSON) {

    var world = JSON.parse(topologyJSON);

    var keys = Object.keys(world.objects);

   return topojson.feature(world, world.objects[keys[0]]);
}

function getSVGPath(geoJSON) {
    return geoPath(geoJSON);
}

function getGeoPoint(x,y) {
    return projection.invert([x, y]);
}

function getFeatureInPoint(geoJSON, coordinate) {

    geoJSON.features.forEach(
     function(d) {
        if (d3.geoContains(d, coordinate)) {
            return d;
        }
     });
    return null;

}

function geoContains(feature, coordinate) {
    return d3.geoContains(feature, coordinate);
}

function getPoint(x,y) {
    return projection([x,y]);
}

function geoLayout(values, width, height)
{
     var geoJSON = values;

     var path = d3.geoPath().projection(d3.geoMercator().fitSize([width,height], geoJSON));

     return path(geoJSON);

}

