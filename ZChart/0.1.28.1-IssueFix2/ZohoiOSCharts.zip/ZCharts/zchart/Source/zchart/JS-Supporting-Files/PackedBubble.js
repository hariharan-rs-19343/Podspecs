//
//  PackedBubble.js
//  d3 js
//

function doPackLayout(values, size)
{
    var packLayout = d3.pack();

//    packLayout.size([300, 300]);
    
    packLayout.size(size);

    var root = d3.hierarchy(values);
    
    root.sum(function(d) {return d.value});

    var desc = packLayout(root).descendants();

    var finalValues = []

    desc.forEach(function(item) {

        var obj = {} ;
        
        obj.radius = item.r;

        obj.x = item.x;

        obj.y = item.y;

        obj.name = item.data.name;
                 
        obj.setIndex = item.data.setIndex;
        
        obj.pathIndex = item.data.pathIndex;
        
        finalValues.push(obj);
  });

  return finalValues
}

