//
//  GeoMapLayer.swift
//  zchart
//
//  Created by Aravinth T on 26/11/21.
//

import Foundation

#if !os(OSX)
    import UIKit
#endif

public class GeoMapLayer : ChartEntryLayer
{
    open var dataset:IChartDataSet? = nil
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, path: CGPath) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.dataset = dataSet
        self.drawEntryLayer(path:path)
        callHighlightDelegate(dataset: dataset)
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    
    public func drawEntryLayer(path:CGPath)
    {
        guard
            let chartEntry = self.chartEntry,
            let chartView = self.chartView,
            let dataSet = self.dataset,
            let plotOption = chartView.getPlotOptions(type: .GeoHeatMap) as? GeoMapPlotOptions
        else{ return }
        
        self.path = path
        
        let index = dataSet.entryIndex(entry: chartEntry)
       
        // Set the color for the currently drawn value. If the index is out of bounds, reuse colors.
        var fillColor = dataSet.color(atIndex: index).cgColor
        
        if (chartView.colorAxis.isEnabled)
        {
            if let color = chartView.colorAxis.getColor(entry: chartEntry) {
                fillColor = color.cgColor
            }
        }
        
        self.fillColor = fillColor
        self.strokeColor = plotOption.strokeColor.cgColor
        self.lineWidth = plotOption.strokeWidth
                              
        chartView.plotView?.nsuiLayer?.addSublayer(self)
    }
    
    public static func removeAllGeoMapLayer(chart: ChartViewBase)
    {
        super.removeAllPlotLayer(chart: chart, kind: self)
    }
    
    public static func getAllGeoMapLayer(chart: ChartViewBase, includeBackground:Bool) -> [GeoMapLayer]
    {
        var mapLayerArray:[GeoMapLayer] = []
        
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: GeoMapLayer.self)
                {
                    let geoMapLayer = (caLayer as! GeoMapLayer)
                    
                    if (!includeBackground && geoMapLayer.chartEntry == GeoMapRenderer.dummyEntry) {
                        continue
                    }
                    
                    mapLayerArray.append(geoMapLayer)
                }
            }
        }
        
        
        return mapLayerArray
    }
    
    public static func getGeoMapLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> GeoMapLayer?
    {
        
        let tempLoc = CGPoint(x: loc.x, y: loc.y)

        for layer in getAllGeoMapLayer(chart: chart, includeBackground: false)
        {
            guard (layer.path != nil)
            else { continue }
            if (layer.path?.contains(tempLoc))!
            {
                return (layer)
            }
            
        }
        return nil
    }
    
    
    public static func getGeoMapLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> GeoMapLayer?
    {
        return super.getLayerForEntry(chart: chart, kind: self, entry: entry) as? GeoMapLayer
    }
}
