//
//  ScatterLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 29/03/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class ScatterLayer: ChartEntryLayer
{
    open var scatterDataSet:IChartDataSet? = nil
    
    open var shapePoint: CGPoint? = nil

    open var shapeSize:CGSize = CGSize()
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, point:CGPoint, shapeSize:CGSize) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.scatterDataSet = dataSet
        self.shapePoint = point
        self.chartEntry = chartEntry
        self.shapeSize = shapeSize
        self.drawEntryLayer()
        self.drawGradientLayer()
        self.callHighlightDelegate(dataset: scatterDataSet)
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    
    
    override public func drawEntryLayer()
    {
        guard let dataSetOption = scatterDataSet?.dataSetOptions as? AxisChartDataSetOptions
            else { return }
        
        let shapeProperties = dataSetOption.shapeProperties
        
        let isSingleColor = scatterDataSet?.colors.count == 1
        
        var color = scatterDataSet?.color(atIndex: 0).cgColor
        
        if  !isSingleColor
        {
            guard let entryIndex = scatterDataSet?.entryIndex(entry: chartEntry!)
            else { return }
            color = scatterDataSet?.color(atIndex: entryIndex).cgColor
        }
        
    
        let _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProperties, point: shapePoint!, strokeColor: color ?? NSUIColor.clear.cgColor, currentLayer: self)
       
        self.chartView?.plotView?.nsuiLayer?.addSublayer(self)
    }
    
    
    func drawGradientLayer() {
        
        let gradients = scatterDataSet?.gradients
        
        if gradients == nil || gradients!.count == 0 {
            return
        }
        
        guard let path = self.path
        else { return }
        
        self.fillColor = NSUIColor.clear.cgColor
        
        guard let entryIndex = scatterDataSet?.entryIndex(entry: chartEntry!)
        else { return }
        
        let baseGradient = scatterDataSet!.gradient(atIndex: entryIndex)
        
        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: path, gradient: baseGradient, drawMaskEnabled: true)
        
        if baseGradientLayer != nil {
            Log.info("Gradient layer created for entry " + String(describing: getScatterChartEntry()))
        }
        
    }
    
    
    open func getScatterChart() -> ChartViewBase
    {
        return (self.chartView!)
    }
    
    open func getScatterChartEntry() ->ChartDataEntry
    {
        return (self.chartEntry!)
    }
    
    public static func getAllScatterLayer(chart: ChartViewBase) -> [ScatterLayer]
    {
        var scatterArray:[ScatterLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [ScatterLayer] {
            scatterArray = layers
        }
        
        return scatterArray
    }
    
    public static func removeAllScatterLayer(chart: ChartViewBase)
    {
        super.removeAllPlotLayer(chart: chart, kind: self)
    }
    

    
    public static func getScatterEntryLayer(chart: ChartViewBase, loc: CGPoint) -> ScatterLayer?
    {
        let high = chart.getHighlightByTouchPoint(loc)
        
        var entry:ChartDataEntry? = nil
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
            
            for layer in getAllScatterLayer(chart: chart)
            {
                if (layer.getScatterChartEntry() === entry)
                {
                    return layer
                }
            }

        }
        
        return nil
    }
    
    public static func getScatterLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> ScatterLayer?
    {
        if entry.y.isNaN || entry.x.isNaN
        {
            return nil
        }
        return super.getLayerForEntry(chart: chart, kind: self, entry: entry) as? ScatterLayer
    }
    
}

