//
//  HighlightLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 27/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class HighlightLayer: CAShapeLayer
{
    

// 
//    init(layer:CAShapeLayer)
//    {
//        self = layer
//    }
//    
//    required public init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    override init(layer: Any) {
//        super.init(layer: layer)
//    }
//    
//    
//    override public func drawEntryLayer()
//{
}

public class ValueTextLayer: CALayer
{

    
}
