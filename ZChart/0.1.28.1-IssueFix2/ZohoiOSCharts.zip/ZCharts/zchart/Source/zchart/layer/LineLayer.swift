//
//  LineLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 22/11/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class LineLayer: ChartEntryLayer
{
    open var lineDataSet:IChartDataSet? = nil
    
    internal var markerShapeLayerIndex:[Int:Int] = [:]
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, path: CGPath) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.lineDataSet = dataSet
        self.drawEntryLayer(path:path)
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
        self.drawGradientLayer()
        self.callHighlightDelegate(dataset: lineDataSet)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    
    public func drawEntryLayer(path:CGPath)
    {
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: lineDataSet!)
        self.path = path
        self.fillColor = NSUIColor.clear.cgColor
        self.strokeColor = lineDataSet?.color(atIndex: 0).cgColor
        self.lineWidth = (lineDataSetOptions.lineWidth)
        self.lineCap =  convertToCAShapeLayerLineCap("round")
        
        if (lineDataSetOptions.lineDashLengths != nil) {
            self.lineDashPhase =  lineDataSetOptions.lineDashPhase //(chartBaseLine?.lineDashPhase)!
            self.lineDashPattern = LimitLineLayer.getNSNumberArray(lineDashLengths: lineDataSetOptions.lineDashLengths)
        }
        
        if (lineDataSetOptions.drawFilledEnabled)
        {
            self.fillColor = lineDataSet?.plotType == .LineRange ? lineDataSetOptions.fillColor.withAlphaComponent((lineDataSetOptions.fillAlpha)).cgColor : lineDataSet?.color(atIndex: 0).withAlphaComponent((lineDataSetOptions.fillAlpha)).cgColor
        }
        
        getLineChart().plotView?.nsuiLayer?.addSublayer(self)
    }
    
    func drawGradientLayer() {
        
        let lineDataSetOptions = LineHelperFunctions.getLineDataSetOptions(dataSet: lineDataSet!)
        
        //Only applicable for area chart
        if !(lineDataSetOptions.drawFilledEnabled){
            return
        }
        
        let gradients = lineDataSet!.gradients
        
        if gradients.count == 0 {
            return
        }
        
        let path = self.path!
        
        self.fillColor = NSUIColor.clear.cgColor
        
        //Always taking index 0 from gradients array since each dataset can have atmost single color
        let baseGradient = lineDataSet!.gradient(atIndex: 0)
        
        //Updating the color array with alphaComponent
        var newColors:[NSUIColor] = []
        for color in baseGradient.colors {
            newColors.append(color.withAlphaComponent((lineDataSetOptions.fillAlpha)))
        }
        baseGradient.colors = newColors
        
        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: path, gradient: baseGradient, drawMaskEnabled: true)
        
        if baseGradientLayer != nil {
            
            Log.info("Gradient layer created for linechartdataset index " + String (describing:  getLineChart().data?.indexOfDataSet(lineDataSet!)))
        }
        
    }
    
    
    open func getLineChart() -> ChartViewBase
    {
        return (self.chartView!)
    }
    
    public static func getAreaLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> LineLayer?
    {
        for layer in getAllDataSetLayer(chart: chart)
        {
            guard (layer.path != nil)
            else { continue }
            if (layer.path?.contains(loc))!
            {
                return (layer)
            }
            
        }
        return nil
    }
    
    
    public static func getAllDataSetLayer(chart: ChartViewBase) -> [LineLayer]
    {
        var lineArray:[LineLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [LineLayer] {
            lineArray = layers
        }
        
        return lineArray
    }
    
    public static func getLayerForDataset(chart: ChartViewBase, lineChartDataSet:ChartDataSet) -> LineLayer?
    {
        
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: LineLayer.self)
                {
                    let lineLayer = (caLayer as! LineLayer)
                    if (lineChartDataSet === lineLayer.lineDataSet) {
                        return lineLayer
                    }
                }
            }
        }
        return nil
    }
    

    
    public static func getDataSetLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> LineLayer?
    {
        
        let high = chart.getHighlightByTouchPoint(loc)
        
        if high != nil{
            
            let dataSet = chart.data?.dataSets[(high?.dataSetIndex)!]
            
            for layer in getAllDataSetLayer(chart: chart)
            {
                if (layer.lineDataSet === dataSet)
                {
                    return (layer)
                }
                
            }
        }
        
        return nil
    }
    
    public static func getLineStrokeLayer(lineLayer: LineLayer) -> LineStrokeLayer?
    {
        var lineStrokeLayer:LineStrokeLayer? = nil
        
        let childLayers = lineLayer.sublayers
        
        if childLayers != nil && (childLayers?.count)! > 0 {
            for layer in childLayers! {
                if layer.isKind(of: LineStrokeLayer.self){
                    lineStrokeLayer = (layer as! LineStrokeLayer)
                    break
                }
            }
        }
        
        return lineStrokeLayer
    }
    
    public static func getMarkerLayers(lineLayer: LineLayer) -> [CAShapeLayer]
    {
        var markerLayers:[CAShapeLayer] = []
        
        guard let childLayers = lineLayer.sublayers
            else {
                return markerLayers
        }
        
        for child in childLayers {
            if child.isKind(of: LineStrokeLayer.self) {
                continue
            }
            markerLayers.append(child as! CAShapeLayer)
        }
        return markerLayers
    }
    
    public  func getMarkerLayerforEntryIndex(entryIndex:Int) -> CAShapeLayer?
    {
        guard let childLayers = self.sublayers,
            let markerIndex = self.markerShapeLayerIndex[entryIndex]
            else {
                return nil
        }
        
        return childLayers[markerIndex] as? CAShapeLayer
        
    }
    /*
    override func highlightLayer( isHighlighted: Bool, plotType: ChartType? = nil) {
        
        if !isHighlighted {
            if self.fillColor != nil && self.fillColor! != NSUIColor.clear.cgColor {
                self.fillColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
            }
            self.strokeColor = NSUIColor.gray.withAlphaComponent(0.1).cgColor
            self.setValue(false, forKey: "isHighlighted")
        }
    }
    */
}

public class LineStrokeLayer : CAShapeLayer {
    
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToCAShapeLayerLineCap(_ input: String) -> CAShapeLayerLineCap {
    return CAShapeLayerLineCap(rawValue: input)
}
