//
//  ConnectorLayer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 28/06/22.
//

import Foundation

public class ConnectorLayer: CAShapeLayer {
    
}
