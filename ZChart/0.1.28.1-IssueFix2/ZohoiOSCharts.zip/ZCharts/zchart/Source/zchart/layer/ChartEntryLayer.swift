//
//  ChartEntryLayer.swift
//  zchart
//
//  Created by Aravinth T on 25/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class ChartEntryLayer: CAShapeLayer {

    open weak var chartView:ChartViewBase? = nil
    
    open var chartEntry:ChartDataEntry? = nil
    
    public override init() {
        super.init()
    }
    
    init(chartView: ChartViewBase, chartEntry:ChartDataEntry) {
        super.init()
        self.chartView = chartView
        self.chartEntry = chartEntry
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    open func drawEntryLayer()
    {
        
    }
    
    func highlightLayer(isHighlighted: Bool, dataset: IChartDataSet? = nil) {
        if !isHighlighted {
            if let datasetPlotOption = (dataset?.dataSetOptions) ?? chartView?.data?.getDataSetForEntry(chartEntry)?.dataSetOptions {
                
                if let nonHighlightFillcolor = datasetPlotOption.nonHighlightFillcolor?.cgColor {
                    self.fillColor = nonHighlightFillcolor
                }
                
                if let nonHighlightStrokecolor = datasetPlotOption.nonHighlightStrokecolor?.cgColor {
                    self.strokeColor = nonHighlightStrokecolor
                }
            }
        }
    }
    
    public static func getAllPlotLayer(chart: ChartViewBase, kind: AnyClass) -> [ChartEntryLayer]
    {
        var layerArray:[ChartEntryLayer] = []

        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                if layer.isKind(of: kind) {
                    layerArray.append(layer as! ChartEntryLayer)
                }
            }
        }
        
        return layerArray
    }
    
    public static func removeAllPlotLayer(chart: ChartViewBase, kind: AnyClass)
    {
        
        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: kind)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
        }
        
    }
    
    public static func getAllValueLayer(chart: ChartViewBase) -> [CATextLayer]
    {
        
        var valArray:[CATextLayer] = []

        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                if layer.isKind(of: CATextLayer.self) {
                    valArray.append(layer as! CATextLayer)
                }
            }
        }
        
        return valArray
    }
    
    public static func getAllValueLayers(chart: ChartViewBase) -> [CALayer]
    {
        
        var valArray:[CALayer] = []

        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                if layer.isKind(of: CATextLayer.self) || layer.isKind(of: ValueTextLayer.self){
                    valArray.append(layer)
                }
            }
        }
        
        return valArray
    }
    
    public static func removeAllValueLayer(chart: ChartViewBase)
    {
        removeAllPlotLayer(chart: chart, kind: CATextLayer.self)
    }
    
    public static func getLayerForEntry(chart:ChartViewBase, kind: AnyClass, entry:ChartDataEntry) -> ChartEntryLayer?
    {
        for layer in getAllPlotLayer(chart: chart, kind: kind)
        {
            if layer.chartEntry === entry
            {
                return layer
            }
        }
        return nil
    }
    
    func callHighlightDelegate(dataset: IChartDataSet?) {
        
        guard let chartView = chartView,
              let entry = chartEntry else {
            return
        }
        
        var isHighlighted = true
        
        if chartView.lastSelected != nil && !chartView.lastSelected!.isEmpty {
                
            if chartView.datasetSelected {
                if let dataset = dataset as? ChartDataSet, let selectedEntryDataSets = chartView.lastSelectedSet {
                    isHighlighted = selectedEntryDataSets.contains(where: { $0 === dataset})
                }
            }
            else if chartView.xGroupSelected {
                isHighlighted = chartView.IsEntryXSelected(x: entry.x) || chartView.IsEntryRoundedXSelected(x: round(entry.x))
            }
            else if chartView.IsEntrySelected(entry: entry) {
                isHighlighted = true
            }
            else {
                isHighlighted = false
            }
        }
        
        chartView.rendererDelegate?.delegateToHighlight?(layer:self,isHighlighted: isHighlighted)
        
        if chartView.rendererDelegate?.delegateToHighlight == nil {
            highlightLayer(isHighlighted: isHighlighted, dataset: dataset)
        }
        
        if !isHighlighted && self.isKind(of: LineLayer.self) {
            self.setValue(false, forKey: "isHighlighted")
        }
    }
}
