//
//  WhiskersLayer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 05/08/22.
//

import Foundation

public class WhiskersLayer: ChartExtrasLayer {
    
    func plotConfiguration(boxPlotPlotOption: BoxPlotPlotOptions) {
        
        self.strokeColor = boxPlotPlotOption.whiskersColor.cgColor
        
        self.lineWidth = boxPlotPlotOption.whiskersStrokeWidth
        
        if boxPlotPlotOption.whiskersDashLengths != nil
        {
            self.lineDashPhase = boxPlotPlotOption.whiskersDashPhase
            
            if let dashLength = boxPlotPlotOption.whiskersDashLengths as? [NSNumber] {
                self.lineDashPattern = dashLength
            }
        }
        else
        {
            self.lineDashPhase = 0.0
            self.lineDashPattern = nil
        }
        
    }
    
    static func getWhiskersLayerForEntry(chart: ChartViewBase, entry: ChartDataEntry) -> WhiskersLayer? {
        
        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                if (layer as? WhiskersLayer)?.chartEntry == entry
                {
                    return layer as? WhiskersLayer
                }
            }
        }
        
        return nil
    }
    
    func opacity(opacityValue: Float) {
        self.opacity = opacityValue
    }
    
    static func getInitialPathForWhiskers(path: inout CGMutablePath, from: CGPoint, to: CGPoint, whiskersWidthHalf: Double) {
        
        path.move(to: from)
        path.addLine(to: to)

        path.move(to: CGPoint(x: to.x - whiskersWidthHalf, y: to.y))
        path.addLine(to: CGPoint(x: to.x + whiskersWidthHalf, y: to.y))
    }
    
    static func getInitialPathForHorizontalWhiskers(path: inout CGMutablePath, from: CGPoint, to: CGPoint, whiskersHeightHalf: Double) {
        
        path.move(to: from)
        path.addLine(to: to)

        path.move(to: CGPoint(x: to.x, y: to.y - whiskersHeightHalf))
        path.addLine(to: CGPoint(x: to.x, y: to.y + whiskersHeightHalf))
    }
}
