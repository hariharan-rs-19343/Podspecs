//
//  BarLayer.swift
//  zchart
//
//  Created by Aravinth T on 25/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif


public class LevelLayer: BarLayer{
    
    open var levelValue:Double?
    
    public static func getAllLevelLayersForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> [LevelLayer]
    {
        var barLevelArray:[LevelLayer] = []
        
       /* let newChart = chart.plotView
        
        if let layers = newChart?.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: LevelLayer.self)
                {
                    barLevelArray.append((caLayer as! LevelLayer))
                }
            }
        }*/
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [LevelLayer] {
            barLevelArray = layers
        }
        
        return barLevelArray
    }
}

public class BarLayer: ChartEntryLayer
{
    fileprivate let typeAllowed = [ChartType.Bar, ChartType.Mekko, ChartType.Bullet, ChartType.WaterFall, ChartType.BoxPlot, ChartType.HorizontalBarRange]
    
    open var barDataSet:IChartDataSet? = nil
    open var barRect:CGRect? = nil
    open var barRectIndex:Int = -1

    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, barRect: CGRect, barRectIndex: Int) {
     super.init(chartView: chartView, chartEntry: chartEntry)
     self.barRectIndex = barRectIndex
     self.barDataSet = dataSet
     self.barRect = barRect
     self.drawEntryLayer()
     self.drawGradientLayer()
        
    callHighlightDelegate(dataset: dataSet)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    override public func drawEntryLayer()
    {
        
        if let shapeProperties =  (barDataSet?.dataSetOptions as? AxisChartDataSetOptions)?.shapeProperties, let rect = barRect {
            
            if !(shapeProperties.shapeType == .Default) {
                drawShapeLayer(rect: rect)
                return
            }
        }
            
        let path = getPath(rect: self.barRect!)//UIBezierPath(rect: self.barRect!)
        
        self.path = path//.cgPath
       
        let barEntry = getBarChartEntry()
        
        let isSingleColor = barDataSet?.colors.count == 1
        
        let barDataSetOptions = barDataSet?.dataSetOptions as? BarDataSetOptions
                        
        let borderWidth = barDataSetOptions?.barBorderWidth
        let borderColor = barDataSetOptions?.barBorderColor
//        let drawBorder = borderWidth! > 0.0

        if !isSingleColor
        {
            guard let index = barDataSet?.entryIndex(entry: barEntry)
            else { return }
            
            // Set the color for the currently drawn value. If the index is out of bounds, reuse colors.
            self.fillColor = barDataSet?.color(atIndex: index).cgColor
            
            //Multicolor columnar chart
            if (getBarChart().data?.dataSets.count == 1) && !(BarHelperFunctions.isStacked(chart: chartView!))
            {
                var colorIndex = index
                let origIndex = barEntry.origIndex
                if origIndex != nil {
                    colorIndex =  ChartUtils.doubleToIntSafeCast(value:origIndex!)
                }
                self.fillColor = barDataSet?.color(atIndex: colorIndex).cgColor
            }
        }
        else
        {
            self.fillColor = barDataSet?.color(atIndex: 0).cgColor
        }
        
        if barDataSet?.plotType == .WaterFall {
            if let entry = chartEntry, let dataset = barDataSet as? ChartDataSet{
            
                if entry.plotData != nil && (entry.plotData as! Int) == 1 && dataset.cascadedCategoryColor != nil {
                    self.fillColor = dataset.cascadedCategoryColor?.cgColor
                }
                else if entry.y >= 0 && dataset.risingCategorycolor != nil {
                    self.fillColor = dataset.risingCategorycolor?.cgColor
                }
                else if entry.y < 0 && dataset.fallingCategorycolor != nil {
                    self.fillColor = dataset.fallingCategorycolor?.cgColor
                }
            
            }
        }
        
        if chartView != nil && chartEntry != nil && (chartView!.colorAxis.isEnabled)
        {
            if let color = chartView!.colorAxis.getColor(entry: self.chartEntry!) {
                self.fillColor = color.cgColor
            }
        }
        
        var isStrokeEnable = false
        
        let isBorderNeeded = ( (self.chartEntry) != nil && !self.chartEntry!.y.isNaN )
        && ( (self.chartEntry) != nil && !(self.chartEntry!.y == 0.0))
        
        if borderWidth != nil && (borderWidth! > 0.0) && isBorderNeeded
        {
            self.lineWidth = borderWidth!
            self.strokeColor = borderColor?.cgColor
            isStrokeEnable = true
        }

        let highColor:CGColor?
        
        let lowColor:CGColor?
        
        /*let barData:ChartData?
        
        if getBarChart().isKind(of: CombinedChartView.self)
        {
            barData = (getBarChart() as! CombinedChartView).barData
            
        }
        else{
            barData = (getBarChart().data as! ChartData)
        }*/
        
        guard let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: getBarChart(), types: typeAllowed) as? BarPlotOptions
        else { return }
        /*
        highColor = (barPlotOptions.highlightColor?.cgColor)
        
        lowColor = (barPlotOptions.nonHighlightColor?.cgColor)
        
        if (barPlotOptions.isStacked)
        {
            if barPlotOptions.barGroupSelectionEnabled
            {
                let lastSelected = getBarChart().lastSelected
                if lastSelected == nil || lastSelected!.isEmpty || getBarChart().IsEntryXSelected(x: barEntry.x) || getBarChart().IsEntryRoundedXSelected(x: round(barEntry.x))// (lastSelected != nil && lastSelected?.x == barEntry.x)
                {
                    self.opacity = 1.0
                    
                    if lastSelected != nil
                    {
                        if highColor != nil{
                            self.fillColor = highColor
                            self.opacity = 1.0
                        }
                    }
                }
                else
                {
                    self.opacity = 0.5
                    
                    if lowColor != nil{
                        self.fillColor = lowColor
                        self.opacity = 1.0
                        if isStrokeEnable {
                            self.strokeColor = lowColor
                        }
                    }
                }
            }
            else
            {
                let lastSelected = getBarChart().lastSelected
                
                var lastSelectedLayer:Bool = false
                
                if lastSelected != nil  && lastSelected!.count > 0
                {
                    guard let chartData = getBarChart().data,
                          let lastSelectedSets = getBarChart().lastSelectedSet,
                          let lastSelectedSet = lastSelectedSets[0]
                        else { return }
                    if lastSelectedSet === self.barDataSet!
                    {
                        lastSelectedLayer = true
                    }
                    
//                    let lastSelectedDataSetIndex = chartData.indexOfDataSet(lastSelectedSet)
//                    let currentDatasetIndex = chartData.indexOfDataSet(self.barDataSet!)
//
//                    if lastSelectedDataSetIndex == currentDatasetIndex
//                    {
//                        lastSelectedLayer = true
//                    }
                    
                }
                
                if lastSelected == nil || lastSelected!.isEmpty || lastSelectedLayer
                {
                    self.opacity = 1.0
                    
                    if lastSelectedLayer
                    {
                        if highColor != nil{
                            self.fillColor = highColor
                            self.opacity = 1.0
                        }
                    }
                }
                else
                {
                    self.opacity = 0.5
                    
                    if lowColor != nil{
                        self.fillColor = lowColor
                        self.opacity = 1.0
                        if isStrokeEnable {
                            self.strokeColor = lowColor
                        }
                    }
                }
            }
        }
        else if (getBarChart().data?.dataSetCount)! > 1
        {
            var seletedDataSet:IChartDataSet? = nil
            if getBarChart().lastSelected != nil && getBarChart().lastSelected!.count > 0 {
                if getBarChart().lastSelectedSet != nil && getBarChart().lastSelectedSet!.count > 0
                {
                    seletedDataSet = getBarChart().lastSelectedSet![0]
                }
            }

            
            if barPlotOptions.barGroupSelectionEnabled
            {
                let lastSelected = getBarChart().lastSelected
                
                if lastSelected == nil || lastSelected!.isEmpty || getBarChart().IsEntryRoundedXSelected(x: round(barEntry.x))  //(lastSelected != nil && round((lastSelected?.x)!) == round(barEntry.x))
                {
                    self.opacity = 1.0
                    
                    if lastSelected != nil
                    {
                        if highColor != nil{
                            self.fillColor = highColor
                            self.opacity = 1.0
                        }
                    }
                }
                else
                {
                    self.opacity = 0.5
                    
                    if lowColor != nil{
                        self.fillColor = lowColor
                        self.opacity = 1.0
                        if isStrokeEnable {
                            self.strokeColor = lowColor
                        }
                    }
                }
            }
            else{
                
                
                if  (self.barDataSet) === seletedDataSet || getBarChart().lastSelected == nil || getBarChart().lastSelected!.isEmpty
                {
                    self.opacity = 1.0
                    
                    if getBarChart().lastSelected != nil
                    {
                        if highColor != nil{
                            self.fillColor = highColor
                        }
                    }
                }
                else
                {
                    self.opacity = 0.5
                    
                    if lowColor != nil{
                        self.fillColor = lowColor
                        self.opacity = 1.0
                        if isStrokeEnable {
                            self.strokeColor = lowColor
                        }
                    }
                }
            }
     
        }
        else{
            
            if  getBarChart().lastSelected == nil || getBarChart().lastSelected!.isEmpty || getBarChart().IsEntryXSelected(x: barEntry.x) //barEntry.x == ((getBarChart().lastSelected)!).x
            {
                self.opacity = 1.0
                
                if getBarChart().lastSelected != nil
                {
                    if highColor != nil{
                        self.fillColor = highColor
                    }
                }
            }
            else
            {
                self.opacity = 0.5
    
                if lowColor != nil{
                    self.fillColor = lowColor
                    self.opacity = 1.0
                    if isStrokeEnable {
                        self.strokeColor = lowColor
                    }
                }
            }
        }*/
        if (getBarChart().customAnimationInProgress) {
            self.opacity = 0.0
        }
    }
    
    func drawGradientLayer() {
        
        let gradients = self.barDataSet?.gradients
        
        if gradients == nil || gradients?.count == 0 {
            return
        }
        
        self.fillColor = NSUIColor.clear.cgColor
        
        let gradientIndex = getGradientColorIndex()
        
        guard let gradient = barDataSet?.gradient(atIndex: gradientIndex)
        else { return }
        
        let baseGradientLayer = createGradientLayer(baseGradient: gradient)
        
        if baseGradientLayer != nil {
            //Create highlighted layer only if baseGradient created
            highlightGradientLayer(container: self, baseGradientLayer: baseGradientLayer!)
        }
    }
    
    func highlightGradientLayer(container: CALayer, baseGradientLayer: BaseGradientLayer) {
        
        guard let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chartView!, types: typeAllowed) as? BarPlotOptions
            else { return }
        
        let highGradient:BaseGradient?
        
        let lowGradient:BaseGradient?
        
//        let barData:ChartData?
        
        let barEntry = self.getBarChartEntry()
        
       /* if getBarChart().isKind(of: CombinedChartView.self) {
            barData = (getBarChart() as! CombinedChartView).barData
        } else{
            barData = (getBarChart().data as! ChartData)
        }*/
        
        highGradient = (barPlotOptions.highlightGradient)
        
        lowGradient = (barPlotOptions.nonHighlightGradient)
        
        //Stacked
        if (barPlotOptions.isStacked)
        {
            if barPlotOptions.barGroupSelectionEnabled //Stacked Group enabled
            {
                let lastSelected = getBarChart().lastSelected
                if lastSelected == nil || getBarChart().IsEntrySelected(entry: barEntry) //(lastSelected != nil && lastSelected == barEntry)
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if lastSelected != nil
                    {
                        if highGradient != nil{
                           _ = createGradientLayer(baseGradient: highGradient!)
                        }
                    }
                }
                else
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                        _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
            }
            else //Stacked single stack enable
            {
                /*if getBarChart().lastSelectedStackIndex == -1
                {
                    baseGradientLayer.opacity = 1.0
                }
                else if getBarChart().lastSelectedStackIndex != -1 && getBarChart().lastSelectedStackIndex != getStackIndex()
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                      _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
                else if getBarChart().lastSelectedStackIndex != -1 && getBarChart().lastSelectedStackIndex == getStackIndex()
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if highGradient != nil{
                        _ = createGradientLayer(baseGradient: highGradient!)
                    }
                }*/
            }
        }
        else if (getBarChart().data?.dataSetCount)! > 1 // Multibar
        {
            var seletedDataSet:IChartDataSet? = nil
            if getBarChart().lastSelected != nil && getBarChart().lastSelected!.count > 0 {
                seletedDataSet = (getBarChart().data?.getDataSetForEntry(getBarChart().lastSelected![0]))
            }

            
            if barPlotOptions.barGroupSelectionEnabled // Multibar group enabled
            {
                let lastSelected = getBarChart().lastSelected
                
                if lastSelected == nil || (lastSelected != nil && lastSelected!.count > 0 && seletedDataSet?.entryIndex(entry: lastSelected![0]) == barDataSet?.entryIndex(entry: barEntry))
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if lastSelected != nil
                    {
                        if highGradient != nil{
                          _ = createGradientLayer(baseGradient: highGradient!)
                        }
                    }
                }
                else
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                        _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
            }
            else{ // Multibar same dataset enabled
                
                
                if  (getBarChart().data?.getDataSetForEntry(barEntry)) === seletedDataSet || getBarChart().lastSelected == nil
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if getBarChart().lastSelected != nil
                    {
                        if highGradient != nil{
                            _ = createGradientLayer(baseGradient: highGradient!)
                        }
                    }
                }
                else
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                        _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
            }
            
        }
        else{ // Single Bar
            
            if  getBarChart().lastSelected == nil || getBarChart().IsEntrySelected(entry: barEntry) //barEntry == ((getBarChart().lastSelected)!)
            {
                baseGradientLayer.opacity = 1.0
                
                if getBarChart().lastSelected != nil
                {
                    if highGradient != nil{
                       _ = createGradientLayer(baseGradient: highGradient!)
                    }
                }
            }
            else
            {
                baseGradientLayer.opacity = 0.5
                
                if lowGradient != nil{
                      _ = createGradientLayer(baseGradient: lowGradient!)
                }
            }
        }
    }
    
    fileprivate func createGradientLayer(baseGradient:BaseGradient) -> BaseGradientLayer? {
        
        let path =  CGMutablePath(rect: barRect!, transform: nil) //UIBezierPath(rect: barRect!).cgPath
        
        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: path, gradient: baseGradient, drawMaskEnabled: false)
        
        return baseGradientLayer
    }
    
    func getGradientColorIndex() -> Int {
        let barEntry = self.getBarChartEntry()
        
        let index = barDataSet?.entryIndex(entry: barEntry)
        
        var gradientIndex:Int = 0
        
        if index != nil {
            gradientIndex = index!
        }
        
//        if (barDataSet?.isStacked)! {
//            gradientIndex = (barRectIndex % (barEntry.yValues?.count)!)
//        }
        
        if getBarChart().data?.dataSets.count == 1 && !(BarHelperFunctions.isStacked(chart: chartView!)) {
            var colorIndex = gradientIndex
            let origIndex = barEntry.origIndex
            if origIndex != nil {
                colorIndex =  ChartUtils.doubleToIntSafeCast(value:origIndex!)
            }
            gradientIndex = colorIndex
        }
        
        return gradientIndex
    }
    
    open func getBarChart() -> ChartViewBase
    {
        return (self.chartView!)
    }
    
    open func getBarChartEntry() -> ChartDataEntry
    {
        return (self.chartEntry!)
    }
    
    
    public static func getAllBarLayer(chart: ChartViewBase) -> [BarLayer]
    {
        var barArray:[BarLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [BarLayer] {
            barArray = layers
        }
        
        return barArray
    }
    
    @available(*, deprecated, renamed: "getAllValueLayer")
    public static func getAllBarValueLayer(chart: ChartViewBase) -> [CATextLayer]
    {
        
        var barArray:[CATextLayer] = []
        
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    barArray.append((caLayer as! CATextLayer))
                }
            }
            
        }
        
        return barArray
    }
    
    public static func removeAllBarLayer(chart: ChartViewBase)
    {
        super.removeAllPlotLayer(chart: chart, kind: self)
    }
    
    @available(*, deprecated, renamed: "removeAllValueLayer")
    public static func removeAllBarValueLayer(chart: ChartViewBase)
    {
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }

    public static func getBarLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> BarLayer?
    {
        for layer in getAllBarLayer(chart: chart)
        {
            
            if chart.isRotated
            {
                if ((layer.barRect?.minY)! <= loc.y) && (loc.y <= (layer.barRect?.maxY)!)
                {
                    return layer
                }
            }
            else{
                if ((layer.barRect?.minX)! <= loc.x) && (loc.x <= (layer.barRect?.maxX)!)
                {
                    return layer
                }
            }
            
        }
        return nil
    }
    
    public static func getAllBarLayersInXLocation(chart: ChartViewBase, loc: CGPoint) -> [BarLayer]
    {
        var barLayers:[BarLayer] = []
        
        for layer in getAllBarLayer(chart: chart)
        {
            
            if chart.isRotated
            {
                if ((layer.barRect?.minY)! <= loc.y) && (loc.y <= (layer.barRect?.maxY)!)
                {
                    barLayers.append(layer)
                }
            }
            else{
                if ((layer.barRect?.minX)! <= loc.x) && (loc.x <= (layer.barRect?.maxX)!)
                {
                    barLayers.append(layer)
                }
            }
            
        }
        return barLayers
    }
    
    public static func getBarLayerInPointOriginal(chart: ChartViewBase, loc: CGPoint) -> BarLayer?
    {
        
        let tempLoc = CGPoint(x: loc.x, y: loc.y) 

        for layer in getAllBarLayer(chart: chart)
        {
            guard (layer.path != nil)
            else { continue }
            if (layer.path?.contains(tempLoc))!
            {
//                layer.roundedCorners(rect: layer.barRect!)
                return (layer)
            }
            
        }
        
        return nil
    }
    
    public static func getBarLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> BarLayer?
    {
        return super.getLayerForEntry(chart: chart, kind: self, entry: entry) as? BarLayer
    }
}


extension BarLayer{
    
    public func getPath(rect: CGRect) -> CGMutablePath{
        
        guard let barPlotOptions = CommonHelperFunctions.getPlotOption(chart: chartView!, types: typeAllowed) as? BarPlotOptions,
              let dataSetOption = barDataSet?.dataSetOptions as? AxisChartDataSetOptions
            else { return CGMutablePath(rect: rect, transform: nil)}
        
        if dataSetOption.shapeProperties.shapeType != .Default {
            drawShapeLayer(rect: rect)
            if let path = self.path {
                return path as! CGMutablePath
            }
        }
        
        if barPlotOptions.roundedCorners{
        
        #if os(iOS) || os(tvOS)
            return UIBezierPath(roundedRect: rect, byRoundingCorners: barPlotOptions.byRoundingCorners, cornerRadii: CGSize(width: barPlotOptions.roundedRadii, height: barPlotOptions.roundedRadii)).cgPath as! CGMutablePath
        
        #else
            return CGMutablePath(roundedRect: rect, cornerWidth: barPlotOptions.roundedRadii, cornerHeight: barPlotOptions.roundedRadii, transform: nil)
        #endif
            
        }
        
        return CGMutablePath(rect: rect, transform: nil)
        
    }
    
    public func drawShapeLayer(rect: CGRect) {
        
        guard let dataSetOption = barDataSet?.dataSetOptions as? AxisChartDataSetOptions
        else { return }
        
        let shapeProperties = dataSetOption.shapeProperties
        
        let isSingleColor = barDataSet?.colors.count == 1
        
        var color = barDataSet?.color(atIndex: 0).cgColor
        
        if  !isSingleColor
        {
            guard let entryIndex = barDataSet?.entryIndex(entry: chartEntry!)
            else { return }
            color = barDataSet?.color(atIndex: entryIndex).cgColor
        }
        
        shapeProperties.size = rect.size
    
        let _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProperties, point: rect.origin, strokeColor: color ?? NSUIColor.clear.cgColor, currentLayer: self)
    }
}
