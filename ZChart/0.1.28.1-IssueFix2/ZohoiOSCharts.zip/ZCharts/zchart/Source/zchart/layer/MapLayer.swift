//
//  MapLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 30/05/19.
//  Copyright © 2019 zoho. All rights reserved.
//


#if !os(OSX)
    import UIKit
#endif

public class MapLayer: ChartEntryLayer
{
    open var dataSet:IChartDataSet? = nil
    open var frameRect:CGRect? = nil
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, frameRect: CGRect) {
        super.init(chartView: chartView, chartEntry: chartEntry)

        self.dataSet = dataSet
        self.frameRect = frameRect
        self.drawEntryLayer()
//        self.drawGradientLayer()
        callHighlightDelegate(dataset: dataSet)
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    override public func drawEntryLayer()
    {
        guard let frameRect = self.frameRect,
            let chartEntry = self.chartEntry,
            let chartView = self.chartView,
            let plotOptions = chartView.getPlotOptions(type: .HeatMap) as? HeatMapPlotOptions
        else{ return }
        
        var path = CGMutablePath(rect: frameRect, transform: nil)//UIBezierPath(rect: frameRect)
        
        
        if plotOptions.roundedCorners {
        
        #if os(iOS) || os(tvOS)
            path = UIBezierPath(roundedRect: frameRect, byRoundingCorners: plotOptions.byRoundingCorners, cornerRadii: CGSize(width: plotOptions.roundedRadii, height: plotOptions.roundedRadii)).cgPath as! CGMutablePath
        
        #else
            path = CGMutablePath(roundedRect: frameRect, cornerWidth: plotOptions.roundedRadii, cornerHeight: plotOptions.roundedRadii, transform: nil)
        #endif
            
        }
        
        self.path = path//.cgPath
        
        guard let index = dataSet?.entryIndex(entry: chartEntry)
            else  { return }
       
        // Set the color for the currently drawn value. If the index is out of bounds, reuse colors.
        var fillColor = dataSet?.color(atIndex: index).cgColor
        
        if (chartView.colorAxis.isEnabled)
        {
            fillColor = (chartView.colorAxis.getColor(entry: chartEntry)?.cgColor)
        }
        
        self.fillColor = fillColor
        
        if let datasetOptions = self.dataSet?.dataSetOptions as? BarDataSetOptions {
            
            self.lineWidth = datasetOptions.barBorderWidth
            self.strokeColor = datasetOptions.barBorderColor.cgColor
        }
        
        /*let shapeProperties = dataSet?.shapeProperties
        
        let point = CGPoint(x: (frameRect?.midX)!, y: (frameRect?.midY)!)

        let _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProperties!, point: point, strokeColor: fillColor ?? NSUIColor.gray.cgColor, currentLayer: self)*/
    }
    
    /*func drawGradientLayer() {
        
        let gradients = self.barDataSet?.gradients
        
        if gradients == nil || gradients?.count == 0 {
            return
        }
        
        self.fillColor = NSUIColor.clear.cgColor
        
        let gradientIndex = getGradientColorIndex()
        
        let gradient = barDataSet?.gradient(atIndex: gradientIndex)
        
        let baseGradientLayer = createGradientLayer(baseGradient: gradient!)
        
        if baseGradientLayer != nil {
            //Create highlighted layer only if baseGradient created
            highlightGradientLayer(container: self, baseGradientLayer: baseGradientLayer!)
        }
    }
    
    func highlightGradientLayer(container: CALayer, baseGradientLayer: BaseGradientLayer) {
        
        let highGradient:BaseGradient?
        
        let lowGradient:BaseGradient?
        
        let barData:ChartData?
        
        let barEntry = self.getBarChartEntry()
        
        if getBarChart().isKind(of: CombinedChartView.self) {
            barData = (getBarChart() as! CombinedChartView).barData
        } else{
            barData = (getBarChart().data as! ChartData)
        }
        
        highGradient = (barData?.highlightGradient)
        
        lowGradient = (barData?.nonHighlightGradient)
        
        //Stacked
        if (barData?.isStacked)!
        {
            if getBarChart().barGroupSelectionEnabled //Stacked Group enabled
            {
                let lastSelected = getBarChart().lastSelected
                if lastSelected == nil || (lastSelected != nil && lastSelected == barEntry)
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if lastSelected != nil
                    {
                        if highGradient != nil{
                            _ = createGradientLayer(baseGradient: highGradient!)
                        }
                    }
                }
                else
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                        _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
            }
            else //Stacked single stack enable
            {
                /*if getBarChart().lastSelectedStackIndex == -1
                 {
                 baseGradientLayer.opacity = 1.0
                 }
                 else if getBarChart().lastSelectedStackIndex != -1 && getBarChart().lastSelectedStackIndex != getStackIndex()
                 {
                 baseGradientLayer.opacity = 0.5
                 
                 if lowGradient != nil{
                 _ = createGradientLayer(baseGradient: lowGradient!)
                 }
                 }
                 else if getBarChart().lastSelectedStackIndex != -1 && getBarChart().lastSelectedStackIndex == getStackIndex()
                 {
                 baseGradientLayer.opacity = 1.0
                 
                 if highGradient != nil{
                 _ = createGradientLayer(baseGradient: highGradient!)
                 }
                 }*/
            }
        }
        else if (getBarChart().data?.dataSetCount)! > 1 // Multibar
        {
            let seletedDataSet = (getBarChart().data?.getDataSetForEntry(getBarChart().lastSelected))
            
            if getBarChart().barGroupSelectionEnabled // Multibar group enabled
            {
                let lastSelected = getBarChart().lastSelected
                
                if lastSelected == nil || (lastSelected != nil && seletedDataSet?.entryIndex(entry: lastSelected!) == barDataSet?.entryIndex(entry: barEntry))
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if lastSelected != nil
                    {
                        if highGradient != nil{
                            _ = createGradientLayer(baseGradient: highGradient!)
                        }
                    }
                }
                else
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                        _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
            }
            else{ // Multibar same dataset enabled
                
                
                if  (getBarChart().data?.getDataSetForEntry(barEntry)) === seletedDataSet || getBarChart().lastSelected == nil
                {
                    baseGradientLayer.opacity = 1.0
                    
                    if getBarChart().lastSelected != nil
                    {
                        if highGradient != nil{
                            _ = createGradientLayer(baseGradient: highGradient!)
                        }
                    }
                }
                else
                {
                    baseGradientLayer.opacity = 0.5
                    
                    if lowGradient != nil{
                        _ = createGradientLayer(baseGradient: lowGradient!)
                    }
                }
            }
            
        }
        else{ // Single Bar
            
            if  getBarChart().lastSelected == nil || barEntry == ((getBarChart().lastSelected) as! ChartDataEntry)
            {
                baseGradientLayer.opacity = 1.0
                
                if getBarChart().lastSelected != nil
                {
                    if highGradient != nil{
                        _ = createGradientLayer(baseGradient: highGradient!)
                    }
                }
            }
            else
            {
                baseGradientLayer.opacity = 0.5
                
                if lowGradient != nil{
                    _ = createGradientLayer(baseGradient: lowGradient!)
                }
            }
        }
    }
    
    fileprivate func createGradientLayer(baseGradient:BaseGradient) -> BaseGradientLayer? {
        
        let path = UIBezierPath(rect: barRect!).cgPath
        
        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: path, gradient: baseGradient, drawMaskEnabled: false)
        
        return baseGradientLayer
    }
    
    func getGradientColorIndex() -> Int {
        let barEntry = self.getBarChartEntry()
        
        let index = barDataSet?.entryIndex(entry: barEntry)
        
        var gradientIndex:Int = 0
        
        if index != nil {
            gradientIndex = index!
        }
        
        //        if (barDataSet?.isStacked)! {
        //            gradientIndex = (barRectIndex % (barEntry.yValues?.count)!)
        //        }
        
        if getBarChart().data?.dataSets.count == 1 && !getBarChart().isStacked() {
            var colorIndex = gradientIndex
            let origIndex = barEntry.origIndex
            if origIndex != nil {
                colorIndex =  ChartUtils.doubleToIntSafeCast(value:origIndex!)
            }
            gradientIndex = colorIndex
        }
        
        return gradientIndex
    }
    */
    
    
    public static func getAllMapLayer(chart: ChartViewBase) -> [MapLayer]
    {
        var mapLayerArray:[MapLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [MapLayer] {
            mapLayerArray = layers
        }
        
        return mapLayerArray
    }
     
    @available(*, deprecated, renamed: "getAllValueLayer")
    public static func getAllMapValueLayer(chart: ChartViewBase) -> [CATextLayer]
    {
        var mapValueArray:[CATextLayer] = []
        
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    mapValueArray.append((caLayer as! CATextLayer))
                }
            }
            
        }
        return mapValueArray
    }
    
    public static func removeAllMapLayer(chart: ChartViewBase)
    {
        super.removeAllPlotLayer(chart: chart, kind: self)
    }
    
    @available(*, deprecated, renamed: "removeAllValueLayer")
    public static func removeAllMapValueLayer(chart: ChartViewBase)
    {
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }
    
    public static func getMapLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> MapLayer?
    {
        for layer in getAllMapLayer(chart: chart) where layer.path != nil
        {
            if (layer.path?.contains(loc))!
            {
                return (layer)
            }
            
        }
        return nil
    }
    
    public static func getMapLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> MapLayer?
    {
        return super.getLayerForEntry(chart: chart, kind: self, entry: entry) as? MapLayer
    }
    
}

