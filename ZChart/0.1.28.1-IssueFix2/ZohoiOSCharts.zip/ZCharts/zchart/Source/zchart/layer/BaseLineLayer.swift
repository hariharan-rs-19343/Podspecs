//
//  BaseLineLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 03/07/18.
//  Copyright © 2018 zoho. All rights reserved.
//


#if !os(OSX)
    import UIKit
#endif

class BaseLineLayer: CAShapeLayer {
    
    weak var chartBaseLine:ChartBaseLine? = nil
    
    weak var chartViewBase:ChartViewBase? = nil
    
    weak var axisRendererBase:AxisRendererBase? = nil
    
    var lineStartPoint:CGPoint? = nil
    
    var lineEndPoint:CGPoint? = nil
    
    init(chartViewBase: ChartViewBase, axisRendererBase: AxisRendererBase, chartBaseLine: ChartBaseLine, startPoint: CGPoint, endPoint:CGPoint) {
        super.init()
        self.chartViewBase = chartViewBase
        self.chartBaseLine = chartBaseLine
        self.axisRendererBase = axisRendererBase
        self.lineStartPoint = startPoint
        self.lineEndPoint = endPoint
        self.drawBaseLineLayer()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    func drawBaseLineLayer()
    {
        var path = CGMutablePath() // UIBezierPath()
    
        path.move(to: lineStartPoint!)
        
        path.addLine(to: lineEndPoint!)
        
        path.closeSubpath()//.close()
        
        self.path = path//.cgPath
        
        self.lineWidth = (chartBaseLine?.lineWidth)!
        self.strokeColor = chartBaseLine?.lineColor.cgColor
        
        if chartBaseLine?.lineDashLengths != nil
        {
            self.lineDashPhase = (chartBaseLine?.lineDashPhase)!
            self.lineDashPattern = getNSNumberArray(lineDashLengths: chartBaseLine?.lineDashLengths)
        }
        else
        {
            self.lineDashPhase = 0.0
            self.lineDashPattern = nil
        }
        
        
    }
    
    
    func getNSNumberArray(lineDashLengths: [CGFloat]?) -> [NSNumber]
    {
        var numberArray:[NSNumber] = []
        
        if lineDashLengths != nil
        {
            for i in 0 ..< (lineDashLengths?.count)!
            {
                let number = NSNumber(value: Float((lineDashLengths?[i])!))
                numberArray.append(number)
            }
        }
        
        return numberArray
    }
    
    

    public static func getAllBaseLineLayer(chartViewBase: ChartViewBase) -> [BaseLineLayer]
    {
        var baseLineArray:[BaseLineLayer] = []
        
        if let layers = chartViewBase.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: BaseLineLayer.self)
                {
                    baseLineArray.append((caLayer as! BaseLineLayer))
                }
            }
        }
        Log.debug("Limit Layer count \(baseLineArray.count)")
        return baseLineArray
    }
    
    public static func removeAllBaseLineLayer(chartViewBase: ChartViewBase)
    {
        
        if let layers = chartViewBase.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: BaseLineLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }
    
    
}
