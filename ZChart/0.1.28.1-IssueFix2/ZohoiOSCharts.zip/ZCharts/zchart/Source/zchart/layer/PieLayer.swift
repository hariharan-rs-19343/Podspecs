//
//  PieLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 22/10/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class PieLayer  : ChartEntryLayer
{
    open var slicePath:CGMutablePath? = nil
    
    open var chartDataSet:ChartDataSet? = nil
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    public init(chart : ChartViewBase, chartEntry: ChartDataEntry, chartDataSet: ChartDataSet, slicePath:CGMutablePath) {
        
        super.init(chartView: chart, chartEntry: chartEntry)
        
        self.chartDataSet = chartDataSet
        
        self.chartView = chart
        
        self.slicePath = slicePath
        
        drawSlice()
        drawGradientLayer()
        callHighlightDelegate(dataset: chartDataSet)
    }
    
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func drawSlice()
    {
        guard let pieChart = chartView,
              let set = chartDataSet
            else { return }
        
        let entryIndex = set.entryIndex(entry: chartEntry!)

        self.path = self.slicePath!
        self.fillColor = set.color(atIndex: entryIndex).cgColor
        
        if pieChart.colorAxis.isEnabled {
            self.fillColor = (pieChart.colorAxis.getColor(entry: chartEntry!)?.cgColor) ?? NSUIColor.clear.cgColor
        }
        
        pieChart.plotView?.nsuiLayer?.addSublayer(self)
        
    }
    
    public static func getPieLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> PieLayer?
    {
        for layer in getAllPieLayer(chart: chart)
        {
            guard (layer.path != nil)
            else { continue }
            if (layer.path?.contains(loc))!
            {
                return (layer)
            }
            
        }
        return nil
    }
    
    public static func getAllPieLayer(chart: ChartViewBase) -> [PieLayer]
    {
        var PieArray:[PieLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [PieLayer] {
            PieArray = layers
        }
        
        return PieArray
    }
    
    public static func getPieLayerForEntry(chart: ChartViewBase, entry:ChartDataEntry) -> PieLayer?
    {
        return super.getLayerForEntry(chart: chart, kind: self, entry: entry) as? PieLayer
    }
    
    public static func getPieLayersForEntryXY(chart: ChartViewBase, entry:ChartDataEntry) -> [PieLayer]
    {
        var pieLayers:[PieLayer] = []
        
        for layer in getAllPieLayer(chart: chart)
        {
            if layer.chartEntry!.x == entry.x && layer.chartEntry!.y == entry.y
            {
                pieLayers.append(layer)
            }
        }
        return pieLayers
    }
    
    public static func removeAllPieValueLayer(chart: ChartViewBase)
    {
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: ValueTextLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }
    
    public static func getAllPieValueLayer(chart: ChartViewBase) -> [CALayer]
    {
        let newChart = chart.plotView
        
        var valueLayers:[CALayer] = []
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: ValueTextLayer.self)
                {
                    if let subLayers = caLayer.sublayers
                    {
                        for sublayer in subLayers
                        {
                            valueLayers.append(sublayer)
                        }
                    }
                }
            }
            
        }
        
        return valueLayers
    }
    
    func drawGradientLayer() {

        guard let pieChart = chartView,
            let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }

        guard let pieDataSet = (pieChart.data?.dataSets[0]) //as! PieChartDataSet
        else { return }

        let gradients = pieDataSet.gradients

        if gradients.count == 0 {
            return
        }

        self.fillColor = NSUIColor.clear.cgColor

        let entry = chartEntry!

        let entryIndex = pieDataSet.entryIndex(entry: entry)

        let gradient = pieDataSet.gradient(atIndex: entryIndex)

        let uiBezeirPath = self.getInitialPath(pieChart: pieChart, entry: entry, radius: piePlot.radius)

//        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: uiBezeirPath.cgPath, gradient: gradient, drawMaskEnabled: true)

        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: slicePath!, gradient: gradient, drawMaskEnabled: true)

        
        if baseGradientLayer != nil {
            Log.info("Gradient layer created for entry " + String(describing: entry))
        }

        if baseGradientLayer != nil && (gradient.isKind(of: RadialGradient.self)) {

            let radialGradientLayer = baseGradientLayer as! RadialGradientLayer

            let bounds = uiBezeirPath.boundingBox// .bounds
            let center = piePlot.centerCircleBox
            let gradientCenter = CGPoint(x: (center.x - bounds.minX), y: (center.y - bounds.minY))
            radialGradientLayer.center = gradientCenter

            radialGradientLayer.radius = piePlot.radius

            if piePlot.drawHoleEnabled {
                radialGradientLayer.radiusPercent = piePlot.holeRadiusPercent
            }
            radialGradientLayer.setNeedsDisplay()
        }
    }
    

    
    /*open func getSlicePath(pieChart: PieChartView, entry:ChartDataEntry, pieCenter: CGPoint, radius: CGFloat) -> UIBezierPath
    {
        var (startAngle, endAngle) = getStartEndAngle(pieChart: pieChart, entry: entry)

        let dataSet = (pieChart.data?.dataSets[0]) as! PieChartDataSet
        
        let sliceSpaceEnabled = dataSet.sliceSpace > 0
        
        var visibleAngleCount = 0
        
        let isClockwise = pieChart.sliceDirection == .clockwise
        
        for j in 0 ..< dataSet.entryCount
        {
            guard let e = dataSet.entryForIndex(j) else { continue }
            if ((abs(e.y) > Double.ulpOfOne))
            {
                visibleAngleCount += 1
            }
        }
        
        let sliceSpaceAngleOuter = visibleAngleCount == 1 ?
            0.0 :
            dataSet.sliceSpace / (ChartUtils.Math.FDEG2RAD * radius)
        
        
        if sliceSpaceEnabled
        {
//            startAngle = startAngle + (sliceSpaceAngleOuter/2)
//            endAngle = endAngle - (sliceSpaceAngleOuter/2)
            if isClockwise {
                startAngle = startAngle + (sliceSpaceAngleOuter/2)
                endAngle = endAngle - (sliceSpaceAngleOuter/2)
            } else {
                startAngle = startAngle - (sliceSpaceAngleOuter/2)
                endAngle = endAngle + (sliceSpaceAngleOuter/2)
            }
        }
        
        let uiBezeirPath = UIBezierPath()
        
        let arcStartPointX = pieCenter.x + radius * cos(startAngle * ChartUtils.Math.FDEG2RAD)
        let arcStartPointY = pieCenter.y + radius * sin(startAngle * ChartUtils.Math.FDEG2RAD)
        
        /// Starts from top left -> top right -> bottom right -> bottom left -> top left
        uiBezeirPath.move(
            to: CGPoint(x: arcStartPointX,
                        y: arcStartPointY))
        
        uiBezeirPath.addArc(withCenter: pieCenter, radius: radius , startAngle: startAngle * ChartUtils.Math.FDEG2RAD, endAngle: endAngle * ChartUtils.Math.FDEG2RAD, clockwise: isClockwise)
        
        if pieChart.drawHoleEnabled // DOUGHNUT
        {
            let innerRadius = radius * pieChart.holeRadiusPercent
            let sliceSpaceAngleInner = visibleAngleCount == 1 || innerRadius == 0.0 ?
                0.0 :
                dataSet.sliceSpace / (ChartUtils.Math.FDEG2RAD * innerRadius)
            
            var (startInnerAngle, endInnerAngle) = getStartEndAngle(pieChart: pieChart, entry: entry)
            
            if sliceSpaceEnabled
            {
                if isClockwise {
                    startInnerAngle = startInnerAngle + (sliceSpaceAngleInner/2)
                    endInnerAngle = endInnerAngle - (sliceSpaceAngleInner/2)
                } else {
                    startInnerAngle = startInnerAngle - (sliceSpaceAngleInner/2)
                    endInnerAngle = endInnerAngle + (sliceSpaceAngleInner/2)
                }
            }
            
            if (endAngle > startAngle) && (startInnerAngle > endInnerAngle) {
                endInnerAngle = startInnerAngle
            }
            
            uiBezeirPath.addLine(
                to: CGPoint(
                    x: pieCenter.x + innerRadius * cos(endInnerAngle * ChartUtils.Math.FDEG2RAD),
                    y: pieCenter.y + innerRadius * sin(endInnerAngle * ChartUtils.Math.FDEG2RAD)))
            
            
            uiBezeirPath.addArc(withCenter: pieCenter, radius: innerRadius , startAngle: endInnerAngle * ChartUtils.Math.FDEG2RAD, endAngle: startInnerAngle * ChartUtils.Math.FDEG2RAD, clockwise: !isClockwise)
            
            uiBezeirPath.addLine(
                to: CGPoint(
                    x: pieCenter.x + radius * cos(startAngle * ChartUtils.Math.FDEG2RAD),
                    y: pieCenter.y + radius * sin(startAngle * ChartUtils.Math.FDEG2RAD)))
            
            uiBezeirPath.close()
            
        }
        else
        {
            uiBezeirPath.addLine(to: pieCenter)
            uiBezeirPath.close()
        }
        
        return uiBezeirPath
        
    }*/
    
    open func getEndPath(pieChart: ChartViewBase, entry:ChartDataEntry, radius: CGFloat) -> CGMutablePath
    {
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return CGMutablePath() }
        
        let midAnglee = PieHelperFunctions.getMidAngle(chart: pieChart, entry: entry)
        
        let newx = piePlot.centerCircleBox.x + ((radius/8) * cos(midAnglee.radians()))
        
        let newy = piePlot.centerCircleBox.y + ((radius/8) * sin(midAnglee.radians()))
        
        let newCenter = CGPoint(x: newx, y: newy)
        
        let uiBezeirPath = getSlicePath(pieChart: pieChart, entry: entry, pieCenter: newCenter, radius: radius)
        
        return uiBezeirPath
    }
    
    func getArcPath(center:CGPoint, radius:CGFloat, startAngleOuter:CGFloat, sweepAngleOuter:CGFloat, drawInnerArc:Bool, innerRadius:CGFloat) -> CGMutablePath
    {
        let arcStartPointX = center.x + radius * cos(startAngleOuter * ChartUtils.Math.FDEG2RAD)
        
        let arcStartPointY = center.y + radius * sin(startAngleOuter * ChartUtils.Math.FDEG2RAD)
        
        let path = CGMutablePath()
    
        path.move(to: CGPoint(x: arcStartPointX,
                              y: arcStartPointY))
        
        path.addRelativeArc(center: center, radius: radius, startAngle: startAngleOuter * ChartUtils.Math.FDEG2RAD, delta: sweepAngleOuter * ChartUtils.Math.FDEG2RAD)
        
       
        if drawInnerArc && (innerRadius > 0.0)
        {
            let endAngleInner = startAngleOuter + sweepAngleOuter

            path.addLine(
                to: CGPoint(
                    x: center.x + innerRadius * cos(endAngleInner * ChartUtils.Math.FDEG2RAD),
                    y: center.y + innerRadius * sin(endAngleInner * ChartUtils.Math.FDEG2RAD)))

            path.addRelativeArc(center: center, radius: innerRadius, startAngle: endAngleInner * ChartUtils.Math.FDEG2RAD, delta: -sweepAngleOuter * ChartUtils.Math.FDEG2RAD)
        }
        else
        {
            path.addLine(to: center)
        }
        
        path.closeSubpath()
        
        
        return path
    }
    
    open func getInitialPath(pieChart: ChartViewBase, entry:ChartDataEntry, radius: CGFloat) -> CGMutablePath
    {
        guard let piePlot = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return CGMutablePath() }
        
        let pieCenter = piePlot.centerCircleBox
        
        let uiBezeirPath = getSlicePath(pieChart: pieChart, entry: entry, pieCenter: pieCenter, radius: radius)
        
        return uiBezeirPath
    }
    
    open func getStartEndAngle(pieChart: ChartViewBase, entry:ChartDataEntry) ->  (startAngle: CGFloat, endAngle: CGFloat)
    {
        guard let piePlotOption = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return (0,0) }
        
        let rotationAngle = piePlotOption.rotationAngle
        
        guard let entryIndex = pieChart.data?.dataSets[0].entryIndex(entry: entry)
        else { return (0,0) }
        
        
        let angleLength = piePlotOption.drawAngles[entryIndex]
        var absAngle = piePlotOption.absoluteAngles[entryIndex]
        
        var startAngle = absAngle - angleLength
        
        if piePlotOption.sliceDirection == .clockwise {
         startAngle = startAngle + rotationAngle
        }else {
         startAngle = rotationAngle - startAngle
        }
        
        
        if startAngle > 360
        {
            startAngle = startAngle - 360
        }
        
//        absAngle = absAngle + rotationAngle
        
        if piePlotOption.sliceDirection == .clockwise {
          absAngle = absAngle + rotationAngle
        }else {
         absAngle = rotationAngle - absAngle
        }
        
        if absAngle > 360
        {
            absAngle = absAngle - 360
        }
        
        if startAngle == absAngle
        {
            absAngle = startAngle + 360
        }
        
        if startAngle < 0 {
            startAngle = startAngle + 360
        }
        
        if absAngle < 0 {
            absAngle = absAngle + 360
        }
        
        return (startAngle, absAngle)
    }
    
    open func getSlicePath(pieChart: ChartViewBase, entry:ChartDataEntry, pieCenter: CGPoint, radius: CGFloat) -> CGMutablePath
    {
        
        let uiBezeirPath = CGMutablePath()
        
        guard let piePlotOption = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return uiBezeirPath }
        
        let sliceSpaceEnabled = piePlotOption.sliceSpace > 0
        
        let isClockwise = piePlotOption.sliceDirection == .clockwise
        
        /*var visibleAngleCount = 0
        
        for j in 0 ..< dataSet.entryCount
        {
            guard let e = dataSet.entryForIndex(j) else { continue }
            if ((abs(e.y) > Double.ulpOfOne))
            {
                visibleAngleCount += 1
            }
        }
        
        let sliceSpaceAngleOuter = visibleAngleCount == 1 ?
            0.0 :
            dataSet.sliceSpace / (ChartUtils.Math.FDEG2RAD * radius)
        
        
        if sliceSpaceEnabled
        {
            //            startAngle = startAngle + (sliceSpaceAngleOuter/2)
            //            endAngle = endAngle - (sliceSpaceAngleOuter/2)
            if isClockwise {
                startAngle = startAngle + (sliceSpaceAngleOuter/2)
                endAngle = endAngle - (sliceSpaceAngleOuter/2)
            } else {
                startAngle = startAngle - (sliceSpaceAngleOuter/2)
                endAngle = endAngle + (sliceSpaceAngleOuter/2)
            }
        }*/
        
        var (startAngle, endAngle) = getStartEndAngle(pieChart: pieChart, entry: entry)
        
        if sliceSpaceEnabled {
            (startAngle, endAngle) = PieLayer.getStartEndAngle(pieChart: pieChart, entry: entry, radius: radius, center: pieCenter)
        }
        
        let arcStartPointX = pieCenter.x + radius * cos(startAngle * ChartUtils.Math.FDEG2RAD)
        let arcStartPointY = pieCenter.y + radius * sin(startAngle * ChartUtils.Math.FDEG2RAD)
        
        /// Starts from top left -> top right -> bottom right -> bottom left -> top left
        uiBezeirPath.move(
            to: CGPoint(x: arcStartPointX,
                        y: arcStartPointY))
        
//        uiBezeirPath.addArc(withCenter: pieCenter, radius: radius , startAngle: startAngle * ChartUtils.Math.FDEG2RAD, endAngle: endAngle * ChartUtils.Math.FDEG2RAD, clockwise: isClockwise)
        uiBezeirPath.addArc(center: pieCenter, radius: radius, startAngle: startAngle * ChartUtils.Math.FDEG2RAD, endAngle: endAngle * ChartUtils.Math.FDEG2RAD, clockwise: !isClockwise)
//        uiBezeirPath.addArc(center: <#T##CGPoint#>, radius: <#T##CGFloat#>, startAngle: <#T##CGFloat#>, endAngle: <#T##CGFloat#>, clockwise: <#T##Bool#>)
        if piePlotOption.drawHoleEnabled // DOUGHNUT
        {
           /* let innerRadius = radius * pieChart.holeRadiusPercent
            let sliceSpaceAngleInner = visibleAngleCount == 1 || innerRadius == 0.0 ?
                0.0 :
                dataSet.sliceSpace / (ChartUtils.Math.FDEG2RAD * innerRadius)
            
            var (startInnerAngle, endInnerAngle) = getStartEndAngle(pieChart: pieChart, entry: entry)
            
            
            if sliceSpaceEnabled
            {
                if isClockwise {
                    startInnerAngle = startInnerAngle + (sliceSpaceAngleInner/2)
                    endInnerAngle = endInnerAngle - (sliceSpaceAngleInner/2)
                } else {
                    startInnerAngle = startInnerAngle - (sliceSpaceAngleInner/2)
                    endInnerAngle = endInnerAngle + (sliceSpaceAngleInner/2)
                }
            }
            
            if (endAngle > startAngle) && (startInnerAngle > endInnerAngle) {
                endInnerAngle = startInnerAngle
            }*/
            
            let innerRadius = radius * piePlotOption.holeRadiusPercent
            var (startInnerAngle, endInnerAngle) = getStartEndAngle(pieChart: pieChart, entry: entry)
            if sliceSpaceEnabled {
                (startInnerAngle, endInnerAngle) = PieLayer.getStartEndAngle(pieChart: pieChart, entry: entry, radius: innerRadius, center: pieCenter)
            }
            
            uiBezeirPath.addLine(
                to: CGPoint(
                    x: pieCenter.x + innerRadius * cos(endInnerAngle * ChartUtils.Math.FDEG2RAD),
                    y: pieCenter.y + innerRadius * sin(endInnerAngle * ChartUtils.Math.FDEG2RAD)))
            
            
//            uiBezeirPath.addArc(withCenter: pieCenter, radius: innerRadius , startAngle: endInnerAngle * ChartUtils.Math.FDEG2RAD, endAngle: startInnerAngle * ChartUtils.Math.FDEG2RAD, clockwise: !isClockwise)
            uiBezeirPath.addArc(center: pieCenter, radius: innerRadius, startAngle: endInnerAngle * ChartUtils.Math.FDEG2RAD, endAngle: startInnerAngle * ChartUtils.Math.FDEG2RAD, clockwise: isClockwise)
            
            uiBezeirPath.addLine(
                to: CGPoint(
                    x: pieCenter.x + radius * cos(startAngle * ChartUtils.Math.FDEG2RAD),
                    y: pieCenter.y + radius * sin(startAngle * ChartUtils.Math.FDEG2RAD)))
            
//            uiBezeirPath.close()
            uiBezeirPath.closeSubpath()
            
        }
        else
        {
            uiBezeirPath.addLine(to: pieCenter)
//            uiBezeirPath.close()
//            uiBezeirPath.closeSubpath()
        }
        
        return uiBezeirPath
        
    }
    
    public static func getStartEndAngle(pieChart: ChartViewBase, entry:ChartDataEntry, radius:CGFloat, center:CGPoint) ->  (startAngle: CGFloat, endAngle: CGFloat)
    {
        guard let piePlotOption = pieChart.getPlotOptions(type: .Pie) as? PiePlotOptions,
                let dataSet = pieChart.data?.dataSets[0]
                   else { return (0,0) }
        
        var visibleAngleCount = 0
        
        for j in 0 ..< dataSet.entryCount
        {
            guard let e = dataSet.entryForIndex(j) else { continue }
            if ((abs(e.y) > Double.ulpOfOne))
            {
                visibleAngleCount += 1
            }
        }
        
        let sliceSpaceAngle = visibleAngleCount == 1 || radius == 0.0 ?
            0.0 :
            piePlotOption.sliceSpace / (ChartUtils.Math.FDEG2RAD * radius)
        
//        let (drawAngles, absoluteAngles) = PieHelperFunctions.getDrawAbsoluteAngles(chart: pieChart, sliceSpaceAngle: sliceSpaceAngle)
        let (drawAngles, absoluteAngles) = (piePlotOption.drawAngles, piePlotOption.absoluteAngles)
        
        let rotationAngle = piePlotOption.rotationAngle
        
        guard let entryIndex = pieChart.data?.dataSets[0].entryIndex(entry: entry)
        else { return (0,0) }
        
        
        let angleLength = drawAngles[entryIndex] - sliceSpaceAngle
        var absAngle = absoluteAngles[entryIndex] - sliceSpaceAngle / 2.0
        
        var startAngle = absAngle - angleLength
        
        if piePlotOption.sliceDirection == .clockwise {
            startAngle = startAngle + rotationAngle
        }else {
            startAngle = rotationAngle - startAngle
        }
        
        
        if startAngle > 360
        {
            startAngle = startAngle - 360
        }
        
        //        absAngle = absAngle + rotationAngle
        
        if piePlotOption.sliceDirection == .clockwise {
            absAngle = absAngle + rotationAngle
        }else {
            absAngle = rotationAngle - absAngle
        }
        
        if absAngle > 360
        {
            absAngle = absAngle - 360
        }
        
        if startAngle == absAngle
        {
            absAngle = startAngle + 360
        }
        
        if startAngle < 0 {
            startAngle = startAngle + 360
        }
        
        if absAngle < 0 {
            absAngle = absAngle + 360
        }
        
        return (startAngle, absAngle)
    }
    /*
    override func highlightLayer( isHighlighted: Bool, plotType: ChartType? = nil) {
        
        if chartDataSet != nil && chartDataSet!.plotType == ChartType.Pie {
            if !isHighlighted {
                let fillColor = NSUIColor(cgColor: self.fillColor ?? NSUIColor.gray.cgColor)
                #if !os(OSX)
                    self.fillColor = fillColor.withAlphaComponent(0.5).cgColor
                #endif
                #if os(OSX)
                    self.fillColor = fillColor?.withAlphaComponent(0.5).cgColor
                #endif
            }
        }
        else {
            
            if !isHighlighted {
                self.fillColor = NSUIColor.gray.withAlphaComponent(0.5).cgColor
            }
        }
        
    }
    */
}

public class DialLevelLayer: PieLayer{
    
    open var levelValue:Double!
    
    public static func getAllDialLevelLayers(chart:ChartViewBase) -> [DialLevelLayer]
    {
        var dialLevelArray:[DialLevelLayer] = []
        
        let newChart = chart.plotView
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: DialLevelLayer.self)
                {
                    dialLevelArray.append((caLayer as! DialLevelLayer))
                }
            }
        }
        return dialLevelArray
    }
}

