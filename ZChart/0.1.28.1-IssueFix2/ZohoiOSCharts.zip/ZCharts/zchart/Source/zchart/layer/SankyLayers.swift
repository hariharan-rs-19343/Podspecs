//
//  SankyLayers.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 16/09/22.
//

import Foundation

public enum SankyLayerType
{
    case Node
    case Link
    case CircularLink
}

public enum RectPoints
{
    case topLeft
    case topRight
    case bottomLeft
    case bottomRight
}

open class SankyLayers : ChartEntryLayer {
    
    open var dataSet:IChartDataSet? = nil
    
    open var nodeName:String = ""
    
    open var type = SankyLayerType.Node
    
    open var rectPoints:[RectPoints:CGPoint] = [:]
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, type: SankyLayerType, path:CGPath, index:Int) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.dataSet = dataSet
        self.type = type
        addCircularLink(path: path,index: index)
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
    }
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, type: SankyLayerType, rect:[RectPoints:CGPoint], index:Int) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.dataSet = dataSet
        self.type = type
        self.rectPoints = rect
        self.drawEntryLayer(index:index)
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
    }
    
    init(chartView: ChartViewBase, nodeName: String, dataSet: IChartDataSet, type: SankyLayerType, rect:[RectPoints:CGPoint], index:Int) {
        super.init()
        self.chartView = chartView
        self.dataSet = dataSet
        self.type = type
        self.nodeName = nodeName
        self.rectPoints = rect
        self.drawEntryLayer(index:index)
        
        if (chartView.customAnimationInProgress) {
            self.opacity = 0.0
        }
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    open func addCircularLink(path: CGPath,index:Int) {
        
        guard let plotOption = chartView?.getPlotOptions(type: .Sanky) as? SankeyPlotOptions,
              let chartData = chartView?.data
            else { return }
        
        let setColors = chartData.dataSets[0].colors
        
        self.path = path
        
        self.fillColor = setColors[index%setColors.count].withAlphaComponent(plotOption.linkOpacity).cgColor
        
        chartView?.plotView?.nsuiLayer?.addSublayer(self)
    }
    
    open func drawEntryLayer(index:Int)
    {
        guard let plotOption = chartView?.getPlotOptions(type: .Sanky) as? SankeyPlotOptions,
              let chartData = chartView?.data
            else { return }
        
        let setColors = chartData.dataSets[0].colors
        
        if type == .Node
        {
            guard let minX = rectPoints[.topLeft]?.x,
                  let minY = rectPoints[.topLeft]?.y,
                  let maxX = rectPoints[.topRight]?.x,
                  let maxY = rectPoints[.bottomRight]?.y
            else { return }
            
            let width = maxX - minX
            let height =  maxY - minY
            
//            let newPath = UIBezierPath(rect: CGRect(x: minX, y: minY, width: width, height: height))
            let newPath = CGMutablePath(rect: CGRect(x: minX, y: minY, width: width, height: height), transform: nil)
            
            self.fillColor = setColors[index%setColors.count].cgColor
            self.path = newPath//.cgPath
        }
        else{
            guard let sourceX =  rectPoints[.topLeft]?.x,
                  let sourceY0 = rectPoints[.topLeft]?.y,
                  let sourceY1 = rectPoints[.bottomLeft]?.y,
                  let targetX = rectPoints[.topRight]?.x,
                  let targetY0 = rectPoints[.topRight]?.y,
                  let targetY1 = rectPoints[.bottomRight]?.y
            else { return }
            
            let (c1,c2) = getControlX(rectPoints: rectPoints)
            
            let newPath = CGMutablePath()
                    
            newPath.move(to: CGPoint(x: sourceX, y: sourceY0))
            
//            newPath.addCurve(to: CGPoint(x: targetX, y: targetY0), controlPoint1: CGPoint(x: c1, y: sourceY0) , controlPoint2: CGPoint(x: c1, y: targetY0 ))
            newPath.addCurve(to: CGPoint(x: targetX, y: targetY0), control1: CGPoint(x: c1, y: sourceY0) , control2: CGPoint(x: c1, y: targetY0 ))
            
            newPath.addLine(to: CGPoint(x: targetX, y: targetY1))
            
//            newPath.addCurve(to: CGPoint(x: sourceX, y: sourceY1), controlPoint1: CGPoint(x: c2, y: targetY1), controlPoint2: CGPoint(x: c2, y: sourceY1))
            newPath.addCurve(to: CGPoint(x: sourceX, y: sourceY1), control1: CGPoint(x: c2, y: targetY1), control2: CGPoint(x: c2, y: sourceY1))
            
            newPath.closeSubpath()//.close()
            
            self.fillColor = setColors[index%setColors.count].withAlphaComponent(plotOption.linkOpacity).cgColor
            self.path = newPath//.cgPath
        }
        chartView?.plotView?.nsuiLayer?.addSublayer(self)
        
    }
    
    public func getControlX(rectPoints: [RectPoints:CGPoint]) -> (c1:CGFloat,c2:CGFloat)
    {
        
        guard let x0 =  rectPoints[.topLeft]?.x,
              let y0 = rectPoints[.topLeft]?.y,
              let x1 = rectPoints[.topRight]?.x,
              let y1 = rectPoints[.topRight]?.y,
              let y0End = rectPoints[.bottomLeft]?.y
        else { return (0,0) }
        
        let linkWidth = abs(y0End - y0)
        
        let width = linkWidth
        var controlPointX = (x0 + x1) / 2
        var controlPointX2 = (x0 + x1) / 2

        if (x1 - x0 > width / 2) {
            if (y0 > y1) {
                controlPointX2 += width / 2;
            } else {
                controlPointX += width / 2;
            }
        }
        return (controlPointX,controlPointX2)
    }
    
    public static func getAllSankeyLayer(chart: ChartViewBase) -> [SankyLayers]
    {
        var layerArray:[SankyLayers] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [SankyLayers] {
            layerArray = layers
        }
        
        return layerArray
    }
    
    public static func getAllNodeLayer(chart: ChartViewBase) -> [SankyLayers]
    {
        var layerArray:[SankyLayers] = []
        
        let newChart = chart
        
        if let layers = newChart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                
                guard let nodeLayer = (caLayer as? SankyLayers), nodeLayer.type == .Node
                    else { continue }
                
                layerArray.append((nodeLayer))
            }
        }
        
        
        return layerArray
    }
    
    public static func getAllLinkLayer(chart: ChartViewBase) -> [SankyLayers]
    {
        var layerArray:[SankyLayers] = []
        
        let newChart = chart
        
        if let layers = newChart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                
                guard let linkLayer = (caLayer as? SankyLayers), linkLayer.type == .Link || linkLayer.type == .CircularLink
                    else { continue }
                
                layerArray.append((linkLayer))
            }
        }
        
        
        return layerArray
    }
    
    public static func getSankeyLayerForTouchPoint(chart: ChartViewBase, loc: CGPoint) -> SankyLayers? {
        
        let newChart = chart
        
        if let layers = newChart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                
                guard let sankyLayer = (caLayer as? SankyLayers), let path = sankyLayer.path
                    else { continue }
                
                if path.contains(loc) {
                    return sankyLayer
                }
            }
        }
        
        return nil
    }
    
    public static func getSankeyNodeLayerForNodeName(chart: ChartViewBase, nodeName: String) -> SankyLayers? {
        
        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                
                guard let nodeLayer = (caLayer as? SankyLayers), nodeLayer.type == .Node
                    else { continue }
                
                if nodeName == nodeLayer.nodeName {
                    return nodeLayer
                }
            }
        }
        return nil
    }
    
    public static func getSankeyLinkLayerForEntry(chart: ChartViewBase, entry: ChartDataEntry) -> SankyLayers? {
        
        let newChart = chart
        
        if let layers = newChart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                
                guard let linkLayer = (caLayer as? SankyLayers), linkLayer.type == .Link || linkLayer.type == .CircularLink
                    else { continue }
                
                if linkLayer.chartEntry == entry {
                    return linkLayer
                }
            }
        }
        
        return nil
    }
}
