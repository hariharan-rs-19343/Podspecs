//
//  LimitLineLayer.swift
//  zchart
//
//  Created by Aravinth T on 06/09/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class LimitLineLayer: CAShapeLayer {
    
    open weak var charLimitLine:ChartLimitLine? = nil
    
    weak var chartViewBase:ChartViewBase? = nil
    
    weak var axisRendererBase:AxisRendererBase? = nil
    
    var linePosition:CGRect? = nil
    
    var lineEndPoint:CGPoint? = nil
    
    init(chartViewBase: ChartViewBase, axisRendererBase: AxisRendererBase, charLimitLine: ChartLimitLine, position: CGRect, endPoint:CGPoint) {
        super.init()
        self.chartViewBase = chartViewBase
        self.charLimitLine = charLimitLine
        self.axisRendererBase = axisRendererBase
        self.linePosition = position
        self.lineEndPoint = endPoint
        self.drawLimitLayer()
        self.drawMaskLayer()
        
        if chartViewBase.customAnimationInProgress || chartViewBase._animator._displayLink != nil
        {
            self.opacity = 0
        }
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    func drawLimitLayer()
    {
        var path = CGMutablePath() // UIBezierPath()
        
        var textFrame:CGRect
        
        let axis = (self.axisRendererBase?.axis)!
        
        let value = (self.charLimitLine?.limit)!
        
        var formattedString:String
        
        if axis.scaleType == .Time
        {
            let interValType =  (axis.scaleTypeProtocol as! TimeScale).currentType
            formattedString = (axis.valueFormatter?.stringForValue?(value, axis: axis, intervalType: interValType)) ?? ""
        }
        else{
            formattedString = (self.axisRendererBase?.axis?.valueFormatter?.stringForValue(value, axis: axis)) ?? ""
        }
        
        formattedString = charLimitLine?.valueFormattor?.getFormattedValue(value: value, axis: axis) ?? formattedString
        
        var centerPoint = CGPoint(x: (linePosition?.midX)!, y: (linePosition?.midY)!)
        
        var textSize = formattedString.size(withAttributes: [NSAttributedString.Key.font: (charLimitLine?.limitValueFont)!])
        
        if charLimitLine?.shapeProperties?.visible ?? false || charLimitLine?.shapeProperties == nil {
            if charLimitLine?.shapeProperties?.shapeType == .custom
            {
                path = (charLimitLine?.shapeProperties?.customPathDataSource?.limitLineShapePath?(shapeFrame: linePosition!, chartLimitLine: (charLimitLine)!)) ?? path
            }
            else {
                path.move(to: centerPoint)
                path.addArc(center: centerPoint, radius: (((linePosition?.height)!*0.8)/2), startAngle: 0, endAngle: 360, clockwise: false)
            }
        }
        
        centerPoint = (charLimitLine?.drawLimitValueEnabled ?? false) ? centerPoint : getStartPoint(textCenterPoint: centerPoint, axis: axis, chart: chartViewBase!)
        
        if textSize.width > linePosition!.width
        {
            textSize = CGSize(width: linePosition!.width, height: textSize.height)
        }
        
        textFrame = CGRect(x: (linePosition?.midX)!-(textSize.width/2), y: (linePosition?.midY)!-(textSize.height/2), width: textSize.width, height: textSize.height)
        
        path.move(to: centerPoint)
        
        path.addLine(to: lineEndPoint!)
        
        path.closeSubpath()// .close()
        
        self.path = path//.cgPath
        
        self.lineWidth = (charLimitLine?.lineWidth)!
        self.strokeColor = charLimitLine?.lineColor.cgColor
        
        self.fillColor = charLimitLine?.lineColor.cgColor
        
        if charLimitLine?.lineDashLengths != nil
        {
            self.lineDashPhase = (charLimitLine?.lineDashPhase)!
            self.lineDashPattern = LimitLineLayer.getNSNumberArray(lineDashLengths: charLimitLine?.lineDashLengths)
        }
        else
        {
            self.lineDashPhase = 0.0
            self.lineDashPattern = nil
        }
        
        if (charLimitLine?.drawLimitValueEnabled)!
        {
            let textLayer = CATextLayer()
         
            textLayer.string = formattedString
            
            textLayer.font =  charLimitLine?.limitValueFont
            
            textLayer.fontSize = (charLimitLine?.limitValueFont.pointSize)!
            
            textLayer.foregroundColor = charLimitLine?.limitValueTextColor.cgColor
            
            textLayer.contentsScale = NSUIMainScreen()!.nsuiScale // UIScreen.main.scale
            
            textLayer.frame = textFrame
            
            textLayer.truncationMode = charLimitLine!.limitValueTruncateMode
            
            self.addSublayer(textLayer)
        }
        
    }
    
    func getStartPoint(textCenterPoint:CGPoint,axis:AxisBase, chart:ChartViewBase) -> CGPoint {
        
        guard let vpHandler = chart.viewPortHandler else {
          return textCenterPoint
        }
        
        var newPoint = CGPoint(x: textCenterPoint.x, y: textCenterPoint.y)
        
        if (axis is YAxis)
        {
            let yAxis = axis as! YAxis
            if (chart.isRotated)
            {
                if (yAxis.axisDependency == .left)
                {
                    newPoint.y = vpHandler.contentTop
                }
                else
                {
                    newPoint.y = vpHandler.contentBottom
                }
            }
            else
            {
                if (yAxis.axisDependency == .left)
                {
                    newPoint.x = vpHandler.contentLeft
                }
                else
                {
                    newPoint.x = vpHandler.contentRight
                }
            }
        }
        else
        {
            let xAxis = axis as! XAxis
            //Handled for bottom in X axis
            if (chart.isRotated)
            {
               
                if xAxis.labelPosition == .top
                {
                    newPoint.x = vpHandler.contentRight
                }
                else{
                    newPoint.x = vpHandler.contentLeft
                }
                
            }
            else
            {
                if xAxis.labelPosition == .top
                {
                    newPoint.y = vpHandler.contentTop
                }
                else{
                    newPoint.y = vpHandler.contentBottom
                }
                
            }
        }
        
        return newPoint
    }
    
    func drawMaskLayer()
    {
        let maskLayer = CAShapeLayer()
        
        let viewPortHandler = self.chartViewBase?.viewPortHandler
        
        guard (viewPortHandler != nil)
        else { return }
        
        let leftRightAxisRect = CGRect(x: 0, y: (viewPortHandler?.contentRect.origin.y)!, width: (self.chartViewBase?.frame.width)!, height: (viewPortHandler?.contentRect.size.height)!)
        
        let topBottomAxisRect = CGRect(x: (viewPortHandler?.contentLeft)!, y: 0, width: (viewPortHandler?.contentRect.width)!, height: (chartViewBase?.frame.height)!)
        
        var newRect:CGRect
        
        if (self.chartViewBase?.isRotated)!
        {
            if (self.axisRendererBase?.axis?.isKind(of: XAxis.self)) ?? true
            {
                newRect = leftRightAxisRect
            }
            else{
                newRect = topBottomAxisRect
            }
        }
        else{
            if (self.axisRendererBase?.axis?.isKind(of: XAxis.self)) ?? true
            {
                newRect = topBottomAxisRect
            }
            else{
                newRect = leftRightAxisRect
            }
        }
        
       
        
        let path = CGMutablePath(rect: newRect, transform: nil)  //UIBezierPath(rect: newRect)
        
        maskLayer.path = path//.cgPath
        
        self.backgroundColor = NSUIColor.clear.cgColor
        
//        self.mask = maskLayer
        
    }
    
    
    public static func getNSNumberArray(lineDashLengths: [CGFloat]?) -> [NSNumber]
    {
        var numberArray:[NSNumber] = []
        
        if lineDashLengths != nil
        {
            for i in 0 ..< (lineDashLengths?.count)!
            {
                let number = NSNumber(value: Float((lineDashLengths?[i])!))
                numberArray.append(number)
            }
        }
        
        return numberArray
    }
    
    
    
    //    open static func getAllLimitLineLayer(limitLineView: LimitLineView) -> [LimitLineLayer]
    public static func getAllLimitLineLayer(chartViewBase: ChartViewBase) -> [LimitLineLayer]
    {
        var barArray:[LimitLineLayer] = []
        
        if let layers = chartViewBase.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: LimitLineLayer.self)
                {
                    barArray.append((caLayer as! LimitLineLayer))
                }
            }
        }
        Log.debug("Limit Layer count \(barArray.count)")
        return barArray
    }
    
    //    open static func removeAllLimitLineLayer(limitLineView: LimitLineView)
    public static func removeAllLimitLineLayer(chartViewBase: ChartViewBase)
    {
        
        if let layers = chartViewBase.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: LimitLineLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }
    
    
    //    open static func getLimitLineLayerInPoint(limitLineView: LimitLineView, loc: CGPoint) -> LimitLineLayer?
    public static func getLimitLineLayerInPoint(chartViewBase: ChartViewBase, loc: CGPoint) -> LimitLineLayer?
    {
        for layer in getAllLimitLineLayer(chartViewBase: chartViewBase)
        {
            // if (layer.path?.contains(loc))!
            guard (layer.path != nil)
            else { continue }
            if (layer.path?.boundingBox.contains(loc))!
            {
                return (layer)
            }
        }
        return nil
    }
    
    public static func getAxisIndex(chart:ChartViewBase, limitLineLayer:LimitLineLayer) -> Int? {
        
        let chartLimitLine = (limitLineLayer.charLimitLine)!
        
        for axis in chart.yAxisArray {
            for limitLine in axis.limitLines where limitLine == chartLimitLine {
                return axis.axisIndex
            }
        }
        return nil
    }
    
}
