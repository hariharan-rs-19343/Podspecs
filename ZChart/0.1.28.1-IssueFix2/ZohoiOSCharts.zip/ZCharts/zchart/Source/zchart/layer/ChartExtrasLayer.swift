//
//  ChartExtrasLayer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 09/08/22.
//

import Foundation

public class ChartExtrasLayer: CAShapeLayer {
    
    open var chartEntry:ChartDataEntry? = nil
    
    init(chartEntry: ChartDataEntry) {
        super.init()
        self.chartEntry = chartEntry
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
