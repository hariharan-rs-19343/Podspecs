//
//  FunnelLayer.swift
//  zchart
//
//  Created by Aravinth T on 04/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

import Foundation

open class FunnelLayer : ChartEntryLayer {
    
    open var funnelSlicePoint:FunnelSlicePoint? = nil
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, funnelSlicePoint: FunnelSlicePoint) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.funnelSlicePoint = funnelSlicePoint
        self.drawEntryLayer()
        self.drawGradientLayer()
        callHighlightDelegate(dataset: nil)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    override open func drawEntryLayer()
    {
        guard let plotOption = chartView?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions,
              (funnelSlicePoint?.points) != nil
            else { return }
        
        let path = FunnelLayer.getBezeirPath(cgPoints: (funnelSlicePoint?.points)!)
        
        self.path = path//.cgPath
        
        if plotOption.strokeColor != nil {
            self.strokeColor = (plotOption.strokeColor)!.cgColor
            self.lineWidth = plotOption.strokeWidth
        }
        
        let entryIndex = getEntryIndex()
        
        let fillColor = getFunnelDataSet().color(atIndex: entryIndex)
        
        self.fillColor = fillColor.cgColor
        
        getFunnelChart().nsuiLayer?.addSublayer(self)
        
        if (getFunnelChart().customAnimationInProgress) {
            self.opacity = 0.0
        }
        
    }
    
    func drawGradientLayer() {
        
        let gradients = getFunnelDataSet().gradients
        
        if gradients.count == 0 {
            return
        }
        
        guard (funnelSlicePoint?.points) != nil
            else { return }
        let path = FunnelLayer.getBezeirPath(cgPoints: (funnelSlicePoint?.points)!)//.cgPath
        
        self.fillColor = NSUIColor.clear.cgColor
        
        let entryIndex = getEntryIndex()
        
        let baseGradient = getFunnelDataSet().gradient(atIndex: entryIndex)
        
        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: path, gradient: baseGradient, drawMaskEnabled: true)
        
        if baseGradientLayer != nil {
            Log.info("Gradient layer created for entry " + String(describing: getFunnelChartEntry()))
        }
        
    }
    
    public static func getBezeirPath(cgPoints:[CGPoint]) -> CGMutablePath {
        
        var index = 0
        
        let path = CGMutablePath()
        
        for point in cgPoints {
            
            if index == 0 {
                path.move(to: point)
            } else {
                path.addLine(to: point)
            }
            index = index + 1
        }
        
        path.closeSubpath()
        
        return path
    }
    
    open func getEntryIndex() -> Int {
        let dataSet = getFunnelDataSet()
        return dataSet.entryIndex(entry: getFunnelChartEntry())
    }
    
    open func getFunnelDataSet() -> IChartDataSet {
        return (getFunnelChart().data?.dataSets[0])!
    }
    
    open func getFunnelChart() -> ChartViewBase
    {
        return self.chartView!
    }
    
    open func getFunnelChartEntry() -> ChartDataEntry
    {
        return (self.chartEntry!)
    }
    
    public static func removeAllFunnelLayer(chart: ChartViewBase)
    {
        let newChart = (chart)
        
        if let layers = newChart.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: FunnelLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }
    
    public static func removeAllFunnelValueLayer(chart: ChartViewBase)
    {
        let newChart = chart
        
        if let layers = newChart.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    caLayer.removeFromSuperlayer()
                }
            }
            
        }
    }
    
    public static func getAllFunnelLayer(chart: ChartViewBase) -> [FunnelLayer]
    {
        var funnelArray:[FunnelLayer] = []
        
        let newChart = chart
        
        if let layers = newChart.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: FunnelLayer.self)
                {
                    funnelArray.append((caLayer as! FunnelLayer))
                }
            }
        }
        
        return funnelArray
    }
    
    public static func getAllFunnelValueLayer(chart: ChartViewBase) -> [CATextLayer]
    {
        
        var barArray:[CATextLayer] = []
        
        let newChart = chart
        
        if let layers = newChart.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CATextLayer.self)
                {
                    barArray.append((caLayer as! CATextLayer))
                }
            }
            
        }
        
        return barArray
    }
    
    
    public static func getFunnelLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> FunnelLayer?
    {
        for layer in getAllFunnelLayer(chart: chart)
        {
            guard (layer.path != nil)
            else { continue }
            if (layer.path?.contains(loc))!
            {
                return (layer)
            }
            
        }
        return nil
    }
    
    public static func getFunnelLayerForEntry(chart: ChartViewBase, entry:ChartDataEntry) -> FunnelLayer?
    {
        for layer in getAllFunnelLayer(chart: chart)
        {
            if (layer.getFunnelChartEntry() == entry)
            {
                return (layer)
            }
        }
        return nil
    }
    
    public static func getFunnelLayerForEntryIndex(chart: ChartViewBase, entryIndex:Int) -> FunnelLayer?
    {
        for layer in getAllFunnelLayer(chart: chart)
        {
            if (layer.getEntryIndex() == entryIndex)
            {
                return (layer)
            }
        }
        return nil
    }
    
    public static func createFunnelLayerForEntry(chart: ChartViewBase, entry: ChartDataEntry, funnelSlicePoint:FunnelSlicePoint) -> FunnelLayer? {
        
        var funnelLayer = getFunnelLayerForEntry(chart: chart, entry: entry)
        
        if funnelLayer == nil {
              funnelLayer = FunnelLayer(chartView: chart, chartEntry: entry, funnelSlicePoint: funnelSlicePoint)
        }
        
        return funnelLayer
    }
    
    public static func getFunnelValueLayerMap(chart: ChartViewBase) -> [Int:CATextLayer]
    {
        var entryIndexToTextLayerMap:[Int:CATextLayer] = [:]
        
        for layer in getAllFunnelValueLayer(chart: chart)
        {
            let indexObjext = layer.value(forKey: FunnelChartRenderer.textLayerKey)
            
            if indexObjext != nil {
                
                entryIndexToTextLayerMap[(indexObjext as! Int)] = layer
            }
        }
        return entryIndexToTextLayerMap
    }
    
    public static func getFunnelValueLayerForIndex(chart: ChartViewBase, index:Int) -> CATextLayer?
    {
        for layer in getAllFunnelValueLayer(chart: chart)
        {
            let indexObjext = layer.value(forKey: FunnelChartRenderer.textLayerKey)
            
            if indexObjext != nil && ((indexObjext as! Int) == index){
                
                return layer
            }
        }
        return nil
    }
    /*
    override func highlightLayer( isHighlighted: Bool, plotType: ChartType? = nil) {
        
        if !isHighlighted {
            let fillColor = NSUIColor(cgColor: self.fillColor ?? NSUIColor.gray.cgColor)
            #if !os(OSX)
                self.fillColor = fillColor.withAlphaComponent(0.5).cgColor
            #endif
            #if os(OSX)
                self.fillColor = fillColor?.withAlphaComponent(0.5).cgColor
            #endif
        }
    }*/
}
