//
//  BubbleLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 30/03/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class BubbleLayer: ChartEntryLayer
{
    open var bubbleDataSet:IChartDataSet? = nil
    
    open var shapePoint: CGPoint? = nil
    
    open var bubbleEntry:ChartDataEntry? = nil
    
    open var shapeSize:CGSize = CGSize()
    
    open var bubbleShapeProperty:ShapeProperties? = nil
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, point:CGPoint, shapeSize:CGSize) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.bubbleDataSet = dataSet
        self.shapePoint = point
        self.bubbleEntry = chartEntry
        self.shapeSize = shapeSize
        self.drawEntryLayer()
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
        self.drawGradientLayer()
        callHighlightDelegate(dataset: dataSet)
    }
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, point:CGPoint, shapeProperty:ShapeProperties) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        self.bubbleDataSet = dataSet
        self.shapePoint = point
        self.bubbleEntry = chartEntry
        self.bubbleShapeProperty = shapeProperty
        self.drawEntryLayerWithShapeProperties()
        if chartView.customAnimationInProgress
        {
            self.opacity = 0
        }
        self.drawGradientLayer()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    
    
    override public func drawEntryLayer()
    {
        guard let dataSetOptions = bubbleDataSet?.dataSetOptions as? AxisChartDataSetOptions
            else {  return }
        
        let shapeProperties = dataSetOptions.shapeProperties
        
        let isSingleColor = bubbleDataSet?.colors.count == 1
        
        var color = bubbleDataSet?.color(atIndex: 0).cgColor
        
        if  !isSingleColor
        {
            guard let entryIndex = bubbleDataSet?.entryIndex(entry: bubbleEntry!)
            else { return }
            color = bubbleDataSet?.color(atIndex: entryIndex).cgColor
        }
        
        let _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProperties, point: shapePoint!, strokeColor: color ?? NSUIColor.clear.cgColor, currentLayer: self)
        
        getBubbleChart().plotView?.nsuiLayer?.addSublayer(self)
    }
    
    public func drawEntryLayerWithShapeProperties()
    {
           guard let shapeProperties = bubbleShapeProperty,
                 (shapeProperties.strokeColor != nil)
               else {  return }
           
           let _ = CommonHelperFunctions.drawShapeLayer(shapeProperties: shapeProperties, point: shapePoint!, strokeColor: shapeProperties.strokeColor!.cgColor, currentLayer: self)
           
           getBubbleChart().plotView?.nsuiLayer?.addSublayer(self)
    }
    
    
    func drawGradientLayer() {
        
        let gradients = bubbleDataSet?.gradients
        
        if gradients == nil || gradients!.count == 0 {
            return
        }
        
        guard let path = self.path
        else { return }
        
        self.fillColor = NSUIColor.clear.cgColor
        
        guard let entryIndex = bubbleDataSet?.entryIndex(entry: chartEntry!)
        else { return }
        
        let baseGradient = bubbleDataSet!.gradient(atIndex: entryIndex)
        
        let baseGradientLayer = GradientLayerRenderer.updateGradientLayer(container: self, gradientPath: path, gradient: baseGradient, drawMaskEnabled: true)
        
        if baseGradientLayer != nil {
            Log.info("Gradient layer created for entry " + String(describing: self.chartEntry))
        }
        
    }
    
    
    open func getBubbleChart() -> ChartViewBase
    {
        return (self.chartView!)
    }
    
    public static func getAllBubbleLayer(chart: ChartViewBase) -> [BubbleLayer]
    {
        var bubbleArray:[BubbleLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [BubbleLayer] {
            bubbleArray = layers
        }
        
        return bubbleArray
    }
    
    public static func getBubbleLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> BubbleLayer?
    {
        if entry.y.isNaN || entry.x.isNaN //|| entry.size.isNaN
        {
            return nil
        }
        
        for layer in BubbleLayer.getAllBubbleLayer(chart: chart)
        {
            if layer.chartEntry === entry
            {
                return layer
            }
        }
        return nil
    }
    
    
    public static func getAllBubbleValueLayer(chart: ChartViewBase) -> [CALayer]
    {
        let newChart = chart.plotView
        
        var valueLayers:[CALayer] = []
        
        if let layers = newChart?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: ValueTextLayer.self)
                {
                    if let subLayers = caLayer.sublayers
                    {
                        for sublayer in subLayers
                        {
                            valueLayers.append(sublayer)
                        }
                    }
                }
            }
            
        }
        
        return valueLayers
    }
    
    public static func getBubbleEntryLayer(chart: ChartViewBase, loc: CGPoint) -> BubbleLayer?
    {
        let high = chart.getHighlightByTouchPoint(loc)
        
        var entry:ChartDataEntry? = nil
        
        if high != nil
        {
            entry = chart.entryForHighlight(high!)
            
            if entry != nil
            {
                return getBubbleLayerForEntry(chart: chart, entry: entry!)
            }
        }
        
        return nil
    }

    
    //    open static func getBarLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> BarLayer?
    //    {
    //        for layer in getAllBarLayer(chart: chart)
    //        {
    //
    //            if chart.isKind(of: HorizontalBarChartView.self)
    //            {
    //                if ((layer.barRect?.minY)! <= loc.y) && (loc.y <= (layer.barRect?.maxY)!)
    //                {
    //                    return layer
    //                }
    //            }
    //            else{
    //                if ((layer.barRect?.minX)! <= loc.x) && (loc.x <= (layer.barRect?.maxX)!)
    //                {
    //                    return layer
    //                }
    //            }
    //
    //        }
    //        return nil
    //    }
    
    
    
    
}
