//
//  MedianLayer.swift
//  zchart
//
//  Created by keerthi-pt4274 on 05/08/22.
//

import Foundation

public class MedianLayer: ChartExtrasLayer {
    
    func plotConfiguration(boxPlotPlotOption: BoxPlotPlotOptions) {
        
        self.strokeColor = boxPlotPlotOption.medianColor.cgColor
        
        self.lineWidth = boxPlotPlotOption.medianStrokeWidth
        
    }
    
    static func getMedianLayerForEntry(chart: ChartViewBase, entry: ChartDataEntry) -> MedianLayer? {
        
        if let layers = chart.plotView?.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                if (layer as? MedianLayer)?.chartEntry == entry
                {
                    return layer as? MedianLayer
                }
            }
        }
        
        return nil
    }
    
    func opacity(opacityValue: Float) {
        self.opacity = opacityValue
    }
}
