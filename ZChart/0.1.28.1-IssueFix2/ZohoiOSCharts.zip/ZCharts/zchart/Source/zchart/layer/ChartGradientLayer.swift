//
//  ChartGradientLayer.swift
//  zchart
//
//  Created by Aravinth T on 08/10/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public class BaseGradientLayer : CAGradientLayer {
    
    public var gradient:BaseGradient? = nil
    
    public var gradientPath:CGPath!
    
    public var drawMaskEnabled:Bool = false
    {
        didSet
        {
            self.drawMaskLayer()
        }
    }
    
    public override init(layer: Any) {
        super.init(layer: layer)
    }
    
    public init(gradient:BaseGradient, gradientPath:CGPath) {
        super.init()
        self.gradient = gradient
        self.gradientPath = gradientPath
        updateFrame(path: self.gradientPath!)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateFrame(path:CGPath){
        let bound = path.boundingBox
        self.frame = bound
    }
    
    func updateGradientProperties(gradient:BaseGradient){
        self.colors = getGradientCGColors(gradient: gradient)
        guard ( gradient.positions as? [NSNumber] != nil )
        else { return }
        self.locations = (gradient.positions! as [NSNumber])
    }
    
    fileprivate func getGradientCGColors(gradient:BaseGradient) -> [CGColor] {
        var cgColors:[CGColor] = []
        for color in gradient.colors {
            cgColors.append(color.cgColor)
        }
        return cgColors
    }
    
    /// To draw mask shape layer for a gradient
    /// Make sure to set the frame property before calling drawMaskLayer()
    public func drawMaskLayer() {
        
        if !self.drawMaskEnabled {
            self.mask = nil
            return
        }
        
        let maskLayer = CAShapeLayer()
        maskLayer.path = gradientPath
        maskLayer.position = CGPoint(x: -self.frame.origin.x, y: -self.frame.origin.y)
        self.mask = maskLayer
    }
    
    
}

public class LinearGradientLayer: BaseGradientLayer {
    
    public override init(layer: Any) {
        super.init(layer: layer)
    }
    
    override init(gradient: BaseGradient, gradientPath: CGPath) {
        super.init(gradient: gradient, gradientPath: gradientPath)
        updateGradientProperties(gradient: gradient)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func updateGradientProperties(gradient: BaseGradient) {
        super.updateGradientProperties(gradient: gradient)
        guard let linearGradient = getLinearGradient()
        else { return }
        self.startPoint = (linearGradient.start)
        self.endPoint = (linearGradient.end)
    }
    
    public func getLinearGradient() -> LinearGradient? {
    
        var linearGradient:LinearGradient? = nil
        if self.gradient != nil && (self.gradient?.isKind(of: LinearGradient.self))! {
            linearGradient = self.gradient as? LinearGradient
        }
        return linearGradient
    }
    
}

public class RadialGradientLayer : BaseGradientLayer {
    
    public required override init(layer: Any) {
        super.init(layer: layer)
        needsDisplayOnBoundsChange = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(gradient: BaseGradient, gradientPath: CGPath) {
        super.init(gradient: gradient, gradientPath: gradientPath)
        updateGradientProperties(gradient: gradient)
    }
    
    override func updateGradientProperties(gradient: BaseGradient) {
        super.updateGradientProperties(gradient: gradient)
        guard let radialGradient = getRadialGradient()
        else { return }
        self.radius = (radialGradient.startRadius)
        self.radius = (radialGradient.endRadius)
        self.center = (radialGradient.startCenter)
        self.center = (radialGradient.endCenter)
    }
    
    public func getRadialGradient() -> RadialGradient? {
        
        var radialGradient:RadialGradient? = nil
        if self.gradient != nil && (self.gradient?.isKind(of: RadialGradient.self))! {
            radialGradient = self.gradient as? RadialGradient
        }
        return radialGradient
    }
    
    var _center:CGPoint? = nil
    
    public var center:CGPoint {
        set {
            _center = newValue
        }
        get {
            return _center!
        }
    }
    
    var _radius:CGFloat = 0.0
    
    public var radius:CGFloat {
        set {
            _radius = newValue
        }
        get {
            return _radius
        }
    }
    
    public var radiusPercent:CGFloat = 0.0
    
    override public func draw(in ctx: CGContext) {
        ctx.saveGState()
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        
        guard (gradient != nil)
        else { return }
        
        let cgGradient = CGGradient(colorsSpace: colorSpace, colors: getGradientCGColors(gradient: gradient!) as CFArray, locations: locations as! [CGFloat])
        
        let startRadius = (radiusPercent) * radius
        
        ctx.drawRadialGradient(cgGradient!, startCenter: center, startRadius: startRadius, endCenter: center, endRadius: radius, options: (gradient?.options)!)
        ctx.restoreGState()
    }
    
}
