//
//  WordCloudTextLayer.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 04/08/21.
//  Copyright © 2021 zoho. All rights reserved.
//

public class WordCloudTextLayer: ChartEntryLayer
{
    open var chartDataSet:IChartDataSet? = nil
    open var valueDict:[String:Any] = [:]
    
    init(chartView: ChartViewBase, chartEntry: ChartDataEntry, dataSet: IChartDataSet, valueDict: [String:Any]) {
        super.init(chartView: chartView, chartEntry: chartEntry)
        chartDataSet = dataSet
        self.valueDict = valueDict
        self.drawEntryLayer()
        callHighlightDelegate(dataset: dataSet)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(layer: Any) {
        super.init(layer: layer)
    }
    
    override public func drawEntryLayer()
    {
        guard (valueDict["x"] as? CGFloat) != nil,
              (valueDict["y"] as? CGFloat) != nil,
              (valueDict["fontSize"] as? CGFloat) != nil,
              (valueDict["text"] as? String) != nil,
              (valueDict["fontFamily"] as? String) != nil,
              (valueDict["rotation"] as? CGFloat) != nil
        else { return }
              
        let _ = self.drawText(x: valueDict["x"] as! CGFloat, y: (valueDict["y"] as! CGFloat), size: valueDict["fontSize"] as! CGFloat, text: valueDict["text"] as! String, fontFamily: (valueDict["fontFamily"] as! String), rotation: valueDict["rotation"] as! CGFloat)
        
        self.chartView!.plotView?.nsuiLayer?.addSublayer(self)
    }
    
    fileprivate func drawText(x:CGFloat,y:CGFloat,size:CGFloat,text:String,fontFamily:String, rotation:CGFloat)
    {
        guard let set = chartDataSet as? ChartBaseDataSet,
              (valueDict["entryIndex"] as? Int) != nil
        else { return }
        
        let valueText:String = text
        var valueFont = set.valueFont
        if #available(macOS 10.15, *) {
             valueFont = set.valueFont.withSize(size)
        } else {
            // Fallback on earlier versions
        } // UIFont(name: fontFamily, size: size)!
        var valueColor = set.color(atIndex: valueDict["entryIndex"] as! Int)
        if (chartView!.colorAxis.isEnabled)
        {
            valueColor = (chartView!.colorAxis.getColor(entry: chartEntry!) ?? NSUIColor.clear)
        }
        let valueAttributes = [NSAttributedString.Key.font: valueFont , NSAttributedString.Key.foregroundColor: valueColor]
        
        let size = text.size(withAttributes: valueAttributes)
        let valuePoint = CGPoint(x: x, y: y - (size.height / 2.0))
        
        let textLayer:CATextLayer = ChartUtils.drawTextLayer(
            text: valueText,
            point: valuePoint,
            align: .center,
            attributes: valueAttributes)
        
        textLayer.transform = CATransform3DMakeRotation(rotation, 0.0, 0.0, 1.0)
        
        if !(chartDataSet!.visible) || chartView!.customAnimationInProgress || (chartEntry!.filterEnabled)
        {
            textLayer.opacity = 0
        }
        
        self.addSublayer(textLayer)
    }
    
    public static func removeAllWordLayer(chart: ChartViewBase)
    {
        super.removeAllPlotLayer(chart: chart, kind: self)
    }
    
    public static func getAllWordLayer(chart: ChartViewBase) -> [WordCloudTextLayer]
    {
        var layerArray:[WordCloudTextLayer] = []
        
        if let layers = super.getAllPlotLayer(chart: chart, kind: self) as? [WordCloudTextLayer] {
            layerArray = layers
        }
        
        return layerArray
    }
    
    public static func getAllWordTextLayer(chart: ChartViewBase) -> [CALayer]
    {
        var layerArray:[CALayer] = []
        
        guard let plotView = (chart.plotView) else {
            return layerArray
        }
        
        if let layers = plotView.nsuiLayer?.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: WordCloudTextLayer.self)
                {
                    guard let textLayer = (caLayer as! WordCloudTextLayer).sublayers?[0] as? CATextLayer else {
                        continue
                    }
                    layerArray.append(textLayer)
                }
            }
            
        }
        return layerArray
    }
    
    public static func getAllSeriesWordTextLayers(chart: ChartViewBase, setIndex:Int) -> [CALayer]
    {
        var allLayers:[CALayer] = []
        
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            guard let textLayer = layer.sublayers?[0] as? CATextLayer,
                  (layer.valueDict["setIndex"] as? Int) != nil
            else {
                continue
            }
            
            let currentSetIndex = layer.valueDict["setIndex"] as! Int
            
            if currentSetIndex == setIndex
            {
                allLayers.append(textLayer)//   textLayer.opacity = 0
            }
        }
        return allLayers
    }
    
    public static func getWordLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> WordCloudTextLayer?
    {
        return super.getLayerForEntry(chart: chart, kind: self, entry: entry) as? WordCloudTextLayer
    }
    
    public static func getWordTextLayerForEntry(chart:ChartViewBase, entry:ChartDataEntry) -> CALayer?
    {
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            if layer.chartEntry === entry
            {
                guard let textLayer = layer.sublayers?[0] as? CATextLayer else {
                    continue
                }
                return textLayer
            }
        }
        return nil
    }
    
    public static func getWordLayerInPoint(chart: ChartViewBase, loc: CGPoint) -> WordCloudTextLayer?
    {
        var highlightedLayer:WordCloudTextLayer? = nil
        
        for layer in WordCloudTextLayer.getAllWordLayer(chart: chart)
        {
            guard let textLayer = layer.sublayers?[0] as? CATextLayer else {
                continue
            }
            
            if (textLayer.frame.contains(loc))
            {
                if highlightedLayer != nil
                {
                    guard let highlightTextLayer = highlightedLayer?.sublayers?[0] as? CATextLayer
                    else { continue }
                    
                    if textLayer.frame.width > (highlightTextLayer.frame.width)
                    {
                        continue
                    }
                }
                
                highlightedLayer = layer
            }
        }
        
        return highlightedLayer
    }
    /*
    override func highlightLayer( isHighlighted: Bool, plotType: ChartType? = nil) {
        
        if !isHighlighted {
            (self.sublayers?.first as? CATextLayer)?.foregroundColor = NSUIColor.lightGray.withAlphaComponent(0.4).cgColor
        }
    }
    */
}
