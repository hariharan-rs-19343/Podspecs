//
//  PanEventListener.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 19/09/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class PanEventListener: NSUIPanGestureRecognizer {
    
    open var handler:EventHandler? = nil 
    
}
