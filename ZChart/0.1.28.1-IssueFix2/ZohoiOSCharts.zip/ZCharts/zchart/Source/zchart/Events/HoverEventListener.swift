//
//  HoverEventListener.swift
//  Pods
//
//  Created by Keerthivass B S on 11/12/24.
//

#if !os(OSX)
    import UIKit
#endif

#if os(iOS)
@available(iOS 13.0, *)
open class HoverEventListener: NSUIHoverGestureRecognizer {
    
    open var handler:EventHandler? = nil
}
#endif
