//
//  TapEventListener.swift
//  zchart
//
//  Created by Aravinth T on 08/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class TapEventListener: NSUITapGestureRecognizer {
    
     open var handler:EventHandler? = nil 
    
}
