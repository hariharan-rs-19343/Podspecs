//
//  LongPressEventListener.swift
//  zchart
//
//  Created by Aravinth T on 10/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

#if os(iOS)
open class LongPressEventListener: NSUILongPressGestureRecognizer {

    open var handler:EventHandler? = nil 
    
}
#endif
