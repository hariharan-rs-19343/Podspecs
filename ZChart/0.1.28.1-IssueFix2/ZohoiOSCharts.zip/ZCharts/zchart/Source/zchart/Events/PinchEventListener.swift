//
//  PinchEventListener.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 08/03/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class PinchEventListener: NSUIPinchGestureRecognizer {
    
    open var handler:EventHandler? = nil
    
}
