//
//  DrillFilterMenuEntry.swift
//  zchart
//
//  Created by Aravinth T on 03/10/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class DrillFilterMenuEntry: NSObject {

    var chartDataEntry:[ChartDataEntry] = []
    
    var dataLevel:Int? = nil
    
    var dataSetIndex:Int? = nil
    
    weak var chartData:ChartData? = nil
    
    var menuType:DrillFilterMenuType? = nil

}
