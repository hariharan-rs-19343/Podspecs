//
//  CommonUtilities.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 23/04/18.
//  Copyright © 2018 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class CommonUtilities
{
    public static func customAnimation(chart:ChartViewBase,duration:TimeInterval,animationBlock:@escaping (()->Void))
    {
        
        chart.customAnimationInProgress = true
        
        if let plotOption = CommonHelperFunctions.getPlotOption(chart: chart, types: [.Bar]) as? BarPlotOptions {
            if plotOption.stackedSumEnabled{
                plotOption.isStackedSumEnabled = false
            }
        }
        
//        chart.setNeedsDisplay()
        
        let tempAnimator = Animator()
        
        
        tempAnimator.updateBlock = { [unowned chart] in
            
            chart.customAnimationInProgress = true
            
        }
        
        tempAnimator.stopBlock = { [unowned chart] in
            
            animationBlock()
            
            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(duration*1000)), execute: {  [weak chart] in
                
                if let chartView = chart {
                    
                    if let plotOption = CommonHelperFunctions.getPlotOption(chart: chartView, types: [.Bar]) as? BarPlotOptions {
                        if plotOption.stackedSumEnabled{
                            plotOption.isStackedSumEnabled = true
                        }
                    }
                    
                    
                    chartView.customAnimationInProgress = false
                    chartView.setNeedsDisplay()
                }
            })
            
            
        }
        
        tempAnimator.animate(xAxisDuration: 0.1)
        
    }
}
