//
//  SeriesPattern.swift
//  Charts
//
//  Created by Mohammed Musthafa A K on 12/07/17.
//
//

import Foundation

var currentColor:CGColor = NSUIColor.blue.cgColor

public class SeriesPattern {
    // the bounds of the shape to draw
    let bounds = CGRect(x: 0, y: 0, width: 10, height: 10)
    
    var sliceColor:CGColor?
    
    
    func getLinePattern(context:CGContext,color:CGColor)  {
        
        //     let patternSize = 10
        //  let size = CGSize(width: patternSize, height: patternSize)
        
        //  UIGraphicsBeginImageContext(size)
        //    let context = UIGraphicsGetCurrentContext()
        
        
        context.saveGState()
        
        //    context!.setAllowsAntialiasing(false)
        
        
        let patternSpace = CGColorSpace(patternBaseSpace: nil)
        
        context.setFillColorSpace(patternSpace!)
        
        
        currentColor  = color
        
        let pattern = createPattern()
        var alpha:CGFloat = 1.0
        context.setFillPattern(pattern!, colorComponents: &alpha)
        
        //  context.fill(CGRect(x:0, y:0, width:size.width, height:size.height))
        
        
        //         context.restoreGState()
        
        //   let image = UIGraphicsGetImageFromCurrentImageContext()
        // UIGraphicsEndImageContext()
        //  return image!
    }
    
    
    
    
    
    func createPattern() -> CGPattern? {
        
        
        
        var callbacks = CGPatternCallbacks(version: 0, drawPattern: { info, ctx in
            
            // cast the opaque pointer back to a SomeShape reference.
            let shape = Unmanaged<SeriesPattern>.fromOpaque(info!).takeUnretainedValue()
            shape.sliceColor = currentColor
            
            ctx.setFillColor(shape.sliceColor!)
            ctx.fill(shape.bounds)
            
            
            // The code to draw a single tile of the pattern into "ctx"...
            // (in this case, two vertical strips)
            ctx.saveGState()
            
            ctx.setAlpha(0.4)
            
            // ctx.setLineWidth(2)
            
            ctx.move(to:  CGPoint(x:0,y:shape.bounds.height))
            
            ctx.addLine(to:  CGPoint(x:shape.bounds.width,y:0))
            
            ctx.setStrokeColor(NSUIColor.white.cgColor)
            
            ctx.strokePath()
            
            ctx.restoreGState()
            
        }, releaseInfo: { info in
            // when the CGPattern is freed, release the info reference,
            // consuming the +1 retain when we originally passed it to the CGPattern.
            Unmanaged<SeriesPattern>.fromOpaque(info!).release()
        })
        
        
        // retain self before passing it off to the info: parameter as an opaque pointer.
        let unsafeSelf = Unmanaged.passRetained(self).toOpaque()
        
        return CGPattern(info: unsafeSelf, bounds: bounds, matrix: .identity,
                         xStep: bounds.width, yStep: bounds.height,
                         tiling: .noDistortion, isColored: true, callbacks: &callbacks)
    }
}
