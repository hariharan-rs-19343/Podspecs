//
//  DefaultToolTipEntryGenerator.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class DefaultToolTipEntryGenerator : NSObject, IToolTipEntryGenerator
{
     public func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = NSUIColor.black
            
            toolTipEntry1.valueFont = NSUIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        if entry != nil
        {
            let pieEntry = entry
            
            
            
            let toolTipEntry = ToolTipEntry(label: (pieEntry!.xString ?? ""), value: String(pieEntry!.y))
            toolTipEntry.valueTextColor = (entry?.entryColor)!
            toolTipEntry.labelFont = NSUIFont.boldSystemFont(ofSize: 17)
            
            var labels:[String] = ["Sales","Avg. Cost","No. of Customers","Others","Label 5","Label 6","Label 7","Label 8"]
            
          
            
                      entries.append(toolTipEntry)
            
            for i in 0...7
            {
                let dummy = ToolTipEntry(label: labels[i], value: String((pieEntry!.y/2)+Double(i+5)))
                dummy.valueTextColor = (entry?.entryColor)!
                entries.append(dummy)
            }
//             entries.append(toolTipEntry)
//             entries.append(toolTipEntry)
//             entries.append(toolTipEntry)
//             entries.append(toolTipEntry)
//             entries.append(toolTipEntry)
//             entries.append(toolTipEntry)
//             entries.append(toolTipEntry)
        }
        
        
        
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)
//        entries.append(toolTipEntry)

        
        
        return entries
    }
}

