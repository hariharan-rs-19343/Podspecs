//
//  Components.swift
//  zchart
//
//  Created by Mohammed Musthafa A K on 09/08/17.
//  Copyright © 2017 zoho. All rights reserved.
//

import Foundation


extension CGFloat {
    public func radians() -> CGFloat {
        let b = CGFloat.pi * (self/180)
        return b
    }
}
#if os(iOS) || os(tvOS)
extension UIBezierPath {
    convenience init(circleSegmentCenter center:CGPoint, radius:CGFloat, startAngle:CGFloat, endAngle:CGFloat)
    {
        self.init()
        self.move(to: CGPoint(x:center.x,y:center.y))
        self.addArc(withCenter: center, radius:radius, startAngle:startAngle.radians(), endAngle: endAngle.radians(), clockwise:true)
        self.close()
    }
}
#endif
func getCGMutablePath(circleSegmentCenter center:CGPoint, radius:CGFloat, startAngle:CGFloat, endAngle:CGFloat) -> CGMutablePath
{
    let path = CGMutablePath()
    path.move(to: CGPoint(x:center.x,y:center.y))
    path.addArc(center: center, radius: radius, startAngle: startAngle.radians(), endAngle: endAngle.radians(), clockwise: false)
    path.closeSubpath()
    return path
}
open class Components
{
    weak fileprivate var chart:ChartViewBase?
    
    var arrowlayer:CAShapeLayer? = nil
    
    var innerLayer:CAShapeLayer? = nil
    
    var outerlayer:CAShapeLayer? = nil
    
    
    weak public var pieChart:ChartViewBase?
        {
        get{
            return chart
        }
        set(newValue)
        {
            let chart = newValue
            self.chart = chart
        }
    }
    
    init()
    {
        
    }
    
    init(chart: ChartViewBase)
    {
        
        let _chart = chart
        self.chart = _chart
    
    }
    
    // Remove previous layers
    func removeLayers(pie:ChartViewBase)
    {
        
        if arrowlayer != nil
        {
            arrowlayer?.removeFromSuperlayer()
        }
        if innerLayer != nil
        {
            innerLayer?.removeFromSuperlayer()
        }
        if outerlayer != nil
        {
           // outerlayer?.removeFromSuperlayer()
        }
    }
    
    func getOuterLayer() -> CAShapeLayer?
    {
        return outerlayer
    }
    
    func removeOuterLayer()
    {
        if outerlayer != nil
        {
            outerlayer?.removeFromSuperlayer()
            outerlayer = nil
        }
    }
    
    // Add Outer Circle
    func outerCircle()
    {
        guard let pieChart = chart,
            let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        if outerlayer == nil
        {
            let lineWidth = (piePlot.radius*(5.29/100))
            outerlayer = CAShapeLayer()
//            let newpath1 = UIBezierPath(arcCenter: piePlot.centerCircleBox, radius: piePlot.radius+(lineWidth/2), startAngle: CGFloat(0), endAngle:CGFloat(360), clockwise:true)
            let newpath1 = CGMutablePath()
            newpath1.addArc(center: piePlot.centerCircleBox, radius: piePlot.radius+(lineWidth/2), startAngle:  CGFloat(0), endAngle: CGFloat(360), clockwise: true)
            outerlayer?.path = newpath1//.cgPath
            outerlayer?.fillColor=NSUIColor.clear.cgColor
            outerlayer?.strokeColor = NSUIColor.gray.withAlphaComponent(0.4).cgColor
            outerlayer?.lineWidth = lineWidth
            outerlayer?.frame = pieChart.frame
           // outerlayer?.opacity=0.2
            pieChart.nsuiLayer?.addSublayer(outerlayer!)
        }
        
        
    }
    
    func outerCircleCanvas(context:CGContext)
    {
        guard let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        context.saveGState()
        let lineWidth = piePlot.outerCircleLineWidth ?? (piePlot.radius*(5.29/100))
//        let newpath1 = UIBezierPath(arcCenter: piePlot.centerCircleBox, radius: piePlot.radius+(lineWidth/2), startAngle: CGFloat(0), endAngle:CGFloat(360), clockwise:true)
        let newpath1 = CGMutablePath()
        newpath1.addArc(center: piePlot.centerCircleBox, radius: piePlot.radius+(lineWidth/2), startAngle:  CGFloat(0), endAngle: CGFloat(360), clockwise: true)
        let outerColor = piePlot.outerCircleColor
        outerColor.setStroke()
//        newpath1.lineWidth = lineWidth
//        newpath1.stroke()
        context.setLineWidth(lineWidth)
        context.beginPath()
        context.addPath(newpath1)
        context.restoreGState()
    }
    
    // Add Inner Circle
    func innerCircle()
    {
        guard let pieChart = chart,
            let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        innerLayer = CAShapeLayer()
//        let newpath = UIBezierPath(circleSegmentCenter: piePlot.centerCircleBox, radius: (35/100)*piePlot.radius, startAngle: CGFloat(0) ,endAngle: CGFloat(360))
        let newpath = getCGMutablePath(circleSegmentCenter: piePlot.centerCircleBox, radius: (35/100)*piePlot.radius, startAngle: CGFloat(0) ,endAngle: CGFloat(360))
        innerLayer?.path = newpath//.cgPath
        innerLayer?.fillColor = NSUIColor.white.cgColor
        innerLayer?.strokeColor = NSUIColor.white.cgColor
        innerLayer?.frame=pieChart.frame
        innerLayer?.opacity=0.7
        pieChart.nsuiLayer?.addSublayer(innerLayer!)
    }
    
    
    
    // Add Arrow
    func addArrow(centerpoint:CGPoint,startAngle:CGFloat,endAngle:CGFloat,radius:CGFloat)
    {
        guard let pieChart = chart
        else { return }
        
        arrowlayer = CAShapeLayer()
        let newpath = CGMutablePath() // UIBezierPath()
        newpath.move(to: centerpoint)
//        newpath.addArc(withCenter: centerpoint, radius:radius, startAngle:startAngle.radians(), endAngle: endAngle.radians(), clockwise:true)
//        newpath.close()
        newpath.addArc(center: centerpoint, radius: radius, startAngle: startAngle.radians(), endAngle: endAngle.radians(), clockwise: false)
        newpath.closeSubpath()
        arrowlayer?.path = newpath//.cgPath
        arrowlayer?.fillColor = NSUIColor.white.cgColor
        arrowlayer?.strokeColor = NSUIColor.white.cgColor
        arrowlayer?.frame = pieChart.frame
        arrowlayer?.opacity=0.7
        pieChart.nsuiLayer?.addSublayer(arrowlayer!)
    }
    
    
    
    // Arrow Top
    func arrowTop()
    {
        guard let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        let centerpoint = CGPoint(x: (piePlot.centerCircleBox.x), y: ((piePlot.centerCircleBox.y)-(piePlot.radius)+(piePlot.radius*(13.49/100))))
        let startAngle = CGFloat(240)
        let endAngle = CGFloat(300)
        addArrow(centerpoint: centerpoint,startAngle: startAngle,endAngle: endAngle, radius: (piePlot.radius*(21/100)))
    }
    
    
    // Arrow Left
    func arrowLeft()
    {
        guard let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        let centerpoint = CGPoint(x: ((piePlot.centerCircleBox.x)-(piePlot.radius)+(piePlot.radius*(13.49/100))), y: (piePlot.centerCircleBox.y))
        let startAngle = CGFloat(150)
        let endAngle = CGFloat(210)
        addArrow(centerpoint: centerpoint,startAngle: startAngle,endAngle: endAngle, radius: (piePlot.radius*(21/100)))
    }

    
    func addPieCompomnents(context:CGContext)
    {
        guard let pieChart = chart,
            let piePlot = chart?.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        removeLayers(pie: pieChart)
        
        if piePlot.outerCircleEnabled
        {
            outerCircleCanvas(context:context)
            
        }
        
        if piePlot.innerCircleEnabled
        {
            innerCircle()
            
        }
        
        if piePlot.arrowShow
        {
            if pieChart.isVertical
            {
                arrowTop()
            }
            else
            {
                arrowLeft()
            }
        }
    }
}
