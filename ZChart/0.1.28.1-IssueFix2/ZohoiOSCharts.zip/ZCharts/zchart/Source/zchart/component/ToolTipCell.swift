//
//  ToolTipCell.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

/*open class ToolTipCell: UIStackView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    let label = UILabel()
    
    let value = UILabel()
    
   public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    /*init() {
     super.init(frame: CGRect.zero)
     self.axis = .vertical
     self.distribution = .fillEqually
     self.alignment = .fill
     self.addViews()
     } */
    
    
    public init(toolTipEntry: ToolTipEntry,  toolTipType: ToolTipType) {
        super.init(frame: CGRect.zero)
        
        if toolTipType == .Centered
        {
            self.axis = .vertical
            self.distribution = .fillEqually
            self.alignment = .fill
            
            label.textAlignment = .center
            value.textAlignment = .center
        }
        else if toolTipType == .leftRight {
            
            self.axis = .horizontal
            self.distribution = .fillEqually
            self.alignment = .fill
            
            label.textAlignment = .left
            value.textAlignment = .right
        }
        
        self.addViews(toolTipEntry : toolTipEntry)
    }
    
    /*init() {
     super.init(frame: CGRect.zero)
     self.axis = .horizontal
     self.distribution = .fillEqually
     self.alignment = .fill
     self.addViews()
     }*/
    
    required public init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addViews(toolTipEntry: ToolTipEntry) {
        
        label.text = toolTipEntry.label
        label.textColor = toolTipEntry.labelTextColor
        label.font = toolTipEntry.labelFont
        
        value.text = toolTipEntry.value
        value.textColor = toolTipEntry.valueTextColor
        value.font = toolTipEntry.valueFont
        
        
        self.addArrangedSubview(label)
        self.addArrangedSubview(value)
    }
    
    func getLabelSize() -> CGSize {
        
        let size1 = (label.text! as NSString).size(attributes: [NSFontAttributeName: label.font])
        let size2 = (value.text! as NSString).size(attributes: [NSFontAttributeName: value.font])
        
        var width:CGFloat = size1.width
        if size2.width > width {
            width = size2.width
        }
        
        var height:CGFloat = size1.height * 2
        if size2.height > size1.height {
            height = size2.height * 2
        }
        
//        height = height + height * (2/3)
        
        return CGSize(width: width, height: height)
        
    }

}*/

#if os(iOS) || os(tvOS)
open class ToolTipItemCell:UICollectionViewCell
{
    let label = UILabel()
    
    let value = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
//        self.contentView.backgroundColor = NSUIColor.white
        self.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(value)
        value.translatesAutoresizingMaskIntoConstraints = false
        value.numberOfLines = 0
        label.numberOfLines = 0
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func constraintsUpdate(tooltip:ToolTipType)
    {
        
        if tooltip == .Centered
        {
            label.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
            label.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
            label.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
            label.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true


            value.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
            value.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
            value.topAnchor.constraint(equalTo: label.bottomAnchor).isActive = true
            value.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        }
        else{
            label.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
            label.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
            label.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
            label.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/2).isActive = true
            
            
            value.leadingAnchor.constraint(equalTo: label.trailingAnchor).isActive = true
            value.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
            value.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
            value.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/2).isActive = true
        }
        
    }
    
 
}
#endif

#if os(OSX)

class ZCNSView : NSView {
    override var isFlipped: Bool {
        return true
    }
}

class ToolTipItemCell: NSCollectionViewItem {
    
    var toolTipItemCellView:ToolTipItemCellView?
    
    weak var tooltipEntry:ToolTipEntry? = nil
    
    weak var chartToolTip:ChartTooltip? = nil
    
    override func loadView() {
      self.toolTipItemCellView = ToolTipItemCellView()
      self.view = self.toolTipItemCellView!
      self.view.wantsLayer = true
    self.toolTipItemCellView?.tooltipEntry = tooltipEntry
        self.toolTipItemCellView?.chartToolTip = chartToolTip
  }
}

class ToolTipItemCellView : ZCNSView
{
    weak var tooltipEntry:ToolTipEntry? = nil
    
    weak var chartToolTip:ChartTooltip? = nil
    
    var spacing = 0.0
    
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        self.wantsLayer = true
//        self.layer?.backgroundColor = NSColor.lightGray.cgColor
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.wantsLayer = true
    }
    
    
    override func layout() {
//        super.layout()
        
        guard let toolTipEntry = tooltipEntry, let toolTip = chartToolTip else {
            return
        }
        
        self.layer?.sublayers?.removeAll()
        let height = self.bounds.height
        let width = self.bounds.width
        let origin = self.frame.origin
        
        var labelFrame = NSRect(x: 0  , y: 0, width: width, height: height / 2.0)
        var valueFrame = NSRect(x: 0 , y:  height / 2.0 , width: width, height: height / 2.0)
        
        if (toolTip.toolTipType == .leftRight) {
//            labelFrame = NSRect(x: origin.x  , y: origin.y, width: width / 2.0, height: height)
//            valueFrame = NSRect(x: origin.x + width / 2.0  , y: origin.y , width: width / 2.0 , height: height)
            
            labelFrame = NSRect(x: 0.0  , y: 0.0, width: width / 2.0, height: height)
            valueFrame = NSRect(x: width / 2.0  , y: 0.0 , width: width / 2.0 , height: height)
        }
        
        
//        let labelFrame = NSRect(x: height  , y: 0, width: width - height, height: height)
        let labelLayer = CATextLayer()
        labelLayer.frame = labelFrame
        labelLayer.font = toolTipEntry.labelFont
        labelLayer.fontSize = toolTipEntry.labelFont.pointSize
        labelLayer.foregroundColor = toolTipEntry.labelTextColor.cgColor
        labelLayer.string = tooltipEntry?.label
        labelLayer.contentsScale = NSScreen.main!.backingScaleFactor
//        labelLayer.alignmentMode = CATextLayerAlignmentMode.justified
        self.layer?.addSublayer(labelLayer)
        
//        let valueFrame = NSRect(x: height  , y: 0, width: width - height, height: height)
        let valueLayer = CATextLayer()
        valueLayer.frame = valueFrame
        valueLayer.font = toolTipEntry.valueFont
        valueLayer.fontSize = toolTipEntry.valueFont.pointSize
        valueLayer.foregroundColor = toolTipEntry.valueTextColor.cgColor
        valueLayer.string = toolTipEntry.value
        valueLayer.contentsScale = NSScreen.main!.backingScaleFactor
            
        self.layer?.addSublayer(valueLayer)
        
    }
}



#endif
