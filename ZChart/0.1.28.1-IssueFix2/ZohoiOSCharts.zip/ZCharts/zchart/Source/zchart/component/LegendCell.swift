//
//  LegendCell.swift
//  ZCharts
//
//  Created by Aravinth T on 11/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

@objc
protocol LegendCellDelegate
{
    @objc optional func legendEnabled(entry: LegendEntry, indexPath: IndexPath)
    
    @objc optional func legendDisabled(entry: LegendEntry, indexPath: IndexPath)
    
#if !os(OSX)
    @objc optional func indexPathForCell(cell: UICollectionViewCell) -> IndexPath
#else
    @objc optional func indexPathForCell(cell: NSCollectionViewItem) -> IndexPath
#endif
}

#if os(iOS) || os(tvOS)
open class LegendCell: UICollectionViewCell {
    
    var formView:UIView!
    
    var labelView:UILabel!
    
    var shapeLayer:CAShapeLayer!
    
    var oldListeners:[UIGestureRecognizer] = []
    
    var textHeight: CGFloat?
    
    open var legendOrientation:LegendOrientation = .Horizontal
    /* {
     didSet
     {
     addGestureListener()
     }
     } */
    
    weak var entry:LegendEntry? = nil
    
    weak var legend:ChartLegendObject? = nil
    
    weak var delegate:LegendCellDelegate? = nil
    
    
    public override init(frame: CGRect) {
        
        super.init(frame: frame)
        
        let spacing = legend?.formLabelSpacing ?? 0.0
        
        var shapeSize = legend?.legendFormSize ?? 0.0
        
        shapeSize = min(shapeSize, self.frame.height)
        
        let textSize = textHeight ?? legend?.legendFont.pointSize ?? 0.0
        
        let heightHalf = self.frame.height / 2.0
        
        formView = UIView(frame: CGRect(x: 0.0, y: heightHalf - shapeSize / 2.0, width: shapeSize , height: shapeSize))
        
        shapeLayer = CAShapeLayer()
        shapeLayer.bounds = formView.bounds
        
        shapeLayer.position = formView.layer.position
        
        formView.layer.addSublayer(shapeLayer)
        
        labelView = UILabel(frame: CGRect(x: shapeSize + spacing , y: heightHalf - textSize / 2.0, width: self.frame.width - shapeSize - spacing , height: textSize))
        
        labelView.font = UIFont.systemFont(ofSize: 15)
        labelView.textAlignment = .left
        
        self.contentView.addSubview(formView)
        self.contentView.addSubview(labelView)
        
        
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func legendInit()
    {
        let spacing = legend?.formLabelSpacing ?? 0.0
        
        var shapeSize = legend?.legendFormSize ?? 0.0
        
        shapeSize = min(shapeSize, self.frame.height)
        
        let textSize = textHeight ?? legend?.legendFont.pointSize ?? 0.0
        
        let heightHalf = self.frame.height / 2.0
        
        formView.frame = CGRect(x: 0.0, y: heightHalf - shapeSize / 2.0, width: shapeSize , height: shapeSize)
        
        shapeLayer.bounds = formView.frame
        
        shapeLayer.position = formView.layer.position
        
        labelView.frame = CGRect(x: shapeSize + spacing , y: heightHalf - textSize / 2.0, width: self.frame.width - shapeSize - spacing , height: textSize)
        
    }
    
    /*  func addGestureListener()
     {
     /*for listener in self.oldListeners
     {
     self.removeGestureRecognizer(listener)
     }*/
     
     if self.oldListeners.count > 0
     {
     return
     }
     
     if self.legendOrientation == .Horizontal
     {
     let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeUp.direction = .up
     self.addGestureRecognizer(swipeUp)
     
     let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeDown.direction = .down
     self.addGestureRecognizer(swipeDown)
     
     oldListeners = [swipeUp, swipeDown]
     }
     else
     {
     let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeLeft.direction = .left
     self.addGestureRecognizer(swipeLeft)
     
     let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeRight.direction = .right
     self.addGestureRecognizer(swipeRight)
     
     oldListeners = [swipeLeft, swipeRight]
     
     }
     
     }
     
     func handleGesture(gesture: UISwipeGestureRecognizer)
     {
     if gesture.direction == UISwipeGestureRecognizerDirection.right {
     disableCell()
     }
     else if gesture.direction == UISwipeGestureRecognizerDirection.left {
     enableCell()
     }
     else if gesture.direction == UISwipeGestureRecognizerDirection.up {
     disableCell()
     }
     else if gesture.direction == UISwipeGestureRecognizerDirection.down {
     enableCell()
     }
     }
     */
    
    func disableCell()
    {
        
        if self.entry == nil {
            return
        }
        
        if !(self.entry?.enabled)!
        {
            return
        }
        
       // self.alpha = 0.1
        
        self.labelView.alpha = 0.1
        self.formView.alpha = 0.1
        
        self.entry?.enabled = false
        
        self.delegate?.legendDisabled!(entry: entry!, indexPath: (self.delegate?.indexPathForCell!(cell: self))!)
        
        /* UIView.animate(withDuration: 1, delay: 0.5, options: UIViewAnimationOptions.transitionCurlUp, animations: {
         self.alpha = 0.5
         self.shapeLayer.fillColor = NSUIColor.lightGray.cgColor
         self.labelView.textColor = NSUIColor.lightGray
         }, completion: nil) */
        
    }
    
    func enableCell()
    {
        if self.entry == nil {
            return
        }
        
        if (self.entry?.enabled)!
        {
            return
        }
        
       // self.alpha = 1.0
        
        self.entry?.enabled = true
        
        self.labelView.alpha = 1.0
        self.formView.alpha = 1.0
        
        self.shapeLayer.fillColor = self.entry?.formColor?.cgColor
//        self.labelView.textColor = NSUIColor.black
        
        /*
         UIView.animate(withDuration: 2, delay: 0.5, options: UIViewAnimationOptions.curveEaseOut, animations: {
         self.alpha = 1.0
         self.shapeLayer.fillColor = (self.entry?.formColor?.cgColor)!
         self.labelView.textColor = NSUIColor.black
         }, completion: nil) */
        
        self.delegate?.legendEnabled!(entry: entry!, indexPath: (self.delegate?.indexPathForCell!(cell: self))!)
        
    }
    
    override open func layoutSubviews() {
        legendInit()

    }
    
    
}
#endif

#if os(OSX)

class LegendCell: NSCollectionViewItem {
    
    var legendCellView:LegendCellView?
    
    weak var legend:ChartLegendObject? = nil
    
    override func loadView() {
      self.legendCellView = LegendCellView()
      self.view = self.legendCellView!
      self.view.wantsLayer = true
    self.legendCellView?.legend = legend
  }
}

class LegendCellView : ZCNSView
{
    weak var legend:ChartLegendObject? = nil
    var legendEntry : LegendEntry? = nil
    var spacing = 0.0
    
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        self.wantsLayer = true
//        self.layer?.backgroundColor = NSColor.lightGray.cgColor
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.wantsLayer = true
    }
    
    
    override func layout() {
//        super.layout()
        
        self.layer?.sublayers?.removeAll()
        let height = self.bounds.height
        let width = self.bounds.width
        let origin = self.frame.origin
        
        let rect = NSRect(x: height / 4.0 , y: height/4.0, width: height/2.0, height: height/2.0)
        print("Rect " , rect)
        let path = CGMutablePath(ellipseIn: rect, transform: nil)
        let font = self.legend?.legendFont // NSFont.systemFont(ofSize: 10)
        let layer = CAShapeLayer()
        layer.path = path
        layer.borderWidth = 2.0
        layer.fillColor = legendEntry?.colors![0].cgColor ??   NSColor.red.withAlphaComponent(0.5).cgColor
        
        layer.opacity = legendEntry!.enabled ? 1 : 0.1
        
        self.layer?.addSublayer(layer)
        
        let textFrame = NSRect(x: height  , y: 0, width: width - height, height: height)
        let textLayer = CATextLayer()
        textLayer.frame = textFrame
        textLayer.font = font
        textLayer.fontSize = font!.pointSize
        textLayer.foregroundColor = NSColor.black.cgColor
        textLayer.string = legendEntry?.label
        textLayer.contentsScale = NSScreen.main!.backingScaleFactor
        
        textLayer.opacity = legendEntry!.enabled ? 1 : 0.1
        
//        let layer = CATextLayer()
//        layer.string = text
//
//        layer.frame = frame
//
//        layer.alignmentMode = convertToCATextLayerAlignmentMode("center")
//        layer.fontSize = font.pointSize
//        layer.font = font
//        layer.foregroundColor = color.cgColor
//        layer.contentsScale = UIScreen.main.scale
//        layer.truncationMode = .end
        
        self.layer?.addSublayer(textLayer)
        
        
    }
}



#endif
