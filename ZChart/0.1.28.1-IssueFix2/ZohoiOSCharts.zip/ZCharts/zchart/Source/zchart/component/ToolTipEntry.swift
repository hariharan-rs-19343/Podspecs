//
//  ToolTipEntry.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

open class ToolTipEntry: NSObject {

    internal var _label:String!
    
    internal var _value:String!
    
    open var labelAttributedString:NSMutableAttributedString? = nil
    
    open var valueAttributedString:NSMutableAttributedString? = nil
    
    
    open var label:String {
        set
        {
            _label = newValue
        }
        get
        {
            return _label
        }
    }
    
    open var value:String {
        set
        {
            _value = newValue
        }
        get
        {
            return _toolTipValueFormatter.stringForValue(value: self._value)
        }
        
    }
    
   public init(label: String, value: String) {
        super.init()
        self.label = label
        self.value = value
    }
    
    open var valueTextColor:NSUIColor = NSUIColor.blue
    
    open var valueFont:NSUIFont = NSUIFont.boldSystemFont(ofSize: 18)
    
    open  var labelTextColor:NSUIColor = NSUIColor.black
    
    open  var labelFont:NSUIFont = NSUIFont.systemFont(ofSize: 15)
    
    open var labelTextAlignment:NSTextAlignment = NSTextAlignment.center
    
    open var valueTextAlignment:NSTextAlignment = NSTextAlignment.center
    
    fileprivate let defaultToolTipValueFormatter = DefaultToolTipValueFormatter()
    
    internal var _toolTipValueFormatter:IToolTipValueFormatter  {
        
        get {
            if toolTipValueFormatter == nil {
                return defaultToolTipValueFormatter
            }
            else {
                return toolTipValueFormatter!
            }
        }
        set {
            toolTipValueFormatter = newValue
        }
    }
    
    weak open var toolTipValueFormatter:IToolTipValueFormatter?
    
    
}
