//
//  DrillFilterMenuDataSource.swift
//  zchart
//
//  Created by Aravinth T on 03/10/17.
//  Copyright © 2017 zoho. All rights reserved.
//

#if !os(OSX)
    import UIKit
#endif

public protocol DrillFilterMenuDataSource: NSObjectProtocol {
    
    func prepareDrillFilterMenuEntries() -> [DrillFilterMenuEntry]
    
}

