//
//  CenterText.swift
//  Charts
//
//  Created by Mohammed Musthafa A K on 21/07/17.
//
//

import Foundation
//TODO FOR OSX
#if os(iOS)
open class CenterText
{
    var plabel: UILabel?
 
    
    //******************Constructors**************
    init()
    {
        
    }
    
    
    func addCenterLabel(chart:ChartViewBase)
    {
        
      let pieChart = chart
        guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        if piePlot.centerLabelEnabled
        {
                addLabel(chart:chart)
        
                for set in pieChart.data!.dataSets
                {
                    if set.isVisible && set.entryCount > 0
                    {
                        let entryCount = set.entryCount
                        
                        let dataSet = pieChart.data?.dataSets[0]
                        
                        
                        for j in 0 ..< entryCount
                        {
                            if  pieChart.needsHighlight(index: j)
                            {
                                
                                let chartEntry = dataSet?.entryForIndex(j)
                                
                                plabel?.text = piePlot.centerTextFormatter.stringForValue(highlightedEntry: chartEntry!, chart: chart)

                            }
        
                        }
                    }
                }
            }

    }
    
    // Add Label
    func addLabel(chart:ChartViewBase)
    {
            guard let piePlot = chart.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
            if plabel != nil
            {
                plabel?.removeFromSuperview()
            }
            
            let pieChart = chart
            let wradius = ((50/100)*piePlot.radius)
            let hradius = ((35/100)*piePlot.radius)
            plabel = UILabel(frame: CGRect(x: 0, y: 0, width: wradius, height: hradius))
            plabel?.text=" "
          // plabel?.adjustsFontSizeToFitWidth =  true
            let size = (piePlot.radius*(11.76/100))
            plabel?.font = plabel?.font.withSize(size)
            plabel?.center = (piePlot.centerCircleBox)
            plabel?.textAlignment = NSTextAlignment.center
            pieChart.addSubview(plabel!)
        }
}
#endif
