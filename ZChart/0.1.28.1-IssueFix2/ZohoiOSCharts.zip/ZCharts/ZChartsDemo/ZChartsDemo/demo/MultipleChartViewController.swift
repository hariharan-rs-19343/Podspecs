//
//  MultipleChartViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 15/12/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class MultipleChartViewController: UIViewController,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource {

    let uiCollectionViewLayout = UICollectionViewFlowLayout()
    
    var uiCollectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        uiCollectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: uiCollectionViewLayout)
        
        self.view.addSubview(uiCollectionView)
        
        uiCollectionView.translatesAutoresizingMaskIntoConstraints = false
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":uiCollectionView])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":uiCollectionView])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        uiCollectionView.dataSource = self
        uiCollectionView.delegate = self
        uiCollectionView.backgroundColor = UIColor.clear
        uiCollectionView.register(PieCVCell.self, forCellWithReuseIdentifier: "PieCVCell")
        uiCollectionView.register(BarCVCell.self, forCellWithReuseIdentifier: "BarCVCell")
        uiCollectionView.register(LineCVCell.self, forCellWithReuseIdentifier: "LineCVCell")
        
        uiCollectionViewLayout.scrollDirection = .vertical
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
      
        
         let count:Int = 0
       
//        if indexPath.item % 2 != 0
//        {
//            count = 3
//        }
        
        
        if indexPath.item % 3 == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PieCVCell", for: indexPath) as! PieCVCell
            
            cell.layer.shouldRasterize = false
            cell.layer.rasterizationScale = UIScreen.main.scale
            
            let pieChart = cell.chartContainer.chartView.chart as! PieChartView
            
            DispatchQueue.global(qos: .userInitiated).async {
                
                let pieData = PieCVCell.getNewPieData(count: count, index: indexPath.item)
                
                DispatchQueue.main.async {
                    
                    cell.chartContainer.titleView.mainTitle.text = "Item " + String(indexPath.item)
                    
                    pieChart.data = pieData
                    
                    pieChart.notifyDataSetChanged()
                    
                }
            }
            
            return cell
        }
        else if indexPath.item % 3 == 1
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BarCVCell", for: indexPath) as! BarCVCell
            
            
            cell.layer.shouldRasterize = false
            cell.layer.rasterizationScale = UIScreen.main.scale
            
            let barChart = cell.chartContainer.chartView.chart as! BarChartView
            
            
            DispatchQueue.global(qos: .userInitiated).async {
                
                
                let barData = BarCVCell.getNewBarData(count: count, index: indexPath.item)
                
                DispatchQueue.main.async {
                    
                    cell.chartContainer.titleView.mainTitle.text = "Item " + String(indexPath.item)
                    
                    barChart.data = barData
                    
                    barChart.notifyDataSetChanged()
                    
                }
            }
            
            return cell
            
        }
        else
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LineCVCell", for: indexPath) as! LineCVCell
            
            
            cell.layer.shouldRasterize = false
            cell.layer.rasterizationScale = UIScreen.main.scale
            
            let lineChart = cell.chartContainer.chartView.chart as! LineChartView
            
            
            DispatchQueue.global(qos: .userInitiated).async {
                
                
                let lineData = LineCVCell.getNewLineData(count: count, index: indexPath.item)
                
                DispatchQueue.main.async {
                    
                    cell.chartContainer.titleView.mainTitle.text = "Item " + String(indexPath.item)
                    
                    lineChart.data = lineData
                    
                    lineChart.notifyDataSetChanged()
                    
                }
            }
            
            return cell
            
        }
   
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let frame = self.uiCollectionView.frame
        return CGSize(width: (frame.width-10), height: (frame.height - 10)/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    
    open static func addChart(containerView:ChartContainer) {
        //Legend Vertical or Horizontal
        containerView.legendView.orientation = .Horizontal
        containerView.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView.toolTipView.toolTipType = .leftRight
        containerView.toolTipView.toolTipEntryGenerator = DefaultToolTipEntryGenerator()
        
        // Views Hide Options
        containerView.titleView.showView = true
        //       containerView.legendView.showView = false
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView.titleView.mainTitle.text = "IOS Chart"
        containerView.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView.enableMainTitle = true
        containerView.enableSubTitle = false
        
        containerView.chartView.isUserInteractionEnabled = false
        containerView.legendView.isUserInteractionEnabled = false
        containerView.toolTipView.isUserInteractionEnabled = false
        
        containerView.toolTipView.showView = false
        containerView.legendView.showView = false
        
        
        //        addPieChart(containerView: containerView)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



class PieCVCell : UICollectionViewCell
{
    
    
    var chartContainer = ChartContainer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
 
        let cell = self
        
        
        chartContainer.translatesAutoresizingMaskIntoConstraints = false
        cell.addSubview(chartContainer)
        chartContainer.backgroundColor = UIColor.clear
        
        chartContainer.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        chartContainer.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        chartContainer.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        chartContainer.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
        
        let pieChartView = PieChartView()
        
        MultipleChartViewController.addChart(containerView: chartContainer)
        
        PieCVCell.addPieChartToContainer(containerView: chartContainer, pieChartView: pieChartView, count: 0)
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
  
    
    open static func addPieChartToContainer(containerView:ChartContainer, pieChartView:PieChartView, count:Int){
        
        let _ = containerView.initializeChart(chart: pieChartView)
        addPieProperties(pieChartView: pieChartView, count: count)
        
    }
    
    
    open static func addPieChart(containerView:ChartContainer){
        
        
        //Chart Input Data
        let pieChartView = containerView.initializeChart(type: .Pie) as! PieChartView
        
        addPieProperties(pieChartView: pieChartView, count: 0)
        
        
    }
    
    open static func addPieProperties(pieChartView:PieChartView, count:Int)
    {
        //  pieChartView.setPieType = .PieSpinWheel
        
        pieChartView.drawHoleEnabled = false // Doughnut
        pieChartView.drawEntryLabelsEnabled = false
        pieChartView.centerLabelEnabled = true
        
        pieChartView._tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView._tapEventListener?.isEnabled = true
        
        pieChartView._longPressEventListener?.handler = CustomLongPressHandler1()
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        //        pieChartView.chartActionListener = self
        
        // chartview?.usePercentValuesEnabled=true
        
        //        pieChartView.outerCircleEnabled = false
        
        let data=[100,200,150,50,80,170,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0 ..< (data.count - count) {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
        pieChartView.innerCircleEnabled = false
        
        pieChartView.centerLabelEnabled = false
        
        //        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
    }
    
    open static func getNewPieData(count:Int, index:Int) -> PieChartData
    {
        let data=[100,200,150,50,80,170,140,300]
        
        let dataLabel = ["Label " + String(index), "Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0 ..< (data.count - count) {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        
        return chartData
        
    }
    
}


class BarCVCell : UICollectionViewCell
{
    
    var chartContainer = ChartContainer()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        
        let cell = self
        
        
        chartContainer.translatesAutoresizingMaskIntoConstraints = false
        cell.addSubview(chartContainer)
        chartContainer.backgroundColor = UIColor.clear
        
        chartContainer.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        chartContainer.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        chartContainer.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        chartContainer.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
        
        let barChartView = BarChartView()
        
        
        MultipleChartViewController.addChart(containerView: chartContainer)
        
        let _ = chartContainer.initializeChart(chart: barChartView)
        
        BarCVCell.addBarChartProperties(barChartView: barChartView)
        
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    open static func addBarChartProperties(barChartView:BarChartView)
    {
        
        barChartView._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView._panEventListener?.handler = CustomBarPanHandler()
        
        barChartView._longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView.rightAxis.enabled = false
        
        barChartView.xAxis.axisTitle = "Years"
        
        barChartView.leftAxis.axisTitle = "Quantities"
        
        barChartView.rightAxis.axisTitle = "Quantities"
        
        barChartView.xAxis.wordWrapEnabled = true
        
        barChartView.xAxis.scaleType = .Ordinal
        
        //
        
        
        //        let count = 2000+50
        let count = 10
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(BarChartDataEntry(xString:lab,y: Double(val1),data:nil))
            // dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(BarChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(BarChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        
        /*    let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = BarChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = BarChartData(dataSet: set1)
        chartData.barWidth = 0.6
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView.data = chartData
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView.xAxis.labelPosition = .bottom
        
        barChartView.xAxis.granularityEnabled = true
        barChartView.xAxis.granularity = 1.0
        
        barChartView.xAxis.labelCount = 10
        
        
        //        barChartView.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView.xAxis.drawGridLinesEnabled = false
        
        barChartView.chartDescription?.enabled = false
        
        //ChartViewCell -> BarViewCell -> LineViewCell
        
    }
    
    
    open static func getNewBarData(count:Int, index:Int) -> BarChartData
    {
        let finalCount = 10
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0 ..< (finalCount - count) {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(BarChartDataEntry(xString:lab,y: Double(val1),data:nil))
            // dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(BarChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(BarChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        
        /*    let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = BarChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = BarChartData(dataSet: set1)
        chartData.barWidth = 0.6
        
        return chartData
        
    }
    
    
    
}


class LineCVCell : UICollectionViewCell
{
    
    var chartContainer = ChartContainer()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        
        let cell = self
        
        
        chartContainer.translatesAutoresizingMaskIntoConstraints = false
        cell.addSubview(chartContainer)
        chartContainer.backgroundColor = UIColor.clear
        
        chartContainer.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        chartContainer.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        chartContainer.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        chartContainer.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
        
        let lineChartView = LineChartView()
        
        
        MultipleChartViewController.addChart(containerView: chartContainer)
        
        let _ = chartContainer.initializeChart(chart: lineChartView)
        
//        BarCVCell.addBarChartProperties(barChartView: barChartView)
        
        LineCVCell.addLineChartProperties(lineChartView: lineChartView)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    open static func addLineChartProperties(lineChartView:LineChartView?){
        
        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
        
        lineChartView?._panEventListener?.handler = LinePanHandler()
        
        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
        
        lineChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.rightAxis.enabled = false
        
        //        lineChartView?.leftAxis.xOffset = 30
        
        //        lineChartView?.rightAxis.xOffset = 30
        
        lineChartView?.leftAxis.drawGridLinesEnabled = true
        
        //        lineChartView?.leftAxis.gridLineWidth = 1
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.leftAxis.resizeEnabled = true
        
        lineChartView?.leftAxis.axisMinimum = 0
        
        lineChartView?.xAxis.axisMinimum = 0
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = 1.0
        //        lineChartView?.xAxis.granularityEnabled = true
        
        lineChartView?.widthToAttainDrillState = 100
        
        
        //        let count = 2000+50
        let count = 10
        var range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            if i > 300
            //            {
            //                range = 300
            //            }
            //            if i > 600
            //            {
            //                range = 200
            //            }
            //            if i > 900
            //            {
            //                range = 100
            //            }
            
            
            let lab = "200" + String(i+1)
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
            
        }
        
        let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        
        let shape = set1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.shapeSize = 8
        shape.lineWidth = 2
        
        set1.setShapeColor(UIColor.red)
        
        set1.lineWidth = 2
        set1.drawShapeEnabled = true
        
        set1.drawFilledEnabled = false
        set1.fillAlpha = 0.3
        set1.fillColor = ChartColorTemplates.pieColor()[5]
        set1.mode = .linear
        
        
        let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        
        let shape1 = set2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.shapeSize = 8
        shape1.lineWidth = 2
        
        set2.setShapeColor(UIColor.brown)
        
        set2.lineWidth = 2
        set2.drawShapeEnabled = true
        
        set2.drawFilledEnabled = false
        set2.fillAlpha = 0.3
        set2.fillColor = ChartColorTemplates.pieColor()[1]
        set2.mode = .linear
        
        let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        
        set3.setCircleColor(UIColor.black)
        set3.lineWidth = 2
        set3.circleRadius = 3.0
        set3.drawCircleHoleEnabled = false
        set3.drawCirclesEnabled = true
        set3.drawShapeEnabled = false
        
        set3.drawFilledEnabled = false
        set3.fillAlpha = 0.3
        set3.fillColor = ChartColorTemplates.pieColor()[2]
        set3.mode = .linear
        
        
        
        
                let chartData = LineChartData(dataSet: set1)
//        let chartData = LineChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(false)
        
        lineChartView?.xAxis.spaceMin = 0.5
        lineChartView?.xAxis.spaceMax = 0.5
        
        lineChartView?.data = chartData
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.black
        upperLimit.shapeProperties = ShapeProperties()
        
        upperLimit.limitValueTextColor = UIColor.white
        upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit.shapeProperties?.holeColor = UIColor.white
        upperLimit.shapeProperties?.shapeType = .circle
        upperLimit.shapeProperties?.shapeSize = 8
        upperLimit.shapeProperties?.lineWidth = 2
//        upperLimit.shapeProperties?.customPathDataSource = self
        
        let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
        lowerRightLimit.lineColor = NSUIColor.red
        
        lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerRightLimit.lineDashPhase = 2.0
        lowerRightLimit.lineDashLengths = [1.0, 2.0]
        
        
        //      upperLimit.lineWidth = 6.0
        
        let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
        xLimit.lineColor = NSUIColor.red
        
        xLimit.lineDashPhase = 2.0
        xLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        lineChartView?.leftAxis.addLimitLine(upperLimit)
        
    }
    
    open static func getNewLineData(count:Int, index:Int) -> LineChartData
    {
        let count = 10
        var range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            if i > 300
            //            {
            //                range = 300
            //            }
            //            if i > 600
            //            {
            //                range = 200
            //            }
            //            if i > 900
            //            {
            //                range = 100
            //            }
            
            
            let lab = "200" + String(i+1)
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
            
        }
        
        let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        
        let shape = set1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.shapeSize = 8
        shape.lineWidth = 2
        
        set1.setShapeColor(UIColor.red)
        
        set1.lineWidth = 2
        set1.drawShapeEnabled = true
        
        set1.drawFilledEnabled = false
        set1.fillAlpha = 0.3
        set1.fillColor = ChartColorTemplates.pieColor()[5]
        set1.mode = .linear
        
        
        let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        
        let shape1 = set2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.shapeSize = 8
        shape1.lineWidth = 2
        
        set2.setShapeColor(UIColor.brown)
        
        set2.lineWidth = 2
        set2.drawShapeEnabled = true
        
        set2.drawFilledEnabled = false
        set2.fillAlpha = 0.3
        set2.fillColor = ChartColorTemplates.pieColor()[1]
        set2.mode = .linear
        
        let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        
        set3.setCircleColor(UIColor.black)
        set3.lineWidth = 2
        set3.circleRadius = 3.0
        set3.drawCircleHoleEnabled = false
        set3.drawCirclesEnabled = true
        set3.drawShapeEnabled = false
        
        set3.drawFilledEnabled = false
        set3.fillAlpha = 0.3
        set3.fillColor = ChartColorTemplates.pieColor()[2]
        set3.mode = .linear
        
        
        
        
        //        let chartData = LineChartData(dataSet: set1)
        let chartData = LineChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(false)
        
//        lineChartView?.xAxis.spaceMin = 0.5
//        lineChartView?.xAxis.spaceMax = 0.5
//
//        lineChartView?.data = chartData
        
        return chartData
        
    }
    
    
    
}

