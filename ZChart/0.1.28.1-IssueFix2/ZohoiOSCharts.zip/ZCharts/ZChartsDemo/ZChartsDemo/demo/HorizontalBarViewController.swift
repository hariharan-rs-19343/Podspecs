//
//  HorizontalBarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 19/12/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class HorizontalBarViewController: UIViewController,ChartActionListener,ChartViewDelegateToContainer,IToolTipEntryGenerator,ShapeFactoryDataSource  {
    
    func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> UIBezierPath {
        
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry as! BarChartDataEntry
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label: label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }

    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.delegateToCustomView = self
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .Centered
        containerView?.toolTipView.toolTipEntryGenerator = self
        containerView?.toolTipView.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.titleView.showView = false
        containerView?.legendView.showView = false
        containerView?.toolTipView.showView = true
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        
        Log.info("Drilled..")
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
        if selectedEntry != nil
        {
    
        }
        
    }
    
    
    var barChartView:HorizontalBarChartView? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        
        barChartView = containerView?.initializeChart(type: .HorizontalBar) as! HorizontalBarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = CustomHorizontalBarPanHandler()
        
        barChartView?._longPressEventListener?.handler = HorizontalBarLongPressListener()
        
        barChartView?.leftAxis.enabled = true
        
        barChartView?.rightAxis.enabled = true
        
        
        
        barChartView?.xAxis.axisTitle = "Items"
        
        barChartView?.leftAxis.axisTitle = "Quantities"
        
        barChartView?.rightAxis.axisTitle = "Quantities"
        
        
        barChartView?.xAxis.axisTitleEnabled = true
        
        barChartView?.leftAxis.axisTitleEnabled = true
        
        barChartView?.rightAxis.axisTitleEnabled = true
        
     
        
        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.leftAxis.drawAxisLineEnabled = false
        barChartView?.xAxis.scaleType = .Ordinal
        
//        barChartView?.leftAxis.baseLineEnabled = true
//        barChartView?.leftAxis.baseLine?.baseValue = 30
        
//        barChartView?.xAxis.xOffset = 50
        
//        barChartView?.leftAxis.yOffset  = 10
//
//        barChartView?.rightAxis.yOffset = 50
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        //        let count = 170
        totalSales = 0
        
        let count = 130
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
      
//            if i==7
//            {
//                dataEntries1.append(BarChartDataEntry(xString: nil, y: val1, data: nil))
//            }
//            else{
//                dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
//            }
//
//            totalSales += CGFloat(val1)
//
//
//            if i==10
//            {
//                dataEntries1.append(BarChartDataEntry(xString: "Zero Value", y: Double(0), data: nil))
//            }
//
//            if i==12
//            {
//                dataEntries1.append(BarChartDataEntry(xString: "Nil Value", y: Double.nan, data: nil))
//            }
            
            if i == 15 || (i >= 1 && i < 5)  {
                dataEntries1.append(BarChartDataEntry(xString: nil, y: val1, data: nil))
            }else {
                dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
            }
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            if i == 29
            {
                dataEntries1.append(BarChartDataEntry(xString: "last", y: val2, data: nil))
            }
            
            
            
        }
        
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.axisDependency = .left
        /*    let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = BarChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = BarChartData(dataSet: set1)
        chartData.barWidth = 0.7
        
        chartData.barWidthPixel = 18
        
        chartData.barSpacePixel = 8
        
        chartData.minimumBarPixel = 18
        
        chartData.maximumBarPixel = 70
        
//        chartData.highlightColor = UIColor.green
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.data = chartData
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 10
        
        barChartView?.scaleYEnabled = false
        barChartView?.scaleXEnabled = false
        
        barChartView?.xAxis.inverted = true
        
       // barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        
        //        barChartView?.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //                barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
//        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
//        upperLimit.lineColor = NSUIColor.green
//        //        upperLimit.lineWidth = 6.0
        
        let upperLimit = ChartLimitLine(limit: 20, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.black
        upperLimit.shapeProperties = ShapeProperties()
        
        upperLimit.limitValueTextColor = UIColor.white
        upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit.shapeProperties?.holeColor = UIColor.white
        upperLimit.shapeProperties?.shapeType = .custom
        upperLimit.shapeProperties?.shapeSize = 8
        upperLimit.shapeProperties?.lineWidth = 2
        upperLimit.shapeProperties?.customPathDataSource = self
        
        let lowerLimit = ChartLimitLine(limit: 10, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        
        //        lowerLimit.lineWidth = 6.0
        
//                barChartView?.leftAxis.addLimitLine(upperLimit)
//                barChartView?.rightAxis.addLimitLine(lowerLimit)
//        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        chartInstance.append(barChartView!)
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.initializeChart(type: .HorizontalBar) as! HorizontalBarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = CustomHorizontalBarPanHandler()
        
        //barChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.leftAxis.enabled = true
        
        barChartView?.rightAxis.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.leftAxis.axisTitle = "Quantities"
        
        barChartView?.rightAxis.axisTitle = "Quantities"
        
        barChartView?.xAxis.axisTitleEnabled = false
        
        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        //        let count = 170
        let count = 170
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
            // dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(BarChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(BarChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(BarChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.axisDependency = .left
        /*    let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = BarChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = BarChartData(dataSet: set1)
        chartData.barWidth = 0.6
        
        chartData.minimumBarPixel = 18
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.data = chartData
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 25
        
        // barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        
        //        barChartView?.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //                barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
       
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //        upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        
        chartInstance.append(barChartView!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart as! HorizontalBarChartView
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged()
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
