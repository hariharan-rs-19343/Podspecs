//
//  ToolTipMenuController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 31/08/17.
//  Copyright © 2017 charts. All rights reserved.
//


import zchart
import UIKit

class ToolTipMenuController: UIViewController,ChartActionListener,MenuDataSource,MenuDelegate {
    
    var containerView:ChartContainer? = nil
    
    func prepareMenuEntries() -> [MenuModel] {
        
        var models:[MenuModel] = []
        let m1 = MenuModel(label:"sorting Ascending",imageName: "sort1")
        let m2 = MenuModel(label:"Filtering",imageName: "filter")
        let m3 = MenuModel(label:"sorting descending",imageName: "desc")
//        let m4 = MenuModel(label:"sorting descending",imageName: "desc")
//        let m5 = MenuModel(labelName: "Checking")
        
        
        models.append(m1)
        models.append(m2)
        models.append(m3)
//        models.append(m4)
//        models.append(m5)
        
        
        return models
        
        
    }
    
    public func selectedItem(model:MenuModel)
    {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .leftRight
        containerView?.toolTipView.toolTipEntryGenerator = DefaultToolTipEntryGenerator()
        
        // Views Hide Options
        //       containerView?.titleView.showView = false
        //       containerView?.legendView.showView = false
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        containerView?.titleView.showView = false
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        //addChartTypeAndData
        
        addPieChart()
        
        //        addBarChart()
        
     
        
        /* REFRESH MENU REMOVED 
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.blue  */
        
    }
    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView?.initializeChart(type: .Pie) as! PieChartView
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        pieChartView.drawHoleEnabled = false // Doughnut
        pieChartView.drawEntryLabelsEnabled = false
        pieChartView.centerLabelEnabled = true
        
        pieChartView._tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView._tapEventListener?.isEnabled = true
        
        pieChartView._longPressEventListener?.handler = CustomLongPressHandler()
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        
        pieChartView.chartActionListener = self
        
        // chartview?.usePercentValuesEnabled=true
        
        let data=[100,200,150,50,80,170,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"] 
       // let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        HelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
        if selectedEntry != nil
        {
        }
        
        //        if selectedLayer != nil
        //        {
        //            //selectedLayer?.position = self.view.center
        //            //  selectedLayer?.backgroundColor = UIColor.lightGray.cgColor
        //            // selectedLayer?.opacity = 0.2
        //
        //            let midAngle =   getMidAngle(chartView: chartView, selectedEntry: selectedEntry)
        //
        //            let distance = 20
        //
        //            let pie = chartView as! PieChartView
        //
        //            let newPos = pie.getPosition(center: (selectedLayer?.position)!, dist:  CGFloat(distance), angle: midAngle)
        //
        //
        //            //            UIView.animate(withDuration: 2, animations: {
        //            //                selectedLayer?.position = newPos
        //            //            })
        //
        //            //selectedLayer?.position = CGPoint(x: (selectedLayer?.position.x)!, y: -100)
        //            //selectedLayer?.frame = self.view.frame
        //            //layerScaleAnimation(layer: selectedLayer!, duration: 2, fromValue: 1, toValue: 2)
        //        }
        
    }
    
    func getMidAngle(chartView: ChartViewBase, selectedEntry: ChartDataEntry?) -> CGFloat
    {
        let pieChart = chartView as! PieChartView
        
        let curIndex = pieChart.data?.dataSets[0].entryIndex(entry: selectedEntry!)
        
        //let nextIndex = (curIndex! + 1) % (self.data?.dataSets[0].entryCount)!
        
        // let pieChart = self
        let rotAngle = pieChart.rotationAngle
        let drawAngle = pieChart.drawAngles[curIndex!]
        let absAngle = pieChart.absoluteAngles[curIndex!]
        
        
        let endAngle = rotAngle + absAngle
        
        
        let startAngle = (endAngle - drawAngle)
        
        var midAngle:CGFloat =  ((startAngle + endAngle) / 2.0)
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        return midAngle
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

