//
//  PieViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 28/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import zchart
import UIKit

class PieViewController: UIViewController,ChartActionListener,MenuDataSource,MenuDelegate,IToolTipEntryGenerator,UIPickerViewDelegate, UIPickerViewDataSource {
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
            let pieEntry = entry as! PieChartDataEntry

            
            let toolTipEntry = ToolTipEntry(label: pieEntry.label!, value: String(pieEntry.y))
            toolTipEntry.valueTextColor = (entry?.entryColor)!
            toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 17)
        
            toolTipEntry.labelTextAlignment = .left
        
            toolTipEntry.valueTextAlignment = .right
            
            var labels:[String] = ["Sales","Avg. Cost","No. of Customers","Others","Label 5","Label 6","Label 7","Label 8"]
            
            
            
            entries.append(toolTipEntry)
            
            for i in 0...7
            {
                let dummy = ToolTipEntry(label: labels[i], value: String((pieEntry.y/2)+Double(i+5)))
                dummy.valueTextColor = (entry?.entryColor)!
                
                dummy.labelTextAlignment = .left
                
                dummy.valueTextAlignment = .right
                entries.append(dummy)
            }
        
       return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    let slideMenuView = UIView()
    
    var legendSwipeUpRecognizer: UISwipeGestureRecognizer!
    
    var legendSwipeDownRecognizer: UISwipeGestureRecognizer!
    
    func prepareMenuEntries() -> [MenuModel] {
        
        var models:[MenuModel] = []
        let m1 = MenuModel(label:"sorting Ascending",imageName: "sort1")
        let m2 = MenuModel(label:"Filtering",imageName: "filter")
        let m3 = MenuModel(label:"sorting descending",imageName: "desc")
        let m4 = MenuModel(label:"sorting descending",imageName: "desc")
        let m5 = MenuModel(labelName: "Checking")
        
        
        models.append(m1)
        models.append(m2)
        models.append(m3)
        models.append(m4)
        models.append(m5)
        
        
        return models
        
        
    }
    
    public func selectedItem(model:MenuModel)
    {
      
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addView()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .leftRight
        containerView?.toolTipView.toolTipEntryGenerator = self
        
        // Views Hide Options
               containerView?.titleView.showView = false
        //       containerView?.legendView.showView = false
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        //addChartTypeAndData
        
        addPieChart()
        
        //        addBarChart()
        
      /*  containerView?.toolTipView.enableMenu = true
        containerView?.toolTipView.menuControl?.dataSource = self
        containerView?.toolTipView.menuControl?.menudelegate = self */
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        
        addListener()
    }
    
    func addListener()
    {
        legendSwipeUpRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.swipeRecognized))
        legendSwipeUpRecognizer.direction = .up
        
        legendSwipeDownRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(self.swipeRecognized))
        legendSwipeDownRecognizer.direction = .down
        
//        self.containerView?.legendView.addGestureRecognizer(legendSwipeUpRecognizer)
//        self.containerView?.legendView.addGestureRecognizer(legendSwipeDownRecognizer)
    }
    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView?.initializeChart(type: .Pie) as! PieChartView
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        pieChartView.drawHoleEnabled = false // Doughnut
        pieChartView.drawEntryLabelsEnabled = false
        
        pieChartView._tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView._tapEventListener?.isEnabled = true
        
        pieChartView._longPressEventListener?.handler = CustomLongPressHandler()
        pieChartView._panEventListener?.handler = CustomPanHandler()
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
      //  pieChartView.rotationEnabled = false
        
        pieChartView.chartActionListener = self
        
     //   pieChartView.radius = 20
        
        // chartview?.usePercentValuesEnabled=true
        
        let data=[10,200,150,-50,0,-7,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
       // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.black
        
        chartDataSet.valueLinePart2Length = 0.6
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
        pieChartView.innerCircleEnabled = false
        
        pieChartView.centerLabelEnabled = false
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
       // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
       
        chartInstance.append(pieChartView)
        
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
        level += 1
        
        //Chart Input Data
        let pieChartView = containerView?.initializeChart(type: .Pie) as! PieChartView
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        pieChartView.drawHoleEnabled = false // Doughnut
        pieChartView.drawEntryLabelsEnabled = false
        pieChartView.centerLabelEnabled = true
        
        pieChartView._tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView._tapEventListener?.isEnabled = true
        
        pieChartView._longPressEventListener?.handler = CustomLongPressHandler()
        pieChartView._panEventListener?.handler = CustomPanHandler()
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        pieChartView.chartActionListener = self
        
        // chartview?.usePercentValuesEnabled=true
        
        let data=[100,200,150,50,80,170,140]
        
        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i]+String(level))
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        chartDataSet.valueTextColor = UIColor.black
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
        pieChartView.innerCircleEnabled = false
        
        pieChartView.centerLabelEnabled = false
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        chartInstance.append(pieChartView)
        
        /*let data=[100,200,150,50,80,170,140]

        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        let pieChartView = chartView as! PieChartView
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
//        pieChartView.innerCircleEnabled = false
        
//        pieChartView.centerLabelEnabled = false
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)*/
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged()
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 1.0, easingOption: .linear)
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
      
        
    }
    
    func getMidAngle(chartView: ChartViewBase, selectedEntry: ChartDataEntry?) -> CGFloat
    {
        let pieChart = chartView as! PieChartView
        
        let curIndex = pieChart.data?.dataSets[0].entryIndex(entry: selectedEntry!)
        
        //let nextIndex = (curIndex! + 1) % (self.data?.dataSets[0].entryCount)!
        
        // let pieChart = self
        let rotAngle = pieChart.rotationAngle
        let drawAngle = pieChart.drawAngles[curIndex!]
        let absAngle = pieChart.absoluteAngles[curIndex!]
        
        
        let endAngle = rotAngle + absAngle
        
        
        let startAngle = (endAngle - drawAngle)
        
        var midAngle:CGFloat =  ((startAngle + endAngle) / 2.0)
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        return midAngle
        
    }
    
    
    // ===== SWIPE ==== //
    
    open var changeInHeight:CGFloat = 0.10
    
    func swipeRecognized(_ gesture: UISwipeGestureRecognizer)
    {
        
        if gesture.direction == .up
        {
            
            NSLayoutConstraint.deactivate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
//            self.containerView?.legendHeightFactor = 0.18
            
//            if self.containerView?.currentOrientation == .Landscape
//            {
//                self.containerView?.legendHeightFactor = 0.25
//            }
            
            self.containerView?.legendHeightFactor = (self.containerView?.legendHeightFactor)! + changeInHeight
            
            self.containerView?.legendViewHeightAnchor  = (self.containerView?.legendView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.legendHeightFactor!)!))!
            
//            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! - (self.containerView?.legendHeightFactor!)!)
            
            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! - self.changeInHeight)
            
            self.containerView?.chartViewHeightAnchor = (self.containerView?.chartView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.chartHeightFactor!)!))!
            
            
            NSLayoutConstraint.activate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
        }
        else if gesture.direction == .down
        {
            
            
            NSLayoutConstraint.deactivate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
//            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! + (self.containerView?.legendHeightFactor!)!)
            
            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! + self.changeInHeight)
            
            
            self.containerView?.chartViewHeightAnchor = (self.containerView?.chartView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.chartHeightFactor!)!))!
            
            
//            self.containerView?.legendHeightFactor = 0.08
//            if self.containerView?.currentOrientation == .Landscape
//            {
//                self.containerView?.legendHeightFactor = 0.15
//            }
            
            self.containerView?.legendHeightFactor = (self.containerView?.legendHeightFactor)! - changeInHeight
            
            
           self.containerView?.legendViewHeightAnchor  = (self.containerView?.legendView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.legendHeightFactor!)!))!
            
            
            NSLayoutConstraint.activate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
        }
        
        UIView.animate(withDuration: 0.5) {
//             self.containerView?.layoutIfNeeded()
             self.containerView?.chartView.layoutIfNeeded()
             self.containerView?.legendView.layoutIfNeeded()
        }
        
    }
    
    // ===== SWIPE ==== //

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //         let leftButton =  UIBarButtonItem(title: "Save", style:   .plain, target: self, action: #selector(self.btn_clicked(_:)))
        
        let rightButton = UIBarButtonItem(title: "Options", style: .plain, target: self, action: #selector(self.btn_clicked(_:)))
        
        // Create two buttons for the navigation item
        navigationItem.rightBarButtonItem = rightButton
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        
        if self.isMovingFromParentViewController {
            
        }
    }
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
    func btn_clicked(_ sender: UIBarButtonItem) {

        var newConstraint:[NSLayoutConstraint] = []
        
        if showSlideMenu
        {
            showSlideMenu = false
            
            newConstraint = self.getHideSlideConstraint()
            
        }
        else
        {
            showSlideMenu = true
            
            newConstraint = self.getShowSlideConstraint()
            
        }
        
        let completionBlock =
        {
            (_ animationCompleted: Bool) in

            if !self.showSlideMenu
            {
                if self.selectedOrientation != nil || self.selectedPosition != nil || self.selectedTooltipType != nil
                {
                    
                    if self.selectedOrientation != nil
                    {
                        var orientation:LegendOrientation = .Horizontal
                        
                        if self.selectedOrientation == "Vertical"
                        {
                            orientation = .Vertical
                        }
                        self.containerView?.legendView.orientation = orientation
                        self.selectedOrientation  = nil
                    }
                    
                    if self.selectedPosition != nil
                    {
                        let position = self.getPostion(selectedPos: self.selectedPosition!)
                        self.containerView?.legendView.position = position
                        self.selectedPosition = nil
                    }
                    
                    if self.selectedTooltipType != nil
                    {
                        let tooltipType = self.getTooltipType(selectedPos: self.selectedTooltipType!)
                        self.containerView?.toolTipView.toolTipType = tooltipType
                        self.selectedTooltipType = nil
                        self.containerView?.toolTipView.setNeedsUpdateConstraints()
                        self.containerView?.toolTipView.setNeedsDisplay()
                        
                    }
                    
                    //To call relayout
                    self.containerView?.currentOrientation = .Undefined
                    self.containerView?.setNeedsUpdateConstraints()
                    
                    
                }
                
                
                
            }
            
            self.oldConstraint = newConstraint
            
        }
        
        
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0.1, options: .curveLinear, animations: {
            //            options: .curveEaseIn, animations: {
            NSLayoutConstraint.deactivate(self.oldConstraint)
            
            NSLayoutConstraint.activate(newConstraint)
            self.view.layoutIfNeeded()
            
            //            self.oldConstraint = newConstraint
        }, completion: completionBlock)
        
    }
    
    var showSlideMenu:Bool = false
    
    var oldConstraint:[NSLayoutConstraint] = []
    
    func addView()
    {
        self.view.addSubview(slideMenuView)
        
        addLegendOptions()
        
       // addTooltipOption()
        
        slideMenuView.translatesAutoresizingMaskIntoConstraints = false
        
        oldConstraint = self.getHideSlideConstraint()
        
        NSLayoutConstraint.activate(oldConstraint)
        
        slideMenuView.backgroundColor = UIColor.white
        
        slideMenuView.layer.borderWidth = 2.0
        
        
    }
    
    func getShowSlideConstraint() -> [NSLayoutConstraint]
    {
        let topConstraint = slideMenuView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50)
        let trailingConstraint = slideMenuView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let bottomConstraint = slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        let widthConstraint = slideMenuView.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 3/4)
        
        
        
        let legOrLabtopConstraint = legendOrientationLabel.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrLableadingConstraint = legendOrientationLabel.leadingAnchor.constraint(equalTo: slideMenuView.leadingAnchor)
        let legOrLabtrailingConstraint = legendOrientationLabel.trailingAnchor.constraint(equalTo: legendOrientationPicker.leadingAnchor)
        let legOrLabheightConstraint = legendOrientationLabel.heightAnchor.constraint(equalTo: legendOrientationPicker.heightAnchor)
        let legOrLabWidthConstraint = legendOrientationLabel.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        
        let legOrtopConstraint = legendOrientationPicker.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrleadingConstraint = legendOrientationPicker.leadingAnchor.constraint(equalTo: legendOrientationLabel.trailingAnchor)
        let legOrtrailingConstraint = legendOrientationPicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legOrheightConstraint = legendOrientationPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let legOrWidthConstraint = legendOrientationPicker.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        
        
        let legPosLabtopConstraint = legendPositionLabel.topAnchor.constraint(equalTo: legendOrientationLabel.bottomAnchor)
        let legPosLableadingConstraint = legendPositionLabel.leadingAnchor.constraint(equalTo: slideMenuView.leadingAnchor)
        let legPosLabtrailingConstraint = legendPositionLabel.trailingAnchor.constraint(equalTo: legendPositionPicker.leadingAnchor)
        let legPosLabheightConstraint = legendPositionLabel.heightAnchor.constraint(equalTo: legendPositionPicker.heightAnchor)
        let legPosLabWidthConstraint = legendPositionLabel.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        
        let legPostopConstraint = legendPositionPicker.topAnchor.constraint(equalTo: legendOrientationPicker.bottomAnchor)
        let legPosleadingConstraint = legendPositionPicker.leadingAnchor.constraint(equalTo: legendPositionLabel.trailingAnchor)
        let legPostrailingConstraint = legendPositionPicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legPosheightConstraint = legendPositionPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let legPosWidthConstraint = legendPositionPicker.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        /*
        let toolTypeLabtopConstraint = tooltipTypeLabel.topAnchor.constraint(equalTo: legendPositionLabel.bottomAnchor)
        let toolTypeLableadingConstraint = tooltipTypeLabel.leadingAnchor.constraint(equalTo: slideMenuView.leadingAnchor)
        let toolTypeLabtrailingConstraint = tooltipTypeLabel.trailingAnchor.constraint(equalTo: tooltipTypePickerView.leadingAnchor)
        let toolTypeLabheightConstraint = tooltipTypeLabel.heightAnchor.constraint(equalTo: tooltipTypePickerView.heightAnchor)
        let toolTypeLabWidthConstraint = tooltipTypeLabel.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        let toolTypePictopConstraint = tooltipTypePickerView.topAnchor.constraint(equalTo: legendPositionPicker.bottomAnchor)
        let toolTypePicleadingConstraint = tooltipTypePickerView.leadingAnchor.constraint(equalTo: tooltipTypeLabel.trailingAnchor)
        let toolTypePictrailingConstraint = tooltipTypePickerView.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let toolTypePicheightConstraint = tooltipTypePickerView.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let toolTypePicWidthConstraint = tooltipTypePickerView.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        */
        
        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
                             legOrLabtopConstraint,legOrLableadingConstraint,legOrLabtrailingConstraint,legOrLabheightConstraint,legOrLabWidthConstraint,
                             legOrtopConstraint, legOrleadingConstraint, legOrtrailingConstraint, legOrheightConstraint,legOrWidthConstraint,
                             
                             legPosLabtopConstraint,legPosLableadingConstraint,legPosLabtrailingConstraint,legPosLabheightConstraint,legPosLabWidthConstraint,
                             legPostopConstraint,legPosleadingConstraint,legPostrailingConstraint,legPosheightConstraint,legPosWidthConstraint]
                             
                           /*  toolTypeLabtopConstraint, toolTypeLableadingConstraint, toolTypeLabtrailingConstraint,toolTypeLabheightConstraint, toolTypeLabWidthConstraint,
                             
                             toolTypePictopConstraint, toolTypePicleadingConstraint, toolTypePictrailingConstraint, toolTypePicheightConstraint, toolTypePicWidthConstraint
        ] */
        
        
        return newConstraint
    }
    
    func getHideSlideConstraint() -> [NSLayoutConstraint]
    {
        let topConstraint = slideMenuView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50)
        let trailingConstraint = slideMenuView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let bottomConstraint = slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        let widthConstraint = slideMenuView.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 0)
        
        
        let legOrLabtopConstraint = legendOrientationLabel.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrLableadingConstraint = legendOrientationLabel.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legOrLabtrailingConstraint = legendOrientationLabel.trailingAnchor.constraint(equalTo: legendOrientationPicker.trailingAnchor)
        //        let legOrLabheightConstraint = legendOrientationLabel.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.15)
        let legOrLabWidthConstraint = legendOrientationLabel.widthAnchor.constraint(equalToConstant: 0)
        
        
        let legOrtopConstraint = legendOrientationPicker.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrleadingConstraint = legendOrientationPicker.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legOrtrailingConstraint = legendOrientationPicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        //        let legOrheightConstraint = legendOrientationPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.15)
        let legOrWidthConstraint = legendOrientationPicker.widthAnchor.constraint(equalToConstant: 0)
        //
        //        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
        //                              legOrLabtopConstraint,legOrLableadingConstraint,legOrLabtrailingConstraint,legOrLabheightConstraint,legOrLabWidthConstraint,
        //            legOrtopConstraint, legOrleadingConstraint, legOrtrailingConstraint, legOrheightConstraint,legOrWidthConstraint]
        //
        
        
        let legPosLabtopConstraint = legendPositionLabel.topAnchor.constraint(equalTo: legendOrientationLabel.bottomAnchor)
        let legPosLableadingConstraint = legendPositionLabel.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legPosLabtrailingConstraint = legendPositionLabel.trailingAnchor.constraint(equalTo: legendPositionPicker.trailingAnchor)
        //        let legPosLabheightConstraint = legendPositionLabel.heightAnchor.constraint(equalTo: legendPositionPicker.heightAnchor)
        let legPosLabWidthConstraint = legendPositionLabel.widthAnchor.constraint(equalToConstant: 0)
        
        
        
        let legPostopConstraint = legendPositionPicker.topAnchor.constraint(equalTo: legendOrientationPicker.bottomAnchor)
        let legPosleadingConstraint = legendPositionPicker.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legPostrailingConstraint = legendPositionPicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        //        let legPosheightConstraint = legendPositionPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.15)
        let legPosWidthConstraint = legendPositionPicker.widthAnchor.constraint(equalToConstant: 0)
        
       /*
        let toolTypeLabtopConstraint = tooltipTypeLabel.topAnchor.constraint(equalTo: legendPositionLabel.bottomAnchor)
        let toolTypeLableadingConstraint = tooltipTypeLabel.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let toolTypeLabtrailingConstraint = tooltipTypeLabel.trailingAnchor.constraint(equalTo: tooltipTypePickerView.trailingAnchor)
        //        let toolTypeLabheightConstraint = tooltipTypeLabel.heightAnchor.constraint(equalTo: tooltipTypePickerView.heightAnchor)
        let toolTypeLabWidthConstraint = tooltipTypeLabel.widthAnchor.constraint(equalToConstant: 0)
        
        
        let toolTypePictopConstraint = tooltipTypePickerView.topAnchor.constraint(equalTo: legendPositionPicker.bottomAnchor)
        let toolTypePicleadingConstraint = tooltipTypePickerView.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let toolTypePictrailingConstraint = tooltipTypePickerView.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        //        let toolTypePicheightConstraint = tooltipTypePickerView.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let toolTypePicWidthConstraint = tooltipTypePickerView.widthAnchor.constraint(equalToConstant: 0)
        
        */
        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
                             legOrLabtopConstraint,legOrLableadingConstraint,legOrLabtrailingConstraint,legOrLabWidthConstraint,
                             legOrtopConstraint, legOrleadingConstraint, legOrtrailingConstraint,legOrWidthConstraint,
                             
                             legPosLabtopConstraint,legPosLableadingConstraint,legPosLabtrailingConstraint,legPosLabWidthConstraint,
                             
                             legPostopConstraint,legPosleadingConstraint,legPostrailingConstraint,legPosWidthConstraint ]
                             
                            /* toolTypeLabtopConstraint, toolTypeLableadingConstraint, toolTypeLabtrailingConstraint, toolTypeLabWidthConstraint,
                             
                             toolTypePictopConstraint, toolTypePicleadingConstraint, toolTypePictrailingConstraint, toolTypePicWidthConstraint
            
        ]*/
        
        
        return newConstraint
    }
    
    
    
    //=================================================//
    
    let legendOrientationPicker = UIPickerView()
    
    let legendOrientationLabel = UILabel()
    
    
    let legendPositionPicker = UIPickerView()
    
    let legendPositionLabel = UILabel()
    
    
    let tooltipTypePickerView = UIPickerView()
    
    let tooltipTypeLabel = UILabel()
    
    let legendOrientationData = ["Horizontal", "Vertical"]
    
    let legendPositionData = ["top", "bottom", "left", "right"]
    
    let tooltipTypeData = ["topDown", "leftRight"]
    
    func addLegendOptions()
    {
        
        slideMenuView.addSubview(legendOrientationLabel)
        
        slideMenuView.addSubview(legendOrientationPicker)
        
        legendOrientationLabel.translatesAutoresizingMaskIntoConstraints = false
        
        legendOrientationPicker.translatesAutoresizingMaskIntoConstraints = false
        
        legendOrientationLabel.text = "Orientation"
        
        legendOrientationLabel.textAlignment = .center
        
        
        
        legendOrientationPicker.backgroundColor = UIColor.clear
        legendOrientationPicker.dataSource = self
        legendOrientationPicker.delegate = self
        
        
        
        slideMenuView.addSubview(legendPositionLabel)
        
        slideMenuView.addSubview(legendPositionPicker)
        
        legendPositionLabel.translatesAutoresizingMaskIntoConstraints = false
        
        legendPositionPicker.translatesAutoresizingMaskIntoConstraints = false
        
        legendPositionLabel.text = "Position"
        
        legendPositionLabel.textAlignment = .center
        
        
        legendPositionPicker.backgroundColor = UIColor.clear
        legendPositionPicker.dataSource = self
        legendPositionPicker.delegate = self
        
        self.selectedPosition = legendPositionData[0]
        self.selectedOrientation = legendOrientationData[0]
        
    }
    
    
    func addTooltipOption()
    {
        slideMenuView.addSubview(tooltipTypeLabel)
        
        slideMenuView.addSubview(tooltipTypePickerView)
        
        tooltipTypeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        tooltipTypePickerView.translatesAutoresizingMaskIntoConstraints = false
        
        tooltipTypeLabel.text = "TooltipType"
        
        tooltipTypeLabel.textAlignment = .center
        
        
        
        tooltipTypePickerView.backgroundColor = UIColor.clear
        tooltipTypePickerView.dataSource = self
        tooltipTypePickerView.delegate = self
        
        self.selectedTooltipType = tooltipTypeData[0]
    }
    
    
    //Number of Colummns
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView == legendOrientationPicker
        {
            return legendOrientationData.count
        }
        else if pickerView == legendPositionPicker
        {
            return legendPositionData.count
        }
        else if pickerView == tooltipTypePickerView
        {
            return tooltipTypeData.count
        }
        
        
        return legendOrientationData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView == legendOrientationPicker
        {
            return legendOrientationData[row]
        }
        else if pickerView == legendPositionPicker
        {
            return legendPositionData[row]
        }
        else if pickerView == tooltipTypePickerView
        {
            return tooltipTypeData[row]
        }
        
        return legendOrientationData[row]
    }
    
    var selectedOrientation:String? = nil
    
    var selectedPosition:String? = nil
    
    var selectedTooltipType:String? = nil
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
        if pickerView == legendOrientationPicker
        {
            selectedOrientation = legendOrientationData[row]
        }
        else if pickerView == legendPositionPicker
        {
            selectedPosition = legendPositionData[row]
        }
        else if pickerView == tooltipTypePickerView
        {
            selectedTooltipType = tooltipTypeData[row]
        }
        
    }
    
}
