//
//  SingleBarViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 28/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  zchart

class SingleBarViewController: UIViewController,ChartActionListener,MenuDataSource,MenuDelegate,ChartViewDelegateToContainer,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry as! BarChartDataEntry
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    
    func prepareMenuEntries() -> [MenuModel] {
        
        var models:[MenuModel] = []
        let m1 = MenuModel(label:"sorting Ascending",imageName: "sort1")
        let m2 = MenuModel(label:"Filtering",imageName: "filter")
        let m3 = MenuModel(label:"sorting descending",imageName: "desc")
//        let m4 = MenuModel(label:"sorting descending",imageName: "desc")
//        let m5 = MenuModel(labelName: "Checking")
        
        
        models.append(m1)
        models.append(m2)
        models.append(m3)
//      models.append(m4)
//      models.append(m5)
        
        return models
        
        
    }
    
    public func selectedItem(model:MenuModel)
    {

    }
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.delegateToCustomView = self
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .Centered
        containerView?.toolTipView.toolTipEntryGenerator = self
        containerView?.toolTipView.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.titleView.showView = false
//               containerView?.legendView.showView = false
//               containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED 
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
        if selectedEntry != nil
        {
           
        }

        
    }
    
    
    var barChartView:BarChartView? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
        
        barChartView?.chartActionListener = self
        
        //*****************************  Handlers  *******************************//
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.leftAxis.axisTitle = "Quantities"
        
        barChartView?.rightAxis.axisTitle = "Quantities"

        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 10
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.rightAxis.enabled = false
        
        barChartView?.xAxis.wordWrapEnabled = false
        
      //  barChartView?.xAxis.autoRotateAngle = 90
        
      //  barChartView?.xAxis.autoRotateEnabled = false
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.leftAxis.drawAxisLineEnabled = false
        
        barChartView?.leftAxis.baseLineEnabled = true
        barChartView?.leftAxis.baseLine?.baseValue = 400
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.leftAxis.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 130
        let range = 1200
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
 
          for i in 0..<count {
            
            var lab = "VVian " + String(Double(i+1))
            
            if i > 10
            {
                lab += " Chennai"
            }
            
            if i > 25
            {
                lab += " Runners"
            }
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
//            dataEntries1.append(BarChartDataEntry(y: Double(val1),data:lab as AnyObject))
//            dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
            if (i == 15 || (i >= 1 && i <= 5) || (i > 25 && i < 30)) && i != 2 {
                dataEntries1.append(BarChartDataEntry(xString: nil, y: val1, data: nil))
            }else {
                dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
            }
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            if i == 29
            {
                dataEntries1.append(BarChartDataEntry(xString: "last", y: Double.nan, data: nil))
            }
            
            totalSales += CGFloat(val1)
            
            
            
        }

        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        
    /*    let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[5]]
        
        let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[4]]
        
        let chartData = BarChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = BarChartData(dataSet: set1)
        
        chartData.setDrawValues(true)
        
        chartData.barWidth = 0.7
        
        chartData.barWidthPixel = 18
        
       chartData.barSpacePixel = 5
        
        barChartView?.data = chartData
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        barChartView?.barCount = 12
        
        //*****************************  MinMax and Colors  *******************************//
        
        chartData.minimumBarPixel = 18
        
        chartData.maximumBarPixel = 30
        
        //        chartData.highlightColor = UIColor.blue
        
        chartData.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
//                barChartView?.leftAxis.addLimitLine(upperLimit)
//                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
  
    }
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
      //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.rightAxis.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.leftAxis.axisTitle = "Quantities"
        
        barChartView?.rightAxis.axisTitle = "Quantities"
        
        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
            
            
        }
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = ChartColorTemplates.pieColor()

        
        let chartData = BarChartData(dataSet: set1)
        chartData.barWidth = 0.6
        
        chartData.minimumBarPixel = 18
        
        barChartView?.data = chartData

        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 12
        
        
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.9
     
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false

        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
     
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        
        chartInstance.append(barChartView!)
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
      
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart as! BarChartView
        
        chart.data = dataBackup[index].copy() as! ChartData

        chart.notifyDataSetChanged()
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
       
    }
    

    
    /*
     override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
     {
     
     super.viewWillTransition(to: size, with: coordinator)
     
     viewChanged = true
     /*  coordinator.animateAlongsideTransition(in: self.containerView, animation: { (UIViewControllerTransitionCoordinatorContext) in
     self.containerView.setNeedsUpdateConstraints()
     }, completion: nil)
     
     coordinator.animate(alongsideTransition: {, completion: <#T##((UIViewControllerTransitionCoordinatorContext) -> Void)?##((UIViewControllerTransitionCoordinatorContext) -> Void)?##(UIViewControllerTransitionCoordinatorContext) -> Void#>) */
     
     //   self.containerView?.legendView.collectionView?.reloadItems(at: (self.containerView?.legendView.collectionView?.indexPathsForVisibleItems)!)
     
     //self.containerView?.legendView.collectionView?.reloadSections(<#IndexSet#>)
     
     coordinator.animate(alongsideTransition: { context in
     // do whatever with your context
     self.containerView?.setNeedsUpdateConstraints()
     //            self.containerView?.legendView.collectionView?.performBatchUpdates({
     //            self.containerView?.legendView.collectionView?.setCollectionViewLayout((self.containerView?.legendView.collectionView?.collectionViewLayout)!, animated: true)
     //            }, completion: nil)
     context.viewController(forKey: UITransitionContextViewControllerKey.from)
     }, completion: nil)
     }
     
     var viewChanged:Bool = false
     
     override func viewWillLayoutSubviews() {
     super.viewWillLayoutSubviews()
     if viewChanged
     {
     //self.containerView?.legendView.collectionView?.collectionViewLayout.invalidateLayout()
     }
     }
     
     override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
     
     if viewChanged {
     viewChanged = false
     //   self.containerView?.legendView.collectionView?.performBatchUpdates({}, completion: nil)
     }
     }
     */

}
