//
//  NegativeValueStackViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 05/07/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

class NegativeValueStackViewController: UIViewController,ChartActionListener,IToolTipEntryGenerator  {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            toolTipEntry1.valueTextColor = UIColor.black
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        if (entry?.x.isNaN)! || (entry?.y.isNaN)!
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            toolTipEntry1.valueTextColor = UIColor.black
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! BarChartDataEntry
        
        let selectedIndex = barChartView?.lastSelectedStackIndex
        
        let set = barChartView?.data?.getDataSetForEntry(barEntry)
        
        let barDataSet = set as! BarChartDataSet
        
        if (barChartView?.barGroupSelectionEnabled)!
        {
            for i in 0 ..< (barEntry.yValues?.count)!
            {
                let toolTipEntry = ToolTipEntry(label: barDataSet.stackLabels[i], value: String(describing: barEntry.yValues?[i]))
                toolTipEntry.valueTextColor = (set?.colors[i])! //UIColor.blue //curEntry.entryColor
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
        }
        else
        {
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! BarChartDataEntry
                //            let val = curEntry.yValues?[selectedIndex!]
                let toolTipEntry = ToolTipEntry(label: curEntry.data! as! String, value: String(describing: curEntry.yValues?[selectedIndex!]))
                toolTipEntry.valueTextColor = (set?.color(atIndex: selectedIndex!))!   //UIColor.blue //curEntry.entryColor
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
            
        }
        
        
        return entries
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .leftRight
        containerView?.toolTipView.toolTipEntryGenerator = self //DefaultToolTipEntryGenerator()
        
        // Views Hide Options
        containerView?.titleView.showView = false
        // containerView?.legendView.showView = false
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        containerView?.legendToolTipToggleEnabled = false
        
        //   containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
        if selectedEntry != nil
        {
            
        }
        
        
        
    }
    
    
    var barChartView:BarChartView? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        //   let groupSpace = 0.3
        
        //  let barSpace = 0.03
        
        barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = StackedBarPanHandler() // BarPanHandler()
        
        barChartView?._longPressEventListener?.handler = StackedBarLongPressListener()
        
        //        barChartView?.xAxis.labelRotationAngle = 0
        //
        barChartView?.rightAxis.enabled = false
        
        barChartView?.leftAxis.drawAxisLineEnabled = false
        
        //
        barChartView?.xAxis.axisTitle = "Items"
        //
        barChartView?.leftAxis.axisTitle = "Quantities"
        //
        //        barChartView?.rightAxis.axisTitle = "Quantities"
        //
        barChartView?.xAxis.wordWrapEnabled = false
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        //
        
        
        //        let count = 2000+50
        
        totalSales = 0
        let count = 10
        let range = 540
        
        var dataEntries1: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            
            var stackEntry = BarChartDataEntry(xString: lab, yValues: [Double(val1), Double(val2), -Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
            
            if i % 5 == 0 {
                stackEntry = BarChartDataEntry(xString: lab, yValues: [Double(val1), -Double(val2),-Double(val3), -Double(val4) , -Double(val5)], data: lab as AnyObject)
            }
            
            if i == 3 {
                stackEntry = BarChartDataEntry(xString: lab, yValues: [Double.nan, Double(val2), Double.nan, Double(val4) , Double.nan], data: lab as AnyObject)
            }
            
            dataEntries1.append(stackEntry)
            
            totalSales += CGFloat(val1+val2+val3+val4+val5)
            
        }
        
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.colorful()[0], ChartColorTemplates.colorful()[1], ChartColorTemplates.colorful()[2], ChartColorTemplates.colorful()[3], ChartColorTemplates.colorful()[4]]
        set1.stackLabels = ["Company A", "Company B", "Company C", "Company D", "Company E"]
        set1.values = dataEntries1
        
        let chartData = BarChartData(dataSets: [set1])
        
        //    let chartData = BarChartData(dataSet: set1)
        chartData.barWidth = 0.6
        
        
        chartData.barWidthPixel = 18
        
        chartData.barSpacePixel = 5
        
        chartData.maximumBarPixel = 100
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        //        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        //        barChartView?.data = chartData
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.axisMinimum = 0
        
        //        barChartView?.xAxis.axisMaximum = 0+chartData.groupWidth(groupSpace: 0.08, barSpace: 0.03)
        
        //        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 25
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.5
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //  barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.fitBars = true
        barChartView?.drawValueAboveBarEnabled = false
        
        //        chartData.highlightColor = UIColor.brown
        
        chartData.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barChartView?.data = chartData
        
        
        //        highlightFullBarEnabled
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        chartInstance.append(barChartView!)
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        //        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        //        upperLimit.lineColor = NSUIColor.green
        //        //        upperLimit.lineWidth = 6.0
        //
        //        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        //        lowerLimit.lineColor = NSUIColor.red
        //
        //        lowerLimit.lineDashPhase = 2.0
        //        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        
    }
    
    var dataBackup:[ChartData] = []
    
    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
        barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = StackedBarPanHandler() // BarPanHandler()
        
        barChartView?._longPressEventListener?.handler = StackedBarLongPressListener()
        
        barChartView?.rightAxis.enabled = false
        
        barChartView?.xAxis.axisTitle = "Items"+String(level)
        
        barChartView?.leftAxis.axisTitle = "Quantities"
        
        barChartView?.xAxis.wordWrapEnabled = true
        
        let count = 30
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            
            let stackEntry = BarChartDataEntry(x: Double(i), yValues: [Double(val1), Double(val2), Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
            
            if i == 0 || (i > 7 && i < 10) || i == 29
            {
                stackEntry.x = Double.nan
            }
            
            
            dataEntries1.append(stackEntry)
            
        }
        
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0], ChartColorTemplates.pieColor()[1], ChartColorTemplates.pieColor()[2], ChartColorTemplates.pieColor()[3], ChartColorTemplates.pieColor()[4]]
        set1.stackLabels = ["Company A", "Company B", "Company C", "Company D", "Company E"]
        set1.values = dataEntries1
        
        let chartData = BarChartData(dataSets: [set1])
        
        chartData.barWidth = 0.6
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 10
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.5
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.fitBars = true
        barChartView?.drawValueAboveBarEnabled = false
        
        barChartView?.data = chartData
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        chartInstance.append(barChartView!)
        
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart as! BarChartView
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged()
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
    
    
    
}

