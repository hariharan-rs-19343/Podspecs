//
//  FunnelWidthViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 01/06/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import  zchart

class FunnelWidthViewController: UIViewController,ChartActionListener,IToolTipEntryGenerator, RendererDelegate {
    
    var containerView:ChartContainer? = nil
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil {
            
            var totalSum:Double = 0
            
            if self.funnelChartView?.data?.dataSets[0] != nil
            {
                let dataSet = (self.funnelChartView?.data?.dataSets[0])! as! FunnelChartDataSet
                
                let funnelEntries = dataSet.values as! [FunnelChartDataEntry]
                
                totalSum = funnelEntries.map { $0.value }.reduce(0, +)
            }
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(totalSum) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        
        let funnelEntry = entry as! FunnelChartDataEntry
        
        let toolTipEntry = ToolTipEntry(label: funnelEntry.label!, value: String(funnelEntry.y))
        toolTipEntry.valueTextColor = (funnelEntry.entryColor)
        
        entries.append(toolTipEntry)
        
        return entries
        
    }
    
    func drawOthers(_ chartView: ChartViewBase) {
        if chartView.lastSelected != nil {
            funnelChartView?.highlightFunnelLayerForEntry(entry: chartView.lastSelected!)
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .Centered
        containerView?.toolTipView.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.titleView.showView = false
        containerView?.legendView.showView = true
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        //addChartTypeAndData
        addFunnelChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    var funnelChartView:FunnelChartView? = nil
    
    func addFunnelChart()
    {
        funnelChartView = containerView?.initializeChart(type: .Funnel) as? FunnelChartView
        
        funnelChartView?._tapEventListener?.handler = FunnelHighlightHandler()
        
        funnelChartView?._longPressEventListener?.handler = FunnelLongPressListener()
        
        funnelChartView?._panEventListener?.handler = FunnelPanHandler()
        
        funnelChartView?.funnelWeightedType = .Width //DefaultType : .Height
        
        funnelChartView?.outerPadding = 20
        //
        funnelChartView?.rendererDelegate = self
        
        funnelChartView?.maxSliceHeight = 80
        
        funnelChartView?.stemHeight = 80
        
        funnelChartView?.stemWidth = 50
        
        funnelChartView?.interSliceSpacing = 5
        
        //      let data=[10,200,150,-50,0,-7,140]
        
        let data:[Double] = [265190,176240,137440,118050,71200]
        //        let data:[Double] = [265190,176240,Double.nan,118050,Double.nan]
        
        let dataLabel = ["Identify","Validated","Qualified","Proposal","Won"]
        
        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var dataEntries:[FunnelChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = FunnelChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            dataEntries.append(dataEntry)
        }
        
        let chartDataSet = FunnelChartDataSet(values: dataEntries, label: "Funnel")
        
        chartDataSet.dataToShow = .showLabel
        
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.white
        
        chartDataSet.valueFont = UIFont.boldSystemFont(ofSize: 10)
        
        let chartData = FunnelChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        funnelChartView?.data = chartData
        
        //        funnelChartView?.animate(xAxisDuration: 1, yAxisDuration: 1)
        
        //        FunnelHelperFunctions.customAnimation(chart: funnelChartView!, animationDuration: 1)
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: funnelChartView!, duration: 1, animationBlock: animateBlock)
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let animateBlock = {
            
            let allLayers = FunnelLayer.getAllFunnelLayer(chart: self.funnelChartView!)
            
            let entryCount = (allLayers.count/(self.funnelChartView?.data?.dataSetCount)!)
            
            let heightPercent = Double(2)
            
            let duration:Double = ((heightPercent) / (Double(entryCount - 1) + heightPercent)) * totalDuration
            
            
            
            let barEntryAnimator = Animator()
            
            
            barEntryAnimator.updateBlock = {
                
                for entryIndex in 0..<entryCount
                {
                    
                    
                    let startTime = (( duration / Double(heightPercent)) * Double(entryIndex))
                    
                    let endTime = startTime + duration
                    
                    let currentTime = (barEntryAnimator.phaseX) * totalDuration
                    
                    if currentTime > endTime  {
                        
                        self.updateLayerPath(phaseValue: 1, index: entryIndex, allLayers: allLayers)
                        
                    } else if currentTime < startTime {
                        
                    } else {
                        
                        let difference = currentTime - startTime
                        
                        var percent = CGFloat(difference/duration)
                        
                        if percent > 1
                        {
                            percent = 1
                        }
                        
                        self.updateLayerPath(phaseValue: percent,index:entryIndex,allLayers: allLayers)
                        
                    }
                    
                }
                
            }
            barEntryAnimator.stopBlock = {
                
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    
    func updateLayerPath(phaseValue:CGFloat,index:Int,allLayers:[ChartEntryLayer])
    {
        
        let entryCount = (funnelChartView?.data?.maxEntryCountSet?.entryCount)! - 1
        
        let indexLayer = (allLayers[entryCount - index]) as! FunnelLayer
        
        let newPoints = getUpdatedPointsForCustomAnimatiom(funnelPoint: (indexLayer.funnelSlicePoint)!, phaseValue: phaseValue)
        
        updateFunnelLayerWithNewPoints(funnelLayer: indexLayer, cgPoints: newPoints)
        
        
    }
    
    func updateFunnelLayerWithNewPoints(funnelLayer:FunnelLayer, cgPoints:[CGPoint]){
        
        let newPath = FunnelLayer.getBezeirPath(cgPoints: cgPoints)
        
        funnelLayer.path = newPath.cgPath
        
        funnelLayer.opacity = 1
    }
    
    func getUpdatedPointsForCustomAnimatiom(funnelPoint:FunnelSlicePoint, phaseValue:CGFloat) -> [CGPoint] {
        
        let allPoints = funnelPoint.points
        
        let endY = allPoints[0].y
        
        let startY = allPoints[3].y
        
        let diff = (endY - startY)
        
        let newStartY = endY - (diff * CGFloat(phaseValue)) //((CGFloat(sliceHeight * Double(index))) + (topValue))
        
        let diffX1 = abs(allPoints[0].x - allPoints[3].x)
        let startX1 = (allPoints[0].x) - (diffX1 * CGFloat(phaseValue))
        
        let diffX2 = abs(allPoints[2].x - allPoints[1].x)
        let startX2 = (allPoints[1].x) + (diffX2 * CGFloat(phaseValue))
        
        var newPoints:[CGPoint] = []
        
        newPoints.append(allPoints[0])
        newPoints.append(allPoints[1])
        newPoints.append(CGPoint(x: startX2, y: newStartY))
        newPoints.append(CGPoint(x: startX1, y: newStartY))
        
        if allPoints.count == 6 {
            
            let diffX4 = abs(allPoints[0].x - allPoints[4].x)
            let startX4 = (allPoints[0].x) - (diffX4 * CGFloat(phaseValue))
            
            let diffX3 = abs(allPoints[3].x - allPoints[1].x)
            let startX3 = (allPoints[1].x) + (diffX3 * CGFloat(phaseValue))
            
            let midDiff = (allPoints[0].y - allPoints[2].y)
            
            let newMidY = endY - (midDiff * CGFloat(phaseValue)) //((CGFloat(sliceHeight * Double(index))) + (topValue))
            
            newPoints.removeAll()
            
            newPoints.append(allPoints[0])
            newPoints.append(allPoints[1])
            newPoints.append(CGPoint(x: allPoints[2].x, y: newMidY))
            newPoints.append(CGPoint(x: startX3, y: newStartY))
            newPoints.append(CGPoint(x: startX4, y: newStartY))
            newPoints.append(CGPoint(x: allPoints[5].x, y: newMidY))
            
            
        }
        
        return newPoints
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
}

