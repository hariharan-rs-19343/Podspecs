//
//  BubbleViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 29/03/18.
//  Copyright © 2018 charts. All rights reserved.
//


import UIKit
import zchart

class BubbleViewController: UIViewController,ChartActionListener,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource {
    
    /*func drawOthers(_ chartView: ChartViewBase) {
     
     let barLineChart = chartView as! BarLineChartViewBase
     if (lineChartView?.datasetSelected)!
     {
     let index = lineChartView?.lastSelectedHigh?.dataSetIndex
     
     if index != nil{
     LineHelperFunctions.magnifyDataSet(chart: lineChartView!, dataSetIndex: index!)
     }
     }
     
     // width for single point
     var currentWidth:CGFloat
     if barLineChart.leftAxis.enabled
     {
     currentWidth = barLineChart.getTransformer(forAxis: .left).valueToPixelMatrix.a
     }
     else{
     currentWidth = barLineChart.getTransformer(forAxis: .right).valueToPixelMatrix.a
     }
     if currentWidth < 0.34
     {
     currentWidth = 0.34
     }
     
     for layer in LineLayer.getAllDataSetLayer(chart: chartView)
     {
     if ((layer.lineDataSet?.lineWidth)!*2) > currentWidth
     {
     layer.lineWidth = currentWidth/2
     }
     }
     
     }
     
     
     func shapePath(point: CGPoint, shapeInstance: ShapeProperties) -> UIBezierPath {
     
     return UIBezierPath()
     }
     
     func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> UIBezierPath {
     
     let path = UIBezierPath()
     
     path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
     
     path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
     
     path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
     
     path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
     
     path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
     
     return path
     }*/
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        /* if entry == nil
         {
         let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
         
         toolTipEntry1.valueTextColor = UIColor.black
         
         toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
         
         entries.append(toolTipEntry1)
         
         return entries
         }
         
         if !(scatterChartView?.datasetSelected)!
         {
         
         let (allEntries,allPosition) = LineHelperFunctions.getAllDatasetLineEntriesAndPosition(entry: entry!, chart:scatterChartView!)
         
         for i in 0..<(allEntries.count)
         {
         let entry = allEntries[i]
         let set = scatterChartView?.data?.getDataSetForEntry(entry)
         
         if (set?.isVisible)!
         {
         let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
         toolTipEntry.valueTextColor = (set?.colors[0])!
         
         entries.append(toolTipEntry)
         }
         }
         }
         else{
         if scatterChartView?.lastSelectedHigh == nil{
         let set = scatterChartView?.data?.getDataSetForEntry(entry)
         if (set?.isVisible)!
         {
         for i in 0..<(set?.entryCount)!
         {
         let entry = set?.entryForIndex(i)
         let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
         toolTipEntry.valueTextColor = (set?.colors[0])!
         
         entries.append(toolTipEntry)
         }
         }
         }
         else{
         
         let set = scatterChartView?.data?.getDataSetForEntry(entry)
         if (set?.isVisible)!
         {
         let toolTipEntry = ToolTipEntry(label: String(describing: entry?.x), value: String(describing: entry?.y))
         toolTipEntry.valueTextColor = (set?.colors[0])!
         
         entries.append(toolTipEntry)
         }
         }
         }
         */
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .Centered
        containerView?.toolTipView.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.titleView.showView = false
        containerView?.legendView.showView = true
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        //addChartTypeAndData
        addScatterChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var bubbleChartView:BubbleChartView? = nil
    
    func addScatterChart()
    {
        
        bubbleChartView = containerView?.initializeChart(type: .Bubble) as? BubbleChartView
        
        bubbleChartView?.chartActionListener = self
        
        //        scatterChartView?.rendererDelegate = self
        
        //        scatterChartView?._tapEventListener?.handler = LineHighlightHandler()
        
        //        scatterChartView?._panEventListener?.handler = LinePanHandler()
        
        //        scatterChartView?._longPressEventListener?.handler = LineLongPressHandler()
        
        //        scatterChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
        
        bubbleChartView?.rightAxis.enabled = false
        
        bubbleChartView?.leftAxis.drawGridLinesEnabled = true
        
        bubbleChartView?.xAxis.labelPosition = .bottom
        
        bubbleChartView?.leftAxis.resizeEnabled = true
        
        bubbleChartView?.leftAxis.axisMinimum = 0
        
        bubbleChartView?.xAxis.axisMinimum = 0
        
        bubbleChartView?.xAxis.drawGridLinesEnabled = false
        
        bubbleChartView?.chartDescription?.enabled = false
        
        bubbleChartView?.xAxis.granularity = 1.0
        
        //        scatterChartView?.widthToAttainDrillState = 100
        
        
        
        //        let count = 2000+50
        let count = 12
        var range = 100
        var sizeRange = 3000
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            
            let lab = "200" + String(i+1)
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            let size1 = arc4random_uniform(UInt32(range)) + 3
        
            dataEntries1.append(BubbleChartDataEntry(x: Double(i), y: Double(val1), size: CGFloat(size1), data: lab as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            let size2 = arc4random_uniform(UInt32(range)) + 3

            dataEntries2.append(BubbleChartDataEntry(x: Double(i), y: Double(val2), size: CGFloat(size2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            let size3 = arc4random_uniform(UInt32(range)) + 3

            dataEntries3.append(BubbleChartDataEntry(x: Double(i), y: Double(val3), size: CGFloat(size3), data: lab as AnyObject))
            
        }
    
        let set1 = BubbleChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[2])
        
        
        let shape = set1.shapeProperties
        shape.holeColor = ChartColorTemplates.pieColor()[2]
        shape.shapeType = .circle
        shape.shapeSize = 16
        shape.lineWidth = 2
        //
        //        set1.setShapeColor(UIColor.red)
        //
        //        set1.lineWidth = 3
        //        set1.drawShapeEnabled = false
        //
        //        set1.drawFilledEnabled = false
        //        set1.fillAlpha = 0.3
        //        set1.fillColor = ChartColorTemplates.pieColor()[5]
        //        set1.mode = .linear
        
        
        /*let set2 = ScatterChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(ChartColorTemplates.pieColor()[1])
         
         let shape1 = set2.markerInstance
         shape1.holeColor = UIColor.brown
         shape1.shapeType = .square
         shape1.shapeSize = 8
         shape1.lineWidth = 2
         
         set2.setShapeColor(UIColor.brown)
         
         set2.lineWidth = 3
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3  = ScatterChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(ChartColorTemplates.pieColor()[2])
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 3
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear*/
        
        
        
        
        let chartData = BubbleChartData(dataSets: [set1])
        chartData.setDrawValues(false)
        
        bubbleChartView?.xAxis.spaceMin = 0.5
        bubbleChartView?.xAxis.spaceMax = 0.5
        
        bubbleChartView?.data = chartData
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        /*  let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
         upperLimit.lineColor = NSUIColor.black
         upperLimit.shapeProperties = ShapeProperties()
         
         upperLimit.limitValueTextColor = UIColor.white
         upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
         
         upperLimit.shapeProperties?.holeColor = UIColor.white
         upperLimit.shapeProperties?.shapeType = .custom
         upperLimit.shapeProperties?.shapeSize = 8
         upperLimit.shapeProperties?.lineWidth = 2
         upperLimit.shapeProperties?.customPathDataSource = self
         
         let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerLimit.lineColor = NSUIColor.red
         
         lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerLimit.lineDashPhase = 2.0
         lowerLimit.lineDashLengths = [1.0, 2.0]
         
         let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerRightLimit.lineColor = NSUIColor.red
         
         lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerRightLimit.lineDashPhase = 2.0
         lowerRightLimit.lineDashLengths = [1.0, 2.0]
         
         
         //      upperLimit.lineWidth = 6.0
         
         let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
         xLimit.lineColor = NSUIColor.red
         
         xLimit.lineDashPhase = 2.0
         xLimit.lineDashLengths = [1.0, 2.0]
         
         //        lowerLimit.lineWidth = 6.0
         
         scatterChartView?.leftAxis.addLimitLine(upperLimit)
         //            lineChartView?.rightAxis.addLimitLine(lowerLimit)
         //        lineChartView?.xAxis.addLimitLine(xLimit)
         
         
         //        lineChartView?.rightAxis.addLimitLine(lowerRightLimit)*/
        
        
        
        bubbleChartView?.animate(xAxisDuration: 1.0)
        
        dataBackup.append(bubbleChartView?.data?.copy() as! ChartData)
        chartInstance.append(bubbleChartView!)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /*     level += 1
         
         scatterChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         
         scatterChartView?.chartActionListener = self
         
         scatterChartView?._tapEventListener?.handler = LineHighlightHandler()
         
         scatterChartView?._panEventListener?.handler = LinePanHandler()
         
         scatterChartView?._longPressEventListener?.handler = LineLongPressHandler()
         
         scatterChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
         
         scatterChartView?.rightAxis.enabled = false
         
         scatterChartView?.leftAxis.drawGridLinesEnabled = false
         
         scatterChartView?.xAxis.labelPosition = .bottom
         
         scatterChartView?.leftAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.drawGridLinesEnabled = false
         
         scatterChartView?.chartDescription?.enabled = false
         
         scatterChartView?.xAxis.granularity = 1.0
         //        lineChartView?.xAxis.granularityEnabled = true
         
         //        let count = 2000+50
         let count = 12
         let range = 54
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = false
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1, set2,set3])
         chartData.setDrawValues(false)
         
         
         scatterChartView?.data = chartData
         
         //lineChartView?.xAxis.spaceMax = 0.5
         scatterChartView?.xAxis.spaceMin = 0.9
         
         
         
         scatterChartView?.animate(xAxisDuration: 1.0)
         
         dataBackup.append(scatterChartView?.data?.copy() as! ChartData)
         chartInstance.append(scatterChartView!)*/
        
    }
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {
      
        /* if true     //velocity > 1  //&& (Int(end)!-Int(start)!) == 1
         {
         //            level += 1
         //
         //        lineChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         //
         //        lineChartView?.chartActionListener = self
         //
         //        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
         //
         //        lineChartView?._panEventListener?.handler = LinePanHandler()
         //
         //        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
         //
         //        lineChartView?.rightAxis.enabled = false
         //
         //        lineChartView?.leftAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.xAxis.labelPosition = .bottom
         //
         //        lineChartView?.leftAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.chartDescription?.enabled = false
         //
         //        lineChartView?.xAxis.granularity = 1.0
         //        //        lineChartView?.xAxis.granularityEnabled = true
         //
         //        //        let count = 2000+50
         let count = 12
         let range = 150
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i%12] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i%12] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i%12] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = true
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1])
         chartData.setDrawValues(false)
         
         
         chartView.data = chartData
         
         
         
         
         //        //lineChartView?.xAxis.spaceMax = 0.5
         //        lineChartView?.xAxis.spaceMin = 0.9
         //
         //
         //
         //        lineChartView?.animate(xAxisDuration: 1.0)
         
         //            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
         //            chartInstance.append(lineChartView!)
         }
         else if velocity < -3  //&& Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
         {
         if level > 0
         {
         level = level-1
         
         let chart = chartInstance[level]
         
         scatterChartView = chart as! LineChartView
         
         chart.data = dataBackup[level].copy() as! ChartData
         
         dataBackup.removeLast(dataBackup.count-1 - level)
         
         chartInstance.removeLast(chartInstance.count-1 - level)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 1.0)
         }
         }*/
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}




