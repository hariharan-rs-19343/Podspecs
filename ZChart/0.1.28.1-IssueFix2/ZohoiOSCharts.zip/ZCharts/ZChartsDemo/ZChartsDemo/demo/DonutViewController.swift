//
//  DonutViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 18/07/18.
//  Copyright © 2018 charts. All rights reserved.
//


import zchart
import UIKit

class DonutViewController: UIViewController,ChartActionListener,IToolTipEntryGenerator{
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let pieEntry = entry as! PieChartDataEntry
        
        
        let toolTipEntry = ToolTipEntry(label: pieEntry.label!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = (entry?.entryColor)!
        toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 17)
        
        toolTipEntry.labelTextAlignment = .left
        
        toolTipEntry.valueTextAlignment = .right
        
        var labels:[String] = ["Sales","Avg. Cost","No. of Customers","Others","Label 5","Label 6","Label 7","Label 8"]
        
        
        
        entries.append(toolTipEntry)
        
        for i in 0...7
        {
            let dummy = ToolTipEntry(label: labels[i], value: String((pieEntry.y/2)+Double(i+5)))
            dummy.valueTextColor = (entry?.entryColor)!
            
            dummy.labelTextAlignment = .left
            
            dummy.valueTextAlignment = .right
            entries.append(dummy)
        }
        
        return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .leftRight
        containerView?.toolTipView.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.titleView.showView = false
        //       containerView?.legendView.showView = false
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        //addChartTypeAndData
        
        addPieChart()
        
        //        addBarChart()
        
        /*  containerView?.toolTipView.enableMenu = true
         containerView?.toolTipView.menuControl?.dataSource = self
         containerView?.toolTipView.menuControl?.menudelegate = self */
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
     
    }

    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView?.initializeChart(type: .Pie) as! PieChartView
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        pieChartView.drawHoleEnabled = true // Doughnut
        pieChartView.drawEntryLabelsEnabled = false
        
        pieChartView._tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView._tapEventListener?.isEnabled = true
        
        pieChartView._longPressEventListener?.handler = CustomLongPressHandler()
        pieChartView._panEventListener?.handler = CustomPanHandler()
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        pieChartView.chartActionListener = self
        
        // Total Angle
//        pieChartView.maxAngle = 180
        
        // Start Angle
//        pieChartView.rotationAngle = 180
        
        //   pieChartView.radius = 20
        
        // chartview?.usePercentValuesEnabled=true
        
        let data=[10,200,150,-50,0,-7,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
        // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.black
        
        chartDataSet.valueLinePart2Length = 0.6
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
        pieChartView.innerCircleEnabled = false
        
        pieChartView.centerLabelEnabled = false
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
        // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        chartInstance.append(pieChartView)
        
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
        level += 1
        
        //Chart Input Data
        let pieChartView = containerView?.initializeChart(type: .Pie) as! PieChartView
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        pieChartView.drawHoleEnabled = false // Doughnut
        pieChartView.drawEntryLabelsEnabled = false
        pieChartView.centerLabelEnabled = true
        
        pieChartView._tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView._tapEventListener?.isEnabled = true
        
        pieChartView._longPressEventListener?.handler = CustomLongPressHandler()
        pieChartView._panEventListener?.handler = CustomPanHandler()
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        pieChartView.chartActionListener = self
        
        // chartview?.usePercentValuesEnabled=true
        
        let data=[100,200,150,50,80,170,140]
        
        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[PieChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i]+String(level))
            piedata.append(dataEntry)
        }
        
        let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        let chartData = PieChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        chartDataSet.valueTextColor = UIColor.black
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
        pieChartView.innerCircleEnabled = false
        
        pieChartView.centerLabelEnabled = false
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        chartInstance.append(pieChartView)
        
        /*let data=[100,200,150,50,80,170,140]
         
         let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
         
         var piedata:[PieChartDataEntry]=[]
         
         for i in 0..<data.count {
         let dataEntry = PieChartDataEntry(value: Double(data[i]),label: dataLabel[i])
         piedata.append(dataEntry)
         }
         
         let chartDataSet = PieChartDataSet(values: piedata, label: "Checking")
         //chartDataSet.drawValuesEnabled = false
         // chartDataSet.sliceSpace=2.0
         
         //Custom Colors can be assigned
         chartDataSet.colors=ChartColorTemplates.colorful()
         
         let chartData = PieChartData(dataSet: chartDataSet)
         
         chartData.setDrawValues(true) //To draw values on Pie Sector
         
         let pieChartView = chartView as! PieChartView
         
         pieChartView.data = chartData
         
         pieChartView.arrowShow = false
         
         pieChartView.patternEnabled = false
         
         pieChartView.outerCircleEnabled = false
         
         //        pieChartView.innerCircleEnabled = false
         
         //        pieChartView.centerLabelEnabled = false
         
         pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)*/
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged()
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 1.0, easingOption: .linear)
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
        
        
    }
    
    func getMidAngle(chartView: ChartViewBase, selectedEntry: ChartDataEntry?) -> CGFloat
    {
        let pieChart = chartView as! PieChartView
        
        let curIndex = pieChart.data?.dataSets[0].entryIndex(entry: selectedEntry!)
        
        //let nextIndex = (curIndex! + 1) % (self.data?.dataSets[0].entryCount)!
        
        // let pieChart = self
        let rotAngle = pieChart.rotationAngle
        let drawAngle = pieChart.drawAngles[curIndex!]
        let absAngle = pieChart.absoluteAngles[curIndex!]
        
        
        let endAngle = rotAngle + absAngle
        
        
        let startAngle = (endAngle - drawAngle)
        
        var midAngle:CGFloat =  ((startAngle + endAngle) / 2.0)
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        return midAngle
        
    }
    
    
    // ===== SWIPE ==== //
    
    open var changeInHeight:CGFloat = 0.10
    
    func swipeRecognized(_ gesture: UISwipeGestureRecognizer)
    {
        
        if gesture.direction == .up
        {
            
            NSLayoutConstraint.deactivate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
            //            self.containerView?.legendHeightFactor = 0.18
            
            //            if self.containerView?.currentOrientation == .Landscape
            //            {
            //                self.containerView?.legendHeightFactor = 0.25
            //            }
            
            self.containerView?.legendHeightFactor = (self.containerView?.legendHeightFactor)! + changeInHeight
            
            self.containerView?.legendViewHeightAnchor  = (self.containerView?.legendView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.legendHeightFactor!)!))!
            
            //            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! - (self.containerView?.legendHeightFactor!)!)
            
            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! - self.changeInHeight)
            
            self.containerView?.chartViewHeightAnchor = (self.containerView?.chartView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.chartHeightFactor!)!))!
            
            
            NSLayoutConstraint.activate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
        }
        else if gesture.direction == .down
        {
            
            
            NSLayoutConstraint.deactivate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
            //            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! + (self.containerView?.legendHeightFactor!)!)
            
            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! + self.changeInHeight)
            
            
            self.containerView?.chartViewHeightAnchor = (self.containerView?.chartView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.chartHeightFactor!)!))!
            
            
            //            self.containerView?.legendHeightFactor = 0.08
            //            if self.containerView?.currentOrientation == .Landscape
            //            {
            //                self.containerView?.legendHeightFactor = 0.15
            //            }
            
            self.containerView?.legendHeightFactor = (self.containerView?.legendHeightFactor)! - changeInHeight
            
            
            self.containerView?.legendViewHeightAnchor  = (self.containerView?.legendView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.legendHeightFactor!)!))!
            
            
            NSLayoutConstraint.activate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
        }
        
        UIView.animate(withDuration: 0.5) {
            //             self.containerView?.layoutIfNeeded()
            self.containerView?.chartView.layoutIfNeeded()
            self.containerView?.legendView.layoutIfNeeded()
        }
        
    }
    
    // ===== SWIPE ==== //
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        
        if self.isMovingFromParentViewController {
            
        }
    }
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
 
}

