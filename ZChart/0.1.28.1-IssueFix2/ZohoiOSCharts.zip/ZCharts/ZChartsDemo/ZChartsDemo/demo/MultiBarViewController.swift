//
//  MultiBarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 09/10/17.
//  Copyright © 2017 charts. All rights reserved.
//


import UIKit
import  zchart

class MultiBarViewController: UIViewController,ChartActionListener,MenuDataSource,MenuDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! BarChartDataEntry
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
   
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (barChartView?.barGroupSelectionEnabled)!
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String(describing: dataSet?.entryForIndex(selectedIndex!)?.y))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! BarChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }

    
    func prepareMenuEntries() -> [MenuModel] {
        
        var models:[MenuModel] = []
        let m1 = MenuModel(label:"sorting Ascending",imageName: "sort1")
        let m2 = MenuModel(label:"Filtering",imageName: "filter")
        let m3 = MenuModel(label:"sorting descending",imageName: "desc")
        //        let m4 = MenuModel(label:"sorting descending",imageName: "desc")
        //        let m5 = MenuModel(labelName: "Checking")
        
        
        models.append(m1)
        models.append(m2)
        models.append(m3)
        //      models.append(m4)
        //      models.append(m5)
        
        return models
        
        
    }
    
    public func selectedItem(model:MenuModel)
    {
       
    }
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legendView.orientation = .Horizontal
        containerView?.legendView.position = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.toolTipView.toolTipType = .Centered
        containerView?.toolTipView.toolTipEntryGenerator = self
        containerView?.toolTipView.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.titleView.showView = false
      //  containerView?.legendView.showView = false
        //       containerView?.toolTipView.showView = false
        
        //Title View options
        containerView?.titleView.mainTitle.text = "IOS Chart"
        containerView?.titleView.subTitle.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.enableMainTitle = true
        containerView?.enableSubTitle = false
        
        containerView?.legendToolTipToggleEnabled = false
        
      //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tapEventCalled(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, selectedLayer: SliceLayer?) {
        
        if selectedEntry != nil
        {
          
        }
     
        
    }
    
    
    var barChartView:BarChartView? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = MultiBarPanHandler()
        
     //   barChartView?.legend.labels
        
        
//        barChartView?.xAxis.labelRotationAngle = 0
//        
        barChartView?.rightAxis.enabled = false
//
        barChartView?.xAxis.axisTitle = "Years"
//
        barChartView?.leftAxis.axisTitle = "Sales"
        
        barChartView?.leftAxis.drawAxisLineEnabled = false
        
//        barChartView?.leftAxis.baseLineEnabled = true
//        barChartView?.leftAxis.baseLine?.baseValue = 30

//        barChartView?.rightAxis.axisTitle = "Quantities"
//        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        totalSales = 0
        
        let count = 10
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        var dataEntries4: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
//            let lab = "Item " + String(Double(i+1))
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
//            dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
            

            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries2.append(BarChartDataEntry(xString: lab, y: val2, data: nil))
//            dataEntries2.append(BarChartDataEntry(x: Double(i), y: Double(val2)))

            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries3.append(BarChartDataEntry(xString: lab, y: val3, data: nil))
//            dataEntries3.append(BarChartDataEntry(x: Double(i), y: Double(val3)))
            
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            if i==0
            {
//                dataEntries4.append(BarChartDataEntry(xString: lab, y: Double(0), data: nil))
                dataEntries4.append(BarChartDataEntry(xString: lab, y: Double.nan, data: nil))
            }
            else
            {
                 dataEntries4.append(BarChartDataEntry(xString: lab, y: val4, data: nil))
            }
            
            totalSales += CGFloat(val1+val2+val3+val4)

        }
        
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        
        let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
         
        let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        
        let set4:BarChartDataSet = BarChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"
         
        let chartData = BarChartData(dataSets: [set1, set2, set3, set4])
        
    //    let chartData = BarChartData(dataSet: set1)
//        chartData.barWidth = 0.175
        
        chartData.barWidthPixel = 18

        chartData.barSpacePixel = 5

        chartData.groupSpacePixel = 20
        
        chartData.minimumBarPixel = 18
        
        chartData.maximumBarPixel = 40
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
//          chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
       // chartData.highlightColor = UIColor.brown
        
        chartData.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
//        barChartView?.data = chartData
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
//        barChartView?.xAxis.axisMinimum = 0
        
//        barChartView?.xAxis.axisMaximum = 0+chartData.groupWidth(groupSpace: 0.08, barSpace: 0.03)
        
//        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        

        barChartView?.xAxis.axisMinimum = 0
        barChartView?.xAxis.axisMaximum = 1 * 2 + 0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
//                barChartView?.xAxis.spaceMax = 2
//                barChartView?.xAxis.spaceMin = 2
        
        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
       // let scaleLevel = CGFloat(count/5)
        
      //  barChartView?.setScaleMinima(scaleLevel, scaleY: 0)
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.data = chartData
        
        //chartData.maximumBarPixel = 10

         barChartView?.xAxis.labelCount = 7
        
//        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
       
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
//        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
//        upperLimit.lineColor = NSUIColor.green
//        //        upperLimit.lineWidth = 6.0
//        
//        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
//        lowerLimit.lineColor = NSUIColor.red
//        
//        lowerLimit.lineDashPhase = 2.0
//        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //barChartView?.data?.setDrawValues(false)
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        chartInstance.append(barChartView!)
        
        
    }
    
    var dataBackup:[ChartData] = []
    
    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
        
        barChartView?.chartActionListener = self
        
        barChartView?._tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?._panEventListener?.handler = MultiBarPanHandler()
        
        
    
        barChartView?.rightAxis.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.leftAxis.axisTitle = "Sales"
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
    
        let count = 10
        let range = 54
        
        var dataEntries1: [BarChartDataEntry] = []
        var dataEntries2: [BarChartDataEntry] = []
        var dataEntries3: [BarChartDataEntry] = []
        var dataEntries4: [BarChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            let lab = "Item " + String(Double(i+1))
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
            //            dataEntries1.append(BarChartDataEntry(x: Double(i), y: Double(val1)))
            
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries2.append(BarChartDataEntry(xString: lab, y: val2, data: nil))
            //            dataEntries2.append(BarChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            
        }
        
        
        let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.colorful()[0]]
        set1.label = "Company A"
        
        let set2:BarChartDataSet = BarChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.colorful()[1]]
        set2.label = "Company B"
        
        let set3:BarChartDataSet = BarChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        
        let set4:BarChartDataSet = BarChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"
        
        let chartData = BarChartData(dataSets: [set1, set2])
        
  
//        chartData.barWidth = 0.175
      
//        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        chartData.barWidthPixel = 18
        
        chartData.barSpacePixel = 5
        
        chartData.groupSpacePixel = 20
        
        chartData.minimumBarPixel = 18
        
        chartData.maximumBarPixel = 100
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.axisMinimum = 0
        barChartView?.xAxis.axisMaximum = 10
        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
     
        
        barChartView?.data = chartData
        
        barChartView?.xAxis.labelCount = 4
        
//        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        chartInstance.append(barChartView!)
        
     
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        
        let chart = chartInstance[index]
        
        barChartView = chart as! BarChartView
        
        level = index
        
        containerView?.initializeChart(chart: chart)
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged()
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        let barChartData = chart.data as! BarChartData
        
        barChartData.groupBars(fromX: 0, groupSpace: barChartData.groupSpace, barSpace: barChartData.barSpace)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
    
    /*
     override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
     {
     
     super.viewWillTransition(to: size, with: coordinator)
     
     viewChanged = true
     /*  coordinator.animateAlongsideTransition(in: self.containerView, animation: { (UIViewControllerTransitionCoordinatorContext) in
     self.containerView.setNeedsUpdateConstraints()
     }, completion: nil)
     
     coordinator.animate(alongsideTransition: {, completion: <#T##((UIViewControllerTransitionCoordinatorContext) -> Void)?##((UIViewControllerTransitionCoordinatorContext) -> Void)?##(UIViewControllerTransitionCoordinatorContext) -> Void#>) */
     
     //   self.containerView?.legendView.collectionView?.reloadItems(at: (self.containerView?.legendView.collectionView?.indexPathsForVisibleItems)!)
     
     //self.containerView?.legendView.collectionView?.reloadSections(<#IndexSet#>)
     
     coordinator.animate(alongsideTransition: { context in
     // do whatever with your context
     self.containerView?.setNeedsUpdateConstraints()
     //            self.containerView?.legendView.collectionView?.performBatchUpdates({
     //            self.containerView?.legendView.collectionView?.setCollectionViewLayout((self.containerView?.legendView.collectionView?.collectionViewLayout)!, animated: true)
     //            }, completion: nil)
     context.viewController(forKey: UITransitionContextViewControllerKey.from)
     }, completion: nil)
     }
     
     var viewChanged:Bool = false
     
     override func viewWillLayoutSubviews() {
     super.viewWillLayoutSubviews()
     if viewChanged
     {
     //self.containerView?.legendView.collectionView?.collectionViewLayout.invalidateLayout()
     }
     }
     
     override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
     
     if viewChanged {
     viewChanged = false
     //   self.containerView?.legendView.collectionView?.performBatchUpdates({}, completion: nil)
     }
     }
     */
    
}
