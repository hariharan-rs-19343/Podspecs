//
//  ChartListController.swift
//  ZCharts
//
//  Created by Aravinth T on 28/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

/*protocol HeaderViewDelegate: class {
    func toggleSection(header: HeaderView, section: Int)
}*/

class ChartListController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    

    var tableView: UITableView  =   UITableView()
    
    var sectionTitle = [["Name":"Pie","Expanded":false],
                        ["Name":"Bar","Expanded":false],
                        ["Name":"Line","Expanded":false],
                        ["Name":"Area","Expanded":false],
                        ["Name":"Scatter","Expanded":false],
                        ["Name":"Bubble","Expanded":false],
                        ["Name":"Funnel","Expanded":false],
                        ["Name":"Multiple","Expanded":false],
                        ["Name":"Negative Data","Expanded":false],
                        ["Name":"BaseLine ","Expanded":false],
                        ["Name":"Combined Charts ","Expanded":false],
                        ["Name":"Percentage Charts ","Expanded":false]] // "Bar","Line","Area","Scatter","Bubble","Funnel","Multiple"]
    
    var sectionItems = [
                        [
                            ["Name":"Type 1 - Spin Wheel", "class":"ArrowPieController"],
                            ["Name":"Type 2 - Vertical tooltip ", "class":"PieViewController"],
                            ["Name":"Donut", "class":"DonutViewController"]
                        ],
                        [
                            ["Name":"SingleBar ", "class":"SingleBarViewController"],
                            ["Name":"HorizontalBar ", "class":"HorizontalBarViewController"],
                            ["Name":"MultiBar ", "class":"MultiBarViewController"],
                            ["Name":"HorizontalMultiBar ", "class":"HorizontalMultiBarViewController"],
                            ["Name":"Stacked ", "class":"StackedBarViewController"],
                            ["Name":"HorizontalStackedBar ", "class":"HorizontalStackedBarViewController"],
                            ["Name":"HorizontalMultiStackBar ", "class":"HorizontalMultiStackBarViewController"],
                            ["Name":"MultiYAxis", "class":"MultiYAxisViewController"]
                        ],
                        [
                            ["Name":"LineChart ", "class":"LineViewController"],
                            ["Name":"Line - TimeScale", "class":"LineViewTimeScaleController"]
                        ],
                        [
                            ["Name":"AreaChart ", "class":"AreaViewController"]
                        ],
                        [
                            ["Name":"ScatterChart ", "class":"ScatterViewController"]
                        ],
                        [
                            ["Name":"BubbleChart ", "class":"BubbleViewController"]
                        ],
                        [
                            ["Name":"FunnelChart - Height ", "class":"FunnelViewController"],
                            ["Name":"FunnelChart - Width ", "class":"FunnelWidthViewController"]
                        ],
                        [
                            ["Name":"MultipleChart ", "class":"MultipleChartViewController"]
                        ],
                        [
                            ["Name":"StackedBar ", "class":"NegativeValueStackViewController"]
                        ],
                        [
                            ["Name":"AreaChart ", "class":"BaseLineAreaViewController"],
                            ["Name":"HorizontalBar ", "class":"BaseLineHorizontalBarViewController"]
                        ],
                        [
                            ["Name":"Bar-Line ", "class":"CombinedBarLineViewController"]
                        ],
                        [
                            ["Name":"StackedBar ", "class":"StackedPercentageViewController"]
                        ]
                    ]
                        
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.title = "PIE DEMO"
        
        self.view.addSubview(tableView)
        
        let contentGuide = view.layoutMarginsGuide
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        tableView.leadingAnchor.constraint(equalTo: contentGuide.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: contentGuide.trailingAnchor).isActive = true
        tableView.topAnchor.constraint(equalTo: contentGuide.topAnchor).isActive = true
        tableView.heightAnchor.constraint(equalTo: contentGuide.heightAnchor).isActive = true

        tableView.delegate      =   self
        tableView.dataSource    =   self
        tableView.backgroundColor = UIColor.clear
        
        tableView.showsVerticalScrollIndicator = false
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
//        tableView.register(HeaderView.self, forHeaderFooterViewReuseIdentifier: "header")
        
             
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
    
  /*  func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = HeaderView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 50))                           //tableView.dequeueReusableHeaderFooterView(withIdentifier: "header") as! HeaderView

        headerView.section = section
        headerView.delegate = self
        headerView.labelView.text = sectionTitle[section]["Name"] as? String
        headerView.labelView.font = UIFont.boldSystemFont(ofSize: 16)
        return headerView
    }
     func toggleSection(header: HeaderView, section: Int) {
        let state =  sectionTitle[section]["Expanded"] as! Bool
        
        if state
        {
            sectionTitle[section]["Expanded"] = false
        }
        else{
            sectionTitle[section]["Expanded"] = true
            
            for count in 0..<sectionTitle.count
            {
                if count != section
                {
                    sectionTitle[count]["Expanded"] = false
                }
            }
        }
        
        tableView.reloadData()
    }*/
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionTitle.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionTitle[section]["Name"] as? String
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return self.items.count
        
        return sectionItems[section].count
        
        /*let state = sectionTitle[section]["Expanded"] as? Bool
        if state == false
        {
            return 0
        }
        else{
            return sectionItems[section].count
        }*/
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        
        let diction = self.sectionItems[indexPath.section][indexPath.row]              //self.dictionary[indexPath.row]
        
        cell.textLabel?.text =  diction["Name"]
        
        //  cell.textLabel?.text = self.items[indexPath.row]
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let diction = self.sectionItems[indexPath.section][indexPath.row]              //self.dictionary[indexPath.row]
        
        let className = diction["class"]
        /* let aClass = NSClassFromString(className!) as! UIViewController.Type
         let viewController = aClass.init()
         */
  
        let viewController = NSObject.fromClassName(className: className!) as! UIViewController
       
        self.navigationController?.pushViewController(viewController, animated: false)
        
    }
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension NSObject {
    class func fromClassName(className : String) -> NSObject {
        let className = Bundle.main.infoDictionary!["CFBundleName"] as! String + "." + className
        let aClass = NSClassFromString(className) as! UIViewController.Type
        return aClass.init()
    }
}


/*class HeaderView:UIView
{
    var section: Int = 0
    
    weak var delegate: HeaderViewDelegate?
    
    var labelView:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        labelView = UILabel(frame: frame)
        
        self.addSubview(labelView)
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(headerTapped)))
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func headerTapped()
    {
        delegate?.toggleSection(header: self, section: section)
    }
}*/

