//
//  CustomTouchHandler.swift
//  ZCharts
//
//  Created by Aravinth T on 11/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class CustomTouchHandler: NSObject, TouchHandler {

    let duration:TimeInterval = 0.5
    
    var oldLayer:SliceLayer? = nil
    
    func getTouchHandlerType() -> TouchHandlerType {
        return TouchHandlerType.custom
    }
    
    func touchEventBegan(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: SliceLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
     
        Log.info("Touch Event Began ")
        
        
        let pieChart = chartView as! PieChartView
        
        let location = getLocation(touches, chart: chartView)
        
        let (selectedHigh, selectedEntry) = HelperFunctions.getHighAndEntryForPoint(chart: chartView, location: location)
        
        if selectedHigh == nil || selectedEntry == nil { return }
        
        let completionBlock =
        {
            pieChart.highlightValue(selectedHigh, callDelegate: false)
        }
        
        HelperFunctions.sliceOut(sliceLayer: sliceLayer!, high: selectedHigh!, chart: pieChart, duration: duration, completionBlock: completionBlock)
        
        oldLayer = sliceLayer
    }
    
    func touchEventMoved(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: SliceLayer?, _ touches: Set<
        NSUITouch>, withEvent event: NSUIEvent?) {
        
        Log.info("Touch Event Moved ")
        
        let pieChart = chartView as! PieChartView
        
        let location = getLocation(touches, chart: chartView)
        
        let (selectedHigh, selectedEntry) = HelperFunctions.getHighAndEntryForPoint(chart: chartView, location: location)
        
        if selectedHigh == nil || selectedEntry == nil || sliceLayer == nil { return }
        
        if  oldLayer == sliceLayer { return }
        
        let completionBlock =
        {
            pieChart.highlightValue(selectedHigh, callDelegate: false)
        }
        
        HelperFunctions.sliceOut(sliceLayer: sliceLayer!, high: selectedHigh!, chart: pieChart, duration: duration, completionBlock: completionBlock)
        
        let oldHigh = oldLayer?.indices?[0]
        
        HelperFunctions.sliceIn(sliceLayer: oldLayer!, high: oldHigh!, chart: pieChart, duration: duration, completionBlock: nil)

        oldLayer = sliceLayer
    }
    
    func touchEventEnded(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: SliceLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
        
        Log.info("Touch Event Ended ")
        
        var selectedLayer:SliceLayer? = sliceLayer
        
        let pieChart = chartView as! PieChartView
        
        let location = getLocation(touches, chart: chartView)
        
        var (selectedHigh, selectedEntry) = HelperFunctions.getHighAndEntryForPoint(chart: chartView, location: location)
        
        if selectedHigh == nil {
            selectedLayer = oldLayer
            selectedHigh = oldLayer?.indices?[0]
        }
        
        if selectedLayer == nil {
            oldLayer = nil
            return
        }
        
        selectedEntry = pieChart.data?.entryForHighlight(selectedHigh!)
        
        let completionBlock = {
            
            selectedEntry?.layerEnabled = false
            
            HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
            
            pieChart.setNeedsDisplay()
            
            self.oldLayer = nil
        }
        
        HelperFunctions.sliceIn(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: duration, completionBlock: completionBlock)

    }
    
    
    func touchEventCancelled(_ chartView: ChartViewBase, entry: ChartDataEntry?, sliceLayer: SliceLayer?, _ touches: Set<NSUITouch>, withEvent event: NSUIEvent?) {
        
        Log.info("Touch Event Cancelled ")
    }
    
    func getLocation(_ touches: Set<NSUITouch>, chart: ChartViewBase) -> CGPoint
    {
        let touch = touches.first as NSUITouch!
    
        let touchLocation = touch?.location(in: chart)
        
        return touchLocation!
    }
}
