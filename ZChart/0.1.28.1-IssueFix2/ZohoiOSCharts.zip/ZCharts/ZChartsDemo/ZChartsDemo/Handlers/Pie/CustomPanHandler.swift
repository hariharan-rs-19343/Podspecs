//
//  CustomPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 13/06/18.
//  Copyright © 2018 charts. All rights reserved.
//


import UIKit
import zchart

class CustomPanHandler: NSObject,EventHandler
{
    var pieRadChange:CGFloat = 0
    var oldEntry : ChartDataEntry? = nil
    var oldLayer:SliceLayer? = nil
    var high:Highlight? = Highlight()
    var oldhigh:Highlight? = Highlight()
    var angle:CGFloat = 0
    var dist:CGFloat = 0
    var distcal:CGFloat = 0
    var startAngle:CGFloat = 0
    var totAngle:CGFloat = 0
    var angleLength:CGFloat = 0
    var absAngle:CGFloat = 0
    var location:CGPoint = CGPoint()
    var dataInd:Int = 0
    var pieChartInstance:ChartViewBase = ChartViewBase()
    var sliceDisplayLink:CADisplayLink!
    var changingFactor:CGFloat = 1
    
    var filterLayer :SliceLayer? = nil
    var filterhigh :Highlight? = Highlight()
    
    func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    func  getMidAngle(high:Highlight) -> CGFloat
    {
        let xIndex = Int((high.x))
        
        let pieChart = pieChartInstance as! PieChartView
        
        let pieRad = pieChartInstance as! PieRadarChartViewBase
        
        let drawAngles = pieChart.drawAngles
        
        let absAngles = pieChart.absoluteAngles
        
        angle /= CGFloat(pieRad.chartAnimator.phaseY)
        
        let angleLength = drawAngles[xIndex]
        let absAngle = absAngles[xIndex]
        
        totAngle = pieRad.rotationAngle + absAngle
        
        startAngle = (totAngle - angleLength)
        
        var midAngle = (startAngle + totAngle ) / 2
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        return midAngle
    }
    
    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint) {
        var (selectedHigh, selectedEntry) = HelperFunctions.getHighAndEntryForRecognizer(chart: chartView, recognizer: recognizer!)
        
        
        
        let pieChart = chartView as! PieChartView
        let pieRadar = chartView as! PieRadarChartViewBase
        let selectedLayer:SliceLayer? = entryLayer as? SliceLayer
        pieChartInstance = chartView
        //        pieChart.highlightPerTapEnabled = true
        
        if(HelperFunctions.getAllSliceLayer(pie: pieRadar).count <= 1)
        {
            
            pieRadar.highlightValue(nil)
            HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
            pieChart.highlightPerTapEnabled = false
            
            return
        }
        else
        {
            pieChart.highlightPerTapEnabled = true
        }
        
        
        if recognizer?.state == NSUIGestureRecognizerState.began
        {
            
            if SliceOutHandler.prevHigh != nil
            {
                let prev = SliceOutHandler.prevHigh
                let entry = pieChart.data?.entryForHighlight(prev!)
                
                entry?.filterEnabled = false
                SliceOutHandler.prevHigh = nil
            }
            
            pieRadChange = pieChart.radius
            pieRadar.resetVelocity()
            
            pieRadar.sampleVelocity(touchLocation: location)
            if selectedHigh == nil || selectedEntry == nil { return }
            
        
            pieChart.data?.setDrawValues(false)
            
            
            oldLayer = selectedLayer
            
            //            HelperFunctions.sliceOut(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0.3, completionBlock: nil)
            //
            //            for layer in HelperFunctions.getAllSliceLayer(pie: pieChart)
            //            {
            //                if layer != selectedLayer
            //                {
            //                    HelperFunctions.changeRadiusAnimator(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.2, fromRadius: pieChart.radius, toRadius: pieChart.radius-20, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
            //                }
            //            }
            location = (recognizer?.location(in: pieRadar))!
            oldEntry = entry
            high = pieRadar.getHighlightByTouchPoint(location)
            
            if high != nil {
                
                let chartEntry = pieRadar.data?.entryForHighlight(high!)
                
                dataInd = (pieRadar.data?.dataSets[0].entryIndex(entry: chartEntry!))!
                
                angle = pieRadar.angleForPoint(x: (high?.xPx)! ,y: (high?.yPx)!)
                
                let pieChart = pieRadar as! PieChartView
                
                angle = getMidAngle(high: high!)
                
                pieChart.arrowShow = false
                
                changingFactor = 21
                
            }
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.changed
        {
            
            
            if oldLayer == nil { return }
            
            let changeLocation = (recognizer?.location(in: pieRadar))!
            
            if high != nil{
                
                angle = getMidAngle(high: high!)
                
                if  ((315 < angle  && angle <= 360)||(0 <= angle && angle <= 45) )
                {
                    changingFactor = changingFactor + (changeLocation.x - location.x)
                }
                else if  (45 < angle  && angle <= 135 )
                {
                    changingFactor = changingFactor + (changeLocation.y - location.y)
                }
                else if  (135 < angle  && angle <= 225)
                {
                    changingFactor = changingFactor - (changeLocation.x - location.x)
                }
                else if  (225 < angle  && angle <= 315 )
                {
                    changingFactor = changingFactor - (changeLocation.y - location.y)
                }
                
                
                
                if(changingFactor < 0)
                {
                    pieRadChange = pieChart.radius + changingFactor
                    
                    filterLayer = oldLayer
                    filterhigh = high
                    HelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, high: high!, chart: pieChart, duration: 0, fromRadius: pieChart.radius, toRadius: pieChart.radius+changingFactor, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                    
                    changingFactor = 0.0
                    
                    
                    pieRadar.sampleVelocity(touchLocation: changeLocation)
                    
                    return
                    
                }
                else{
                    pieRadChange = pieChart.radius + changingFactor
                }
                oldhigh = high
                let newx = pieChart.centerCircleBox.x + (changingFactor) * cos(angle.radians())
                
                let newy = pieChart.centerCircleBox.y + (changingFactor) * sin(angle.radians())
                
                if(changingFactor <= 21)
                {
                    HelperFunctions.sliceMove(sliceLayer: oldLayer!, high: high!, chart: pieChart, duration: 0, nx:newx, ny:newy, completionBlock: nil)
                }
                else
                {
                    
                    let newx = pieChart.centerCircleBox.x + 21 * cos(angle.radians())
                    
                    let newy = pieChart.centerCircleBox.y + 21 * sin(angle.radians())
                    
                    HelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, high: high!, chart: pieChart, duration: 0, fromRadius: pieChart.radius, toRadius: pieChart.radius+changingFactor-21, pieCenter: CGPoint(x: newx, y: newy), completionBlock: nil)
                    
                }
                location = changeLocation
                pieRadar.sampleVelocity(touchLocation: location)
            }
        }
        else if recognizer?.state == NSUIGestureRecognizerState.ended
        {
            if oldLayer == nil {
                return
            }
            let endLocation = (recognizer?.location(in: pieRadar))!
            
            pieRadar.sampleVelocity(touchLocation: endLocation)
            
            let velocityCalculated = pieRadar.calculateVelocity()
            
            
            if  pieRadChange < (pieChart.radius-20) //(velocityCalculated < -10 && changingFactor < (pieChart.radius/8)) ||
            {
                let completionBlock = {
                    HelperFunctions.deleteSliceWithNoFill(sliceLayer: self.filterLayer!, high: self.filterhigh!, chart: pieChart, duration: 0.3, animation: .linear)
                    self.filterLayer?.chartEntry?.layerEnabled = false
                    pieChart.highlightValue(nil, callDelegate: true)
                    if (pieChart.data?.valuesEnabled)! {
                        pieChart.data?.setDrawValues(true)
                    }
                }
                
                HelperFunctions.changeRadiusAnimator(sliceLayer: filterLayer!, high: self.filterhigh!, chart: pieChart, duration: 0.3, fromRadius: pieRadChange, toRadius: 0, pieCenter: pieChart.centerCircleBox, completionBlock: completionBlock)
                
            }
            else if ((velocityCalculated > 20 && changingFactor > (pieChart.radius/4)) || (pieRadar.distance(from: pieChart.centerCircleBox , to: endLocation) >= pieChart.radius))
            {
                
                for layer in HelperFunctions.getAllSliceLayer(pie: pieChart)
                {
                    if layer != oldLayer
                    {
                        HelperFunctions.changeRadiusAnimator(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.3, fromRadius: pieChart.radius, toRadius: 0, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                        
                    }
                    else
                    {
                        HelperFunctions.sliceIn(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.3, completionBlock: nil)
                    }
                }
                
                
                DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(400), execute: {
                    
                    self.oldEntry?.layerEnabled = false
                    HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
                    pieChart.setNeedsDisplay()
                    if (pieChart.data?.valuesEnabled)! {
                        pieChart.data?.setDrawValues(true)
                    }
                    pieRadar.drillEntry(selectedEntry: self.oldEntry!)
                    
                })
                
            }
            else{
                
                selectedEntry = pieChart.data?.entryForHighlight(selectedHigh!)
                
                
                
                let completionBlock = {
                    
                    
                    
                    selectedEntry?.layerEnabled = false
                    
                    HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
                    
                    
                    
                    // use this method only when outercircle is enabled
                    
                    //                    HelperFunctions.removeOuterCircleLayer(pieChart:(chartView as! PieRadarChartViewBase))
                    
                    
                    
                    if (pieChart.data?.valuesEnabled)!
                        
                    {
                        
                        pieChart.data?.setDrawValues(true)
                        
                    }
                    
                    
                    
                    pieChart.setNeedsDisplay()
                    
                    
                    
                    self.oldLayer = nil
                    
                    if (pieChart.data?.valuesEnabled)! {
                        pieChart.data?.setDrawValues(true)
                    }
                    
                }
                
                
                
                HelperFunctions.sliceIn(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0.3, completionBlock: completionBlock)
                
                
                
            }
            
            
        }
        
    }
    
}
extension CGFloat {
    func radians() -> CGFloat {
        let b = .pi * (self/180)
        return b
    }
}



