//
//  CustomLongPressHandler1.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 16/10/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class CustomLongPressHandler1: NSObject,EventHandler
{
    var pieRadChange:CGFloat = 0
    var oldLayer:SliceLayer? = nil
    var high:Highlight? = Highlight()
    var oldhigh:Highlight? = Highlight()
    var angle:CGFloat = 0
    var dist:CGFloat = 0
    var distcal:CGFloat = 0
    var startAngle:CGFloat = 0
    var totAngle:CGFloat = 0
    var angleLength:CGFloat = 0
    var absAngle:CGFloat = 0
    var location:CGPoint = CGPoint()
    var dataInd:Int = 0
    var pieChartInstance:ChartViewBase = ChartViewBase()
    var sliceDisplayLink:CADisplayLink!
    var changingFactor:CGFloat = 1
    
    var filterLayer :SliceLayer? = nil
    var filterhigh :Highlight? = Highlight()
    
    func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    func  getMidAngle(high:Highlight) -> CGFloat
    {
        let xIndex = Int((high.x))
        
        let pieChart = pieChartInstance as! PieChartView
        
        let pieRad = pieChartInstance as! PieRadarChartViewBase
        
        let drawAngles = pieChart.drawAngles
        
        let absAngles = pieChart.absoluteAngles
        
        angle /= CGFloat(pieRad.chartAnimator.phaseY)
        
        let angleLength = drawAngles[xIndex]
        let absAngle = absAngles[xIndex]
        
        totAngle = pieRad.rotationAngle + absAngle
        
        startAngle = (totAngle - angleLength)
        
        var midAngle = (startAngle + totAngle ) / 2
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        return midAngle
    }
    
    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        var (selectedHigh, selectedEntry) = HelperFunctions.getHighAndEntryForRecognizer(chart: chartView, recognizer: recognizer!)
        
        let duration:TimeInterval = 0.2
        
        let pieChart = chartView as! PieChartView
        let pieRadar = chartView as! PieRadarChartViewBase
        var selectedLayer:SliceLayer? = entryLayer as? SliceLayer
        pieChartInstance = chartView
        //        pieChart.highlightPerTapEnabled = true
        
        if(HelperFunctions.getAllSliceLayer(pie: pieRadar).count <= 1)
        {
            
            pieRadar.highlightValue(nil)
            HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
            pieChart.highlightPerTapEnabled = false
            
            return
        }
        else
        {
            pieChart.highlightPerTapEnabled = true
        }
        
        
        if recognizer?.state == NSUIGestureRecognizerState.began
        {
            pieChart.data?.setDrawValues(false)
            pieRadChange = pieChart.radius
            pieRadar.resetVelocity()
            
            pieRadar.sampleVelocity(touchLocation: location)
            pieChart.highlightValue(selectedHigh, callDelegate: false)
            if selectedHigh == nil || selectedEntry == nil { return }
            
            oldLayer = selectedLayer
            
            HelperFunctions.sliceOut(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: duration, completionBlock: nil)
            
            for layer in HelperFunctions.getAllSliceLayer(pie: pieChart)
            {
                if layer != selectedLayer
                {
//                    HelperFunctions.changeRadius(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: duration, radiusChange: -20, completionBlock: nil)
                    
                    HelperFunctions.changeRadiusAnimator(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: duration, fromRadius: pieChart.radius, toRadius: pieChart.radius-20, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                }
            }
            location = (recognizer?.location(in: pieRadar))!
            distcal = pieRadar.distance(from: pieChart.centerCircleBox, to: location)
            high = pieRadar.getHighlightByTouchPoint(location)
            
            if high != nil {
                
                let chartEntry = pieRadar.data?.entryForHighlight(high!)
                
                dataInd = (pieRadar.data?.dataSets[0].entryIndex(entry: chartEntry!))!
                
                angle = pieRadar.angleForPoint(x: (high?.xPx)! ,y: (high?.yPx)!)
                
                let pieChart = pieRadar as! PieChartView
                
                angle = getMidAngle(high: high!)
                
                
                pieChart.arrowShow = false
                
                changingFactor = 21
                
            }
            
            // use this method only when outercircle is enabled
            HelperFunctions.changeOuterCircleLayer(pieRadChart: chartView as! PieRadarChartViewBase, radius: -20)
        }
        else if recognizer?.state == NSUIGestureRecognizerState.changed
        {
            
            
            if selectedLayer == nil { return }
            
            let changeLocation = (recognizer?.location(in: pieRadar))!
            
            if oldLayer == selectedLayer {
                high = pieRadar.getHighlightByTouchPoint(changeLocation)
                
                if high != nil{
                    
                    angle = getMidAngle(high: high!)
                    dist = abs(pieRadar.distance(from: changeLocation, to: pieChart.centerCircleBox) - distcal)
                    let angle_at_point = pieChart.angleForPoint(x: changeLocation.x, y: changeLocation.y)
                    
                    if ((angle_at_point > (angle-10)) && (angle_at_point < (angle+10)))
                    {
                        if  ((315 < angle  && angle <= 360)||(0 <= angle && angle <= 45) )
                        {
                            changingFactor = changingFactor + (changeLocation.x - location.x)
                        }
                        else if  (45 < angle  && angle <= 135 )
                        {
                            changingFactor = changingFactor + (changeLocation.y - location.y)
                        }
                        else if  (135 < angle  && angle <= 225)
                        {
                            changingFactor = changingFactor - (changeLocation.x - location.x)
                        }
                        else if  (225 < angle  && angle <= 315 )
                        {
                            changingFactor = changingFactor - (changeLocation.y - location.y)
                        }
                        
                        
                        
                        if(changingFactor < 0)
                        {
                            pieRadChange = pieChart.radius + changingFactor
                            
                            filterLayer = selectedLayer
                            filterhigh = selectedHigh
//                            HelperFunctions.changeRadius(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0, radiusChange: changingFactor, completionBlock: nil)
                            
                            HelperFunctions.changeRadiusAnimator(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0, fromRadius: pieChart.radius, toRadius: pieChart.radius+changingFactor, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                            
                           /* let endPath = SliceLayer.getSlicePath(pieChart: pieChart, high: selectedHigh!, pieCenter: pieChart.centerCircleBox, radius: pieChart.radius+changingFactor)
                            
                            selectedLayer?.path = endPath.cgPath*/
                            
                            changingFactor = 0.0
                            
                            
                            pieRadar.sampleVelocity(touchLocation: changeLocation)
                            
                            return
                            
                        }
                        else{
                            pieRadChange = pieChart.radius + changingFactor
                            //  HelperFunctions.changeRadius(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0, radiusChange: 0, completionBlock: nil)
                        }
                        oldhigh = high
                        let newx = pieChart.centerCircleBox.x + (changingFactor) * cos(angle.radians())
                        
                        let newy = pieChart.centerCircleBox.y + (changingFactor) * sin(angle.radians())
                        
                        if(changingFactor <= 21)
                        {
                            HelperFunctions.sliceMove(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0, nx:newx, ny:newy, completionBlock: nil)
                        }
                        else
                        {
                            
                            let newx = pieChart.centerCircleBox.x + 21 * cos(angle.radians())
                            
                            let newy = pieChart.centerCircleBox.y + 21 * sin(angle.radians())
                            
                            let sliceCenter = CGPoint(x: newx, y: newy)

                            HelperFunctions.changeRadiusAnimator(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0, fromRadius: pieRadChange, toRadius: pieChart.radius+changingFactor-21, pieCenter:sliceCenter, completionBlock: nil)
                            
               /*             let endPath = SliceLayer.getSlicePath(pieChart: pieChart, high: selectedHigh!, pieCenter: sliceCenter, radius: pieChart.radius+changingFactor-21)
                            
                            selectedLayer?.path = endPath.cgPath*/
                            
                            
                           /* CATransaction.begin()
                            
                            let anim = CABasicAnimation(keyPath: "path")
                            let endPath = SliceLayer.getSlicePath(pieChart: pieChart, high: high!, pieCenter: CGPoint(x: newx, y: newy), radius: pieChart.radius+changingFactor-21)
                            anim.fromValue = selectedLayer!.path
                            anim.toValue = endPath.cgPath
                            anim.duration = 0
                            anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                            CATransaction.setCompletionBlock(nil)
                            selectedLayer?.add(anim, forKey: "changeRadius")
                            
                            CATransaction.commit()
                            
                            selectedLayer?.path = endPath.cgPath*/
                            
                            
                        }
                    }
                    location = changeLocation
                    pieRadar.sampleVelocity(touchLocation: location)
                }
                
            }
            else{
                
                let layers = HelperFunctions.getAllSliceLayer(pie: pieRadar)
                let curIndex = layers.index(of: selectedLayer!)
                
                let oldIndex = layers.index(of: oldLayer!)
                
                
                //pieRadar.getHighlightByTouchPoint(<#T##pt: CGPoint##CGPoint#>)
                if(abs(curIndex! - oldIndex!) == 1)||((abs(curIndex! - oldIndex!)+1 == layers.count))
                {
                    if  pieRadChange > (pieChart.radius-20) //(velocityCalculated < -10 && changingFactor < (pieChart.radius/8)) ||
                    {
                        let generator = UISelectionFeedbackGenerator()
                        generator.selectionChanged()
                        pieRadar.resetVelocity()
                        pieRadar.sampleVelocity(touchLocation: changeLocation)
                        pieChart.highlightValue(selectedHigh, callDelegate: false)
                        HelperFunctions.sliceOut(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: duration, completionBlock: nil)
                        
                        
                        oldhigh = oldLayer?.indices?[0]
                        
                        HelperFunctions.sliceIn(sliceLayer: oldLayer!, high: oldhigh!, chart: pieChart, duration: duration, completionBlock: nil)
                        
//                        HelperFunctions.changeRadius(sliceLayer: oldLayer!, high: oldhigh!, chart: pieChart, duration: duration, radiusChange: -20, completionBlock: nil)
                        
                        HelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, high: oldhigh!, chart: pieChart, duration: duration, fromRadius: pieChart.radius, toRadius: pieChart.radius-20, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                        
                        oldLayer = selectedLayer
                        changingFactor = 21
                    }
                }
                
                
            }
        }
        else if recognizer?.state == NSUIGestureRecognizerState.ended
        {
            if selectedLayer == nil {
                selectedLayer = oldLayer
                selectedHigh = oldLayer?.indices?[0]
            }
            
            if selectedLayer == nil {
                oldLayer = nil
                return
            }
            
            selectedEntry = pieChart.data?.entryForHighlight(selectedHigh!)
            
            let endLocation = (recognizer?.location(in: pieRadar))!
            
            pieRadar.sampleVelocity(touchLocation: endLocation)
            
            let velocityCalculated = pieRadar.calculateVelocity()
            
            
            if  pieRadChange < (pieChart.radius-20) //(velocityCalculated < -10 && changingFactor < (pieChart.radius/8)) ||
            {
                let completionBlock = {
                    // use this method only when outercircle is enabled
                    HelperFunctions.removeOuterCircleLayer(pieChart:(chartView as! PieRadarChartViewBase))
                    
                    HelperFunctions.deleteSliceWithNoFill(sliceLayer: self.filterLayer!, high: self.filterhigh!, chart: pieChart, duration: 0.2, animation: .linear)
                    self.filterLayer?.chartEntry?.layerEnabled = false
                    pieChart.highlightValue(nil, callDelegate: true)
                    
                    
                }
                
                HelperFunctions.changeRadiusAnimator(sliceLayer: filterLayer!, high: self.filterhigh!, chart: pieChart, duration: 0.4, fromRadius: pieRadChange, toRadius: 0, pieCenter: pieChart.centerCircleBox, completionBlock: completionBlock)
                
            }
            else if ((velocityCalculated > 20 && changingFactor > (pieChart.radius/4)) || (pieRadar.distance(from: pieChart.centerCircleBox , to: endLocation) >= pieChart.radius))
            {
                
                for layer in HelperFunctions.getAllSliceLayer(pie: pieChart)
                {
                    if layer != selectedLayer
                    {
                        HelperFunctions.changeRadiusAnimator(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.5, fromRadius: pieChart.radius, toRadius: 0, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                        //  HelperFunctions.changeRadius(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.2, radiusChange: -(pieChart.radius), completionBlock: nil)
                    }
                    else
                    {
                        HelperFunctions.sliceIn(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.5, completionBlock: nil)
                    }
                }
                
                // use this method only when outercircle is enabled
                HelperFunctions.changeOuterCircleLayer(pieRadChart: chartView as! PieRadarChartViewBase, radius: 0)
                
                
                DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(600), execute: {
                    
                    //                    HelperFunctions.deleteSliceWithNoFill(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0.5, animation: .linear)
                    selectedEntry?.layerEnabled = false
                    HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
                    
                    // use this method only when outercircle is enabled
                    HelperFunctions.removeOuterCircleLayer(pieChart:(chartView as! PieRadarChartViewBase))
                    
                    if (pieChart.data?.valuesEnabled)!
                    {
                        pieChart.data?.setDrawValues(true)
                    }
                    
                    pieChart.setNeedsDisplay()
                    pieRadar.drillEntry(selectedEntry: selectedEntry!)
                    
                })
                
            }
            else{
                
                selectedEntry = pieChart.data?.entryForHighlight(selectedHigh!)
                
                let completionBlock = {
                    
                    selectedEntry?.layerEnabled = false
                    HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
                    
                    // use this method only when outercircle is enabled
                    HelperFunctions.removeOuterCircleLayer(pieChart:(chartView as! PieRadarChartViewBase))
                    
                    if (pieChart.data?.valuesEnabled)!
                    {
                        pieChart.data?.setDrawValues(true)
                    }
                    
                    pieChart.setNeedsDisplay()
                    
                    self.oldLayer = nil
                    
                }
                
                HelperFunctions.sliceIn(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: duration, completionBlock: completionBlock)
            }
            
        }
        
    }
    
}
//extension CGFloat {
//    func radians() -> CGFloat {
//        let b = CGFloat(M_PI) * (self/180)
//        return b
//    }
//}



