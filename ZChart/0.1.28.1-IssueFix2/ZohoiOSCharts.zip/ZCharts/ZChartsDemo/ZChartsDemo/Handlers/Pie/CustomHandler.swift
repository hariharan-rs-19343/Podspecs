//
//  CustomHandler.swift
//  ZCharts
//
//  Created by Aravinth T on 08/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class CustomHandler: NSObject,EventHandler {

    func getEventHandlerType() -> EventHandlerType {
      return EventHandlerType.custom
    }
    
    var oldLayer:SliceLayer? = nil
    
    let radiusChange:CGFloat = 10
    
    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint) {
       
        var sliceLayer = entryLayer as! SliceLayer
        let chart = chartView
        
        let pie:PieRadarChartViewBase = chart as! PieRadarChartViewBase
        
        let pieChart = chart as! PieChartView
//        let loc = recognizer.location(in: chart)
        let loc = touchLocation
        var high = chart.getHighlightByTouchPoint(loc)
        //var sliceLayer:SliceLayer? = HelperFunctions.getSliceLayerInPoint(pie: pieChart, loc: loc)
        
        if (high == nil && sliceLayer != nil) || (high != nil && sliceLayer == nil) || (high != nil && sliceLayer != nil)
        {
            
            if high == nil
            {
                high = sliceLayer.indices?[0]
            }
            
            if oldLayer == nil
            {
                increaseRadius(pieChart: pieChart, sliceLayer: sliceLayer)
            }
            else if oldLayer != nil
            {
                if oldLayer == sliceLayer
                {
                    decreaseRadius(pieChart: pieChart, sliceLayer: oldLayer)
                }
                else if oldLayer != sliceLayer
                {
                   decreaseRadius(pieChart: pieChart, sliceLayer: oldLayer)
                   increaseRadius(pieChart: pieChart, sliceLayer: sliceLayer)
                }
            }
            
            
        }
            
        else if high == nil && sliceLayer == nil && pie.layer.sublayers != nil
        {
        
            for layer in pie.layer.sublayers!
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: SliceLayer.self)
                {
                    let sliceLayer = caLayer as! SliceLayer
                    decreaseRadius(pieChart: pieChart, sliceLayer: sliceLayer)
                }
            }
            
        }

    }
    
    func decreaseRadius(pieChart: PieChartView, sliceLayer: SliceLayer?)
    {
        let high = sliceLayer?.indices?[0]
        
        let chartEntry = pieChart.data?.entryForHighlight(high!)
        
        let completionBlock = {
            
            chartEntry?.layerEnabled = false
            
            chartEntry?.filterEnabled = false
            
            sliceLayer?.removeFromSuperlayer()
            
            pieChart.setNeedsDisplay()
            
            self.oldLayer = nil
        }
        
//        HelperFunctions.changeRadius(sliceLayer: sliceLayer!, high: high!, chart: pieChart, duration: 0.5, radiusChange: 0, completionBlock: completionBlock)
        
        HelperFunctions.changeRadiusAnimator(sliceLayer: sliceLayer!, high: high!, chart: pieChart, duration: 0.5, fromRadius: pieChart.radius, toRadius: pieChart.radius, pieCenter: pieChart.centerCircleBox, completionBlock: completionBlock)
    }
    
    func increaseRadius(pieChart: PieChartView, sliceLayer: SliceLayer?)
    {
        
        let high = sliceLayer?.indices?[0]
        
        let completionBlock = {
            
            self.oldLayer = sliceLayer
        }
        
//        HelperFunctions.changeRadius(sliceLayer: sliceLayer!, high: high!, chart: pieChart, duration: 0.5, radiusChange: radiusChange, completionBlock: completionBlock)
        
        HelperFunctions.changeRadiusAnimator(sliceLayer: sliceLayer!, high: high!, chart: pieChart, duration: 0.5, fromRadius: pieChart.radius, toRadius: pieChart.radius + radiusChange, pieCenter: pieChart.centerCircleBox, completionBlock: completionBlock)
    }
    
}
