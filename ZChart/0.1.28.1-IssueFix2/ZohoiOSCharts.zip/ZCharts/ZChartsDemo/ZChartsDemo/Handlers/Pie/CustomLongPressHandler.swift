//
//  CustomLongPressHandler.swift
//  ZCharts
//
//  Created by Aravinth T on 11/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class CustomLongPressHandler: NSObject,EventHandler
{
    var pieRadChange:CGFloat = 0
    var oldLayer:SliceLayer? = nil
    var high:Highlight? = Highlight()
    var oldhigh:Highlight? = Highlight()
    var angle:CGFloat = 0
    
    var startAngle:CGFloat = 0
    var totAngle:CGFloat = 0
    var angleLength:CGFloat = 0
    var absAngle:CGFloat = 0
    var location:CGPoint = CGPoint()
    
    var pieChartInstance:ChartViewBase = ChartViewBase()
    
    var changingFactor:CGFloat = 1
    
    func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    func  getMidAngle(high:Highlight) -> CGFloat
    {
        let xIndex = Int((high.x))
        
        let pieChart = pieChartInstance as! PieChartView
        
        let pieRad = pieChartInstance as! PieRadarChartViewBase
        
        let drawAngles = pieChart.drawAngles
        
        let absAngles = pieChart.absoluteAngles
        
        angle /= CGFloat(pieRad.chartAnimator.phaseY)
        
        let angleLength = drawAngles[xIndex]
        let absAngle = absAngles[xIndex]
        
        totAngle = pieRad.rotationAngle + absAngle
        
        startAngle = (totAngle - angleLength)
        
        var midAngle = (startAngle + totAngle ) / 2
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        return midAngle
    }
    
    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        var (selectedHigh, selectedEntry) = HelperFunctions.getHighAndEntryForRecognizer(chart: chartView, recognizer: recognizer!)
        
        let duration:TimeInterval = 0.4
        
        let pieChart = chartView as! PieChartView
        let pieRadar = chartView as! PieRadarChartViewBase
        var selectedLayer:SliceLayer? = entryLayer as? SliceLayer
        pieChartInstance = chartView
        //        pieChart.highlightPerTapEnabled = true
        
        if(HelperFunctions.getAllSliceLayer(pie: pieRadar).count <= 1)
        {
            
            pieRadar.highlightValue(nil)
            HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
            pieChart.highlightPerTapEnabled = false
            
            return
        }
        else
        {
            pieChart.highlightPerTapEnabled = true
        }
        
        if recognizer?.state == NSUIGestureRecognizerState.began
        {
            
            if SliceOutHandler.prevHigh != nil
            {
                let prev = SliceOutHandler.prevHigh
                let entry = pieChart.data?.entryForHighlight(prev!)
                
                entry?.filterEnabled = false
                SliceOutHandler.prevHigh = nil
            }
            
            pieRadChange = pieChart.radius
            pieRadar.resetVelocity()
            
            pieRadar.sampleVelocity(touchLocation: location)
            if selectedHigh == nil || selectedEntry == nil { return }
            
            
            pieChart.data?.setDrawValues(false)
            
            
            oldLayer = selectedLayer
            
            HelperFunctions.sliceOut(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0.3, completionBlock: nil)
            
            for layer in HelperFunctions.getAllSliceLayer(pie: pieChart)
            {
                if layer != selectedLayer
                {
                    HelperFunctions.changeRadiusAnimator(sliceLayer: layer, high: (layer.indices?[0])!, chart: pieChart, duration: 0.2, fromRadius: pieChart.radius, toRadius: pieChart.radius-20, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                }
            }
            location = (recognizer?.location(in: pieRadar))!
            
            high = pieRadar.getHighlightByTouchPoint(location)
            
            if high != nil {
                
                angle = pieRadar.angleForPoint(x: (high?.xPx)! ,y: (high?.yPx)!)
                
                let pieChart = pieRadar as! PieChartView
                
                angle = getMidAngle(high: high!)
                
                pieChart.arrowShow = false
                
                changingFactor = 21
                
            }
            
            pieChart.highlightValue(high, callDelegate: false)
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.changed
        {
            
            
            if selectedLayer == nil { return }
            
            let changeLocation = (recognizer?.location(in: pieRadar))!
            
            let layers = HelperFunctions.getAllSliceLayer(pie: pieRadar)
            let curIndex = layers.index(of: selectedLayer!)
            
            let oldIndex = layers.index(of: oldLayer!)
            
            if(abs(curIndex! - oldIndex!) == 1)||((abs(curIndex! - oldIndex!)+1 == layers.count))
            {
                if  pieRadChange > (pieChart.radius-30) //(velocityCalculated < -10 && changingFactor < (pieChart.radius/8)) ||
                {
                    let generator = UISelectionFeedbackGenerator()
                    generator.selectionChanged()
                    pieRadar.resetVelocity()
                    pieRadar.sampleVelocity(touchLocation: changeLocation)
                    HelperFunctions.sliceOut(sliceLayer: selectedLayer!, high: selectedHigh!, chart: pieChart, duration: 0.2, completionBlock: nil)
                    
                    pieChart.highlightValue(selectedHigh!, callDelegate: false)
                    oldhigh = oldLayer?.indices?[0]
                    
                    HelperFunctions.sliceIn(sliceLayer: oldLayer!, high: oldhigh!, chart: pieChart, duration: 0.2, completionBlock: nil)
                    
                    HelperFunctions.changeRadiusAnimator(sliceLayer: oldLayer!, high: oldhigh!, chart: pieChart, duration: duration, fromRadius: pieChart.radius, toRadius: pieChart.radius-20, pieCenter: pieChart.centerCircleBox, completionBlock: nil)
                    
                    oldLayer = selectedLayer
                    changingFactor = 21
                }
            }
            
        }
        else if recognizer?.state == NSUIGestureRecognizerState.ended
        {
            if selectedLayer == nil {
                selectedLayer = oldLayer
                selectedHigh = oldLayer?.indices?[0]
            }
            
            if selectedLayer == nil {
                oldLayer = nil
                return
            }
            
            selectedEntry = pieChart.data?.entryForHighlight(selectedHigh!)
            
            let endLocation = (recognizer?.location(in: pieRadar))!
            
            pieRadar.sampleVelocity(touchLocation: endLocation)
            
            if SliceOutHandler.prevHigh != nil
            {
                let prev = SliceOutHandler.prevHigh
                let entry = pieChart.data?.entryForHighlight(prev!)
                
                entry?.filterEnabled = false
                
            }
            
            selectedEntry = pieChart.data?.entryForHighlight(selectedHigh!)
            
            selectedLayer?.chartEntry?.filterEnabled = true
            
            let sliceRadius = (pieChart.radius/8)
            
            let midAnglee = getMidAngle(high: selectedHigh!)
            
            let newx = pieChart.centerCircleBox.x + (sliceRadius * cos(midAnglee.radians()))
            
            let newy = pieChart.centerCircleBox.y + (sliceRadius * sin(midAnglee.radians()))
            
            selectedLayer?.chartEntry?.centerChanged = CGPoint(x:newx, y:newy)
            
            SliceOutHandler.prevHigh = selectedHigh!
            
            let completionBlock = {
                
                selectedEntry?.layerEnabled = false
                
                HelperFunctions.removeAllSliceLayers(pieChart: pieChart)
                pieChart.setNeedsDisplay()
                
                self.oldLayer = nil
                
                if (pieChart.data?.valuesEnabled)! {
                    pieChart.data?.setDrawValues(true)
                }
            }
            completionBlock()
        }
        
    }
    
}


