//
//  FunnelLongPressListener.swift
//  ZCharts
//
//  Created by Aravinth T on 09/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

import Foundation

import zchart

class FunnelLongPressListener: NSObject,EventHandler {
    
    var prevChartEntry:ChartDataEntry? = nil
    
    var toggleAscending:Bool = true
    
    func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }

    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint) {
     
        let funnelChart =  chartView as! FunnelChartView
        
        if recognizer?.state == .began {
            
            self.prevChartEntry = nil
            callHighlight(entry: entry, funnelChart: funnelChart)
            
        } else if recognizer?.state == .changed {
            
            if prevChartEntry != nil && entry == nil {
//                resetLastselectedToNil(chart: funnelChart)
            } else if (prevChartEntry == nil && entry != nil) || (prevChartEntry != nil && entry != nil && prevChartEntry != entry) {
                callHighlight(entry: entry, funnelChart: funnelChart)
            }
            
        } else if recognizer?.state == .ended {
//             resetLastselectedToNil(chart: chartView)
        }
    }
    
    func callHighlight(entry: ChartDataEntry?, funnelChart: FunnelChartView){
        if entry != nil {
            funnelChart.highlightFunnelLayerForEntry(entry: entry!)
            prevChartEntry = entry
        }
    }
    
    func resetLastselectedToNil(chart:ChartViewBase) {
        chart.lastSelected = nil
        chart.highlightValue(nil, callDelegate: false, redrawRequired: false)
        self.prevChartEntry = nil
    }
    
}
