//
//  LineSingleTouchPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 06/03/18.
//  Copyright © 2018 charts. All rights reserved.
//


import UIKit
import zchart

open class LineSingleTouchPanHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.linePan
    }
    
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barLine = chart as! BarLineChartViewBase
        
        
        if recognizer.state == NSUIGestureRecognizerState.began //&& recognizer.nsuiNumberOfTouches() > 0
        {
            
            
            barLine.stopDeceleration()
            
            if barLine.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barLine._lastPanPoint = recognizer.translation(in: barLine)
            
            barLine._isDragging = true
            
            
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            
            barLine._isDragging = true
            let originalTranslation = recognizer.translation(in: barLine)
            let translation = CGPoint(x: originalTranslation.x - barLine._lastPanPoint.x, y: originalTranslation.y - barLine._lastPanPoint.y)
            
            let _ = barLine.performPanChange(translation: translation)
            
            barLine._lastPanPoint = originalTranslation
            
            
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            barLine._isDragging = true
            
            if recognizer.state == NSUIGestureRecognizerState.ended && barLine.isDragDecelerationEnabled
            {
                barLine.stopDeceleration()
                
                barLine._decelerationLastTime = CACurrentMediaTime()
                barLine._decelerationVelocity = recognizer.velocity(in: barLine)
                
                barLine._decelerationDisplayLink = NSUIDisplayLink(target: barLine, selector: #selector(BarLineChartViewBase.decelerationLoop))
                barLine._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoopMode.commonModes)

            }
            
            barLine._isDragging = false
            
            
            if barLine._outerScrollView !== nil
            {
                barLine._outerScrollView?.nsuiIsScrollEnabled = true
                barLine._outerScrollView = nil
            }
            
            
            
        }
    }
}

