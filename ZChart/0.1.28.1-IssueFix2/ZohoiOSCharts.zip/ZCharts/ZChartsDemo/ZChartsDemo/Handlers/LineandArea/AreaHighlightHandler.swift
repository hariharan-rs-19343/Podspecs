//
//  AreaHighlightHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 16/03/18.
//  Copyright © 2018 charts. All rights reserved.
//
import zchart

open class AreaHighlightHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.lineHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        
        let lineChart = (chart as! LineChartView)
        
        if !chart.viewPortHandler.isInBoundsX(touchLocation.x)
        {
            chart.setNeedsDisplay()
            lineChart.lastSelectedHigh = nil
            lineChart.datasetSelected = false
            lineChart.callDelegateToContainer(highlight: nil, entry: nil)
            return
        }
        
        if entry != nil{

            let entry =  LineHelperFunctions.getEntryAboveTouchPoint(location: (recognizer?.location(in: chart))!, chart: chart as! BarLineChartViewBase)
  
            if entry != nil{
                
                let dataSet = (chart.data?.getDataSetForEntry(entry)) as! ILineChartDataSet
            
                highlightDataSet(dataSet: dataSet, chart: chart as! BarLineChartViewBase)
                
                let entryLocation = lineChart.pixelForValues(x: (entry?.x)!, y: (entry?.y)!, axis: dataSet.axisDependency)
                
                let high = chart.getHighlightByTouchPoint(entryLocation)
                
                lineChart.lastHighlighted = high
                
                lineChart.callDelegateToContainer(highlight: high, entry: entry)
            }
            
        }
    }
    
     func highlightDataSet(dataSet:ILineChartDataSet, chart: BarLineChartViewBase)
    {
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            if layer.lineDataSet === dataSet
            {
                layer.strokeColor = layer.lineDataSet?.color(atIndex: 0).cgColor
                layer.fillColor = layer.lineDataSet?.color(atIndex: 0).withAlphaComponent(0.7).cgColor
            }
            else{
                layer.fillColor = UIColor.gray.withAlphaComponent(0.1).cgColor
                layer.strokeColor = UIColor.gray.withAlphaComponent(0.1).cgColor
            }
        }
        
    }
    
}
