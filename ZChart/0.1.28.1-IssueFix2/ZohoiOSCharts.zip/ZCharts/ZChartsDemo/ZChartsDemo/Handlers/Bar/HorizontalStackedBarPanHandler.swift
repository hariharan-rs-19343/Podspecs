//
//  HorizontalStackedBarPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 20/07/18.
//  Copyright © 2018 charts. All rights reserved.
//

//
//  StackedBarPanHandler.swift
//  ZCharts
//
//  Created by Aravinth T on 10/11/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class HorizontalStackedBarPanHandler: NSObject,EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    
    
    var indexToBarLayer:[Int:BarLayer] = [:]
    
    var totalHeight:CGFloat = 0.0
    
    // 20 % of viewport height
    var maxHeight:CGFloat = 0.0
    
    func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart as! BarLineChartViewBase
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: startLoc!)
            
            if barChart.lastSelected != nil && startLay?.chartEntry != barChart.lastSelected {
                if barChart.lastSelectedStackIndex == -1
                {
                    startLay = BarLayer.getBarLayerForEntry(chart: barChart, entry: barChart.lastSelected!)
                }
                else{
                    startLay = BarLayer.getStackedBarLayer(chart: barChart, entry: barChart.lastSelected!, stackIndex: barChart.lastSelectedStackIndex)
                }
            }
            
            lastTouched = startLoc
            maxHeight = barChart.viewPortHandler.contentWidth * 0.2
            
            if startLay != nil{
                indexToBarLayer = BarHelperFunctions.getStackIndexToBarLayer(barChart: barChart as! BarChartView)
                BarLayer.removeAllBarValueLayer(chart: barChart)
                totalHeight = getTotalWidthOfSelectedEntry(barChart: barChart as! BarChartView)
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
//            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPointOriginal(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            // **************************************** Vertical Pan Change**************************************************************
            if (barChart.lastSelected == startLay?.chartEntry) && verticalMove && !(recognizer.nsuiNumberOfTouches() == 2) && startLay != nil
            {
                trans = recognizer.translation(in: barChart)
                
                //                if vel.y > 5 || vel.y < -5 {
                
                // **************************************** Group Selection **************************************************************
                if barChart.barGroupSelectionEnabled
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let selectedBarEntry = (barChart.lastSelected as! BarChartDataEntry)
                    
                    let barDataSet = (barChart.data?.dataSets[0] as! BarChartDataSet)
                    
                    let bottomXPosition = barChart.pixelForValues(x: -(selectedBarEntry.negativeSum), y: 0, axis: barDataSet.axisDependency).x
                    
                    // **************************************** Group Drill **************************************************************
                    if trans.x > 0
                    {
                        let opac:CGFloat!
                        
                        let curHeight:CGFloat!
                        
                        if abs(trans.x) > (maxHeight)
                        {
                            trans.x = (maxHeight)
                        }
                        
                        let origDiff = maxHeight
                        
                        let curDiff =  origDiff - trans.x
                        
                        if curDiff < 0
                        {
                            opac = 0
                            curHeight = 0
                        }
                        else
                        {
                            
                            opac = (1/origDiff)*curDiff
                            
                            curHeight =  ((BarLayer.getAllBarLayer(chart: barChart)[0].barRect?.height)!/origDiff)*curDiff
                            
                            
                        }
                        
                        animationDuration = 0
                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                        {
                            if layer.getBarChartEntry() == barChart.lastSelected
                            {
                                if  (layer.barRect?.minX)! == bottomXPosition && (layer.barRect?.width)! > 0
                                {
                                    BarHelperFunctions.changeBarXPositionAndWidth(barLayer: layer, changeXValue: 0, changeWidth: trans.x, chart: barChart, duration: animationDuration)
                                }
                                else
                                {
                                    BarHelperFunctions.changeBarXPosition(barLayer: layer, newXValue: trans.x, chart: barChart, duration: animationDuration)
                                    
                                }
                            }
                            else{
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: opac, changeSize: CGSize(width: (layer.barRect?.width)!, height: curHeight), chart: barChart, duration: animationDuration)
                            }
                        }
                        
                    }
                        // **************************************** Group Filter **************************************************************
                    else
                    {
                        if dist >= (totalHeight)
                        {
                            trans.x = -totalHeight
                            animationDuration = 0
                        }
                        
                        let percent = abs(trans.x / totalHeight)
                        
                        if isGroupFilterAllowed(barChart: chart as! BarChartView)
                        {
                            for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                            {
                                if layer.getBarChartEntry() == barChart.lastSelected
                                {
                                    let xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                    let widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                    
                                    let newPath = UIBezierPath(rect: CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent) , height: (layer.barRect?.height)!))
                                    
                                    BarHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                }
                            }
                        }
                    }
                }
                    
                    // **************************************** Stack Selection **************************************************************
                    
                else if barChart.lastSelectedStackIndex != -1
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let barWidth = (startLay?.barRect?.size.width)!
                    
                    // **************************************** Stack Drill **************************************************************
                    
                    if trans.x > 0
                    {
                        
                        let heightToDrill = maxHeight
                        
                        if abs(trans.x) > heightToDrill
                        {
                            trans.x = heightToDrill
                        }
                        
                        let percent = abs(trans.x / heightToDrill)
                        
                        
                        var index = -1
                        
                        let stackCount = (startLay?.chartEntry as! BarChartDataEntry).yValues?.count
                        
                        
                        for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                        {
                            index += 1
                            
                            let layerEntry = layer.chartEntry as! BarChartDataEntry
                            
                            var topValue = layerEntry.positiveSum
                            var bottomValue = -layerEntry.negativeSum
                            
                            if (barChart as! BarChartView).isStackPercentEnabled()
                            {
                                topValue = 100
                                bottomValue = 0
                            }
                            
                            let topXPosition = barChart.pixelForValues(x: topValue, y: 0, axis: (barChart.data?.dataSets[0].axisDependency)!).x
                            let bottomXPosition = barChart.pixelForValues(x: bottomValue, y: 0, axis: (barChart.data?.dataSets[0].axisDependency)!).x
                            
                            let filterLayer = indexToBarLayer[index/stackCount!]
                            
                            if (filterLayer?.barRect?.width)! == 0
                            {
                                continue
                            }
                            
                            let xInterPolator:((CGFloat) -> CGFloat)
                            let widthInterpolator:((CGFloat) -> CGFloat)
                            
                            if (layer.barRect?.minX)! < (filterLayer?.barRect?.minX)! && layer.getStackIndex() != barChart.lastSelectedStackIndex
                            {
                                xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                
                            }
                            else if layer.getStackIndex() == barChart.lastSelectedStackIndex
                            {
                                
                                xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: (topXPosition - bottomXPosition))
                                
                            }
                            else{
                                
                                xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: topXPosition)
                                widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                
                            }
                            
                            let newPath = UIBezierPath(rect: CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent), height: (layer.barRect?.height)!))
                            
                            BarHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0)
                            
                        }
                        
                        return
                        
                    }
                        // **************************************** Stack Filter **************************************************************
                    else if dist >= (barWidth)
                    {
                        trans.x = -barWidth
                        animationDuration = 0
                    }
                    
                    if isStackEntryFilterAllowed(barChart: chart as! BarChartView)
                    {
                        let percent = abs(trans.x / barWidth)
                        
                        BarHelperFunctions.callHorizontalGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: percent)
                    }
                    else{
                        return
                    }
                    
                }
                //                }
            }
                // **************************************** Horizontal Pan Change **************************************************************
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                
                if recognizer.nsuiNumberOfTouches() == 2
                {
                    barChart._isDragging = true
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = barChart.performPanChange(translation: translation)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        barChart.barGroupSelectionEnabled = true
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }
                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            if recognizer.nsuiNumberOfTouches() == 2
            {
                barChart._isDragging = true
            }
            
            // **************************************** Verical Pan End **************************************************************
            if verticalMove && startLay != nil  && !barChart._isDragging
            {
                let vel = recognizer.velocity(in: barChart)
                
                // **************************************** Grouped Selection End  **************************************************************
                if barChart.barGroupSelectionEnabled
                {
                    var animationDuration:TimeInterval = 0
                    
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let selectedBarEntry = (barChart.lastSelected as! BarChartDataEntry)
                    
                    let barDataSet = (barChart.data?.dataSets[0] as! BarChartDataSet)
                    
                    let bottomXPosition = barChart.pixelForValues(x: -(selectedBarEntry.negativeSum), y: 0, axis: barDataSet.axisDependency).x
                    
                    // **************************************** Grouped Drill  **************************************************************
                    if trans.x > 0
                    {
                        // **************************************** Drill Performed **************************************************************
                        if abs(trans.x) >= (maxHeight)
                        {
                            trans.x = maxHeight
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                            {
                                if layer.getBarChartEntry() == barChart.lastSelected
                                {
                                    let newPath = UIBezierPath(rect: CGRect(x: bottomXPosition , y: (layer.barRect?.minY)!, width: 0 , height: (layer.barRect?.height)!))
                                    BarHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                                barChart.drillEntry(barEntry: barChart.lastSelected as! BarChartDataEntry)
                            })
                        }
                            // **************************************** Drill reverted **************************************************************
                        else{
                            trans.x = 0
                            animationDuration = 0.6
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let barPath = UIBezierPath(rect:layer.barRect!)
                                BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: barPath, chart: barChart, duration: animationDuration)
                            }
                            
                        }
                    }
                        // **************************************** Grouped Filter  **************************************************************
                    else
                    {
                        var filtered = true
                        
                        if vel.x < -1200
                        {
                            trans.x = -totalHeight
                            animationDuration = 0.2
                        }
                        else if dist > (totalHeight / 2 ) &&  dist <= (totalHeight )
                        {
                            trans.x = -totalHeight
                            animationDuration = 0.2
                        }
                        else if dist >= (totalHeight)
                        {
                            trans.x = -totalHeight
                            animationDuration = 0
                        }
                        else if dist <= (totalHeight / 2)
                        {
                            filtered = false
                            trans.x = 0
                            animationDuration = 0.2
                        }
                        
                        let percent = abs(trans.x / totalHeight)
                        
                        if isGroupFilterAllowed(barChart: chart as! BarChartView)
                        {
                            for layer in BarLayer.getAllBarLayer(chart: barChart as! BarChartView)
                            {
                                if layer.getBarChartEntry() == barChart.lastSelected
                                {
                                    let xInterPolator = Interpolator.interpolate(a: (layer.barRect?.minX)!, b: bottomXPosition)
                                    let widthInterpolator = Interpolator.interpolate(a: (layer.barRect?.width)!, b: 0)
                                    
                                    let newPath = UIBezierPath(rect: CGRect(x: xInterPolator(percent), y: (layer.barRect?.minY)!, width: widthInterpolator(percent) , height: (layer.barRect?.height)!))
                                    
                                    BarHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: animationDuration)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                                
                                if filtered
                                {
                                    barChart.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true)
                                }
                                
                            })
                        }
                        
                    }
                }
                    // **************************************** Stack Selection End **************************************************************
                else if barChart.lastSelectedStackIndex != -1 && barChart.lastSelectedStackIndex == startLay?.getStackIndex()
                {
                    let dist = distance(from: startLoc!, to: touchLocation)
                    
                    let barWidth = (startLay?.barRect?.size.width)!
                    
                    var animationDuration:TimeInterval = 0
                    
                    // **************************************** Stack Drill  **************************************************************
                    if trans.x > 0
                    {
                        // Height required to drill
                        let heightToDrill = maxHeight
                        
                        // **************************************** Drill Performed  **************************************************************
                        if abs(trans.x) >= heightToDrill
                        {
                            let baseLineValue = barChart.getBaseLineValue(dataSet: (barChart.data?.dataSets[0])!)
                            let baseLineYPosition = barChart.pixelForValues(x: baseLineValue, y: 0, axis: (barChart.data?.dataSets[0] as! BarChartDataSet).axisDependency).x
                            
                            let percentEnabled = (barChart as! BarChartView).isStackPercentEnabled()
                            
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let stackValue = (layer.chartEntry as! BarChartDataEntry).yValues![barChart.lastSelectedStackIndex]
                                
                                // Current Drilled Stack
                                if layer.getStackIndex() == barChart.lastSelectedStackIndex && !percentEnabled
                                {
                                    let aboveBaseLine = (layer.chartEntry as! BarChartDataEntry).yValues![barChart.lastSelectedStackIndex] > baseLineValue
                                    
                                    let xValue:CGFloat
                                    
                                    if aboveBaseLine
                                    {
                                        xValue = baseLineYPosition
                                    }
                                    else{
                                        xValue = baseLineYPosition - (layer.barRect?.width)!
                                    }
                                    
                                    let toPath = UIBezierPath(rect: CGRect(x: xValue, y: (layer.barRect?.minY)!, width: (layer.barRect?.width)!, height: (layer.barRect?.height)!))
                                    
                                    BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: toPath, chart: barChart, duration: 1)
                                    
                                }
                                else if stackValue.isNaN || stackValue == 0
                                {
                                    BarHelperFunctions.performOpacityAnim(targetLayer: layer, opacity: 0, duration: 0.75)
                                }
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(1)*CGFloat(1000))), execute: {
                                
                                let lowerCount = barChart.lastSelectedStackIndex
                                
                                // Remove stacks below selected stack
                                for _ in 0..<(lowerCount)
                                {
                                    barChart.lastSelectedStackIndex = 0
                                    barChart.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true)
                                }
                                
                                // Remove stacks above selected stack
                                for _ in 0..<(((self.startLay?.getBarChartEntry())!.yValues?.count)!-1)
                                {
                                    barChart.lastSelectedStackIndex = 1
                                    barChart.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true)
                                }
                                
                                
                            })
                            
                        }
                            // **************************************** Drill Reverted  **************************************************************
                        else{
                            for layer in BarLayer.getAllBarLayer(chart: barChart)
                            {
                                let barPath = UIBezierPath(rect:layer.barRect!)
                                BarHelperFunctions.changePathWithAnimation(barLayer: layer, path: barPath, chart: barChart, duration: 0)
                            }
                        }
                        
                    }
                        
                        // **************************************** Stack Filter  **************************************************************
                    else
                    {
                        if vel.x < -1200
                        {
                            trans.x = -barWidth
                            animationDuration = 0.2
                        }
                        else if dist > (barWidth / 2 ) &&  dist <= (barWidth )
                        {
                            trans.x = -barWidth
                            animationDuration = 0.2
                        }
                        else if dist >= (barWidth)
                        {
                            trans.x = -barWidth
                            animationDuration = 0
                        }
                        else if dist <= (barWidth / 2)
                        {
                            trans.x = 0
                            animationDuration = 0.2
                        }
                        if isStackEntryFilterAllowed(barChart: chart as! BarChartView)
                        {
                            let percent = abs(trans.x / (startLay?.barRect?.width)!)
                           
                            BarHelperFunctions.callHorizontalGroupFilterAnimation(chartView: barChart, animationDuration: animationDuration, percent: percent)
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(animationDuration)*CGFloat(1000))), execute: {
                                
                                let boundingRect = (self.startLay?.path?.boundingBox)!
                                
                                if boundingRect.size.width == 0
                                {
                                    if (barChart as! BarChartView).isStackPercentEnabled()
                                    {
                                        BarHelperFunctions.callGroupFilterEndAnimation(chartView: barChart, animationDuration: 0.15)
                                        
                                        DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(CGFloat(0.15)*CGFloat(1000))), execute: {
                                            barChart.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true)
                                        })
                                    }
                                    else{
                                        barChart.removeEntry(barEntry: (self.startLay?.getBarChartEntry())!, defaultAnimation: true)
                                    }
                                }
                                
                            })
                        }
                        else{
                            return
                        }
                    }
                    
                }
                
                
            }
                // **************************************** Horizontal Pan End **************************************************************
            else{
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = NSUIDisplayLink(target: barChart, selector: #selector(BarLineChartViewBase.decelerationLoop))
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoopMode.commonModes)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.nsuiIsScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
    
    open func getTotalWidthOfSelectedEntry(barChart:BarChartView) -> CGFloat
    {
        var width:CGFloat = 0.0
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            if layer.getBarChartEntry() == barChart.lastSelected
            {
                width = width + (layer.barRect?.size.width)!
            }
        }
        
        return width
    }
    
    open func getLowerUpperHeightOfEntry(barChartEntry:BarChartDataEntry, barChart:BarChartView) -> (CGFloat,CGFloat)
    {
        var lowerHeight:CGFloat = 0.0
        
        var upperHeight:CGFloat = 0.0
        
        for layer in BarLayer.getAllBarLayer(chart: barChart)
        {
            if layer.getBarChartEntry() == barChartEntry
            {
                if layer.getStackIndex() < barChart.lastSelectedStackIndex
                {
                    lowerHeight = lowerHeight + (layer.barRect?.size.height)!
                }
                else if layer.getStackIndex() > barChart.lastSelectedStackIndex
                {
                    upperHeight = upperHeight + (layer.barRect?.size.height)!
                }
                
            }
        }
        
        return (lowerHeight,upperHeight)
    }
    
    open func distance(from: CGPoint, to: CGPoint) -> CGFloat
    {
        let dx = from.x - to.x
        let dy = from.y - to.y
        return sqrt(dx * dx + dy * dy)
    }
    
    open func isStackEntryFilterAllowed(barChart:BarChartView) ->  Bool
    {
        let entry = barChart.data?.dataSets[0].entryForIndex(0)
        let barEntry  = entry as! BarChartDataEntry
        if barEntry.yValues?.count == 1
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    open func isGroupFilterAllowed(barChart:BarChartView) -> Bool
    {
        let count = barChart.data?.dataSets[0].entryCount
        if (count)! <= 1
        {
            return false
        }
        else
        {
            return true
        }
    }
}


