//
//  StackedBarLongPressListener.swift
//  ZCharts
//
//  Created by Aravinth T on 01/11/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class StackedBarLongPressListener: NSObject,EventHandler {
 
    var prevEntry:ChartDataEntry? = nil
    
    var prevStackedIndex:Int? = -1
    
    var horizontalChart = false
    
    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?,
                 _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint)
    {
        var entryLayer = entryLayer
        
        if entryLayer == nil{
            entryLayer = BarLayer.getBarLayerInPoint(chart: chartView, loc: touchLocation)
        }
        
        let bar = chartView as! BarChartView
        
        if entryLayer == nil
        {
            if recognizer?.state == .ended
            {
                reloadBar(barChartView: bar)
            }
            return
        }
        
        let high = bar.getHighlightByTouchPoint(touchLocation)
        
        let barLayer = entryLayer as! BarLayer
        
        if recognizer?.state == .began
        {
            reloadBar(barChartView: chartView as! BarChartView)
            
            if bar.isKind(of: HorizontalBarChartView.self)
            {
                horizontalChart = true
            }
            
            BarLayer.removeAllBarValueLayer(chart: bar)
            
            prevEntry = barLayer.getBarChartEntry()
            
            for layer in BarLayer.getAllBarLayer(chart: bar)
            {
                var newSize = (layer.barRect?.size)!
                
                if layer.getBarChartEntry() == barLayer.getBarChartEntry()
                {
                    if horizontalChart
                    {
                        newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                    }
                    else{
                        newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                    }
                    
                    BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                }
                else
                {
                    
                    if horizontalChart
                    {
                        newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                    }
                    else{
                        newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                    }

                    BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                }
            }

            bar.lastSelectedStackIndex = -1
            bar.barGroupSelectionEnabled = true
            bar.callDelegateToContainer(highlight: high, entry: entry)
            
        }
        else if recognizer?.state == .changed
        {
            if prevEntry == barLayer.getBarChartEntry()
            {
                if prevStackedIndex == -1
                {
                    prevStackedIndex = barLayer.getStackIndex()
                }
                else if prevStackedIndex == barLayer.getStackIndex()  // Same bar entry and same stack
                {
                    
                }
                else // Same bar entry and different stack
                {
                    prevStackedIndex = barLayer.getStackIndex()
                    
                    
                    
                    for layer in BarLayer.getAllBarLayer(chart: bar)
                    {
                        var newSize = (layer.barRect?.size)!
                        
                        if  layer.getStackIndex() == barLayer.getStackIndex()
                        {
                            if horizontalChart
                            {
                                newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                            }
                            else{
                                newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                            }
                            
                            if layer.getBarChartEntry() != barLayer.getBarChartEntry()
                            {
                                if horizontalChart
                                {
                                    newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                                }
                                else{
                                    newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                                }
                            }
                            
                            let color = ((bar.data) as! BarChartData).highlightColor?.cgColor
                            if color != nil
                            {
                                layer.fillColor = color
                            }
                            else
                            {
                                layer.fillColor = layer.barDataSet?.color(atIndex: ((layer.barRectIndex) % (layer.getBarChartEntry().yValues?.count)!)).cgColor
                            }
                            
                            BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                            
                        }
                        else
                        {
                            if horizontalChart
                            {
                                newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                            }
                            else{
                                newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                            }
                            
                            if layer.getBarChartEntry() == barLayer.getBarChartEntry()
                            {
                                if horizontalChart
                                {
                                    newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                                }
                                else{
                                    newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                                }
                            }
                            
                            let color = ((bar.data) as! BarChartData).nonHighlightColor?.cgColor
                            
                            var changeOpacity:CGFloat
                            
                            if color != nil
                            {
                                layer.fillColor = color
                                changeOpacity = 1.0
                            }
                            else{
                                changeOpacity = 0.5
                                layer.fillColor = layer.barDataSet?.color(atIndex: ((layer.barRectIndex) % (layer.getBarChartEntry().yValues?.count)!)).cgColor
                            }
                            
                            BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: changeOpacity, changeSize: newSize, chart: bar, duration: 0.2)
                            
                        }
                    }
                    bar.lastSelectedStackIndex =  self.prevStackedIndex!
                    bar.barGroupSelectionEnabled = false
                    bar.callDelegateToContainer(highlight: high, entry: barLayer.getBarChartEntry())
                }
            }
            else
            {
                for layer in BarLayer.getAllBarLayer(chart: bar)
                {
                    var newSize = (layer.barRect?.size)!
                    
                    if layer.getBarChartEntry() == barLayer.getBarChartEntry()
                    {
                        
                        if horizontalChart
                        {
                            newSize.height = (layer.barRect?.size.height)! +  ((layer.barRect?.size.height)! * 0.1)
                        }
                        else{
                            newSize.width = (layer.barRect?.size.width)! +  ((layer.barRect?.size.width)! * 0.1)
                        }
                        
                        let color = ((bar.data) as! BarChartData).highlightColor?.cgColor
                        if color != nil
                        {
                            layer.fillColor = color
                        }
                        else
                        {
                            layer.fillColor = layer.barDataSet?.color(atIndex: ((layer.barRectIndex) % (layer.getBarChartEntry().yValues?.count)!)).cgColor
                        }
                        
                        BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: 1, changeSize: newSize, chart: bar, duration: 0.2)
                        
                    }
                    else
                    {
                        if horizontalChart
                        {
                            newSize.height = (layer.barRect?.size.height)! -  ((layer.barRect?.size.height)! * 0.2)
                        }
                        else{
                            newSize.width = (layer.barRect?.size.width)! -  ((layer.barRect?.size.width)! * 0.2)
                        }
                        
                        let color = ((bar.data) as! BarChartData).nonHighlightColor?.cgColor
                        
                        var changeOpacity:CGFloat
                        
                        if color != nil
                        {
                            layer.fillColor = color
                            changeOpacity = 1.0
                        }
                        else{
                            changeOpacity = 0.5
                            layer.fillColor = layer.barDataSet?.color(atIndex: ((layer.barRectIndex) % (layer.getBarChartEntry().yValues?.count)!)).cgColor
                        }
                        
                        BarHelperFunctions.barSizeOpacityAnimator(barLayer: layer, opacity: changeOpacity, changeSize: newSize, chart: bar, duration: 0.2)
                        
                    }
                }
                
                prevStackedIndex = -1
                
                bar.lastSelectedStackIndex = -1
                bar.barGroupSelectionEnabled = true
                bar.callDelegateToContainer(highlight: high, entry: barLayer.getBarChartEntry())
                
            }
            
            prevEntry = barLayer.getBarChartEntry()
        }
        else if recognizer?.state == .ended
        {
           // reloadBar(barChartView: bar)
        }
    }

    
    func resetBarChanges(barChartView:BarChartView)
    {
        prevEntry = nil
        prevStackedIndex = -1
        barChartView.barGroupSelectionEnabled = false
        barChartView.lastSelected = nil
        barChartView.lastSelectedStackIndex = -1
        barChartView.callDelegateToContainer(highlight: nil, entry: nil)
    }
    
    func reloadBar(barChartView:BarChartView)
    {
        resetBarChanges(barChartView: barChartView)
        barChartView.setNeedsDisplay()
    }
    
    func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.custom
    }
    
    
}
