//
//  CustomBarPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 23/10/17.
//  Copyright © 2017 charts. All rights reserved.
//


import UIKit
import zchart

open class CustomBarPanHandler: NSObject, EventHandler {
    
    var startLoc:CGPoint? = nil
    var startLay:BarLayer? = nil
    var trans:CGPoint!
    var verticalMove:Bool = true
    var curLay:BarLayer? = nil
    var lastTouched:CGPoint? = nil
    var sumChange:CGFloat = 0
    
    
    var baseLineValue = Double(0)
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.barPan
    }
    
   /* func changeOpacityForOtherBars(barLayer:BarLayer,chart: ChartViewBase,opacity:CGFloat,width:CGFloat)
        
    {
        
        let allLayers = BarLayer.getAllBarLayer(chart: chart)
        
        
        
        chart.data?.setDrawValues(false)
        
        
        
        
        
        for eachBarLayer in allLayers
            
        {
            
            if eachBarLayer == barLayer
                
            {
                
                continue
                
            }
            
            
            
            let barRect = eachBarLayer.barRect!
            
            
            
            let newRect:CGRect!
            
//            if width == 0
//            {
//               newRect = CGRect(x: (barRect.origin.x + barRect.size.width/2), y: barRect.origin.y, width: 0, height: barRect.size.height)
//            }
//            else{
//               newRect = CGRect(x: barRect.origin.x, y: barRect.origin.y, width: (barLayer.barRect?.width)!, height: barRect.size.height)
//            }
            
            newRect = CGRect(x: (barRect.origin.x + ((barRect.size.width - width)/2)), y: barRect.origin.y, width: width, height: barRect.size.height)
            
            let newPath = UIBezierPath(rect: newRect)
            
            
            
            CATransaction.begin()
            
            let anim = CABasicAnimation(keyPath: "path")
            
            anim.fromValue = eachBarLayer.path
            
            anim.toValue = newPath.cgPath
            
            anim.duration = 0.2
            
            anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
            
            CATransaction.setCompletionBlock(nil)
            
            eachBarLayer.add(anim, forKey: "path")
            
            CATransaction.commit()
            
            eachBarLayer.path = newPath.cgPath
            
            
            
            UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveLinear, animations: {
                
                eachBarLayer.opacity = Float(opacity)
                
            }, completion: nil)
            
            
            
        }
        
        
        
    }*/
    

    func changeOpacityForOther(barLayer:BarLayer,opacity:CGFloat,width:CGFloat,chart: ChartViewBase)
    {
        
        
        let allLayers = BarLayer.getAllBarLayer(chart: chart)
        
        //chart.data?.setDrawValues(false)

        
        for eachBarLayer in allLayers
            
        {
            
            if eachBarLayer == barLayer
            {
                continue
            }
            
            eachBarLayer.opacity = Float(opacity)
            
            eachBarLayer.path = UIBezierPath(rect: CGRect(x: (eachBarLayer.barRect?.minX)! + (((eachBarLayer.barRect?.width)! - width)/2), y: (eachBarLayer.barRect?.minY)!, width: width, height: (eachBarLayer.barRect?.height)!)).cgPath
            
        }
        

    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barChart = chart as! BarLineChartViewBase
        
        if (barChart.data?.maxEntryCountSet?.entryCount)! <= 1
        {
            return
        }
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            
            sumChange = 0
            verticalMove = true
            startLoc = recognizer.location(in: barChart)
            startLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: startLoc!)
            lastTouched = startLoc
            
            if startLay != nil
            {
                baseLineValue = barChart.getBaseLineValue(dataSet: (barChart.data?.getDataSetForEntry(startLay?.chartEntry))!)
            }
            
            barChart.stopDeceleration()
            
            if barChart.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            // If drag is enabled and we are in a position where there's something to drag:
            //  * If we're zoomed in, then obviously we have something to drag.
            //  * If we have a drag offset - we always have something to drag
          /*  if barChart.isDragEnabled &&
                (!barChart.hasNoDragOffset || !barChart.isFullyZoomedOut)
            {
                barChart._isDragging = true
                
                barChart._closestDataSetToTouch = barChart.getDataSetByTouchPoint(point:  recognizer.location(ofTouch: 0, in: barChart))
                
                let translation = recognizer.translation(in: barChart)
                let didUserDrag = (barChart is HorizontalBarChartView) ? translation.y != 0.0 : translation.x != 0.0
                
                // Check to see if user dragged at all and if so, can the chart be dragged by the given amount
                if didUserDrag && !barChart.performPanChange(translation: translation)
                {
                    if barChart._outerScrollView !== nil
                    {
                        // We can stop dragging right now, and let the scroll view take control
                        barChart._outerScrollView = nil
                        barChart._isDragging = false
                    }
                }
                else
                {
                    if barChart._outerScrollView !== nil
                    {
                        // Prevent the parent scroll view from scrolling
                        barChart._outerScrollView?.isScrollEnabled = false
                    }
                }
                
                barChart._lastPanPoint = recognizer.translation(in: barChart)
            }
            else if barChart.isHighlightPerDragEnabled
            {
                // We will only handle highlights on NSUIGestureRecognizerState.Changed
                
                barChart._isDragging = false
            }*/
            
            barChart._lastPanPoint = recognizer.translation(in: barChart)
            
            barChart._isDragging = false
            
            if recognizer.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            let vel = recognizer.velocity(in: barChart)
            let curLoc = recognizer.location(in: barChart)
            
            if recognizer.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            
            curLay = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
            
            if curLay != nil{
                lastTouched = curLoc
            }
            
            if curLay != nil && (curLay?.chartEntry == startLay?.chartEntry) && verticalMove
            {
               // BarLayer.removeAllBarValueLayer(chart: chart)
                
               for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
               {
                eachBar.opacity = 0
                }
 
                trans = recognizer.translation(in: barChart)
                
                if vel.y > 5 || vel.y < -5 {
                    
                    let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: curLoc)
                    sumChange += trans.y
                    
                    if ll != nil
                    {
                        var curY = (ll?.barRect?.minY)!+trans.y
                        let newPath:UIBezierPath!
                        
                        // Filter
                        if trans.y > 0
                        {
                            if (ll?.path?.boundingBox.height)! <  ((ll?.barRect?.height)!/2)
                            {
                                let curDiff = (ll?.path?.boundingBox.height)! - ((ll?.barRect?.height)!/4)
                                
                                let origDiff = (ll?.barRect?.height)!/4
                                
                                if curDiff <= 0
                                {
                                    ll?.opacity = 0
                                }
                                else
                                {
                                    
                                    let opac = (1/origDiff)*curDiff
                                    ll?.opacity = Float(opac)
                                }
                            }
                            else{
                                ll?.opacity = 1
                            }
                            
                                let height = ((ll?.barRect?.height)! - trans.y) < 0 ? 0 : ((ll?.barRect?.height)! - trans.y)
                                newPath = UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height))

                        }
                        else{ // Drill
                            
                            let opac:CGFloat!
                            
                            let curWidth:CGFloat!
                            
                            var height = (ll?.barRect?.height)! + abs(trans.y)
                            
                            
                            // 20 % of viewport height
                            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
                            
                            if abs(trans.y) > maxHeight
                            {
                                height = (ll?.barRect?.height)! + maxHeight
                                
                                curY = (ll?.barRect?.minY)! - maxHeight
                            }
                            
                            let origDiff = maxHeight
                            
                            let curDiff = maxHeight - abs(trans.y)          //(curY - ((ll?.barRect?.minY)! - origDiff))
                            
                            if curDiff < 0
                            {
                                opac = 0
                                curWidth = 0
                            }
                            else
                            {
                                opac = (1/origDiff)*curDiff
                                
                                curWidth =  ((ll?.barRect?.width)!/origDiff)*curDiff
                            }
                            
                            changeOpacityForOther(barLayer: ll!, opacity: opac, width: curWidth, chart: barChart)
                            

                            newPath = UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: curY , width: (ll?.barRect?.width)!, height: height))

                        }
                        
                        
                        
                        let anim = CABasicAnimation(keyPath: "path")
                        anim.fromValue = ll?.path
                        anim.toValue = newPath.cgPath
                        anim.duration = 0
                        anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                        ll?.add(anim, forKey: "path")
                        ll?.path = newPath.cgPath
                    }
                }
            }
            else {
                if curLay != nil   {
                    verticalMove = false
                }
                for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                {
                    eachBar.opacity = 1
                }
                

                if recognizer.numberOfTouches == 2
                {
                    barChart._isDragging = true
                }
                
                if barChart._isDragging
                {
                    let originalTranslation = recognizer.translation(in: barChart)
                    let translation = CGPoint(x: originalTranslation.x - barChart._lastPanPoint.x, y: originalTranslation.y - barChart._lastPanPoint.y)
                    
                    let _ = barChart.performPanChange(translation: translation)
                    
                    barChart._lastPanPoint = originalTranslation
                }
                else if barChart.isHighlightPerDragEnabled
                {
                    let selected = BarLayer.getBarLayerInPoint(chart: barChart, loc: recognizer.location(in: barChart))
                    if selected != nil
                    {
                        BarHelperFunctions.highlightBarWithMagnifiedEffect(location: recognizer.location(in: barChart), changePercent: 0.5, bar: barChart)
                    }

                }
            }
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            var flag = true
            var filtered = false
            if recognizer.numberOfTouches == 2
            {
                barChart._isDragging = true
            }
            // 20 % of viewport height
            let maxHeight = barChart.viewPortHandler.contentHeight * 0.2
            
            let ll = BarLayer.getBarLayerInPoint(chart: barChart, loc: lastTouched!)
            if verticalMove && ll != nil && startLay != nil  && !barChart._isDragging
            {
                let vel = recognizer.velocity(in: barChart)
                let newPath:UIBezierPath!
                let animDur:TimeInterval!
                
                
                if ll != nil && startLay != nil{
                    
                    // Drill
                    if vel.y < -1200 || ((ll?.path?.boundingBox.height)! > (ll?.barRect?.height)!)
                    {
                        
                        if (ll?.path?.boundingBox.height)! == (ll?.barRect?.height)! + maxHeight
                        {
                                newPath = UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.minY)! + (ll?.barRect?.height)!, width: (ll?.barRect?.width)!, height: 0))
                                for eachBar in BarLayer.getAllBarLayer(chart: chart)
                                {
                                    if eachBar == ll
                                    {
                                        continue
                                    }
                                    BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 0, changeSize: CGSize(width: 0, height: (eachBar.barRect?.height)!), chart: chart, duration: 0.4)
                                }
                        }
                        else
                        {
                            flag = false
                            newPath = UIBezierPath(rect: (startLay?.barRect)!)

                            for eachBar in BarLayer.getAllBarLayer(chart: chart)
                            {
                                if eachBar == ll
                                {
                                    continue
                                }
                                BarHelperFunctions.barSizeOpacityAnimator(barLayer: eachBar, opacity: 1, changeSize: CGSize(width: (ll?.barRect?.width)!, height: (eachBar.barRect?.height)!), chart: chart, duration: 0.4)
                            }
                            
                        }
                        
                        
                        
                        
                        
                        animDur = 0.4
                    }
                    else if vel.y > 1200  || ((ll?.path?.boundingBox.height)! < ((ll?.barRect?.height)!/2))
                    {
                        filtered = true
                        
                        newPath = UIBezierPath(rect: CGRect(x: (ll?.barRect?.minX)!, y: (ll?.barRect?.midY)!+((ll?.barRect?.height)!/4), width: (ll?.barRect?.width)!, height: (ll?.barRect?.height)!/4))
                      
                        let barOpacity = Interpolator.interpolate(a: Double((ll?.opacity)!), b: 0)
                        let opacityAnimator = Animator()
                        
                        opacityAnimator.updateBlock = {
                            ll?.opacity = Float(barOpacity(opacityAnimator.phaseX))
                        }
                        
                        let dur:TimeInterval!
                        
                        if (ll?.path?.boundingBox.height)! < ((ll?.barRect?.height)!/2)
                        {
                            dur = 0.1
                            animDur = 0.3
                        }
                        else{
                            dur = 0.3
                            animDur = 0.5
                        }
                        
                        opacityAnimator.animate(xAxisDuration: dur, easingOption: .linear)
                        
                    }
                    else{
                        flag = false
                        newPath = UIBezierPath(rect: (startLay?.barRect)!)
                        animDur = 0.3
                    }
                    
                    CATransaction.begin()
                    let anim = CABasicAnimation(keyPath: "path")
                    anim.fromValue = ll?.path
                    anim.toValue = newPath.cgPath
                    anim.duration = animDur
                    anim.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
                    CATransaction.setCompletionBlock({
                        if flag{
//                            barChart.updateDataOrigIndex()
                            if filtered
                            {
                                barChart.removeEntry(barEntry: ll?.chartEntry as! BarChartDataEntry, defaultAnimation: true)
                            }
                            else
                            {
                                barChart.drillEntry(barEntry: ll?.chartEntry as! BarChartDataEntry)
                            }
                        }
                        else{
                            for eachBar in BarLayer.getAllBarValueLayer(chart: chart)
                            {
                                eachBar.opacity = 1
                            }
                        }
                    })
                    
                    ll?.add(anim, forKey: "path")
                    CATransaction.commit()
                    ll?.path = newPath.cgPath
                }
                
                
            }
            else{
                if barChart._isDragging
                {
                    if recognizer.state == NSUIGestureRecognizerState.ended && barChart.isDragDecelerationEnabled
                    {
                        barChart.stopDeceleration()
                        
                        barChart._decelerationLastTime = CACurrentMediaTime()
                        barChart._decelerationVelocity = recognizer.velocity(in: barChart)
                        
                        barChart._decelerationDisplayLink = NSUIDisplayLink(target: barChart, selector: #selector(BarLineChartViewBase.decelerationLoop))
                        barChart._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoopMode.commonModes)
                    }
                    
                    barChart._isDragging = false
                }
                
                if barChart._outerScrollView !== nil
                {
                    barChart._outerScrollView?.isScrollEnabled = true
                    barChart._outerScrollView = nil
                }
            }
        }
        
    }
}

