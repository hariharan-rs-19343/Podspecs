//
//  HorizontalBarLongPressListener.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 28/02/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

class HorizontalBarLongPressListener: NSObject,EventHandler {
    
    
    var prevLongPressLoc:CGPoint? = nil
    
    
    var toggleAscending:Bool = true
    
    
    func getEventHandlerType() -> EventHandlerType {
        return EventHandlerType.custom
    }
    
    func execute(_ chartView: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?, _ touchLocation: CGPoint) {
        
        let barChart =  chartView as! BarChartView
        
        let location = touchLocation

        
        if recognizer?.state == .began
        {
    
            barChart.updateBackupData()
            
            prevLongPressLoc = location
            
            BarLayer.removeAllBarValueLayer(chart: chartView)
            
            
        }
        else if recognizer?.state == .changed
        {
            let dist = location.y - (prevLongPressLoc?.y)!
            
            let allLayer = BarLayer.getAllBarLayer(chart: chartView)
            
            for layer in allLayer
            {
                BarHelperFunctions.changeBarYPosition(barLayer: layer, newYValue: dist, chart: chartView, duration: 0)
            }
        }
        else if recognizer?.state == .ended
        {
            let dist = location.y - (prevLongPressLoc?.y)!

            if abs(dist) < 50
            {
                barChart.setNeedsDisplay()
                return
            }
            
            if dist >= 0
            {
                barChart.sortInteractionCalled = false
                barChart.sortAscendingEnabled = true
                self.toggleAscending = true
                restoreChartWithNewData(entries: getOriginalEntriesBasedOnOriginalIndex(barChart: barChart), barChart: barChart)
                //              self.backUpallowed = true
            }
            else
            {
                barChart.sortInteractionCalled = true
                barChart.sortAscendingEnabled = self.toggleAscending
                restoreChartWithNewData(entries: getSortedEntries(barChart: barChart), barChart: barChart)
            }
            
            barChart.barGroupSelectionEnabled = false
            
            barChart.lastSelected = nil
            
            barChart.lastSelectedStackIndex = -1
            
            barChart.highlightValue(nil, callDelegate: false)

        }
        
    }
    
    
    func getSortedEntries(barChart: BarChartView) -> [BarChartDataEntry]
    {
        var newEntries:[BarChartDataEntry] = []
        
        var nanEntries:[BarChartDataEntry] = []
        
        
        for i in 0 ..< (barChart.data?.dataSets[0].entryCount)!            {
            let oldEntry = barChart.data?.dataSets[0].entryForIndex(i) as! BarChartDataEntry
            
            let clonedEntry = oldEntry.copy() as! BarChartDataEntry
            
            if clonedEntry.x.isNaN || clonedEntry.y.isNaN
            {
                nanEntries.append(clonedEntry)
                continue
            }
            
            newEntries.append(clonedEntry)
        }
        
        
        if self.toggleAscending
        {
            newEntries.sort { (first:BarChartDataEntry, second:BarChartDataEntry) -> Bool in
                first.y < second.y
            }
            self.toggleAscending = false
        }
        else
        {
            newEntries.sort { (first:BarChartDataEntry, second:BarChartDataEntry) -> Bool in
                first.y > second.y
            }
            self.toggleAscending = true
        }
        
        for entries in nanEntries
        {
            newEntries.append(entries)
        }
        
        return newEntries
        
    }
    
    func getOriginalEntriesBasedOnOriginalIndex(barChart:BarChartView) -> [BarChartDataEntry]
    {
        var newEntries:[BarChartDataEntry] = []
        
        
        for i in 0 ..< (barChart.data?.dataSets[0].entryCount)!            {
            let oldEntry = barChart.data?.dataSets[0].entryForIndex(i) as! BarChartDataEntry
            let clonedEntry = oldEntry.copy() as! BarChartDataEntry
            newEntries.append(clonedEntry)
        }
        
        newEntries.sort { (first:BarChartDataEntry, second:BarChartDataEntry) -> Bool in
            ( (first.origIndex)! < (second.origIndex)! )
        }
        
        return newEntries
    }
    
    /* func takeBackUp(barChart: BarChartView)
     {
     self.backUpEntries.removeAll()
     
     for i in 0 ..< (barChart.data?.dataSets[0].entryCount)!            {
     let oldEntry = barChart.data?.dataSets[0].entryForIndex(i) as! BarChartDataEntry
     backUpEntries.append(oldEntry)
     }
     
     } */
    
    func restoreChartWithNewData(entries: [BarChartDataEntry], barChart: BarChartView)
    {
        barChart.data?.dataSets[0].clear()
        
        _ = barChart.data?.dataSets[0].resetEntries(entries: entries)
        
        barChart.resetMatricesForDataReload()
        
        UIView.animate(withDuration: 0.5, animations: {
            
            barChart.data?.updateXYValues()
            
            barChart.data?.dataSets[0].calcMinMax()
            
            barChart.data?.notifyDataChanged()
            
            barChart.notifyDataSetChanged()
            
            barChart.animate(xAxisDuration: 0.2, yAxisDuration: 0.2)
        })
        
    }
    
}

