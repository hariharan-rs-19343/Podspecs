//
//  ScatterHighlightHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 04/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

import zchart

open class ScatterHighlightHandler: NSObject, EventHandler {

    open static var needRefresh = false
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterHighlight
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        var entry = entry
        
        let scatterChart = (chart as! ScatterChartView)
        
        if scatterChart.isAnimationinProgress()
        {
            return
        }
        
        scatterChart.stopDeceleration()
        
        // To remove previous highlight laayer
        ScatterHelperFunctions.removeHighLightLayers(chart: chart)
        
        
        
        for layer in ScatterLayer.getAllScatterLayer(chart: chart)
        {
                layer.strokeColor = UIColor.lightGray.cgColor           
        }
        
        if ScatterHighlightHandler.needRefresh
        {
            entry = nil
            ScatterHighlightHandler.needRefresh = false
        }
        
        
        if scatterChart.lastSelected != nil && entry != nil && entryLayer != nil
        {
            if scatterChart.barGroupSelectionEnabled
            {
                if (entry?.x)! == (scatterChart.lastSelected?.x)!
                {
                    entry = nil
                }
            }
            else{
                if entry! == scatterChart.lastSelected!
                {
                    entry = nil
                }
            }
        }
        

        
        if entry != nil && entryLayer != nil && chart.viewPortHandler.isInBoundsX(touchLocation.x){
            
            let entryLocation = ScatterHelperFunctions.getEntryLocation(chart: chart as! BarLineChartViewBase, entry: entry!)!
            
            let interSpace = scatterChart.interSpace
            
            let scatterLayer = entryLayer as! ScatterLayer
            
            // SingleEntry Selection
            if abs(touchLocation.x - entryLocation.x) <= interSpace && abs(touchLocation.y - entryLocation.y) <= interSpace
            {
                scatterChart.lastSelected = entry
                
                scatterChart.barGroupSelectionEnabled = false
                
                ScatterHelperFunctions.highlightSingleEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!)
            }
            else{   //MultiSeries Entry Selection
                
                scatterChart.lastSelected = entry
                
                scatterChart.barGroupSelectionEnabled = true
                
                ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleRadius: 4, outerCircleRadius: 8)
                
            }
        }
        else{
            scatterChart.lastSelected = nil
            scatterChart.barGroupSelectionEnabled = false
            chart.setNeedsDisplay()
            entry = nil
        }
        
        // Tooltip delegate
        chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(touchLocation), entry: entry)
    }
    
}

