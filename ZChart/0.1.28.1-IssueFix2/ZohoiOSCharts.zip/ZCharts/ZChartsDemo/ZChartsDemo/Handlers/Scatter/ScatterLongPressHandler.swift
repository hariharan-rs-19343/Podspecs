//
//  ScatterLongPressHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 05/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

open class ScatterLongPressHandler: NSObject, EventHandler {
    
    
    var verticalMove:Bool = true
    
    var startHigh:Highlight? = nil
    
    var curHigh:Highlight? = nil
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterLongPress
    }
    
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUILongPressGestureRecognizer
        let scatterChart = chart as! ScatterChartView
        
        if entry == nil || entryLayer == nil
        {
            return
        }
        
        let scatterLayer = entryLayer as! ScatterLayer
        
        scatterChart.barGroupSelectionEnabled = true
        
        ScatterHelperFunctions.removeHighLightLayers(chart: chart)
        
        ScatterHighlightHandler.needRefresh = true
        
        // Tooltip delegate
        chart.callDelegateToContainer(highlight: chart.getHighlightByTouchPoint(touchLocation), entry: entry)
        
        if recognizer.state == NSUIGestureRecognizerState.began
        {
            ChartUtils.longPressSound()
            
            for layer in ScatterLayer.getAllScatterLayer(chart: chart)
            {
                let newPath = UIBezierPath(arcCenter: layer.shapePoint!, radius: 4-(1/2), startAngle: 0, endAngle: 360, clockwise: true)
                
                BarHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0.2)
                
                BarHelperFunctions.performLineWidthAnim(targetLayer: layer, newlineWidth: 1, duration: 0.2)
                
                layer.strokeColor = UIColor.lightGray.cgColor
            }
 
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleRadius: 6, outerCircleRadius: 10)
            
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleRadius: 6, outerCircleRadius: 10)
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            
            ScatterHelperFunctions.highlightMultiSeriesEntry(chart: chart, entry: entry!, point: scatterLayer.shapePoint!, innerCircleRadius: 6, outerCircleRadius: 10)
        }
        
    }
    
}
