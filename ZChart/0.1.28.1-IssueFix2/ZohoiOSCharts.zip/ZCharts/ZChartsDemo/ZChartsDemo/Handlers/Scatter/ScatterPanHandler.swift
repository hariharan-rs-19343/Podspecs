//
//  ScatterPanHandler.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 09/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

open class ScatterPanHandler: NSObject, EventHandler {
    
    public func getEventHandlerType() -> EventHandlerType
    {
        return EventHandlerType.scatterPan
    }
    
    var startLoc:CGPoint!
    var startEntry:ChartDataEntry!
    var startLayer:ChartEntryLayer!
    
    var yValueToMove:CGFloat = 0
    
    var allOtherScatterLayerAtSameIndex:[ScatterLayer]!
    
    var verticalPan = false
    var horizontalPan = false
    
    var highlighted = false
    
    var movingUp = false
    
    var allowed = true
    
    func deselect(chart:BarLineChartViewBase)
    {
        chart.lastSelected = nil
        chart.barGroupSelectionEnabled = false
        chart.callDelegateToContainer(highlight: nil, entry: nil)
    }
    
    public func execute(_ chart: ChartViewBase, entry: ChartDataEntry?, entryLayer: ChartEntryLayer?, _ recognizer: UIGestureRecognizer?,_ touchLocation: CGPoint) {
        
        let recognizer = recognizer as! NSUIPanGestureRecognizer
        let barLine = chart as! BarLineChartViewBase
        let trans = recognizer.translation(in: barLine)
        
        if (barLine.renderer as! ScatterChartRenderer).entryDeleted == true ||  (barLine.data?.maxEntryCountSet?.entryCount) == 1 || (barLine.data?.getDataSetForEntry(entry) == nil) || recognizer.nsuiNumberOfTouches() > 1 || (barLine.customAnimationInProgress)
        {   startEntry = nil
            return
        }
        
        if entry == nil || entryLayer == nil
        {
            horizontalPan = true
//            return
        }
        
        barLine._isDragging = false

        if recognizer.state == NSUIGestureRecognizerState.began //&& recognizer.nsuiNumberOfTouches() > 0
        {
            barLine.stopDeceleration()
            
            
            if barLine.data === nil
            { // If we have no data, we have nothing to pan and no data to highlight
                return
            }
            
            barLine._lastPanPoint = recognizer.translation(in: barLine)
            
            barLine._isDragging = false
            
            startLoc = ScatterHelperFunctions.getEntryLocation(chart: chart as! BarLineChartViewBase, entry: entry!)
            startEntry = entry
            startLayer = entryLayer as? ScatterLayer
    
            
            if barLine.lastSelected != nil
            {
                if LineHelperFunctions.getHighlightLayer(chart: barLine).count != 0
                {
                    highlighted = true
                    startLoc = ScatterHelperFunctions.getEntryLocation(chart: barLine, entry: barLine.lastSelected!)
                    startEntry = barLine.lastSelected
                }
                else{
                    barLine.lastSelected = nil
                    barLine.barGroupSelectionEnabled = false
                    
                }
            }
        
        }
        else if recognizer.state == NSUIGestureRecognizerState.changed
        {
            if startEntry == nil
            {
                return
            }
            // Detecting vertical pan - once detected no change to horizontal
            if abs(trans.y) > 10 && abs(trans.x) < 10 && !verticalPan && !horizontalPan
            {
                verticalPan = true
                
                startLayer = ScatterLayer.getScatterEntryLayer(chart: barLine, loc: startLoc)
                
//                startEntry = startLayer.chartEntry
                
                let otherEntriesAtSameIndex = ScatterHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: startEntry, chart: barLine)
                
                var maxEntry = startEntry
                
                allOtherScatterLayerAtSameIndex = []
                
                // find entry at the top - maxY value
                for entry in otherEntriesAtSameIndex
                {
                    if !highlighted
                    {
                        allOtherScatterLayerAtSameIndex.append(ScatterLayer.getScatterLayerForEntry(chart: barLine, entry: entry)!)
                    }
                    else{
                        ScatterLayer.getScatterLayerForEntry(chart: barLine, entry: entry)!.opacity = 0
                    }
                    
                    
                    if  entry.y > (maxEntry?.y)!
                    {
                        maxEntry = entry
                    }
                }
                
                // Initially calculate distanceToMove for moving down case
                let maxEntryLocation = ScatterHelperFunctions.getEntryLocation(chart: barLine, entry: maxEntry!)!
                yValueToMove =  (chart.viewPortHandler.contentBottom - maxEntryLocation.y + 6) / 2
                
            }
            else if abs(trans.x) > 10 && abs(trans.y) < 10 && !horizontalPan && !verticalPan
            {
                horizontalPan = true
            }
            
            if verticalPan
            {
                    barLine._isDragging = false

                    if  highlighted
                    {
                        if !barLine.barGroupSelectionEnabled
                        {
                            yValueToMove = startLoc.y - 6 - chart.viewPortHandler.contentTop
                            movingUp = true
                        }
                    }
                    else{
                        if trans.y < 0
                        {
                            yValueToMove = startLoc.y - 6 - chart.viewPortHandler.contentTop
                            movingUp = true
                        }
                    }
            }
            else if horizontalPan{
                barLine._isDragging = true
            }
            
            if verticalPan
            {
                if trans.y < 0 || movingUp
                {
                    // All entry highlighted case - not allowing up
                    if barLine.barGroupSelectionEnabled
                    {
                        LineHelperFunctions.getHighlightLayer(chart: barLine)[0].position = CGPoint(x: 0, y: 0 )
                        return
                    }
                    
                    if allowed && trans.y < 0
                    {
                        allowed = false
                        
                        
                        for layer in ScatterLayer.getAllScatterLayer(chart: chart)
                        {
                            if layer.chartEntry == startEntry
                            {
                                continue
                            }
                            let newPath = UIBezierPath(arcCenter: layer.shapePoint!, radius: 0, startAngle: 0, endAngle: 360, clockwise: true)
                        
                            BarHelperFunctions.performPathAnim(targetLayer: layer, newPath: newPath, duration: 0.5)
                            
                            BarHelperFunctions.performLineWidthAnim(targetLayer: layer, newlineWidth: 0, duration: 0.5)
                            
                            layer.strokeColor = UIColor.lightGray.cgColor
                        }
                        
                    }
                    
                    // Exponential increment
                    var yValue = abs(3*trans.y)

                    if yValue > yValueToMove
                    {
                        yValue = yValueToMove
                    }
                    
                    // Restrict moving down
                    if trans.y > 0
                    {
                        yValue = 0
                    }
                    
                    var newPoint = startLoc
                    newPoint?.y -= yValue
                    
                    
                    if highlighted
                    {
                        // Circle
                        LineHelperFunctions.getHighlightLayer(chart: barLine)[0].sublayers![1].position = CGPoint(x: 0, y: 0 - yValue)
                        
                        // Horizontal Line
//                        LineHelperFunctions.getHighlightLayer(chart: barLine)[0].sublayers![0].sublayers![0].position = CGPoint(x: 0, y: 0 - yValue)
  
                    }
                    else{
                        let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                        BarHelperFunctions.performPathAnim(targetLayer: startLayer, newPath: newPath, duration: 0)
                    }

                }
                else if !movingUp {         // Moving Down Case
                    
                    let yValue = abs(3*trans.y)
                    
                    if highlighted
                    {
                        if !barLine.barGroupSelectionEnabled
                        {
                            return
                        }
                        else{
                            LineHelperFunctions.getHighlightLayer(chart: barLine)[0].position = CGPoint(x: 0, y: 0 + yValue)
                        }
                        
                    }
                    else{
                        for target in allOtherScatterLayerAtSameIndex
                        {
                            var newPoint = target.shapePoint
                            newPoint?.y += yValue
                            
                            let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                        
                            BarHelperFunctions.performPathAnim(targetLayer: target, newPath: newPath, duration: 0)
                        }
                    }
                    
                    
                }
                
            }
            else if  barLine._isDragging == true    // Scroll
          {
            if barLine.lastSelected != nil
            {
                deselect(chart: barLine)
            }
            
            let originalTranslation = recognizer.translation(in: barLine)
            let translation = CGPoint(x: originalTranslation.x - barLine._lastPanPoint.x, y: originalTranslation.y - barLine._lastPanPoint.y)
            
            let _ = barLine.performPanChange(translation: translation)
            
            barLine._lastPanPoint = originalTranslation
            }
     
        }
        else if recognizer.state == NSUIGestureRecognizerState.ended || recognizer.state == NSUIGestureRecognizerState.cancelled
        {
            if startEntry == nil
            {
                return
            }
            
            horizontalPan = false
            
            if verticalPan
            {
                if movingUp
                {
                    // Check for drill condition
                    if abs(trans.y*3) >= yValueToMove && trans.y < 0
                    {
                        barLine.curLevel += 1
                        barLine.delegateToContainer?.chartValueDrillPerformed!(barLine, entry: startEntry, level: barLine.curLevel)
                        barLine.chartActionListener?.drillPerformed!(chartView: barLine, selectedEntry: startEntry,index: barLine.curLevel)
                    }
                    
                    barLine.setNeedsDisplay()
                }
                else{
                    let currentYValue = abs(trans.y*3)
                    
                    // Check for filter condition
                    if currentYValue >= yValueToMove && trans.y > 0
                    {
                        let percent = currentYValue / (yValueToMove*2)
                        
                        // isFullyHidden
                        if percent < 1
                        {
                            let duration = Double(1 - percent)
                            
                            if highlighted
                            {
                                let highLayer = LineHelperFunctions.getHighlightLayer(chart: barLine)[0]
                                ScatterHelperFunctions.performPositionAnim(targetLayer: highLayer, point: CGPoint(x: 0, y: 0 + (yValueToMove*4)), duration: duration)
                            }
                            else{
                                for target in allOtherScatterLayerAtSameIndex
                                {
                                    var newPoint = target.shapePoint
                                    newPoint?.y += (yValueToMove*2)
                                    
                                    let newPath = UIBezierPath(arcCenter: newPoint!, radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
                                    
                                    BarHelperFunctions.performPathAnim(targetLayer: target, newPath: newPath, duration: duration)
                                }
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() +  DispatchTimeInterval.milliseconds(Int(duration*1000)), execute: {
                                
                                barLine.updateDataOrigIndex()
                                barLine.alignScatter(chartEntry: self.startEntry)
                            })
                            
                        }
                        else{
                            barLine.updateDataOrigIndex()
                            barLine.alignScatter(chartEntry: self.startEntry)
                        }
                    }
                    else{
                        
                        barLine.setNeedsDisplay()
                    }
                    
                  
                }
                highlighted = false
                deselect(chart: barLine)
    
                verticalPan = false
                allowed = true
                movingUp = false
                
                
            }
            else{
            barLine._isDragging = true
            
            if recognizer.state == NSUIGestureRecognizerState.ended && barLine.isDragDecelerationEnabled
            {
                barLine.stopDeceleration()
                
                barLine._decelerationLastTime = CACurrentMediaTime()
                barLine._decelerationVelocity = recognizer.velocity(in: barLine)
                
                barLine._decelerationDisplayLink = NSUIDisplayLink(target: barLine, selector: #selector(BarLineChartViewBase.decelerationLoop))
                barLine._decelerationDisplayLink.add(to: RunLoop.main, forMode: RunLoopMode.commonModes)
                
            }
            
            barLine._isDragging = false
            
            
            if barLine._outerScrollView !== nil
            {
                barLine._outerScrollView?.nsuiIsScrollEnabled = true
                barLine._outerScrollView = nil
            }
                
            }
            // To all
            horizontalPan = false
            highlighted = false
            deselect(chart: barLine)
        }
    }
}
