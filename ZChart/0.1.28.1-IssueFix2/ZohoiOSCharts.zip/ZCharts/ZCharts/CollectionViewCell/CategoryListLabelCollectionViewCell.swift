//
//  CategoryListLabelCollectionViewCell.swift
//  ZChartsDemo
//
//  Created by keerthi-pt4274 on 29/11/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import UIKit

class CategoryListLabelCollectionViewCell: UICollectionViewCell {
    
    var chartName = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpName()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setUpName(){
        
        if #available(iOS 13.0, *) {
            contentView.backgroundColor = .tertiarySystemBackground
        } else {
            // Fallback on earlier versions
        }
        
        contentView.addSubview(chartName)
        
        chartName.font = chartName.font.withSize(13.0)
        
        chartName.numberOfLines = 0
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        let offSetForRoundedRect: CGFloat = 8.0
        let height: CGFloat = self.frame.height - CGFloat(offSetForRoundedRect * 2.0)
        let width: CGFloat = self.frame.width - CGFloat(offSetForRoundedRect * 2.0)
        
        chartName.frame = CGRect(x: offSetForRoundedRect, y: offSetForRoundedRect, width: width, height: height)

    }
}
