//
//  CategoryListCollectionViewCell.swift
//  DemoApp2.0
//
//  Created by keerthi-pt4274 on 16/11/21.
//

import UIKit

class CategoryListCollectionViewCell: UICollectionViewCell {
    
    var chartName = UILabel()
    
    var chartImage = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpName()
        setUpImageView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setUpName(){
        
        if #available(iOS 13.0, *) {
            contentView.backgroundColor = .tertiarySystemBackground
        } else {
            // Fallback on earlier versions
        }
        
        contentView.addSubview(chartName)
        
        chartName.font = chartName.font.withSize(13.0)
    }
    
    func setUpImageView(){
        contentView.addSubview(chartImage)
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        let heightForChartName: CGFloat = CGFloat(chartName.font.pointSize + 4.0)
        
        let offSetForRoundedRect: CGFloat = 8.0
        
        chartName.frame = CGRect(x: offSetForRoundedRect, y: offSetForRoundedRect, width: CGFloat(self.frame.size.width - offSetForRoundedRect), height: heightForChartName)
        
        chartImage.frame = CGRect(x: offSetForRoundedRect,
                                  y: heightForChartName + offSetForRoundedRect,
                                  width: self.frame.size.width - CGFloat(offSetForRoundedRect * 2.0),
                                  height: self.frame.size.height - heightForChartName - CGFloat(offSetForRoundedRect * 2.0))
    }
}
