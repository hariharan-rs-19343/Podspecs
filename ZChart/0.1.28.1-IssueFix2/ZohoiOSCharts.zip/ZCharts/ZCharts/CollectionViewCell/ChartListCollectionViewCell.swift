//
//  ChartListCollectionViewCell.swift
//  DemoApp2.0
//
//  Created by keerthi-pt4274 on 16/11/21.
//

import UIKit

class ChartListCollectionViewCell: UICollectionViewCell {
    
    var cellData: ChartListDataModel!
    
    var chartName = UILabel()
    
    var collectionView: UICollectionView!
    
    var navigation: UINavigationController!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        if #available(iOS 13.0, *) {
            contentView.backgroundColor = .systemBackground
        } else {
            // Fallback on earlier versions
        }
        
        setUpLabel()
        
        setUpCollectionView()
        
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setUpLabel(){
        contentView.addSubview(chartName)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let heightForChartName: CGFloat = CGFloat(chartName.font.pointSize + 4.0)
        
        let offSet: CGFloat = 10.0

        chartName.frame = CGRect(x: offSet, y: 0.0, width: CGFloat(self.frame.size.width - offSet), height: heightForChartName)
    }
    
    func setUpCollectionView(){
        
        let flowLayout = UICollectionViewFlowLayout()
        
        flowLayout.scrollDirection = .horizontal
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        
        addSubview(collectionView)
        
        collectionView.register(CategoryListCollectionViewCell.self, forCellWithReuseIdentifier: "innercell")
        
        collectionView.register(CategoryListLabelCollectionViewCell.self, forCellWithReuseIdentifier: "innerlabelcell")
        
        collectionView.delegate = self
        
        collectionView.dataSource = self
        
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        
        if #available(iOS 13.0, *) {
            collectionView.backgroundColor = .systemBackground
        } else {
            // Fallback on earlier versions
        }
        
        setUpConstraints()
    }
    
    func setUpConstraints(){
        self.addConstraints([
            collectionView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            collectionView.topAnchor.constraint(equalTo: chartName.bottomAnchor),
            collectionView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: self.bottomAnchor)
        ])
    }
    
}

extension ChartListCollectionViewCell: UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        let chartVC = fromClassName(className: cellData.categoryOfChart[indexPath.row].className) as! UIViewController
        
        navigation?.pushViewController(chartVC, animated: false)
        
    }
    
    func fromClassName(className : String) -> NSObject {
        let className = Bundle.main.infoDictionary!["CFBundleName"] as! String + "." + className
        
        let aClass = NSClassFromString(className) as! UIViewController.Type
        return aClass.init()
    }
    
}

extension ChartListCollectionViewCell: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cellData.categoryOfChart.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let image = UIImage(named: cellData.categoryOfChart[indexPath[1]].chartImageName){
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "innercell", for: indexPath) as! CategoryListCollectionViewCell
            
            cell.chartName.text = cellData.categoryOfChart[indexPath[1]].name
            
            cell.chartImage.image = image
            
            self.setUpLayout(cell: cell)
            
            return cell
            
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "innerlabelcell", for: indexPath) as! CategoryListLabelCollectionViewCell
            
            cell.chartName.text = cellData.categoryOfChart[indexPath[1]].name
            
            self.setUpLayout(cell: cell)
            
            return cell
        }
    }
    
    func setUpLayout(cell: UICollectionViewCell){
        
//        cell.contentView.layer.cornerRadius = 8.0
        
        cell.layer.cornerRadius = 8.0
        
        cell.layer.borderWidth = 0.5
        
        cell.layer.borderColor = UIColor.lightGray.cgColor
    }
}

extension ChartListCollectionViewCell: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 140.0, height: 120.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0.0, left: 10.0, bottom: 0.0, right: 10.0)
    }
}
