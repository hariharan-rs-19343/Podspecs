//
//  ChartListDataModel.swift
//  DemoApp2.0
//
//  Created by keerthi-pt4274 on 16/11/21.
//

import Foundation

import Foundation

class ChartListDataModel: Hashable{
    
    var chartName: String
    
    var categoryOfChart: [CategoryListDataModel]
    
    init(chartName: String,categoryOfChart: [CategoryListDataModel]){
        self.chartName = chartName
        self.categoryOfChart = categoryOfChart
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(chartName)
    }
    
    func contains(searchText: String) -> Bool {
        return chartName.lowercased().contains(searchText.lowercased())
    }
    
    static func == (obj1: ChartListDataModel, obj2: ChartListDataModel) -> Bool {
        return obj1.chartName == obj2.chartName
    }
}

//section datamodel

enum Section{
    case main
}
