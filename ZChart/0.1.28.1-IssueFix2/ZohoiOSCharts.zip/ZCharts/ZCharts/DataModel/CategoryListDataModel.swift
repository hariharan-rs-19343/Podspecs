//
//  CategoryListDataModel.swift
//  DemoApp2.0
//
//  Created by keerthi-pt4274 on 16/11/21.
//

import Foundation

class CategoryListDataModel: Hashable{
    var name: String
    
    var className: String
    
    var chartImageName: String
    
    init(name: String,className: String,chartImageName: String){
        self.name = name
        self.className = className
        self.chartImageName = chartImageName
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(name)
    }
    
    func contains(searchText: String) -> Bool {
        return name.lowercased().contains(searchText.lowercased())
    }
    
    static func == (obj1: CategoryListDataModel, obj2: CategoryListDataModel) -> Bool {
        return obj1.name == obj2.name
    }
}
