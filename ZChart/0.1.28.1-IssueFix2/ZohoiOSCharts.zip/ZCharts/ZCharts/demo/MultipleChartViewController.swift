//
//  MultipleChartViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 15/12/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class MultipleChartViewController: UIViewController,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource {

    let uiCollectionViewLayout = UICollectionViewFlowLayout()
    
    var uiCollectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        uiCollectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: uiCollectionViewLayout)
        
        self.view.addSubview(uiCollectionView)
        
        uiCollectionView.translatesAutoresizingMaskIntoConstraints = false
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":uiCollectionView])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":uiCollectionView])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        uiCollectionView.dataSource = self
        uiCollectionView.delegate = self
        uiCollectionView.backgroundColor = UIColor.clear
        uiCollectionView.register(PieCVCell.self, forCellWithReuseIdentifier: "PieCVCell")
        uiCollectionView.register(BarCVCell.self, forCellWithReuseIdentifier: "BarCVCell")
        uiCollectionView.register(LineCVCell.self, forCellWithReuseIdentifier: "LineCVCell")
        
        uiCollectionViewLayout.scrollDirection = .vertical
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
      
        
         let count:Int = 0
       
//        if indexPath.item % 2 != 0
//        {
//            count = 3
//        }
        
        
        if indexPath.item % 3 == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PieCVCell", for: indexPath) as! PieCVCell
            
            cell.layer.shouldRasterize = false
            cell.layer.rasterizationScale = UIScreen.main.scale
            
            let pieChart = cell.chartContainer.chartView.chart 
            
            DispatchQueue.global(qos: .userInitiated).async {
                
                let pieData = PieCVCell.getNewPieData(count: count, index: indexPath.item)
                
                DispatchQueue.main.async {
                    
                    cell.chartContainer.title.mainTitleSettings.text = "Item " + String(indexPath.item)
                    
                    pieChart.data = pieData
                    
                    pieChart.notifyDataSetChanged(redrawRequired: true)
                    
                }
            }
            
            return cell
        }
        else if indexPath.item % 3 == 1
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BarCVCell", for: indexPath) as! BarCVCell
            
            
            cell.layer.shouldRasterize = false
            cell.layer.rasterizationScale = UIScreen.main.scale
            
            let barChart = cell.chartContainer.chartView.chart
            
            
            DispatchQueue.global(qos: .userInitiated).async {
                
                
                let barData = BarCVCell.getNewBarData(count: count, index: indexPath.item,plotOptions:barChart.getPlotOptions(type: .Bar) as! BarPlotOptions)
                
                DispatchQueue.main.async {
                    
                    cell.chartContainer.title.mainTitleSettings.text = "Item " + String(indexPath.item)
                    
                    barChart.data = barData
                    
                    barChart.notifyDataSetChanged(redrawRequired: true)
                    
                }
            }
            
            return cell
            
        }
        else
        {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LineCVCell", for: indexPath) as! LineCVCell
            
            
            cell.layer.shouldRasterize = false
            cell.layer.rasterizationScale = UIScreen.main.scale
            
            let lineChart = cell.chartContainer.chartView.chart
            
            
            DispatchQueue.global(qos: .userInitiated).async {
                
                
                let lineData = LineCVCell.getNewLineData(count: count, index: indexPath.item)
                
                DispatchQueue.main.async {
                    
                    cell.chartContainer.title.mainTitleSettings.text = "Item " + String(indexPath.item)
                    
                    lineChart.data = lineData
                    
                    lineChart.notifyDataSetChanged(redrawRequired: true)
                    
                }
            }
            
            return cell
            
        }
   
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let frame = self.uiCollectionView.frame
        return CGSize(width: (frame.width-10), height: (frame.height - 10)/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    
    public static func addChart(containerView:ChartContainer) {
        //Legend Vertical or Horizontal
        containerView.legend.legendOrientation = .Horizontal
        containerView.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView.tooltip.toolTipType = .leftRight
        containerView.tooltip.toolTipEntryGenerator = DefaultToolTipEntryGenerator()
        
        // Views Hide Options
        containerView.title.titleEnabled = true
        //       containerView.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView.title.mainTitleSettings.text = "IOS Chart"
        containerView.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView.title.mainTitleEnabled = true
        containerView.title.subTitleEnabled = false
        
        containerView.chartView.isUserInteractionEnabled = false
        containerView.legendView.isUserInteractionEnabled = false
        containerView.toolTipView.isUserInteractionEnabled = false
        
        containerView.tooltip.tooltipEnabled = false
        containerView.legend.legendEnabled = false
        
        
        //        addPieChart(containerView: containerView)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}



class PieCVCell : UICollectionViewCell
{
    
    
    var chartContainer = ChartContainer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
 
        let cell = self
        
        
        chartContainer.translatesAutoresizingMaskIntoConstraints = false
        cell.addSubview(chartContainer)
        chartContainer.backgroundColor = UIColor.clear
        
        chartContainer.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        chartContainer.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        chartContainer.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        chartContainer.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
        
        chartContainer.isAxisChart = false
        
        let pieChartView = ChartViewBase()
        
        MultipleChartViewController.addChart(containerView: chartContainer)
        
        PieCVCell.addPieChartToContainer(containerView: chartContainer, pieChartView: pieChartView, count: 0)
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
  
    
    public static func addPieChartToContainer(containerView:ChartContainer, pieChartView:ChartViewBase, count:Int){
        
        let _ = containerView.initializeChart(chart: pieChartView)
        addPieProperties(pieChartView: pieChartView, count: count)
        
    }
    
    
    public static func addPieChart(containerView:ChartContainer){
        
        
        //Chart Input Data
        let pieChartView = containerView.chartView.chart
        
        addPieProperties(pieChartView: pieChartView, count: 0)
        
        
    }
    
    public static func addPieProperties(pieChartView:ChartViewBase, count:Int)
    {
        // MARK: Events
        
        pieChartView.tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
//        pieChartView.longPressEventListener?.handler = CustomLongPressHandler1()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        //        pieChartView.chartActionListener = self
        
        // chartview?.usePercentValuesEnabled=true
        
        //        pieChartView.outerCircleEnabled = false
        
        // MARK: Data
        
        let data=[100,200,150,50,80,170,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0 ..< (data.count - count) {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        chartDataSet.plotType = .Pie
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        //  pieChartView.setPieType = .PieSpinWheel
              
        piePlotOption.drawHoleEnabled = false // Doughnut
        piePlotOption.drawEntryLabelsEnabled = false
        piePlotOption.centerLabelEnabled = true
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        //        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
    }
    
    public static func getNewPieData(count:Int, index:Int) -> ChartData
    {
        let data=[100,200,150,50,80,170,140,300]
        
        let dataLabel = ["Label " + String(index), "Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0 ..< (data.count - count) {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        chartDataSet.plotType = .Pie
       
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        
        return chartData
        
    }
    
}


class BarCVCell : UICollectionViewCell
{
    
    var chartContainer = ChartContainer()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        
        let cell = self
        
        
        chartContainer.translatesAutoresizingMaskIntoConstraints = false
        cell.addSubview(chartContainer)
        chartContainer.backgroundColor = UIColor.clear
        
        chartContainer.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        chartContainer.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        chartContainer.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        chartContainer.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
        
        let barChartView = ChartViewBase()
        
        
        MultipleChartViewController.addChart(containerView: chartContainer)
        
        let _ = chartContainer.initializeChart(chart: barChartView)
        
        BarCVCell.addBarChartProperties(barChartView: barChartView)
        
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public static func addBarChartProperties(barChartView:ChartViewBase)
    {
        
        barChartView.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView.xAxis.axisTitle = "Years"
        
        barChartView.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
//        barChartView.xAxis.wordWrapEnabled = true
        
        barChartView.xAxis.scaleType = .Ordinal
        
        barChartView.xAxis.tickLabelMode = .forced
        //
        
        
        //        let count = 2000+50
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(ChartDataEntry(xString:lab,y: Double(val1),data:nil))
            // dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView.data = chartData
        
        
        guard let plotOptions = (barChartView.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.barWidth = 0.6
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        
        
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView.xAxis.labelPosition = .bottom
        
        barChartView.xAxis.granularityEnabled = true
        barChartView.xAxis.granularity = 1.0
        
        barChartView.xAxis.labelCount = 10
        
        
        //        barChartView.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView.xAxis.drawGridLinesEnabled = false
        
        barChartView.chartDescription?.enabled = false
        
        //ChartViewCell -> BarViewCell -> LineViewCell
        
    }
    
    
    public static func getNewBarData(count:Int, index:Int, plotOptions:BarPlotOptions) -> ChartData
    {
        let finalCount = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0 ..< (finalCount - count) {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(ChartDataEntry(xString:lab,y: Double(val1),data:nil))
            // dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        plotOptions.barWidth = 0.6
        
        return chartData
        
    }
    
    
    
}


class LineCVCell : UICollectionViewCell
{
    
    var chartContainer = ChartContainer()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        
        let cell = self
        
        
        chartContainer.translatesAutoresizingMaskIntoConstraints = false
        cell.addSubview(chartContainer)
        chartContainer.backgroundColor = UIColor.clear
        
        chartContainer.leadingAnchor.constraint(equalTo: cell.leadingAnchor).isActive = true
        chartContainer.trailingAnchor.constraint(equalTo: cell.trailingAnchor).isActive = true
        chartContainer.topAnchor.constraint(equalTo: cell.topAnchor).isActive = true
        chartContainer.bottomAnchor.constraint(equalTo: cell.bottomAnchor).isActive = true
        
        let lineChartView = ChartViewBase()
        
        
        MultipleChartViewController.addChart(containerView: chartContainer)
        
        let _ = chartContainer.initializeChart(chart: lineChartView)
        
//        BarCVCell.addBarChartProperties(barChartView: barChartView)
        
        LineCVCell.addLineChartProperties(lineChartView: lineChartView)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public static func addLineChartProperties(lineChartView:ChartViewBase?){
        
        lineChartView?.tapEventListener?.handler = LineHighlightHandler()
        
        lineChartView?.panEventListener?.handler = LinePanHandler()
        
        lineChartView?.longPressEventListener?.handler = LineLongPressHandler()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        //        lineChartView?.leftAxis.xOffset = 30
        
        //        lineChartView?.rightAxis.xOffset = 30
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        //        lineChartView?.leftAxis.gridLineWidth = 1
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        lineChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
//        lineChartView?.xAxis.axisMinimum = 0
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = 1.0
        //        lineChartView?.xAxis.granularityEnabled = true
        
        
        
        //        let count = 2000+50
        let count = 10
        var range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            if i > 300
            //            {
            //                range = 300
            //            }
            //            if i > 600
            //            {
            //                range = 200
            //            }
            //            if i > 900
            //            {
            //                range = 100
            //            }
            
            
            let lab = "200" + String(i+1)
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        set1.plotType = .Line
        
        let dataOption = set1.dataSetOptions as! LineDataSetOptions
        let shape = dataOption.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        dataOption.setShapeColor(UIColor.red)
        
        dataOption.lineWidth = 2
        dataOption.drawShapeEnabled = true
        
        dataOption.drawFilledEnabled = false
        dataOption.fillAlpha = 0.3
        dataOption.fillColor = ChartColorTemplates.pieColor()[5]
        dataOption.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Line
        
        let dataOption1 = set2.dataSetOptions as! LineDataSetOptions
        let shape1 = dataOption1.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        dataOption1.setShapeColor(UIColor.brown)
        
        dataOption1.lineWidth = 2
        dataOption1.drawShapeEnabled = true
        
        dataOption1.drawFilledEnabled = false
        dataOption1.fillAlpha = 0.3
        dataOption1.fillColor = ChartColorTemplates.pieColor()[1]
        dataOption1.mode = .linear
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Line
        
        let dataOption2 = set3.dataSetOptions as! LineDataSetOptions
        dataOption2.setCircleColor(UIColor.black)
        dataOption2.lineWidth = 2
        dataOption2.circleRadius = 3.0
        dataOption2.drawCircleHoleEnabled = false
        dataOption2.drawCirclesEnabled = true
        dataOption2.drawShapeEnabled = false
        
        dataOption2.drawFilledEnabled = false
        dataOption2.fillAlpha = 0.3
        dataOption2.fillColor = ChartColorTemplates.pieColor()[2]
        dataOption2.mode = .linear
        
        
        
        
                let chartData = ChartData(dataSet: set1)
//        let chartData = LineChartData(dataSets: [set1, set2, set3])
        lineChartView?.data = chartData
        
        let plotOptions = lineChartView?.getPlotOptions(type: .Line) as! LinePlotOptions
        chartData.setDrawValues(false)
        plotOptions.maxWidthZoomRestrictionPixel = 100

        
        lineChartView?.xAxis.spaceMin = 0.5
        lineChartView?.xAxis.spaceMax = 0.5
        
        
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.black
        upperLimit.shapeProperties = ShapeProperties()
        
        upperLimit.limitValueTextColor = UIColor.white
        upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit.shapeProperties?.holeColor = UIColor.white
        upperLimit.shapeProperties?.shapeType = .circle
        upperLimit.shapeProperties?.size = CGSize(width: 8.0, height: 8.0)
        upperLimit.shapeProperties?.lineWidth = 2
//        upperLimit.shapeProperties?.customPathDataSource = self
        
        let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
        lowerRightLimit.lineColor = NSUIColor.red
        
        lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerRightLimit.lineDashPhase = 2.0
        lowerRightLimit.lineDashLengths = [1.0, 2.0]
        
        
        //      upperLimit.lineWidth = 6.0
        
        let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
        xLimit.lineColor = NSUIColor.red
        
        xLimit.lineDashPhase = 2.0
        xLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        lineChartView?.getYAxis(atIndex: 0)!.addLimitLine(upperLimit)
        
    }
    
    public static func getNewLineData(count:Int, index:Int) -> ChartData
    {
        let count = 10
        var range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            if i > 300
            //            {
            //                range = 300
            //            }
            //            if i > 600
            //            {
            //                range = 200
            //            }
            //            if i > 900
            //            {
            //                range = 100
            //            }
            
            
            let lab = "200" + String(i+1)
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        set1.plotType = .Line
        
        
        let dataOption1 = set1.dataSetOptions as! LineDataSetOptions
        let shape = dataOption1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        dataOption1.setShapeColor(UIColor.red)
        
        dataOption1.lineWidth = 2
        dataOption1.drawShapeEnabled = true
        
        dataOption1.drawFilledEnabled = false
        dataOption1.fillAlpha = 0.3
        dataOption1.fillColor = ChartColorTemplates.pieColor()[5]
        dataOption1.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Line
        
        let dataOption2 = set2.dataSetOptions as! LineDataSetOptions
        let shape1 = dataOption2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        dataOption2.setShapeColor(UIColor.brown)
        
        dataOption2.lineWidth = 2
        dataOption2.drawShapeEnabled = true
        
        dataOption2.drawFilledEnabled = false
        dataOption2.fillAlpha = 0.3
        dataOption2.fillColor = ChartColorTemplates.pieColor()[1]
        dataOption2.mode = .linear
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Line
        
        let dataOption3 = set3.dataSetOptions as! LineDataSetOptions
        dataOption3.setCircleColor(UIColor.black)
        dataOption3.lineWidth = 2
        dataOption3.circleRadius = 3.0
        dataOption3.drawCircleHoleEnabled = false
        dataOption3.drawCirclesEnabled = true
        dataOption3.drawShapeEnabled = false
        
        dataOption3.drawFilledEnabled = false
        dataOption3.fillAlpha = 0.3
        dataOption3.fillColor = ChartColorTemplates.pieColor()[2]
        dataOption3.mode = .linear
        
        
        
        
        //        let chartData = LineChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(false)
        
//        lineChartView?.xAxis.spaceMin = 0.5
//        lineChartView?.xAxis.spaceMax = 0.5
//
//        lineChartView?.data = chartData
        
        return chartData
        
    }
    
    
    
}

