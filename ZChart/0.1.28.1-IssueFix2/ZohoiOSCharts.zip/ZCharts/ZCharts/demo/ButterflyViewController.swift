//
//  ButterflyViewController.swift
//  ZCharts
//
//  Created by Keerthivass B S on 08/04/24.
//  Copyright © 2024 charts. All rights reserved.
//

import UIKit
import zchart

class ButterflyViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator  {
    
    // MARK: - ToolTip Preparation
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil || (entry?.x.isNaN)! //|| (entry?.y.isNaN)!
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(Double(totalSales)) )
            toolTipEntry1.valueTextColor = ColorUtility.color(traitCollection: traitCollection)
            
            toolTipEntry1.labelTextColor = ColorUtility.color(traitCollection: traitCollection)
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry!
        
        guard let dataSet = barChartView?.data?.getDataSetForEntry(barEntry)
            else { return entries }
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            for set in (barChartView?.data?.dataSets)!
            {
                if !(set.isVisible)
                {
                    continue
                }
                
                guard let entry = set.entryForXValue(barEntry.x, closestToY: Double.nan)
                    else { continue }
                
                
                let toolTipEntry = ToolTipEntry(label: set.label!, value: String(abs((entry.y))))
                toolTipEntry.valueTextColor = (set.colors[0])
                
                toolTipEntry.labelTextColor = ColorUtility.color(traitCollection: traitCollection)
                
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
                
            }
        }
        else
        {
            for i in 0..<(dataSet.entryCount)
            {
                
                let curEntry = dataSet.entryForIndex(i)!
                
                guard let label = curEntry.xString
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: label, value: String(abs(curEntry.y)))
                toolTipEntry.valueTextColor = (dataSet.color(atIndex: 0))
                
                toolTipEntry.labelTextColor = ColorUtility.color(traitCollection: traitCollection)
                
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
            
        }
        
        
        return entries
    }
    
    // MARK: - Container and its Components
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        view.addConstraints([
            containerView!.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            containerView!.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            containerView!.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            containerView!.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self //DefaultToolTipEntryGenerator()
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
        containerView?.legend.legendTextColor = ColorUtility.color(traitCollection: traitCollection)
        
        addBarChart()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    // MARK: - Chart Input Data
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        barChartView = containerView?.chart

        barChartView?.getYAxis(atIndex: 0)?.valueFormatter = self
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = HorizontalStackedBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = StackedBarLongPressListener()
        
    
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        
        barChartView?.xAxis.axisTitle = "Items"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
       
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.rendererDelegate = self
        
        //axis color based on light or dark mode
        
        axisColor()
        
        totalSales = 0
        let count = 10
        let range = 540
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        let xStrings = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","p"]
        
        let val1 = [[Double(12), Double(23) ],
        
         [Double(34), Double(24)],
        
         [Double(23), -Double(9)],
        
         [Double(10), Double(34)],
        
        [Double(43), -Double(41)],
        
        [Double(50), Double(23) ],
                    
        [-Double(34), Double(44)],
                    
        [Double(10), Double(5)],
                    
        [Double(7), Double(15)],
                    
        [Double(6), Double(5)],
                    
        [Double(5), -Double(23) ],
                    
        [Double(40), Double(24)],
                    
        [Double(23), Double(9)],
                    
        [Double(10), Double(34)],
                    
        [Double(43), Double(41)],
                    
        [Double(34), Double(24)]
        ]
    
        
        
        for i in 0..<xStrings.count
        {
            
            dataEntries1.append(ChartDataEntry(xString: xStrings[i], y: abs(val1[i][0]), plotData: (val1[i][0] < 0) as AnyObject,data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: xStrings[i], y: -abs(val1[i][1]), plotData: (val1[i][1] < 0) as AnyObject, data: nil))
            
            let val = val1[i][0] + val1[i][1]
            totalSales = val.isNaN ? totalSales : totalSales + val
           
        }

        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Sales")
        set1.colors = [ChartColorTemplates.colorful()[0]]
        set1.valueTextColor = ColorUtility.color(traitCollection: traitCollection)
        set1.plotType = .Bar
        set1.valueFormatter = self
        set1.dataSetOptions?.nonHighlightFillcolor = NSUIColor.gray.withAlphaComponent(0.5)
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Cost")
        set2.colors = [ChartColorTemplates.colorful()[1]]
        set2.valueTextColor = ColorUtility.color(traitCollection: traitCollection)
        set2.plotType = .Bar
        set2.valueFormatter = self
        set2.dataSetOptions?.nonHighlightFillcolor = NSUIColor.gray.withAlphaComponent(0.5)
        
        
        let chartData = ChartData(dataSets: [set1, set2])
        
        barChartView?.data = chartData
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.isStacked = true
        
        plotOptions.barWidth = 0.8
        
        
        plotOptions.barWidthPixel = 10
        
        plotOptions.barSpacePixel = 5
        
        plotOptions.maximumBarPixel = 100
        
        plotOptions.minimumBarPixel = 10
        
        plotOptions.fitBars = true
   
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.getYAxis(atIndex: 0)?.axisDependency = .right
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 25
        barChartView?.xAxis.spaceMax = 1.0
        barChartView?.xAxis.spaceMin = 1.0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.getYAxis(atIndex: 1)!.baseLineEnabled = true

        plotOptions.drawValueAboveBarEnabled = false

//        plotOptions.nonHighlightColor = ColorUtility.highlightColor(traitCollection: self.traitCollection)
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
    }
    
    // MARK: - Drill Input Data
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // BarPanHandler()
        
        barChartView?.longPressEventListener?.handler = StackedBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Items"+String(level)
        barChartView?.xAxis.scaleType = .Ordinal
        
        //axis color based on light or dark mode
        
        axisColor()
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        let count = 30
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = "Product " + String(Double(i+1))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val5 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            
            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
            
            dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.demoappcolor()[0]]
        set1.valueTextColor = ColorUtility.color(traitCollection: traitCollection)
        set1.plotType = .Bar
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.demoappcolor()[1]]
        set2.valueTextColor = ColorUtility.color(traitCollection: traitCollection)
        set2.plotType = .Bar
        
        let chartData = ChartData(dataSets: [set1,set2])
        
        barChartView?.data = chartData
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.isStacked = true
        
        plotOptions.barWidth = 0.6
        
        plotOptions.fitBars = true
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 10
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.5
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        plotOptions.drawValueAboveBarEnabled = false
        
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
    
    
    
}

extension ButterflyViewController{
    
    func axisColor(){
        //axis title color
        
        barChartView?.getYAxis(atIndex: 0)?.drawGridLinesEnabled = false
        
        barChartView?.xAxis.axisTitleColor = ColorUtility.color(traitCollection: traitCollection)
        
        barChartView?.getYAxis(atIndex: 0)?.axisTitleColor = ColorUtility.color(traitCollection: traitCollection)
        
        barChartView?.xAxis.gridColor = ColorUtility.color(traitCollection: traitCollection)
        
        barChartView?.xAxis.labelTextColor = ColorUtility.color(traitCollection: traitCollection)
        
        barChartView?.getYAxis(atIndex: 0)?.labelTextColor = ColorUtility.color(traitCollection: traitCollection)
        
        barChartView?.xAxis.labelHighlightColor = ColorUtility.highlightLabelcolor(traitCollection: traitCollection)
        
        barChartView?.xAxis.labelHighlightFont = UIFont.boldSystemFont(ofSize: 11)
    }
}

extension ButterflyViewController: IAxisValueFormatter{
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        
        return String((abs(value)))
    }
}

extension ButterflyViewController: IValueFormatter{
    
    func getFormattedValue(entry: ChartDataEntry) -> String {
        return entry.xString ?? ""
    }
    
    func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
        return String(abs(value))
    }
}

extension ButterflyViewController: RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        for barLayer in BarLayer.getAllBarLayer(chart: chartView) {
            if let entry = barLayer.chartEntry, let isNegative = entry.plotData as? Bool {
                if isNegative {
                    let fillColor = NSUIColor(cgColor: barLayer.fillColor ?? NSUIColor.gray.cgColor)
                    barLayer.fillColor = fillColor.withAlphaComponent(0.3).cgColor
                }
            }
        }
    }
}
