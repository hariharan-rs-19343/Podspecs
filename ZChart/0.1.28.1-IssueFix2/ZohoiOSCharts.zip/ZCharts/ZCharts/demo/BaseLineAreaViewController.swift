//
//  BaseLineAreaViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 05/07/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

class BaseLineAreaViewController: UIViewController,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let allEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: lineChartView!)
        
        for i in 0..<(allEntries.count)
        {
            let entry = allEntries[i]
            let set = lineChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!  //UIColor.blue //curEntry.entryColor
            
            entries.append(toolTipEntry)
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    /* var showCustomLineView:Bool = false
     
     func addCustomLineView() {
     
     
     childView = UIView(frame: self.view.bounds)
     
     childView.backgroundColor = UIColor.clear
     
     self.view.addSubview(childView)
     
     //        self.addMultipleLine(view: childView)
     
     //        addLine(view: childView, point: CGPoint(x: 100, y: 50))
     //        childView.layer.addSublayer(shapeLayer)
     
     let tapGestureRecognizer = NSUITapGestureRecognizer(target: self, action: #selector(tapGestureRecognized(_:)))
     childView.addGestureRecognizer(tapGestureRecognizer)
     
     let panGestureRecognizer = NSUIPanGestureRecognizer(target: self, action: #selector(panGestureRecognized(_:)))
     childView.addGestureRecognizer(panGestureRecognizer)
     
     
     let subPath = UIBezierPath(rect: CGRect(x: 75, y: 75, width: 50, height: 50))
     
     let mainLayer = CAShapeLayer()
     mainLayer.backgroundColor = UIColor.clear.cgColor
     mainLayer.fillColor = UIColor.green.cgColor
     mainLayer.opacity = 0.5
     let mainPath = UIBezierPath(rect: CGRect(x: 50, y: 50, width: 100, height: 100))
     mainPath.append(subPath)
     mainPath.usesEvenOddFillRule = true
     mainLayer.fillRule = kCAFillRuleEvenOdd
     
     mainLayer.path = mainPath.cgPath
     
     
     let subLayer = CAShapeLayer()
     subLayer.backgroundColor = UIColor.clear.cgColor
     subLayer.fillColor = UIColor.yellow.cgColor
     subLayer.opacity = 0.5
     //    let subPath = UIBezierPath(rect: CGRect(x: 75, y: 75, width: 50, height: 50))
     subLayer.path = subPath.cgPath
     //    subLayer.fillRule = "even-odd"
     
     
     
     //    mainLayer.addSublayer(subLayer)
     //    self.childView.layer.addSublayer(mainLayer)
     
     //    subLayer.mask = mainLayer
     //    self.childView.layer.addSublayer(subLayer)
     
     
     
     }*/
    
    
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        addLine(view: childView, point: location)
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    @objc fileprivate func panGestureRecognized(_ recognizer: NSUIPanGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        if  recognizer.state == .began
        {
            childView.layer.addSublayer(shapeLayer)
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .changed
        {
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .ended || recognizer.state == .cancelled
        {
            addLine(view: childView, point: location)
            shapeLayer.removeFromSuperlayer()
        }
        
        
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    func addMultipleLine(view:UIView)
    {
        
        
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 50, y: 50))
        path.addLine(to: CGPoint(x: 50, y: 95))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:50, y: 105))
        path.addLine(to: CGPoint(x: 50, y: 150))
        path.close()
        
        
        
        //        layer.lineCap = "round"
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        //        layer.fillColor = UIColor.green.cgColor
        shapeLayer.lineWidth = 2
        
        view.layer.addSublayer(shapeLayer)
        
        let circleLayer = CAShapeLayer()
        //        let circlePath = UIBezierPath(rect: CGRect(x: 45, y: 95, width: 10, height: 10))
        let circlePath = UIBezierPath(ovalIn: CGRect(x: 45, y: 95, width: 10, height: 10))
        //        UIBezierPath(ovalIn: <#T##CGRect#>)
        circleLayer.path = circlePath.cgPath
        circleLayer.strokeColor = UIColor.black.cgColor
        circleLayer.fillColor = UIColor.clear.cgColor
        
        shapeLayer.addSublayer(circleLayer)
    }
    
    func addLine(view:UIView, point:CGPoint)
    {
        let path = getNewPath(point: point, yChange: 100)
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 2
        
        var circleLayer:CAShapeLayer? = nil
        
        let sublayers = shapeLayer.sublayers
        if sublayers != nil
        {
            for layer in sublayers!
            {
                if layer.isKind(of: CAShapeLayer.self)
                {
                    circleLayer = layer as! CAShapeLayer
                    break
                }
            }
        }
        
        if circleLayer == nil
        {
            circleLayer = CAShapeLayer()
            circleLayer?.strokeColor = UIColor.black.cgColor
            circleLayer?.fillColor = UIColor.clear.cgColor
            
            shapeLayer.addSublayer(circleLayer!)
        }
        
        circleLayer?.path = getCirclePath(point: point, yChange: 100).cgPath
    }
    
    func getNewPath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        //        let yChange:CGFloat = 50
        let path = UIBezierPath()
        path.move(to: point)
        path.addLine(to: CGPoint(x: point.x, y: point.y + yChange - 5))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:point.x, y: point.y + yChange + 5))
        path.addLine(to: CGPoint(x: point.x, y: point.y + (2.0 * yChange)))
        path.close()
        
        return path
    }
    
    func getCirclePath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        let radius:CGFloat = 5
        //        let yChange:CGFloat = 50
        let rect = CGRect(x: point.x - radius, y: point.y + yChange - radius, width: 2 * radius, height: 2 * radius)
        let path = UIBezierPath(ovalIn: rect)
        path.close()
        
        return path
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*  if showCustomLineView
         {
         addCustomLineView()
         return
         }*/
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
//               containerView?.title.titleEnabled = false
        //containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addLineChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var lineChartView:ChartViewBase? = nil
    
    func addLineChart()
    {
        
        lineChartView = containerView?.chart
        
        lineChartView?.tapEventListener?.handler = AreaHighlightHandler()
        
        lineChartView?.panEventListener?.handler = LineFilterHandler()  // LinePanHandler()
        
        //        lineChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
        
        lineChartView?.xAxis.labelPosition = .bottom
    
        
//        lineChartView?.xAxis.axisMinimum = 0
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = 1.0
        
        lineChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = true
        lineChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        
        lineChartView?.xAxis.baseLineEnabled = true
        lineChartView?.xAxis.baseLine?.baseValue = 4
        
        //        lineChartView?.xAxis.granularityEnabled = true
        
        //        let count = 2000+50
        let count = 10
        let range = 700
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            if i == 1 || i == 5 || i == 6 || i == 10 || i == 11 || i == 20 || i == 22 || i >= 98
            {
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            }else {
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            }
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        set1.plotType = .Line
        
        let dataOptions1 = set1.dataSetOptions as! LineDataSetOptions
        let shape = dataOptions1.markerInstance
        shape.holeColor = UIColor.red
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        dataOptions1.setShapeColor(UIColor.red)
        
        dataOptions1.drawShapeEnabled = false
        
        dataOptions1.lineWidth = 1
        
        dataOptions1.drawFilledEnabled = true
        dataOptions1.fillAlpha = 0.3
        dataOptions1.fillColor = ChartColorTemplates.pieColor()[5]
        dataOptions1.mode = .cubicBezier
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Line
        
        let dataOptions2 = set2.dataSetOptions as! LineDataSetOptions
        dataOptions2.drawShapeEnabled = false
        dataOptions2.setCircleColor(UIColor.black)
        dataOptions2.lineWidth = 1
        dataOptions2.circleRadius = 3.0
        dataOptions2.drawCircleHoleEnabled = false
        dataOptions2.drawCirclesEnabled = false
        dataOptions2.drawFilledEnabled = true
        dataOptions2.fillAlpha = 0.3
        dataOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        dataOptions2.mode = .linear
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Line
        
        let dataOptions3 = set3.dataSetOptions as! LineDataSetOptions
        dataOptions3.drawShapeEnabled = false
        dataOptions3.setCircleColor(UIColor.black)
        dataOptions3.lineWidth = 1
        dataOptions3.circleRadius = 3.0
        dataOptions3.drawCircleHoleEnabled = false
        dataOptions3.drawCirclesEnabled = false
        dataOptions3.drawFilledEnabled = true
        dataOptions3.fillAlpha = 0.3
        dataOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        dataOptions3.mode = .linear
        
        
        
        
        //                let chartData = LineChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1, set2,set3])
        chartData.setDrawValues(false)
        
        
        lineChartView?.data = chartData
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: lineChartView!,duration:1,animationBlock: animateBlock)
        
        //         lineChartView?.animate(xAxisDuration: 1.0)
        
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = lineChartView!
        
        let animateBlock = {
            
            if chart.data == nil
            {
                return
            }
            
            let contentRect = (self.lineChartView?.viewPortHandler.contentRect)!
            
            
            
            let allLayers = LineLayer.getAllDataSetLayer(chart: chart)
            
            let entryCount =  (self.lineChartView?.data?.dataSetCount)!
            
            let heightPercent = Double(4)
            
            let duration:Double = ((heightPercent) / (Double(entryCount - 1) + heightPercent)) * totalDuration
            
            
            for entryLayer in allLayers
            {
                let maskLayer = CAShapeLayer()
                
                maskLayer.path = UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: 0, height: contentRect.height)).cgPath
                
                maskLayer.fillColor = UIColor.white.cgColor
                
                entryLayer.mask = maskLayer
                
                entryLayer.opacity = 1
            }
            
            
            let barEntryAnimator = Animator()
            
            
            barEntryAnimator.updateBlock = {
                
                for entryIndex in 0..<entryCount
                {
                    
                    
                    let startTime = (( duration / Double(heightPercent)) * Double(entryIndex))
                    
                    let endTime = startTime + duration
                    
                    let currentTime = (barEntryAnimator.phaseX) * totalDuration
                    
                    if currentTime > endTime  {
                        
                        self.updateLayerPath(phaseValue: 1, index: entryIndex, allLayers: allLayers)
                        
                    } else if currentTime < startTime {
                        
                    } else {
                        
                        let difference = currentTime - startTime
                        
                        var percent = CGFloat(difference/duration)
                        
                        if percent > 1
                        {
                            percent = 1
                        }
                        
                        self.updateLayerPath(phaseValue: percent,index:entryIndex,allLayers: allLayers)
                        
                    }
                    
                }
                
            }
            barEntryAnimator.stopBlock = {
                
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    func updateLayerPath(phaseValue:CGFloat,index:Int,allLayers:[ChartEntryLayer])
    {
        let chart = lineChartView!
        
        let contentRect = (self.lineChartView?.viewPortHandler.contentRect)!
        
        let xInterpolator = Interpolator.interpolate(a: 0, b: contentRect.width)
        
        let currentPath = UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: xInterpolator(phaseValue), height: contentRect.height)).cgPath
        
        
        var dataSetIndex = -1
        
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            dataSetIndex += 1
            
            if dataSetIndex == index
            {
                guard let maskLayer = layer.mask as? CAShapeLayer
                    else { return }
                maskLayer.path = currentPath
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


