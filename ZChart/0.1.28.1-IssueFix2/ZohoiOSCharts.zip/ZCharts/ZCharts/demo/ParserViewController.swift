//
//  ParserViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 26/04/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import WebKit
import JavaScriptCore
import zchart


class ParserViewController: UIViewController, IToolTipEntryGenerator, WKUIDelegate, ChartViewDelegate, CustomTicksDelegate , ShapeFactoryDataSource, UITextViewDelegate{
    
    var webJSONInput:String = ""
    
    /// Tooltip
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        let entries:[ToolTipEntry] = []
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var barChartView:ChartViewBase? = nil
    
    let slideMenuView = UIView()
    
    let editableTextField =  UITextView() // UITextField()
    
    var slideMenuViewBottomConstraint: NSLayoutConstraint!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        /// Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])

        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        addSlideView()
        
//        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
//               view.addGestureRecognizer(tap) // Add gesture recognizer to background view
        
        containerView?.chartViewDelegate = self
        
        ///Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        ///Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        /// Views Hide Options
        containerView?.title.titleEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        
        testJSONAutomation()
    }
    
    
    func readDataFromJson() -> String
    {
            if let urlPath = Bundle.main.url(forResource: "jsString", withExtension: "json") {
                
                do {
                    let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                    
                    let ss = String(data: jsonData, encoding: String.Encoding.utf8)
                    return ss!
                }
                catch let jsonError {
                
                }
            }
            
            return ""
    }
    
    
    // MARK: - JSON Automation
    
    func loadChart(jsonString:String)
    {
        var timerValue = Double(0)
        
        var runCount = 0
        
        containerView?.isAxisChart = true
        
        let chartString = ParserFunctions.getParsedJson(jsString: jsonString)
        
        ParserHelperFunctions.initializeChart(jsonString: chartString, containerView: containerView!)
        
        //        if (jsonString["plotOption"] as? [String:Any])?["WORD_CLOUD"] != nil || (jsonString["plotOption"] as? [String:Any])?["SANKEY"] != nil {
        //            timerValue += 5
        //        }
        //        else{
        //            timerValue += 0.2
        //        }
        //
        //        if #available(iOS 10.0, *) {
        //            Timer.scheduledTimer(withTimeInterval: timerValue, repeats: false) { timer in
        //                print("Timer fired!")
        //
        //                if self.containerView?.legend.type == LegendType.continous
        //                {
        //                    self.containerView?.currentOrientation = .Undefined
        //                    self.containerView?.legend.type = .discrete
        //
        //                    self.containerView?.legendView.collectionView?.dataSource = self.containerView?.legendView
        //                    self.containerView?.updateConstraints()
        //                }
        //            }
        //        } else {
        //            // Fallback on earlier versions
        //        }
    }
    
    func testJSONAutomation()
    {
        webJSONInput = readDataFromJson()
            
        loadChart(jsonString: webJSONInput)
    }


    // MARK: - SLIDE VIEW
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let rightButton = UIBarButtonItem(title: "Edit JSON", style: .plain, target: self, action: #selector(self.btn_clicked(_:)))
        
        // Create two buttons for the navigation item
        navigationItem.rightBarButtonItem = rightButton
        
    }
    
    func addSlideView()
    {
        self.view.addSubview(slideMenuView)
        
        slideMenuView.translatesAutoresizingMaskIntoConstraints = false
        
        addSlideViewContent()
        
        oldConstraint = self.getHideSlideConstraint()
        
        NSLayoutConstraint.activate(oldConstraint)
        
        slideMenuView.backgroundColor = UIColor.white
        
        slideMenuView.layer.borderWidth = 2.0
        
     
        // Notifications for when the keyboard opens/closes
               NotificationCenter.default.addObserver(
                   self,
                   selector: #selector(self.keyboardWillShow),
                   name: UIResponder.keyboardWillShowNotification,
                   object: nil)

               NotificationCenter.default.addObserver(
                   self,
                   selector: #selector(self.keyboardWillHide),
                   name: UIResponder.keyboardWillHideNotification,
                   object: nil)
    }
    
    @objc func keyboardWillShow(_ notification: NSNotification) {
            // Move the view only when the usernameTextField or the passwordTextField are being edited
            if editableTextField.isEditable {
                moveViewWithKeyboard(notification: notification, viewBottomConstraint: self.slideMenuViewBottomConstraint, keyboardWillShow: true)
            }
        }
        
        @objc func keyboardWillHide(_ notification: NSNotification) {
            moveViewWithKeyboard(notification: notification, viewBottomConstraint: self.slideMenuViewBottomConstraint, keyboardWillShow: false)
        }
        
        func moveViewWithKeyboard(notification: NSNotification, viewBottomConstraint: NSLayoutConstraint, keyboardWillShow: Bool) {
            // Keyboard's size
            guard let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else { return }
            let keyboardHeight = keyboardSize.height
            
            // Keyboard's animation duration
            let keyboardDuration = notification.userInfo![UIResponder.keyboardAnimationDurationUserInfoKey] as! Double
            
            // Keyboard's animation curve
            let keyboardCurve = UIView.AnimationCurve(rawValue: notification.userInfo![UIResponder.keyboardAnimationCurveUserInfoKey] as! Int)!
         
            let oldConstraint = oldConstraint[2]
            
            var newConstraint = self.slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -keyboardHeight)
            
            // Change the constant
            if keyboardWillShow {
                let safeAreaExists = (self.view?.window?.safeAreaInsets.bottom != 0) // Check if safe area exists
                                                                                                    
            }else {
                newConstraint = self.slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
            }
            
            if (oldConstraint.constant == newConstraint.constant ){
                return
            }
            // Animate the view the same way the keyboard animates
            let animator = UIViewPropertyAnimator(duration: keyboardDuration, curve: keyboardCurve) { [weak self] in
                // Update Constraints
                NSLayoutConstraint.deactivate([oldConstraint])
                
                NSLayoutConstraint.activate([newConstraint])
                self?.view.layoutIfNeeded()
            }
            
            animator.addCompletion({_ in
                self.oldConstraint[2] = newConstraint
            })
            
            // Perform the animation
            animator.startAnimation()
        }
 
    func addSlideViewContent()
    {
        editableTextField.text = webJSONInput
        editableTextField.font = UIFont.systemFont(ofSize: 15)
//        editableTextField.layer.st = UITextField.BorderStyle.roundedRect
//        editableTextField.autocorrectionType = UITextAutocorrectionType.no
//        editableTextField.keyboardType = UIKeyboardType.default
        editableTextField.returnKeyType = UIReturnKeyType.default
//        sampleTextField.delegate = self
        self.slideMenuView.addSubview(editableTextField)
        
        editableTextField.translatesAutoresizingMaskIntoConstraints = false
        self.editableTextField.delegate = self
        
        self.editableTextField.addDoneButton(title: "Done", target: self, selector: #selector(tapDone(sender:)))
        
    }
    
    @objc func btn_clicked(_ sender: UIBarButtonItem) {

        var newConstraint:[NSLayoutConstraint] = []
        
       
        
        if showSlideMenu
        {
            showSlideMenu = false
            
            newConstraint = self.getHideSlideConstraint()
            
            self.editableTextField.endEditing(true)
            
            
            self.webJSONInput = self.editableTextField.text
        }
        else
        {
            
            self.editableTextField.text = self.webJSONInput
            
            showSlideMenu = true
            
            newConstraint = self.getShowSlideConstraint()
            
        }
        
        let completionBlock =
        {
            (_ animationCompleted: Bool) in

            if !self.showSlideMenu
            {
                self.navigationItem.rightBarButtonItem?.title = "Edit JSON"
                self.loadChart(jsonString: self.webJSONInput)
            }
            else
            {
                self.navigationItem.rightBarButtonItem?.title = "Submit"
            }
            
            self.oldConstraint = newConstraint
            
        }
        
        
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveLinear, animations: {
            //            options: .curveEaseIn, animations: {
            NSLayoutConstraint.deactivate(self.oldConstraint)
            
            NSLayoutConstraint.activate(newConstraint)
            self.view.layoutIfNeeded()
            
            //            self.oldConstraint = newConstraint
        }, completion: completionBlock)
        
    }
    
    func getShowSlideConstraint() -> [NSLayoutConstraint]
    {
        let topConstraint = slideMenuView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50)
        let trailingConstraint = slideMenuView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let bottomConstraint = slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        let widthConstraint = slideMenuView.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 4/4)
        
        let editableTextFieldTopConstraint = editableTextField.topAnchor.constraint(equalTo: self.slideMenuView.topAnchor)
        let editableTextFieldTrailingConstraint = editableTextField.trailingAnchor.constraint(equalTo: self.slideMenuView.trailingAnchor)
        let editableTextFieldBottomConstraint = editableTextField.bottomAnchor.constraint(equalTo: self.slideMenuView.bottomAnchor)
        let editableTextFieldWidthConstraint = editableTextField.widthAnchor.constraint(equalTo: self.slideMenuView.widthAnchor)
        
        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
                             editableTextFieldTopConstraint,editableTextFieldTrailingConstraint,editableTextFieldBottomConstraint,editableTextFieldWidthConstraint]
        slideMenuViewBottomConstraint = bottomConstraint
        return newConstraint
    }
    
    func getHideSlideConstraint() -> [NSLayoutConstraint]
    {
        let topConstraint = slideMenuView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50)
        let trailingConstraint = slideMenuView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let bottomConstraint = slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        let widthConstraint = slideMenuView.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 0)
        
        let editableTextFieldTopConstraint = editableTextField.topAnchor.constraint(equalTo: self.slideMenuView.topAnchor)
        let editableTextFieldTrailingConstraint = editableTextField.trailingAnchor.constraint(equalTo: self.slideMenuView.trailingAnchor)
        let editableTextFieldBottomConstraint = editableTextField.bottomAnchor.constraint(equalTo: self.slideMenuView.bottomAnchor)
        let editableTextFieldWidthConstraint = editableTextField.widthAnchor.constraint(equalTo: self.slideMenuView.widthAnchor, multiplier: 0)
        

        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
                             editableTextFieldTopConstraint,editableTextFieldTrailingConstraint,editableTextFieldBottomConstraint,editableTextFieldWidthConstraint
                             ]
        
        slideMenuViewBottomConstraint = bottomConstraint
        return newConstraint
    }
    
    var showSlideMenu:Bool = false
    
    var oldConstraint:[NSLayoutConstraint] = []
    
   
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.editableTextField.endEditing(true)
           return false
       }
    
//    @objc func handleTap() {
//         editableTextField.resignFirstResponder() // dismiss keyoard
//     }
    
    @objc func tapDone(sender: Any) {
          self.view.endEditing(true)
//        editableTextField.resignFirstResponder()
      }

}

// MARK: - Codable


extension ParserViewController: NoteDelegate {
    
    func getTickSizeforEntry(axis: AxisBase, value: Double, chart: ChartViewBase) -> CGSize {
        
        let position = CGPoint(x: 0, y: 0)
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
       
        var size = textLayer.frame.size
        
        let imageSize = CGSize(width:min(size.width,30), height: 30)
        
        size.height += imageSize.height
        size.width = max(imageSize.width,textLayer.frame.width)
        
        return size
    }
    
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text: String, chart: ChartViewBase) -> TickLayer {
        
        var position = position
        var size = size
        
        
        let tickLayer = TickLayer()
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        tickLayer.addSublayer(textLayer)
        
        position.y += textLayer.frame.height
        size.height -= textLayer.frame.height
        
        let imageSize = CGSize(width: min(size.width,30), height: size.height)
        let imageLayer = CALayer()
        imageLayer.backgroundColor = UIColor.clear.cgColor
        imageLayer.bounds = CGRect(x: position.x-imageSize.width/2, y: position.y-imageSize.height/2 , width: imageSize.width, height: imageSize.height)
        imageLayer.position = CGPoint(x: position.x, y: position.y+imageSize.height/2)
        imageLayer.contents = UIImage(named: "sort1")?.cgImage  //UIImage(named:segment.imageName)?.cgImage
        tickLayer.addSublayer(imageLayer)
        
        return tickLayer
    }
    
    func shapePath(frame: CGRect, shapeInstance: ShapeProperties, entry: Any?, shapeLayer: CAShapeLayer) -> UIBezierPath {
        let path = CGMutablePath()

        let shapeSize = frame.width
        let shapeHalf = shapeSize / 2.0

        let circlePath = UIBezierPath()

        circlePath.move(to: CGPoint(x: frame.midX, y: frame.minY))
        circlePath.addLine(to: CGPoint(x: frame.midX, y: frame.maxY))
        circlePath.close()
        path.addPath(circlePath.cgPath)

        return UIBezierPath(cgPath: path)
    }
    

    
    
    
    
}

extension UITextView {
    
    func addDoneButton(title: String, target: Any, selector: Selector) {
        
        let toolBar = UIToolbar(frame: CGRect(x: 0.0,
                                              y: 0.0,
                                              width: UIScreen.main.bounds.size.width,
                                              height: 44.0))//1
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)//2
        let barButton = UIBarButtonItem(title: title, style: .plain, target: target, action: selector)//3
        toolBar.setItems([flexible, barButton], animated: false)//4
        self.inputAccessoryView = toolBar//5
    }
}

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
       assert(red >= 0 && red <= 255, "Invalid red component")
       assert(green >= 0 && green <= 255, "Invalid green component")
       assert(blue >= 0 && blue <= 255, "Invalid blue component")

       self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }

    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}
