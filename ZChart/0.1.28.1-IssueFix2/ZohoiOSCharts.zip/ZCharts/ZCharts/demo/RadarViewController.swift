//
//  RadarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 26/06/20.
//  Copyright © 2020 charts. All rights reserved.
//

import Foundation

import zchart
import UIKit

class RadarViewController: UIViewController,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
              
          if entry == nil
          {
              let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
              
              toolTipEntry1.valueTextColor = UIColor.black
              
              toolTipEntry1.labelFont = UIFont.boldSystemFont(ofSize: 20)
            
              toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
              
              entries.append(toolTipEntry1)
              
              return entries
          }
          
        let set = radarChartView.data?.getDataSetForEntry(entry)
        let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.xString)!), value: String(describing: entry?.y))
        toolTipEntry.valueTextColor = (set?.colors[0])!
        toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 20)
        
        entries.append(toolTipEntry)

        return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
      // Views Hide Options
       containerView?.title.titleEnabled = false
//       containerView?.legend.legendEnabled = true
       containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        containerView?.isAxisChart = false

                
//        containerView?.mainTitleSettings.text = "PieChart"//textSettings//.text = "PieChart"
        
        //addChartTypeAndData
        addPieChart()
    }
    
    var  radarChartView:ChartViewBase!
    
    func addPieChart(){
        
        //Chart Input Data
        radarChartView = containerView!.chartView.chart
        
        // MARK: Events
        
        radarChartView.tapEventListener?.handler = RadarHighlightHandler() //RotateAndHighlightHandler()   //CustomHandler()
        radarChartView.tapEventListener?.isEnabled = true
        radarChartView.tapEventListener?.delaysTouchesBegan = true
        
//        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        radarChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        radarChartView.panEventListener?.handler = PiePanHandler()
        radarChartView.panEventListener?.cancelsTouchesInView = false
        
//        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        radarChartView.touchEventsEnabled = false
        
        radarChartView.chartDescription?.enabled = false
        
        radarChartView.xAxis.scaleType = .Ordinal
        radarChartView.xAxis.axisLineColor = UIColor.green
        radarChartView.xAxis.gridColor = UIColor.black
//        radarChartView.xAxis.gridLineWidth =
        radarChartView.xAxis.drawAxisLineEnabled = false
        radarChartView.xAxis.maxLabelWidth = 40
        
        radarChartView.getYAxis(atIndex: 0)?.labelCount = 5
        radarChartView.getYAxis(atIndex: 0)?.yOffset = 5
        radarChartView.getYAxis(atIndex: 0)?.axisLineColor = UIColor.blue
        radarChartView.getYAxis(atIndex: 0)?.drawAxisLineEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.drawLabelsEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.gridColor = UIColor.gray.withAlphaComponent(0.3)
        radarChartView.getYAxis(atIndex: 0)?.drawTopYLabelEntryEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.drawBottomYLabelEntryEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.axisMinimum = 0
        
        
//        pieChartView.radius = 130
        
        // MARK: Data
        
        let data = [75,73,40,100,12,35,72,38]
        let dataLabel = ["Shawarma","French Fries","Chicken Wrap","Frankie","Coke","mayonnaise","Chips","Honey Wings"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
            var dataEntry:ChartDataEntry
            
            if i == 0 || i == 4 || i == 7
            {
                dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            }
            else{
                 dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            }
            
            piedata.append(dataEntry)
        }
        
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Foods")
        //chartDataSet.drawValuesEnabled = false
        
        //Custom Colors can be assigned
        chartDataSet.colors = [ChartColorTemplates.colorful()[0]]

        chartDataSet.valueTextColor = UIColor.black
      
        chartDataSet.plotType = .Radar
            
        (chartDataSet.dataSetOptions as! LineDataSetOptions).drawFilledEnabled = true
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).fillColor = ChartColorTemplates.colorful()[0]
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).shapeColors = [ChartColorTemplates.colorful()[0]]
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).mode = .montonic
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).markerInstance.shapeType = .circle
        
        let chartData = ChartData(dataSet: chartDataSet)

        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        radarChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let dialPlotOption = radarChartView.getPlotOptions(type: .Radar) as? DialPlotOptions
                else { return }
        
        
        dialPlotOption.startAngle = 270

        dialPlotOption.maxAngle = 360
        
        
        // MARK: Animate
        
//        radarChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
        let animateBlock = RadarViewController.getRadarAnimationBlock(barLineChart: radarChartView!, animationDuration: 1.0)
        CommonUtilities.customAnimation(chart: radarChartView!,duration:1,animationBlock: animateBlock)
    
        chartInstance.append(radarChartView)
        
    }
    
    public static func getRadarAnimationBlock(barLineChart:ChartViewBase,animationDuration:Double) -> (() -> Void) {
        let animationBlock = { [unowned barLineChart] in
            barLineChart.customAnimationInProgress = false
            guard let radarPlot = barLineChart.getPlotOptions(type: .Radar) as? DialPlotOptions,
                  let data = barLineChart.data,
                  data.dataSetCount > 0
            else { return }
            
            var dataSets:[ChartDataSet] = []
            var drawShapeEnabled:[LineDataSetOptions:Bool] = [:]
            
            for dataset in data.dataSets where dataset.visible && dataset.plotType == .Radar {
                let chartDataSet = dataset as! ChartDataSet
                
                dataSets.append(chartDataSet)
                if (dataset.dataSetOptions != nil ) {
                    let lineDataSetOptions = dataset.dataSetOptions as! LineDataSetOptions
                    if (lineDataSetOptions.drawShapeEnabled){
                        drawShapeEnabled[lineDataSetOptions] = lineDataSetOptions.drawShapeEnabled
                        lineDataSetOptions.drawShapeEnabled = false
                    }
                }
            }
            
            if (dataSets.count == 0) {
                return
            }
            
            let toPoints = ChartInteractionHelperFunction.prepareRectArrayforAllDataset(chart: barLineChart)
            
            var fromCenter:[[CGRect]] = []
            
            var toCenter:[[CGRect]] = []
            
            for set in dataSets
            {
                let index = data.indexOfDataSet(set)
                toCenter.append(toPoints[index])
            }
            
            for set in dataSets
            {
                var points:[CGRect] = []
                
                for entryIndex in 0..<set.entryCount
                {
                    let entry = set.entryForIndex(entryIndex)!
                    entry.centerChanged = radarPlot.centerCircleBox
                    
                    var point = CGRect()
                    point.origin = radarPlot.centerCircleBox
                    points.append(point)
                }
                fromCenter.append(points)
            }
            
            
                        
            let datasetXYInterpolator = ChartInteractionHelperFunction.getXYInterpolator(dataSets: dataSets, fromPoints: fromCenter, toPoints: toCenter)
            
            let radarAnimator = Animator()
            
            radarAnimator.updateBlock = ChartInteractionHelperFunction.getXYUpdateBlock(barLineChart: barLineChart, dataSets: dataSets, xInterpolateArray: datasetXYInterpolator.xInterpolateArray, yInterpolateArray: datasetXYInterpolator.yInterpolateArray, animator: radarAnimator)
            
            radarAnimator.stopBlock = { [unowned radarAnimator] in
                
                radarAnimator.updateBlock = nil
                
                ChartInteractionHelperFunction.setForcedValue(axisChartBase: barLineChart, enable: false)

                for lineDataSetOptions in drawShapeEnabled.keys {
                    lineDataSetOptions.drawShapeEnabled = drawShapeEnabled[lineDataSetOptions]!
                }
                
//                barLineChart.enableDrawValues()
                barLineChart.interactionAnimationInProgress = false

                barLineChart.setNeedsDisplay()
            }
            
            radarAnimator.animate(xAxisDuration: animationDuration/2, easingOption: .linear)
        }
        return animationBlock
    }
    

 
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
    
    
}
