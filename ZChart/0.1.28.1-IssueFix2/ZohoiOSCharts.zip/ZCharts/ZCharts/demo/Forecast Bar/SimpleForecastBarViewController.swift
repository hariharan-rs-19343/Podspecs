//
//  SimpleForecastBarViewController.swift
//  ZCharts
//
//  Created by Keerthivass B S on 22/01/24.
//  Copyright © 2024 charts. All rights reserved.
//

import UIKit
import zchart

class SimpleForecastBarViewController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
      
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return entries }
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
   
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String((dataSet?.entryForIndex(selectedIndex!)?.y)!))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! ChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }

    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
      //  containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
      //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler()

        barChartView?.getYAxis(atIndex: 1)!.enabled = false

        barChartView?.xAxis.axisTitle = "Years"

        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        barChartView?.xAxis.inverted = false
        
        totalSales = 0
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
//            let lab = "Item " + String(Double(i+1))
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
//            if i < 3
//            {
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
//            }

            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
//            if i > 2 && i < 6
//            {
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
//            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
//            }

            totalSales += CGFloat(val1+val2)

        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
        set2.plotType = .Bar
        
        let shapeProperties = (set2.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[1].withAlphaComponent(0.6)
        shapeProperties.customPathDataSource = self
        
        let datasets = [set1,set2]
        
        let chartData = ChartData(dataSets: datasets)
        
        // single forecast bar
        chartData.datasetsGroupArray = [[0,1]]
//        chartData.stackGroupArray = [[0],[1]]
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
//        barPlotOptions.isStacked = false
        
        barPlotOptions.barWidthPixel = 25

        barPlotOptions.barSpacePixel = 2

//        barPlotOptions.groupSpacePixel = 5
        
        barPlotOptions.minimumBarPixel = 25
        
        barPlotOptions.maximumBarPixel = 25
        
        barPlotOptions.fitBars = true
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
         barChartView?.xAxis.labelCount = 20
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
       
        
        barChartView?.chartDescription?.enabled = false
    }
    
}

extension SimpleForecastBarViewController: ShapeFactoryDataSource {
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer: CAShapeLayer) -> CGMutablePath {
        
        let size = shapeInstance.size
        
        return CGMutablePath(rect: CGRect(origin: CGPoint(x: point.x + (size.width / 2.0) - ((size.width * 0.5) / 2.0), y: point.y), size: CGSize(width: size.width * 0.5, height: size.height)), transform: nil)
    }
}
