//
//  MultiForecastBarViewController.swift
//  ZCharts
//
//  Created by Keerthivass B S on 22/01/24.
//  Copyright © 2024 charts. All rights reserved.
//

import UIKit
import zchart

class MultiForecastBarViewController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
      
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return entries }
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
   
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String((dataSet?.entryForIndex(selectedIndex!)?.y)!))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! ChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        return entries
    }

    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
      //  containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
      //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler()

        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        barChartView?.xAxis.inverted = false
        
        totalSales = 0
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        var dataEntries6: [ChartDataEntry] = []
        var dataEntries7: [ChartDataEntry] = []
        var dataEntries8: [ChartDataEntry] = []
        var dataEntries9: [ChartDataEntry] = []
        var dataEntries10: [ChartDataEntry] = []
        var dataEntries11: [ChartDataEntry] = []
        var dataEntries12: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
            
            dataEntries5.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries6.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries7.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries8.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries9.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries10.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries11.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            dataEntries12.append(ChartDataEntry(xString: lab, y: Double(arc4random_uniform(UInt32(range)) + 3), data: nil))
            
            totalSales += CGFloat(val1+val2+val3+val4)
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        //        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
        set2.plotType = .Bar
        
        //        set2.gradients = [gradient2]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        //        set3.gradients = [gradient3]
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        //        set4.gradients = [gradient4]
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Set5")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.label = "Company E"
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
        let set6:ChartDataSet = ChartDataSet(values: dataEntries6, label: "Set6")
        set6.colors = [ChartColorTemplates.pieColor()[5]]
        set6.label = "Company F"
        set6.plotType = .Bar
        
//        var shapeProperties = (set6.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
//        shapeProperties.shapeType = .custom
//        shapeProperties.holeColor = ChartColorTemplates.pieColor()[5].withAlphaComponent(0.6)
//        shapeProperties.customPathDataSource = self
        
        let set7:ChartDataSet = ChartDataSet(values: dataEntries7, label: "Set7")
        set7.colors = [ChartColorTemplates.pieColor()[6].withAlphaComponent(0.3)]
        set7.label = "Company G"
        set7.plotType = .Bar
        
        var shapeProperties = (set7.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[6]
        shapeProperties.customPathDataSource = self
        
        
        let set8:ChartDataSet = ChartDataSet(values: dataEntries8, label: "Set8")
        set8.colors = [ChartColorTemplates.pieColor()[7].withAlphaComponent(0.3)]
        set8.label = "Company H"
        set8.plotType = .Bar
        
        shapeProperties = (set8.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[7].withAlphaComponent(0.6)
        shapeProperties.customPathDataSource = self
        
        let set9:ChartDataSet = ChartDataSet(values: dataEntries9, label: "Set9")
        set9.colors = [ChartColorTemplates.pieColor()[8].withAlphaComponent(0.3)]
        set9.label = "Company I"
        set9.plotType = .Bar
        
        shapeProperties = (set9.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[8].withAlphaComponent(0.6)
        shapeProperties.customPathDataSource = self
        
        let set10:ChartDataSet = ChartDataSet(values: dataEntries10, label: "Set10")
        set10.colors = [ChartColorTemplates.pieColor()[9].withAlphaComponent(0.3)]
        set10.label = "Company J"
        set10.plotType = .Bar
        
        shapeProperties = (set10.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[9].withAlphaComponent(0.6)
        shapeProperties.customPathDataSource = self
        
        let set11:ChartDataSet = ChartDataSet(values: dataEntries11, label: "Set11")
        set11.colors = [ChartColorTemplates.pieColor()[10].withAlphaComponent(0.3)]
        set11.label = "Company K"
        set11.plotType = .Bar
        
        shapeProperties = (set11.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[10].withAlphaComponent(0.6)
        shapeProperties.customPathDataSource = self
        
        let set12:ChartDataSet = ChartDataSet(values: dataEntries12, label: "Set12")
        set12.colors = [ChartColorTemplates.pieColor()[11].withAlphaComponent(0.3)]
        set12.label = "Company L"
        set12.plotType = .Bar
        set12.dataSetOptions = BarDataSetOptions()
        
        shapeProperties = (set12.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.holeColor = ChartColorTemplates.pieColor()[11].withAlphaComponent(0.6)
        shapeProperties.customPathDataSource = self
        
        let datasets = [set1, set2, set3, set4, set5, set6, set7,set8,set9, set10, set11, set12]
        
        let chartData = ChartData(dataSets: datasets)
        
        // multi forecast bar
        chartData.datasetsGroupArray = [[0,6],[1,7],[2,8],[3,9],[4,10],[5,11]]
//        chartData.stackGroupArray =
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
//        barPlotOptions.isStacked = true
        
        barPlotOptions.barWidthPixel = 25
        
        barPlotOptions.barSpacePixel = 2
        
        barPlotOptions.groupSpacePixel = 5
        
        barPlotOptions.minimumBarPixel = 25
        
        barPlotOptions.maximumBarPixel = 25
        
        barPlotOptions.fitBars = true
        
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.xAxis.labelCount = 20
        
        //        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
    }
    
}

extension MultiForecastBarViewController: ShapeFactoryDataSource {
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer: CAShapeLayer) -> CGMutablePath {
        
        let size = shapeInstance.size
        
        return CGMutablePath(rect: CGRect(origin: CGPoint(x: point.x + (size.width / 2.0) - ((size.width * 0.5) / 2.0), y: point.y), size: CGSize(width: size.width * 0.5, height: size.height)), transform: nil)
    }
}
