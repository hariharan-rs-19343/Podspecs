//
//  WaterFallCustomLegendViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 26/07/22.
//  Copyright © 2022 charts. All rights reserved.
//

import UIKit
import zchart

class WaterFallCustomLegendViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator,LegendViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry!
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        containerView?.legendView.delegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
//        barChartView?.getYAxis(atIndex: 0)!.xOffset = 50

        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 50
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.labelRotationAngle = 60
        
        barChartView?.xAxis.tickLabelMode = .auto
        
        barChartView?.xAxis.customTickEnabled = true
        
        barChartView?.xAxis.axisLabelOffsets.marginTop = 0
        barChartView?.xAxis.axisLabelOffsets.marginBotom = 0
        barChartView?.xAxis.axisLabelOffsets.marginLeft = 10
        barChartView?.xAxis.axisLabelOffsets.marginRight = 10
        
        barChartView?.xAxis.axisTitleOffsets.marginTop = 0
        barChartView?.xAxis.axisTitleOffsets.marginBotom = 0
        barChartView?.xAxis.axisTitleOffsets.marginLeft = 10
        barChartView?.xAxis.axisTitleOffsets.marginRight = 10
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = false
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 20
        let range = 10
        
        var dataEntries1: [ChartDataEntry] = []
        
 
          for i in 0..<count {
            
              let lab = "W"+String(Double(i+1))
              
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
              
              let k = 1
              
              if i == 4 || i == 8 || i == 12 || i == 16 {
                  dataEntries1.append(ChartDataEntry(xString: lab, y: 0.0, plotData: k as NSNumber,data: nil))
              }
              else if i == 5 {
                  dataEntries1.append(ChartDataEntry(xString: nil, y: Double.nan,plotData: k as NSNumber, data: nil))
              }
              else if i == 1 || (i > 4 && i < 8) || (i > 12 && i < 16) {
                  dataEntries1.append(ChartDataEntry(xString: lab, y: -val1, plotData: nil,data: nil))
              }
              else if i == 19 {
                  dataEntries1.append(ChartDataEntry(xString: nil, y: val1,plotData: nil, data: nil))
              }
              else {
                  dataEntries1.append(ChartDataEntry(xString: lab, y: val1, plotData: nil,data: nil))
              }
            
            totalSales += CGFloat(val1)
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .WaterFall
        
        let dataSetOption = BarDataSetOptions()
        dataSetOption.barBorderWidth = 1
        dataSetOption.barBorderColor = UIColor.black
        
        set1.dataSetOptions = dataSetOption
        set1.risingCategorycolor = ChartColorTemplates.pieColor()[3]
        set1.fallingCategorycolor = ChartColorTemplates.pieColor()[0]
        set1.cascadedCategoryColor = ChartColorTemplates.pieColor()[2]
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! WaterFallPlotOptions
        
        barPlotOptions.connectorDashLengths = [2.0,2.0]
        
        barPlotOptions.roundedCorners = true
        
        barPlotOptions.roundedRadii = 5.0
        
        barPlotOptions.fitBars = true
        
        chartData.setDrawValues(true)
        
        barPlotOptions.barWidth = 0.7
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.barCount = 12
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 30
        
        //        chartData.highlightColor = UIColor.blue
        
        barPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
  
    }
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.maxLabelWidth = 30
        barChartView?.xAxis.maxLabelWidth = 60
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = ChartColorTemplates.pieColor()
        set1.plotType = .Bar
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.barWidth = 0.6
        
        plotOptions.minimumBarPixel = 18

        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 12
        
        
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.9
     
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false

        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
     
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        
        plotBackup.append(barChartView!.plotOptions)
        
        chartInstance.append(barChartView!)
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
      
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
       
    }
}

extension WaterFallCustomLegendViewController {
    
    func legendReloaded(_ chartView: ChartViewBase, _ legendEntries: [LegendEntry]?) {
            
            var legendEntries1 = [LegendEntry]()
            
            guard let chartData = chartView.data
            else {
                return
            }
        
            var cascadeflag = true
        
            var risingFlag = true
        
            var fallingFlag = true
            
            outerLoop:for dataSet in chartData.dataSets{
                
                for entryIndex in 0..<dataSet.entryCount {
                    
                    guard let entry = dataSet.entryForIndex(entryIndex) else {
                        continue
                    }
                    
                    var flag = false
                    
                    var color = dataSet.color(atIndex: 0)
                    
                    var label = ""
                    
                    if cascadeflag && WaterFallHelperFunction.isCascade(entry: entry) {
                        cascadeflag = false
                        flag = true
                        color = (dataSet as! ChartDataSet).cascadedCategoryColor!
                        label = "Cascade"
                    }
                    else if risingFlag && entry.y > 0.0 {
                        risingFlag = false
                        flag = true
                        color = (dataSet as! ChartDataSet).risingCategorycolor!
                        label = "Rising"
                    }
                    else if fallingFlag && entry.y < 0.0 {
                        fallingFlag = false
                        flag = true
                        color = (dataSet as! ChartDataSet).fallingCategorycolor!
                        label = "Falling"
                    }
                    
                    if flag {
                        let legendEntry = LegendEntry(
                                label: label,
                                form: dataSet.form,
                                formSize: dataSet.formSize,
                                formLineWidth: dataSet.formLineWidth,
                                formLineDashPhase: dataSet.formLineDashPhase,
                                formLineDashLengths: dataSet.formLineDashLengths,
                                formColor : color
                            )
                    
                        legendEntries1.append(legendEntry)
                    }
                }
                
            }
            
        containerView!.legendView.reload(legendEntries: legendEntries1)
    }
    
    func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        
        guard let chartData = barChartView?.data
        else {
            return
        }
        
        var removeEntries = [ChartDataEntry]()
        
        for dataSet in chartData.dataSets{
            
            for entryIndex in 0..<dataSet.entryCount {
                
                guard let datasetEntry = dataSet.entryForIndex(entryIndex) else {
                    continue
                }
                
                if WaterFallHelperFunction.isCascade(entry: datasetEntry) && entry.label == "Cascade" {
                    removeEntries.append(datasetEntry)
                    continue
                }
                else if datasetEntry.y > 0.0 && entry.label == "Rising" && !WaterFallHelperFunction.isCascade(entry: datasetEntry) {
                    removeEntries.append(datasetEntry)
                    continue
                }
                else if datasetEntry.y < 0.0 && entry.label == "Falling" && !WaterFallHelperFunction.isCascade(entry: datasetEntry) {
                    removeEntries.append(datasetEntry)
                    continue
                }
            }
            
        }
        
        barChartView?.updateDataOrigIndex()
        
        ChartInteractionHelperFunction.removeEntriesWithAnimation(entries: removeEntries, chart: barChartView!, duration: 0.5)
        
    }
    
    
}
