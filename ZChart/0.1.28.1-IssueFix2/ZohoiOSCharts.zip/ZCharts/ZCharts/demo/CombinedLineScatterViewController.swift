//
//  CombinedLineScatterViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 20/11/18.
//  Copyright © 2018 charts. All rights reserved.
//



import UIKit
import  zchart

class CombinedLineScatterViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry!
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
    }
    
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        //               containerView?.legend.legendEnabled = false
        //               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        //        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        //
        barChartView?.panEventListener?.handler = DefaultPanHandler()
        //
        //        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = DefaultPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 10
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
//        barChartView?.rightAxis.enabled = true
        
//        barChartView?.xAxis.wordWrapEnabled = false
        
        //  barChartView?.xAxis.autoRotateAngle = 90
        
        //  barChartView?.xAxis.autoRotateEnabled = false
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
//        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.getYAxis(atIndex: 1)!.scaleType = .Ordinal
        
        barChartView?.xAxis.maxLabelWidth = barChartView!.xAxis.labelWidth
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 1)!.valueFormatter = ValueFormatter(chart: barChartView!)
        
        //        barChartView?.leftAxis.baseLineEnabled = true
        //        barChartView?.leftAxis.baseLine?.baseValue = 400
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//
        
        totalSales = 0
        
        
        var dataSets:[ChartDataSet] = []
        
        for set in getScatterDataSets()
        {
            dataSets.append(set)
        }
        
        for set in getLineDataSets()
        {
            dataSets.append(set)
        }
        
        barChartView?.scalePreference = .Scatter
        
        barChartView?.data = ChartData(dataSets: dataSets)
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        //        barChartView?.barCount = 12
        
        //*****************************  MinMax and Colors  *******************************//
        
        
        //        chartData.highlightColor = UIColor.blue
        
        
        //*****************************  Animation  *******************************//
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //                barChartView?.leftAxis.addLimitLine(upperLimit)
        //                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
            dataBackup.append(barChartView?.data?.copy() as! ChartData)
            chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
    }
    
    
    
    func getLineDataSets() -> [ChartDataSet]
    {
        let count = 50
        let range:UInt32 = 2054
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            let lab = String((i+2000))
            
            let xVal = Double(i + 900)
            
            var val1 = arc4random_uniform(UInt32(range)) + 3
            
//            dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data:  nil))
            
            dataEntries1.append(ChartDataEntry(x: xVal, y: Double(val1), data: nil))
            
            
            
            //     dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            let val2 = arc4random_uniform(UInt32(range)) + (3 + range)
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val2), data:  nil))
            
            //            dataEntries2.append(ChartDataEntry(xString: Double(i), y: Double(val2), data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            let val3 = arc4random_uniform(UInt32(range)) + (3 + range * 2)
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data:  nil))
            
            //            dataEntries3.append(ChartDataEntry(xString: Double(i), y: Double(val3), data: nil))
            //            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
        }
        
        
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        set1.plotType = .Line
        
        let dataOptions1 = set1.dataSetOptions as! LineDataSetOptions
        
        let shape = dataOptions1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        dataOptions1.setShapeColor(UIColor.red)
        
        dataOptions1.lineWidth = 1
        dataOptions1.drawShapeEnabled = false
        
        dataOptions1.drawFilledEnabled = false
        dataOptions1.fillAlpha = 0.3
        dataOptions1.fillColor = ChartColorTemplates.pieColor()[5]
        dataOptions1.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Line
               
        let dataOptions2 = set2.dataSetOptions as! LineDataSetOptions
        
        let shape1 = dataOptions2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        dataOptions2.setShapeColor(UIColor.brown)
        
        dataOptions2.lineWidth = 0.5
        dataOptions2.drawShapeEnabled = false
        
        dataOptions2.drawFilledEnabled = true
        dataOptions2.fillAlpha = 0.3
        dataOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        dataOptions2.mode = .cubicBezier
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Line
               
        let dataOptions3 = set3.dataSetOptions as! LineDataSetOptions
        dataOptions3.setCircleColor(UIColor.black)
        dataOptions3.lineWidth = 0.5
        dataOptions3.circleRadius = 3.0
        dataOptions3.drawCircleHoleEnabled = false
        dataOptions3.drawCirclesEnabled = true
        dataOptions3.drawShapeEnabled = false
        
        dataOptions3.drawFilledEnabled = true
        dataOptions3.fillAlpha = 0.3
        dataOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        dataOptions3.mode = .cubicBezier
        
        
        
        
       /* let chartData = LineChartData(dataSets: [set1])                //LineChartData(dataSet: set1)
        //        let chartData = LineChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(false)*/
        
        //        chartData.isStacked = true
        
        return [set1]
    }
    
    func getScatterDataSets() -> [ChartDataSet]
    {
        let count = 50
        let range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        
        for i in 0..<count {
        
            // x - number , y - ordinal
            
             let newnum = Double(i + 900)
             var lab = "Item " + String( (arc4random_uniform(UInt32(range)) % 5 ) )
             
             dataEntries1.append(ChartDataEntry(x: newnum, yString: lab, data: nil))
            
            
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[6])
        set1.axisIndex = 1
        set1.plotType = .Scatter
        
        let dataOptions = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOptions.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape.shapeType = .circle
//        shape.shapeSize = 10
        shape.lineWidth = 2
    
        
//        let chartData = ScatterChartData(dataSets: [set1])
//        chartData.setDrawValues(false)
        
        
        return [set1]
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /* let chart = chartInstance[index]
         
         level = index
         
         barChartView = chart as! BarChartView
         
         chart.data = dataBackup[index].copy() as! ChartData
         
         chart.notifyDataSetChanged()
         
         dataBackup.removeLast(dataBackup.count-1 - index)
         
         chartInstance.removeLast(chartInstance.count-1 - index)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)*/
        
    }
    var orientationFlag = true

}

extension CombinedLineScatterViewController {

// MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }

        return themeImage
    }

    func addChartOrientationSwapButton(){

        let orientationSwapButton = UIButton(type: .custom)

        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)

        orientationSwapButton.setImage(buttonImage(), for: .normal)

        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)

        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true

        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true

        self.navigationItem.rightBarButtonItem = buttonItem
    }

    @objc func chartOrientationSwap(){

        if !orientationFlag{
            
            barChartView?.isRotated = false
            
            barChartView?.xAxis.tickLabelMode = .auto
            
            barChartView?.xAxis.maxLabelWidth = barChartView!.xAxis.labelWidth
            
            orientationFlag = true
        }
        else{
            
            barChartView?.isRotated = true
            
            barChartView?.xAxis.labelPosition = .bottom
            
            barChartView?.xAxis.tickLabelMode = .forced
            
            barChartView?.xAxis.maxLabelWidth = barChartView!.xAxis.labelWidth
            
            barChartView?.xAxis.labelRotationAngle = 0
            
            orientationFlag = false
        }

        barChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
    }
}
