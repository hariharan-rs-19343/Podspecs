//
//  ArrowPieController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 31/08/17.
//  Copyright © 2017 charts. All rights reserved.
//


import zchart
import UIKit

class ArrowPieController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        
        if entry == nil{
            let toolTipEntry = ToolTipEntry(label: " ", value: " ")
            toolTipEntry.valueTextColor = UIColor.black
            
            entries.append(toolTipEntry)
            
            return entries
        }
        
        let pieEntry = entry!
        let toolTipEntry = ToolTipEntry(label: pieEntry.xString!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = (entry?.entryColor)!
        
        entries.append(toolTipEntry)
        
      //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]

        
//        for i in 0...7
//        {
//            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
//            dummy.valueTextColor = entry.entryColor
//            entries.append(dummy)
//        }

        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Vertical
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        //       containerView?.titleView.showView = false
        //       containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        
        addPieChart()
        
        containerView?.title.titleEnabled = false
        
        containerView?.title.mainTitleSettings.alignment = .center
        containerView?.title.subTitleSettings.alignment = .center
        
        containerView?.title.mainTitleSettings.font = UIFont.systemFont(ofSize: 20)
        
        containerView?.isAxisChart = false
        
        //        addBarChart()
        
       /* containerView?.toolTipView.enableMenu = true
        containerView?.toolTipView.menuControl?.dataSource = self
        containerView?.toolTipView.menuControl?.menudelegate = self */
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
    }
    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
        
       // MARK: Events
        
        pieChartView.tapEventListener?.handler = RotateAndHighlightHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieArrowLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = true
        
        
        
      //  pieChartView.radius = 75
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        let data=[100,200,0,50,80,170,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"] //,"Pete Zachriah","Andy Roddick","Venus Powell"]
      //  let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            var dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil )
//            if i == 2 {
//                dataEntry = ChartDataEntry(value: Double.nan,label: dataLabel[i]+String(level))
//            }
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        chartDataSet.valueTextColor = UIColor.black
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
//        chartDataSet.gradients = getRadialGradientArray()
        
        chartDataSet.plotType = .Pie
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let piePlot = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        //  pieChartView.setPieType = .PieSpinWheel
           
               
        piePlot.drawHoleEnabled = false // Doughnut
        piePlot.drawEntryLabelsEnabled = false
        piePlot.centerLabelEnabled = true
        
        piePlot.arrowShow = true
        
        piePlot.patternEnabled = false
        
//        pieChartView.radius = pieChartView.frame.width/2
        
        // MARK: Animate
        
        PieHelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        plotBackup.append(pieChartView.plotOptions)
        
        chartInstance.append(pieChartView)
        
    }
    
    func getRadialGradientArray() -> [RadialGradient] {
        
        let gradient1 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[0]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient2 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[1]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient3 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[2]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient4 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[3]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient5 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[4]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient6 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[5]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        return [gradient1, gradient2, gradient3, gradient4, gradient5, gradient6]
    }
    
    func getLinearGradientArray() -> [LinearGradient] {
        
        let gradient1 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[0]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient2 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[1]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient3 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[2]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient4 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[3]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient5 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[4]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient6 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[5]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        
        return [gradient1, gradient2, gradient3, gradient4, gradient5, gradient6]
    }
    
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        level += 1
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
        
       
        // MARK: Events
        
        pieChartView.tapEventListener?.handler = RotateAndHighlightHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieArrowLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = true
        
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        let data=[100,200,150,50,80,170,140]
        
       // let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"] //,"Pete Zachriah","Andy Roddick","Venus Powell"]
          let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i]+String(level))
            let dataEntry = ChartDataEntry(xString: dataLabel[i]+String(level), y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        chartDataSet.valueTextColor = UIColor.black
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        chartDataSet.plotType = .Pie
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let piePlot = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        //  pieChartView.setPieType = .PieSpinWheel
               
               
       piePlot.drawHoleEnabled = false // Doughnut
       piePlot.drawEntryLabelsEnabled = false
       piePlot.centerLabelEnabled = true
        
        piePlot.arrowShow = true
        
        piePlot.patternEnabled = false
        
        //        pieChartView.radius = pieChartView.frame.width/2
        
        // MARK: Animate
        
        PieHelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        plotBackup.append(pieChartView.plotOptions)
        
        chartInstance.append(pieChartView)
        
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        PieHelperFunctions.rotateAndPositionMid(chart: chart)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
