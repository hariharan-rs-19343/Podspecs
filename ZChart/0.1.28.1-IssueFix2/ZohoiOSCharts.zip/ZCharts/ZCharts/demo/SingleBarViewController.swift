//
//  SingleBarViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 28/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  zchart

class SingleBarViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator,CustomTicksDelegate {
    
    func getTickSizeforEntry(axis: AxisBase, value: Double, chart: ChartViewBase) -> CGSize {
        
        let position = CGPoint(x: 0, y: 0)
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
       
        var size = textLayer.frame.size
        
        let imageSize = CGSize(width:min(size.width,30), height: 30)
        
        size.height += imageSize.height
        size.width = max(imageSize.width,textLayer.frame.width)
        
        return size
    }
    
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text: String, chart: ChartViewBase) -> TickLayer {
        
        var position = position
        var size = size
        
        
        let tickLayer = TickLayer()
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        tickLayer.addSublayer(textLayer)
        
        position.y += textLayer.frame.height
        size.height -= textLayer.frame.height
        
        let imageSize = CGSize(width: min(size.width,30), height: size.height)
        let imageLayer = CALayer()
        imageLayer.backgroundColor = UIColor.clear.cgColor
        imageLayer.bounds = CGRect(x: position.x-imageSize.width/2, y: position.y-imageSize.height/2 , width: imageSize.width, height: imageSize.height)
        imageLayer.position = CGPoint(x: position.x, y: position.y+imageSize.height/2)
        imageLayer.contents = UIImage(named: "usericon")?.cgImage  //UIImage(named:segment.imageName)?.cgImage
        tickLayer.addSublayer(imageLayer)
        
        return tickLayer
    }
    
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry!
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED 
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        barChartView?.rendererDelegate = self
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
//        barChartView?.xAxis.axisTitle = "Years"
        
//        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 0)?.drawLabelsEnabled = false
        
//        barChartView?.getYAxis(atIndex: 0)!.xOffset = 50

        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 50
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = true
        barChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = true
        barChartView?.getYAxis(atIndex: 0)?.drawLabelsEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)?.axisLabelOffsets.marginLeft = 0
        barChartView?.getYAxis(atIndex: 0)?.axisLabelOffsets.marginRight = 0
        barChartView?.getYAxis(atIndex: 0)?.axisTitleOffsets.marginLeft = 0
        barChartView?.getYAxis(atIndex: 0)?.axisTitleOffsets.marginRight = 0
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
//        barChartView?.xAxis.autoRotateAngle = 0
        
        barChartView?.xAxis.labelRotationAngle = 60
        
        barChartView?.xAxis.tickLabelMode = .auto
        
        barChartView?.xAxis.customTickEnabled = true
        
        barChartView?.customScaleEnabled = true
        barChartView?.setScaleMinima(1, scaleY: 1)
        
        barChartView?.xAxis.tickDelegate = self
        
        barChartView?.xAxis.axisLabelOffsets.marginTop = 0
        barChartView?.xAxis.axisLabelOffsets.marginBotom = 0
        barChartView?.xAxis.axisLabelOffsets.marginLeft = 10
        barChartView?.xAxis.axisLabelOffsets.marginRight = 10
        
        barChartView?.xAxis.axisTitleOffsets.marginTop = 0
        barChartView?.xAxis.axisTitleOffsets.marginBotom = 0
        barChartView?.xAxis.axisTitleOffsets.marginLeft = 10
        barChartView?.xAxis.axisTitleOffsets.marginRight = 10
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = false
//        barChartView?.customScaleEnabled = true
//        barChartView?.setScaleMinima(1, scaleY: 1)
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 30
        let range = 1200
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
 
        for i in 0..<count {
          
          var lab = "W"+String(Double(i+1))+"\n"+"22 Dec 2022\n" + "2022"
          
          if i > 10
          {
              lab += " Chennai"
          }
          
          if i > 25
          {
              lab += " Runners"
          }
          
          let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
        
//            dataEntries1.append(ChartDataEntry(y: Double(val1),data:lab as AnyObject))
//            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//          if (i == 15 || (i >= 1 && i <= 5) || (i > 25 && i < 30)) && i != 2 {
//              dataEntries1.append(ChartDataEntry(xString: nil, y: Double.nan, data: nil))
//          }else {
              dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//                if i == 0
//                {
//                    for i in 1...10
//                    {
//                    let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
//                   dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//                    }
//                }
//          }
          
//          let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
//
//          if i == 29
//          {
//              dataEntries1.append(ChartDataEntry(xString: "last", y: Double.nan, data: nil))
//          }
          
          totalSales += CGFloat(val1)
          
          
          
      }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        set1.valueFormatter = BarFormator()
        
      /*  let gradient = LinearGradient(colors: [UIColor.cyan, UIColor.blue], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set1.gradients = [gradient] */
        
    /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[5]]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[4]]
        
        let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
        //        chartData.stackSpacing = 25
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.fitBars = true
        
        chartData.setDrawValues(true)
        
//        barPlotOptions.barWidth = 0.7
        
//        barPlotOptions.barWidthPixel = 18
//
//        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.barCount = 12
        
        barPlotOptions.minOffset = 0
        
//        barPlotOptions.isStacked = true
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 30
        
        //        chartData.highlightColor = UIColor.blue
        
        barPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
//        let animateBlock = SingleBarViewController.getAnimationBlock(chartView: self.barChartView!)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 0.5)
        
        CommonUtilities.customAnimation(chart: barChartView!, duration: 1.0, animationBlock: animateBlock)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
//                barChartView?.leftAxis.addLimitLine(upperLimit)
//                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
  
    }
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
      //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.maxLabelWidth = 30
        barChartView?.xAxis.maxLabelWidth = 60
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = ChartColorTemplates.pieColor()
        set1.plotType = .Bar
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.barWidth = 0.6
        
        plotOptions.minimumBarPixel = 18

        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 12
        
        
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.9
     
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false

        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
     
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        
        plotBackup.append(barChartView!.plotOptions)
        
        chartInstance.append(barChartView!)
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
      
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
       
    }
    

    
    /*
     override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
     {
     
     super.viewWillTransition(to: size, with: coordinator)
     
     viewChanged = true
     /*  coordinator.animateAlongsideTransition(in: self.containerView, animation: { (UIViewControllerTransitionCoordinatorContext) in
     self.containerView.setNeedsUpdateConstraints()
     }, completion: nil)
     
     coordinator.animate(alongsideTransition: {, completion: <#T##((UIViewControllerTransitionCoordinatorContext) -> Void)?##((UIViewControllerTransitionCoordinatorContext) -> Void)?##(UIViewControllerTransitionCoordinatorContext) -> Void#>) */
     
     //   self.containerView?.legendView.collectionView?.reloadItems(at: (self.containerView?.legendView.collectionView?.indexPathsForVisibleItems)!)
     
     //self.containerView?.legendView.collectionView?.reloadSections(<#IndexSet#>)
     
     coordinator.animate(alongsideTransition: { context in
     // do whatever with your context
     self.containerView?.setNeedsUpdateConstraints()
     //            self.containerView?.legendView.collectionView?.performBatchUpdates({
     //            self.containerView?.legendView.collectionView?.setCollectionViewLayout((self.containerView?.legendView.collectionView?.collectionViewLayout)!, animated: true)
     //            }, completion: nil)
     context.viewController(forKey: UITransitionContextViewControllerKey.from)
     }, completion: nil)
     }
     
     var viewChanged:Bool = false
     
     override func viewWillLayoutSubviews() {
     super.viewWillLayoutSubviews()
     if viewChanged
     {
     //self.containerView?.legendView.collectionView?.collectionViewLayout.invalidateLayout()
     }
     }
     
     override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
     
     if viewChanged {
     viewChanged = false
     //   self.containerView?.legendView.collectionView?.performBatchUpdates({}, completion: nil)
     }
     }
     */
    
    func chartDataNil(chartView: ChartViewBase) {
        
        chartView.layer.sublayers?.removeAll()
        
        let chartViewFrame = chartView.frame
        
        let rect = CGRect(origin: CGPoint(x: chartViewFrame.midX - 100, y: chartViewFrame.midY - 100), size: CGSize(width: 200, height: 200))
        
        let imageView = UIImageView(frame: rect)
        
        imageView.image = UIImage(named: "nodataimage")
        
        chartView.addSubview(imageView)
        
        let text = "No Data to Show"
        
        let textAttributedText = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 10.0)]
        
        let labelSize = text.size(withAttributes: textAttributedText)
        
        let labelRect = CGRect(origin: CGPoint(x: chartViewFrame.midX - rect.width / 2.0, y: chartViewFrame.midY - labelSize.height / 2.0), size: CGSize(width: rect.width, height: labelSize.height))
        
        let label = UILabel(frame: labelRect)

        label.text = text
        
        label.textAlignment = .center
        
        chartView.addSubview(label)
        
    }

}


extension SingleBarViewController: RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        guard let barPlotoptions = chartView.getPlotOptions(type: .Bar) as? BarPlotOptions
        else {
            return
        }
        
        if barPlotoptions.isStacked {
            
        }
        else  {
            
            for barLayer in BarLayer.getAllBarLayer(chart: chartView) {
                
                guard let barRect = barLayer.barRect else {
                    continue
                }
                
                let isRotated = chartView.isRotated
                
                if (barRect.height == 0 && !isRotated) || (barRect.width == 0 && isRotated) {
                    
                    let path = CGMutablePath()
                                           
                    if isRotated {
                        path.move(to: barRect.origin)
                        path.addLine(to: CGPoint(x: barRect.origin.x, y: barRect.origin.y + barRect.height))
                        
                    }
                    else {
                        path.move(to: barRect.origin)
                        path.addLine(to: CGPoint(x: barRect.origin.x + barRect.width, y: barRect.origin.y))
                    }
                    
                    if let barSubLayers = barLayer.sublayers, barSubLayers.count > 1 {
                        (barSubLayers[0] as? ChartExtrasLayer)?.path = path
                        (barSubLayers[0] as? ChartExtrasLayer)?.strokeColor = barLayer.fillColor
                    }
                    else {
                        let layerForValueZero = CAShapeLayer()
                        layerForValueZero.path = path
                        layerForValueZero.strokeColor = barLayer.fillColor
                        barLayer.addSublayer(layerForValueZero)
                    }
                }
            }
        }
    }
    
    func delegateToHighlight(layer: ChartEntryLayer, isHighlighted: Bool) {
        
        if !isHighlighted {
            layer.opacity = 0.3
        }
    }
}

class BarFormator: DefaultValueFormatter {
    
    override func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
        
        return String(value) + "dummy longest value"
    }
}

