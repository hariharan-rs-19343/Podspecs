//
//  DialViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 30/09/19.
//  Copyright © 2019 charts. All rights reserved.
//

import Foundation

import zchart
import UIKit

class DialViewController: UIViewController,IToolTipEntryGenerator, RendererDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            return entries
        }
        
        let pieEntry = entry!
        let toolTipEntry = ToolTipEntry(label: pieEntry.xString!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = (entry?.entryColor)!
        
        entries.append(toolTipEntry)
        
       return entries
    }
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        drawDataLabelOnData(chart: chartView)
    }
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
      // Views Hide Options
       containerView?.title.titleEnabled = false
       containerView?.legend.legendEnabled = true
       containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        containerView?.isAxisChart = false

                
//        containerView?.mainTitleSettings.text = "PieChart"//textSettings//.text = "PieChart"
        
        //addChartTypeAndData
        addPieChart()
    }
    
    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
        
        // MARK: Events
        
        pieChartView.tapEventListener?.handler = DialHandler()//SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
//        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.handler = PiePanHandler()
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
//        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        
        pieChartView.getYAxis(atIndex: 0)?.labelCount = 5
        pieChartView.getYAxis(atIndex: 0)?.yOffset = 5
        pieChartView.getYAxis(atIndex: 0)?.visible = false
        pieChartView.getYAxis(atIndex: 0)?.axisMaximum = 100
        pieChartView.rendererDelegate = self
        
        
//        pieChartView.radius = 130
        
        // MARK: Data
        
        let data = [0]
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]), label: dataLabel[i], data: nil)
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        chartDataSet.drawValuesEnabled = false
        //chartDataSet.drawValuesEnabled = false
        
        
        //Custom Colors can be assigned
        chartDataSet.colors = ChartColorTemplates.colorful()
        
//        chartDataSet.gradients = getRadialGradientArray()
        
       // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.black
        
//        chartDataSet.sliceSpace = 10
        
        chartDataSet.plotType = .Dial
        
        let chartData = ChartData(dataSet: chartDataSet)

//        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let dialPlotOption = pieChartView.getPlotOptions(type: .Dial) as? DialPlotOptions
                else { return }
        
        
//        dialPlotOption.startAngle = 180
             
        dialPlotOption.maxAngle = 180
              
        dialPlotOption.direction = .clockwise
              
        dialPlotOption.bandWidth = 0.1
       
        dialPlotOption.innerRadiusPercent = 0.9
               
        dialPlotOption.roundedCorners =  true
              
        dialPlotOption.needleShapeProperties.strokeColor = UIColor.black
        
        dialPlotOption.needleShapeProperties.holeColor = UIColor.black
        
        dialPlotOption.needleShapeProperties.lineWidth = 2
       
        dialPlotOption.needleShapeProperties.size = CGSize(width: 20.0, height: 20.0)
      
        dialPlotOption.needleShapeProperties.padding = 0.2
            
        dialPlotOption.drawEntryLabelsEnabled = false
        
        dialPlotOption.valueLinePart2Length = 0.6
        
        dialPlotOption.arrowShow = false
        
        dialPlotOption.patternEnabled = false
        
        dialPlotOption.outerCircleEnabled = false
        
        dialPlotOption.innerCircleEnabled = false
        
        dialPlotOption.centerLabelEnabled = false
        
        dialPlotOption.drawHoleEnabled = false
        
        dialPlotOption.holeRadiusPercent = 0.8
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
       
        chartInstance.append(pieChartView)
        
    }
 
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
    
    
}
extension DialViewController {
    
    func drawDataLabelOnData(chart: ChartViewBase) {
        
        guard let polarTransformer = chart.getTransformer(axisIndex: 0) as? PolarTransformer,
              let dataSets = chart.data?.dataSets,
              let dialOption = chart.getPlotOptions(type: .Dial) as? DialPlotOptions else {
            return
        }
        
        let chartRadius = dialOption.radius
        let chartCenter = dialOption.centerCircleBox
        for dataSet in dataSets where dataSet.isVisible
        {
            
            if chart.chartAnimator.phaseX != 1.0
            {
                continue
            }
            
            for index in 0..<(dataSet.entryCount)
            {
                guard let e = dataSet.entryForIndex(index)
                    else { continue }
                
                let value = e.y.isNaN ? 0 : e.y
                
                let text = String(value)
                
                let textSize = text.size(withAttributes: [NSAttributedString.Key.font: dataSet.valueFont])
                
                let angle = polarTransformer.absoluteAngleForValue(value: value)
                
                let radius = chartRadius + (textSize.width/2)
                
                let point = ChartUtils.getPosition(center: chartCenter, dist: radius, angle: angle)
                
                let attributes = [NSAttributedString.Key.font: dataSet.valueFont, NSAttributedString.Key.foregroundColor: dataSet.valueTextColor]
                
                let dataLabel = ChartUtils.drawTextLayer(text: text, point: point, align: .center, attributes: attributes)
                
                let tickLayer = TickLayer()
                
                tickLayer.addSublayer(dataLabel)
                
                chart.layer.addSublayer(tickLayer)
            }
        }
    }
}
