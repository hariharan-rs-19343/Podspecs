//
//  ChartChangeViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 11/03/20.
//  Copyright © 2020 charts. All rights reserved.
//


import zchart
import UIKit

class ChartChangeViewController: UIViewController,IToolTipEntryGenerator,PlotDelegate, ChartViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var containerView:ChartContainer? = nil
    
    var chartInstance:[ChartViewBase] = []
    
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    // MARK: - Delegates
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
            let pieEntry = entry!

            
            let toolTipEntry = ToolTipEntry(label: pieEntry.xString!, value: String(pieEntry.y))
            toolTipEntry.valueTextColor = (entry?.entryColor)!
            toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 17)
        
            toolTipEntry.labelTextAlignment = .left
        
            toolTipEntry.valueTextAlignment = .right
            
            var labels:[String] = ["Sales","Avg. Cost","No. of Customers","Others","Label 5","Label 6","Label 7","Label 8"]
            
            
            
            entries.append(toolTipEntry)
        
            for i in 0...7
            {
                let dummy = ToolTipEntry(label: labels[i], value: String((pieEntry.y/2)+Double(i+5)))
                dummy.valueTextColor = (entry?.entryColor)!
                
                dummy.labelTextAlignment = .left
                
                dummy.valueTextAlignment = .right
                entries.append(dummy)
            }
        
       return entries
    }
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
//        for type in pieChartView.getPlotTypes()
//        {
            switch  type {
                case .Bar:
                    updateBarPlot(plotOptions: plotOption as! BarPlotOptions)
                case .Line:
                    updateLinePlot(plotOptions: plotOption as! LinePlotOptions)
                default:
                    updatePiePlot(piePlotOption:plotOption as! PiePlotOptions)
            }
//        }
    }
    
    func updatePiePlot(piePlotOption:PiePlotOptions)
    {
//        guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
//            else { return }
        
        piePlotOption.valueLinePart2Length = 0.6
        
        piePlotOption.drawHoleEnabled = false // Doughnut
        
        piePlotOption.drawEntryLabelsEnabled = false
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        piePlotOption.sliceDirection = .clockwise
    }
    
    func updateBarPlot(plotOptions:BarPlotOptions)
    {
//        guard let plotOptions = (pieChartView.getPlotOptions(type: .Bar) as? BarPlotOptions)
//        else { return }
        
        plotOptions.barWidth = 0.6
        
        plotOptions.minimumBarPixel = 18
    }
    
    func updateLinePlot(plotOptions:LinePlotOptions)
    {
//        guard let plotOptions = pieChartView.getPlotOptions(type: .Funnel) as? FunnelPlotOptions
//        else { return }
        
        
    }
    // MARK: - View Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addView()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
      // Views Hide Options
       containerView?.title.titleEnabled = false
       containerView?.legend.legendEnabled = true
       containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        containerView?.isAxisChart = false

                
//        containerView?.mainTitleSettings.text = "PieChart"//textSettings//.text = "PieChart"
        
        //addChartTypeAndData
        
        addPieChart()
        
        //        addBarChart()
        
      /*  containerView?.toolTipView.enableMenu = true
        containerView?.toolTipView.menuControl?.dataSource = self
        containerView?.toolTipView.menuControl?.menudelegate = self */
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
    }
    
    override func didReceiveMemoryWarning() {
           super.didReceiveMemoryWarning()
           // Dispose of any resources that can be recreated.
       }
       
   override func viewDidAppear(_ animated: Bool) {
       super.viewDidAppear(animated)
       
       //         let leftButton =  UIBarButtonItem(title: "Save", style:   .plain, target: self, action: #selector(self.btn_clicked(_:)))
       
       let rightButton = UIBarButtonItem(title: "Chart Types", style: .plain, target: self, action: #selector(self.btn_clicked(_:)))
       
       // Create two buttons for the navigation item
       navigationItem.rightBarButtonItem = rightButton
       
   }
       
   override func viewWillDisappear(_ animated: Bool) {
       super.viewWillDisappear(animated)
       
       
       if self.isMovingFromParent {
           
       }
   }
    
    var pieChartView:ChartViewBase!
    
    // MARK: - Chart Input Data
    func addPieChart(){
        
      pieChartView   = containerView!.chartView.chart
        
        pieChartView.plotDelegate = self
       
        pieChartView.touchEventsEnabled = false
    
        
        pieChartView.xAxis.drawGridLinesEnabled = false
        pieChartView.xAxis.labelPosition = .bottom
        
        // MARK: Data
//        let data=[10,200,150,-50,0,-7,140]
let data = [265190,176240,137440,118050,71200]
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        chartDataSet.valueTextColor = NSUIColor.white
        chartDataSet.valueFont = NSUIFont.systemFont(ofSize: 13.0)

        chartDataSet.valueTextColor = UIColor.black
        
        chartDataSet.plotType = .Pie
    
        let chartData = ChartData(dataSet: chartDataSet)

        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        
        // MARK: Plot Options
        
        guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
            else { return }
        
        piePlotOption.valueLinePart2Length = 0.6
        
        piePlotOption.drawHoleEnabled = false // Doughnut
        
        piePlotOption.drawEntryLabelsEnabled = false
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        piePlotOption.sliceDirection = .clockwise
      
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
     
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        plotBackup.append(pieChartView.plotOptions)
       
        chartInstance.append(pieChartView)
        
    }
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    // MARK: - Drill Input Data
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
        level += 1
        
        
        let pieChartView = containerView!.chartView.chart
        
       // MARK: Events
        
        pieChartView.tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.handler = PiePanHandler()
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        // MARK: Data
        
        let data=[100,200,150,50,80,170,140]
        
        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry] = []
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i]+String(level))
            let dataEntry = ChartDataEntry(xString: dataLabel[i]+String(level), y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        chartDataSet.plotType = .Pie
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        chartDataSet.valueTextColor = UIColor.black
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        //  pieChartView.setPieType = .PieSpinWheel
               
       piePlotOption.drawHoleEnabled = false // Doughnut
       piePlotOption.drawEntryLabelsEnabled = false
       piePlotOption.centerLabelEnabled = true
        
       // chartview?.usePercentValuesEnabled=true
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        plotBackup.append(pieChartView.plotOptions)
        
        chartInstance.append(pieChartView)
        
        /*let data=[100,200,150,50,80,170,140]

        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        let pieChartView = chartView as! PieChartView
        
        pieChartView.data = chartData
        
        pieChartView.arrowShow = false
        
        pieChartView.patternEnabled = false
        
        pieChartView.outerCircleEnabled = false
        
//        pieChartView.innerCircleEnabled = false
        
//        pieChartView.centerLabelEnabled = false
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)*/
        
    }
    
    // MARK: - Drill Reverted
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 1.0, easingOption: .linear)
    }

    
    // MARK: - Slider Menu
   
    let slideMenuView = UIView()
    
    var showSlideMenu:Bool = false
    
    var oldConstraint:[NSLayoutConstraint] = []
    
    var selectedOrientation:String? = nil
    
    var selectedChartType:String? = nil
    
    let chartOrientationPicker = UIPickerView()
    
    let chartOrientationLabel = UILabel()
    
    
    let chartTypePicker = UIPickerView()
    
    let chartTypeLabel = UILabel()
    
    
    let chartOrientationData = ["Horizontal", "Vertical"]
    
//    let chartTypes = ["Pie", "Dial", "Bar", "Line", "HorizontalBar", "Scatter", "Bubble", "Funnel", "HeatMap", "Combined", "Bullet", "HorizontalBullet" ]
   
    let chartTypes = ["Pie", "Bar", "Line"]
    
    // MARK: - Slider Target
    
    func addView()
    {
        self.view.addSubview(slideMenuView)
        
        addOptions()
       
        slideMenuView.translatesAutoresizingMaskIntoConstraints = false
        
        oldConstraint = self.getHideSlideConstraint()
        
        NSLayoutConstraint.activate(oldConstraint)
        
        slideMenuView.backgroundColor = UIColor.white
        
        slideMenuView.layer.borderWidth = 2.0
        
    }
    
    func addOptions()
    {
        
        slideMenuView.addSubview(chartOrientationLabel)
        
        slideMenuView.addSubview(chartOrientationPicker)
        
        chartOrientationLabel.translatesAutoresizingMaskIntoConstraints = false
        
        chartOrientationPicker.translatesAutoresizingMaskIntoConstraints = false
        
        chartOrientationLabel.text = "Orientation"
        
        chartOrientationLabel.textAlignment = .center
        
        
        
        chartOrientationPicker.backgroundColor = UIColor.clear
        chartOrientationPicker.dataSource = self
        chartOrientationPicker.delegate = self
        
        
        
        slideMenuView.addSubview(chartTypeLabel)
        
        slideMenuView.addSubview(chartTypePicker)
        
        chartTypeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        chartTypePicker.translatesAutoresizingMaskIntoConstraints = false
        
        chartTypeLabel.text = "Chart Types"
        
        chartTypeLabel.textAlignment = .center
        
        
        chartTypePicker.backgroundColor = UIColor.clear
        chartTypePicker.dataSource = self
        chartTypePicker.delegate = self
        
        self.selectedChartType = chartTypes[0]
        self.selectedOrientation = chartOrientationData[0]
        
    }
    
    @objc func btn_clicked(_ sender: UIBarButtonItem) {

        var newConstraint:[NSLayoutConstraint] = []
        
        if showSlideMenu
        {
            showSlideMenu = false
            
            newConstraint = self.getHideSlideConstraint()
            
        }
        else
        {
            showSlideMenu = true
            
            newConstraint = self.getShowSlideConstraint()
            
        }
        
        let completionBlock =
        {
            (_ animationCompleted: Bool) in

            if !self.showSlideMenu
            {
                if self.selectedOrientation != nil  || self.selectedChartType != nil
                {
                    
//                    if self.selectedOrientation != nil
//                    {
//                        var orientation:LegendOrientation = .Horizontal
//
//                        if self.selectedOrientation == "Vertical"
//                        {
//                            orientation = .Vertical
//                        }
//                        self.containerView?.legend.legendOrientation = orientation
//                        self.selectedOrientation  = nil
//                    }
    
                    
                    if self.selectedChartType != nil
                    {
                        
                        
                        switch self.selectedChartType {

                            case "Bar":
                                self.containerView?.isAxisChart = true
                                self.containerView?.updateConstraints()
                                self.pieChartView.xAxis.enabled = true
                                self.pieChartView.xAxis.scaleType = .Ordinal
                                self.pieChartView.getYAxis(atIndex: 0)?.enabled = true
                                for set in (self.pieChartView.data?.dataSets)!
                                {
                                    set.plotType = .Bar
                                }
                                break
                            
                            case "Line":
                                self.containerView?.isAxisChart = true
                                self.containerView?.updateConstraints()
                                self.pieChartView.xAxis.enabled = true
                                self.pieChartView.xAxis.spaceMinPixel = 20
                                self.pieChartView.xAxis.spaceMaxPixel = 20
                                self.pieChartView.getYAxis(atIndex: 0)!.enabled = true
                                for set in (self.pieChartView.data?.dataSets)!
                                {
                                    set.plotType = .Line
                                    let lineDataSetOptions1 = LineDataSetOptions()
                                    set.dataSetOptions = lineDataSetOptions1
                                    
                                    let shape = lineDataSetOptions1.markerInstance
                                    //shape.holeColor = UIColor.white
                                    shape.shapeType = .circle
                                    shape.size = CGSize(width: 8.0, height: 8.0)
                                    shape.lineWidth = 2
                                    
                                    lineDataSetOptions1.setShapeColor(UIColor.red)
                                    
                                    lineDataSetOptions1.lineWidth = 1
                                    lineDataSetOptions1.drawShapeEnabled = true
                                    
                                    lineDataSetOptions1.drawFilledEnabled = false
                                    lineDataSetOptions1.fillAlpha = 0.3
                                    lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[5]
                                    lineDataSetOptions1.mode = .linear
                                }
                                
                                break
                            
                           /*
                             case "Dial":
                             for set in (self.pieChartView.data?.dataSets)!
                             {
                                 set.plotType = .Dial
                             }
                             break
                             
                            case "Line":
                            for set in (self.pieChartView.data?.dataSets)!
                            {
                                set.plotType = .Line
                            }
                            break
                            
                            case "HorizontalBar":
                            for set in (self.pieChartView.data?.dataSets)!
                            {
                                set.plotType = .HorizontalBar
                            }
                            break
                            
                            case "Scatter":
                            for set in (self.pieChartView.data?.dataSets)!
                            {
                                set.plotType = .Scatter
                            }
                            break
                            
                            case "Bubble":
                            for set in (self.pieChartView.data?.dataSets)!
                            {
                                set.plotType = .Bubble
                            }
                            break
                            
                            case "Funnel":
                            for set in (self.pieChartView.data?.dataSets)!
                            {
                                set.plotType = .Funnel
                            }
                            break
                            
                            case "HeatMap":
                            for set in (self.pieChartView.data?.dataSets)!
                            {
                                set.plotType = .HeatMap
                            }
                            break*/
                            
                            default:
                                self.containerView?.isAxisChart = false
                                self.containerView?.updateConstraints()
                                self.pieChartView.xAxis.enabled = false
                                self.pieChartView.getYAxis(atIndex: 0)!.enabled = false
                                for set in (self.pieChartView.data?.dataSets)!
                                {
                                    set.plotType = .Pie
                                }
                                
                        }
                        
                        self.pieChartView.notifyPlotUpdated()
                        
                    }
                    
                    //To call relayout
                    self.containerView?.currentOrientation = .Undefined
                    self.containerView?.setNeedsUpdateConstraints()
                    
                }
                
                
                
            }
            
            self.oldConstraint = newConstraint
            
        }
        
        
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0.1, options: .curveLinear, animations: {
            //            options: .curveEaseIn, animations: {
            NSLayoutConstraint.deactivate(self.oldConstraint)
            
            NSLayoutConstraint.activate(newConstraint)
            self.view.layoutIfNeeded()
            
            //            self.oldConstraint = newConstraint
        }, completion: completionBlock)
        
    }
        
    
    
    // MARK: - Slider Constraints
    func getShowSlideConstraint() -> [NSLayoutConstraint]
    {
        let topConstraint = slideMenuView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50)
        let trailingConstraint = slideMenuView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let bottomConstraint = slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        let widthConstraint = slideMenuView.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 3/4)
        
        
        
        let legOrLabtopConstraint = chartOrientationLabel.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrLableadingConstraint = chartOrientationLabel.leadingAnchor.constraint(equalTo: slideMenuView.leadingAnchor)
        let legOrLabtrailingConstraint = chartOrientationLabel.trailingAnchor.constraint(equalTo: chartOrientationPicker.leadingAnchor)
        let legOrLabheightConstraint = chartOrientationLabel.heightAnchor.constraint(equalTo: chartOrientationPicker.heightAnchor)
        let legOrLabWidthConstraint = chartOrientationLabel.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        
        let legOrtopConstraint = chartOrientationPicker.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrleadingConstraint = chartOrientationPicker.leadingAnchor.constraint(equalTo: chartOrientationLabel.trailingAnchor)
        let legOrtrailingConstraint = chartOrientationPicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legOrheightConstraint = chartOrientationPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let legOrWidthConstraint = chartOrientationPicker.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        
        
        let legPosLabtopConstraint = chartTypeLabel.topAnchor.constraint(equalTo: chartOrientationLabel.bottomAnchor)
        let legPosLableadingConstraint = chartTypeLabel.leadingAnchor.constraint(equalTo: slideMenuView.leadingAnchor)
        let legPosLabtrailingConstraint = chartTypeLabel.trailingAnchor.constraint(equalTo: chartTypePicker.leadingAnchor)
        let legPosLabheightConstraint = chartTypeLabel.heightAnchor.constraint(equalTo: chartTypePicker.heightAnchor)
        let legPosLabWidthConstraint = chartTypeLabel.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        
        let legPostopConstraint = chartTypePicker.topAnchor.constraint(equalTo: chartOrientationPicker.bottomAnchor)
        let legPosleadingConstraint = chartTypePicker.leadingAnchor.constraint(equalTo: chartTypeLabel.trailingAnchor)
        let legPostrailingConstraint = chartTypePicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legPosheightConstraint = chartTypePicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let legPosWidthConstraint = chartTypePicker.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        /*
        let toolTypeLabtopConstraint = tooltipTypeLabel.topAnchor.constraint(equalTo: legendPositionLabel.bottomAnchor)
        let toolTypeLableadingConstraint = tooltipTypeLabel.leadingAnchor.constraint(equalTo: slideMenuView.leadingAnchor)
        let toolTypeLabtrailingConstraint = tooltipTypeLabel.trailingAnchor.constraint(equalTo: tooltipTypePickerView.leadingAnchor)
        let toolTypeLabheightConstraint = tooltipTypeLabel.heightAnchor.constraint(equalTo: tooltipTypePickerView.heightAnchor)
        let toolTypeLabWidthConstraint = tooltipTypeLabel.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        
        
        
        let toolTypePictopConstraint = tooltipTypePickerView.topAnchor.constraint(equalTo: legendPositionPicker.bottomAnchor)
        let toolTypePicleadingConstraint = tooltipTypePickerView.leadingAnchor.constraint(equalTo: tooltipTypeLabel.trailingAnchor)
        let toolTypePictrailingConstraint = tooltipTypePickerView.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let toolTypePicheightConstraint = tooltipTypePickerView.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let toolTypePicWidthConstraint = tooltipTypePickerView.widthAnchor.constraint(equalTo: slideMenuView.widthAnchor, multiplier: 0.5)
        */
        
        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
                             legOrLabtopConstraint,legOrLableadingConstraint,legOrLabtrailingConstraint,legOrLabheightConstraint,legOrLabWidthConstraint,
                             legOrtopConstraint, legOrleadingConstraint, legOrtrailingConstraint, legOrheightConstraint,legOrWidthConstraint,
                             
                             legPosLabtopConstraint,legPosLableadingConstraint,legPosLabtrailingConstraint,legPosLabheightConstraint,legPosLabWidthConstraint,
                             legPostopConstraint,legPosleadingConstraint,legPostrailingConstraint,legPosheightConstraint,legPosWidthConstraint]
                             
                           /*  toolTypeLabtopConstraint, toolTypeLableadingConstraint, toolTypeLabtrailingConstraint,toolTypeLabheightConstraint, toolTypeLabWidthConstraint,
                             
                             toolTypePictopConstraint, toolTypePicleadingConstraint, toolTypePictrailingConstraint, toolTypePicheightConstraint, toolTypePicWidthConstraint
        ] */
        
        
        return newConstraint
    }
    
    func getHideSlideConstraint() -> [NSLayoutConstraint]
    {
        let topConstraint = slideMenuView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50)
        let trailingConstraint = slideMenuView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let bottomConstraint = slideMenuView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        let widthConstraint = slideMenuView.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 0)
        
        
        let legOrLabtopConstraint = chartOrientationLabel.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrLableadingConstraint = chartOrientationLabel.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legOrLabtrailingConstraint = chartOrientationLabel.trailingAnchor.constraint(equalTo: chartOrientationPicker.trailingAnchor)
        //        let legOrLabheightConstraint = legendOrientationLabel.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.15)
        let legOrLabWidthConstraint = chartOrientationLabel.widthAnchor.constraint(equalToConstant: 0)
        
        
        let legOrtopConstraint = chartOrientationPicker.topAnchor.constraint(equalTo: slideMenuView.topAnchor)
        let legOrleadingConstraint = chartOrientationPicker.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legOrtrailingConstraint = chartOrientationPicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        //        let legOrheightConstraint = legendOrientationPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.15)
        let legOrWidthConstraint = chartOrientationPicker.widthAnchor.constraint(equalToConstant: 0)
        //
        //        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
        //                              legOrLabtopConstraint,legOrLableadingConstraint,legOrLabtrailingConstraint,legOrLabheightConstraint,legOrLabWidthConstraint,
        //            legOrtopConstraint, legOrleadingConstraint, legOrtrailingConstraint, legOrheightConstraint,legOrWidthConstraint]
        //
        
        
        let legPosLabtopConstraint = chartTypeLabel.topAnchor.constraint(equalTo: chartOrientationLabel.bottomAnchor)
        let legPosLableadingConstraint = chartTypeLabel.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legPosLabtrailingConstraint = chartTypeLabel.trailingAnchor.constraint(equalTo: chartTypePicker.trailingAnchor)
        //        let legPosLabheightConstraint = legendPositionLabel.heightAnchor.constraint(equalTo: legendPositionPicker.heightAnchor)
        let legPosLabWidthConstraint = chartTypeLabel.widthAnchor.constraint(equalToConstant: 0)
        
        
        
        let legPostopConstraint = chartTypePicker.topAnchor.constraint(equalTo: chartOrientationPicker.bottomAnchor)
        let legPosleadingConstraint = chartTypePicker.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let legPostrailingConstraint = chartTypePicker.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        //        let legPosheightConstraint = legendPositionPicker.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.15)
        let legPosWidthConstraint = chartTypePicker.widthAnchor.constraint(equalToConstant: 0)
        
       /*
        let toolTypeLabtopConstraint = tooltipTypeLabel.topAnchor.constraint(equalTo: legendPositionLabel.bottomAnchor)
        let toolTypeLableadingConstraint = tooltipTypeLabel.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let toolTypeLabtrailingConstraint = tooltipTypeLabel.trailingAnchor.constraint(equalTo: tooltipTypePickerView.trailingAnchor)
        //        let toolTypeLabheightConstraint = tooltipTypeLabel.heightAnchor.constraint(equalTo: tooltipTypePickerView.heightAnchor)
        let toolTypeLabWidthConstraint = tooltipTypeLabel.widthAnchor.constraint(equalToConstant: 0)
        
        
        let toolTypePictopConstraint = tooltipTypePickerView.topAnchor.constraint(equalTo: legendPositionPicker.bottomAnchor)
        let toolTypePicleadingConstraint = tooltipTypePickerView.leadingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        let toolTypePictrailingConstraint = tooltipTypePickerView.trailingAnchor.constraint(equalTo: slideMenuView.trailingAnchor)
        //        let toolTypePicheightConstraint = tooltipTypePickerView.heightAnchor.constraint(equalTo: slideMenuView.heightAnchor, multiplier: 0.33)
        let toolTypePicWidthConstraint = tooltipTypePickerView.widthAnchor.constraint(equalToConstant: 0)
        
        */
        let newConstraint = [topConstraint, trailingConstraint, bottomConstraint, widthConstraint,
                             legOrLabtopConstraint,legOrLableadingConstraint,legOrLabtrailingConstraint,legOrLabWidthConstraint,
                             legOrtopConstraint, legOrleadingConstraint, legOrtrailingConstraint,legOrWidthConstraint,
                             
                             legPosLabtopConstraint,legPosLableadingConstraint,legPosLabtrailingConstraint,legPosLabWidthConstraint,
                             
                             legPostopConstraint,legPosleadingConstraint,legPostrailingConstraint,legPosWidthConstraint ]
                             
                            /* toolTypeLabtopConstraint, toolTypeLableadingConstraint, toolTypeLabtrailingConstraint, toolTypeLabWidthConstraint,
                             
                             toolTypePictopConstraint, toolTypePicleadingConstraint, toolTypePictrailingConstraint, toolTypePicWidthConstraint
            
        ]*/
        
        
        return newConstraint
    }
    
    
    
    //=================================================//
    
    
    // MARK: - Picker View Delegates
    
    //Number of Colummns
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView == chartOrientationPicker
        {
            return chartOrientationData.count
        }
        else if pickerView == chartTypePicker
        {
            return chartTypes.count
        }
        
        
        
        return chartOrientationData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView == chartOrientationPicker
        {
            return chartOrientationData[row]
        }
        else if pickerView == chartTypePicker
        {
            return chartTypes[row]
        }
        
        return chartOrientationData[row]
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
        if pickerView == chartOrientationPicker
        {
            selectedOrientation = chartOrientationData[row]
        }
        else if pickerView == chartTypePicker
        {
            selectedChartType = chartTypes[row]
        }
        
        
    }
    
}



