//
//  LineViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 11/11/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class LineViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate {
    
    func updateShapeProperties(frame: CGRect, shapeInstance: ShapeProperties, entry: Any?) {
        shapeInstance.shapeType = .triangle
        shapeInstance.size = CGSize(width: 20.0, height: 20.0)
        shapeInstance.holeColor = UIColor.green
    }
    
    func drawOthers(_ chartView: ChartViewBase) {
/*
        let barLineChart = chartView 
        if (lineChartView?.datasetSelected)!
        {
            let index = lineChartView?.lastSelectedHigh?.dataSetIndex
            
            if index != nil{
                LineHelperFunctions.magnifyDataSet(chart: lineChartView!, dataSetIndex: index!)
            }
        }
        
        // width for single point
        var currentWidth:CGFloat
        /*if barLineChart.leftAxis(atIndex: 0).enabled
        {
            currentWidth = barLineChart.getTransformer(forAxis: .left, axisIndex: 0).valueToPixelMatrix.a * CGFloat(barLineChart.xAxis.granularity)
        }
        else{
            currentWidth = barLineChart.getTransformer(forAxis: .right, axisIndex: 0).valueToPixelMatrix.a * CGFloat(barLineChart.xAxis.granularity)
        }*/
        
        currentWidth = CommonHelperFunctions.getOnePointWidth(chart: barLineChart)
        
        if currentWidth < 0.34
        {
            currentWidth = 0.34
        }
        
        for layer in LineLayer.getAllDataSetLayer(chart: chartView)
        {
            if ((LineHelperFunctions.getLineDataSetOptions(dataSet: layer.lineDataSet!).lineWidth)*2) > currentWidth
            {
                layer.lineWidth = currentWidth/2
            }
        }
        */
    }
    
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties) -> UIBezierPath {
       
        return UIBezierPath()
    }
    
    func limitLineShapePath(shapeFrame: CGRect, chartLimitLine: ChartLimitLine) -> CGMutablePath {
       
//        let path = UIBezierPath()
//
//        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
//
//        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
//
//        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
//
//        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
//
//        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
//        let valueText = sha
        
        let newRect = CGRect(x: shapeFrame.minX, y: shapeFrame.midY - (shapeFrame.height/4), width: shapeFrame.width, height: (shapeFrame.height/2))
        
        let path = CGMutablePath()
//
        path.addPath(UIBezierPath(roundedRect: newRect, cornerRadius: 2).cgPath)
        
        return path
    }

    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        if !(lineChartView?.datasetSelected)!
        {
        
            let allEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: lineChartView!)

        for i in 0..<(allEntries.count)
        {
            let entry = allEntries[i]
            let set = lineChartView?.data?.getDataSetForEntry(entry)
            
            if (set?.isVisible)!
            {
            let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            }
        }
        }
        else{
            if lineChartView?.lastSelectedHigh == nil{
            let set = lineChartView?.data?.getDataSetForEntry(entry)
                if (set?.isVisible)!
                {
                    for i in 0..<(set?.entryCount)!
                    {
                        let entry = set?.entryForIndex(i)
                        let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
                        toolTipEntry.valueTextColor = (set?.colors[0])!
                        
                        entries.append(toolTipEntry)
                    }
                }
            }
            else{
                
                let set = lineChartView?.data?.getDataSetForEntry(entry)
                if (set?.isVisible)!
                {
                    let toolTipEntry = ToolTipEntry(label: String(describing: entry?.x), value: String(describing: entry?.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
                }
            }
        }
  
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()

    
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
          addLine(view: childView, point: location)
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    @objc fileprivate func panGestureRecognized(_ recognizer: NSUIPanGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        if  recognizer.state == .began
        {
             childView.layer.addSublayer(shapeLayer)
              addLine(view: childView, point: location)
        }
        else if recognizer.state == .changed
        {
           addLine(view: childView, point: location)
        }
        else if recognizer.state == .ended || recognizer.state == .cancelled
        {
            addLine(view: childView, point: location)
            shapeLayer.removeFromSuperlayer()
        }
        
        
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                       
                    }
                }
            }
        }
        
        
    }
    
    
    func addMultipleLine(view:UIView)
    {
    
        
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 50, y: 50))
        path.addLine(to: CGPoint(x: 50, y: 95))
       // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:50, y: 105))
        path.addLine(to: CGPoint(x: 50, y: 150))
        path.close()
        
   
        
//        layer.lineCap = "round"
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
//        layer.fillColor = UIColor.green.cgColor
        shapeLayer.lineWidth = 2
            
     view.layer.addSublayer(shapeLayer)
        
        let circleLayer = CAShapeLayer()
//        let circlePath = UIBezierPath(rect: CGRect(x: 45, y: 95, width: 10, height: 10))
        let circlePath = UIBezierPath(ovalIn: CGRect(x: 45, y: 95, width: 10, height: 10))
//        UIBezierPath(ovalIn: <#T##CGRect#>)
        circleLayer.path = circlePath.cgPath
        circleLayer.strokeColor = UIColor.black.cgColor
        circleLayer.fillColor = UIColor.clear.cgColor
        
        shapeLayer.addSublayer(circleLayer)
    }
    
    func addLine(view:UIView, point:CGPoint)
    {
        let path = getNewPath(point: point, yChange: 100)
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 2
        
        var circleLayer:CAShapeLayer? = nil
        
        let sublayers = shapeLayer.sublayers
        if sublayers != nil
        {
            for layer in sublayers!
            {
                if layer.isKind(of: CAShapeLayer.self)
                {
                    circleLayer = layer as! CAShapeLayer
                    break
                }
            }
        }
        
        if circleLayer == nil
        {
           circleLayer = CAShapeLayer()
            circleLayer?.strokeColor = UIColor.black.cgColor
            circleLayer?.fillColor = UIColor.clear.cgColor
            
            shapeLayer.addSublayer(circleLayer!)
        }
        
        circleLayer?.path = getCirclePath(point: point, yChange: 100).cgPath
    }
    
    func getNewPath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
//        let yChange:CGFloat = 50
        let path = UIBezierPath()
        path.move(to: point)
        path.addLine(to: CGPoint(x: point.x, y: point.y + yChange - 5))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:point.x, y: point.y + yChange + 5))
        path.addLine(to: CGPoint(x: point.x, y: point.y + (2.0 * yChange)))
        path.close()
        
        return path
    }
    
    func getCirclePath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        let radius:CGFloat = 5
        //        let yChange:CGFloat = 50
        let rect = CGRect(x: point.x - radius, y: point.y + yChange - radius, width: 2 * radius, height: 2 * radius)
        let path = UIBezierPath(ovalIn: rect)
        path.close()
        
        return path
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

      /*  if showCustomLineView
        {
            addCustomLineView()
            return
        }*/
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addLineChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var lineChartView:ChartViewBase? = nil
    
    func addLineChart()
    {
        
        let granularity =  1.0 // 525600.0 * 60.0 //3600.0
        
        
        lineChartView = containerView?.chart
        lineChartView?.plotDelegate = self
        
//        lineChartView?.extraTopOffset = 100
        
        lineChartView?.rendererDelegate = self
        
        lineChartView?.tapEventListener?.handler = LineHighlightHandler()
        
        lineChartView?.panEventListener?.handler = LineFilterHandler() //LinePanFilterHandler() // LinePanHandler()
        
        lineChartView?.longPressEventListener?.handler = LineLongPressHandler()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = true
        
        //        lineChartView?.leftAxis.xOffset = 30
        
        //        lineChartView?.rightAxis.xOffset = 30
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        //        lineChartView?.leftAxis.gridLineWidth = 1
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        lineChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
        
        lineChartView?.xAxis.labelCount = 5
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = granularity
        //        lineChartView?.xAxis.granularityEnabled = true
        
        
//        lineChartView?.xAxis.scaleType = .Ordinal
        
        lineChartView?.xAxis.tickLabelMode = .forced
        
        lineChartView?.xAxis.labelRotationAngle = 60
        
        lineChartView?.xAxis.inverted = false
        
        let block = {
            (
            _ value: Double,
            _ axis: AxisBase?) -> String in
            
            return "myValue " + String(value)
        }
        
        let temp = DefaultAxisValueFormatter(block: block)
        
        lineChartView?.getYAxis(atIndex: 0)!.valueFormatter = temp
        
        //        let count = 2000+50
        let count = 10
        var range:UInt32 = 1200
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        let date = Date()
        
        let now = date.timeIntervalSince1970
        
        let valline:[Double] = [1017,712,978,985,274] //[Double.nan,712,978,985,Double.nan] // [1017,712,978,985,274]
        
        let lineValue:[Double] = [300,712,978,570,274,1030, 1200, 340, 790, 960]
         
        let from = now - (Double(count) / 2.0) * granularity;
        let to = now + (Double(count) / 2.0) * granularity;
        
        //        for i in 2000..<count {
        //        for i in 0..<count {
        
        /*   dataEntries1.append(ChartDataEntry(x: Double(1262284200), y: Double(225881.08)))
         dataEntries1.append(ChartDataEntry(x: Double(1293820200), y: Double(297103.28)))
         dataEntries1.append(ChartDataEntry(x: Double(1325356200), y: Double(338301.21)))
         dataEntries1.append(ChartDataEntry(x: Double(1356892200), y: Double(351459.57)))//1356892200//1356978600
         dataEntries1.append(ChartDataEntry(x: Double(1388428200), y: Double(87201.92))) //1388428200 //1388514600 */
        
//        for i in 0..<(count) {
        var valindex = 0
            for i in 900..<(900+count) {
            
            //   for i in stride(from: from, through: to, by: granularity) {
            
//                        if i > 300
//                        {
//                            range = 300
//                        }
//                        if i > 600
//                        {
//                            range = 200
//                        }
//                        if i > 900
//                        {
//                            range = 100
//                        }
            
//            let tempDate = Date(timeIntervalSince1970: Double(i))
//            let tempFormatter = DateFormatter()
//            tempFormatter.dateFormat = "HH:mm:ss a"
//            tempFormatter.locale = Locale(identifier: "en_IN")

            let lab = i
            
            var val1 = arc4random_uniform(UInt32(range)) + 3
          
//                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data:  nil))
//            if i == 900  || i == 905 || i == 907 || i == 910 || i == 911 || i == 920 || i == 922 || i >= 998  // || (i > 903 && i < 940)
////                if i == 0 || i == 5 || i == 6 || i == 10 || i == 11 || i == 20 || i == 22 || i >= 98
//                //            if i == 2 || i == 3 || i == 6 || i == 9 || i == 20 || i == 22 || i == 29
//            {
//                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data:  nil))
//            }
//            else{
//                if i == 917 || i == 903 || i == 945 || i == 946 || i == 947
//                {
//                    dataEntries1.append(ChartDataEntry(x: Double(i), y: Double.nan, data:  nil))
//                }
//                else{
//                    dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data:  nil))
//                }
//            }
//
                dataEntries1.append(ChartDataEntry(x: Double(lab), y: Double(val1), data:  nil))
////                if i == 907
////                {
////                    valindex += 1
////                    continue
////                }
////                if i == 908
////                {
////                    dataEntries1.append(ChartDataEntry(xString: lab, y: lineValue[valindex], data:  nil))
////
////                }
////                if i == 900 || i == 906
////                {
////                    dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data:  nil))
////                }
//                 dataEntries1.append(ChartDataEntry(xString: lab, y: lineValue[valindex], data:  nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: valline[valindex], data:  nil))
                valindex += 1
                val1 = arc4random_uniform(UInt32(range)) + 500
//                dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val1), data:  nil))
                /*if i == 900  || i == 905 || i == 907 || i == 910 || i == 911 || i == 920 || i == 922 || i >= 998  // || (i > 903 && i < 940)
                    //                if i == 0 || i == 5 || i == 6 || i == 10 || i == 11 || i == 20 || i == 22 || i >= 98
                    //            if i == 2 || i == 3 || i == 6 || i == 9 || i == 20 || i == 22 || i == 29
                {
                    dataEntries1.append(ChartDataEntry(xString: nil, y: Double(val1), data:  nil))
                    val1 = arc4random_uniform(UInt32(range)) + 500
                    dataEntries2.append(ChartDataEntry(xString: nil, y: Double(val1), data: nil))
                    val1 = arc4random_uniform(UInt32(range)) + 1000
                    dataEntries3.append(ChartDataEntry(xString: nil, y: Double(val1), data: nil))
                }
                else{
                    if i == 917 || i == 903 || i == 945 || i == 946 || i == 947
                    {
                        dataEntries1.append(ChartDataEntry(xString: lab, y: Double.nan, data:  nil))
                        val1 = arc4random_uniform(UInt32(range)) + 500
                        dataEntries2.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
                        val1 = arc4random_uniform(UInt32(range)) + 1000
                        dataEntries3.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
                    }
                    else{
                        dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data:  nil))
                        val1 = arc4random_uniform(UInt32(range)) + 500
                        dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
                        val1 = arc4random_uniform(UInt32(range)) + 1000
                        dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
                    }
                }*/
            
            //     dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            let val2 = arc4random_uniform(UInt32(range)) + (3 + range)
            
                dataEntries2.append(ChartDataEntry(x: Double(lab), y: Double(val2), data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            let val3 = arc4random_uniform(UInt32(range)) + (3 + range * 2)
            
                dataEntries3.append(ChartDataEntry(x: Double(lab), y: Double(val3), data: nil))
            //            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        set1.plotType = .Line
        
        let lineDataSetOptions1 = LineDataSetOptions()
        set1.dataSetOptions = lineDataSetOptions1
        
        let shape = lineDataSetOptions1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        lineDataSetOptions1.lineDashLengths = [4.0,8.0]
        lineDataSetOptions1.lineDashPhase = 2.0
        lineDataSetOptions1.setShapeColor(UIColor.red)
        
        lineDataSetOptions1.lineWidth = 1
        lineDataSetOptions1.drawShapeEnabled = true
        
        lineDataSetOptions1.drawFilledEnabled = false
        lineDataSetOptions1.fillAlpha = 0.3
        lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[5]
        lineDataSetOptions1.mode = .montonic
        set1.axisIndex = 0
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        
        set2.plotType = .Line
        let lineDataSetOptions2 = LineDataSetOptions()
        set2.dataSetOptions = lineDataSetOptions2
        
        let shape1 = lineDataSetOptions2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        lineDataSetOptions2.setShapeColor(UIColor.brown)
        
        lineDataSetOptions2.lineWidth = 0.5
        lineDataSetOptions2.drawShapeEnabled = true
        
        lineDataSetOptions2.drawFilledEnabled = false
        lineDataSetOptions2.fillAlpha = 0.3
        lineDataSetOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        lineDataSetOptions2.mode = .linear
        set2.axisIndex = 0
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        
        set3.plotType = .Line
        let lineDataSetOptions3 = LineDataSetOptions()
        set3.dataSetOptions = lineDataSetOptions3
        
        lineDataSetOptions3.setCircleColor(UIColor.black)
        lineDataSetOptions3.lineWidth = 0.5
        lineDataSetOptions3.circleRadius = 3.0
        lineDataSetOptions3.drawCircleHoleEnabled = false
        lineDataSetOptions3.drawCirclesEnabled = true
        lineDataSetOptions3.drawShapeEnabled = false
        
        lineDataSetOptions3.drawFilledEnabled = false
        lineDataSetOptions3.fillAlpha = 0.3
        lineDataSetOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        lineDataSetOptions3.mode = .montonic
        set3.axisIndex = 0
        
        
        
        
//                let chartData = LineChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(true)
        
        lineChartView?.data = chartData
        
        let entry1 = NoteEntry()
        entry1.noteEntryData = dataEntries1[0]
        
        let entry2 = NoteEntry()
        entry2.point = (x: 7, y: 192)
        
        let entry3 = NoteEntry()
        entry3.noteEntryData = dataEntries1[7]
        
        let entry4 = NoteEntry()
        entry4.noteEntryData = dataEntries1[9]
        
        let noteEntries = [entry1, entry2, entry3, entry4]
        
        lineChartView?.notes = Notes(entries: noteEntries)
        lineChartView?.notes?.notesShape.customPathDataSource = self
        
        guard let linePlotOptions = (lineChartView?.getPlotOptions(type: .Line) as? LinePlotOptions)
        else { return }
        
        linePlotOptions.maxWidthZoomRestrictionPixel = 100

        lineChartView?.xAxis.spaceMinPixel = 20
        lineChartView?.xAxis.spaceMaxPixel = 20
        
//        lineChartView?.xAxis.spaceMin = granularity / 2.0
//        lineChartView?.xAxis.spaceMax = granularity / 2.0
        
        
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        let upperLimit = ChartLimitLine(limit: 1400, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.black
        upperLimit.shapeProperties = ShapeProperties()
        
        upperLimit.limitValueTextColor = UIColor.white
        upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit.shapeProperties?.holeColor = UIColor.white
        upperLimit.shapeProperties?.shapeType = .custom
        upperLimit.shapeProperties?.size = CGSize(width: 8.0, height: 8.0)
        upperLimit.shapeProperties?.lineWidth = 2
        upperLimit.shapeProperties?.customPathDataSource = self
        
        let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
        lowerRightLimit.lineColor = NSUIColor.red
        
        lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerRightLimit.lineDashPhase = 2.0
        lowerRightLimit.lineDashLengths = [1.0, 2.0]
        
        let upperLimit1 = ChartLimitLine(limit: 600, label: "UpperLimit")
        upperLimit1.lineColor = NSUIColor.green
        upperLimit1.shapeProperties = ShapeProperties()
        
        upperLimit1.limitValueTextColor = UIColor.white
        upperLimit1.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit1.shapeProperties?.holeColor = UIColor.white
        upperLimit1.shapeProperties?.shapeType = .custom
        upperLimit1.shapeProperties?.size = CGSize(width: 8.0, height: 8.0)
        upperLimit1.shapeProperties?.lineWidth = 2
        upperLimit1.shapeProperties?.customPathDataSource = self
        
        let upperLimit2 = ChartLimitLine(limit: 900, label: "UpperLimit")
        upperLimit2.lineColor = NSUIColor.blue
        upperLimit2.shapeProperties = ShapeProperties()
        
        upperLimit2.limitValueTextColor = UIColor.white
        upperLimit2.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit2.shapeProperties?.holeColor = UIColor.white
        upperLimit2.shapeProperties?.shapeType = .custom
        upperLimit2.shapeProperties?.size = CGSize(width: 8.0, height: 8.0)
        upperLimit2.shapeProperties?.lineWidth = 2
        upperLimit2.shapeProperties?.customPathDataSource = self
        
        
        //      upperLimit.lineWidth = 6.0
        
        let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
        xLimit.lineColor = NSUIColor.red
        
        xLimit.lineDashPhase = 2.0
        xLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
//            lineChartView?.getYAxis(atIndex: 0)!.addLimitLine(upperLimit)
//        lineChartView?.getYAxis(atIndex: 0)!.addLimitLine(upperLimit1)
//        lineChartView?.getYAxis(atIndex: 0)!.addLimitLine(upperLimit2)
//
//        lineChartView?.getYAxis(atIndex: 0)!.addLimitLine(lowerLimit)
//
        //            lineChartView?.rightAxis.addLimitLine(lowerLimit)
        //        lineChartView?.xAxis.addLimitLine(xLimit)
        
        
        //        lineChartView?.rightAxis.addLimitLine(lowerRightLimit)
        
        /*   let numberFormmater = NumberFormatter()
         numberFormmater.numberStyle = .currency
         numberFormmater.minimumFractionDigits = 0
         numberFormmater.locale = Locale(identifier: "en_IN") */
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.lineChartView!)
        lineChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        /*  let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "yyyy"// "HH:mm:ss a"
         dateFormatter.locale = Locale(identifier: "en_IN")
         let timeaxisValueFormatter = ValueFormatter(formatter: dateFormatter, chart: lineChartView!) */
        
        let xFormatter = ValueFormatter(chart: lineChartView!)
        //        xFormatter.fetchValueFromData = true
        self.lineChartView?.xAxis.valueFormatter = xFormatter
        
        
        lineChartView?.animate(xAxisDuration: 1.0)
//        let animateBlock = getAnimationBlock()
//
//        CommonUtilities.customAnimation(chart: lineChartView!,duration:1.5,animationBlock: animateBlock)
        
        dataBackup.append(lineChartView?.data?.copy() as! ChartData)
        chartInstance.append(lineChartView!)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
     func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1.5)
        
        let chart = lineChartView!
        
        let animateBlock = { [weak self,chart] in
            
            guard let self = self else {
                return
            }
            
            let contentRect = chart.viewPortHandler.contentRect
            
            
            
            let allLayers = LineLayer.getAllDataSetLayer(chart: chart)
            
            let entryCount =  (chart.data?.dataSetCount)!
            
            let heightPercent = Double(4)
            
            let duration:Double = ((heightPercent) / (Double(entryCount - 1) + heightPercent)) * totalDuration
            
            
            for entryLayer in allLayers
            {
                let maskLayer = CAShapeLayer()
                
                maskLayer.path = chart.isRotated ? UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: contentRect.width, height: 0)).cgPath : UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: 0, height: contentRect.height)).cgPath
                
                maskLayer.fillColor = UIColor.white.cgColor
                
                entryLayer.mask = maskLayer
                
                entryLayer.opacity = 1
                
                guard let markerLayers = entryLayer.sublayers
                    else {
                        continue
                }
                for markerLayer in markerLayers
                {
                    markerLayer.opacity = 1
                }
            }
            
            
            let barEntryAnimator = Animator()
            
            
            barEntryAnimator.updateBlock = { [unowned self, barEntryAnimator] in
                
                for entryIndex in 0..<entryCount
                {
                    
                    
                    let startTime = (( duration / Double(heightPercent)) * Double(entryIndex))
                    
                    let endTime = startTime + duration
                    
                    let currentTime = (barEntryAnimator.phaseX) * totalDuration
                    
                    //                print("Entry ", entryIndex, "entry", entry, "CT",currentTime,"ET", endTime, "ST",startTime, "dur", duration)
                    
                    if currentTime > endTime  {
                        
                        self.updateLayerPath(phaseValue: 1, index: entryIndex, allLayers: allLayers)
                        
                    } else if currentTime < startTime {
                        
                    } else {
                        
                        //                  print("Entry ", entryIndex, "entry", entry)
                        
                        let difference = currentTime - startTime
                        
                        var percent = CGFloat(difference/duration)
                        
                        if percent > 1
                        {
                            percent = 1
                        }
                        
                        self.updateLayerPath(phaseValue: percent,index:entryIndex,allLayers: allLayers)
                        
                    }
                    
                }
                
            }
            barEntryAnimator.stopBlock = { [unowned barEntryAnimator] in
                barEntryAnimator.updateBlock = nil
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    func updateLayerPath(phaseValue:CGFloat,index:Int,allLayers:[ChartEntryLayer])
    {
        let chart = lineChartView!
        
        let contentRect = (self.lineChartView?.viewPortHandler.contentRect)!
        
        let xInterpolator = chart.isRotated ? Interpolator.interpolate(a: 0, b: contentRect.height) : Interpolator.interpolate(a: 0, b: contentRect.width)
        
        let currentPath = chart.isRotated ? UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: contentRect.width, height: xInterpolator(phaseValue))).cgPath : UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: xInterpolator(phaseValue), height: contentRect.height)).cgPath
        
        
        var dataSetIndex = -1
        
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            dataSetIndex += 1
            
            if dataSetIndex == index
            {
                print("index - ",index,"phase - ",phaseValue)
                guard let maskLayer = layer.mask as? CAShapeLayer
                    else { return }
                maskLayer.path = currentPath
            }
        }
        
    }

    
    /*func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1.5)
        
        let chart = lineChartView!
        
        let animateBlock = {
            
            let allLayers = LineLayer.getAllDataSetLayer(chart: chart)
            
            let strokeEndAnimation = CABasicAnimation(keyPath: "strokeEnd")
            strokeEndAnimation.toValue = 1.0
            strokeEndAnimation.duration = totalDuration
            strokeEndAnimation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
            strokeEndAnimation.isRemovedOnCompletion = false
            strokeEndAnimation.fillMode = kCAFillModeForwards
            
            for entryLayer in allLayers
            {
                entryLayer.strokeStart = 0.0
                CATransaction.begin()
                CATransaction.setDisableActions(true)
                entryLayer.strokeEnd = 0.0
                CATransaction.commit()
                entryLayer.add(strokeEndAnimation, forKey: "strokeEndAnimation")
                entryLayer.opacity = 1
            }
            
    
        }
        
        return animateBlock
    }*/
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
    
        level += 1
        
        lineChartView = containerView?.chart
        
        lineChartView?.tapEventListener?.handler = LineHighlightHandler()
        
        lineChartView?.panEventListener?.handler = LinePanHandler()
        
        lineChartView?.longPressEventListener?.handler = LineLongPressHandler()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
//        lineChartView?.xAxis.axisMinimum = 0
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = 1.0
        
        lineChartView?.getYAxis(atIndex: 0)!.scaleType = .Ordinal
        //        lineChartView?.xAxis.granularityEnabled = true
        
        lineChartView?.getYAxis(atIndex: 0)?.spaceMaxPixel = 5
        
        //        let count = 2000+50
        let count = 12
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), yString: months[Int(val1)%12], data: nil))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i] as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i] as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(UIColor.green)
        
        set1.plotType = .Line
        let lineDataSetOptions1 = LineDataSetOptions()
        set1.dataSetOptions = lineDataSetOptions1
        
        let shape = lineDataSetOptions1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        lineDataSetOptions1.setShapeColor(UIColor.red)
        
        lineDataSetOptions1.lineWidth = 2
        lineDataSetOptions1.drawShapeEnabled = false
        
        lineDataSetOptions1.drawFilledEnabled = false
        lineDataSetOptions1.fillAlpha = 0.3
        lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[5]
        lineDataSetOptions1.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(UIColor.red)
        
        set2.plotType = .Line
        let lineDataSetOptions2 = LineDataSetOptions()
        set2.dataSetOptions = lineDataSetOptions2
        
        lineDataSetOptions2.setCircleColor(UIColor.black)
        lineDataSetOptions2.lineWidth = 2
        lineDataSetOptions2.circleRadius = 3.0
        lineDataSetOptions2.drawCircleHoleEnabled = false
        lineDataSetOptions2.drawCirclesEnabled = true
        lineDataSetOptions2.drawShapeEnabled = false
        
        lineDataSetOptions2.drawFilledEnabled = false
        lineDataSetOptions2.fillAlpha = 0.3
        lineDataSetOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        lineDataSetOptions2.mode = .linear
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(UIColor.blue)
        
        set3.plotType = .Line
        let lineDataSetOptions3 = LineDataSetOptions()
        set3.dataSetOptions = lineDataSetOptions3
        
        lineDataSetOptions3.setCircleColor(UIColor.black)
        lineDataSetOptions3.lineWidth = 2
        lineDataSetOptions3.circleRadius = 3.0
        lineDataSetOptions3.drawCircleHoleEnabled = false
        lineDataSetOptions3.drawCirclesEnabled = true
        lineDataSetOptions3.drawShapeEnabled = false
        
        lineDataSetOptions3.drawFilledEnabled = false
        lineDataSetOptions3.fillAlpha = 0.3
        lineDataSetOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        lineDataSetOptions3.mode = .linear
        
        
        
        
        //        let chartData = LineChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1])
        chartData.setDrawValues(false)
        
        
        lineChartView?.data = chartData
        
        //lineChartView?.xAxis.spaceMax = 0.5
        lineChartView?.xAxis.spaceMin = 0.9
        
        
        
        lineChartView?.animate(xAxisDuration: 1.0)
        
        dataBackup.append(lineChartView?.data?.copy() as! ChartData)
        chartInstance.append(lineChartView!)
        
    }
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {
    
        if true     //velocity > 1  //&& (Int(end)!-Int(start)!) == 1
        {
//            level += 1
//
//        lineChartView = containerView?.initializeChart(type: .Line) as! LineChartView
//
//        lineChartView?.chartActionListener = self
//
//        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
//
//        lineChartView?._panEventListener?.handler = LinePanHandler()
//
//        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
//
//        lineChartView?.rightAxis.enabled = false
//
//        lineChartView?.leftAxis.drawGridLinesEnabled = false
//
//        lineChartView?.xAxis.labelPosition = .bottom
//
//        lineChartView?.leftAxis.axisMinimum = 0
//
//        lineChartView?.xAxis.axisMinimum = 0
//
//        lineChartView?.xAxis.drawGridLinesEnabled = false
//
//        lineChartView?.chartDescription?.enabled = false
//
//        lineChartView?.xAxis.granularity = 1.0
//        //        lineChartView?.xAxis.granularityEnabled = true
//
//        //        let count = 2000+50
        let count = 12
        let range = 150
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
            var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
            
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i%12] as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i%12] as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i%12] as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(UIColor.green)
        
        set1.plotType = .Line
        let lineDataSetOptions1 = LineDataSetOptions()
        set1.dataSetOptions = lineDataSetOptions1
            
        let shape = lineDataSetOptions1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        lineDataSetOptions1.setShapeColor(UIColor.red)
        
        lineDataSetOptions1.lineWidth = 2
        lineDataSetOptions1.drawShapeEnabled = true
        
        lineDataSetOptions1.drawFilledEnabled = false
            lineDataSetOptions1.fillAlpha = 0.3
        lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[5]
        lineDataSetOptions1.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(UIColor.red)
        
        set2.plotType = .Line
        let lineDataSetOptions2 = LineDataSetOptions()
        set2.dataSetOptions = lineDataSetOptions2
            
        lineDataSetOptions2.setCircleColor(UIColor.black)
        lineDataSetOptions2.lineWidth = 2
        lineDataSetOptions2.circleRadius = 3.0
        lineDataSetOptions2.drawCircleHoleEnabled = false
        lineDataSetOptions2.drawCirclesEnabled = true
        lineDataSetOptions2.drawShapeEnabled = false
        
        lineDataSetOptions2.drawFilledEnabled = false
        lineDataSetOptions2.fillAlpha = 0.3
        lineDataSetOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        lineDataSetOptions2.mode = .linear
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(UIColor.blue)

        set3.plotType = .Line
        let lineDataSetOptions3 = LineDataSetOptions()
        set3.dataSetOptions = lineDataSetOptions3

            
        lineDataSetOptions3.setCircleColor(UIColor.black)
        lineDataSetOptions3.lineWidth = 2
        lineDataSetOptions3.circleRadius = 3.0
        lineDataSetOptions3.drawCircleHoleEnabled = false
        lineDataSetOptions3.drawCirclesEnabled = true
        lineDataSetOptions3.drawShapeEnabled = false
        
        lineDataSetOptions3.drawFilledEnabled = false
        lineDataSetOptions3.fillAlpha = 0.3
        lineDataSetOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        lineDataSetOptions3.mode = .linear

        
        
        //        let chartData = LineChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1])
        chartData.setDrawValues(false)
        
        
        chartView.data = chartData
            
            
            
        
//        //lineChartView?.xAxis.spaceMax = 0.5
//        lineChartView?.xAxis.spaceMin = 0.9
//
//
//
//        lineChartView?.animate(xAxisDuration: 1.0)
            
//            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
//            chartInstance.append(lineChartView!)
        }
        else if velocity < -3  //&& Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
        {
            if level > 0
            {
            level = level-1

            let chart = chartInstance[level]
 
            lineChartView = chart
            
            chart.data = dataBackup[level].copy() as! ChartData
            
            dataBackup.removeLast(dataBackup.count-1 - level)
            
            chartInstance.removeLast(chartInstance.count-1 - level)
            
            containerView?.initializeChart(chart: chart)
            
            chart.animate(xAxisDuration: 1.0)
            }
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    var orientationFlag = true
}

extension LineViewController: PlotDelegate {
    
    // MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        
        return themeImage
    }
    
    func addChartOrientationSwapButton(){
        
        let orientationSwapButton = UIButton(type: .custom)
        
        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)
        
        orientationSwapButton.setImage(buttonImage(), for: .normal)
        
        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)
        
        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true
        
        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true
        
        self.navigationItem.rightBarButtonItem = buttonItem
    }
    
    @objc func chartOrientationSwap(){
        
        lineChartView?.xAxis.tickLabelMode = .forced
        
        if !orientationFlag{
            
            lineChartView?.isRotated = false
            
            orientationFlag = true
            
            lineChartView?.xAxis.labelRotationAngle = 60
        }
        else{
            
            lineChartView?.isRotated = true
            
            lineChartView?.xAxis.labelPosition = .bottom
            
            lineChartView?.xAxis.labelRotationAngle = 0
            
            lineChartView?.getYAxis(atIndex: 0)?.labelPosition = .outsideChart
            
            orientationFlag = false
        }
        
        lineChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
        
//        let animateBlock = getAnimationBlock()
//
//        CommonUtilities.customAnimation(chart: lineChartView!,duration:1.5,animationBlock: animateBlock)
        lineChartView?.animate(xAxisDuration: 1.0)
    }
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        
        if let plotOptions = (plotOption as? LinePlotOptions) {
            plotOptions.maxWidthZoomRestrictionPixel = 100
        }
    }
}
