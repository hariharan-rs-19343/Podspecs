//
//  StairCaseViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 31/01/23.
//  Copyright © 2023 charts. All rights reserved.
//
import zchart
import UIKit

class StairCaseViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource  {
    
    let arrowSizePrecentage = 0.7
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer: CAShapeLayer) -> CGMutablePath {
        
        let xPoint = point.x
        
        let arrowSize = shapeInstance.size.width * arrowSizePrecentage
        
        shapeInstance.polarRadius = arrowSize
        
        shapeInstance.polarAngle = 0
        
        return ShapeFactory.getArrowPath(point: CGPoint(x: xPoint, y: point.y + (shapeInstance.size.height / 2.0)), shapeInstance: shapeInstance) as! CGMutablePath
        
    }
    
    private func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> UIBezierPath {
        
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil || (entry?.x.isNaN)! //|| (entry?.y.isNaN)!
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(Double(totalSales)) )
            toolTipEntry1.valueTextColor = UIColor.black
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry!
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return [] }
        
        guard let dataSet = barChartView?.data?.getDataSetForEntry(barEntry)
            else { return entries }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            for set in (barChartView?.data?.dataSets)!
            {
                if !(set.isVisible)
                {
                    continue
                }
                
                guard let entry = set.entryForXValue(barEntry.x, closestToY: Double.nan)
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: set.label!, value: String((entry.y)))
                toolTipEntry.valueTextColor = (set.colors[0])
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
                
            }
        }
        else
        {
            for i in 0..<(dataSet.entryCount)
            {
                let curEntry = dataSet.entryForIndex(i)!
                
                guard let label = curEntry.xString
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: label, value: String((curEntry.y)))
                toolTipEntry.valueTextColor = (dataSet.color(atIndex: 0))
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
            
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false

        addBarChart()
        
    }

    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = HorizontalStackedBarPanHandler() //CustomHorizontalBarPanHandler()
        
        barChartView?.longPressEventListener?.handler =  StackedBarLongPressListener()//      HorizontalBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = true
        
        barChartView?.xAxis.axisTitle = "Items"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.axisTitleEnabled = false
        barChartView?.xAxis.drawAxisLineEnabled = false
        barChartView?.xAxis.visible = false
        barChartView?.xAxis.drawLabelsEnabled = false
        barChartView?.getYAxis(atIndex: 0)?.visible = false
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        barChartView?.xAxis.scaleType = .Ordinal
        
        totalSales = 0
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        var noteEntries: [NoteEntry] = []
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = 200.0
            
            let val2 = 400.0
            
            let val3 = 300.0
            
            let val4 = 1000.0 - 100.0 * Double(i)
            
            let val5 = Double(arc4random_uniform(UInt32(range)) + 3)

            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            
            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))

                        if i != 7
                        {
            dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
                        }
            
            if i != 9 {
                let noteEntry = NoteEntry()
                noteEntry.noteEntryData = dataEntries4[i]
                noteEntry.text = "120%"
                
                noteEntries.append(noteEntry)
            }
            
            totalSales += CGFloat(val1)
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [NSUIColor.black]
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        set3.drawValuesEnabled = false
//        set3.legendNeeded = false
        
        let shapeProperties = (set3.dataSetOptions as! AxisChartDataSetOptions).shapeProperties
        shapeProperties.shapeType = .custom
        shapeProperties.lineWidth = 1.5
        shapeProperties.padding = 10
        shapeProperties.customPathDataSource = self
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4])
        
//        chartData.setDrawValues(false)
        
        barChartView?.data = chartData
        
        barChartView?.notes = Notes(entries: noteEntries)
        
        barChartView?.notes?.cusotmNoteEnabled = true
        barChartView?.notes?.customNoteDelegate = self
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
    barPlotOptions.fitBars = true
        
//        barPlotOptions.barWidth = 0.5
//
//        barPlotOptions.barSpace = 0.5
        
        barPlotOptions.barSpacePixel = 50
        barPlotOptions.barWidthPixel = 50
        
        barPlotOptions.minimumBarPixel = 50
        
        barPlotOptions.maximumBarPixel = 70
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barPlotOptions.drawValueCenteredEnabled = true
        
        barPlotOptions.stackedSumEnabled = true
        
        barPlotOptions.stackSumValueFormatter = formator()
        
//        chartData.stackSpacing = 20
        
        barPlotOptions.drawValueAboveBarEnabled = false
        barChartView?.xAxis.labelPosition = .top
        barChartView?.getYAxis(atIndex: 0)?.inverted = true
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 10
        
        barChartView?.scaleYEnabled = false
        barChartView?.scaleXEnabled = false
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
    }
}

extension StairCaseViewController: NoteDelegate {
    
    func updateNoteLayer(noteLayer: NoteLayer, noteShape: ShapeProperties) {
        
        if let noteEntry = noteLayer.noteEntry,
           let entry = noteLayer.noteEntry?.noteEntryData,
           let entryForLayer = BarLayer.getBarLayerForEntry(chart: barChartView!, entry: entry),
           let rect = entryForLayer.barRect,
           let plotOption = barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions {
            
            let xPoint = rect.midX

            let arrowSize = plotOption.barSpacePixel * arrowSizePrecentage

            noteShape.polarRadius = arrowSize

            noteShape.polarAngle = 90
            
            let shape = CAShapeLayer()

            shape.path = ShapeFactory.getArrowPath(point: CGPoint(x: xPoint, y: rect.maxY), shapeInstance: noteShape)
            
            shape.strokeColor = NSUIColor.black.cgColor
            shape.lineWidth = 1.5
            
            if noteEntry.text != ""
            {
                let labelAttrs = [NSAttributedString.Key.font: noteEntry.textFont,
                                  NSAttributedString.Key.foregroundColor: noteEntry.textColor]
                
                let pixelValue = CGPoint(x: xPoint + 5.0, y: rect.maxY + arrowSize / 2.0 - noteEntry.textFont.lineHeight / 2.0)
                
                let textLayer = ChartUtils.drawTextLayer(text: noteEntry.text, point: pixelValue, align: .right, attributes: labelAttrs)
                
                noteLayer.addSublayer(textLayer)
            }
            
            noteLayer.addSublayer(shape)
        }
    }
    
    
}

class formator: NSObject, IValueFormatter {
    
    public func getFormattedTextforValue(value:Double, type: FieldType, data:AnyObject?) -> String {
        switch(type)
        {
            case .x:
                return String(value)
                
            case .y:
                return String(value)
        }
    }
    public func getFormattedTextforLabel(label: String, type: FieldType, data:AnyObject?) -> String {
        switch(type)
        {
            case .x:
                return label
            
            case .y:
                return label
        }
    }
    
    func stringForValue(_ value: Double, entry: zchart.ChartDataEntry, dataSetIndex: Int, viewPortHandler: zchart.ViewPortHandler?) -> String {
        return String(value)
    }
    
    func getFormattedValue(entry: zchart.ChartDataEntry) -> String {
        return entry.xString ?? ""
    }
    
    
    func getFormattedValue(stackSum:Double, entryX: Double) -> String {
        return "stage "+String(stackSum)
    }
}
