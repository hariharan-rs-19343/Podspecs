//
//  BubbleViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 29/03/18.
//  Copyright © 2018 charts. All rights reserved.
//


import UIKit
import zchart

class BubbleViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate, CustomTicksDelegate, NoteDelegate {
    
    func updateNoteLayer(noteLayer: NoteLayer, noteShape: ShapeProperties) {
        let tempPoint = noteLayer.noteEntry!.point!
        
        let tempPxelPoint  = bubbleChartView!.pixelForValues(x: tempPoint.x as! Double, y: tempPoint.y as! Double, axisIndex: noteLayer.noteEntry!.axisIndex)
        
        let newShape = CAShapeLayer()
        newShape.path = UIBezierPath(ovalIn: CGRect(x: tempPxelPoint.x-10, y: tempPxelPoint.y-10, width: 20, height: 20)).cgPath
        newShape.fillColor = UIColor.red.cgColor
        noteLayer.addSublayer(newShape)
    }
    
    func getTickSizeforEntry(axis: AxisBase, value: Double, chart: ChartViewBase) -> CGSize {
        
        let position = CGPoint(x: 0, y: 0)
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        
        var size = textLayer.frame.size
        
        let imageSize = CGSize(width:30, height: max(30,textLayer.frame.height) )
        
        size.width += imageSize.width
        size.height = max(size.height,imageSize.height)
        
        return size
    }
    
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text: String, chart: ChartViewBase) -> TickLayer {
        
        var size = size
        
        
        let tickLayer = TickLayer()
        
        
        
        var position = CGPoint(x: position.x+size.width/2, y: position.y)
        
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textSize = text.size(withAttributes: labelAttrs)
        
        let textPosition = CGPoint(x: position.x - textSize.width/2, y: position.y-textSize.height/2)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: textPosition, align: .center, attributes: labelAttrs)
        tickLayer.addSublayer(textLayer)
        
        position.x -= textLayer.frame.width
        size.width -= textLayer.frame.width
        
        let imageLayer = CALayer()
        imageLayer.backgroundColor = UIColor.clear.cgColor
        imageLayer.bounds = CGRect(x: position.x-size.width, y: position.y-size.height/2 , width: size.width, height: size.height)
        imageLayer.position = CGPoint(x: position.x - size.width/2, y: position.y)
        imageLayer.contents = UIImage(named: "usericon")?.cgImage  //UIImage(named:segment.imageName)?.cgImage
        tickLayer.addSublayer(imageLayer)
        
        return tickLayer
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        let set = bubbleChartView?.data?.getDataSetForEntry(entry)
        
        if entry == nil || set == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        guard let plotOptions = (bubbleChartView?.getPlotOptions(type: .Bubble) as? BubblePlotOptions)
        else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            let allEntriesAtIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: bubbleChartView!)
            
            for tooltipEntry in allEntriesAtIndex
            {
                let set = bubbleChartView?.data?.getDataSetForEntry(tooltipEntry)
                let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: tooltipEntry.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
            }
        }
        else{
            let set = bubbleChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            
        }
        
        
        return entries
    }
    
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        
    }
    
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer:CAShapeLayer) -> CGMutablePath {
        
        let size = shapeInstance.size.width
        
        let shapeFrame = CGRect(x: point.x - (size/2), y: point.y - (size/2), width: size, height: size)
        
        let path = CGMutablePath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addScatterChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    func readDataFromJson() -> [[Double]]
    {
        var finalData:[[Double]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        for rowArray in dataArray
                        {
                            var row:[Double] = []
                            for element in rowArray
                            {
                                let val = element as! Double
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    var bubbleChartView:ChartViewBase? = nil
    
    func addScatterChart()
    {
        
        bubbleChartView = containerView?.chart
        
        bubbleChartView?.plotDelegate = self
        
//        bubbleChartView?.isRotated = true
        
        //        scatterChartView?.rendererDelegate = self
        
        bubbleChartView?.tapEventListener?.handler = BubbleHighlightHandler()
        
        bubbleChartView?.panEventListener?.handler = DefaultPanHandler()
        //
        //        scatterChartView?.panEventListener?.handler = ScatterPanHandler()
        //
        //        scatterChartView?.longPressEventListener?.handler = ScatterLongPressHandler()
        
        bubbleChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        bubbleChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        bubbleChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        bubbleChartView?.xAxis.labelPosition = .bottom
        
//        bubbleChartView?.xAxis.customTickEnabled = true
        
        bubbleChartView?.xAxis.tickDelegate = self
        
        
        bubbleChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        bubbleChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
//        bubbleChartView?.xAxis.axisMinimum = 0
        
        bubbleChartView?.xAxis.drawGridLinesEnabled = false
        
        bubbleChartView?.chartDescription?.enabled = false
        
        bubbleChartView?.xAxis.granularity = 1.0
        
        //        bubbleChartView?.xAxis.scaleType = .Time
        
        bubbleChartView?.xAxis.tickLabelMode = .auto
        
        bubbleChartView?.xAxis.labelCount = 10
        
        bubbleChartView?.xAxis.labelRotationAngle = 60
        
        bubbleChartView?.xAxis.valueFormatter = ValueFormatter(chart: bubbleChartView!)
        
        bubbleChartView?.xAxis.spaceMinPixel = 50
        bubbleChartView?.xAxis.spaceMaxPixel = 50
        
        bubbleChartView?.xAxis.inverted = false
        
        let count = 20
        let range = 100
        let sizeRange = 3000
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        /// Time data testing
        /*let newData =  readDataFromJson()
         var inc:UInt32 = 3
         for row in newData
         {
         inc += 1
         let val = arc4random_uniform(UInt32(range)) + inc
         dataEntries1.append(BubbleChartDataEntry(x: row[0], y: Double(val), size: CGFloat(5), data: nil))
         
         }*/
        
        
        for i in 0..<count {
            
            
            let lab = "200" + String(i+1)
            
            let xString = "Item " + String(i+1)
            let yString = "Furniture " + String(i+1)
            let val1 = arc4random_uniform(UInt32(range)) + 3
            let size1 = arc4random_uniform(UInt32(range)) + 3
            
            if i == 3
            {
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), size: CGFloat(size1), data: lab as AnyObject))
            }
            else if i == 7
            {
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), size: CGFloat.nan, data: lab as AnyObject))
            }
            else{
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), size: CGFloat(size1), data: lab as AnyObject))
            }
            
            /// Ordinal Testing
            //            dataEntries1.append(BubbleChartDataEntry(xString: xString, yString: yString, size: CGFloat(size1), data: nil))
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            let size2 = arc4random_uniform(UInt32(range)) + 3
            
            if i == 5
            {
                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double.nan, size: CGFloat(size2), data: lab as AnyObject))
            }
            else{
                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), size: CGFloat(size2), data: lab as AnyObject))
            }
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            let size3 = arc4random_uniform(UInt32(range)) + 3
            
            if i == 8
            {
                let val3 = arc4random_uniform(UInt32(range)) + 203
                dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), size: -CGFloat(size3), data: lab as AnyObject))
            }
            else{
                dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), size: CGFloat(size3), data: lab as AnyObject))
            }
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), size: CGFloat(size3), data: lab as AnyObject))
            
            
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[2])
        set1.plotType = .Bubble
        
        let dataOptions = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOptions.shapeProperties
        shape.holeColor = ChartColorTemplates.pieColor()[2]
        shape.shapeType = .circle
        shape.lineWidth = 2
        
        let gradient6 = LinearGradient(colors: [ChartColorTemplates.pieColor()[2], ChartColorTemplates.pieColor()[2].withAlphaComponent(0.5)], positions: [0.2,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        //        set1.gradients = [gradient6]
        
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Bubble
        
        let dataOptions1 = set2.dataSetOptions as! AxisChartDataSetOptions
        let shape1 = dataOptions1.shapeProperties
        shape1.holeColor = ChartColorTemplates.pieColor()[1]
        shape1.shapeType = .triangle
        shape1.lineWidth = 2
        
        
        let set3  = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[3])
        set3.plotType = .Bubble
        
        let dataOptions2 = set3.dataSetOptions as! AxisChartDataSetOptions
        let shape2 = dataOptions2.shapeProperties
        shape2.holeColor = ChartColorTemplates.pieColor()[3]
        shape2.shapeType = .custom
        shape2.customPathDataSource = self
        shape2.lineWidth = 2
        
        
        
        
        let chartData = ChartData(dataSets: [set1, set2 , set3])
        chartData.setDrawValues(true)
        
        bubbleChartView?.data = chartData
        
        let entry1 = NoteEntry()
        entry1.point = (x: 2.0, y: 192.0)
        
        let entry2 = NoteEntry()
        entry2.point = (x: 4.0, y: 12.0)
        
        let entry3 = NoteEntry()
        entry3.point = (x: 7.0, y: 202.0)
        
        let entry4 = NoteEntry()
        entry4.point = (x: 9.0, y: 192.0)
        
        let noteEntries = [entry1, entry2, entry3, entry4]
        
        bubbleChartView?.notes = Notes(entries: noteEntries)
        bubbleChartView?.notes?.cusotmNoteEnabled = true
        bubbleChartView?.notes?.customNoteDelegate = self
        
        let plotOptions = (bubbleChartView?.getPlotOptions(type: .Bubble) as! BubblePlotOptions)
        plotOptions.minimumShapeSizeInPixel = 8
        plotOptions.maximumShapeSizeInPixel = 30
        
        plotOptions.maxWidthZoomRestrictionPixel = 100
        
        bubbleChartView?.xAxis.spaceMin = 0.5
        bubbleChartView?.xAxis.spaceMax = 0.5
        
        
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        /*  let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
         upperLimit.lineColor = NSUIColor.black
         upperLimit.shapeProperties = ShapeProperties()
         
         upperLimit.limitValueTextColor = UIColor.white
         upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
         
         upperLimit.shapeProperties?.holeColor = UIColor.white
         upperLimit.shapeProperties?.shapeType = .custom
         upperLimit.shapeProperties?.shapeSize = 8
         upperLimit.shapeProperties?.lineWidth = 2
         upperLimit.shapeProperties?.customPathDataSource = self
         
         let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerLimit.lineColor = NSUIColor.red
         
         lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerLimit.lineDashPhase = 2.0
         lowerLimit.lineDashLengths = [1.0, 2.0]
         
         let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerRightLimit.lineColor = NSUIColor.red
         
         lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerRightLimit.lineDashPhase = 2.0
         lowerRightLimit.lineDashLengths = [1.0, 2.0]
         
         
         //      upperLimit.lineWidth = 6.0
         
         let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
         xLimit.lineColor = NSUIColor.red
         
         xLimit.lineDashPhase = 2.0
         xLimit.lineDashLengths = [1.0, 2.0]
         
         //        lowerLimit.lineWidth = 6.0
         
         scatterChartView?.leftAxis.addLimitLine(upperLimit)
         //            lineChartView?.rightAxis.addLimitLine(lowerLimit)
         //        lineChartView?.xAxis.addLimitLine(xLimit)
         
         
         //        lineChartView?.rightAxis.addLimitLine(lowerRightLimit)*/
        
        
        
        bubbleChartView?.animate(xAxisDuration: 1.0)
        
        dataBackup.append(bubbleChartView?.data?.copy() as! ChartData)
        chartInstance.append(bubbleChartView!)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /*     level += 1
         
         scatterChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         
         scatterChartView?.chartActionListener = self
         
         scatterChartView?._tapEventListener?.handler = LineHighlightHandler()
         
         scatterChartView?._panEventListener?.handler = LinePanHandler()
         
         scatterChartView?._longPressEventListener?.handler = LineLongPressHandler()
         
         scatterChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
         
         scatterChartView?.rightAxis.enabled = false
         
         scatterChartView?.leftAxis.drawGridLinesEnabled = false
         
         scatterChartView?.xAxis.labelPosition = .bottom
         
         scatterChartView?.leftAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.drawGridLinesEnabled = false
         
         scatterChartView?.chartDescription?.enabled = false
         
         scatterChartView?.xAxis.granularity = 1.0
         //        lineChartView?.xAxis.granularityEnabled = true
         
         //        let count = 2000+50
         let count = 12
         let range = 54
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = false
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1, set2,set3])
         chartData.setDrawValues(false)
         
         
         scatterChartView?.data = chartData
         
         //lineChartView?.xAxis.spaceMax = 0.5
         scatterChartView?.xAxis.spaceMin = 0.9
         
         
         
         scatterChartView?.animate(xAxisDuration: 1.0)
         
         dataBackup.append(scatterChartView?.data?.copy() as! ChartData)
         chartInstance.append(scatterChartView!)*/
        
    }
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {
        
        /* if true     //velocity > 1  //&& (Int(end)!-Int(start)!) == 1
         {
         //            level += 1
         //
         //        lineChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         //
         //        lineChartView?.chartActionListener = self
         //
         //        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
         //
         //        lineChartView?._panEventListener?.handler = LinePanHandler()
         //
         //        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
         //
         //        lineChartView?.rightAxis.enabled = false
         //
         //        lineChartView?.leftAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.xAxis.labelPosition = .bottom
         //
         //        lineChartView?.leftAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.chartDescription?.enabled = false
         //
         //        lineChartView?.xAxis.granularity = 1.0
         //        //        lineChartView?.xAxis.granularityEnabled = true
         //
         //        //        let count = 2000+50
         let count = 12
         let range = 150
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i%12] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i%12] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i%12] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = true
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1])
         chartData.setDrawValues(false)
         
         
         chartView.data = chartData
         
         
         
         
         //        //lineChartView?.xAxis.spaceMax = 0.5
         //        lineChartView?.xAxis.spaceMin = 0.9
         //
         //
         //
         //        lineChartView?.animate(xAxisDuration: 1.0)
         
         //            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
         //            chartInstance.append(lineChartView!)
         }
         else if velocity < -3  //&& Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
         {
         if level > 0
         {
         level = level-1
         
         let chart = chartInstance[level]
         
         scatterChartView = chart as! LineChartView
         
         chart.data = dataBackup[level].copy() as! ChartData
         
         dataBackup.removeLast(dataBackup.count-1 - level)
         
         chartInstance.removeLast(chartInstance.count-1 - level)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 1.0)
         }
         }*/
        
    }
    
    var orientationFlag = true
    
}

extension BubbleViewController: PlotDelegate {
    
    // MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        
        return themeImage
    }
    
    func addChartOrientationSwapButton(){
        
        let orientationSwapButton = UIButton(type: .custom)
        
        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)
        
        orientationSwapButton.setImage(buttonImage(), for: .normal)
        
        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)
        
        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true
        
        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true
        
        self.navigationItem.rightBarButtonItem = buttonItem
    }
    
    @objc func chartOrientationSwap(){
        
        if !orientationFlag{
            
            bubbleChartView?.isRotated = false
            
            orientationFlag = true
        }
        else{
            
            bubbleChartView?.isRotated = true
            
            bubbleChartView?.xAxis.labelPosition = .bottom
            
            bubbleChartView?.xAxis.labelRotationAngle = 0
            
            bubbleChartView?.getYAxis(atIndex: 0)?.labelPosition = .outsideChart
            
            orientationFlag = false
        }
        
        bubbleChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
        bubbleChartView?.animate(yAxisDuration: 1.0)
    }
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        
        if let plotOptions = (plotOption as? BubblePlotOptions) {
            plotOptions.minimumShapeSizeInPixel = 8
            plotOptions.maximumShapeSizeInPixel = 30
            
            bubbleChartView?.xAxis.spaceMin = 0.5
            bubbleChartView?.xAxis.spaceMax = 0.5
        }
    }
}

