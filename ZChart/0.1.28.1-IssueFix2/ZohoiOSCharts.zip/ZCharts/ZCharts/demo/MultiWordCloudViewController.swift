//
//  MultiWordCloudViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 17/08/21.
//  Copyright © 2021 charts. All rights reserved.
//
import UIKit
import  zchart

class MultiWordCloudViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            return entries
        }
        else
        {
            let layerHighligted = WordCloudTextLayer.getWordLayerForEntry(chart: barChartView!, entry: entry!)
            let set = barChartView!.data!.dataSets[layerHighligted?.valueDict["setIndex"] as! Int]
          
            
            for entryIndex in 0..<set.entryCount
            {
                guard let entry = set.entryForIndex(entryIndex)
                else{ continue }
                
                let barEntry = entry
                    
                var label:String
                var value:String
                    
                if barEntry.xString != nil
                {
                    label = barEntry.xString!
                }
                else{
                    label = String(barEntry.x)
                }
                    
                if barEntry.yString != nil
                {
                    value = barEntry.yString!
                }
                else{
                    value = String(barEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label:label, value: value)
                
                toolTipEntry.valueTextColor = (set.color(atIndex: 0))
                
                toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
                
                entries.append(toolTipEntry)
            }
            
            
            return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        barChartView?.backgroundColor = UIColor.clear
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = WordCloudHighlightHandler()
        
        barChartView?.pinchEventListener?.handler = DefaultPinchHandler()
        
        barChartView?.panEventListener?.handler = DefaultPanHandler()
        
        barChartView?.pinchZoomEnabled = true
        
        /*barChartView?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()*/
        
        
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 130
        let range = 1200
        
        let xyvalues = [[
            [
                "Apple",
                8977
            ],
            [
                "Orange",
                25607
            ],
            [
                "Mango",
                10664
            ],
            [
                "Banana",
                25561
            ],
            [
                "Papaya",
                22950
            ],
            [
                "Kiwi",
                32950
            ]
        ],
        [
            [
                "Brinjal",
                22113
            ],
            [
                "Potato",
                31692
            ],
            [
                "Tomato",
                31953
            ],
            [
                "Carrot",
                33449
            ],
            [
                "Beans",
                15598
            ]
        ],
        [
            [
                "Barley",
                18196
            ],
            [
                "Wheat",
                26475
            ],
            [
                "Corn",
                22495
            ],
            [
                "Millet",
                19000
            ]
        ]]
        
        var setEntries: [[ChartDataEntry]] = []
 
        for set in xyvalues{
            
            var dataEntries: [ChartDataEntry] = []
            
            for entryIndex in 0..<set.count
            {
                var xLabel = set[entryIndex][0] as! String
                
                let yVal = Double(set[entryIndex][1] as! Int)
              
                dataEntries.append(ChartDataEntry(xString: xLabel, y: yVal, data: nil))
            }
            setEntries.append(dataEntries)
        }
        
        let set1:ChartDataSet = ChartDataSet(values: setEntries[0], label: "Fruits")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .WordCloud
        set1.valueFont  = UIFont(name: "TimesNewRomanPS-BoldItalicMT", size: 10)!

        let set2:ChartDataSet = ChartDataSet(values: setEntries[1], label: "Vegetables")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .WordCloud
        
        let set3:ChartDataSet = ChartDataSet(values: setEntries[2], label: "Grains")
        set3.colors = [ChartColorTemplates.pieColor()[3]]
        set3.plotType = .WordCloud
        set3.valueFont  = UIFont(name: "AvenirNext-Medium", size: 10)!
        
     
        let chartData = ChartData(dataSets: [set1,set2,set3])
       
        barChartView?.data = chartData
        
        
        let plotOptions = barChartView?.getPlotOptions() as! WordCloudPlotOptions
        
        plotOptions.minFontSize = 2
        
        plotOptions.rotation = [0,90]
        
//        plotOptions.outerPadding = 30
        
        //*****************************  Animation  *******************************//
        
        
//        let animateBlock = SingleBarViewController.getAnimationBlock(chartView: self.barChartView!)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 0.5)
        
        CommonUtilities.customAnimation(chart: barChartView!, duration: 1.0, animationBlock: animateBlock)
  
    }
    var initialAnimationAllowed = true
    
    func chartBufferLoadedBeforeDraw(chartView: ChartViewBase) -> Bool {
//        barChartView?.customAnimationInProgress = false
        
        if initialAnimationAllowed
        {
            let animateBlock = getAnimationBlock()
        
            CommonUtilities.customAnimation(chart: barChartView!,duration:1,animationBlock: animateBlock)
            
            initialAnimationAllowed = false
        }
        return true
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = barChartView!
        
        let animateBlock = { [unowned chart] in
            
            if chart.data == nil
            {
                return
            }

            let allLayers = WordCloudTextLayer.getAllWordLayer(chart: chart)
            
            if allLayers.count == 0
            {
                return
            }
            
            let opacAnimator = Animator()
            
            let indexInterpolator = Interpolator.interpolate(a: Double(1), b: Double(allLayers.count-1))
            
            opacAnimator.updateBlock = { [unowned opacAnimator] in
                
                let targetIndex = Int(indexInterpolator(opacAnimator.phaseX))
                
                for i in 0..<(targetIndex+1)
                {
                    guard let textLayer = allLayers[i].sublayers?[0] as? CATextLayer else {
                        continue
                    }
                    textLayer.opacity = 1
                }
            }
            
            opacAnimator.stopBlock = { [unowned opacAnimator] in
                opacAnimator.updateBlock = nil
            }
            
            opacAnimator.animate(xAxisDuration: totalDuration)
        }
        
        return animateBlock
    }
    
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {

        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
       
    }

}


