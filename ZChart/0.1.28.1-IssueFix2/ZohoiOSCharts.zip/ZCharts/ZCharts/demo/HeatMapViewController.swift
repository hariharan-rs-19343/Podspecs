//
//  HeatMapViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 29/05/19.
//  Copyright © 2019 charts. All rights reserved.
//

import Foundation
import zchart
import UIKit

class HeatMapViewController: UIViewController,IToolTipEntryGenerator,RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        if !((mapChartView?.customAnimationInProgress)!)
        {
            HeatMapHelperFunctions.highLightMapEntry(chart: chartView, entry: (chartView.lastSelected != nil && chartView.lastSelected!.count > 0 ) ? chartView.lastSelected![0] : nil)
        }
    }
    
    func readDataFromJson() -> [[AnyObject]]
    {
        if let urlPath = Bundle.main.url(forResource: "heatmap", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        return dataArray
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return [[AnyObject]]()
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let mapEntry = entry!
        let set = mapChartView?.data?.getDataSetForEntry(mapEntry)
        let index = set?.entryIndex(entry: mapEntry)

        var labels:[String] = ["X Label","Y Label","Color Value","Color String"]
        var values:[String] = [(mapEntry.xString!),(mapEntry.yString!),String((mapEntry.colorValue)!),(mapEntry.colorString ?? "nil")]
   
        
        var valueColor = set?.color(atIndex: index!)
        
        if (mapChartView?.colorAxis.isEnabled)!
        {
            valueColor = mapChartView!.colorAxis.getColor(entry: mapEntry)
        }
        
        for i in 0...3
        {
            let dummy = ToolTipEntry(label: labels[i], value: values[i])
            dummy.valueTextColor = valueColor!
            
            dummy.labelTextAlignment = .left
            
            dummy.valueTextAlignment = .right
            entries.append(dummy)
        }
        
        return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .right
        containerView?.legend.type = .continous
        
        addHeatMapChart()
        
    }
    
    var mapChartView:ChartViewBase? = nil
    
    func addHeatMapChart()
    {
        
        //*****************************  initialize chart  *******************************//
        
        //Chart Input Data
        mapChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        mapChartView?.tapEventListener?.handler = MapHighlightHandler()

        mapChartView?.panEventListener?.handler = DefaultPanHandler()
//
//        mapChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
//
        mapChartView?.pinchEventListener?.handler = HeatMapPinchHandler()        //DefaultPinchHandler()
        
        mapChartView?.rendererDelegate = self
        
        
        //*****************************  Axis Title  *******************************//
        
        mapChartView?.xAxis.axisTitleEnabled = false
        
        mapChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = false
        
        //***********************  other Axis Properties  *******************************//
        
        mapChartView?.getYAxis(atIndex: 1)!.enabled = false
        
//        mapChartView?.xAxis.wordWrapEnabled = false

        //  mapChartView?.xAxis.autoRotateAngle = 90
        
        //  mapChartView?.xAxis.autoRotateEnabled = false
        
        mapChartView?.xAxis.labelPosition = .bottom
        
        mapChartView?.getYAxis(atIndex: 0)?.tickLabelMode = .forced
        
        mapChartView?.getYAxis(atIndex: 0)?.labelRotationAngle = 0
        
        mapChartView?.xAxis.granularityEnabled = true
        
        mapChartView?.xAxis.granularity = 1.0
        
        mapChartView?.scaleXEnabled = true
        mapChartView?.scaleYEnabled = true
//        mapChartView?.pinchZoomEnabled = true
        
        mapChartView?.xAxis.scaleType = .Ordinal
        mapChartView?.getYAxis(atIndex: 0)!.scaleType = .Ordinal
        
        
        mapChartView?.xAxis.drawAxisLineEnabled = false
        mapChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        mapChartView?.xAxis.drawGridLinesEnabled = false
        mapChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
        
        mapChartView?.getYAxis(atIndex: 0)?.labelCount = 10
        
//        mapChartView?.setScaleMinima(3.0, scaleY: 1.7)
//
//        mapChartView?.xAxis.spaceMinPixel = 20
//        mapChartView?.xAxis.spaceMaxPixel = 20
        
        
       
        
        /*let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: mapChartView!)
        mapChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter*/
        
        //*****************************  Data  *******************************//
        
        var dataEntries1: [ChartDataEntry] = []
        
        let newData =  readDataFromJson()
        let range = 1500
        var inc:UInt32 = 0
        for row in newData
        {
            inc += 1
            var xString = row[0] as? String
            var yString = row[1] as? String
            var colorValue = row[2] as? Double
            let size = inc == 1 ? CGFloat.nan : CGFloat(arc4random_uniform(UInt32(range)) + 3)
            
            if inc == 1
            {
                colorValue = Double.nan
            }
            
            let mapEntry = ChartDataEntry(xString: xString, yString: yString, size: size, data: nil)
            mapEntry.size = size
            mapEntry.colorValue = colorValue
            dataEntries1.append(mapEntry)
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set 1")
        
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        
        set1.plotType = .HeatMap
        
        let chartData = ChartData(dataSets: [set1])
        
        chartData.setDrawValues(true)
        
        chartData.paddingInPixels = 5
    
        mapChartView?.data = chartData
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: mapChartView!,duration:1,animationBlock: animateBlock)
        
       
//        chartData.highlightColor = UIColor.blue
        
//        chartData.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
      
        //*****************************  Other chart properties  *******************************//
        
        mapChartView?.chartDescription?.enabled = false
    
        let colorAxis = (mapChartView?.colorAxis)!
        colorAxis.enabled = true
        
        //Linear Type
        colorAxis.type = .linear
        colorAxis.stops = [0,3000]
        colorAxis.colors = [hexStringToUIColor(hex: "#A5D6FE"),hexStringToUIColor(hex: "#336A93")] //[UIColor.blue,UIColor.yellow,UIColor.red,UIColor.green,UIColor.purple,UIColor.orange,UIColor.magenta]
//
        
//        colorAxis.type = .range
//        let range1 = Range(from: 0, to: 3000)
//        colorAxis.rangeArray = [range1]
//        colorAxis.colors = [hexStringToUIColor(hex: "#A5D6FE"),hexStringToUIColor(hex: "#336A93")]
        //Range Type
        /*  colorAxis.type = .range
         let range1 = Range(from: 0, to: 250)
         let range2 = Range(from: 250, to: 500)
         let range3 = Range(from: 500, to: 750)
         let range4 = Range(from: 750, to: 1000)
         colorAxis.rangeArray = [range1,range2,range3,range4]
         colorAxis.colors = [UIColor.blue,UIColor.yellow,UIColor.red,UIColor.green] */
        
        //*****************************  Backup  *******************************//
        if mapChartView?.data != nil
        {
            dataBackup.append(mapChartView?.data?.copy() as! ChartData)
            chartInstance.append(mapChartView!)
        }
      
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = mapChartView!
        
        let animateBlock = { [unowned chart] in
            
            if chart.data == nil
            {
                return
            }
            
            let allLayers = MapLayer.getAllMapLayer(chart: chart).shuffled()
            
            let barEntryAnimator = Animator()

            barEntryAnimator.updateBlock = { [unowned barEntryAnimator] in

                let index = barEntryAnimator.phaseX * Double(allLayers.count)

                var curIndex = 0
                for layer in allLayers
                {
                    if curIndex <= Int(ceil(index))
                    {
                        layer.opacity = 1
                    }
                    curIndex += 1
                }
               

            }

            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 1.0, easingOption: .linear)
    }
    
    
    // ===== SWIPE ==== //
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        if UIDevice.current.orientation.isLandscape {
            containerView?.legendView.rangeSlider?.trackerWidthInPercentage = 0.2
            containerView?.legendView.rangeSlider?.trackerHeightInPercentage = 1.0
//            containerView?.legendView.rangeSlider?.layoutSubviews()
        }
        else {
            containerView?.legendView.rangeSlider?.trackerWidthInPercentage = 1.0
            containerView?.legendView.rangeSlider?.trackerHeightInPercentage = 0.3
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
}



