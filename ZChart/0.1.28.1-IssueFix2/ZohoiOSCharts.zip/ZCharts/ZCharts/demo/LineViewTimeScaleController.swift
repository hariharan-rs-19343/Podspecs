//
//  LineViewTimeScaleController.swift
//  ZCharts
//
//  Created by Aravinth T on 11/01/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import  zchart

class LineViewTimeScaleController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func readDataFromJson() -> [[Double]]
    {
        var finalData:[[Double]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                       
                        for rowArray in dataArray
                        {
                            var row:[Double] = []
                            for element in rowArray
                            {
                                let val = element as! Double
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
  
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        if !(lineChartView?.datasetSelected)!
        {
            
            let allEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: lineChartView!)
            
            for i in 0..<(allEntries.count)
            {
                let entry = allEntries[i]
                let set = lineChartView?.data?.getDataSetForEntry(entry)
                
                if (set?.isVisible)!
                {
                    let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
                    toolTipEntry.valueTextColor = (set?.colors[0])!
                    
                    entries.append(toolTipEntry)
                }
            }
        }
        else{
            if lineChartView?.lastSelectedHigh == nil{
                let set = lineChartView?.data?.getDataSetForEntry(entry)
                if (set?.isVisible)!
                {
                    for i in 0..<(set?.entryCount)!
                    {
                        let entry = set?.entryForIndex(i)
                        let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
                        toolTipEntry.valueTextColor = (set?.colors[0])!
                        
                        entries.append(toolTipEntry)
                    }
                }
            }
            else{
                
                let set = lineChartView?.data?.getDataSetForEntry(entry)
                if (set?.isVisible)!
                {
                    let toolTipEntry = ToolTipEntry(label: String(describing: entry?.x), value: String(describing: entry?.y))
                    toolTipEntry.valueTextColor = (set?.colors[0])!
                    
                    entries.append(toolTipEntry)
                }
            }
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        addLine(view: childView, point: location)
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    @objc fileprivate func panGestureRecognized(_ recognizer: NSUIPanGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        if  recognizer.state == .began
        {
            childView.layer.addSublayer(shapeLayer)
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .changed
        {
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .ended || recognizer.state == .cancelled
        {
            addLine(view: childView, point: location)
            shapeLayer.removeFromSuperlayer()
        }
        
        
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {

                    }
                }
            }
        }
        
        
    }
    
    
    func addMultipleLine(view:UIView)
    {
        
        
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 50, y: 50))
        path.addLine(to: CGPoint(x: 50, y: 95))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:50, y: 105))
        path.addLine(to: CGPoint(x: 50, y: 150))
        path.close()
        
        
        
        //        layer.lineCap = "round"
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        //        layer.fillColor = UIColor.green.cgColor
        shapeLayer.lineWidth = 2
        
        view.layer.addSublayer(shapeLayer)
        
        let circleLayer = CAShapeLayer()
        //        let circlePath = UIBezierPath(rect: CGRect(x: 45, y: 95, width: 10, height: 10))
        let circlePath = UIBezierPath(ovalIn: CGRect(x: 45, y: 95, width: 10, height: 10))
        //        UIBezierPath(ovalIn: <#T##CGRect#>)
        circleLayer.path = circlePath.cgPath
        circleLayer.strokeColor = UIColor.black.cgColor
        circleLayer.fillColor = UIColor.clear.cgColor
        
        shapeLayer.addSublayer(circleLayer)
    }
    
    func addLine(view:UIView, point:CGPoint)
    {
        let path = getNewPath(point: point, yChange: 100)
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 2
        
        var circleLayer:CAShapeLayer? = nil
        
        let sublayers = shapeLayer.sublayers
        if sublayers != nil
        {
            for layer in sublayers!
            {
                if layer.isKind(of: CAShapeLayer.self)
                {
                    circleLayer = layer as! CAShapeLayer
                    break
                }
            }
        }
        
        if circleLayer == nil
        {
            circleLayer = CAShapeLayer()
            circleLayer?.strokeColor = UIColor.black.cgColor
            circleLayer?.fillColor = UIColor.clear.cgColor
            
            shapeLayer.addSublayer(circleLayer!)
        }
        
        circleLayer?.path = getCirclePath(point: point, yChange: 100).cgPath
    }
    
    func getNewPath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        //        let yChange:CGFloat = 50
        let path = UIBezierPath()
        path.move(to: point)
        path.addLine(to: CGPoint(x: point.x, y: point.y + yChange - 5))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:point.x, y: point.y + yChange + 5))
        path.addLine(to: CGPoint(x: point.x, y: point.y + (2.0 * yChange)))
        path.close()
        
        return path
    }
    
    func getCirclePath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        let radius:CGFloat = 5
        //        let yChange:CGFloat = 50
        let rect = CGRect(x: point.x - radius, y: point.y + yChange - radius, width: 2 * radius, height: 2 * radius)
        let path = UIBezierPath(ovalIn: rect)
        path.close()
        
        return path
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*  if showCustomLineView
         {
         addCustomLineView()
         return
         }*/
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
//               containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addLineChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var lineChartView:ChartViewBase? = nil
    
    func addLineChart()
    {
        
        lineChartView = containerView?.chart
        
        lineChartView?.tapEventListener?.handler = LineHighlightHandler()
        
        lineChartView?.panEventListener?.handler =  LineFilterHandler()             //LineSingleTouchPanHandler()
        
        lineChartView?.longPressEventListener?.handler = LineLongPressHandler()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = true
        
        lineChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
        lineChartView?.getYAxis(atIndex: 1)!.axisMinimum = 0
        
        lineChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        lineChartView?.getYAxis(atIndex: 1)!.resizeEnabled = true
        
//        lineChartView?.rightAxis.xOffset = 30
        
//        lineChartView?.xAxis.axisMinimum = 0
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
//        lineChartView?.xAxis.granularity = 1.0
        
          let dateFormatter = DateFormatter()
         dateFormatter.dateFormat = "MMM\nyyyy"//"HH:mm:ss a"
         dateFormatter.locale = Locale(identifier: "en_IN")
        
        let xFormatter = ValueFormatter(formatter: dateFormatter, chart: lineChartView!)
        //        xFormatter.fetchValueFromData = true
        self.lineChartView?.xAxis.valueFormatter = xFormatter
        
        lineChartView?.xAxis.inverted = false
        
        lineChartView?.xAxis.scaleType = .Time
        
        lineChartView?.xAxis.setTimeScaleType(type: .Forced, forcedType: TimeScaleIntervalType.ABSMONTH)
        
        //        lineChartView?.xAxis.granularityEnabled = true
        
        //        let count = 2000+50
        let count = 1000
        var range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        /*
        //        for i in 2000..<count {
        for i in 0..<count {
            
            if i > 300
            {
                range = 300
            }
            if i > 600
            {
                range = 200
            }
            if i > 900
            {
                range = 100
            }
            
            
            let lab = "200" + String(i+1)
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        
        let shape = set1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.shapeSize = 8
        shape.lineWidth = 2
        
        set1.setShapeColor(UIColor.red)
        
        set1.lineWidth = 2
        set1.drawShapeEnabled = false
        
        set1.drawFilledEnabled = false
        set1.fillAlpha = 0.3
        set1.fillColor = ChartColorTemplates.pieColor()[5]
        set1.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        
        let shape1 = set2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.shapeSize = 8
        shape1.lineWidth = 2
        
        set2.setShapeColor(UIColor.brown)
        
        set2.lineWidth = 2
        set2.drawShapeEnabled = true
        
        set2.drawFilledEnabled = false
        set2.fillAlpha = 0.3
        set2.fillColor = ChartColorTemplates.pieColor()[1]
        set2.mode = .linear
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        
        set3.setCircleColor(UIColor.black)
        set3.lineWidth = 2
        set3.circleRadius = 3.0
        set3.drawCircleHoleEnabled = false
        set3.drawCirclesEnabled = true
        set3.drawShapeEnabled = false
        
        set3.drawFilledEnabled = false
        set3.fillAlpha = 0.3
        set3.fillColor = ChartColorTemplates.pieColor()[2]
        set3.mode = .linear
        
        */
        
        
        let newData =  readDataFromJson()
        var inc:UInt32 = 3
        for row in newData
        {
            inc += 1
            let val = arc4random_uniform(UInt32(range)) + inc
            dataEntries1.append(ChartDataEntry(x: Double(row[0]), y: Double(row[1])))
            dataEntries2.append(ChartDataEntry(x: Double(row[0]), y: Double(val)))
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        
        set1.plotType = .Line
        let lineDataSetOptions1 = LineDataSetOptions()
        set1.dataSetOptions = lineDataSetOptions1
        
        lineDataSetOptions1.drawCirclesEnabled = false
        set1.drawIconsEnabled = false
        lineDataSetOptions1.drawShapeEnabled = false
        set1.axisIndex = 1
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        
        set2.plotType = .Line
        let lineDataSetOptions2 = LineDataSetOptions()
        set2.dataSetOptions = lineDataSetOptions2
        
        lineDataSetOptions2.drawCirclesEnabled = false
        set2.drawIconsEnabled = false
        lineDataSetOptions2.drawShapeEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[5])
        set2.axisIndex = 0
        
        
        
        //        let chartData = ChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1, set2])
        chartData.setDrawValues(false)
        
        
        lineChartView?.data = chartData
        
        //lineChartView?.xAxis.spaceMax = 0.5
//        lineChartView?.xAxis.spaceMin = 0.9
        
        let lowerLimit = ChartLimitLine(limit: 12000, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
//        lineChartView?.rightAxis.addLimitLine(lowerLimit)
        
        
        lineChartView?.animate(xAxisDuration: 1.0)
        
        dataBackup.append(lineChartView?.data?.copy() as! ChartData)
        chartInstance.append(lineChartView!)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {

        if velocity > 1 && (Int(end)!-Int(start)!) == 1
        {
            level += 1
            
            lineChartView = containerView?.chart
            
            lineChartView?.tapEventListener?.handler = LineHighlightHandler()
            
            lineChartView?.panEventListener?.handler = LinePanHandler()
            
            lineChartView?.longPressEventListener?.handler = LineLongPressHandler()
            
            
            lineChartView?.getYAxis(atIndex: 1)!.enabled = false
            
            lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
            
            lineChartView?.xAxis.labelPosition = .bottom
            
            lineChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
            
//            lineChartView?.xAxis.axisMinimum = 0
            
            lineChartView?.xAxis.drawGridLinesEnabled = false
            
            lineChartView?.chartDescription?.enabled = false
            
            lineChartView?.xAxis.granularity = 1.0
            //        lineChartView?.xAxis.granularityEnabled = true
            
            //        let count = 2000+50
            let count = 12
            let range = 54
            
            var dataEntries1: [ChartDataEntry] = []
            var dataEntries2: [ChartDataEntry] = []
            var dataEntries3: [ChartDataEntry] = []
            
            var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
            
            //        for i in 2000..<count {
            for i in 0..<count {
                
                let lab = "Item " + String(Double(i+1))
                
                let val1 = arc4random_uniform(UInt32(range)) + 3
                
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i] as AnyObject))
                
                
                let val2 = arc4random_uniform(UInt32(range)) + 3
                
                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i] as AnyObject))
                
                let val3 = arc4random_uniform(UInt32(range)) + 3
                
                dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i] as AnyObject))
                
            }
            
            let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
            set1.drawIconsEnabled = false
            set1.setColor(UIColor.green)
            
            set1.plotType = .Line
            let lineDataSetOptions1 = LineDataSetOptions()
            set1.dataSetOptions = lineDataSetOptions1
            
            let shape = lineDataSetOptions1.markerInstance
            //shape.holeColor = UIColor.white
            shape.shapeType = .circle
            shape.size = CGSize(width: 8.0, height: 8.0)
            shape.lineWidth = 2
            
            lineDataSetOptions1.setShapeColor(UIColor.red)
            
            lineDataSetOptions1.lineWidth = 2
            lineDataSetOptions1.drawShapeEnabled = false
            
            lineDataSetOptions1.drawFilledEnabled = false
            lineDataSetOptions1.fillAlpha = 0.3
            lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[5]
            lineDataSetOptions1.mode = .linear
            
            
            let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
            set2.drawIconsEnabled = false
            set2.setColor(UIColor.red)
            
            set2.plotType = .Line
            let lineDataSetOptions2 = LineDataSetOptions()
            set2.dataSetOptions = lineDataSetOptions2
            
            lineDataSetOptions2.setCircleColor(UIColor.black)
            lineDataSetOptions2.lineWidth = 2
            lineDataSetOptions2.circleRadius = 3.0
            lineDataSetOptions2.drawCircleHoleEnabled = false
            lineDataSetOptions2.drawCirclesEnabled = true
            lineDataSetOptions2.drawShapeEnabled = false
            
            lineDataSetOptions2.drawFilledEnabled = false
            lineDataSetOptions2.fillAlpha = 0.3
            lineDataSetOptions2.fillColor = ChartColorTemplates.pieColor()[1]
            lineDataSetOptions2.mode = .linear
            
            let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
            set3.drawIconsEnabled = false
            set3.setColor(UIColor.blue)
            
            set3.plotType = .Line
            let lineDataSetOptions3 = LineDataSetOptions()
            set3.dataSetOptions = lineDataSetOptions3
            
            lineDataSetOptions3.setCircleColor(UIColor.black)
            lineDataSetOptions3.lineWidth = 2
            lineDataSetOptions3.circleRadius = 3.0
            lineDataSetOptions3.drawCircleHoleEnabled = false
            lineDataSetOptions3.drawCirclesEnabled = true
            lineDataSetOptions3.drawShapeEnabled = false
            
            lineDataSetOptions3.drawFilledEnabled = false
            lineDataSetOptions3.fillAlpha = 0.3
            lineDataSetOptions3.fillColor = ChartColorTemplates.pieColor()[2]
            lineDataSetOptions3.mode = .linear
            
            
            
            
            //        let chartData = ChartData(dataSet: set1)
            let chartData = ChartData(dataSets: [set1, set2,set3])
            chartData.setDrawValues(false)
            
            
            lineChartView?.data = chartData
            
            //lineChartView?.xAxis.spaceMax = 0.5
            lineChartView?.xAxis.spaceMin = 0.9
            
            
            
            lineChartView?.animate(xAxisDuration: 1.0)
            
            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
            chartInstance.append(lineChartView!)
        }
        else if velocity < -3 && Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
        {
            if level > 0
            {
                level = level-1
                
                let chart = chartInstance[level]
                
                lineChartView = chart
                
                chart.data = dataBackup[level].copy() as! ChartData
                
                dataBackup.removeLast(dataBackup.count-1 - level)
                
                chartInstance.removeLast(chartInstance.count-1 - level)
                
                containerView?.initializeChart(chart: chart)
                
                chart.animate(xAxisDuration: 1.0)
            }
        }
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    var orientationFlag = true
}

extension LineViewTimeScaleController: PlotDelegate {
    
    // MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        
        return themeImage
    }
    
    func addChartOrientationSwapButton(){
        
        let orientationSwapButton = UIButton(type: .custom)
        
        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)
        
        orientationSwapButton.setImage(buttonImage(), for: .normal)
        
        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)
        
        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true
        
        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true
        
        self.navigationItem.rightBarButtonItem = buttonItem
    }
    
    @objc func chartOrientationSwap(){
        
        lineChartView?.xAxis.tickLabelMode = .forced
        
        if !orientationFlag{
            
            lineChartView?.isRotated = false
            
            orientationFlag = true
            
            lineChartView?.xAxis.labelRotationAngle = 60
        }
        else{
            
            lineChartView?.isRotated = true
            
            lineChartView?.xAxis.labelPosition = .bottom
            
            lineChartView?.xAxis.labelRotationAngle = 0
            
            lineChartView?.getYAxis(atIndex: 0)?.labelPosition = .outsideChart
            
            orientationFlag = false
        }
        
        lineChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
    }
}

