//
//  MultiBarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 09/10/17.
//  Copyright © 2017 charts. All rights reserved.
//


import UIKit
import  zchart

class MultiBarViewController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
      
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return entries }
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
   
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String((dataSet?.entryForIndex(selectedIndex!)?.y)!))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! ChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }

    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
      //  containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
      //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = MultiBarPanHandler()
        
     //   barChartView?.legend.labels
        
        
//        barChartView?.xAxis.labelRotationAngle = 0
//        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
//
        barChartView?.xAxis.axisTitle = "Years"
//
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
//        barChartView?.leftAxis.baseLineEnabled = true
//        barChartView?.leftAxis.baseLine?.baseValue = 30

//        barChartView?.rightAxis.axisTitle = "Quantities"
//        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.rendererDelegate = self
        
        totalSales = 0
        
        let count = 9
        let range = 54
        
        let yVal1 = [27.0,16.0,1.0,31.0,2.0,0.0,26.0,9.0,0.0,27.0,16.0,1.0,31.0,2.0,0.0,26.0,9.0,0.0,27.0,16.0,1.0,31.0,2.0,0.0,26.0,9.0,0.0]
        let xString = ["Positive","Neutral","Negative","Positive1","Neutral1","Negative1","Positive2","Neutral2","Negative2"]
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        var index = 0
        for i in 0..<count {
            
            dataEntries1.append(ChartDataEntry(xString: xString[i], y: -yVal1[index], data: nil))
            index += 1
            dataEntries2.append(ChartDataEntry(xString: xString[i], y: yVal1[index], data: nil))
            index += 1
            dataEntries3.append(ChartDataEntry(xString: xString[i], y: yVal1[index], data: nil))
            index += 1
        }
        
        
       /* let gradient1 = LinearGradient(colors: [ChartColorTemplates.pieColor()[0], ChartColorTemplates.pieColor()[0]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[1]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient3 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient4 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[3]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient5 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[4]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        */
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
//        set2.gradients = [gradient2]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
//        set3.gradients = [gradient3]
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
//        set4.gradients = [gradient4]
        
        let chartData = ChartData(dataSets: [set1, set2, set3])
        
    //    let chartData = ChartData(dataSet: set1)
//        chartData.barWidth = 0.175
        
        barChartView?.data = chartData
        
        
        //        let groupSpace = 0.1;
                //        let barSpace = 0.03;
                //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        //          chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
                
               // chartData.highlightColor = UIColor.brown
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidthPixel = 18

        barPlotOptions.barSpacePixel = 5

        barPlotOptions.groupSpacePixel = 20
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 40
        
        barPlotOptions.fitBars = true
        
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
//        chartData.highlightGradient = gradient5
//        chartData.nonHighlightGradient = gradient5
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
//        barChartView?.xAxis.axisMinimum = 0
        
//        barChartView?.xAxis.axisMaximum = 0+chartData.groupWidth(groupSpace: 0.08, barSpace: 0.03)
        
//        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        

//        barChartView?.xAxis.axisMinimum = 0
//        barChartView?.xAxis.axisMaximum = 1 * 2 + 0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
//                barChartView?.xAxis.spaceMax = 2
//                barChartView?.xAxis.spaceMin = 2
        
//        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
       // let scaleLevel = CGFloat(count/5)
        
      //  barChartView?.setScaleMinima(scaleLevel, scaleY: 0)
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        
        //chartData.maximumBarPixel = 10

         barChartView?.xAxis.labelCount = 7
        
//        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
       
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
//        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
//        upperLimit.lineColor = NSUIColor.green
//        //        upperLimit.lineWidth = 6.0
//        
//        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
//        lowerLimit.lineColor = NSUIColor.red
//        
//        lowerLimit.lineDashPhase = 2.0
//        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //barChartView?.data?.setDrawValues(false)
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
        
    }
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = MultiBarPanHandler()
        
        
    
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
    
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            let lab = "Item " + String(Double(i+1))
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.colorful()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.colorful()[1]]
        set2.label = "Company B"
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()

        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSets: [set1, set2])
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
//        chartData.barWidth = 0.175
      
//        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.groupSpacePixel = 20
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 100
        
        barPlotOptions.fitBars = true
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
//        barChartView?.xAxis.axisMinimum = 0
//        barChartView?.xAxis.axisMaximum = 10
//        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
     
        
        
        barChartView?.xAxis.labelCount = 4
        
//        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
     
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        
        let chart = chartInstance[index]
        
        barChartView = chart
        
        level = index
        
        containerView?.initializeChart(chart: chart)
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
//        let ChartData = chart.data as! ChartData
        
//        let barChartPlotOption = barChartView!.getBarPlotOption()
//
//        barChartView.groupBars(fromX: 0, groupSpace: barChartPlotOption.groupSpace, barSpace: barChartPlotOption.barSpace, xInverted: barChartView!.xAxis.isInverted)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
    
    /*
     override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
     {
     
     super.viewWillTransition(to: size, with: coordinator)
     
     viewChanged = true
     /*  coordinator.animateAlongsideTransition(in: self.containerView, animation: { (UIViewControllerTransitionCoordinatorContext) in
     self.containerView.setNeedsUpdateConstraints()
     }, completion: nil)
     
     coordinator.animate(alongsideTransition: {, completion: <#T##((UIViewControllerTransitionCoordinatorContext) -> Void)?##((UIViewControllerTransitionCoordinatorContext) -> Void)?##(UIViewControllerTransitionCoordinatorContext) -> Void#>) */
     
     //   self.containerView?.legendView.collectionView?.reloadItems(at: (self.containerView?.legendView.collectionView?.indexPathsForVisibleItems)!)
     
     //self.containerView?.legendView.collectionView?.reloadSections(<#IndexSet#>)
     
     coordinator.animate(alongsideTransition: { context in
     // do whatever with your context
     self.containerView?.setNeedsUpdateConstraints()
     //            self.containerView?.legendView.collectionView?.performBatchUpdates({
     //            self.containerView?.legendView.collectionView?.setCollectionViewLayout((self.containerView?.legendView.collectionView?.collectionViewLayout)!, animated: true)
     //            }, completion: nil)
     context.viewController(forKey: UITransitionContextViewControllerKey.from)
     }, completion: nil)
     }
     
     var viewChanged:Bool = false
     
     override func viewWillLayoutSubviews() {
     super.viewWillLayoutSubviews()
     if viewChanged
     {
     //self.containerView?.legendView.collectionView?.collectionViewLayout.invalidateLayout()
     }
     }
     
     override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
     
     if viewChanged {
     viewChanged = false
     //   self.containerView?.legendView.collectionView?.performBatchUpdates({}, completion: nil)
     }
     }
     */
    
}

extension MultiBarViewController: RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        guard let barPlotoptions = chartView.getPlotOptions(type: .Bar) as? BarPlotOptions
        else {
            return
        }
        
        if barPlotoptions.isStacked {
            
        }
        else  {
            
            for barLayer in BarLayer.getAllBarLayer(chart: chartView) {
                
                guard let barRect = barLayer.barRect else {
                    continue
                }
                
                let isRotated = chartView.isRotated
                
                if (barRect.height == 0 && !isRotated) || (barRect.width == 0 && isRotated) {
                    
                    let path = CGMutablePath()
                                           
                    if isRotated {
                        path.move(to: barRect.origin)
                        path.addLine(to: CGPoint(x: barRect.origin.x, y: barRect.origin.y + barRect.height))
                        
                    }
                    else {
                        path.move(to: barRect.origin)
                        path.addLine(to: CGPoint(x: barRect.origin.x + barRect.width, y: barRect.origin.y))
                    }
                    
                    if let barSubLayers = barLayer.sublayers, barSubLayers.count > 1 {
                        (barSubLayers[0] as? ChartExtrasLayer)?.path = path
                        (barSubLayers[0] as? ChartExtrasLayer)?.strokeColor = barLayer.fillColor
                    }
                    else {
                        let layerForValueZero = CAShapeLayer()
                        layerForValueZero.path = path
                        layerForValueZero.strokeColor = barLayer.fillColor
                        barLayer.addSublayer(layerForValueZero)
                    }
                }
            }
        }
    }
}
