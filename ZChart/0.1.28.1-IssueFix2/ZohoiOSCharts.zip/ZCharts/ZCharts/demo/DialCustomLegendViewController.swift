//
//  DialCustomLegendViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 22/06/22.
//  Copyright © 2022 charts. All rights reserved.
//

import Foundation

import zchart
import UIKit

class DialCustomLegendViewController: UIViewController,IToolTipEntryGenerator,ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            return entries
        }
        
        let pieEntry = entry!
        let toolTipEntry = ToolTipEntry(label: pieEntry.xString!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = (entry?.entryColor)!
        
        entries.append(toolTipEntry)
        
       return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
      // Views Hide Options
       containerView?.title.titleEnabled = false
       containerView?.legend.legendEnabled = true
       containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        containerView?.isAxisChart = false

                
//        containerView?.mainTitleSettings.text = "PieChart"//textSettings//.text = "PieChart"
        
        //addChartTypeAndData
        addPieChart()
    }
    
    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
    
        // MARK: Events
        
        pieChartView.tapEventListener?.handler = DialHandler()//SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
//        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.handler = PiePanHandler()
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
//        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        
        pieChartView.getYAxis(atIndex: 0)?.labelCount = 5
//        pieChartView.getYAxis(atIndex: 0)?.axisMinimum = -150
//        pieChartView.getYAxis(atIndex: 0)?.axisMaximum = 150
        pieChartView.getYAxis(atIndex: 0)?.axisLineColor = UIColor.black
        pieChartView.getYAxis(atIndex: 0)?.axisLineWidth = 2
        pieChartView.getYAxis(atIndex: 0)?.axisTickMarkColor = UIColor.black
//        pieChartView.getYAxis(atIndex: 0)?.axisTickMarkLineWidth = 0.5
        pieChartView.getYAxis(atIndex: 0)?.yOffset = 5
        pieChartView.getYAxis(atIndex: 0)?.drawGridLinesEnabled = false
    
        
//        pieChartView.radius = 150
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        
        let data = [75]
//
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]), label: dataLabel[i], levelMarker: [15,30,46,64,79,92,100], targetMarker: 85, data: nil)
            let dataEntry =  ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), levelMarker: [-100,-75,-35,0,35,75,100]
, targetMarker: 100, data: nil)
//            let dataEntry =  ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), levelMarker: [15,Double.nan,30,Double.nan,100], targetMarker: 85, data: nil)
//            let dataEntry = ChartDataEntry(value: Double(data[i]), label: dataLabel[i], levelMarker: [15,Double.nan,30,Double.nan,100], targetMarker: 85, data: nil)
//            let dataEntry = ChartDataEntry(value: Double(data[i]), label: dataLabel[i], data: nil)
            piedata.append(dataEntry)
        }
        
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors = [UIColor.black]
        
//        chartDataSet.gradients = getRadialGradientArray()
        
       // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.black
        
//        chartDataSet.sliceSpace = 10
        
        chartDataSet.plotType = .Dial
        
        let chartData = ChartData(dataSet: chartDataSet)

        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        let dialOptions = pieChartView.getPlotOptions(type: .Dial) as! DialPlotOptions
        dialOptions.startAngle = 180
        dialOptions.maxAngle = 180
        dialOptions.innerRadiusPercent = 0.9
        dialOptions.direction = .clockwise
        dialOptions.levelMarkerColors = [ChartColorTemplates.demoappcolor()]
        dialOptions.bandWidth = 0.1
        
        dialOptions.valueLinePart2Length = 0.6
        
        dialOptions.targetMarkerShapeProperties.holeColor = nil
        dialOptions.targetMarkerShapeProperties.strokeColor = UIColor.red
        dialOptions.targetMarkerPadding = 0.3
        
//        dialOptions.needleShapeProperties = ShapeProperties(type: LineShapes.needleRound)
        
        dialOptions.needleShapeProperties.strokeColor = UIColor.black
        dialOptions.needleShapeProperties.holeColor = UIColor.black
        dialOptions.needleShapeProperties.lineWidth = 2
        dialOptions.needleShapeProperties.size = CGSize(width: 20.0, height: 20.0)
        dialOptions.needleShapeProperties.padding = 0.2
        
        dialOptions.drawEntryLabelsEnabled = false
        
        dialOptions.arrowShow = false
        
        dialOptions.patternEnabled = false
        
        dialOptions.outerCircleEnabled = false
        
        dialOptions.innerCircleEnabled = false
        
        dialOptions.centerLabelEnabled = false
        
        dialOptions.drawHoleEnabled = false
        
        dialOptions.holeRadiusPercent = 0.8
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
       // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
       
        chartInstance.append(pieChartView)
        
    }
 
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
    
    
}

extension DialCustomLegendViewController{
    
    func legendReloaded(_ chartView: ChartViewBase, _ legendEntries: [LegendEntry]?) {
        
        var levelMarkerEntries = [LegendEntry]()
        
        guard let chartData = chartView.data,
              let DialPlotoption = CommonHelperFunctions.getPlotOption(chart: chartView, types: [.Dial]) as? DialPlotOptions
        else {
            return
        }
        
        for dataSet in chartData.dataSets{
            
            let levelVal = dataSet.entryForIndex(0)?.levelMarker
            
            let levelColor = DialPlotoption.levelMarkerColors[dataSet.axisIndex]
            
            for (val,color) in zip(levelVal!, levelColor) {
                
                var label = ""
                
                switch(val){
                    
                case -100 ..< -75:
                    label = "extremely negative"
                    break
                case -75 ..< -35:
                    label = "negative"
                    break
                case -35 ..< 0:
                    label = "Neutral"
                    break
                case -0 ..< 35:
                    label = "likely to be positive"
                    break
                case 35 ..< 75:
                    label = "positive";
                    break
                case 75 ..< 100:
                    label = "very positive"
                    ; break
                default:
                    label = ""
                }
                
                let legendEntry = LegendEntry(
                            label: label,
                            form: dataSet.form,
                            formSize: dataSet.formSize,
                            formLineWidth: dataSet.formLineWidth,
                            formLineDashPhase: dataSet.formLineDashPhase,
                            formLineDashLengths: dataSet.formLineDashLengths,
                            formColor : color
                        )
                
                levelMarkerEntries.append(legendEntry)
            }
        }
        
        containerView?.legendView.delegate = nil
        
        containerView?.legendView.reload(legendEntries: levelMarkerEntries)
        
    }
}

