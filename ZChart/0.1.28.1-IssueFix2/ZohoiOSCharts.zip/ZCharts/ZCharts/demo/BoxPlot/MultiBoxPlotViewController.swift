//
//  MultiBoxPlotViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 11/08/22.
//  Copyright © 2022 charts. All rights reserved.
//

import UIKit

import zchart

class MultiBoxPlotViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry!
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
//        barChartView?.getYAxis(atIndex: 0)!.xOffset = 50

        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 50
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.labelRotationAngle = 60
        
        barChartView?.xAxis.tickLabelMode = .auto
        
        barChartView?.xAxis.customTickEnabled = true
        
        barChartView?.xAxis.axisLabelOffsets.marginTop = 0
        barChartView?.xAxis.axisLabelOffsets.marginBotom = 0
        barChartView?.xAxis.axisLabelOffsets.marginLeft = 10
        barChartView?.xAxis.axisLabelOffsets.marginRight = 10
        
        barChartView?.xAxis.axisTitleOffsets.marginTop = 0
        barChartView?.xAxis.axisTitleOffsets.marginBotom = 0
        barChartView?.xAxis.axisTitleOffsets.marginLeft = 10
        barChartView?.xAxis.axisTitleOffsets.marginRight = 10
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = false
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 20
        let range = 10
        
        var dataEntries1: [ChartDataEntry] = []
        
        var dataEntries2: [ChartDataEntry] = []
        
 
          for i in 0..<count {
            
              let lab = "W"+String(Double(i+1))
              
              let val1 = Double(arc4random_uniform(UInt32(range)) + 15)
              
              let val2 = Double(arc4random_uniform(UInt32(range)) + 1)
              
              let val3 = Double(arc4random_uniform(UInt32(range)) + 35)
              
              let val4 = Double(arc4random_uniform(UInt32(range)) + 15)
              
              var medianVal: Double
              
              var maxWhiskersVal: Double
                                                 
              var minWhiskersVal: Double
              
              var valArr: [Double]
              
              if i > 3 && i < 6 {
                  
                  medianVal = Double.random(in: -val2..<val1 - 2)
                  
                  maxWhiskersVal = max(val1,-val2) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(val1,-val2) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: val1, y0: -val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: -val4..<val3 - 2)
                  
                  maxWhiskersVal = max(val3,-val4) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(val3,-val4) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: val3, y0: -val4, plotData: valArr as AnyObject, data: nil))
                  
              }
              else if i > 7 && i < 10 {
                  
                  medianVal = Double.random(in: -val1..<(-val2 - 2))
                  
                  maxWhiskersVal = max(-val1,-val2) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(-val1,-val2) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: -val1, y0: -val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: -val3..<(-val4 - 2))
                  
                  maxWhiskersVal = max(-val3,-val4) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(-val3,-val4) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: -val3, y0: -val4, plotData: valArr as AnyObject, data: nil))
                  
//                  print(valArr[0],val1,val2)
              }
              else if i > 12 && i < 16 {
                  
                  medianVal = Double.random(in: -val1..<val2 - 2)
                  
                  maxWhiskersVal = max(-val1,val2) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(-val1,val2) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: -val1, y0: val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: -val3..<val4 - 2)
                  
                  maxWhiskersVal = max(-val3,val4) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(-val3,val4) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: -val3, y0: val4, plotData: valArr as AnyObject, data: nil))
                  
//                  print(valArr[0],val1,val2)
              }
              else {
                  
                  medianVal = Double.random(in: val2..<val1 - 2)
                  
                  maxWhiskersVal = max(val1,val2) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(val1,val2) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: val1, y0: val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: val4..<val3 - 2)
                  
                  maxWhiskersVal = max(val3,val4) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(val3,val4) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: val3, y0: val4, plotData: valArr as AnyObject, data: nil))
                  
//                  print(valArr[0],val1,val2)
              }
              
              totalSales += CGFloat(val1)
          }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[2]]
        set1.plotType = .BoxPlot
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .BoxPlot
        set2.dataSetOptions = set1.dataSetOptions
        
        let chartData = ChartData(dataSets: [set1,set2])
        
        barChartView?.data = chartData
        
        
        let BoxPlotPlotOptions = barChartView?.getPlotOptions() as! BoxPlotPlotOptions
        
        BoxPlotPlotOptions.fitBars = true
        
        chartData.setDrawValues(false)
        
        BoxPlotPlotOptions.groupSpacePixel = 0.1
        
        BoxPlotPlotOptions.barWidth = 0.7
        
        BoxPlotPlotOptions.barWidthPixel = 20
        
        BoxPlotPlotOptions.barSpacePixel = 20
        
        BoxPlotPlotOptions.barCount = 12
        
        BoxPlotPlotOptions.medianIndex = 0
        
        BoxPlotPlotOptions.minWhiskersIndex = 1
        
        BoxPlotPlotOptions.maxWhiskersIndex = 2
        
        BoxPlotPlotOptions.drawMedianValueEnabled = true
        
        BoxPlotPlotOptions.drawWhiskersValueEnabled = true
        
        BoxPlotPlotOptions.medianColor = UIColor.white
        
        if #available(iOS 13.0, *) {
            BoxPlotPlotOptions.whiskersColor = UIColor.systemGray2
        } else {
            // Fallback on earlier versions
        }
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        BoxPlotPlotOptions.minimumBarPixel = 18
        
        BoxPlotPlotOptions.maximumBarPixel = 30
        
//                BoxPlotPlotOptions.highlightColor = UIColor.blue
        
        BoxPlotPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 0.5)
        
        CommonUtilities.customAnimation(chart: barChartView!, duration: 0.6, animationBlock: animateBlock)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
  
    }
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.maxLabelWidth = 30
        barChartView?.xAxis.maxLabelWidth = 60
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = ChartColorTemplates.pieColor()
        set1.plotType = .Bar
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.barWidth = 0.6
        
        plotOptions.minimumBarPixel = 18

        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 12
        
        
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.9
     
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false

        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
     
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        
        plotBackup.append(barChartView!.plotOptions)
        
        chartInstance.append(barChartView!)
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
      
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
       
    }
}
