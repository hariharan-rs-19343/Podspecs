//
//  ParserFunctions.swift
//  ZCharts
//
//  Created by Aravinth T on 26/04/23.
//  Copyright © 2023 charts. All rights reserved.
//

import Foundation
import charts_json_parser


class ParserFunctions
{
    public static func getParsedJson(jsString:String) -> String
    {
        
        let parsedString = ChartUtils().getJSONString(s:"{\"chartJSON\":" + jsString + "}")

        return parsedString
        
//        return jsString
    }

}
