//
//  WordCloudColorAxisViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 01/09/21.
//  Copyright © 2021 charts. All rights reserved.
//

import UIKit
import  zchart

class WordCloudColorAxisViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            
            return entries
        }
        else
        {
            let barEntry = entry!
                
            var label:String
            var value:String
                
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
                
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (chartInstance?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .right
        containerView?.legend.type = .continous
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
    }
    
    
    
    var chartInstance:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        chartInstance = containerView?.chart
        
        chartInstance?.backgroundColor = UIColor.clear
        
        //*****************************  Handlers  *******************************//
        
        chartInstance?.pinchEventListener?.handler = DefaultPinchHandler()
        
        chartInstance?.panEventListener?.handler = DefaultPanHandler()
        
        chartInstance?.pinchZoomEnabled = true
                
        chartInstance?.tapEventListener?.handler = WordCloudHighlightHandler()
        
        /*chartInstance?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        chartInstance?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        chartInstance?.pinchEventListener?.handler = ZoomingPinchHandler()*/
    
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 130
        let range = 1200
        
        let xyvalues = [
            [
                "Aggregate",
                22781
            ],
            [
                "Arithmetic",
                5969
            ],
            [
                "BinaryExpression",
                7300
            ],
            [
                "CompositeExpression",
                3892
            ],
            [
                "Distinct",
                4876
            ],
            [
                "ExpressionIterator",
                1476
            ],
            [
                "If",
                2434
            ],
            [
                "Literal",
                4159
            ],
            [
                "Comparison",
                5103
            ],
            [
                "Match",
                4116
            ],
            [
                "Maximum",
                6000
            ],
            [
                "Average",
                11630
            ],
            [
                "LinearScale",
                12781
            ],
            [
                "LogScale",
                3969
            ],
            [
                "OrdinalScale",
                5300
            ],
            [
                "QuantileScale",
                13892
            ],
            [
                "QuantitativeScale",
                4876
            ],
            [
                "RootScale",
                1476
            ],
            [
                "TimeScale",
                9434
            ],
            [
                "IScaleMap",
                3159
            ],
            [
                "ScaleType",
                4103
            ],
            [
                "Scale",
                3116
            ],
            [
                "Domain",
                4500
            ],
            [
                "Range",
                8630
            ],
            [
                "Arrays",
                25470
            ],
            [
                "Colors",
                2119
            ],
            [
                "Dates",
                7072
            ],
            [
                "Filter",
                3042
            ],
            [
                "Geometry",
                7167
            ],
            [
                "AgglomerativeCluster",
                5960
            ],
            [
                "CommunityStructure",
                2310
            ],
            [
                "HierarchicalCluster",
                4200
            ],
            [
                "MergeEdge",
                4300
            ],
            [
                "BetweennessCentrality",
                3400
            ],
            [
                "LinkDistance",
                7000
            ],
            [
                "MaxFlowMinCut",
                7000
            ],
            [
                "ShortestPaths",
                2500
            ],
            [
                "SpanningTree",
                4111
            ],
            [
                "AspectRatioBanker",
                3507
            ]
        ]
        
        var dataEntries1: [ChartDataEntry] = []
 
        for i in 0..<xyvalues.count {
            
            let xLabel = xyvalues[i][0] as! String
            
            let yVal = Double(xyvalues[i][1] as! Int)
            
            let e = ChartDataEntry(xString: xLabel, y: yVal, data: nil)
            e.colorValue =  Double(arc4random_uniform(UInt32(2997)) + 3)
            dataEntries1.append(e)
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "States")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .WordCloud
        set1.valueFont  = UIFont(name: "TimesNewRomanPS-BoldItalicMT", size: 10)!
        
     
        let chartData = ChartData(dataSet: set1)
       
        chartInstance?.data = chartData
        
        
        let plotOptions = chartInstance?.getPlotOptions() as! WordCloudPlotOptions
        
        plotOptions.minFontSize = 2
        
        plotOptions.rotation = [0,90]
        
//        plotOptions.outerPadding = 30
        
        let colorAxis = (chartInstance?.colorAxis)!
        colorAxis.enabled = true
        colorAxis.type = .linear
        colorAxis.stops = [0,3000]
        colorAxis.colors = [UIColor.red,UIColor.yellow]
        
       /*
        //*****************************  Animation  *******************************//
        
//        chartInstance?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
//        let animateBlock = SingleBarViewController.getAnimationBlock(chartView: self.chartInstance!)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.chartInstance!, duration: 0.5)
        
        CommonUtilities.customAnimation(chart: chartInstance!, duration: 1.0, animationBlock: animateBlock)
        
 */
  
    }
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {

        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
       
    }

}


