//
//  FlatPackedBubbleViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 17/12/20.
//  Copyright © 2020 charts. All rights reserved.
//

//
//  PackedBubbleViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 13/05/20.
//  Copyright © 2020 charts. All rights reserved.
//


import UIKit
import zchart

class FlatPackedBubbleViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let high = bubbleChartView?.getHighlightByEntry(entry!)
        
        let set = bubbleChartView?.data?.dataSets[high!.dataSetIndex]
       
        let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.xString)!), value: String(describing: entry?.y))
        toolTipEntry.valueTextColor = (set?.colors[0])!
            
        entries.append(toolTipEntry)
        
        return entries
    }
    
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        if chartView.lastSelected != nil
        {
            
            for layer in BubbleLayer.getAllBubbleLayer(chart: chartView)
            {
                if layer.bubbleEntry === chartView.lastSelected![0]
                {
                    layer.lineWidth = 4
                }
                else
                {
//                    layer.fillColor = NSUIColor.gray.withAlphaComponent(0.5).cgColor
//                    layer.opacity = 0.4
                }
            }
        }
        
    }
    
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer:CAShapeLayer) -> UIBezierPath {
        
        let size = shapeInstance.size.width
        
        let shapeFrame = CGRect(x: point.x - (size/2), y: point.y - (size/2), width: size, height: size)
        
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.isAxisChart = false
        
        //addChartTypeAndData
        addScatterChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    func readDataFromJson() -> [[Double]]
    {
        var finalData:[[Double]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        for rowArray in dataArray
                        {
                            var row:[Double] = []
                            for element in rowArray
                            {
                                let val = element as! Double
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    var bubbleChartView:ChartViewBase? = nil
    
    func addScatterChart()
    {
        
        bubbleChartView = containerView?.chart
        
        bubbleChartView?.rendererDelegate = self
        
        bubbleChartView?.pinchZoomEnabled = true
        
        bubbleChartView?.tapEventListener?.handler = PackedBubbleHighlightHandler()
        
        bubbleChartView?.panEventListener?.handler = DefaultPanHandler()
        
        bubbleChartView?.pinchEventListener?.handler = DefaultPinchHandler()
        
        bubbleChartView?.getYAxis(atIndex: 0)!.enabled = false
        
        bubbleChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        bubbleChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        bubbleChartView?.xAxis.labelPosition = .bottom
        
        
        bubbleChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        bubbleChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
//        bubbleChartView?.xAxis.axisMinimum = 0
        
        bubbleChartView?.xAxis.drawGridLinesEnabled = false
        
        bubbleChartView?.chartDescription?.enabled = false
        
        bubbleChartView?.xAxis.granularity = 1.0
        
        bubbleChartView?.xAxis.scaleType = .Ordinal
        
        bubbleChartView?.xAxis.valueFormatter = ValueFormatter(chart: bubbleChartView!)
        
        bubbleChartView?.xAxis.spaceMinPixel = 50
        bubbleChartView?.xAxis.spaceMaxPixel = 50
        
        bubbleChartView?.xAxis.inverted = false
        
        let count = 20
        let range = 100
        let sizeRange = 3000
        
        var dataEntries1:[ChartDataEntry] = []
        var dataEntries2:[ChartDataEntry] = []
        var dataEntries3:[ChartDataEntry] = []
                        
        
        dataEntries1.append(ChartDataEntry(xString: "A1", y: 100, data: nil))
        dataEntries1.append(ChartDataEntry(xString: "A2", y: 500, data: nil))
        dataEntries1.append(ChartDataEntry(xString: "A3", y: 700, data: nil))
        
        dataEntries2.append(ChartDataEntry(xString: "B1", y: 90, data: nil))
        dataEntries2.append(ChartDataEntry(xString: "c3", y: 300, data: nil))
        
        dataEntries3.append(ChartDataEntry(xString: "C1", y: 100, data: nil))
        dataEntries3.append(ChartDataEntry(xString: "C3", y: 200, data: nil))
        dataEntries3.append(ChartDataEntry(xString: "C3", y: 600, data: nil))
        dataEntries3.append(ChartDataEntry(xString: "C4", y: 900, data: nil))
        
        
        // ****************************************** Web data  ******************************************
        
            /*   let root = ChartDataEntry(xString: "A1", y: 0, data: nil)
               
           root.childEntries.append(ChartDataEntry(xString: "B1", y: 9285.06, data: nil))
           root.childEntries.append(ChartDataEntry(xString: "B2", y: 21569.53, data: nil))
            root.childEntries.append(ChartDataEntry(xString: "B3", y: 26574.06, data: nil))
            root.childEntries.append(ChartDataEntry(xString: "B4", y: 54130.35, data: nil))
            root.childEntries.append(ChartDataEntry(xString: "B5", y: 8021.13, data: nil))
               
               let root1 = ChartDataEntry(xString: "A2", y: 0, data: nil)
               
               root1.childEntries.append(ChartDataEntry(xString: "c1", y: 46822.92, data: nil))
               root1.childEntries.append(ChartDataEntry(xString: "c2", y: 56613.76, data: nil))
               root1.childEntries.append(ChartDataEntry(xString: "c3", y: 50016.81, data: nil))
               root1.childEntries.append(ChartDataEntry(xString: "c4", y: 53194.35, data: nil))
                root1.childEntries.append(ChartDataEntry(xString: "c5", y: 18197.32, data: nil))
               
               
               let root2 = ChartDataEntry(xString: "A3", y: 0, data: nil)
               
               root2.childEntries.append(ChartDataEntry(xString: "D1", y: 21070.37, data: nil))
               root2.childEntries.append(ChartDataEntry(xString: "D2", y: 29932.19, data: nil))
               root2.childEntries.append(ChartDataEntry(xString: "D3", y: 42632.44, data: nil))
               root2.childEntries.append(ChartDataEntry(xString: "D4", y: 34032.92, data: nil))
                root2.childEntries.append(ChartDataEntry(xString: "D5", y: 8681.25, data: nil))
        
               dataEntries1.append(root)
               dataEntries2.append(root1)
               dataEntries3.append(root2)*/
            
        
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[3])
        set1.plotType = .PackedBubble
        
        let dataOptions = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOptions.shapeProperties
        shape.holeColor = ChartColorTemplates.pieColor()[3].withAlphaComponent(0.3)
        shape.strokeColor = ChartColorTemplates.pieColor()[3]
        shape.shapeType = .circle
        shape.lineWidth = 2
        
        let gradient6 = LinearGradient(colors: [ChartColorTemplates.pieColor()[2], ChartColorTemplates.pieColor()[2].withAlphaComponent(0.5)], positions: [0.2,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        //        set1.gradients = [gradient6]
        
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[4])
        set2.plotType = .PackedBubble
        
        let dataOptions1 = set2.dataSetOptions as! AxisChartDataSetOptions
        let shape1 = dataOptions1.shapeProperties
        shape1.holeColor = ChartColorTemplates.pieColor()[4].withAlphaComponent(0.3)
        shape1.strokeColor = ChartColorTemplates.pieColor()[4]
        shape1.shapeType = .circle
        shape1.lineWidth = 2
        
        
        let set3  = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .PackedBubble
        
        let dataOptions2 = set3.dataSetOptions as! AxisChartDataSetOptions
        let shape2 = dataOptions2.shapeProperties
        shape2.holeColor = ChartColorTemplates.pieColor()[2].withAlphaComponent(0.3)
        shape2.strokeColor = ChartColorTemplates.pieColor()[2]
        shape2.shapeType = .circle
        shape2.customPathDataSource = self
        shape2.lineWidth = 2
        
        
        
        
        let chartData = ChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(true)
        
        bubbleChartView?.data = chartData
        
        let plotOptions = (bubbleChartView?.getPlotOptions(type: .PackedBubble) as! BubblePlotOptions)
        plotOptions.mode = .Flat
//        plotOptions.minimumShapeSizeInPixel = 8
//        plotOptions.maximumShapeSizeInPixel = 30
        
        bubbleChartView?.xAxis.spaceMin = 0.5
        bubbleChartView?.xAxis.spaceMax = 0.5
        
        
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        /*  let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
         upperLimit.lineColor = NSUIColor.black
         upperLimit.shapeProperties = ShapeProperties()
         
         upperLimit.limitValueTextColor = UIColor.white
         upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
         
         upperLimit.shapeProperties?.holeColor = UIColor.white
         upperLimit.shapeProperties?.shapeType = .custom
         upperLimit.shapeProperties?.shapeSize = 8
         upperLimit.shapeProperties?.lineWidth = 2
         upperLimit.shapeProperties?.customPathDataSource = self
         
         let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerLimit.lineColor = NSUIColor.red
         
         lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerLimit.lineDashPhase = 2.0
         lowerLimit.lineDashLengths = [1.0, 2.0]
         
         let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerRightLimit.lineColor = NSUIColor.red
         
         lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerRightLimit.lineDashPhase = 2.0
         lowerRightLimit.lineDashLengths = [1.0, 2.0]
         
         
         //      upperLimit.lineWidth = 6.0
         
         let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
         xLimit.lineColor = NSUIColor.red
         
         xLimit.lineDashPhase = 2.0
         xLimit.lineDashLengths = [1.0, 2.0]
         
         //        lowerLimit.lineWidth = 6.0
         
         scatterChartView?.leftAxis.addLimitLine(upperLimit)
         //            lineChartView?.rightAxis.addLimitLine(lowerLimit)
         //        lineChartView?.xAxis.addLimitLine(xLimit)
         
         
         //        lineChartView?.rightAxis.addLimitLine(lowerRightLimit)*/
        
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: bubbleChartView!,duration:1,animationBlock: animateBlock)
        
//        bubbleChartView?.animate(xAxisDuration: 1.0)
        
        dataBackup.append(bubbleChartView?.data?.copy() as! ChartData)
        chartInstance.append(bubbleChartView!)
        
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = bubbleChartView!
        
        let animateBlock = {
            
            if chart.data == nil
            {
                return
            }
            
            let contentRect = (self.bubbleChartView?.viewPortHandler.contentRect)!
            
            /*for layer in BubbleLayer.getAllBubbleLayer(chart: chart)
            {
                layer.opacity = 1
            }*/
            
            let barEntryAnimator = Animator()
            
            barEntryAnimator.updateBlock = {
                
                for layer in BubbleLayer.getAllBubbleLayer(chart: chart)
                {
                    let radiusInterpolator = Interpolator.interpolate(a: 0, b: layer.bubbleShapeProperty!.size.width)
                    let pointXInterpolator = Interpolator.interpolate(a: contentRect.midX, b: layer.shapePoint!.x)
                    let pointYnterpolator = Interpolator.interpolate(a: contentRect.midY, b: layer.shapePoint!.y)
                    let shapeSize = radiusInterpolator(CGFloat(barEntryAnimator.phaseX))
                    let shapeHalf = shapeSize / 2.0
                    let pointX = pointXInterpolator(CGFloat(barEntryAnimator.phaseX))
                    let pointY = pointYnterpolator(CGFloat(barEntryAnimator.phaseX))
                   
                    let circlePath = UIBezierPath(arcCenter: CGPoint(x: pointX,y: pointY), radius: shapeHalf, startAngle: CGFloat(0), endAngle:CGFloat.pi * 2,  clockwise: true)
                    layer.path = circlePath.cgPath
                    layer.opacity = 1
                }
                
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*func getData() -> [String:Any] {
        let data : [String:Any] = [
                 "name" : "A1",
                 "children": [
                   [
                     "name" : "B1",
                     "children": [
                       [
                         "name" : "C1",
                          "value" : 300
                       ],
                       [
                         "name" : "C2",
                         "children": [
                           [
                             "name" : "E1",
                             "value": 100
                           ],
                           [
                             "name" : "E2",
                             "value" : 300
                           ],
                           [
                             "name" : "E3",
                             "value" : 200
                           ]
                         ]
                         
                       ],
                       [
                         "name" : "C3",
                         "value" : 200
                       ]
                     ]
                   ],
                   [
                     "name" : "B2",
                     "children": [
                       [
                         "name" : "D1",
                         "value": 100
                       ],
                       [
                         "name" : "D2",
                         "children": [
                           [
                             "name" : "E1",
                             "value": 100
                           ],
                           [
                             "name" : "E2",
                             "value" : 300
                           ],
                           [
                             "name" : "E3",
                             "value" : 200
                           ]
                         ]
                       ],
                       [
                         "name" : "D3",
                         "value" : 200
                       ]
                     ]
                   ]
                 ]
               ]
        
        for dict in data
        {
            ChartDataEntry(xString: dict["name"], y: 0, data: nil)
        }
        return data
    }*/
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /*     level += 1
         
         scatterChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         
         scatterChartView?.chartActionListener = self
         
         scatterChartView?._tapEventListener?.handler = LineHighlightHandler()
         
         scatterChartView?._panEventListener?.handler = LinePanHandler()
         
         scatterChartView?._longPressEventListener?.handler = LineLongPressHandler()
         
         scatterChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
         
         scatterChartView?.rightAxis.enabled = false
         
         scatterChartView?.leftAxis.drawGridLinesEnabled = false
         
         scatterChartView?.xAxis.labelPosition = .bottom
         
         scatterChartView?.leftAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.drawGridLinesEnabled = false
         
         scatterChartView?.chartDescription?.enabled = false
         
         scatterChartView?.xAxis.granularity = 1.0
         //        lineChartView?.xAxis.granularityEnabled = true
         
         //        let count = 2000+50
         let count = 12
         let range = 54
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = false
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1, set2,set3])
         chartData.setDrawValues(false)
         
         
         scatterChartView?.data = chartData
         
         //lineChartView?.xAxis.spaceMax = 0.5
         scatterChartView?.xAxis.spaceMin = 0.9
         
         
         
         scatterChartView?.animate(xAxisDuration: 1.0)
         
         dataBackup.append(scatterChartView?.data?.copy() as! ChartData)
         chartInstance.append(scatterChartView!)*/
        
    }
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {
        
        /* if true     //velocity > 1  //&& (Int(end)!-Int(start)!) == 1
         {
         //            level += 1
         //
         //        lineChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         //
         //        lineChartView?.chartActionListener = self
         //
         //        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
         //
         //        lineChartView?._panEventListener?.handler = LinePanHandler()
         //
         //        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
         //
         //        lineChartView?.rightAxis.enabled = false
         //
         //        lineChartView?.leftAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.xAxis.labelPosition = .bottom
         //
         //        lineChartView?.leftAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.chartDescription?.enabled = false
         //
         //        lineChartView?.xAxis.granularity = 1.0
         //        //        lineChartView?.xAxis.granularityEnabled = true
         //
         //        //        let count = 2000+50
         let count = 12
         let range = 150
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i%12] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i%12] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i%12] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = true
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1])
         chartData.setDrawValues(false)
         
         
         chartView.data = chartData
         
         
         
         
         //        //lineChartView?.xAxis.spaceMax = 0.5
         //        lineChartView?.xAxis.spaceMin = 0.9
         //
         //
         //
         //        lineChartView?.animate(xAxisDuration: 1.0)
         
         //            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
         //            chartInstance.append(lineChartView!)
         }
         else if velocity < -3  //&& Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
         {
         if level > 0
         {
         level = level-1
         
         let chart = chartInstance[level]
         
         scatterChartView = chart as! LineChartView
         
         chart.data = dataBackup[level].copy() as! ChartData
         
         dataBackup.removeLast(dataBackup.count-1 - level)
         
         chartInstance.removeLast(chartInstance.count-1 - level)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 1.0)
         }
         }*/
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}





