//
//  HorizontalMultiStackedBarViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 23/02/22.
//  Copyright © 2022 charts. All rights reserved.
//

import UIKit

import zchart

class HorizontalMultiStackedBarViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource  {
    
    func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> UIBezierPath {
        
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return [] }
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
        
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String((dataSet?.entryForIndex(selectedIndex!)?.y)!))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! ChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
  
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = HorizontalStackedBarPanHandler()
        
        //        barChartView?.longPressEventListener?.handler = HorizontalBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        
        
        barChartView?.xAxis.axisTitle = "Items"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        
        barChartView?.xAxis.axisTitleEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitleEnabled = true
        
        
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        barChartView?.xAxis.scaleType = .Ordinal
        
        
//        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        
        //        barChartView?.xAxis.xOffset = 50
        
        //        barChartView?.leftAxis.yOffset  = 10
        //
        //        barChartView?.rightAxis.yOffset = 50
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        //        let count = 170
        totalSales = 0
        
        let count = 30
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val2), data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
            
            
            totalSales += CGFloat(val1)
            
            
            
            //            if i==10
            //            {
            //                dataEntries1.append(ChartDataEntry(xString: "Zero Value", y: Double(0), data: nil))
            //            }
            
        }
        
       /* let gradient1 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[0]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[1]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        let gradient3 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        let gradient4 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[3]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        let gradient5 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[4]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        let gradient6 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[5]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        */
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[5]]
        set2.label = "Company B"
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
//        set2.gradients = [gradient6]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[1]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
//        set3.gradients = [gradient2]
        
        let chartData = ChartData(dataSets: [set1, set2, set3])
        
        chartData.datasetsGroupArray = [[1],[0,2]]
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.groupSpacePixel = 20
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 100
        
        barPlotOptions.fitBars = true
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        //        chartData.highlightColor = UIColor.green
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        
        
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 30
        
        barChartView?.scaleYEnabled = false
        barChartView?.scaleXEnabled = false
        
        barChartView?.xAxis.inverted = false
        
        //        barChartView?.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //                barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 1.0)
        CommonUtilities.customAnimation(chart: barChartView!, duration: 1, animationBlock: animateBlock)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        //        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        //        upperLimit.lineColor = NSUIColor.green
        //        //        upperLimit.lineWidth = 6.0
        
        let upperLimit = ChartLimitLine(limit: 20, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.black
        upperLimit.shapeProperties = ShapeProperties()
        
        upperLimit.limitValueTextColor = UIColor.white
        upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit.shapeProperties?.holeColor = UIColor.white
        upperLimit.shapeProperties?.shapeType = .custom
        upperLimit.shapeProperties?.size = CGSize(width: 8.0, height: 8.0)
        upperLimit.shapeProperties?.lineWidth = 2
        upperLimit.shapeProperties?.customPathDataSource = self
        
        let lowerLimit = ChartLimitLine(limit: 10, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        
        //        lowerLimit.lineWidth = 6.0
        
        //                barChartView?.leftAxis.addLimitLine(upperLimit)
        //                barChartView?.rightAxis.addLimitLine(lowerLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
    }
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomHorizontalBarPanHandler()
        
        //barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.axisTitleEnabled = false
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        //        let count = 170
        let count = 170
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            // dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.minimumBarPixel = 18
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        
        
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 25
        
        // barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        
        //        barChartView?.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //                barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //        upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
       
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


