//
//  SankeyViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 15/09/22.
//  Copyright © 2022 charts. All rights reserved.
//

import UIKit
import zchart

class SankeyViewController: UIViewController,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate {

    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        if !(lineChartView?.datasetSelected)!
        {
        
            let allEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: lineChartView!)

        for i in 0..<(allEntries.count)
        {
            let entry = allEntries[i]
            let set = lineChartView?.data?.getDataSetForEntry(entry)
            
            if (set?.isVisible)!
            {
            let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            }
        }
        }
        else{
            if lineChartView?.lastSelectedHigh == nil{
            let set = lineChartView?.data?.getDataSetForEntry(entry)
                if (set?.isVisible)!
                {
                    for i in 0..<(set?.entryCount)!
                    {
                        let entry = set?.entryForIndex(i)
                        let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
                        toolTipEntry.valueTextColor = (set?.colors[0])!
                        
                        entries.append(toolTipEntry)
                    }
                }
            }
            else{
                
                let set = lineChartView?.data?.getDataSetForEntry(entry)
                if (set?.isVisible)!
                {
                    let toolTipEntry = ToolTipEntry(label: String(describing: entry?.x), value: String(describing: entry?.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
                }
            }
        }
  
        
        return entries
    }
    
    let offSet = 10.0
    var labelFont = NSUIFont.systemFont(ofSize: 10.0)
    var labelColor = NSUIColor.gray.withAlphaComponent(0.9)
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        
        containerView?.tooltip.tooltipEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addLineChart()
    }
    
    
    
    var lineChartView:ChartViewBase? = nil
    
    func readStringDataFromJson() -> [String: AnyObject]
    {
        let finalData:[String: AnyObject] = [:]
        
        if let urlPath = Bundle.main.url(forResource: "sankey", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                        return jsonDict
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    func addLineChart()
    {
        lineChartView = containerView?.chart
        
//        lineChartView?.extraTopOffset = 100
        
        lineChartView?.tapEventListener?.handler = SankeyHighlightHandler()
        
        lineChartView?.panEventListener?.handler = DefaultPanHandler()
        
        lineChartView?.pinchEventListener?.handler = DefaultPinchHandler()
        
        lineChartView?.rendererDelegate = self
        
        lineChartView?.xAxis.scaleType = .Ordinal
        
        lineChartView?.getYAxis(atIndex: 0)?.scaleType = .Ordinal
//
//        lineChartView?.panEventListener?.handler = LineFilterHandler() //LinePanFilterHandler() // LinePanHandler()
//
//        lineChartView?.longPressEventListener?.handler = LineLongPressHandler()
//
//        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
//        lineChartView?.setScaleMinima(2.0, scaleY: 1.0)
        
        var dataEntries1: [ChartDataEntry] = []
        
        let dataToLoad = readStringDataFromJson()
        
        for link in dataToLoad["data"] as! [[AnyObject]]
        {
            let source = link[0] as? String
            let target = link[1] as? String
            let value = link[2] as? CGFloat
            
            dataEntries1.append(ChartDataEntry(xString: source, yString: target, size: value!, data: nil))

        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        
        var newColorArray:[NSUIColor] = []
        newColorArray.append(contentsOf: ChartColorTemplates.joyful())
        newColorArray.append(contentsOf: ChartColorTemplates.colorful())
        
        set1.colors = newColorArray
        set1.plotType = .Sanky

        let chartData = ChartData(dataSets: [set1])
        chartData.setDrawValues(true)
        
        chartData.skipDataValuesEnabled = false

        lineChartView?.data = chartData

        guard let sankeyPlotOptions = (lineChartView?.getPlotOptions(type: .Sanky) as? SankeyPlotOptions)
        else { return }
        
        sankeyPlotOptions.outerPadding = 10
        
        sankeyPlotOptions.minNodeWidth = 18
        sankeyPlotOptions.maxNodeWidth = 100
        
        sankeyPlotOptions.nodeWidthInterpolateStartPercent = 20
        sankeyPlotOptions.nodeWidthInterpolateEndPercent = 70

        sankeyPlotOptions.nodePadding = 10
        sankeyPlotOptions.nodeAlign = .justify
        sankeyPlotOptions.linkOpacity = 0.4
        sankeyPlotOptions.linkPadding = 5
//        sankeyPlotOptions.drawDataLabelCenteredEnabled = true
        
//        sankeyPlotOptions.dataValuesTrancateMode = .end
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var initialAnimationAllowed = true
    func chartBufferLoadedBeforeDraw(chartView: ChartViewBase) -> Bool {
        
        if initialAnimationAllowed
        {
            let animateBlock = getAnimationBlock(chartView: lineChartView!, duration: 1.0)

            CommonUtilities.customAnimation(chart: lineChartView!,duration:1.0,animationBlock: animateBlock)
            
            initialAnimationAllowed = false
        }
        return true
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {}
    
    func performPathAnimation(targetLayer:ChartEntryLayer,newPath:UIBezierPath,duration:TimeInterval, delay:TimeInterval)
    {
        
        let anim = CABasicAnimation(keyPath: "path")
        
        anim.fromValue = targetLayer.path
        
        anim.toValue = newPath.cgPath
        
        anim.duration = duration
        
        anim.timingFunction =  CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        anim.beginTime = delay
        
        anim.fillMode = .forwards
        anim.isRemovedOnCompletion = false
        
        targetLayer.add(anim, forKey: "path")
    }
    
    func performOpacityAnimation(targetLayer:ChartEntryLayer,duration:TimeInterval, delay:TimeInterval)
    {
        
        let anim = CABasicAnimation(keyPath: "opacity")
        
        anim.fromValue = 0
        
        anim.toValue = 1
        
        anim.duration = duration
        
        anim.timingFunction =  CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        anim.beginTime = delay
        
        anim.fillMode = .forwards
        anim.isRemovedOnCompletion = false
        
        targetLayer.add(anim, forKey: "opacity")
    }
    
    func getAnimationBlock(chartView: ChartViewBase, duration:TimeInterval) -> (() -> Void)
        {
            let animateBlock = {
                
                if chartView.data == nil
                {
                    return
                }

                let linkLayers = SankyLayers.getAllSankeyLayer(chart: chartView)
                
                var categorisedLayers:[Double:[SankyLayers]] = [:]
                let categorisedNodeLayers:[Double:[SankyLayers]] = SankeyHelperFunctions.getCategorisedNodeByX(chartview: chartView)
                
                for link in linkLayers
                {
                    let leftPoint = link.rectPoints[.topLeft]?.x ?? link.path?.currentPoint.x
                    
                    if leftPoint != nil {
                        if categorisedLayers[leftPoint!] == nil
                        {
                            categorisedLayers[leftPoint!] = [link]
                        }
                        else{
                            categorisedLayers[leftPoint!]?.append(link)
                        }
                    }
                }
                
                let sortedKeys = categorisedLayers.keys.sorted()
                
                let sortedNodekeys = categorisedNodeLayers.keys.sorted()
                
                let linkDurationInterval = duration*0.9/Double(abs(categorisedLayers.keys.count - categorisedNodeLayers.keys.count))
                let nodeDurationInterval = duration*0.1/Double(categorisedNodeLayers.keys.count)
                
                var addValue = Double(0)
                
                let currentTime = CACurrentMediaTime()
                
                for keyValue in sortedKeys
                {
                    let linkLayersX = categorisedLayers[keyValue]!
                    
                    var type:SankyLayerType = .Node
                    
                    for selectedLayer in linkLayersX
                    {
                        let rectPoints = selectedLayer.rectPoints
                        if selectedLayer.type == .Node
                        {
                            let duration = nodeDurationInterval
                            
                            let bound = selectedLayer.path!.boundingBox
                            
//                            guard let minX = rectPoints[.topLeft]?.x,
//                                  let minY = rectPoints[.topLeft]?.y,
//                                  let maxX = rectPoints[.topRight]?.x,
//                                  let maxY = rectPoints[.bottomRight]?.y
//                            else { return }
                            let minX = bound.minX
                            let minY = bound.minY
                            let maxX = bound.maxX
                            let maxY = bound.maxY
                            

                            let width = maxX - minX
                            let height = maxY - minY

                            let fromPath = CGMutablePath(rect: CGRect(x: minX, y: minY, width: 0, height: height), transform: nil)
                            selectedLayer.path = fromPath
                            selectedLayer.opacity = 1
                            let newPath = CGMutablePath(rect: CGRect(x: minX, y: minY, width: width, height: height), transform: nil)

                            self.performPathAnimation(targetLayer: selectedLayer, newPath: UIBezierPath(cgPath: newPath), duration: duration, delay: currentTime + addValue)
                            continue
                            
                        }
                        
                        type = .Link
                        
                        let sourceNode = SankeyHelperFunctions.getNodeLayerForNodeName(layers: SankyLayers.getAllNodeLayer(chart: chartView), nodeName: selectedLayer.chartEntry?.xString ?? "")
                        
                        let tragetNode = SankeyHelperFunctions.getNodeLayerForNodeName(layers: SankyLayers.getAllNodeLayer(chart: chartView), nodeName: selectedLayer.chartEntry?.yString ?? "")
                        
                        var nodeCount = 1
                        
                        if let startX = sourceNode?.rectPoints[.topLeft]?.x, let endX = tragetNode?.rectPoints[.topLeft]?.x {
                            
                            let startIndex = sortedNodekeys.firstIndex(where: { $0 == startX}) ?? 1
                            
                            let endIndex = sortedNodekeys.firstIndex(where: { $0 == endX}) ?? 2
                            
                            nodeCount = abs(endIndex - startIndex)
                        }
                        
                        let duration = linkDurationInterval * Double(nodeCount)
                        
                        let (path,lineWidth) = SankeyHelperFunctions.linkStokePathFor(sankeyLayer: selectedLayer, chart: chartView)
                        
                        let maskLayer = CAShapeLayer()//selectedLayer.maskLayer
                        maskLayer.path = path
                        maskLayer.strokeEnd = 0
                        maskLayer.strokeColor =  UIColor.white.cgColor
                        maskLayer.fillColor = UIColor.clear.cgColor
                        maskLayer.lineWidth = lineWidth
                        selectedLayer.mask = maskLayer
                        selectedLayer.opacity = 1
                        
                        
                        let animation = CABasicAnimation(keyPath: "strokeEnd")
                        animation.fromValue = 0
                        animation.toValue = 1
                        animation.duration = duration * 0.8
                        animation.beginTime = currentTime + addValue
                        animation.timingFunction = CAMediaTimingFunction(name: .linear)
                        animation.fillMode = .forwards
                        animation.isRemovedOnCompletion = false
                        
                        maskLayer.add(animation, forKey: "strokeEndAnimation")
                        
                    }
                    
                    addValue = type == .Link ? (addValue + linkDurationInterval*0.8) : (addValue + nodeDurationInterval*0.8)
                }
                return
            }
            
            return animateBlock
        }
}

extension SankeyViewController: RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        ExtraLayer.removeExtraLayer(chart: chartView)
        
        let xValArr:[Double] = SankeyHelperFunctions.getCategorisedNodeByX(chartview: chartView).keys.sorted()
        
        let sankeyLayers = SankyLayers.getAllSankeyLayer(chart: chartView)
        
        if sankeyLayers.count == 3
        {
            for node in sankeyLayers
            {
                let bound = node.path!.boundingBox
                
                let width =  bound.width
                let height = (bound.height)*0.25
                
                let newPath = CGMutablePath(rect: CGRect(x: bound.minX, y: (bound.minY+bound.maxY)/2-(height/2), width: width, height: height), transform: nil)
                
                node.path = newPath
                
            }
        }
        
        var prevTextLayer: CALayer?
        
        for xVal in xValArr {
            
            let text = "stage"+String(xVal)
            
            let position = CGPoint(x: xVal, y: chartView.contentRect.origin.y - offSet - labelFont.lineHeight / 2.0)
            
            let labelAttrs = [NSAttributedString.Key.font: labelFont,
                              NSAttributedString.Key.foregroundColor: labelColor ]
            
            let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .right, attributes: labelAttrs)
            
            if prevTextLayer == nil || !prevTextLayer!.frame.intersects(textLayer.frame) {
                
                prevTextLayer = textLayer
                
                let extraLayer = ExtraLayer()
                
                extraLayer.addSublayer(textLayer)
                
                chartView.layer.addSublayer(extraLayer)
            }
        }
    }
}

