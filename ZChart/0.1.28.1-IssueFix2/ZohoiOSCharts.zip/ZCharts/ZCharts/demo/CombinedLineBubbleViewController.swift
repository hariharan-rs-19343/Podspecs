//
//  CombinedLineBubbleViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 12/09/19.
//  Copyright © 2019 charts. All rights reserved.
//


import UIKit
import  zchart

class CombinedLineBubbleViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator, RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
       let textLayers = ChartViewBase.getAllTextLayer(chartView: chartView)
        let sortedLayers = textLayers.sorted(by: { $0.frame.origin.x < $1.frame.origin.x })
        for textLayer in sortedLayers {
            if (!isInBound(frame: textLayer.frame, chart: chartView)) {
                updateFrame(textLayer: textLayer, chart: chartView)
            }
        }
        reorder(textLayers: sortedLayers, chartView: chartView)
    }
    
    func updateFrame(textLayer:CATextLayer, chart:ChartViewBase) {
        
        guard let viewPortHandler = chart.viewPortHandler else {
            return
        }
        
        let contentRect = viewPortHandler.contentRect
        let frame = textLayer.frame
                        
        if (!viewPortHandler.isInBoundsLeft(frame.origin.x))
        {
            textLayer.frame.origin.x = contentRect.origin.x + frame.width / 4
        }
        
        if (!viewPortHandler.isInBoundsRight((frame.origin.x + frame.size.width)))
        {
            let distance = abs((frame.origin.x + frame.size.width) -  viewPortHandler.contentRight)
            textLayer.frame.origin.x = textLayer.frame.origin.x - distance
        }
        
        if (!viewPortHandler.isInBoundsTop(frame.origin.y))
        {
            textLayer.frame.origin.y = contentRect.origin.y + frame.height / 4
        }
        
        if (!viewPortHandler.isInBoundsBottom((frame.origin.y + frame.size.height)))
        {
            let distance = 3 * abs((frame.origin.y + frame.size.height) -  viewPortHandler.contentBottom)
            textLayer.frame.origin.y = textLayer.frame.origin.y - distance
        }
    }
    
    
    func isInBound(frame:CGRect, chart:ChartViewBase) -> Bool {
        let viewPortHandler = chart.viewPortHandler!
        
        return viewPortHandler.isInBoundsLeft(frame.origin.x) && viewPortHandler.isInBoundsRight(frame.origin.x + frame.width) && viewPortHandler.isInBoundsTop(frame.origin.y) && viewPortHandler.isInBoundsBottom(frame.origin.y + frame.height)
        
    }
    
   /* func reorder(textLayers:[CATextLayer], chartView:ChartViewBase)
    {
        var visitedIndex:Int = 0
        
        for currentIndex in stride(from: 1, to: textLayers.count, by: 1)
        {
            let textLayer = textLayers[currentIndex]
            if (!isInChartXBound(frame: textLayer.frame, chart: chartView)) {
                textLayer.removeFromSuperlayer()
                continue
            }
            
            let overLap = checkOverlap(frame: textLayer.frame, prevIndex: visitedIndex, layers: textLayers)
            let yBound = isInChartYBound(frame: textLayer.frame, chart: chartView)
            
            if !overLap && yBound {
                continue
            }
            
            let upFrame = getNewFrame(frame: textLayer.frame, up: true, count: 1)
            let downFrame = getNewFrame(frame: textLayer.frame, up: false, count: 1)
            
            let upOverLap = checkOverlap(frame: upFrame, prevIndex: visitedIndex, layers: textLayers)
            let downOverLap = checkOverlap(frame: downFrame, prevIndex: visitedIndex, layers: textLayers)
            
            if (upOverLap && downOverLap)
            {
                textLayer.removeFromSuperlayer()
                continue
            }
            
            if (!upOverLap && isInChartYBound(frame: upFrame, chart: chartView) )
            {
                textLayer.frame = upFrame
                visitedIndex = currentIndex
                continue
            }
            
            if (!downOverLap && isInChartYBound(frame: downFrame, chart: chartView) )
            {
                visitedIndex = currentIndex
                textLayer.frame = downFrame
            }
            
        }
    }*/
    
    func reorder(textLayers:[CATextLayer], chartView:ChartViewBase)
    {
        var visitedIndex:Int = 0
        
        var removedIndexes:[Int] = []
        
        for currentIndex in stride(from: 1, to: textLayers.count, by: 1)
        {
            let textLayer = textLayers[currentIndex]
            
            let overLap = checkOverlap(frame: textLayer.frame, prevIndex: visitedIndex, layers: textLayers, toBeRemoved: removedIndexes)
            
            if (overLap) {
                removedIndexes.append(currentIndex)
            }
            
            visitedIndex = currentIndex
        }
        
        for index in removedIndexes {
            textLayers[index].removeFromSuperlayer()
        }
    }
    
    func getNewFrame(frame:CGRect, up:Bool, count:Int) -> CGRect {
        let shiftVal = up ?  -frame.size.height / 2 : frame.size.height / 2
        return CGRect(x: frame.origin.x, y: frame.origin.y + CGFloat(count) * shiftVal, width: frame.width, height: frame.height)
    }
    
    func checkOverlap(frame:CGRect, prevIndex:Int, layers:[CATextLayer]) -> Bool
    {
        for index in stride(from: 0, to: prevIndex + 1, by: 1)
        {
            if isRectOverlappedWithPrevious(frame: frame, prevFrame: layers[index].frame)
            {
                return true
            }
        }
        return false
    }
    
    func checkOverlap(frame:CGRect, prevIndex:Int, layers:[CATextLayer], toBeRemoved:[Int]) -> Bool
    {
        for index in stride(from: 0, to: prevIndex + 1, by: 1) where !toBeRemoved.contains(index)
        {
            if isRectOverlappedWithPrevious(frame: frame, prevFrame: layers[index].frame)
            {
                return true
            }
        }
        return false
    }
    
    
    var r1:CGPoint = .zero
    var r2:CGPoint = .zero
    
    func isRectOverlappedWithPrevious(frame:CGRect, prevFrame:CGRect) -> Bool {
        
        r1.x = 0
        r1.y = 0
        r2.x = 0
        r2.y = 0
        
        let l1 = prevFrame.origin
        r1.x = l1.x + prevFrame.width
        r1.y = l1.y + prevFrame.height
        
        let l2 = frame.origin
        r2.x = l2.x + frame.width
        r2.y = l2.y + frame.height
        return isRectPointsOverlap(l1: l1, r1: r1, l2: l2, r2: r2)
    }
    
    func isRectPointsOverlap(l1:CGPoint, r1:CGPoint, l2:CGPoint, r2:CGPoint) -> Bool {
             
        if (l1.x == r1.x || l1.y == r1.y || l2.x == r2.x || l2.y == r2.y) {
            return false
        }
        if (l1.x >= r2.x || l2.x >= r1.x) {
            return false
        }
        if (l1.y >= r2.y || l2.y >= r1.y){
            return false
        }
        return true
    }
    
//    bool doOverlap(Point l1, Point r1, Point l2, Point r2)
//    {
//
//        // To check if either rectangle is actually a line
//        // For example :  l1 ={-1,0}  r1={1,1}  l2={0,-1}
//        // r2={0,1}
//
//        if (l1.x == r1.x || l1.y == r1.y || l2.x == r2.x
//            || l2.y == r2.y) {
//            // the line cannot have positive overlap
//            return false;
//        }
//
//        // If one rectangle is on left side of other
//        if (l1.x >= r2.x || l2.x >= r1.x)
//            return false;
//
//        // If one rectangle is above other
//        if (l1.y >= r2.y || l2.y >= r1.y)
//            return false;
//
//        return true;
//    }
    
    func isInChartXBound(frame:CGRect, chart:ChartViewBase) -> Bool {
        let viewPortHandler = chart.viewPortHandler!
        return viewPortHandler.isInBoundsLeft(frame.origin.x) && viewPortHandler.isInBoundsRight(frame.origin.x + frame.width)
    }
    
    func isInChartYBound(frame:CGRect, chart:ChartViewBase) -> Bool {
        let viewPortHandler = chart.viewPortHandler!
        return viewPortHandler.isInBoundsTop(frame.origin.y) && viewPortHandler.isInBoundsBottom(frame.origin.y + frame.height)
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry!
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
    }
    
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        //               containerView?.legend.legendEnabled = false
        //               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        barChartView?.rendererDelegate = self
        barChartView?.plotDelegate = self
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BubbleHighlightHandler()//  BarHighlightHandler()
        //
        barChartView?.panEventListener?.handler = DefaultPanHandler()
        //
        //        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = DefaultPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 10
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        //        barChartView?.rightAxis.enabled = true
        
//        barChartView?.xAxis.wordWrapEnabled = false
        
        //  barChartView?.xAxis.autoRotateAngle = 90
        
        //  barChartView?.xAxis.autoRotateEnabled = false
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        //        barChartView?.xAxis.scaleType = .Ordinal
        
//        barChartView?.xAxis.maxLabelWidth = barChartView!.xAxis.labelWidth
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.getYAxis(atIndex: 1)!.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 1)!.valueFormatter = ValueFormatter(chart: barChartView!)
        
        //        barChartView?.leftAxis.baseLineEnabled = true
        //        barChartView?.leftAxis.baseLine?.baseValue = 400
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//
        
        totalSales = 0
        
        
        var dataSets:[ChartDataSet] = []
        
        for set in getBubbleDataSets()
        {
            dataSets.append(set)
        }
        
        
        
        
        for set in getLineDataSets()
        {
            dataSets.append(set)
        }
        
        
//        barChartView?.scalePreference = .Bubble
        
        barChartView?.data = ChartData(dataSets: dataSets)
        
        let bubblePlotOptions = barChartView?.getPlotOptions(type: .Bubble) as! BubblePlotOptions
        bubblePlotOptions.minimumShapeSizeInPixel = 8
        bubblePlotOptions.maximumShapeSizeInPixel = 30
        
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        //        barChartView?.barCount = 12
        
        //*****************************  MinMax and Colors  *******************************//
        
        
        //        chartData.highlightColor = UIColor.blue
        
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //                barChartView?.leftAxis.addLimitLine(upperLimit)
        //                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
            dataBackup.append(barChartView?.data?.copy() as! ChartData)
            chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
    }
    
    
    
    func getLineDataSets() -> [ChartDataSet]
    {
        let count = 50
        let range:UInt32 = 2054
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            let lab = String((i+2000))
            
            let xVal = Double(i + 2000)
            
            var val1 = arc4random_uniform(UInt32(range)) + 3
            
            //            dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data:  nil))
            
            dataEntries1.append(ChartDataEntry(x: xVal, y: Double(val1), data: nil))
            
            
            
            //     dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            let val2 = arc4random_uniform(UInt32(range)) + (3 + range)
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val2), data:  nil))
            
            //            dataEntries2.append(ChartDataEntry(xString: Double(i), y: Double(val2), data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            let val3 = arc4random_uniform(UInt32(range)) + (3 + range * 2)
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data:  nil))
            
            //            dataEntries3.append(ChartDataEntry(xString: Double(i), y: Double(val3), data: nil))
            //            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
        }
        
        
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[5])
        set1.plotType = .Line
        //        set1.axisDependency = .right
        
        let dataOptions1 = set1.dataSetOptions as! LineDataSetOptions
        let shape = dataOptions1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        dataOptions1.setShapeColor(UIColor.red)
        
        dataOptions1.lineWidth = 1
        dataOptions1.drawShapeEnabled = false
        
        dataOptions1.drawFilledEnabled = true
        dataOptions1.fillAlpha = 0.3
        dataOptions1.fillColor = ChartColorTemplates.pieColor()[5]
        dataOptions1.mode = .linear
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Line
        
        let dataOptions2 = set2.dataSetOptions as! LineDataSetOptions
        let shape1 = dataOptions2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        dataOptions2.setShapeColor(UIColor.brown)
        
        dataOptions2.lineWidth = 0.5
        dataOptions2.drawShapeEnabled = false
        
        dataOptions2.drawFilledEnabled = true
        dataOptions2.fillAlpha = 0.3
        dataOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        dataOptions2.mode = .cubicBezier
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Line
        
        let dataOptions3 = set3.dataSetOptions as! LineDataSetOptions
        dataOptions3.setCircleColor(UIColor.black)
        dataOptions3.lineWidth = 0.5
        dataOptions3.circleRadius = 3.0
        dataOptions3.drawCircleHoleEnabled = false
        dataOptions3.drawCirclesEnabled = true
        dataOptions3.drawShapeEnabled = false
        
        dataOptions3.drawFilledEnabled = true
        dataOptions3.fillAlpha = 0.3
        dataOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        dataOptions3.mode = .cubicBezier
        
        
        
        
        
        //        chartData.isStacked = true
        
        return [set1]
    }
    
    func getBubbleDataSets() -> [ChartDataSet]
    {
        let count = 50
        let range = 100
        
        var dataEntries1: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            // x - number , y - ordinal
            
            let size = arc4random_uniform(UInt32(range)) + 3
            
            let newnum = Double(i + 2000)
            var lab = "Item " + String( (arc4random_uniform(UInt32(range)) % 5 ) )
            let yVal = Double(arc4random_uniform(UInt32(2054)) + 3)

//            dataEntries1.append(ChartDataEntry(x: newnum, yString: lab, size: CGFloat(size), data: lab as AnyObject))
            dataEntries1.append(ChartDataEntry(x: newnum, y: yVal, size: CGFloat(size), data: lab as AnyObject))
            
            
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[2])
        set1.plotType = .Bubble
        set1.axisIndex = 0
        
        let dataOptions = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOptions.shapeProperties
        shape.holeColor = ChartColorTemplates.pieColor()[2]
        shape.shapeType = .circle
        shape.lineWidth = 2
        
        
//        chartData.setDrawValues(false)
        
        
        
        return [set1]
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /* let chart = chartInstance[index]
         
         level = index
         
         barChartView = chart as! BarChartView
         
         chart.data = dataBackup[index].copy() as! ChartData
         
         chart.notifyDataSetChanged()
         
         dataBackup.removeLast(dataBackup.count-1 - index)
         
         chartInstance.removeLast(chartInstance.count-1 - index)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)*/
        
    }
    var orientationFlag = true

}

extension CombinedLineBubbleViewController: PlotDelegate {

// MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }

        return themeImage
    }

    func addChartOrientationSwapButton(){

        let orientationSwapButton = UIButton(type: .custom)

        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)

        orientationSwapButton.setImage(buttonImage(), for: .normal)

        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)

        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true

        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true

        self.navigationItem.rightBarButtonItem = buttonItem
    }

    @objc func chartOrientationSwap(){

        if !orientationFlag{
            
            barChartView?.isRotated = false
            
            orientationFlag = true
        }
        else{
            
            barChartView?.isRotated = true
            
//            barChartView?.xAxis.labelPosition = .bottom
            
            orientationFlag = false
        }

        barChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
    }
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        
        if let plotOptions = (plotOption as? BubblePlotOptions) {
            plotOptions.minimumShapeSizeInPixel = 8
            plotOptions.maximumShapeSizeInPixel = 30
        }
    }
}
