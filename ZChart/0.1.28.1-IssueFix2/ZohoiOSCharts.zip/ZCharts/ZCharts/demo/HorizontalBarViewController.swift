//
//  HorizontalBarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 19/12/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class HorizontalBarViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, CustomTicksDelegate  {
    
    func getTickSizeforEntry(axis: AxisBase, value: Double, chart: ChartViewBase) -> CGSize {
        
        let position = CGPoint(x: 0, y: 0)
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        
        var size = textLayer.frame.size
        
        let imageSize = CGSize(width:30, height: max(30,textLayer.frame.height) )
        
        size.width += imageSize.width
        size.height = max(size.height,imageSize.height)
        
        return size
    }
    
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text: String, chart: ChartViewBase) -> TickLayer {
        
        var size = size
        
        
        let tickLayer = TickLayer()
        
        
        
        var position = CGPoint(x: position.x+size.width/2, y: position.y)
        
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textSize = text.size(withAttributes: labelAttrs)
        
        let textPosition = CGPoint(x: position.x - textSize.width/2, y: position.y-textSize.height/2)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: textPosition, align: .center, attributes: labelAttrs)
        tickLayer.addSublayer(textLayer)
        
        position.x -= textLayer.frame.width
        size.width -= textLayer.frame.width
        
        let imageLayer = CALayer()
        imageLayer.backgroundColor = UIColor.clear.cgColor
        imageLayer.bounds = CGRect(x: position.x-size.width, y: position.y-size.height/2 , width: size.width, height: size.height)
        imageLayer.position = CGPoint(x: position.x - size.width/2, y: position.y)
        imageLayer.contents = UIImage(named: "usericon")?.cgImage  //UIImage(named:segment.imageName)?.cgImage
        tickLayer.addSublayer(imageLayer)
        
        return tickLayer
    }
    
    func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> UIBezierPath {
        
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry as! ChartDataEntry
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label: label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }

    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = false
        containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        
        Log.info("Drilled..")
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
   
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = DefaultPanHandler()          //CustomHorizontalBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = HorizontalBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        
        
        barChartView?.xAxis.axisTitle = "Items"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        
        barChartView?.xAxis.axisTitleEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitleEnabled = true
        
        barChartView?.xAxis.customTickEnabled = true
        
        barChartView?.xAxis.tickDelegate = self
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        barChartView?.xAxis.scaleType = .Ordinal
        
//        barChartView?.leftAxis.baseLineEnabled = true
//        barChartView?.leftAxis.baseLine?.baseValue = 30
        
//        barChartView?.xAxis.xOffset = 50
        
//        barChartView?.leftAxis.yOffset  = 10
//
//        barChartView?.rightAxis.yOffset = 50
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        //        let count = 170
        totalSales = 0
        
        let count = 131
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
      
//            if i==7
//            {
//                dataEntries1.append(ChartDataEntry(xString: nil, y: val1, data: nil))
//            }
//            else{
//                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//            }
//
//            totalSales += CGFloat(val1)
//
//
//            if i==10
//            {
//                dataEntries1.append(ChartDataEntry(xString: "Zero Value", y: Double(0), data: nil))
//            }
//
//            if i==12
//            {
//                dataEntries1.append(ChartDataEntry(xString: "Nil Value", y: Double.nan, data: nil))
//            }
         
            if i == 15 || (i >= 1 && i < 5)  {
                dataEntries1.append(ChartDataEntry(xString: nil, y: val1, data: nil))
            }else {
                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//                if i == 0
//                {
//                    let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
//                    dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//                }
            }
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            if i == 29
            {
                dataEntries1.append(ChartDataEntry(xString: "last", y: val2, data: nil))
            }
            
//             dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        set1.valueFormatter = BarFormator()
       /* let gradient = LinearGradient(colors: [UIColor.red, UIColor.blue], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        set1.gradients = [gradient] */
        
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        //        chartData.stackSpacing = 25
                
        //        chartData.highlightColor = UIColor.green
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
                
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.drawBarShadowEnabled = true
        
        barPlotOptions.barWidth = 0.7
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 8
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 70
        

        
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 10
        
        barChartView?.scaleYEnabled = true
        barChartView?.scaleXEnabled = false
        
        barChartView?.xAxis.inverted = false
        barChartView?.getYAxis(atIndex: 0)?.drawLabelsEnabled = false
        
       // barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        
        //        barChartView?.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //                barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
//        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
//        upperLimit.lineColor = NSUIColor.green
//        //        upperLimit.lineWidth = 6.0
        
        let upperLimit = ChartLimitLine(limit: 20, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.black
        upperLimit.shapeProperties = ShapeProperties()
        
        upperLimit.limitValueTextColor = UIColor.white
        upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
        
        upperLimit.shapeProperties?.holeColor = UIColor.white
        upperLimit.shapeProperties?.shapeType = .custom
        upperLimit.shapeProperties?.size = CGSize(width: 8.0, height: 8.0)
        upperLimit.shapeProperties?.lineWidth = 2
        upperLimit.shapeProperties?.customPathDataSource = self
        
        let lowerLimit = ChartLimitLine(limit: 10, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        
        //        lowerLimit.lineWidth = 6.0
        
        barChartView?.getYAxis(atIndex: 0)!.addLimitLine(upperLimit)
//                barChartView?.rightAxis.addLimitLine(lowerLimit)
//        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
    }
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomHorizontalBarPanHandler()
        
        //barChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.axisTitleEnabled = false
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        //        let count = 170
        let count = 170
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            /* if i == 3
             {
             continue
             //             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(0)))
             }
             else
             {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             }*/
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            // dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            /*if i%2 == 0 {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
             } else {
             dataEntries1.append(ChartDataEntry(x: Double(i), y: -Double(val1)))
             }*/
            
            
            //dataEntries1.append()
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]        
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
      /*  let gradient = LinearGradient(colors: [UIColor.yellow, UIColor.blue], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0, y: 0.5), end: CGPoint(x: 1, y: 0.5))
        set1.gradients = [gradient] */
        
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
         barChartView?.data = chartData
        
        //        let groupSpace = 0.1;
         //        let barSpace = 0.03;
         //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
         
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.minimumBarPixel = 18
        
        
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 25
        
        // barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        
        //        barChartView?.xAxis.spaceMax = 0.5
        //        barChartView?.xAxis.spaceMin = 0.9
        
        
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //                barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
       
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //        upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        
        chartInstance.append(barChartView!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
