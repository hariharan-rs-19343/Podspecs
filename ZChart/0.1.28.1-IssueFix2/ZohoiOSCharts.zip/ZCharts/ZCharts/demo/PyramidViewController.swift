//
//  PyramidViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 13/02/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import zchart

class PyramidViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry!
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        containerView?.legendView.delegate = nil
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        addBarChart()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        barChartView?.isRotated = true
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = HorizontalStackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.labelRotationAngle = 60
        
        barChartView?.xAxis.tickLabelMode = .auto
        
        barChartView?.xAxis.labelPosition = .top
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.xAxis.drawAxisLineEnabled = false
        barChartView?.xAxis.visible = false
        barChartView?.xAxis.drawLabelsEnabled = false
        barChartView?.xAxis.axisTitleEnabled = false
        barChartView?.getYAxis(atIndex: 0)?.visible = false
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        barChartView?.getYAxis(atIndex: 0)?.inverted = true
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let values: [[Double]] = [[3500,750,750],[2100,792,500],[1210,98,640],[0.0,0.0,0.0,640,660]]
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        var noteEntries: [NoteEntry] = []
        
        var y0 = 0.0
 
        for i in 0..<values.count {
            
            let lab = "W"+String(Double(i+1))
              
            let value = values[i]
            
            var y = value[0] + y0
            var initialY0 = y0
              
            if i < values.count - 1 {
                dataEntries1.append(ChartDataEntry(xString: lab,y: y, y0: y0, data: nil))
                
                y0 = y
                y = value[1] + y0
                
                dataEntries2.append(ChartDataEntry(xString: lab, y: y, y0: y0, data: nil))
                
                y0 = y
                y = value[2] + y0
                
                dataEntries3.append(ChartDataEntry(xString: lab, y: y, y0: y0, data: nil))
            }
            else {
                
                y0 = y
                y = value[3] + y0
                
                dataEntries4.append(ChartDataEntry(xString: lab, y: y, y0: y0, data: nil))
                
                y0 = y
                y = value[4] + y0
                
                dataEntries5.append(ChartDataEntry(xString: lab, y: y, y0: y0, data: nil))
                
            }
            
            if !(values.count - 1 == i) {
                
                var total = abs(y - initialY0)
                
                y0 = (total - values[i+1].reduce(0, {$0 + $1})) / 2.0 + initialY0
                
                print(total,y0,initialY0)
                
                let noteEntry = NoteEntry()
                noteEntry.noteEntryData = dataEntries1[i]
                noteEntry.text = "100 %"
                noteEntries.append(noteEntry)
            }
              
            totalSales += CGFloat(1)
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[1]]
        set1.plotType = .HorizontalBarRange
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[0]]
        set2.plotType = .HorizontalBarRange
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .HorizontalBarRange
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Won")
        set4.colors = [ChartColorTemplates.pieColor()[6]]
        set4.plotType = .HorizontalBarRange
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Lost")
        set5.colors = [ChartColorTemplates.pieColor()[3]]
        set5.plotType = .HorizontalBarRange
        
        let chartData = ChartData(dataSets: [set1,set2,set3,set4,set5])
        
        barChartView?.data = chartData
        
        let notes = Notes(entries: noteEntries)
        
        notes.cusotmNoteEnabled = true
        notes.customNoteDelegate = self
        
        barChartView?.notes = notes
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.fitBars = true
        
        chartData.setDrawValues(true)
        
        barPlotOptions.barWidth = 0.7
        
        barPlotOptions.barWidthPixel = 30
        
        barPlotOptions.barSpacePixel = 50
        
        barPlotOptions.barCount = 12
        
        barPlotOptions.drawValueCenteredEnabled = true
        
        barPlotOptions.stackedSumEnabled = true
        
        barPlotOptions.roundedCorners = true
        
        barPlotOptions.drawValueAboveBarEnabled = false
        
        barPlotOptions.stackSumValueFormatter = Pyramidformator()
        
        barPlotOptions.stackSumValueFont = NSUIFont.systemFont(ofSize: 10.0)
        
//        barPlotOptions.isStacked = true
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        barPlotOptions.minimumBarPixel = 30
        
        barPlotOptions.maximumBarPixel = 30
        
        barPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 0.5)
        
        CommonUtilities.customAnimation(chart: barChartView!, duration: 0.6, animationBlock: animateBlock)
        
        barChartView?.chartDescription?.enabled = false
  
    }
}

extension PyramidViewController: NoteDelegate {
    
    func updateNoteLayer(noteLayer: NoteLayer, noteShape: ShapeProperties) {
        
        var (min,max) = getMinMaXForX(EntryXvalue: 0.0)
        
        guard let chart = barChartView,
              let plotOptions = barChartView?.getPlotOptions(type: .HorizontalBarRange) as? BarPlotOptions,
              let noteEntry = noteLayer.noteEntry,
              let noteEntryData = noteEntry.noteEntryData,
              var midPoint = getMidPointForEntryX(EntryXvalue: 0.0, min: min, max: max, axisIndex: 0)
        else {
            return
        }
        
        midPoint.y = chart.pixelForValues(x: 0.0, y: noteEntryData.x, axisIndex: 0).y
        
        midPoint.y += plotOptions.barWidthPixel / 2.0
        
        min = chart.pixelForValues(x: min, y: 0.0, axisIndex: 0).x
        
        max = chart.pixelForValues(x: max, y: 0.0, axisIndex: 0).x
        
        var totalWidth = min - max
        
        let arrowWidth = totalWidth * 0.3
        
        let height = plotOptions.barSpacePixel
        
        noteLayer.addSublayer(createArrowShape(midPoint: midPoint, arrowSize: CGSize(width: arrowWidth, height: height)))
        
        (min,max) = getMinMaXForX(EntryXvalue: noteEntryData.x)
        
        min = chart.pixelForValues(x: min, y: 0.0, axisIndex: 0).x
        
        max = chart.pixelForValues(x: max, y: 0.0, axisIndex: 0).x
        
        totalWidth = abs(max - min)
        
        let positiveLevelPercentage = 0.6
        
        var originX = midPoint.x - arrowWidth / 2.0
        
        let positiveLevelWidth = (originX - max) * positiveLevelPercentage
        
        let positiveLevelOrigin = CGPoint(x: originX, y: midPoint.y)
        
        noteLayer.addSublayer(createLevelShape(origin: positiveLevelOrigin, totalSize: CGSize(width: positiveLevelWidth, height: height), levelWidthPercentage: 0.2, color: UIColor.green.cgColor,positiveLevel: true))
        
        var textPoint = CGPoint(x: originX, y: midPoint.y + (height * 0.2))
        
        var textLayer = ChartUtils.drawTextLayer(text: "60%", point: textPoint, align: .left, attributes: [NSAttributedString.Key.font: noteEntry.textFont,NSAttributedString.Key.foregroundColor: noteEntry.textColor])
        
        noteLayer.addSublayer(textLayer)
        
        let negativeLevelPercentage = 0.3
        
        originX = midPoint.x + arrowWidth / 2.0

        let negativeLevelWidth = (min - originX) * negativeLevelPercentage

        let negativeLevelOrigin = CGPoint(x: originX, y: midPoint.y)

        noteLayer.addSublayer(createLevelShape(origin: negativeLevelOrigin, totalSize: CGSize(width: negativeLevelWidth, height: height), levelWidthPercentage: 0.2, color: UIColor.red.cgColor, positiveLevel: false))
        
        textPoint.x = originX
        
        textLayer = ChartUtils.drawTextLayer(text: "30%", point: textPoint, align: .right, attributes: [NSAttributedString.Key.font: noteEntry.textFont,NSAttributedString.Key.foregroundColor: noteEntry.textColor])
        
        noteLayer.addSublayer(textLayer)
            
        if noteEntry.text != "" {
                
            let point = CGPoint(x: midPoint.x, y: (midPoint.y + height * 0.2) - noteEntry.textFont.lineHeight / 2.0)
                
            let textLayer = ChartUtils.drawTextLayer(text: noteEntry.text, point: point, align: .center, attributes: [NSAttributedString.Key.font: noteEntry.textFont,NSAttributedString.Key.foregroundColor: noteEntry.textColor])
                
            noteLayer.addSublayer(textLayer)
        }
    }
    
    func getMinMaXForX(EntryXvalue: Double) -> (Double,Double) {
        
        var xMin = Double.greatestFiniteMagnitude
        var xMax = -Double.greatestFiniteMagnitude
        
        guard let barChartView = barChartView,let chartData = barChartView.data else {
            return (xMin,xMax)
        }
        
        for dataset in chartData.dataSets {
            
            guard let firstEntry = dataset.entriesForXValue(EntryXvalue).first else {
                continue
            }
            
            let yMinVal = min(firstEntry.y, firstEntry.y0)
            let yMaxVal = max(firstEntry.y, firstEntry.y0)
                
            if xMin > yMinVal {
                xMin = yMinVal
            }
                
            if xMax < yMaxVal {
                xMax = yMaxVal
            }
        }
        
        return (xMin,xMax)
    }
    
    func getMidPointForEntryX(EntryXvalue: Double, min: Double, max: Double, axisIndex: Int) -> (CGPoint)? {
        
        guard let barChartView = barChartView, !(min == Double.greatestFiniteMagnitude || max == -Double.greatestFiniteMagnitude) else {
            return nil
        }
        
        let xMid = abs(max - min) / 2.0
        
        return barChartView.pixelForValues(x: xMid, y: EntryXvalue, axisIndex: axisIndex)
    }
    
    func createArrowShape(midPoint: CGPoint, arrowSize: CGSize) -> CAShapeLayer{
        
        let ArrowShape = CAShapeLayer()
        
        let arrowSizeHalf = arrowSize.width / 2.0
        
        ArrowShape.path = arrowPath(origin: CGPoint(x: midPoint.x - arrowSizeHalf, y: midPoint.y), size: arrowSize)
        
        if #available(iOS 13.0, *) {
            ArrowShape.fillColor = UIColor.systemGray3.cgColor
        } else {
            ArrowShape.fillColor = UIColor.gray.cgColor
        }
        
        return ArrowShape
    }
    
    func createLevelShape(origin: CGPoint, totalSize: CGSize, levelWidthPercentage: Double, color: CGColor, positiveLevel: Bool) -> CAShapeLayer {
        
        let levelShape = CAShapeLayer()
        
        let levelPath = CGMutablePath()
        
        let levelHeight = totalSize.height * levelWidthPercentage
        
        let hightHalf = levelHeight / 2.0
        
        var arrowMaxXValue = origin.x + totalSize.width
        var xMax = arrowMaxXValue - hightHalf
        
        if positiveLevel {
            arrowMaxXValue = origin.x - totalSize.width
            xMax = arrowMaxXValue + hightHalf
        }
        
        levelPath.move(to: origin)
        
        levelPath.addLine(to: CGPoint(x: xMax, y: origin.y))
        
        levelPath.addLine(to: CGPoint(x: arrowMaxXValue, y: origin.y + hightHalf))
        
        levelPath.addLine(to: CGPoint(x: xMax, y: origin.y + levelHeight))
        
        levelPath.addLine(to: CGPoint(x: origin.x, y: origin.y + levelHeight))
        
        levelShape.path = levelPath
        
        levelShape.fillColor = color
        
        return levelShape
    }
    
    func arrowPath(origin: CGPoint, size: CGSize) -> CGMutablePath {
        
        let arrowPath = CGMutablePath()
        
        arrowPath.move(to: origin)
        
        arrowPath.addLine(to: CGPoint(x: origin.x, y: origin.y + size.height * 0.4))
        
        arrowPath.addLine(to: CGPoint(x: origin.x + size.width / 2.0, y: origin.y + size.height))
        
        arrowPath.addLine(to: CGPoint(x: origin.x + size.width, y: origin.y + size.height * 0.4))
        
        arrowPath.addLine(to: CGPoint(x: origin.x + size.width, y: origin.y))
        
        return arrowPath
    }
}

class Pyramidformator: NSObject, IValueFormatter {
    
    public func getFormattedTextforValue(value:Double, type: FieldType, data:AnyObject?) -> String {
        switch(type)
        {
            case .x:
                return String(value)
                
            case .y:
                return String(value)
        }
    }
    public func getFormattedTextforLabel(label: String, type: FieldType, data:AnyObject?) -> String {
        switch(type)
        {
            case .x:
                return label
            
            case .y:
                return label
        }
    }
    
    func stringForValue(_ value: Double, entry: zchart.ChartDataEntry, dataSetIndex: Int, viewPortHandler: zchart.ViewPortHandler?) -> String {
        return String(value)
    }
    
    func getFormattedValue(entry: zchart.ChartDataEntry) -> String {
        return entry.xString ?? ""
    }
    
    
    func getFormattedValue(stackSum:Double, entryX: Double) -> String {
        return "stage \n"+String(stackSum)
    }
}
