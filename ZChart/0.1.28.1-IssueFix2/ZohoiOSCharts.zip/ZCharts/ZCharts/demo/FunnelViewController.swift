//
//  FunnelViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 04/04/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import  zchart

class FunnelViewController: UIViewController,IToolTipEntryGenerator, RendererDelegate {
   
    var containerView:ChartContainer? = nil
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
        
        if entry == nil {
            
            var totalSum:Double = 0
            
            if self.funnelChartView?.data?.dataSets[0] != nil
            {
                let dataSet = (self.funnelChartView?.data?.dataSets[0])! as! ChartDataSet
                
                let funnelEntries = dataSet.values
                
                totalSum = funnelEntries.map { $0.y }.reduce(0, +)
            }
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(totalSum) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        
        let funnelEntry = entry!
        
        let toolTipEntry = ToolTipEntry(label: funnelEntry.xString!, value: String(funnelEntry.y))
        toolTipEntry.valueTextColor = (funnelEntry.entryColor)
        
        entries.append(toolTipEntry)
        
        return entries
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
                
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.isAxisChart = false
        
        //addChartTypeAndData
        addFunnelChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    var funnelChartView:ChartViewBase? = nil
    
    func addFunnelChart()
    {
        funnelChartView = containerView?.chart as? ChartViewBase
        
        funnelChartView?.tapEventListener?.handler = FunnelHighlightHandler()
        
        funnelChartView?.longPressEventListener?.handler = FunnelLongPressListener()
        
        funnelChartView?.panEventListener?.handler = FunnelPanHandler()
        
        funnelChartView?.rendererDelegate = self
        
//      let data=[10,200,150,-50,0,-7,140]
        
        let data:[Double] = [265190,176240,137440,118050,71200]
//        let data:[Double] = [265190,176240,Double.nan,118050,Double.nan]
        
        let dataLabel = ["Identify","Validated","Qualified","Proposal","Won"]

        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var dataEntries:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = FunnelChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            dataEntries.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: dataEntries, label: "Funnel")
        
        chartDataSet.plotType = .Funnel
        
//        chartDataSet.dataToShow = .showLabel
        
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
       /* let gradient1 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[0]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[1]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient3 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient4 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[3]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient5 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[4]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         chartDataSet.gradients = [gradient1, gradient2,gradient3, gradient4,gradient5] */
        
        // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.white
        
        chartDataSet.valueFont = UIFont.boldSystemFont(ofSize: 10)
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        funnelChartView?.data = chartData
        
        guard let plotOptions = funnelChartView?.getPlotOptions(type: .Funnel) as? FunnelPlotOptions
        else { return }
        
        plotOptions.funnelWeightedType = .Height //DefaultType : .Height
        
        plotOptions.outerPadding = 20
        
        plotOptions.maxSliceHeight = 80
        
        plotOptions.stemHeight = 80
        
        plotOptions.stemWidth = 50
        
        plotOptions.interSliceSpacing = 5
        
        plotOptions.dataToShow = .showLabel
        
//        funnelChartView?.animate(xAxisDuration: 1, yAxisDuration: 1)
        
//        FunnelHelperFunctions.customAnimation(chart: funnelChartView!, animationDuration: 1)
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: funnelChartView!, duration: 1, animationBlock: animateBlock)
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let animateBlock = { [unowned self] in
            
            if self.funnelChartView?.data == nil
            {
                return
            }
           
            let barEntryAnimator = Animator()
            
            
            barEntryAnimator.updateBlock = { [unowned self, barEntryAnimator] in
                
                let allLayers = FunnelLayer.getAllFunnelLayer(chart: self.funnelChartView!)
                
                let entryCount = (allLayers.count/(self.funnelChartView?.data?.dataSetCount)!)
                
                let heightPercent = Double(2)
                
                let duration:Double = ((heightPercent) / (Double(entryCount - 1) + heightPercent)) * totalDuration
                
                for entryIndex in 0..<entryCount
                {
                    
                    
                    let startTime = (( duration / Double(heightPercent)) * Double(entryIndex))
                    
                    let endTime = startTime + duration
                    
                    let currentTime = (barEntryAnimator.phaseX) * totalDuration
                    
                    if currentTime > endTime  {
                        
                        self.updateLayerPath(phaseValue: 1, index: entryIndex, allLayers: allLayers)
                        
                    } else if currentTime < startTime {
                        
                    } else {
                     
                        let difference = currentTime - startTime
                        
                        var percent = CGFloat(difference/duration)
                        
                        if percent > 1
                        {
                            percent = 1
                        }
                        
                        self.updateLayerPath(phaseValue: percent,index:entryIndex,allLayers: allLayers)
                        
                    }
                    
                }
                
            }
            barEntryAnimator.stopBlock = { [unowned barEntryAnimator] in
                barEntryAnimator.updateBlock = nil
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    
    func updateLayerPath(phaseValue:CGFloat,index:Int,allLayers:[ChartEntryLayer])
    {
        
//       let entryCount = (funnelChartView?.data?.maxEntryCountSet?.entryCount)! - 1        
        let entryCount = allLayers.count - 1
        
        if entryCount <= -1 || index < -1 || index > entryCount {
            return
        }
        
        let indexLayer = (allLayers[entryCount - index]) as! FunnelLayer
        
        if indexLayer.funnelSlicePoint == nil {
            return
        }
        
        let newPoints = getUpdatedPointsForCustomAnimatiom(funnelPoint: (indexLayer.funnelSlicePoint)!, phaseValue: phaseValue)
        
        updateFunnelLayerWithNewPoints(funnelLayer: indexLayer, cgPoints: newPoints)
    
        
    }
    
     func updateFunnelLayerWithNewPoints(funnelLayer:FunnelLayer, cgPoints:[CGPoint]){
        
        let newPath = FunnelLayer.getBezeirPath(cgPoints: cgPoints)
        
        funnelLayer.path = newPath//.cgPath
        
        funnelLayer.opacity = 1
        
        GradientLayerRenderer.updateGradientLayerPath(targetLayer: funnelLayer, newPath: newPath)
        
    }
    
     func getUpdatedPointsForCustomAnimatiom(funnelPoint:FunnelSlicePoint, phaseValue:CGFloat) -> [CGPoint] {
        
        let allPoints = funnelPoint.points
        
        let endY = allPoints[0].y
        
        let startY = allPoints[3].y
        
        let diff = (endY - startY)
        
        let newStartY = endY - (diff * CGFloat(phaseValue)) //((CGFloat(sliceHeight * Double(index))) + (topValue))
        
        let diffX1 = abs(allPoints[0].x - allPoints[3].x)
        let startX1 = (allPoints[0].x) - (diffX1 * CGFloat(phaseValue))
        
        let diffX2 = abs(allPoints[2].x - allPoints[1].x)
        let startX2 = (allPoints[1].x) + (diffX2 * CGFloat(phaseValue))
        
        var newPoints:[CGPoint] = []
        
        newPoints.append(allPoints[0])
        newPoints.append(allPoints[1])
        newPoints.append(CGPoint(x: startX2, y: newStartY))
        newPoints.append(CGPoint(x: startX1, y: newStartY))
        
        if allPoints.count == 6 {
            
            let diffX4 = abs(allPoints[0].x - allPoints[4].x)
            let startX4 = (allPoints[0].x) - (diffX4 * CGFloat(phaseValue))
            
            let diffX3 = abs(allPoints[3].x - allPoints[1].x)
            let startX3 = (allPoints[1].x) + (diffX3 * CGFloat(phaseValue))
            
            let midDiff = (allPoints[0].y - allPoints[2].y)
            
            let newMidY = endY - (midDiff * CGFloat(phaseValue)) //((CGFloat(sliceHeight * Double(index))) + (topValue))
            
            newPoints.removeAll()
            
            newPoints.append(allPoints[0])
            newPoints.append(allPoints[1])
            newPoints.append(CGPoint(x: allPoints[2].x, y: newMidY))
            newPoints.append(CGPoint(x: startX3, y: newStartY))
            newPoints.append(CGPoint(x: startX4, y: newStartY))
            newPoints.append(CGPoint(x: allPoints[5].x, y: newMidY))
            
            
        }
        
        return newPoints
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func delegateToHighlight(layer: ChartEntryLayer, isHighlighted: Bool) {
        
        guard let layer = layer as? FunnelLayer,
              let entry = layer.chartEntry,
              let chart = layer.chartView else {
            return
        }
        
        if isHighlighted {
            
            if let lastSelected = chart.lastSelected {
                if lastSelected.contains( where: {$0 === entry}) {
                    
                    let highlightDifference:CGFloat = 15.0
                    
                    let funnelSlicePoint = layer.funnelSlicePoint
                    var points = (funnelSlicePoint?.points)!
                        
                    if points.count == 6 {
                        points[0].x = points[0].x - highlightDifference
                        points[4].x = points[4].x - highlightDifference
                        points[5].x = points[5].x - highlightDifference
                            
                        points[1].x = points[1].x + highlightDifference
                        points[2].x = points[2].x + highlightDifference
                        points[3].x = points[3].x + highlightDifference
                    } else {
                        points[0].x = points[0].x - highlightDifference
                        points[3].x = points[3].x - highlightDifference
                            
                        points[1].x = points[1].x + highlightDifference
                        points[2].x = points[2].x + highlightDifference
                    }
                        
                    layer.path = FunnelLayer.getBezeirPath(cgPoints: points)
                }
            }
        }
    }
    

}
