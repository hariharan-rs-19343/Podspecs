//
//  PieContinuousLegendVC.swift
//  ZCharts
//
//  Created by Aravinth T on 02/05/19.
//  Copyright © 2019 charts. All rights reserved.
//

import Foundation
import zchart
import UIKit

class PieContinuousLegendVC: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let pieEntry = entry!
        
        
        let toolTipEntry = ToolTipEntry(label: pieEntry.xString!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = (entry?.entryColor)!
        toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 17)
        
        toolTipEntry.labelTextAlignment = .left
        
        toolTipEntry.valueTextAlignment = .right
        
        var labels:[String] = ["Sales","Avg. Cost","No. of Customers","Others","Label 5","Label 6","Label 7","Label 8"]
        
        
        
        entries.append(toolTipEntry)
        
        for i in 0...7
        {
            let dummy = ToolTipEntry(label: labels[i], value: String((pieEntry.y/2)+Double(i+5)))
            dummy.valueTextColor = (entry?.entryColor)!
            
            dummy.labelTextAlignment = .left
            
            dummy.valueTextAlignment = .right
            entries.append(dummy)
        }
        
        return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    let slideMenuView = UIView()
    
    var legendSwipeUpRecognizer: UISwipeGestureRecognizer!
    
    var legendSwipeDownRecognizer: UISwipeGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .top
        containerView?.legend.type = .continous
        
        containerView?.isAxisChart = false
        
        addPieChart()
    
    }
    
    // MARK: - Chart Input
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
        
      
        // MARK: Events
        
        //        pieChartView.enableDrawValues()
        
        pieChartView.tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
//        pieChartView.panEventListener?.handler = PiePanHandler()
        
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        //   pieChartView.radius = 20
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        let data=[10,200,150,-50,10,-7,140]
        //
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        piedata[0].colorValue = 5//Blue
        piedata[1].colorValue = 375//Yellow
        piedata[2].colorValue = 100//Blue
        piedata[3].colorValue = 999//Green
        piedata[4].colorValue = 128//Blue
        piedata[5].colorValue = 777//Green
        piedata[6].colorValue = 498//yellow
        
        
        piedata[0].colorString = "North"
        piedata[1].colorString = "East"
        piedata[2].colorString = "South"
        piedata[3].colorString = "West"
        piedata[4].colorString = "South"
        piedata[5].colorString = "East"
        piedata[6].colorString = "West"
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
        //        chartDataSet.gradients = getRadialGradientArray()
        
        // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.black
        
        chartDataSet.plotType = .Pie
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
               
       guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
           else { return }
       
       piePlotOption.valueLinePart2Length = 0.6
               
               //        piePlotOption.sliceSpace = 10
        //  pieChartView.setPieType = .PieSpinWheel
              
       piePlotOption.drawHoleEnabled = false // Doughnut
       piePlotOption.drawEntryLabelsEnabled = false
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        piePlotOption.sliceDirection = .clockwise
        
        //        pieChartView.drawHoleEnabled = true
        
        let colorAxis = pieChartView.colorAxis
        colorAxis.enabled = true
        
        //Linear Type
        colorAxis.type = .linear
        colorAxis.stops = [0,250,500,750,1000]
        colorAxis.colors = [hexStringToUIColor(hex: "#ee7d54"),hexStringToUIColor(hex: "#dbbe56"),hexStringToUIColor(hex: "#92c658"),hexStringToUIColor(hex: "#1ac9bb"),hexStringToUIColor(hex: "#0eaadd")] 
        
      
        //Range Type
      /*  colorAxis.type = .range
        let range1 = Range(from: 0, to: 250)
        let range2 = Range(from: 250, to: 500)
        let range3 = Range(from: 500, to: 750)
        let range4 = Range(from: 750, to: 1000)
        colorAxis.rangeArray = [range1,range2,range3,range4]
        colorAxis.colors = [UIColor.blue,UIColor.yellow,UIColor.red,UIColor.green] */
        
     /*  //Discrete Type
        colorAxis.type = .discrete
        colorAxis.category = ["North","South","East","West"]
        colorAxis.colors = [UIColor.blue,UIColor.yellow,UIColor.red,UIColor.green]*/
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
        // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        chartInstance.append(pieChartView)
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    // MARK: - Drill Input Data
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
        level += 1
        
        
        guard let pieChartView = containerView?.chart
            else { return }
        
        containerView?.legend.type = .discrete
        
        // MARK: Event
        
        pieChartView.tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.handler = PiePanHandler()
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        let data=[100,200,150,50,80,170,140]
        
        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i]+String(level))
            let dataEntry =  ChartDataEntry(xString: dataLabel[i]+String(level), y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        chartDataSet.plotType = .Pie
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        chartDataSet.valueTextColor = UIColor.black
        
        pieChartView.data = chartData
        
        
        // MARK: Plot Options
        
        guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
        else { return }
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        piePlotOption.drawHoleEnabled = false // Doughnut
        piePlotOption.drawEntryLabelsEnabled = false
        piePlotOption.centerLabelEnabled = true
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        chartInstance.append(pieChartView)
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 1.0, easingOption: .linear)
    }
    
  
    // ===== SWIPE ==== //
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
 
}

/*extension Array {
    subscript (safe index: Int) -> Element? {
        return indices ~= index ? self[index] : nil
    }
}

extension UIColor {
    public convenience init?(hex: String) {
        let r, g, b, a: CGFloat
        
        if hex.hasPrefix("#") {
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])
            
            if hexColor.count == 8 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0
                
                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff000000) >> 24) / 255
                    g = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    b = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    a = CGFloat(hexNumber & 0x000000ff) / 255
                    
                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
        }
        
        return nil
    }
} */
