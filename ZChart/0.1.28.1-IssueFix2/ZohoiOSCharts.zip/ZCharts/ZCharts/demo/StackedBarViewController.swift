//
//  StackedBarViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 11/10/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import zchart

class StackedBarViewController: UIViewController,IToolTipEntryGenerator, PlotDelegate, ChartViewDelegate, ShapeFactoryDataSource  {

    
    func shapePath(frame: CGRect, shapeInstance: ShapeProperties, entry: Any?, shapeLayer: CAShapeLayer) -> CGMutablePath {
        let path = CGMutablePath()

        let shapeSize = frame.width
        let shapeHalf = shapeSize / 2.0

        let circlePath = UIBezierPath()

        circlePath.move(to: CGPoint(x: frame.midX, y: frame.minY))
        circlePath.addLine(to: CGPoint(x: frame.midX, y: frame.maxY))
        circlePath.close()
        path.addPath(circlePath.cgPath)

        return path
    }

    func updateShapeProperties(frame:CGRect, shapeInstance: ShapeProperties, entry: Any?) {
        guard let entry = entry as? LegendEntry
        else { return }
        
        shapeInstance.resetProperties()

        shapeInstance.size = frame.size
        shapeInstance.shapeType = .custom

        switch entry.label
        {
                case "Company A":
                    shapeInstance.shapeType = .circle
                    shapeInstance.lineDashPhase = 2.0
                    shapeInstance.lineDashLengths = [4.0,8.0]

                case "Company B":
                    shapeInstance.shapeType = .x

                case "Company C":
                    shapeInstance.shapeType = .square

                case "Company D":
                    shapeInstance.shapeType = .custom

                default:
                    shapeInstance.shapeType = .triangle
        }

        shapeInstance.strokeColor = entry.formColor
        shapeInstance.holeColor = UIColor.clear
    }
    
    
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil || (entry?.x.isNaN)! //|| (entry?.y.isNaN)!
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(Double(totalSales)) )
            toolTipEntry1.valueTextColor = UIColor.black
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }

        let barEntry = entry!

        guard let dataSet = barChartView?.data?.getDataSetForEntry(barEntry)
            else { return entries }
        
        guard let barPlotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return []}
    
        if (barPlotOptions.barGroupSelectionEnabled)
        {
            
            for set in (barChartView?.data?.dataSets)!
            {
                if !(set.isVisible)
                {
                    continue
                }
                
                let xEntries = set.entriesForXValue(barEntry.x)
                if xEntries.count <= 0
                {                   //entryForXValue(barEntry.x, closestToY: Double.nan)
                  continue
                }
                
                let entry = xEntries[0]
                
                let toolTipEntry = ToolTipEntry(label: set.label!, value: String((entry.y)))
                toolTipEntry.valueTextColor = (set.colors[0])
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
                
            }
            /*for i in 0 ..< (barEntry.yValues?.count)!
            {
                let toolTipEntry = ToolTipEntry(label: barDataSet.stackLabels[i], value: String((barEntry.yValues?[i])!))
                toolTipEntry.valueTextColor = (set?.colors[i])! //UIColor.blue //curEntry.entryColor
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }*/
        }
        else
        {
            for i in 0..<(dataSet.entryCount)
            {
                let curEntry = dataSet.entryForIndex(i) as! ChartDataEntry
                
                guard let label = curEntry.xString
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: label, value: String((curEntry.y)))
                toolTipEntry.valueTextColor = (dataSet.color(atIndex: 0))
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
            
        }
        
        
        return entries
    }

    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        let formShape = ShapeProperties()
        formShape.customPathDataSource = self
        formShape.shapeType = .triangle
        
        
        containerView?.legend.legendFormCustomEnabled = true
        containerView?.legend.customFormShape = formShape
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
//        containerView?.delegateToChartView = self
        
        
        containerView?.legend.customPath = { (bound:CGRect) -> CGPath in
            return UIBezierPath(roundedRect: bound, byRoundingCorners: [.allCorners], cornerRadii: CGSize(width: 3.0, height: 3.0)).cgPath
        }
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self //DefaultToolTipEntryGenerator()
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
       // containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
     //   containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
     //   let groupSpace = 0.3
        
      //  let barSpace = 0.03
        
        barChartView = containerView?.chart
        
        barChartView?.rendererDelegate = self
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = DefaultPanHandler()
        
        barChartView?.longPressEventListener?.handler = StackedBarLongPressListener()
        
        //        barChartView?.xAxis.labelRotationAngle = 0
        //
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        //
                barChartView?.xAxis.axisTitle = "Items"
        //
                barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        //
        //        barChartView?.rightAxis.axisTitle = "Quantities"
        //
//                barChartView?.xAxis.wordWrapEnabled = false
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.xAxis.labelRotationAngle = 0
        
        //
        barChartView?.xAxis.inverted = false
        
        //        let count = 2000+50
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 80
        
        totalSales = 0
        let count = 100
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            var val1 = Double(arc4random_uniform(UInt32(range)) + 3)
    
            var val2 = Double(arc4random_uniform(UInt32(range)) + 3)
       
            var val3 = Double(arc4random_uniform(UInt32(range)) + 3)
          
            var val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            var val5 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            if i == 0
            {
//                (val1,val2,val3,val4,val5) = (Double.nan,Double.nan,Double.nan,Double.nan,Double.nan)
//                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//                val1 = Double(arc4random_uniform(UInt32(range)) + 3)
//                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//                continue
            }
            
            if i == 0
            {
                val1 = Double.nan
            }
            
            if i == 3
            {
                (val1,val3,val5) = (Double.nan,Double.nan,Double.nan)
            }
            
//            if i == 3
//            {
//                dataEntries1.append(ChartDataEntry(xString: nil, y: val1, data: nil))
//            }
//            else{
                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
//            }
            
            if i == 4
            {
                dataEntries2.append(ChartDataEntry(xString: nil, y: val2, data: nil))
            }
            else{
                dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            }
            
            if i == 3
            {
                dataEntries3.append(ChartDataEntry(xString: nil, y: -val3, data: nil))
            }
            else{
                dataEntries3.append(ChartDataEntry(xString: lab, y: -val3, data: nil))
            }
//            if i==0
//            {
//                //                dataEntries4.append(ChartDataEntry(xString: lab, y: Double(0), data: nil))
//                dataEntries4.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
//            }
//            else
//            {
                dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
//
//                val4 = Double(arc4random_uniform(UInt32(range)) + 3)
//                dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
         
//            }
            
//            if i != 7
//            {
                dataEntries5.append(ChartDataEntry(xString: lab, y: -val5, data: nil))
//
//                val5 = Double(arc4random_uniform(UInt32(range)) + 3)
//                dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
            
//            }
            totalSales += CGFloat(val1+val2+val3+val4)
            
        }
        totalSales = 81091.0
    
        /*for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            
            var stackEntry = ChartDataEntry(xString: lab, yValues: [Double(val1), Double(val2), Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
            
            if i == 0 {
                stackEntry = ChartDataEntry(xString: lab, yValues: [Double.nan, Double(val2), Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
            }
            
            if i == 3 {
                stackEntry = ChartDataEntry(xString: lab, yValues: [Double.nan, Double(val2), Double.nan, Double(val4) , Double.nan], data: lab as AnyObject)
            }
            
            /*    var stackEntry = ChartDataEntry(xString: lab, yValues: [Double(val1), -Double(val2), Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
             
             if i == 0 {
             stackEntry = ChartDataEntry(xString: lab, yValues: [0, Double(val2), Double(val3), -Double(val4) , Double(val5)], data: lab as AnyObject)
             }
             else if i % 5 == 0{
             stackEntry = ChartDataEntry(xString: lab, yValues: [-Double(val1), Double(val2), -Double(val3), Double(val4) , -Double(val5)], data: lab as AnyObject)
             }
             
             if i == 3 {
             stackEntry = ChartDataEntry(xString: lab, yValues: [Double.nan, Double(val2), Double.nan, -Double(val4) , Double.nan], data: lab as AnyObject)
             }
             */
            
            dataEntries1.append(stackEntry)
            
            totalSales += CGFloat(val1+val2+val3+val4+val5)
            
        }*/
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.values = dataEntries1
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
    
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
        
       /* let gradient1 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[0]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[1]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient3 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient4 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[3]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient5 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[4]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set1.gradients = [gradient1, gradient2,gradient3, gradient4,gradient5] */
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4, set5])
        
        barChartView?.data = chartData
        
        chartData.setDrawValues(false)
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
        barPlotOptions.stackedSumEnabled = true
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.barWidthPixel = 18
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.maximumBarPixel = 100
        
        barPlotOptions.fitBars = true
        
//        chartData.stackSpacing = 20
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.axisMinimum = 0
        
        //        barChartView?.xAxis.axisMaximum = 0+chartData.groupWidth(groupSpace: 0.08, barSpace: 0.03)
        
        //        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
                barChartView?.xAxis.labelCount = 25
                barChartView?.xAxis.spaceMax = 0.5
                barChartView?.xAxis.spaceMin = 0.5
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
      
        
        
//        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
      //  barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barPlotOptions.drawValueAboveBarEnabled = false
        
//        chartData.highlightColor = UIColor.brown
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
//        chartData.nonHighlightGradient = LinearGradient(colors: [UIColor.red, UIColor.orange], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        
//        chartData.highlightGradient = LinearGradient(colors: [UIColor.cyan, UIColor.blue], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        
        
        
//        highlightFullBarEnabled
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
//        let animateBlock = SingleBarViewController.getAnimationBlock(chartView: self.barChartView!)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 1.0)
        
        CommonUtilities.customAnimation(chart: barChartView!, duration: 1, animationBlock: animateBlock)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        
       
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        chartInstance.append(barChartView!)
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        //        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        //        upperLimit.lineColor = NSUIColor.green
        //        //        upperLimit.lineWidth = 6.0
        //
        //        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        //        lowerLimit.lineColor = NSUIColor.red
        //
        //        lowerLimit.lineDashPhase = 2.0
        //        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        
    }
    
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []
    
    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        if (type == .Bar)
        {
            let barPlotOptions = plotOption as! BarPlotOptions
            
            barPlotOptions.isStacked = true
            
            barPlotOptions.barWidth = 0.6
            
            barPlotOptions.barWidthPixel = 18
            
            barPlotOptions.minimumBarPixel = 18
            
            barPlotOptions.barSpacePixel = 5
            
            barPlotOptions.maximumBarPixel = 100
            
            barPlotOptions.fitBars = true
        }
    }
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        barChartView?.lastSelected = nil
        barChartView?.isRotated = true
        barChartView?.plotDelegate = self
        let xOrdinal = barChartView?.xAxis.scaleType == .Ordinal
        barChartView?.xAxis.labelRotationAngle = 0 
        for dataset in barChartView!.data!.dataSets
        {
            let yOrdinal = barChartView?.getYAxis(atIndex: dataset.axisIndex)!.scaleType == .Ordinal
            for i in 0..<dataset.entryCount {
                let e = dataset.entryForIndex(i)!
                if (xOrdinal) {
                    e.x = Double.leastNormalMagnitude
                }
                if (yOrdinal) {
                    e.y = Double.leastNormalMagnitude
                }
            }
            dataset.plotType = .Bar
            dataset.notifyDataSetChanged()
        }
        
        barChartView?.data?.reinit()
        barChartView?.notifyPlotUpdated()        
        
        /*level += 1

        barChartView = containerView?.initializeChart()
        
        barChartView?.chartActionListener = self
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // BarPanHandler()
        
        barChartView?.longPressEventListener?.handler = StackedBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
    
        barChartView?.xAxis.axisTitle = "Item "+String(level)
        
        barChartView?.xAxis.scaleType = .Ordinal
       
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
   
        barChartView?.xAxis.wordWrapEnabled = true
        
        let count = 30
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
     
        for i in 0..<count {
            
            let lab = "Product " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            var xValue = Double(i)
         
            if i == 0 || (i > 7 && i < 10) || i == 29
            {
                xValue = Double.nan
            }
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
            dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val2), data: nil))
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
            dataEntries4.append(ChartDataEntry(xString: lab, y: Double(val4), data: nil))
            dataEntries5.append(ChartDataEntry(xString: lab, y: Double(val5), data: nil))
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
      /*  let gradient1 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[0]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[1]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient3 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient4 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[3]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient5 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[4]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set1.gradients = [gradient1, gradient2,gradient3, gradient4,gradient5] */
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4, set5])
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.fitBars = true
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 10
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.5

        barChartView?.xAxis.drawGridLinesEnabled = false
        
    
        barPlotOptions.drawValueAboveBarEnabled = false
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        chartInstance.append(barChartView!)
        */
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
     
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    

    

    
}

extension StackedBarViewController: RendererDelegate {
    
    func drawOthers(_ chartView: ChartViewBase) {
            
            for barLayer in BarLayer.getAllBarLayer(chart: chartView) {
                
                guard let barRect = barLayer.barRect else {
                    continue
                }
                
                let isRotated = chartView.isRotated
                
                if (barRect.height == 0 && !isRotated) || (barRect.width == 0 && isRotated) {
                    
                    let path = CGMutablePath()
                                           
                    if isRotated {
                        path.move(to: barRect.origin)
                        path.addLine(to: CGPoint(x: barRect.origin.x, y: barRect.origin.y + barRect.height))
                        
                    }
                    else {
                        path.move(to: barRect.origin)
                        path.addLine(to: CGPoint(x: barRect.origin.x + barRect.width, y: barRect.origin.y))
                    }
                    
                    if let barSubLayers = barLayer.sublayers, barSubLayers.count > 1 {
                        (barSubLayers[0] as? ChartExtrasLayer)?.path = path
                        (barSubLayers[0] as? ChartExtrasLayer)?.strokeColor = barLayer.fillColor
                    }
                    else {
                        let layerForValueZero = CAShapeLayer()
                        layerForValueZero.path = path
                        layerForValueZero.strokeColor = barLayer.fillColor
                        barLayer.addSublayer(layerForValueZero)
                    }
                }
            }
    }
}


