//
//  AreaStackedViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 20/09/18.
//  Copyright © 2018 charts. All rights reserved.
//



import UIKit
import zchart

class AreaStackedViewController: UIViewController,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let allEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: lineChartView!)
        
        for i in 0..<(allEntries.count)
        {
            let entry = allEntries[i]
            let set = lineChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!  //UIColor.blue //curEntry.entryColor
            
            entries.append(toolTipEntry)
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    /* var showCustomLineView:Bool = false
     
     func addCustomLineView() {
     
     
     childView = UIView(frame: self.view.bounds)
     
     childView.backgroundColor = UIColor.clear
     
     self.view.addSubview(childView)
     
     //        self.addMultipleLine(view: childView)
     
     //        addLine(view: childView, point: CGPoint(x: 100, y: 50))
     //        childView.layer.addSublayer(shapeLayer)
     
     let tapGestureRecognizer = NSUITapGestureRecognizer(target: self, action: #selector(tapGestureRecognized(_:)))
     childView.addGestureRecognizer(tapGestureRecognizer)
     
     let panGestureRecognizer = NSUIPanGestureRecognizer(target: self, action: #selector(panGestureRecognized(_:)))
     childView.addGestureRecognizer(panGestureRecognizer)
     
     
     let subPath = UIBezierPath(rect: CGRect(x: 75, y: 75, width: 50, height: 50))
     
     let mainLayer = CAShapeLayer()
     mainLayer.backgroundColor = UIColor.clear.cgColor
     mainLayer.fillColor = UIColor.green.cgColor
     mainLayer.opacity = 0.5
     let mainPath = UIBezierPath(rect: CGRect(x: 50, y: 50, width: 100, height: 100))
     mainPath.append(subPath)
     mainPath.usesEvenOddFillRule = true
     mainLayer.fillRule = kCAFillRuleEvenOdd
     
     mainLayer.path = mainPath.cgPath
     
     
     let subLayer = CAShapeLayer()
     subLayer.backgroundColor = UIColor.clear.cgColor
     subLayer.fillColor = UIColor.yellow.cgColor
     subLayer.opacity = 0.5
     //    let subPath = UIBezierPath(rect: CGRect(x: 75, y: 75, width: 50, height: 50))
     subLayer.path = subPath.cgPath
     //    subLayer.fillRule = "even-odd"
     
     
     
     //    mainLayer.addSublayer(subLayer)
     //    self.childView.layer.addSublayer(mainLayer)
     
     //    subLayer.mask = mainLayer
     //    self.childView.layer.addSublayer(subLayer)
     
     
     
     }*/
    
    
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        addLine(view: childView, point: location)
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    @objc fileprivate func panGestureRecognized(_ recognizer: NSUIPanGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        if  recognizer.state == .began
        {
            childView.layer.addSublayer(shapeLayer)
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .changed
        {
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .ended || recognizer.state == .cancelled
        {
            addLine(view: childView, point: location)
            shapeLayer.removeFromSuperlayer()
        }
        
        
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    func addMultipleLine(view:UIView)
    {
        
        
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 50, y: 50))
        path.addLine(to: CGPoint(x: 50, y: 95))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:50, y: 105))
        path.addLine(to: CGPoint(x: 50, y: 150))
        path.close()
        
        
        
        //        layer.lineCap = "round"
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        //        layer.fillColor = UIColor.green.cgColor
        shapeLayer.lineWidth = 2
        
        view.layer.addSublayer(shapeLayer)
        
        let circleLayer = CAShapeLayer()
        //        let circlePath = UIBezierPath(rect: CGRect(x: 45, y: 95, width: 10, height: 10))
        let circlePath = UIBezierPath(ovalIn: CGRect(x: 45, y: 95, width: 10, height: 10))
        //        UIBezierPath(ovalIn: <#T##CGRect#>)
        circleLayer.path = circlePath.cgPath
        circleLayer.strokeColor = UIColor.black.cgColor
        circleLayer.fillColor = UIColor.clear.cgColor
        
        shapeLayer.addSublayer(circleLayer)
    }
    
    func addLine(view:UIView, point:CGPoint)
    {
        let path = getNewPath(point: point, yChange: 100)
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 2
        
        var circleLayer:CAShapeLayer? = nil
        
        let sublayers = shapeLayer.sublayers
        if sublayers != nil
        {
            for layer in sublayers!
            {
                if layer.isKind(of: CAShapeLayer.self)
                {
                    circleLayer = layer as! CAShapeLayer
                    break
                }
            }
        }
        
        if circleLayer == nil
        {
            circleLayer = CAShapeLayer()
            circleLayer?.strokeColor = UIColor.black.cgColor
            circleLayer?.fillColor = UIColor.clear.cgColor
            
            shapeLayer.addSublayer(circleLayer!)
        }
        
        circleLayer?.path = getCirclePath(point: point, yChange: 100).cgPath
    }
    
    func getNewPath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        //        let yChange:CGFloat = 50
        let path = UIBezierPath()
        path.move(to: point)
        path.addLine(to: CGPoint(x: point.x, y: point.y + yChange - 5))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:point.x, y: point.y + yChange + 5))
        path.addLine(to: CGPoint(x: point.x, y: point.y + (2.0 * yChange)))
        path.close()
        
        return path
    }
    
    func getCirclePath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        let radius:CGFloat = 5
        //        let yChange:CGFloat = 50
        let rect = CGRect(x: point.x - radius, y: point.y + yChange - radius, width: 2 * radius, height: 2 * radius)
        let path = UIBezierPath(ovalIn: rect)
        path.close()
        
        return path
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*  if showCustomLineView
         {
         addCustomLineView()
         return
         }*/
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        //       containerView?.titleView.showView = false
        //containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addLineChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var lineChartView:ChartViewBase? = nil
    
    func addLineChart()
    {
        
        lineChartView = containerView?.chart
        lineChartView?.plotDelegate = self
        
        lineChartView?.tapEventListener?.handler = AreaHighlightHandler()
        
        lineChartView?.panEventListener?.handler = LinePanHandler()
        
        //        lineChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        //        lineChartView?.leftAxis.axisMinimum = 0
        
//        lineChartView?.xAxis.axisMinimum = 0
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = 1.0
        //        lineChartView?.xAxis.granularityEnabled = true
        
        //        let count = 2000+50
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        var dataEntries6: [ChartDataEntry] = []
        
        
        
        
        /*for i in 0..<count {
         let lab = "Item " + String(Double(i+1))
         
         var val1 = arc4random_uniform(UInt32(range)) + 3
         
         //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
         if i == 0 || i == 9 //|| i == 0 || i == 6 || i == 11 || i == 20 || i == 22 || i >= 98
         {
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
         }
         else{
         dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
         dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
         dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
         }
         //                if i == 5{
         //                    dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
         //                    val1 = arc4random_uniform(UInt32(range)) + 3
         //                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
         //            }
         
         if i == 9
         {
         dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
         }
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         if i == 1 || i == 2 || i == 3
         {
         dataEntries2.append(ChartDataEntry(x: Double.nan, y: Double.nan, data: lab as AnyObject))
         }
         else{
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
         }
         
         
         //            if i == 5{
         //                val1 = arc4random_uniform(UInt32(range)) + 3
         //                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
         //            }
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val3), data: lab as AnyObject))
         
         let val4 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries4.append(ChartDataEntry(x: Double(i), y: Double(val4), data: lab as AnyObject))
         
         }*/
        
        
        /*for i in 0..<count {
         let lab = "Item " + String(Double(i+1))
         
         var val1 = arc4random_uniform(UInt32(range)) + 3
         
         
         
         if i == 5
         {
         //val1 = arc4random_uniform(UInt32(range)) + 3
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(40), data: lab as AnyObject))
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(3), data: lab as AnyObject))
         }
         else{
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
         }
         
         var val2 = arc4random_uniform(UInt32(range)) + 3
         if i == 5
         {
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(50), data: lab as AnyObject))
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(10), data: lab as AnyObject))
         }
         else{
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
         }
         
         
         //            if i == 5
         //            {
         //                val2 = arc4random_uniform(UInt32(range)) + 3
         //                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
         //            }
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val3), data: lab as AnyObject))
         
         let val4 = arc4random_uniform(UInt32(range)) + 3
         
         if i != 3
         {
         dataEntries4.append(ChartDataEntry(x: Double(i), y: Double(val4), data: lab as AnyObject))
         }
         }*/
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            var val1 = arc4random_uniform(UInt32(range)) + 3
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            let val6 = arc4random_uniform(UInt32(range)) + 3
            
            if i % 2 == 0 // != 5 && i != 6
            {
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double.nan, data: lab as AnyObject))
//                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
            }
            else{
                
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
//                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double.nan, data: lab as AnyObject))
            }
            
            
//            if i == 5
//            {
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//            }
            
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))

//            if i == 5
//            {
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//            }
            
            
            if i % 2 == 0
            {
                dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val3), data: lab as AnyObject))
            }
            else{
                dataEntries3.append(ChartDataEntry(x: Double.nan, y: -Double(val3), data: lab as AnyObject))
            }
//            if i == 5
//            {
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val1), data: lab as AnyObject))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val1), data: lab as AnyObject))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val1), data: lab as AnyObject))
//            }
            
            
            if i != 5 && i != 6
            {
                dataEntries4.append(ChartDataEntry(x: Double(i), y: -Double(val4), data: lab as AnyObject))
            }
            else{
                dataEntries4.append(ChartDataEntry(x: Double.nan, y: Double.nan, data: lab as AnyObject))
            }
            
            
            
            
            
            if i != 5 && i != 6
            {
                if i ==  3
                {
                    dataEntries5.append(ChartDataEntry(x: Double(i), y: Double(val5), data: lab as AnyObject))
                    val1 = arc4random_uniform(UInt32(range)) + 3
                    dataEntries5.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
                }
                else{
                    dataEntries5.append(ChartDataEntry(x: Double(i), y: Double(val5), data: lab as AnyObject))
                }
                
            }
            else{
                dataEntries5.append(ChartDataEntry(x: Double.nan, y: Double.nan, data: lab as AnyObject))
            }
            
            
            
            dataEntries6.append(ChartDataEntry(x: Double(i), y: -Double(val6), data: lab as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[0])
        
        set1.plotType = .Area
        let lineDataSetOptions1 = LineDataSetOptions()
        set1.dataSetOptions = lineDataSetOptions1
        
        let shape = lineDataSetOptions1.markerInstance
        shape.holeColor = UIColor.red
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        lineDataSetOptions1.setShapeColor(UIColor.red)
        
        lineDataSetOptions1.drawShapeEnabled = true
        
        lineDataSetOptions1.lineWidth = 1
        
        lineDataSetOptions1.drawFilledEnabled = true
        lineDataSetOptions1.fillAlpha = 0.3
        lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[0]
//        set1.mode = .cubicBezier
        /*let gradient1 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[0]], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set1.gradients = [gradient1]*/
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        
        set2.plotType = .Area
        let lineDataSetOptions2 = LineDataSetOptions()
        set2.dataSetOptions = lineDataSetOptions2
        
        lineDataSetOptions2.drawShapeEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        lineDataSetOptions2.setCircleColor(UIColor.black)
        lineDataSetOptions2.lineWidth = 1
        lineDataSetOptions2.circleRadius = 3.0
        lineDataSetOptions2.drawCircleHoleEnabled = false
        lineDataSetOptions2.drawCirclesEnabled = false
        lineDataSetOptions2.drawFilledEnabled = true
        lineDataSetOptions2.fillAlpha = 0.3
        lineDataSetOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        lineDataSetOptions2.lineDashLengths = [4.0,8.0]
        lineDataSetOptions2.lineDashPhase = 2.0
//        set2.mode = .cubicBezier
       /* let gradient2 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[1]], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set2.gradients = [gradient2]*/
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false

        set3.plotType = .Area
        let lineDataSetOptions3 = LineDataSetOptions()
        set3.dataSetOptions = lineDataSetOptions3

        lineDataSetOptions3.drawShapeEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        lineDataSetOptions3.setCircleColor(UIColor.black)
        lineDataSetOptions3.lineWidth = 1
        lineDataSetOptions3.circleRadius = 3.0
        lineDataSetOptions3.drawCircleHoleEnabled = false
        lineDataSetOptions3.drawCirclesEnabled = false
        lineDataSetOptions3.drawFilledEnabled = true
        lineDataSetOptions3.fillAlpha = 0.3
        lineDataSetOptions3.fillColor = ChartColorTemplates.pieColor()[2]
//        set3.mode = .cubicBezier
        /*let gradient3 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[2]], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set3.gradients = [gradient3]*/
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.drawIconsEnabled = false

        set4.plotType = .Area
        let lineDataSetOptions4 = LineDataSetOptions()
        set4.dataSetOptions = lineDataSetOptions4

        lineDataSetOptions4.drawShapeEnabled = false
        set4.setColor(ChartColorTemplates.pieColor()[3])
        lineDataSetOptions4.setCircleColor(UIColor.black)
        lineDataSetOptions4.lineWidth = 1
        lineDataSetOptions4.circleRadius = 3.0
        lineDataSetOptions4.drawCircleHoleEnabled = false
        lineDataSetOptions4.drawCirclesEnabled = false
        lineDataSetOptions4.drawFilledEnabled = true
        lineDataSetOptions4.fillAlpha = 0.3
        lineDataSetOptions4.fillColor = ChartColorTemplates.pieColor()[3]
//        set4.mode = .cubicBezier
      /*  let gradient4 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[3]], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set4.gradients = [gradient4]*/
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Set5")
        set5.drawIconsEnabled = false
        
        set5.plotType = .Area
        let lineDataSetOptions5 = LineDataSetOptions()
        set5.dataSetOptions = lineDataSetOptions5

        lineDataSetOptions5.drawShapeEnabled = false
        set5.setColor(ChartColorTemplates.pieColor()[4])
        lineDataSetOptions5.setCircleColor(UIColor.black)
        lineDataSetOptions5.lineWidth = 1
        lineDataSetOptions5.circleRadius = 3.0
        lineDataSetOptions5.drawCircleHoleEnabled = false
        lineDataSetOptions5.drawCirclesEnabled = false
        lineDataSetOptions5.drawFilledEnabled = true
        lineDataSetOptions5.fillAlpha = 0.3
        lineDataSetOptions5.fillColor = ChartColorTemplates.pieColor()[4]
//        set5.mode = .cubicBezier
      /*  let gradient5 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[4]], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set5.gradients = [gradient5]*/
        
        let set6:ChartDataSet = ChartDataSet(values: dataEntries6, label: "Set6")
        set6.drawIconsEnabled = false

        set6.plotType = .Area
        let lineDataSetOptions6 = LineDataSetOptions()
        set6.dataSetOptions = lineDataSetOptions6

        lineDataSetOptions6.drawShapeEnabled = false
        set6.setColor(ChartColorTemplates.pieColor()[5])
        lineDataSetOptions6.setCircleColor(UIColor.black)
        lineDataSetOptions6.lineWidth = 1
        lineDataSetOptions6.circleRadius = 3.0
        lineDataSetOptions6.drawCircleHoleEnabled = false
        lineDataSetOptions6.drawCirclesEnabled = false
        lineDataSetOptions6.drawFilledEnabled = true
        lineDataSetOptions6.fillAlpha = 0.3
        lineDataSetOptions6.fillColor = ChartColorTemplates.pieColor()[5]
//        set6.mode = .cubicBezier
        /*let gradient6 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[5]], positions: [0,0.8], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        set6.gradients = [gradient6]*/
        
        
//        lineDataSetOptions1.mode = .cubicBezier
//        lineDataSetOptions2.mode = .cubicBezier
//        lineDataSetOptions3.mode = .cubicBezier
//        lineDataSetOptions4.mode = .cubicBezier
//        lineDataSetOptions5.mode = .cubicBezier
//        lineDataSetOptions6.mode = .cubicBezier
        
//        lineDataSetOptions1.mode = .montonic
//        lineDataSetOptions2.mode = .montonic
//        lineDataSetOptions3.mode = .montonic
//        lineDataSetOptions4.mode = .montonic
//        lineDataSetOptions5.mode = .montonic
//        lineDataSetOptions6.mode = .montonic
        
//        lineDataSetOptions1.mode = .linear
//        lineDataSetOptions2.mode = .linear
//        lineDataSetOptions3.mode = .linear
//        lineDataSetOptions4.mode = .linear
//        lineDataSetOptions5.mode = .linear
//        lineDataSetOptions6.mode = .linear
        
        
        lineDataSetOptions1.mode = .stepped
        lineDataSetOptions2.mode = .stepped
        lineDataSetOptions3.mode = .stepped
        lineDataSetOptions4.mode = .stepped
        lineDataSetOptions5.mode = .stepped
        lineDataSetOptions6.mode = .stepped
//
//        set1.mode = .stepped
//        set2.mode = .stepped
//        set3.mode = .stepped
//        set4.mode = .stepped
//        set5.mode = .stepped
//        set6.mode = .stepped
        
        
        
        
        
        //                let chartData = ChartData(dataSet: set1)
        let chartData = ChartData(dataSets: [set1, set2,set3,set4,set5,set6])
        chartData.setDrawValues(true)
        
        lineChartView?.data = chartData
        
        guard let linePlotOptions = (lineChartView?.getPlotOptions(type: .Area) as? AreaPlotOptions)
            else { return }
        
        linePlotOptions.isStacked = true
        
        
        
//        let animateBlock = getAnimationBlock()
//
//        CommonUtilities.customAnimation(chart: lineChartView!,duration:1,animationBlock: animateBlock)
        
                 lineChartView?.animate(xAxisDuration: 1.0)
        
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = lineChartView!
        
        let animateBlock = { [unowned self] in
            
            if chart.data == nil
            {
                return
            }
            
            let contentRect = (self.lineChartView?.viewPortHandler.contentRect)!
            
            
            
            let allLayers = LineLayer.getAllDataSetLayer(chart: chart)
            
            let entryCount =  (self.lineChartView?.data?.dataSetCount)!
            
            let heightPercent = Double(4)
            
            let duration:Double = ((heightPercent) / (Double(entryCount - 1) + heightPercent)) * totalDuration
            
            
            for entryLayer in allLayers
            {
                let maskLayer = CAShapeLayer()
                
                maskLayer.path = UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: 0, height: contentRect.height)).cgPath
                
                maskLayer.fillColor = UIColor.white.cgColor
                
                entryLayer.mask = maskLayer
                
                entryLayer.opacity = 1
            }
            
            
            let barEntryAnimator = Animator()
            
            
            barEntryAnimator.updateBlock = { [unowned barEntryAnimator, self] in
                
                for entryIndex in 0..<entryCount
                {
                    
                    
                    let startTime = (( duration / Double(heightPercent)) * Double(entryIndex))
                    
                    let endTime = startTime + duration
                    
                    let currentTime = (barEntryAnimator.phaseX) * totalDuration
                    
                    if currentTime > endTime  {
                        
                        self.updateLayerPath(phaseValue: 1, index: entryIndex, allLayers: allLayers)
                        
                    } else if currentTime < startTime {
                        
                    } else {
                        
                        let difference = currentTime - startTime
                        
                        var percent = CGFloat(difference/duration)
                        
                        if percent > 1
                        {
                            percent = 1
                        }
                        
                        self.updateLayerPath(phaseValue: percent,index:entryIndex,allLayers: allLayers)
                        
                    }
                    
                }
                
            }
            barEntryAnimator.stopBlock = { [unowned barEntryAnimator] in
                barEntryAnimator.updateBlock = nil
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    func updateLayerPath(phaseValue:CGFloat,index:Int,allLayers:[ChartEntryLayer])
    {
        let chart = lineChartView!
        
        let contentRect = (self.lineChartView?.viewPortHandler.contentRect)!
        
        let xInterpolator = Interpolator.interpolate(a: 0, b: contentRect.width)
        
        let currentPath = UIBezierPath(rect: CGRect(x: contentRect.minX, y: contentRect.minY, width: xInterpolator(phaseValue), height: contentRect.height)).cgPath
        
        
        var dataSetIndex = -1
        
        for layer in LineLayer.getAllDataSetLayer(chart: chart)
        {
            dataSetIndex += 1
            
            if dataSetIndex == index
            {
                guard let maskLayer = layer.mask as? CAShapeLayer
                    else {
                        return
                }
                maskLayer.path = currentPath
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    var orientationFlag = true
    
}

extension AreaStackedViewController: PlotDelegate {
    
    // MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        
        return themeImage
    }
    
    func addChartOrientationSwapButton(){
        
        let orientationSwapButton = UIButton(type: .custom)
        
        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)
        
        orientationSwapButton.setImage(buttonImage(), for: .normal)
        
        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)
        
        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true
        
        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true
        
        self.navigationItem.rightBarButtonItem = buttonItem
    }
    
    @objc func chartOrientationSwap(){
        
        lineChartView?.xAxis.tickLabelMode = .forced
        
        if !orientationFlag{
            
            lineChartView?.isRotated = false
            
            orientationFlag = true
            
            lineChartView?.xAxis.labelRotationAngle = 60
        }
        else{
            
            lineChartView?.isRotated = true
            
            lineChartView?.xAxis.labelPosition = .bottom
            
            lineChartView?.xAxis.labelRotationAngle = 0
            
            lineChartView?.getYAxis(atIndex: 0)?.labelPosition = .outsideChart
            
            orientationFlag = false
        }
        
        lineChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
        lineChartView?.animate(xAxisDuration: 1.0)
    }
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        
        if let plotOptions = (plotOption as? LinePlotOptions) {
            plotOptions.isStacked = true
        }
    }
}



