//
//  CombinedBarAreaViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 20/11/18.
//  Copyright © 2018 charts. All rights reserved.
//


import UIKit
import  zchart

class CombinedBarAreaViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry!
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
    }
    
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        //               containerView?.legend.legendEnabled = false
        //               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        barChartView?.plotDelegate = self
        
        //*****************************  Handlers  *******************************//
        
        //        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        //
        barChartView?.panEventListener?.handler = DefaultPanHandler()
        //
        //        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = DefaultPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 10
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
//        barChartView?.xAxis.wordWrapEnabled = false
        
        //  barChartView?.xAxis.autoRotateAngle = 90
        
        //  barChartView?.xAxis.autoRotateEnabled = false
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        //        barChartView?.leftAxis.baseLineEnabled = true
        //        barChartView?.leftAxis.baseLine?.baseValue = 400
        
        
        barChartView?.xAxis.valueFormatter = ValueFormatter(chart: barChartView!)
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//
        
        totalSales = 0
        
        
        var dataSets:[ChartDataSet] = []
        
        for set in getStackedDataSets()
        {
            dataSets.append(set)
        }
        
        for set in getLineDataSets()
        {
            dataSets.append(set)
        }
        
        barChartView?.scalePreference = .Bar
        
        barChartView?.data = ChartData(dataSets: dataSets)
        
        let barPlotOptions = barChartView?.getPlotOptions(type: .Bar) as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
        barPlotOptions.barWidth = 0.6
        
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.maximumBarPixel = 40
        
        barPlotOptions.fitBars = true
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        //        barChartView?.barCount = 12
        
        //*****************************  MinMax and Colors  *******************************//
        
        
        //        chartData.highlightColor = UIColor.blue
        
        
        //*****************************  Animation  *******************************//
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //                barChartView?.leftAxis.addLimitLine(upperLimit)
        //                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
            dataBackup.append(barChartView?.data?.copy() as! ChartData)
            chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
    }
    
    func getStackedDataSets() -> [ChartDataSet]
    {
        let count = 5
        let range = 5400/5
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            var val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            var val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            var val5 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            if i == 0
            {
                val1 = Double.nan
            }
            
            if i == 3
            {
                (val1,val3,val5) = (Double.nan,Double.nan,Double.nan)
            }
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            
            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
           
            dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
            
            /*    var stackEntry = BarChartDataEntry(xString: lab, yValues: [Double(val1), -Double(val2), Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
             
             if i == 0 {
             stackEntry = BarChartDataEntry(xString: lab, yValues: [0, Double(val2), Double(val3), -Double(val4) , Double(val5)], data: lab as AnyObject)
             }
             else if i % 5 == 0{
             stackEntry = BarChartDataEntry(xString: lab, yValues: [-Double(val1), Double(val2), -Double(val3), Double(val4) , -Double(val5)], data: lab as AnyObject)
             }
             
             if i == 3 {
             stackEntry = BarChartDataEntry(xString: lab, yValues: [Double.nan, Double(val2), Double.nan, -Double(val4) , Double.nan], data: lab as AnyObject)
             }
             */
            
            
            totalSales += CGFloat(val1+val2+val3+val4+val5)
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        
        
        
        /* let gradient1 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[0]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[1]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient3 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient4 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[3]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         let gradient5 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[4]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         set1.gradients = [gradient1, gradient2,gradient3, gradient4,gradient5] */
        
        
        
//        chartData.stackedPercentEnabled = true
        
        return [set1, set2, set3, set4, set5]
    }
    
    func getLineDataSets() -> [ChartDataSet]
    {
        let count = 5
        let range:UInt32 = 2054
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            var val1 = arc4random_uniform(UInt32(range)) + 3
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data:  nil))
            
            
            
            //     dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            let val2 = arc4random_uniform(UInt32(range)) + (3 + range)
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val2), data:  nil))
            
            //            dataEntries2.append(ChartDataEntry(xString: Double(i), y: Double(val2), data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            let val3 = arc4random_uniform(UInt32(range)) + (3 + range * 2)
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data:  nil))
            
            //            dataEntries3.append(ChartDataEntry(xString: Double(i), y: Double(val3), data: nil))
            //            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
        }
        
        
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[6])
        set1.axisIndex = 1
        set1.plotType = .Line
        
        let dataOptions1 = set1.dataSetOptions as! LineDataSetOptions
        let shape = dataOptions1.markerInstance
        //shape.holeColor = UIColor.white
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        dataOptions1.setShapeColor(UIColor.red)
        
        dataOptions1.lineWidth = 1
        dataOptions1.drawShapeEnabled = true
        
        dataOptions1.drawFilledEnabled = true
        dataOptions1.fillAlpha = 0.3
        dataOptions1.fillColor = ChartColorTemplates.pieColor()[6]
        dataOptions1.mode = .cubicBezier
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Line
        
        let dataOptions2 = set2.dataSetOptions as! LineDataSetOptions
        let shape1 = dataOptions2.markerInstance
        shape1.holeColor = UIColor.brown
        shape1.shapeType = .square
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        dataOptions2.setShapeColor(UIColor.brown)
        
        dataOptions2.lineWidth = 0.5
        dataOptions2.drawShapeEnabled = false
        
        dataOptions2.drawFilledEnabled = true
        dataOptions2.fillAlpha = 0.3
        dataOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        dataOptions2.mode = .cubicBezier
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Line
        
        let dataOptions3 = set3.dataSetOptions as! LineDataSetOptions
        dataOptions3.setCircleColor(UIColor.black)
        dataOptions3.lineWidth = 0.5
        dataOptions3.circleRadius = 3.0
        dataOptions3.drawCircleHoleEnabled = false
        dataOptions3.drawCirclesEnabled = true
        dataOptions3.drawShapeEnabled = false
        
        dataOptions3.drawFilledEnabled = true
        dataOptions3.fillAlpha = 0.3
        dataOptions3.fillColor = ChartColorTemplates.pieColor()[2]
        dataOptions3.mode = .cubicBezier
        
        
        
        
//        chartData.setDrawValues(false)
        
        //        chartData.isStacked = true
        
        return [set1]
    }
    
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        /* //  chartInstance.append(chartView)
         
         level += 1
         
         barChartView = containerView?.initializeChart(type: .Bar) as! BarChartView
         
         barChartView?.chartActionListener = self
         
         barChartView?._tapEventListener?.handler = BarHighlightHandler()
         
         barChartView?._panEventListener?.handler = CustomBarPanHandler()
         
         barChartView?._longPressEventListener?.handler = SingleBarLongPressListener()
         
         barChartView?.rightAxis.enabled = false
         
         barChartView?.xAxis.axisTitle = "Years"+String(level)
         
         barChartView?.leftAxis.axisTitle = "Quantities"
         
         barChartView?.rightAxis.axisTitle = "Quantities"
         
         barChartView?.xAxis.wordWrapEnabled = true
         
         barChartView?.xAxis.scaleType = ScaleType.Ordinal
         
         let count = 10
         let range = 54
         
         var dataEntries1: [BarChartDataEntry] = []
         var dataEntries2: [BarChartDataEntry] = []
         var dataEntries3: [BarChartDataEntry] = []
         
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
         
         
         dataEntries1.append(BarChartDataEntry(xString: lab, y: val1, data: nil))
         
         
         }
         
         let set1:BarChartDataSet = BarChartDataSet(values: dataEntries1, label: "Set1")
         set1.colors = ChartColorTemplates.pieColor()
         
         
         let chartData = BarChartData(dataSet: set1)
         chartData.barWidth = 0.6
         
         chartData.minimumBarPixel = 18
         
         barChartView?.data = chartData
         
         
         barChartView?.xAxis.labelPosition = .bottom
         
         barChartView?.xAxis.granularityEnabled = true
         barChartView?.xAxis.granularity = 1.0
         
         barChartView?.xAxis.labelCount = 12
         
         
         barChartView?.xAxis.spaceMax = 0.5
         barChartView?.xAxis.spaceMin = 0.9
         
         barChartView?.xAxis.drawGridLinesEnabled = false
         
         
         barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
         
         barChartView?.chartDescription?.enabled = false
         
         
         let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
         upperLimit.lineColor = NSUIColor.green
         
         let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
         lowerLimit.lineColor = NSUIColor.red
         
         lowerLimit.lineDashPhase = 2.0
         lowerLimit.lineDashLengths = [1.0, 2.0]
         
         
         dataBackup.append(barChartView?.data?.copy() as! ChartData)
         
         chartInstance.append(barChartView!)*/
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /* let chart = chartInstance[index]
         
         level = index
         
         barChartView = chart as! BarChartView
         
         chart.data = dataBackup[index].copy() as! ChartData
         
         chart.notifyDataSetChanged()
         
         dataBackup.removeLast(dataBackup.count-1 - index)
         
         chartInstance.removeLast(chartInstance.count-1 - index)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)*/
        
    }
    var orientationFlag = true

}

extension CombinedBarAreaViewController: PlotDelegate {

    // MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }

        return themeImage
    }
    
    func addChartOrientationSwapButton(){

        let orientationSwapButton = UIButton(type: .custom)

        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)

        orientationSwapButton.setImage(buttonImage(), for: .normal)

        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)

        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true

        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true

        self.navigationItem.rightBarButtonItem = buttonItem
    }

    @objc func chartOrientationSwap(){

        if !orientationFlag{
            
            barChartView?.isRotated = false
            
            orientationFlag = true
        }
        else{
            
            barChartView?.isRotated = true
            
            barChartView?.xAxis.labelPosition = .bottom
            
            orientationFlag = false
        }

        barChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
    }

    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {

        if let barPlotOptions = (plotOption as? BarPlotOptions) {
            barPlotOptions.isStacked = true
            
            barPlotOptions.barWidth = 0.6
            
            barPlotOptions.barWidthPixel = 18
            
            barPlotOptions.barSpacePixel = 5
            
            barPlotOptions.maximumBarPixel = 40
            
            barPlotOptions.fitBars = true
        }
    }
}
