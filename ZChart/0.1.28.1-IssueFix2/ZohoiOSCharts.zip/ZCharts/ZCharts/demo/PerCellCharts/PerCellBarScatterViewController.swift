//
//  PerCellBarScatterViewController.swift
//  ZCharts
//
//  Created by Keerthivass B S on 05/04/24.
//  Copyright © 2024 charts. All rights reserved.
//

import UIKit
import zchart

class PerCellBarScatterViewController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
      
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return entries }
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
   
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String((dataSet?.entryForIndex(selectedIndex!)?.y)!))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! ChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }

    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
      //  containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
      //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = MultiBarPanHandler()
        
     //   barChartView?.legend.labels
        
        
//        barChartView?.xAxis.labelRotationAngle = 0
//
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
//
        barChartView?.xAxis.axisTitle = "Years"
//
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
//        barChartView?.leftAxis.baseLineEnabled = true
//        barChartView?.leftAxis.baseLine?.baseValue = 30

//        barChartView?.rightAxis.axisTitle = "Quantities"
//
//        barChartView?.xAxis.wordWrapEnabled = true
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        
        //        let count = 2000+50
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        barChartView?.xAxis.inverted = false
        
        totalSales = 0
        
        let yVal1 = [27.0,16.0,10.0,31.0,12.0,20.0,26.0,9.0,15.0,27.0,16.0,18.0,31.0,25.0,30.0,26.0,19.0,17.0,27.0,16.0,19.0,31.0,29.0,30.0,26.0,29.0,40.0]
        let xString = ["Positive","Neutral","Negative","Positive1","Neutral1","Negative1","Positive2","Neutral2","Negative2"]
        
        let count = xString.count
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        var dataEntries6: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        var index = 0
        var minVal = Double.greatestFiniteMagnitude
        for i in 0..<count {
            
            dataEntries1.append(ChartDataEntry(xString: xString[i], y: yVal1[index], data: nil))
            minVal = min(minVal, yVal1[index])
            index += 1
            dataEntries2.append(ChartDataEntry(xString: xString[i], y: yVal1[index], data: nil))
            minVal = min(minVal, yVal1[index])
            index += 1
            dataEntries3.append(ChartDataEntry(xString: xString[i], y: yVal1[index], data: nil))
            minVal = min(minVal, yVal1[index])
            index += 1
            
            dataEntries4.append(ChartDataEntry(xString: xString[i], y: minVal / 1.5, data: nil))
            dataEntries5.append(ChartDataEntry(xString: xString[i], y: minVal / 1.5, data: nil))
            dataEntries6.append(ChartDataEntry(xString: xString[i], y: minVal / 1.5, data: nil))
            
            minVal = Double.greatestFiniteMagnitude
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
//        set2.gradients = [gradient2]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
//        set3.gradients = [gradient3]
        
        let Scatter1 = ChartDataSet(values: dataEntries4, label: "Scatter1")
        Scatter1.drawIconsEnabled = false
        Scatter1.setColor(NSUIColor.black)
        Scatter1.plotType = .Scatter
        
        let dataOption = Scatter1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOption.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape.shapeType = .custom
//        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 1.5
        shape.customPathDataSource = self
        
        let Scatter2 = ChartDataSet(values: dataEntries5, label: "Scatter2")
        Scatter2.drawIconsEnabled = false
        Scatter2.setColor(ChartColorTemplates.pieColor()[1])
        Scatter2.plotType = .Scatter
        
        let dataOption2 = Scatter2.dataSetOptions as! AxisChartDataSetOptions
        
        let shape1 = dataOption2.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape1.shapeType = .circle
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        let Scatter3 = ChartDataSet(values: dataEntries5, label: "Scatter3")
        Scatter3.drawIconsEnabled = false
        Scatter3.setColor(ChartColorTemplates.pieColor()[2])
        Scatter3.plotType = .Scatter
        
        let dataOption3 = Scatter3.dataSetOptions as! AxisChartDataSetOptions
        
        let shape2 = dataOption3.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape2.shapeType = .circle
        shape2.size = CGSize(width: 8.0, height: 8.0)
        shape2.lineWidth = 2
        
        let chartData = ChartData(dataSets: [set1, set2, set3, Scatter1])
        
        
        barChartView?.data = chartData

        let barPlotOptions = barChartView?.getPlotOptions(type: .Bar) as! BarPlotOptions
        
        barPlotOptions.barWidthPixel = 18

        barPlotOptions.barSpacePixel = 5

        barPlotOptions.groupSpacePixel = 20
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 40
        
        barPlotOptions.fitBars = true
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        guard let plotOptions = barChartView?.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
        else { return }
        
        plotOptions.minimumShapeSizeInPixel = 8
        plotOptions.maximumShapeSizeInPixel = 16
        
        plotOptions.maxWidthZoomRestrictionPixel = 50
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0

        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false

        barChartView?.xAxis.drawGridLinesEnabled = false

        barChartView?.xAxis.labelCount = 7
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false

    }
}

extension PerCellBarScatterViewController: ShapeFactoryDataSource {
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer: CAShapeLayer) -> CGMutablePath {
        
//        let stepSize = CommonHelperFunctions.stepSize(chart: barChartView!, axisIndex: 0)
//        
//        shapeInstance.size.width = stepSize - stepSize * ((barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)?.groupSpace ?? 0.0) - stepSize * ((barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)?.barSpace ?? 0.0)
//        
//        let path = CGMutablePath()
//        
//        path.addPath(ShapeFactory.getLinePath(point: point, shapeInstance: shapeInstance, isVertical: (barChartView?.isRotated ?? false)))
        
        
        let path = CGMutablePath()
        
        path.addArc(center: point, radius: 6.0, startAngle: 0.0, endAngle: 360.0, clockwise: false)
        
        let innerPath = CGMutablePath()

        innerPath.addArc(center: point, radius: 3.0, startAngle: 0.0, endAngle: 360.0, clockwise: false)
        
        path.addPath(innerPath)
        
        return path
    }
}
