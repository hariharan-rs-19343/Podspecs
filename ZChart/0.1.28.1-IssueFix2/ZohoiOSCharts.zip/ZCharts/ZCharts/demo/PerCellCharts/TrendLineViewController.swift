//
//  TrendLineViewController.swift
//  ZCharts
//
//  Created by Keerthivass B S on 05/04/24.
//  Copyright © 2024 charts. All rights reserved.
//

import UIKit
import zchart

class TrendLineViewController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
      
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return entries }
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
   
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            let selectedDataset = barChartView?.data?.getDataSetForEntry(entry)
            
            let selectedIndex = selectedDataset?.entryIndex(entry: entry!)
            
            for i in 0 ..< (barChartView?.data?.dataSetCount)!
            {
                let dataSet = barChartView?.data?.dataSets[i]
                if !((dataSet?.isVisible)!)
                {
                    continue
                }
                
                let toolTipEntry = ToolTipEntry(label: (dataSet?.label)!, value: String((dataSet?.entryForIndex(selectedIndex!)?.y)!))
                toolTipEntry.valueTextColor = (dataSet?.color(atIndex: 0))! //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        else{
            for i in 0..<(set?.entryCount)!
            {
                let curEntry = set?.entryForIndex(i) as! ChartDataEntry
                
                var label:String
                var value:String
                
                if curEntry.xString != nil
                {
                    label = curEntry.xString!
                }
                else{
                    label = String(curEntry.x)
                }
                
                if curEntry.yString != nil
                {
                    value = curEntry.yString!
                }
                else{
                    value = String(curEntry.y)
                }
                
                let toolTipEntry = ToolTipEntry(label: label, value: value)
                toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
                
                entries.append(toolTipEntry)
            }
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }

    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
      //  containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
      //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = MultiBarPanHandler()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false

        barChartView?.xAxis.axisTitle = "Years"

        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
//        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        barChartView?.getYAxis(atIndex: 1)!.visible = false
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.scalePreference = .Bar
        
        totalSales = 0
        
        let yVal1 = [27.0,16.0,10.0,31.0,12.0,20.0,26.0,9.0,15.0,27.0,16.0,18.0,31.0,25.0,30.0,26.0,19.0,17.0,27.0,16.0,19.0,31.0,29.0,30.0,26.0,29.0,40.0]
        let xString = ["Positive","Neutral","Negative","Positive1","Neutral1","Negative1","Positive2","Neutral2","Negative2"]
        
        let count = xString.count
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        //        for i in 2000..<count {
        var index = 0
        for i in 0..<count {
            
            dataEntries1.append(ChartDataEntry(xString: xString[i], y: yVal1[index], data: nil))
            
            if i == 0 {
                dataEntries2.append(ChartDataEntry(xString: xString[i], y: 15, data: nil))
                dataEntries3.append(ChartDataEntry(xString: xString[i], y: 10, data: nil))
                dataEntries4.append(ChartDataEntry(xString: xString[i], y: 5, data: nil))
            }
            
            if i == 5 {
                dataEntries2.append(ChartDataEntry(xString: xString[i], y: 25, data: nil))
                dataEntries3.append(ChartDataEntry(xString: xString[i], y: 20, data: nil))
                dataEntries4.append(ChartDataEntry(xString: xString[i], y: 15, data: nil))
            }
            
            if i == count - 1 {
                dataEntries2.append(ChartDataEntry(xString: xString[i], y: 40, data: nil))
                dataEntries3.append(ChartDataEntry(xString: xString[i], y: 35, data: nil))
                dataEntries4.append(ChartDataEntry(xString: xString[i], y: 30, data: nil))
            }
            
            index += 1
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "BarSet1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "LineSet2")
        set2.colors = [NSUIColor.black.withAlphaComponent(0.8)]
        set2.label = "Company B"
        set2.plotType = .Line
        set2.axisIndex = 1
        if let lineDataSetOptions1 = set2.dataSetOptions as? LineDataSetOptions {
            lineDataSetOptions1.lineDashLengths = [4.0,8.0]
            lineDataSetOptions1.lineDashPhase = 2.0
            lineDataSetOptions1.mode = .montonic
        }
        
//        set2.gradients = [gradient2]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "LineSet3")
         set3.colors = [NSUIColor.black.withAlphaComponent(0.8)]
        set3.label = "Company C"
        set3.plotType = .Line
        set3.axisIndex = 1
        (set3.dataSetOptions as? LineDataSetOptions)?.mode = .montonic
        
//        set3.gradients = [gradient3]
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "LineSet4")
         set4.colors = [NSUIColor.black.withAlphaComponent(0.8)]
        set4.label = "Company D"
        set4.plotType = .Line
        if let lineDataSetOptions1 = set4.dataSetOptions as? LineDataSetOptions {
            lineDataSetOptions1.lineDashLengths = [4.0,8.0]
            lineDataSetOptions1.lineDashPhase = 2.0
            lineDataSetOptions1.mode = .montonic
        }
        set4.axisIndex = 1
//        set3.gradients = [gradient3]
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4])
        
        barChartView?.data = chartData

        let barPlotOptions = barChartView?.getPlotOptions(type: .Bar) as! BarPlotOptions
        
        barPlotOptions.barWidthPixel = 18

        barPlotOptions.barSpacePixel = 5

        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 40
        
//        barPlotOptions.fitBars = true
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0

        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false

        barChartView?.xAxis.drawGridLinesEnabled = false

        barChartView?.xAxis.labelCount = 7
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false

    }
}
