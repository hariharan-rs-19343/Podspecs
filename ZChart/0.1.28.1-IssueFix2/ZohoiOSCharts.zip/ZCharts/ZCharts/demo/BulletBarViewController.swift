//
//  BulletBarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 04/12/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import  zchart

class BulletBarViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry as! ChartDataEntry
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        //               containerView?.legend.legendEnabled = false
        //               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        Log.info("Drilled")
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
//        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
//        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
//        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 10
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = true
        
//        barChartView?.xAxis.wordWrapEnabled = false
        
        //  barChartView?.xAxis.autoRotateAngle = 90
        
        //  barChartView?.xAxis.autoRotateEnabled = false
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        
        barChartView?.getYAxis(atIndex: 0)!.spaceBottom = 0
        barChartView?.getYAxis(atIndex: 1)!.spaceBottom = 0
        
        
        //        barChartView?.customScaleEnabled = true
        //        barChartView?.setScaleMinima(1, scaleY: 1)
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//
        
        totalSales = 0
        
        let count = 1
        let range = 1200
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        let levelMarkers:[Double] = [1400, 600, 2800]
        
        for i in 0..<count
        {
            let xLabel = "Vivian "+String(i)
            dataEntries1.append(ChartDataEntry(xString: xLabel, y: Double(1600), levelMarker: levelMarkers, targetMarker: 2000, data: nil ))
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[5]]
        set1.plotType = .Bullet
        
        let dataSetOptions = BarDataSetOptions()
        set1.dataSetOptions = dataSetOptions
        
        dataSetOptions.levelMarkerColors = [ChartColorTemplates.pieColor()]
//        dataSetOptions.bulletModel = true
        set1.axisIndex = 1
        
        let shapeProp = dataSetOptions.targetMarkerShapeProperties
        shapeProp.size = CGSize(width: 60*0.3, height: 60*0.3)
        shapeProp.shapeType = .line
        shapeProp.strokeColor = UIColor.black
        shapeProp.lineDashPhase = 2.0
        shapeProp.lineDashLengths = [1.0, 2.0]
        
        /*  let gradient = LinearGradient(colors: [UIColor.cyan, UIColor.blue], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         set1.gradients = [gradient] */
        
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
        chartData.setDrawValues(true)
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
//        chartData.barWidth = 0.7
        
        barPlotOptions.barWidthPixel = 30
        //
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.levelMarkerWidthPixel = 60
        
        barPlotOptions.adjustViewToLevelWidth = true
        //        chartData.barCount = 12
        
        
        
        
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        barPlotOptions.minimumBarPixel = 30
        
        barPlotOptions.maximumBarPixel = 30
        
        //        chartData.highlightColor = UIColor.blue
        
        barPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //                barChartView?.leftAxis.addLimitLine(upperLimit)
        //                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
            dataBackup.append(barChartView?.data?.copy() as! ChartData)
            chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
    }
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = ChartColorTemplates.pieColor()
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSet: set1)
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.minimumBarPixel = 18
        
        barChartView?.data = chartData
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 12
        
        
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        
        chartInstance.append(barChartView!)
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
    }
    
    
    
    /*
     override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
     {
     
     super.viewWillTransition(to: size, with: coordinator)
     
     viewChanged = true
     /*  coordinator.animateAlongsideTransition(in: self.containerView, animation: { (UIViewControllerTransitionCoordinatorContext) in
     self.containerView.setNeedsUpdateConstraints()
     }, completion: nil)
     
     coordinator.animate(alongsideTransition: {, completion: <#T##((UIViewControllerTransitionCoordinatorContext) -> Void)?##((UIViewControllerTransitionCoordinatorContext) -> Void)?##(UIViewControllerTransitionCoordinatorContext) -> Void#>) */
     
     //   self.containerView?.legendView.collectionView?.reloadItems(at: (self.containerView?.legendView.collectionView?.indexPathsForVisibleItems)!)
     
     //self.containerView?.legendView.collectionView?.reloadSections(<#IndexSet#>)
     
     coordinator.animate(alongsideTransition: { context in
     // do whatever with your context
     self.containerView?.setNeedsUpdateConstraints()
     //            self.containerView?.legendView.collectionView?.performBatchUpdates({
     //            self.containerView?.legendView.collectionView?.setCollectionViewLayout((self.containerView?.legendView.collectionView?.collectionViewLayout)!, animated: true)
     //            }, completion: nil)
     context.viewController(forKey: UITransitionContextViewControllerKey.from)
     }, completion: nil)
     }
     
     var viewChanged:Bool = false
     
     override func viewWillLayoutSubviews() {
     super.viewWillLayoutSubviews()
     if viewChanged
     {
     //self.containerView?.legendView.collectionView?.collectionViewLayout.invalidateLayout()
     }
     }
     
     override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
     
     if viewChanged {
     viewChanged = false
     //   self.containerView?.legendView.collectionView?.performBatchUpdates({}, completion: nil)
     }
     }
     */
    
}

