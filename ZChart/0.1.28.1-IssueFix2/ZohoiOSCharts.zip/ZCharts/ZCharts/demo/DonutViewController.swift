//
//  DonutViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 18/07/18.
//  Copyright © 2018 charts. All rights reserved.
//


import zchart
import UIKit

class DonutViewController: UIViewController,IToolTipEntryGenerator,ChartViewDelegate{
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let pieEntry = entry!
        
        
        let toolTipEntry = ToolTipEntry(label: pieEntry.xString!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = (entry?.entryColor)!
        toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 17)
        
        toolTipEntry.labelTextAlignment = .left
        
        toolTipEntry.valueTextAlignment = .right
        
        var labels:[String] = ["Sales","Avg. Cost","No. of Customers","Others","Label 5","Label 6","Label 7","Label 8"]
        
        
        
        entries.append(toolTipEntry)
        
        for i in 0...7
        {
            let dummy = ToolTipEntry(label: labels[i], value: String((pieEntry.y/2)+Double(i+5)))
            dummy.valueTextColor = (entry?.entryColor)!
            
            dummy.labelTextAlignment = .left
            
            dummy.valueTextAlignment = .right
            entries.append(dummy)
        }
        
        return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        //       containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.isAxisChart = false
        
        //addChartTypeAndData
        
        addPieChart()
        
        //        addBarChart()
        
        /*  containerView?.toolTipView.enableMenu = true
         containerView?.toolTipView.menuControl?.dataSource = self
         containerView?.toolTipView.menuControl?.menudelegate = self */
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
     
    }

    
    func addPieChart(){
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
        
        // MARK: Events
        
        pieChartView.tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.handler = PiePanHandler()
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        
        // Total Angle
//        pieChartView.maxAngle = 180
        
        // Start Angle
//        pieChartView.rotationAngle = 180
        
        //   pieChartView.radius = 20
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        let data=[10,200,150,-50,0,-7,140]
        
        let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        //let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i])
            let dataEntry = ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.pieColor()
        
//        chartDataSet.sliceSpace = 10
        
        // chartDataSet.xValuePosition = .outsideSlice
        
        //chartDataSet.yValuePosition = .outsideSlice
        
        chartDataSet.valueTextColor = UIColor.black
        
        chartDataSet.plotType = .Pie
        
//        chartDataSet.gradients = getRadialGradientArray()
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        pieChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
                   else { return }
               
               piePlotOption.valueLinePart2Length = 0.6
        
        //  pieChartView.setPieType = .PieSpinWheel
        
        piePlotOption.drawHoleEnabled = true // Doughnut
        piePlotOption.drawEntryLabelsEnabled = false
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        piePlotOption.maxAngle = 180
        
        piePlotOption.rotationAngle = 270
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 0.6, yAxisDuration: 0.6, easingOption: .linear)
        
        // HelperFunctions.rotateAndPositionMid(chart: pieChartView)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        plotBackup.append(pieChartView.plotOptions)
        
        chartInstance.append(pieChartView)
        
    }
    
    func getRadialGradientArray() -> [RadialGradient] {
        
        let gradient1 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[0]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient2 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[1]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient3 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[2]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient4 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[3]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient5 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[4]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        let gradient6 = RadialGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[5]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], startCenter: CGPoint.zero, startRadius: 10, endCenter: CGPoint.zero, endRadius: 20)
        return [gradient1, gradient2, gradient3, gradient4, gradient5, gradient6]
    }
    
    func getLinearGradientArray() -> [LinearGradient] {
        
        let gradient1 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[0]], positions: [0.3,0.8], options: [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient2 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[1]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient3 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[2]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient4 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[3]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient5 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[4]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        let gradient6 = LinearGradient(colors: [UIColor.cyan, ChartColorTemplates.pieColor()[5]], positions: [0.3,0.8], options:  [.drawsBeforeStartLocation, .drawsAfterEndLocation], start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        
        return [gradient1, gradient2, gradient3, gradient4, gradient5, gradient6]
    }
    
    
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
        level += 1
        
        //Chart Input Data
        let pieChartView = containerView!.chartView.chart
        
       
        // MARK: Events
        
        pieChartView.tapEventListener?.handler = SliceOutHandler() //RotateAndHighlightHandler()   //CustomHandler()
        pieChartView.tapEventListener?.isEnabled = true
        pieChartView.tapEventListener?.delaysTouchesBegan = true
        
        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        pieChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        pieChartView.panEventListener?.handler = PiePanHandler()
        pieChartView.panEventListener?.cancelsTouchesInView = false
        
        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        pieChartView.touchEventsEnabled = false
        //  pieChartView.rotationEnabled = false
        
        // chartview?.usePercentValuesEnabled=true
        
        // MARK: Data
        
        let data=[100,200,150,50,80,170,140]
        
        //let dataLabel = ["Vincent Herbert","John Britto","David Flashing","Maxwell Schwartz","Lela Donovan","Susan Juliet","Carl Lewis"]
        let dataLabel = ["Proposal/Price Quote","Qualification","Negotiation/Review","Initial Offer","Prospect","Closed Won","Needs Analysis"]
        
        var piedata:[ChartDataEntry]=[]
        
        for i in 0..<data.count {
//            let dataEntry = ChartDataEntry(value: Double(data[i]),label: dataLabel[i]+String(level))
            let dataEntry = ChartDataEntry(xString: dataLabel[i]+String(level), y: Double(data[i]), data: nil)
            piedata.append(dataEntry)
        }
        
        let chartDataSet = ChartDataSet(values: piedata, label: "Checking")
        //chartDataSet.drawValuesEnabled = false
        // chartDataSet.sliceSpace=2.0
        
        //Custom Colors can be assigned
        chartDataSet.colors=ChartColorTemplates.colorful()
        
        chartDataSet.plotType = .Pie
        
        let chartData = ChartData(dataSet: chartDataSet)
        
        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        chartDataSet.valueTextColor = UIColor.black
        
        pieChartView.data = chartData
        
        
        // MARK: Plot Options
               
               guard let piePlotOption = pieChartView.getPlotOptions(type: .Pie) as? PiePlotOptions
                          else { return }
        
        //  pieChartView.setPieType = .PieSpinWheel
               
       piePlotOption.drawHoleEnabled = false // Doughnut
       piePlotOption.drawEntryLabelsEnabled = false
       piePlotOption.centerLabelEnabled = true
        
        piePlotOption.arrowShow = false
        
        piePlotOption.patternEnabled = false
        
        piePlotOption.outerCircleEnabled = false
        
        piePlotOption.innerCircleEnabled = false
        
        piePlotOption.centerLabelEnabled = false
        
        piePlotOption.maxAngle = 180
        
        piePlotOption.rotationAngle = 180
        
        // MARK: Animate
        
        pieChartView.animate(xAxisDuration: 1.0, easingOption: .linear)
        
        dataBackup.append(pieChartView.data?.copy() as! ChartData)
        
        plotBackup.append(pieChartView.plotOptions)

        chartInstance.append(pieChartView)
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 1.0, easingOption: .linear)
    }
    
    // ===== SWIPE ==== //
    
    open var changeInHeight:CGFloat = 0.10
    
    func swipeRecognized(_ gesture: UISwipeGestureRecognizer)
    {
        
        if gesture.direction == .up
        {
            
            NSLayoutConstraint.deactivate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
            //            self.containerView?.legendHeightFactor = 0.18
            
            //            if self.containerView?.currentOrientation == .Landscape
            //            {
            //                self.containerView?.legendHeightFactor = 0.25
            //            }
            
            self.containerView?.legendHeightFactor = (self.containerView?.legendHeightFactor)! + changeInHeight
            
            self.containerView?.legendViewHeightAnchor  = (self.containerView?.legendView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.legendHeightFactor!)!))!
            
            //            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! - (self.containerView?.legendHeightFactor!)!)
            
            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! - self.changeInHeight)
            
            self.containerView?.chartViewHeightAnchor = (self.containerView?.chartView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.chartHeightFactor!)!))!
            
            
            NSLayoutConstraint.activate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
        }
        else if gesture.direction == .down
        {
            
            
            NSLayoutConstraint.deactivate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
            //            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! + (self.containerView?.legendHeightFactor!)!)
            
            self.containerView?.chartHeightFactor = ((self.containerView?.chartHeightFactor!)! + self.changeInHeight)
            
            
            self.containerView?.chartViewHeightAnchor = (self.containerView?.chartView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.chartHeightFactor!)!))!
            
            
            //            self.containerView?.legendHeightFactor = 0.08
            //            if self.containerView?.currentOrientation == .Landscape
            //            {
            //                self.containerView?.legendHeightFactor = 0.15
            //            }
            
            self.containerView?.legendHeightFactor = (self.containerView?.legendHeightFactor)! - changeInHeight
            
            
            self.containerView?.legendViewHeightAnchor  = (self.containerView?.legendView.heightAnchor.constraint(equalTo: (self.containerView?.heightAnchor)!, multiplier: (self.containerView?.legendHeightFactor!)!))!
            
            
            NSLayoutConstraint.activate([(self.containerView?.legendViewHeightAnchor)!, (self.containerView?.chartViewHeightAnchor)!])
            
        }
        
        UIView.animate(withDuration: 0.5) {
            //             self.containerView?.layoutIfNeeded()
            self.containerView?.chartView.layoutIfNeeded()
            self.containerView?.legendView.layoutIfNeeded()
        }
        
    }
    
    // ===== SWIPE ==== //
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        
        if self.isMovingFromParent {
            
        }
    }
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
 
}

