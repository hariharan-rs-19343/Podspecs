//
//  CustomRoundedStackedBarViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 01/06/22.
//  Copyright © 2022 charts. All rights reserved.
//

import UIKit
import zchart

class CustomRoundedStackedBarViewController: UIViewController,IToolTipEntryGenerator, PlotDelegate, ChartViewDelegate, ShapeFactoryDataSource, RendererDelegate  {
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        let barLayer = BarLayer.getAllBarLayer(chart: chartView)
        
        var layersForX: [Double:[BarLayer]] = [:]
    
        for layer in barLayer {
            
            guard let xVal = layer.chartEntry?.x else {
                continue
            }
            
            if layersForX[xVal] == nil {
                layersForX[xVal] = [BarLayer]()
            }
            
            layersForX[xVal]!.append(layer)
            
        }
        
        (chartView.longPressEventListener?.handler as! CustomRoundedStackedBarLongPressListener).layersForX = layersForX
        
        let cornerRadii = (barChartView?.longPressEventListener?.handler as! CustomRoundedStackedBarLongPressListener).cornerRadii!
        
        for xval in layersForX.keys {
            
            var positiveLayer: BarLayer?
            var bottomPositiveLayer: BarLayer?
            var negativeLayer: BarLayer?
            var topNegativeLayer: BarLayer?
            
            var bottomPositiveFlag = true
            var topNegativeFlag = true
            
            for index in 0..<layersForX[xval]!.count {
                let layer = layersForX[xval]![index]
                
                if bottomPositiveFlag && layer.chartEntry!.y > 0 {
                    bottomPositiveFlag = false
                    bottomPositiveLayer = layer
                }
                
                if layer.chartEntry!.y > 0 {
                    positiveLayer = layer
                }
                
                if topNegativeFlag && layer.chartEntry!.y < 0 {
                    topNegativeFlag = false
                    topNegativeLayer = layer
                }
                
                if layer.chartEntry!.y < 0 {
                    negativeLayer = layer
                }
            }
            
            if negativeLayer == nil && bottomPositiveLayer != nil {
                
                if bottomPositiveLayer == positiveLayer {
                    bottomPositiveLayer!.path = UIBezierPath(roundedRect: bottomPositiveLayer!.barRect!, byRoundingCorners: .allCorners, cornerRadii: cornerRadii).cgPath
                    
                    continue
                }
                else{
                    bottomPositiveLayer!.path = UIBezierPath(roundedRect: bottomPositiveLayer!.barRect!, byRoundingCorners: [.bottomLeft,.bottomRight], cornerRadii: cornerRadii).cgPath
                }
                
            }
        
            if positiveLayer != nil {
        
                positiveLayer!.path = UIBezierPath(roundedRect: positiveLayer!.barRect!, byRoundingCorners: [.topLeft,.topRight], cornerRadii: cornerRadii).cgPath
            
            }
            
            if positiveLayer == nil && topNegativeLayer != nil {
                
                if topNegativeLayer == negativeLayer {
                    topNegativeLayer!.path = UIBezierPath(roundedRect: topNegativeLayer!.barRect!, byRoundingCorners: .allCorners, cornerRadii: cornerRadii).cgPath
                    
                    continue
                }
                else {
                    topNegativeLayer!.path = UIBezierPath(roundedRect: topNegativeLayer!.barRect!, byRoundingCorners: [.topLeft,.topRight], cornerRadii: cornerRadii).cgPath
                }
                
            }
        
            if negativeLayer != nil {
                negativeLayer!.path = UIBezierPath(roundedRect: negativeLayer!.barRect!, byRoundingCorners: [.bottomLeft,.bottomRight], cornerRadii: cornerRadii).cgPath
            }
        }
    }

    
    func shapePath(frame: CGRect, shapeInstance: ShapeProperties, entry: Any?, shapeLayer: CAShapeLayer) -> UIBezierPath {
        let path = CGMutablePath()

        let shapeSize = frame.width
        let shapeHalf = shapeSize / 2.0

        let circlePath = UIBezierPath()

        circlePath.move(to: CGPoint(x: frame.midX, y: frame.minY))
        circlePath.addLine(to: CGPoint(x: frame.midX, y: frame.maxY))
        circlePath.close()
        path.addPath(circlePath.cgPath)

        return UIBezierPath(cgPath: path)
    }

    func updateShapeProperties(frame:CGRect, shapeInstance: ShapeProperties, entry: Any?) {
        guard let entry = entry as? LegendEntry
        else { return }
        
        shapeInstance.resetProperties()

        shapeInstance.size = frame.size
        shapeInstance.shapeType = .custom

        switch entry.label
        {
                case "Company A":
                    shapeInstance.shapeType = .circle
                    shapeInstance.lineDashPhase = 2.0
                    shapeInstance.lineDashLengths = [4.0,8.0]

                case "Company B":
                    shapeInstance.shapeType = .x

                case "Company C":
                    shapeInstance.shapeType = .square

                case "Company D":
                    shapeInstance.shapeType = .custom

                default:
                    shapeInstance.shapeType = .triangle
        }

        shapeInstance.strokeColor = entry.formColor
        shapeInstance.holeColor = UIColor.clear
    }
    
    
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil || (entry?.x.isNaN)! //|| (entry?.y.isNaN)!
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(Double(totalSales)) )
            toolTipEntry1.valueTextColor = UIColor.black
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }

        let barEntry = entry!

        guard let dataSet = barChartView?.data?.getDataSetForEntry(barEntry)
            else { return entries }
        
        guard let barPlotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return []}
    
        if (barPlotOptions.barGroupSelectionEnabled)
        {
            
            for set in (barChartView?.data?.dataSets)!
            {
                if !(set.isVisible)
                {
                    continue
                }
                
                let xEntries = set.entriesForXValue(barEntry.x)
                if xEntries.count <= 0
                {                   //entryForXValue(barEntry.x, closestToY: Double.nan)
                  continue
                }
                
                let entry = xEntries[0]
                
                let toolTipEntry = ToolTipEntry(label: set.label!, value: String((entry.y)))
                toolTipEntry.valueTextColor = (set.colors[0])
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
                
            }
            /*for i in 0 ..< (barEntry.yValues?.count)!
            {
                let toolTipEntry = ToolTipEntry(label: barDataSet.stackLabels[i], value: String((barEntry.yValues?[i])!))
                toolTipEntry.valueTextColor = (set?.colors[i])! //UIColor.blue //curEntry.entryColor
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }*/
        }
        else
        {
            for i in 0..<(dataSet.entryCount)
            {
                let curEntry = dataSet.entryForIndex(i) as! ChartDataEntry
                
                guard let label = curEntry.xString
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: label, value: String((curEntry.y)))
                toolTipEntry.valueTextColor = (dataSet.color(atIndex: 0))
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
            
        }
        
        
        return entries
    }

    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        let formShape = ShapeProperties()
        formShape.customPathDataSource = self
        formShape.shapeType = .triangle
        
        
        containerView?.legend.legendFormCustomEnabled = true
        containerView?.legend.customFormShape = formShape
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        
        containerView?.legend.customPath = { (bound:CGRect) -> CGPath in
            return UIBezierPath(roundedRect: bound, byRoundingCorners: [.allCorners], cornerRadii: CGSize(width: 3.0, height: 3.0)).cgPath
        }
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self //DefaultToolTipEntryGenerator()
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
       // containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
     //   containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = DefaultPanHandler()
        
        // use CustomRoundedStackedBarLongPressListener for custom Rounded stacked bar
        
        barChartView?.longPressEventListener?.handler = CustomRoundedStackedBarLongPressListener()//StackedBarLongPressListener()
        
        (barChartView?.longPressEventListener?.handler as! CustomRoundedStackedBarLongPressListener).cornerRadii = CGSize(width: 6.0, height: 6.0)
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.rendererDelegate = self
        
        
        barChartView?.xAxis.axisTitle = "Items"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.xAxis.labelRotationAngle = 60
        
        
        barChartView?.xAxis.inverted = false
        
        //        let count = 2000+50
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 80
        
        totalSales = 0
        let count = 100
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            var val1 = Double(arc4random_uniform(UInt32(range)) + 3)
    
            var val2 = Double(arc4random_uniform(UInt32(range)) + 3)
       
            var val3 = Double(arc4random_uniform(UInt32(range)) + 3)
          
            var val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            var val5 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            if i == 0
            {
                val1 = Double.nan
            }
            
            if i == 3
            {
                (val1,val3,val5) = (Double.nan,Double.nan,Double.nan)
            }
            
            
                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            if i == 4
            {
                dataEntries2.append(ChartDataEntry(xString: nil, y: val2, data: nil))
            }
            else{
                dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            }
            
            if i == 3
            {
                dataEntries3.append(ChartDataEntry(xString: nil, y: val3, data: nil))
            }
            else{
                dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            }
            
                dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
            
                dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
            totalSales += CGFloat(val1+val2+val3+val4)
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
//        set1.values = dataEntries1
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
    
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4, set5])
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
//        barPlotOptions.roundedCorners = true
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.barWidthPixel = 18
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.maximumBarPixel = 100
        
        barPlotOptions.fitBars = true
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
                barChartView?.xAxis.labelCount = 25
                barChartView?.xAxis.spaceMax = 0.5
                barChartView?.xAxis.spaceMin = 0.5
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barPlotOptions.drawValueAboveBarEnabled = false
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        let animateBlock = getAnimationBlock(chartView: self.barChartView!, duration: 1.0)
        
        CommonUtilities.customAnimation(chart: barChartView!, duration: 1, animationBlock: animateBlock)
        
       
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)
        chartInstance.append(barChartView!)
        
    }
    
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []
    
    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        if (type == .Bar)
        {
            let barPlotOptions = plotOption as! BarPlotOptions
            
            barPlotOptions.isStacked = true
            
            barPlotOptions.barWidth = 0.6
            
            barPlotOptions.barWidthPixel = 18
            
            barPlotOptions.minimumBarPixel = 18
            
            barPlotOptions.barSpacePixel = 5
            
            barPlotOptions.maximumBarPixel = 100
            
            barPlotOptions.fitBars = true
        }
    }
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        barChartView?.lastSelected = nil
        barChartView?.isRotated = true
        barChartView?.plotDelegate = self
        let xOrdinal = barChartView?.xAxis.scaleType == .Ordinal
        barChartView?.xAxis.labelRotationAngle = 0
        for dataset in barChartView!.data!.dataSets
        {
            let yOrdinal = barChartView?.getYAxis(atIndex: dataset.axisIndex)!.scaleType == .Ordinal
            for i in 0..<dataset.entryCount {
                let e = dataset.entryForIndex(i)!
                if (xOrdinal) {
                    e.x = Double.leastNormalMagnitude
                }
                if (yOrdinal) {
                    e.y = Double.leastNormalMagnitude
                }
            }
            dataset.plotType = .Bar
            dataset.notifyDataSetChanged()
        }
        
        barChartView?.data?.reinit()
        barChartView?.notifyPlotUpdated()
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
     
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        plotBackup.removeLast(plotBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
}

extension CustomRoundedStackedBarViewController {
    
    func getAnimationBlock(chartView: ChartViewBase, duration:TimeInterval) -> (() -> Void)
    {
        let animateBlock = { [self] in
            
            if chartView.data == nil
            {
                return
            }
            
            var newLayers = BarLayer.getAllBarLayer(chart: chartView)
            
        
            newLayers = newLayers.sorted(by: {
                (layer1:BarLayer, layer2:BarLayer) -> Bool in
                return (layer1.chartEntry!.x.isNaN ? 0 : layer1.chartEntry!.x) < (layer2.chartEntry!.x.isNaN ? 0 : layer2.chartEntry!.x)
            })
            
            var layerDict:[Double:[BarLayer]] = [:]
            
            var xArray:[Double] = []
            
            for layer in newLayers
            {
                var x = layer.chartEntry!.x
                if (x.isNaN) {
                    x = 0.0
                }
                
                if (!xArray.contains(x)) {
                    xArray.append(x)
                }
                
                var barLayerArray = layerDict[x]
                
                if (barLayerArray == nil) {
                    barLayerArray = []
                }
                barLayerArray?.append(layer)
                layerDict[x] = barLayerArray
            }
                    
            let mapCount = layerDict.count
            
            let intervalBetweenBarLayers = duration / Double(mapCount)
            
            let currentSystemTime = CACurrentMediaTime()
                    
            var mapIndex:Int = 0
            
            for x in xArray {
                let barLayers = layerDict[x]!
                let shapeDelay = (Double(mapIndex) * intervalBetweenBarLayers)
                let shapeDuration = duration -  shapeDelay
                let actualDelay = currentSystemTime + shapeDelay
                
                let baseValue = getBaseValue(chartView: chartView, barLayers: barLayers)
                
                for barLayer in barLayers {
                    
                    let finalPath = UIBezierPath(cgPath: barLayer.path!)// barLayer.path
                                        
                    updateLayerPathForCustomAnim(chartView:chartView, phaseValue: 0.0,indexLayer: barLayer, baseValue:baseValue)
                    
                    performPathAnimForCustomAnim(targetLayer: barLayer, newPath: finalPath, duration: shapeDuration, delay: actualDelay)
                }
                mapIndex = mapIndex + 1
            }
         
        }
        
        return animateBlock
    }
    
    func updateLayerPathForCustomAnim(chartView:ChartViewBase,phaseValue:CGFloat,indexLayer:BarLayer, baseValue:CGFloat)
    {
        if indexLayer.barRect == nil {
            return
        }
        
        let barRect = indexLayer.barRect!
        
        let entry = indexLayer.chartEntry!
        
        var newWidth = barRect.width
        
        var newHeight = barRect.height
        
        var newX =  barRect.origin.x
        
        var newY = barRect.origin.y
                
        if (chartView.isRotated)
        {
            newWidth = phaseValue * barRect.width
            
            if (entry.y >= 0 )
            {
                newX = baseValue.isNaN ? barRect.origin.x : baseValue
            }
            else
            {
                newX = baseValue.isNaN ? (barRect.origin.x + barRect.width) : baseValue
            }
        }
        else
        {
            newHeight = phaseValue * barRect.height
            
            if (entry.y >= 0 )
            {
                newY = baseValue.isNaN ? ( barRect.origin.y + barRect.height) : baseValue
            }
            else
            {
                newY = baseValue.isNaN ?  barRect.origin.y : baseValue
            }
        }
        
        let rect = CGRect(x: newX, y: newY, width: newWidth, height: newHeight)
        
        (chartView.longPressEventListener?.handler as! CustomRoundedStackedBarLongPressListener).customRoundedRect(layer: indexLayer,newRect: rect)
        
//        let path = UIBezierPath(cgPath: indexLayer.path!)//indexLayer.getPath(rect: rect)//UIBezierPath(rect: rect)
//
//        indexLayer.path = path.cgPath
        
        indexLayer.opacity = 1.0
        
        GradientLayerRenderer.updateGradientLayerPath(targetLayer: indexLayer, newPath: indexLayer.path as! CGMutablePath)
        
    }
    
    func performPathAnimForCustomAnim(targetLayer:ChartEntryLayer,newPath:UIBezierPath,duration:TimeInterval, delay:TimeInterval)
    {
        
        let anim = CABasicAnimation(keyPath: "path")
        
        anim.fromValue = targetLayer.path
        
        anim.toValue = newPath.cgPath
        
        anim.duration = duration
        
        anim.timingFunction =  CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        anim.beginTime = delay
        
        anim.fillMode = .forwards
        anim.isRemovedOnCompletion = false
        
        targetLayer.add(anim, forKey: "path")
        
        GradientLayerRenderer.performGradientLayerPathAnimation(targetLayer: targetLayer, newPath: newPath.cgPath as! CGMutablePath, duration: duration)
    }
    
    func getBaseValue(chartView:ChartViewBase, barLayers:[BarLayer]) -> CGFloat {
                
        var baseValue:CGFloat = CGFloat.nan
        var currentBase:CGFloat = CGFloat.zero
        for barLayer in barLayers
        {
            var yVal = barLayer.chartEntry!.y
            let barRect = barLayer.barRect!
            if (yVal.isNaN) {
                yVal = 0.0
            }
            
            if (chartView.isRotated)
            {
                if (yVal >= 0 )
                {
                    currentBase = barRect.origin.x
                    baseValue = (baseValue.isNaN || (currentBase < baseValue )) ? currentBase : baseValue
                }
                else
                {
                    currentBase = barRect.origin.x + barRect.width
                    baseValue = (baseValue.isNaN || (currentBase > baseValue )) ? currentBase : baseValue
                }
            }
            else
            {
                if (yVal >= 0 )
                {
                    currentBase = barRect.origin.y + barRect.height
                    baseValue = (baseValue.isNaN || (currentBase > baseValue )) ? currentBase : baseValue
                }
                else
                {
                    currentBase = barRect.origin.y
                    baseValue = (baseValue.isNaN || (currentBase < baseValue )) ? currentBase : baseValue
                }
            }
        }
        return baseValue
    }
}
