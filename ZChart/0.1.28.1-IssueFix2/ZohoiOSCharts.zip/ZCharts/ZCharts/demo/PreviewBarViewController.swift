//
//  PreviewBarViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 11/09/19.
//  Copyright © 2019 charts. All rights reserved.
//

import UIKit
import zchart

class PreviewBarViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator,RendererDelegate {
    
    var selectionLayer:CAShapeLayer? = nil
    
    func drawOthers(_ chartView: ChartViewBase) {
        print("X Range LOW", barChartView?.lowestVisibleX, " HIGH ", barChartView?.highestVisibleX )
        
        print("Preview X Range LOW", previewBarChartView?.lowestVisibleX, " HIGH ", previewBarChartView?.highestVisibleX )
        
        let minVal = ceil(barChartView!.lowestVisibleX)
        let maxVal = floor(barChartView!.highestVisibleX)
        
        let minTop = CGPoint(x:Double((previewBarChartView?.xAxisRenderer.transformer?.pixelForValues(x: minVal, y: 0).x)!), y: Double(previewBarChartView!.viewPortHandler!.contentTop))
        let minBottom = CGPoint(x:Double((previewBarChartView?.xAxisRenderer.transformer?.pixelForValues(x: minVal, y: 0).x)!), y: Double(previewBarChartView!.viewPortHandler!.contentBottom))
        
        let maxTop = CGPoint(x:Double((previewBarChartView?.xAxisRenderer.transformer?.pixelForValues(x: maxVal, y: 0).x)!), y: Double(previewBarChartView!.viewPortHandler!.contentTop))
        let maxBottom = CGPoint(x:Double((previewBarChartView?.xAxisRenderer.transformer?.pixelForValues(x: maxVal, y: 0).x)!), y: Double(previewBarChartView!.viewPortHandler!.contentBottom))
        
        if selectionLayer == nil {
            //            selectionLayer?.removeFromSuperlayer()
            selectionLayer = CAShapeLayer()
            previewBarChartView?.layer.addSublayer(selectionLayer!)
        }
        
        let cgRect = CGRect(x: minTop.x, y: minTop.y, width: (maxTop.x - minTop.x) , height: (minBottom.y - minTop.y))
        
        let path = UIBezierPath(rect: cgRect)
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        selectionLayer?.path = path.cgPath
        CATransaction.commit()
        
        
        selectionLayer?.fillColor = UIColor.lightGray.withAlphaComponent(0.2).cgColor
        
        
        
        
        
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry as! ChartDataEntry
            
            var label:String
            var value:String
            
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
            
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    
    var previewContainerView:ChartContainer? = nil
    //    var previewContainerView:UIView? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        previewContainerView = ChartContainer()
        self.view.addSubview(previewContainerView!)
        containerView?.translatesAutoresizingMaskIntoConstraints = false
        previewContainerView?.translatesAutoresizingMaskIntoConstraints = false
        
        //        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        //
        //        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        //
        //        self.view.addConstraints(constraint1)
        //        self.view.addConstraints(constraint2)
        
        
        let chartCenterXAnchor = containerView?.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let chartTopAnchor = containerView?.topAnchor.constraint(equalTo: self.view.topAnchor)
        let chartWidthAnchor = containerView?.widthAnchor.constraint(equalTo: self.view.widthAnchor)
        let chartHeightAnchor = containerView?.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.9)
        
        let previewCenterXAnchor = previewContainerView?.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let previewTopAnchor = previewContainerView?.topAnchor.constraint(equalTo: self.containerView!.bottomAnchor)
        let previewWidthAnchor = previewContainerView?.widthAnchor.constraint(equalTo: self.view.widthAnchor)
        let previewHeightAnchor = previewContainerView?.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.1)
        let previewBottomAnchor = previewContainerView?.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        
        NSLayoutConstraint.activate([chartCenterXAnchor!,chartTopAnchor!,chartWidthAnchor!,chartHeightAnchor!, previewCenterXAnchor!, previewTopAnchor!, previewWidthAnchor!, previewHeightAnchor!, previewBottomAnchor!])
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        containerView?.legend.legendEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        //               containerView?.legend.legendEnabled = false
        //               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //        containerView?.legendToolTipToggleEnabled = true
        
        // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        addPreviewBarChart()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        Log.info("Drilled")
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var previewBarChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        barChartView?.rendererDelegate = self
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        //*****************************  Axis Title Font  *******************************//
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        //
        //        barChartView?.rightAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //*****************************  Axis Offset  *******************************//
        
        //        barChartView?.xAxis.yOffset = 10
        //
        //        barChartView?.leftAxis.xOffset = 50
        //
        //        barChartView?.rightAxis.xOffset = 50
        
        //*****************************  Axis Grid Lines  *******************************//
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //        barChartView?.leftAxis.drawGridLinesEnabled = true
        //
        //        barChartView?.leftAxis.gridColor = UIColor.blue
        //
        //        barChartView?.leftAxis.gridLineWidth = 5
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        barChartView?.getYAxis(atIndex: 0)!.visible = false
        
//        barChartView?.xAxis.wordWrapEnabled = false
        
        //  barChartView?.xAxis.autoRotateAngle = 90
        
        //  barChartView?.xAxis.autoRotateEnabled = false
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.xAxis.maxLabelWidth = 20
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        
        //                barChartView?.customScaleEnabled = true
        //                barChartView?.setScaleMinima(1, scaleY: 1)
        //
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //        barChartView?.xAxis.axisTitleEnabled = false
        //        barChartView?.leftAxis.axisTitleEnabled = false
        
        //        barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        //        barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.spaceMax = 0.75
        //        barChartView?.xAxis.spaceMin = 0.75
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        
        //*****************************  Data  *******************************//
        
        totalSales = 0
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = false
        
        let count = 130
        let range = 1200
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        for i in 0..<count {
            
            var lab = "VVian " + String(Double(i+1))
            
            if i > 10
            {
                lab += " Chennai"
            }
            
            if i > 25
            {
                lab += " Runners"
            }
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            //            dataEntries1.append(ChartDataEntry(y: Double(val1),data:lab as AnyObject))
            //            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            if (i == 15 || (i >= 1 && i <= 5) || (i > 25 && i < 30)) && i != 2 {
                dataEntries1.append(ChartDataEntry(xString: nil, y: Double.nan, data: nil))
            }else {
                dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            }
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            if i == 29
            {
                dataEntries1.append(ChartDataEntry(xString: "last", y: Double.nan, data: nil))
            }
            
            totalSales += CGFloat(val1)
            
            
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        /*  let gradient = LinearGradient(colors: [UIColor.cyan, UIColor.blue], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         set1.gradients = [gradient] */
        
        /*    let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
         set2.colors = [ChartColorTemplates.pieColor()[5]]
         
         let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
         set3.colors = [ChartColorTemplates.pieColor()[4]]
         
         let chartData = ChartData(dataSets: [set1, set2, set3]) */
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.fitBars = true
        
        chartData.setDrawValues(true)
        
        barPlotOptions.barWidth = 0.7
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.barCount = 12
        
        
        
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 30
        
        //        chartData.highlightColor = UIColor.blue
        
        barPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        //      upperLimit.lineWidth = 6.0
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //                barChartView?.leftAxis.addLimitLine(upperLimit)
        //                barChartView?.xAxis.addLimitLine(lowerLimit)
        
        //*****************************  Backup  *******************************//
        if barChartView?.data != nil
        {
            dataBackup.append(barChartView?.data?.copy() as! ChartData)
            plotBackup.append(barChartView!.plotOptions)

            chartInstance.append(barChartView!)
        }
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
    }
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        //  chartInstance.append(chartView)
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        barChartView?.xAxis.tickLabelMode = .wordwrap
        
        barChartView?.xAxis.scaleType = ScaleType.Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = ChartColorTemplates.pieColor()
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidth = 0.6
        
        barPlotOptions.minimumBarPixel = 18
        
        
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 12
        
        
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
        
        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        upperLimit.lineColor = NSUIColor.green
        
        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        lowerLimit.lineColor = NSUIColor.red
        
        lowerLimit.lineDashPhase = 2.0
        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
    }
    
    
    
    /*
     override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
     {
     
     super.viewWillTransition(to: size, with: coordinator)
     
     viewChanged = true
     /*  coordinator.animateAlongsideTransition(in: self.containerView, animation: { (UIViewControllerTransitionCoordinatorContext) in
     self.containerView.setNeedsUpdateConstraints()
     }, completion: nil)
     
     coordinator.animate(alongsideTransition: {, completion: <#T##((UIViewControllerTransitionCoordinatorContext) -> Void)?##((UIViewControllerTransitionCoordinatorContext) -> Void)?##(UIViewControllerTransitionCoordinatorContext) -> Void#>) */
     
     //   self.containerView?.legendView.collectionView?.reloadItems(at: (self.containerView?.legendView.collectionView?.indexPathsForVisibleItems)!)
     
     //self.containerView?.legendView.collectionView?.reloadSections(<#IndexSet#>)
     
     coordinator.animate(alongsideTransition: { context in
     // do whatever with your context
     self.containerView?.setNeedsUpdateConstraints()
     //            self.containerView?.legendView.collectionView?.performBatchUpdates({
     //            self.containerView?.legendView.collectionView?.setCollectionViewLayout((self.containerView?.legendView.collectionView?.collectionViewLayout)!, animated: true)
     //            }, completion: nil)
     context.viewController(forKey: UITransitionContextViewControllerKey.from)
     }, completion: nil)
     }
     
     var viewChanged:Bool = false
     
     override func viewWillLayoutSubviews() {
     super.viewWillLayoutSubviews()
     if viewChanged
     {
     //self.containerView?.legendView.collectionView?.collectionViewLayout.invalidateLayout()
     }
     }
     
     override func viewDidLayoutSubviews() {
     super.viewDidLayoutSubviews()
     
     if viewChanged {
     viewChanged = false
     //   self.containerView?.legendView.collectionView?.performBatchUpdates({}, completion: nil)
     }
     }
     */
    
    
    func addPreviewBarChart()
    {
        previewContainerView?.legend.legendEnabled = false
        previewContainerView?.tooltip.tooltipEnabled = false
        previewContainerView?.tooltip.toolTipEntryGenerator = self
        previewContainerView?.title.titleEnabled = false
        
        
        
        
        
        //*****************************  initialize chart  *******************************//
        
        previewBarChartView = previewContainerView?.chartView.chart
        
        
        let myHandler = PreviewBarPanHandler()
        myHandler.parentBarChartView = barChartView
        
        previewBarChartView?.panEventListener?.handler = myHandler
        
        previewBarChartView?.customScaleEnabled = true
        previewBarChartView?.setScaleMinima(1, scaleY: 1)
        previewBarChartView?.data = barChartView?.data?.copy() as! ChartData
        
        
        previewBarChartView?.xAxis.enabled = false
        previewBarChartView?.getYAxis(atIndex: 0)!.visible = false
        previewBarChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        previewBarChartView?.xAxis.scaleType = .Ordinal
        
        //*****************************  Animation  *******************************//
        
        previewBarChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //*****************************  LimitLines  *******************************//
        
        
        
        //*****************************  Other chart properties  *******************************//
        
        previewBarChartView?.chartDescription?.enabled = false
        
        
        
    }
    
}

