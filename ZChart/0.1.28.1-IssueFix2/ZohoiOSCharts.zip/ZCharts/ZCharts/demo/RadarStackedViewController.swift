//
//  RadarStackedViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 29/07/20.
//  Copyright © 2020 charts. All rights reserved.
//

import Foundation

import zchart
import UIKit

class RadarStackedViewController: UIViewController,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
       
        var entries:[ToolTipEntry] = []
              
          if entry == nil
          {
              let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
              
              toolTipEntry1.valueTextColor = UIColor.black
              
              toolTipEntry1.labelFont = UIFont.boldSystemFont(ofSize: 20)
            
              toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
              
              entries.append(toolTipEntry1)
              
              return entries
          }
          
        
        let set = radarChartView.data?.getDataSetForEntry(entry)
        
        for entryIndex in 0..<(set?.entryCount)!
        {
            let entry = set?.entryForIndex(entryIndex)
            let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.xString)!), value: String(describing: entry?.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            toolTipEntry.labelFont = UIFont.boldSystemFont(ofSize: 20)
            
            entries.append(toolTipEntry)
        }

        return entries
    }
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
      // Views Hide Options
       containerView?.title.titleEnabled = false
       containerView?.legend.legendEnabled = true
       containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        containerView?.isAxisChart = false

                
//        containerView?.mainTitleSettings.text = "PieChart"//textSettings//.text = "PieChart"
        
        //addChartTypeAndData
        addPieChart()
    }
    
    
    var radarChartView:ChartViewBase!
    
    func addPieChart(){
        
        //Chart Input Data
         radarChartView = containerView!.chartView.chart
        
        // MARK: Events
        
        let high = RadarHighlightHandler()
        high.pointHighlight = false
        radarChartView.tapEventListener?.handler = high //RotateAndHighlightHandler()   //CustomHandler()
        radarChartView.tapEventListener?.isEnabled = true
        radarChartView.tapEventListener?.delaysTouchesBegan = true
        
//        pieChartView.longPressEventListener?.handler = PieLongPressHandler()
        radarChartView.longPressEventListener?.minimumPressDuration = 0.2
        
        radarChartView.panEventListener?.handler = PiePanHandler()
        radarChartView.panEventListener?.cancelsTouchesInView = false
        
//        pieChartView.touchHandler = RotationTouchHandler() //CustomTouchHandler()  // CustomTouchHandler()
        radarChartView.touchEventsEnabled = false
        
        radarChartView.chartDescription?.enabled = false
        
        radarChartView.xAxis.scaleType = .Ordinal
        radarChartView.xAxis.axisLineColor = UIColor.green
        radarChartView.xAxis.gridColor = UIColor.black
        radarChartView.xAxis.drawAxisLineEnabled = false
        radarChartView.xAxis.maxLabelWidth = 40
        radarChartView.xAxis.labelCount = 40
        
        radarChartView.getYAxis(atIndex: 0)?.labelCount = 5
        radarChartView.getYAxis(atIndex: 0)?.yOffset = 5
//        radarChartView.getYAxis(atIndex: 0)?.axisMaximum = 100
        radarChartView.getYAxis(atIndex: 0)?.axisLineColor = UIColor.blue
        radarChartView.getYAxis(atIndex: 0)?.drawAxisLineEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.drawLabelsEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.drawTopYLabelEntryEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.drawBottomYLabelEntryEnabled = false
        radarChartView.getYAxis(atIndex: 0)?.gridColor = UIColor.gray.withAlphaComponent(0.3)
        
        
//        pieChartView.radius = 130
        
        // MARK: Data
        
        let data = [175,473,540, 100]
        let data1 = [50,273,150,300]
        let data2 = [250,173,350,100]
        
        let dataLabel = ["2014","2015","2016","2017", "2018","2019","2020","2021"]
        
        var dataEntries1:[ChartDataEntry] = []
        var dataEntries2:[ChartDataEntry] = []
        var dataEntries3:[ChartDataEntry] = []
        
        for i in 0..<data.count {
            
            dataEntries1.append(ChartDataEntry(xString: dataLabel[i], y: Double(data[i]), data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: dataLabel[i], y: Double(data1[i]), data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: dataLabel[i], y: Double(data2[i]), data: nil))
        }
        
        
        let chartDataSet = ChartDataSet(values: dataEntries1, label: "Tamil Nadu")
        //chartDataSet.drawValuesEnabled = false
        
        //Custom Colors can be assigned
        chartDataSet.colors = [ChartColorTemplates.joyful()[1]]
        
        chartDataSet.valueTextColor = UIColor.black
        
        chartDataSet.plotType = .Radar
            
        (chartDataSet.dataSetOptions as! LineDataSetOptions).drawFilledEnabled = true
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).fillColor = ChartColorTemplates.joyful()[1].withAlphaComponent(0.3)
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).shapeColors = [ChartColorTemplates.joyful()[1]]
        
//        (chartDataSet.dataSetOptions as! LineDataSetOptions).fillAlpha = 1
        (chartDataSet.dataSetOptions as! LineDataSetOptions).markerInstance.shapeType = .circle
        
        (chartDataSet.dataSetOptions as! LineDataSetOptions).markerInstance.holeColor = UIColor.red
        
        
        let chartDataSet1 = ChartDataSet(values: dataEntries2, label: "Kerala")
        
        //Custom Colors can be assigned
        chartDataSet1.colors = [ChartColorTemplates.joyful()[2]]
        
        chartDataSet1.valueTextColor = UIColor.black
        
        chartDataSet1.plotType = .Radar
            
        (chartDataSet1.dataSetOptions as! LineDataSetOptions).drawFilledEnabled = true
        
        (chartDataSet1.dataSetOptions as! LineDataSetOptions).fillColor = ChartColorTemplates.joyful()[2].withAlphaComponent(0.3)
        
        (chartDataSet1.dataSetOptions as! LineDataSetOptions).shapeColors = [ChartColorTemplates.joyful()[2]]
        
//        (chartDataSet1.dataSetOptions as! LineDataSetOptions).fillAlpha = 1
        
        
        let chartDataSet2 = ChartDataSet(values: dataEntries3, label: "Andhra Pradhesh")
        
        //Custom Colors can be assigned
        chartDataSet2.colors = [ChartColorTemplates.joyful()[3]]
        
        chartDataSet2.valueTextColor = UIColor.black
        
        chartDataSet2.plotType = .Radar
            
        (chartDataSet2.dataSetOptions as! LineDataSetOptions).drawFilledEnabled = true
        
        (chartDataSet2.dataSetOptions as! LineDataSetOptions).fillColor = ChartColorTemplates.joyful()[3].withAlphaComponent(0.3)
        
        (chartDataSet2.dataSetOptions as! LineDataSetOptions).shapeColors = [ChartColorTemplates.joyful()[3]]
        
//        (chartDataSet2.dataSetOptions as! LineDataSetOptions).fillAlpha = 1
        
        
        let chartData = ChartData(dataSets: [chartDataSet, chartDataSet1, chartDataSet2])

        chartData.setDrawValues(true) //To draw values on Pie Sector
        
        radarChartView.data = chartData
        
        // MARK: Plot Options
        
        guard let dialPlotOption = radarChartView.getPlotOptions(type: .Radar) as? DialPlotOptions
                else { return }
        
        
        dialPlotOption.startAngle = 270

        dialPlotOption.maxAngle = 360
        
        dialPlotOption.isStacked = true
        
        
        // MARK: Animate
        
//        radarChartView.animate(yAxisDuration: 0.6, easingOption: .linear)
        
        let animateBlock = RadarViewController.getRadarAnimationBlock(barLineChart: radarChartView!, animationDuration: 1.0)
        CommonUtilities.customAnimation(chart: radarChartView!,duration:1,animationBlock: animateBlock)
    
        chartInstance.append(radarChartView)
        
    }
 
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int)
    {
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
    
    
    func getPostion(selectedPos: String) -> LegendPosition
    {
        var position:LegendPosition = .left
        
        if selectedPos == "left"
        {
            position = .left
        }
        else if selectedPos == "right"
        {
            position = .right
        }
        else if selectedPos == "top"
        {
            position = .top
        }
        else if selectedPos == "bottom"
        {
            position = .bottom
        }
        
        return position
    }
    
    func getTooltipType(selectedPos: String) -> ToolTipType
    {
        
        var tooltipType:ToolTipType = .leftRight
        
        if selectedPos == "leftRight"
        {
            tooltipType = .leftRight
        }
        else if selectedPos == "topDown"
        {
            tooltipType = .Centered
        }
        
        return tooltipType
    }
    
    
    
    
}


