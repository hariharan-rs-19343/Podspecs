//
//  MultiYAxisViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 03/01/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

class MultiYAxisViewController: UIViewController,IToolTipEntryGenerator,ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry as! ChartDataEntry
        
        var set = barChartView?.data?.getDataSetForEntry(barEntry)
        
        if set == nil
        {
            set = barChartView?.data?.dataSets[0]
        }
        
        for i in 0..<(set?.entryCount)!
        {
            let curEntry = set?.entryForIndex(i) as! ChartDataEntry
            
            var label:String
            var value:String
            
            if curEntry.xString != nil
            {
                label = curEntry.xString!
            }
            else{
                label = String(curEntry.x)
            }
            
            if curEntry.yString != nil
            {
                value = curEntry.yString!
            }
            else{
                value = String(curEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label: label , value: value)
            toolTipEntry.valueTextColor = (set?.color(atIndex: 0))!   //UIColor.blue //curEntry.entryColor
            
            entries.append(toolTipEntry)
        }
        
        //  var labels:[String] = ["Label 1","Label 2","Label 3","Label 4","Label 5","Label 6","Label 7","Label 8"]
        
        
        //        for i in 0...7
        //        {
        //            let dummy = ToolTipEntry(label: labels[i], value: String(arc4random_uniform(UInt32(500))))
        //            dummy.valueTextColor = entry.entryColor
        //            entries.append(dummy)
        //        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        //       containerView?.titleView.showView = false
//          containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
        //  containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    var barChartView:ChartViewBase? = nil
    
    func addBarChart()
    {
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = MultiBarPanHandler()
        
        
        
        //        barChartView?.xAxis.labelRotationAngle = 0
        //
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        //
        barChartView?.xAxis.axisTitle = "Years"
        //
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Cost"
        //
        //        barChartView?.rightAxis.axisTitle = "Quantities"
        //
        //        barChartView?.xAxis.wordWrapEnabled = true
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        //
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        //        let count = 2000+50
        let count = 10
        let range = 54
        let range1 = 100
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            let lab = "Item " + String(Double(i+1))
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            
            let val2 = Double(arc4random_uniform(UInt32(range1)) + 3)
            
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            //            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
            
            let val4 = Double(arc4random_uniform(UInt32(range1)) + 3)
            
            
            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.axisIndex = 0
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
        set2.axisIndex = 1
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        set3.axisIndex = 2
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"        
        set4.axisIndex = 3
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        barChartView?.getYAxis(atIndex: 0)!.labelTextColor = ChartColorTemplates.pieColor()[0]
        barChartView?.getYAxis(atIndex: 0)!.axisLineColor = ChartColorTemplates.pieColor()[0]
        barChartView?.getYAxis(atIndex: 0)?.axisDependency = .right
        
        barChartView?.getYAxis(atIndex: 1)!.labelTextColor = ChartColorTemplates.pieColor()[1]
        barChartView?.getYAxis(atIndex: 1)!.axisLineColor = ChartColorTemplates.pieColor()[1]
        barChartView?.getYAxis(atIndex: 1)?.axisDependency = .left
//
        _ = barChartView?.createYAxis(axisIndex: 2)
        barChartView?.getYAxis(atIndex: 2)?.axisDependency = .right
        barChartView?.getYAxis(atIndex: 2)!.labelTextColor = ChartColorTemplates.pieColor()[2]
        barChartView?.getYAxis(atIndex: 2)!.axisLineColor = ChartColorTemplates.pieColor()[2]

        _ = barChartView?.createYAxis(axisIndex: 3)
        barChartView?.getYAxis(atIndex: 3)?.axisDependency = .right
        barChartView?.getYAxis(atIndex: 3)!.labelTextColor = ChartColorTemplates.pieColor()[3]
        barChartView?.getYAxis(atIndex: 3)!.axisLineColor = ChartColorTemplates.pieColor()[3]
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Company A"
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Company B"
        barChartView?.getYAxis(atIndex: 2)!.axisTitle = "Company C"
        barChartView?.getYAxis(atIndex: 3)!.axisTitle = "Company D"
//        barChartView?.getYAxis(atIndex: 3)?.visible = false
        let chartData = ChartData(dataSets: [set1, set2, set3, set4])
        
//        chartData.barWidth = 0.175
        
//        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)

        
//        chartData.groupSpacePixel = 15
//        chartData.barSpacePixel = 5
//        chartData.barWidthPixel = 20
//        
//        chartData.fitBars = true
        
        barChartView?.data = chartData
        
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.groupSpacePixel = 20
        
        barPlotOptions.minimumBarPixel = 18
        
        barPlotOptions.maximumBarPixel = 100
        
        barPlotOptions.fitBars = true
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        
//        barChartView?.xAxis.axisMinimum = 0
//        barChartView?.xAxis.axisMaximum = 10//chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false

        
        barChartView?.xAxis.labelCount = 7
        
//        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
        
    }
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
   /* func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
//        barChartView?.getYAxis(atIndex: 1)?.visible = false
//        barChartView?.getYAxis(atIndex: 3)?.visible = true
//        barChartView?.swapAxis(axisIndexA: 1, axisIndexZ: 2)
    }*/
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
//        let groupSpace = 0.2
        
//        let barSpace = 0.025
        
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = MultiBarPanHandler()
        
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Years"+String(level)
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Sales"
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        
        //        for i in 2000..<count {
        for i in 0..<count {
            
            //            let lab = "Item " + String(Double(i+1))
            
            let lab = String((i+2000))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1)))
            
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2)))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
//            dataEntries3.append(ChartDataEntry(y: Double(val3),data:lab as AnyObject))
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
            //            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3)))
            
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            
//            dataEntries4.append(ChartDataEntry(y: Double(val4),data:lab as AnyObject))
            dataEntries4.append(ChartDataEntry(xString: lab, y: Double(val4),data: nil))
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.label = "Company B"
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.label = "Company D"
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSets: [set1,set2])
        
        
//        chartData.barWidth = 0.175
        
//        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        barPlotOptions.groupSpacePixel = 15
        barPlotOptions.barSpacePixel = 5
        barPlotOptions.barWidthPixel = 20
        
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
//        barChartView?.xAxis.axisMinimum = 0
        barChartView?.xAxis.axisMaximum = Double(count) // chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        
        
        barChartView?.xAxis.labelCount = 4
        
//        barChartView?.xAxis.spaceMin = 0.9
        
        barChartView?.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        
        let chart = chartInstance[index]
        
        barChartView = chart
        
        level = index
        
        containerView?.initializeChart(chart: chart)
        
        chart.data = dataBackup[index].copy() as! ChartData
        chart.plotOptions = plotBackup[index]

        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
//        let ChartData = chart.data as! ChartData
        
//        ChartData.groupBars(fromX: 0, groupSpace: ChartData.groupSpace, barSpace: ChartData.barSpace)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
  /*  func chartValueRemoved(chartView: ChartViewBase, entry: [ChartDataEntry]?, index: Int, dataSetRemoved: Bool) {
        
        let axisChart = (chartView as! BarLineChartViewBase)
        let aYxis = axisChart.getYAxis(atIndex: 2)
        let zYxis = axisChart.getYAxis(atIndex: 3)
        
        aYxis?.visible = false
        zYxis?.visible = true
        axisChart.swapAxis(axisIndexA: 2, axisIndexZ: 3)
    }*/
   

}
