//
//  HorizontalStageStackedBarViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 07/03/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import zchart

class HorizontalStageStackedBarViewController: UIViewController, ChartViewDelegate {
    
    let scrollView = UIScrollView()
    
    let firstChartVCView = UIView()
    
    let secondChartVCView = UIView()
    
    let thirdChartVCView = UIView()
    
    let firstChartVC = HorizontalStackedBarViewController1()
    
    let secondChartVC = HorizontalStackedBarViewController2()
    
    let thirdChartVC = HorizontalMultiBarViewController3()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 11.0, *) {
            var safeAreaInsets = view.safeAreaInsets
            if let window = UIApplication.shared.keyWindow {
                safeAreaInsets = window.safeAreaInsets
            }
            
            self.view.frame = CGRect(x: safeAreaInsets.left,
                                     y: safeAreaInsets.top,
                                     width: view.frame.width,
                                     height: view.frame.height - safeAreaInsets.top - safeAreaInsets.bottom)
        } else {
            // Fallback on earlier versions
        }

        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addSubview(scrollView)
        
        if #available(iOS 11.0, *) {
            view.addConstraints([
                scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
        } else {
            // Fallback on earlier versions
        }
        
        var height = view.bounds.height
        
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                height = window.safeAreaLayoutGuide.layoutFrame.height - view.frame.origin.y
            }
        } else {
            // Fallback on earlier versions
        }
//
        
        scrollView.contentSize = CGSize(width: (view.bounds.width / 2.0) * 3, height: height)

        firstChartVCView.frame = CGRect(origin: .zero, size: CGSize(width: (view.bounds.width / 2.0), height: height))
        
        firstChartVC.view.frame.size = firstChartVCView.frame.size
        
        firstChartVCView.addSubview(firstChartVC.view)
        
        secondChartVCView.frame = CGRect(origin: CGPoint(x: (view.bounds.width / 2.0), y: 0.0), size: CGSize(width: (view.bounds.width / 2.0), height: height))
        
        secondChartVC.view.frame.size = secondChartVCView.frame.size
        
        secondChartVCView.addSubview(secondChartVC.view)
        
        thirdChartVCView.frame = CGRect(origin: CGPoint(x: self.view.bounds.width, y: 0.0), size: CGSize(width: (self.view.bounds.width / 2.0), height: height))
        
        thirdChartVC.view.frame.size = thirdChartVCView.frame.size

        thirdChartVCView.addSubview(thirdChartVC.view)
        
        scrollView.addSubview(firstChartVCView)
        scrollView.addSubview(secondChartVCView)
        scrollView.addSubview(thirdChartVCView)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        
        scrollView.contentSize = CGSize(width: (size.width / 2.0) * 3, height: size.height)
        
        
        firstChartVCView.frame = CGRect(origin: .zero, size: CGSize(width: (size.width / 2.0), height: size.height))
        
        firstChartVC.view.frame.size = firstChartVCView.frame.size
        
        secondChartVCView.frame = CGRect(origin: CGPoint(x: (size.width / 2.0), y: 0.0), size: CGSize(width: (size.width / 2.0), height: size.height))
        
        secondChartVC.view.frame.size = secondChartVCView.frame.size
        
        thirdChartVCView.frame = CGRect(origin: CGPoint(x: size.width, y: 0.0), size: CGSize(width: (size.width / 2.0), height: size.height))
        
        thirdChartVC.view.frame.size = thirdChartVCView.frame.size
        
    }
}

class VCFirst: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .red
    }
}

class VCSecond: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .blue
    }
}

class HorizontalStackedBarViewController1: UIViewController,ChartViewDelegate,ShapeFactoryDataSource  {
    
    private func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> CGMutablePath {
        
        let path = CGMutablePath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        containerView = ChartContainer()
        
        self.view.addSubview(containerView!)
        
        containerView?.translatesAutoresizingMaskIntoConstraints = false
        
        if #available(iOS 11.0, *) {
            view.addConstraints([
                containerView!.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                containerView!.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                containerView!.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                containerView!.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
        } else {
            // Fallback on earlier versions
        }
        
        containerView?.chartViewDelegate = self
        
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = false
        containerView?.title.titleEnabled = false
        
        containerView?.legend.legendOrientation = .Vertical
        
        addBarChart()
        
    }
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        barChartView = containerView?.chart//containerView?.initializeChart()
        
        barChartView?.isRotated = true
        
//        barChartView?.tapEventListener?.handler = BarHighlightHandler()
//
        barChartView?.panEventListener?.handler = DefaultPanHandler()//HorizontalStackedBarPanHandler() //CustomHorizontalBarPanHandler()
//
//        barChartView?.longPressEventListener?.handler =  StackedBarLongPressListener()//      HorizontalBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.xAxis.axisTitleEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)?.axisTitleEnabled = false
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.getYAxis(atIndex: 0)?.axisDependency = .right
        
        
        let count = 5
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val5 = Double(arc4random_uniform(UInt32(range)) + 3)

            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))

            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))

            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))

            dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4, set5])
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
//        barPlotOptions.fitBars = true
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 8
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barPlotOptions.minimumBarPixel = 18
        barPlotOptions.maximumBarPixel = 70
        
        barPlotOptions.drawValueAboveBarEnabled = false
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 10
        
        barChartView?.scaleYEnabled = false
        barChartView?.scaleXEnabled = false
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

class HorizontalStackedBarViewController2: UIViewController,ChartViewDelegate,ShapeFactoryDataSource  {
    
    private func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> CGMutablePath {
        
        let path = CGMutablePath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        containerView = ChartContainer()
        
        self.view.addSubview(containerView!)
        
        containerView?.translatesAutoresizingMaskIntoConstraints = false
        
        if #available(iOS 11.0, *) {
            view.addConstraints([
                containerView!.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
                containerView!.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                containerView!.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                containerView!.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
            ])
        } else {
            // Fallback on earlier versions
        }
        
        containerView?.chartViewDelegate = self
        
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = false
        containerView?.title.titleEnabled = false
        
        containerView?.legend.legendOrientation = .Vertical
        
        addBarChart()
        
    }
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        barChartView = containerView?.chart//containerView?.initializeChart()
        
        barChartView?.isRotated = true
        
//        barChartView?.tapEventListener?.handler = BarHighlightHandler()
//
        barChartView?.panEventListener?.handler = DefaultPanHandler()//HorizontalStackedBarPanHandler() //CustomHorizontalBarPanHandler()
//
//        barChartView?.longPressEventListener?.handler =  StackedBarLongPressListener()//      HorizontalBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = false
        
        barChartView?.xAxis.enabled = false
        
        barChartView?.getYAxis(atIndex: 0)?.axisTitleEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        let count = 5
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val5 = Double(arc4random_uniform(UInt32(range)) + 3)

            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))

            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))

            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))

            dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
            
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        set4.dataSetOptions = BarDataSetOptions()
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        set5.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSets: [set1])
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.isStacked = true
        
//        barPlotOptions.fitBars = true
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.barSpacePixel = 8//(((8 * 3) + 20 + (18 * 3)) / 2) - 9
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barPlotOptions.minimumBarPixel = 18
        barPlotOptions.maximumBarPixel = 70
        
        barPlotOptions.drawValueAboveBarEnabled = false
        barChartView?.getYAxis(atIndex: 0)?.axisDependency = .right
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 10
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

class HorizontalMultiBarViewController3: UIViewController,ChartViewDelegate,ShapeFactoryDataSource  {
    
    func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> CGMutablePath {
        
        let path = CGMutablePath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = false
        
        containerView?.legend.legendOrientation = .Vertical
        
        addBarChart()
    }

    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        
        barChartView = containerView?.chart//containerView?.initializeChart()
        
        barChartView?.isRotated = true
        
//        barChartView?.tapEventListener?.handler = BarHighlightHandler()
//
        barChartView?.panEventListener?.handler = DefaultPanHandler()//HorizontalMultiBarPanHandler()
        
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.xAxis.axisTitleEnabled = false
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = false
        
        barChartView?.xAxis.tickLabelMode = .forced
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        barChartView?.xAxis.scaleType = .Ordinal
        barChartView?.xAxis.enabled = false
        
        barChartView?.getYAxis(atIndex: 0)?.axisDependency = .right

        totalSales = 0
        
        let count = 5
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []

        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: Double(val2), data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
            
            
            totalSales += CGFloat(val1)
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.label = "Company A"
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        //        set1.gradients = [gradient1]
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[5]]
        set2.label = "Company B"
        set2.plotType = .Bar
        set2.dataSetOptions = BarDataSetOptions()
        //        set2.gradients = [gradient6]
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.colors = [ChartColorTemplates.pieColor()[1]]
        set3.label = "Company C"
        set3.plotType = .Bar
        set3.dataSetOptions = BarDataSetOptions()
        //        set3.gradients = [gradient2]
        
        let chartData = ChartData(dataSets: [set1, set2, set3])
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        barPlotOptions.barWidthPixel = 18
        
        barPlotOptions.isStacked = true
        
        barPlotOptions.barSpacePixel = 8
        
        barPlotOptions.minimumBarPixel = 18
        barPlotOptions.maximumBarPixel = 70
        
//        barPlotOptions.fitBars = true
        
        barPlotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.xAxis.labelCount = 10
        
        barChartView?.scaleYEnabled = false
        barChartView?.scaleXEnabled = false
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
//        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 1.0)
//        CommonUtilities.customAnimation(chart: barChartView!, duration: 1, animationBlock: animateBlock)
        
        barChartView?.chartDescription?.enabled = false
        
    }
}
