//
//  MariMekkoChartViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 22/08/22.
//  Copyright © 2022 charts. All rights reserved.
//

import UIKit
import zchart

class MariMekkoChartViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate,CustomTicksDelegate {
    
    func getTickSizeforEntry(axis: AxisBase, value: Double, chart: ChartViewBase) -> CGSize {
        
        let position = CGPoint(x: 0, y: 0)
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
       
        var size = textLayer.frame.size
        
        size.height += size.height + 5.0
        
        return size
    }
    
    var prevPrecentageLayer: CALayer? = nil
    var prevTectLayer: CALayer? = nil
    
    var labelFont = NSUIFont.systemFont(ofSize: 10.0)
    var labelColor = NSUIColor.gray.withAlphaComponent(0.9)
    
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text:String, chart: ChartViewBase) -> TickLayer {
        
        let midX = position.x
        
        let sizeValue = BarHelperFunctions.getXPoint(chart: chart, value: value)
        
        var position = position
        
        position.x = sizeValue
        
        let tickLayer = TickLayer()
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        if let precentVal = BarHelperFunctions.precentageOfXEntry(chart: chart, value: value) {
            
            let text = String(precentVal)+"%"
        
            let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
            
            if prevPrecentageLayer == nil || !(prevPrecentageLayer!.frame.intersects(textLayer.frame)) {
            
                tickLayer.addSublayer(textLayer)
            
                prevPrecentageLayer = textLayer
            }
        }
        
        position.x = midX
        position.y += (size.height - axis.labelFont.lineHeight)
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
    
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        
        if prevTectLayer == nil || !(prevTectLayer!.frame.intersects(textLayer.frame)) {
            
            tickLayer.addSublayer(textLayer)
        
            prevTectLayer = textLayer
        }
        
        return tickLayer
    }

    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        let set = mekkoChartView?.data?.getDataSetForEntry(entry)
        
        if entry == nil || set == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        guard let plotOptions = (mekkoChartView?.getPlotOptions(type: .Bubble) as? BubblePlotOptions)
        else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            let allEntriesAtIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: mekkoChartView!)
            
            for tooltipEntry in allEntriesAtIndex
            {
                let set = mekkoChartView?.data?.getDataSetForEntry(tooltipEntry)
                let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: tooltipEntry.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
            }
        }
        else{
            let set = mekkoChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            
        }
        
        
        return entries
    }
    
    let offSet = 10.0
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        guard let chartData = chartView.data,
              let xStringArr = chartData.xString else {
            return
        }
        
        let trans = chartView.getTransformer(axisIndex: chartData.dataSets[0].axisIndex)
        
        var prevLabel: CALayer? = nil
        
        ExtraLayer.removeExtraLayer(chart: chartView)
        
        for x in 0..<xStringArr.count {
            
            let (startVal,sizeVal) = BarHelperFunctions.getCategoryToSizeForEntryXValue(chart: chartView, value: Double(x))
            
            var position = CGPoint(x: startVal + (sizeVal / 2), y: 0.0)
            
            trans.pointValueToPixel(&position)
            
            position.y = chartView.contentRect.origin.y - offSet - labelFont.lineHeight / 2.0
            
            let text = String(Double(sizeVal))
            
            let labelAttrs = [NSAttributedString.Key.font: labelFont,
                              NSAttributedString.Key.foregroundColor: labelColor ]
            
            let extraLayer = ExtraLayer()
            
            let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
            
            if prevLabel == nil || !(prevLabel!.frame.intersects(textLayer.frame)) {
                
                extraLayer.addSublayer(textLayer)
            
                chartView.layer.addSublayer(extraLayer)
                
                prevLabel = textLayer
            }
        }
        
        prevTectLayer = nil
        
        prevPrecentageLayer = nil
    }
    
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer:CAShapeLayer) -> UIBezierPath {
        
        let size = shapeInstance.size.width
        
        let shapeFrame = CGRect(x: point.x - (size/2), y: point.y - (size/2), width: size, height: size)
        
        let path = UIBezierPath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addScatterChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    func readDataFromJson() -> [[Double]]
    {
        var finalData:[[Double]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        for rowArray in dataArray
                        {
                            var row:[Double] = []
                            for element in rowArray
                            {
                                let val = element as! Double
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    var mekkoChartView:ChartViewBase? = nil
    
    func addScatterChart()
    {
        
        mekkoChartView = containerView?.chart
        
        mekkoChartView?.xAxis.customTickEnabled = true

        mekkoChartView?.xAxis.tickDelegate = self
        
        mekkoChartView?.extraTopOffset = labelFont.lineHeight + offSet
        
        mekkoChartView?.rendererDelegate = self
        
        mekkoChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        mekkoChartView?.panEventListener?.handler = StackedBarPanHandler()
        //
        //        scatterChartView?.panEventListener?.handler = ScatterPanHandler()
        //
        //        scatterChartView?.longPressEventListener?.handler = ScatterLongPressHandler()
        
        mekkoChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        mekkoChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        mekkoChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        mekkoChartView?.xAxis.labelPosition = .bottom
        
        mekkoChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        mekkoChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
//        bubbleChartView?.xAxis.axisMinimum = 0
        
        mekkoChartView?.xAxis.drawGridLinesEnabled = false
        
        mekkoChartView?.chartDescription?.enabled = false
        
        mekkoChartView?.xAxis.granularity = 1.0
        
        mekkoChartView?.xAxis.scaleType = .Ordinal
        
        mekkoChartView?.xAxis.tickLabelMode = .auto
        
        mekkoChartView?.xAxis.labelCount = 10
        
        mekkoChartView?.xAxis.labelRotationAngle = 60
        
        mekkoChartView?.xAxis.valueFormatter = ValueFormatter(chart: mekkoChartView!)
        
        mekkoChartView?.xAxis.inverted = false
        
        let count = 6
        let range = 100
        let sizeRange = 3000
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []

        var sizeArray = [700,100,300,600,100,100,50,1200,600,700,500]
        for i in 0..<count {
            
            
            let lab = "200" + String(i+1)
            
            let xString = "Item " + String(i+1)
            let yString = "Furniture " + String(i+1)
            let val1 = arc4random_uniform(UInt32(range)) + 3
            var size1 = arc4random_uniform(UInt32(range)) + 3
           
//            if i == 0 || i == 4
//            {
            dataEntries1.append(ChartDataEntry(xString: xString, y: Double(val1), size: CGFloat(sizeArray[i]), data: nil))
//            }
            let val2 = arc4random_uniform(UInt32(range)) + 103
            
//            if i > 0 && i < 3
//            {
            dataEntries2.append(ChartDataEntry(xString: xString, y: Double(val2), size: CGFloat(sizeArray[i]), data: lab as AnyObject))
//            }
            
            let val3 = arc4random_uniform(UInt32(range)) + 203

//            if i == 0 || i == 4
//            {
            dataEntries3.append(ChartDataEntry(xString: xString, y: Double(val3), size: CGFloat(sizeArray[i]), data: lab as AnyObject))
//            }
            
            
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Mekko
        /*
        let dataOptions = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOptions.shapeProperties
        shape.holeColor = ChartColorTemplates.pieColor()[2]
        shape.shapeType = .circle
        shape.lineWidth = 2
        */
        let gradient6 = LinearGradient(colors: [ChartColorTemplates.pieColor()[2], ChartColorTemplates.pieColor()[2].withAlphaComponent(0.5)], positions: [0.2,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
        //        set1.gradients = [gradient6]
        
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Mekko
        /*
        let dataOptions1 = set2.dataSetOptions as! AxisChartDataSetOptions
        let shape1 = dataOptions1.shapeProperties
        shape1.holeColor = ChartColorTemplates.pieColor()[1]
        shape1.shapeType = .triangle
        shape1.lineWidth = 2
        */
        
        let set3  = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.colors = [ChartColorTemplates.pieColor()[3]]
        set3.plotType = .Mekko
        /*
        let dataOptions2 = set3.dataSetOptions as! AxisChartDataSetOptions
        let shape2 = dataOptions2.shapeProperties
        shape2.holeColor = ChartColorTemplates.pieColor()[3]
        shape2.shapeType = .custom
        shape2.customPathDataSource = self
        shape2.lineWidth = 2
        */
        
        
        
        let chartData = ChartData(dataSets: [set1,set2,set3])
        chartData.setDrawValues(false)
        chartData.setValueFont(NSUIFont.systemFont(ofSize: 12))
        
        mekkoChartView?.data = chartData
        
        
        let plotOptions = (mekkoChartView?.getPlotOptions(type: .Mekko) as! BarPlotOptions)
        plotOptions.barWidth = 1
        plotOptions.isStacked = true
        plotOptions.stackSpacing = 5.0
        plotOptions.barSpacePixel = 5
//        plotOptions.barWidthPixel = 10
        plotOptions.stackedPercentEnabled = true
        plotOptions.drawValueCenteredEnabled = true
        plotOptions.isdrawLabelsEnabled = true
        
//        mekkoChartView?.xAxis.spaceMin = 0.5
//        mekkoChartView?.xAxis.spaceMax = 0.5
        
        
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        /*  let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
         upperLimit.lineColor = NSUIColor.black
         upperLimit.shapeProperties = ShapeProperties()
         
         upperLimit.limitValueTextColor = UIColor.white
         upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
         
         upperLimit.shapeProperties?.holeColor = UIColor.white
         upperLimit.shapeProperties?.shapeType = .custom
         upperLimit.shapeProperties?.shapeSize = 8
         upperLimit.shapeProperties?.lineWidth = 2
         upperLimit.shapeProperties?.customPathDataSource = self
         
         let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerLimit.lineColor = NSUIColor.red
         
         lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerLimit.lineDashPhase = 2.0
         lowerLimit.lineDashLengths = [1.0, 2.0]
         
         let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerRightLimit.lineColor = NSUIColor.red
         
         lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerRightLimit.lineDashPhase = 2.0
         lowerRightLimit.lineDashLengths = [1.0, 2.0]
         
         
         //      upperLimit.lineWidth = 6.0
         
         let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
         xLimit.lineColor = NSUIColor.red
         
         xLimit.lineDashPhase = 2.0
         xLimit.lineDashLengths = [1.0, 2.0]
         
         //        lowerLimit.lineWidth = 6.0
         
         scatterChartView?.leftAxis.addLimitLine(upperLimit)
         //            lineChartView?.rightAxis.addLimitLine(lowerLimit)
         //        lineChartView?.xAxis.addLimitLine(xLimit)
         
         
         //        lineChartView?.rightAxis.addLimitLine(lowerRightLimit)*/
        
        
        
//        mekkoChartView?.animate(xAxisDuration: 0.6,yAxisDuration: 0.6)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.mekkoChartView!, duration: 0.5)

        CommonUtilities.customAnimation(chart: mekkoChartView!, duration: 0.6, animationBlock: animateBlock)
        
        dataBackup.append(mekkoChartView?.data?.copy() as! ChartData)
        chartInstance.append(mekkoChartView!)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        /*     level += 1
         
         scatterChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         
         scatterChartView?.chartActionListener = self
         
         scatterChartView?._tapEventListener?.handler = LineHighlightHandler()
         
         scatterChartView?._panEventListener?.handler = LinePanHandler()
         
         scatterChartView?._longPressEventListener?.handler = LineLongPressHandler()
         
         scatterChartView?._pinchEventListener?.handler = ZoomingPinchHandler()
         
         scatterChartView?.rightAxis.enabled = false
         
         scatterChartView?.leftAxis.drawGridLinesEnabled = false
         
         scatterChartView?.xAxis.labelPosition = .bottom
         
         scatterChartView?.leftAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.axisMinimum = 0
         
         scatterChartView?.xAxis.drawGridLinesEnabled = false
         
         scatterChartView?.chartDescription?.enabled = false
         
         scatterChartView?.xAxis.granularity = 1.0
         //        lineChartView?.xAxis.granularityEnabled = true
         
         //        let count = 2000+50
         let count = 12
         let range = 54
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = false
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1, set2,set3])
         chartData.setDrawValues(false)
         
         
         scatterChartView?.data = chartData
         
         //lineChartView?.xAxis.spaceMax = 0.5
         scatterChartView?.xAxis.spaceMin = 0.9
         
         
         
         scatterChartView?.animate(xAxisDuration: 1.0)
         
         dataBackup.append(scatterChartView?.data?.copy() as! ChartData)
         chartInstance.append(scatterChartView!)*/
        
    }
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {
        
        /* if true     //velocity > 1  //&& (Int(end)!-Int(start)!) == 1
         {
         //            level += 1
         //
         //        lineChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         //
         //        lineChartView?.chartActionListener = self
         //
         //        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
         //
         //        lineChartView?._panEventListener?.handler = LinePanHandler()
         //
         //        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
         //
         //        lineChartView?.rightAxis.enabled = false
         //
         //        lineChartView?.leftAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.xAxis.labelPosition = .bottom
         //
         //        lineChartView?.leftAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.chartDescription?.enabled = false
         //
         //        lineChartView?.xAxis.granularity = 1.0
         //        //        lineChartView?.xAxis.granularityEnabled = true
         //
         //        //        let count = 2000+50
         let count = 12
         let range = 150
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i%12] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i%12] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i%12] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = true
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1])
         chartData.setDrawValues(false)
         
         
         chartView.data = chartData
         
         
         
         
         //        //lineChartView?.xAxis.spaceMax = 0.5
         //        lineChartView?.xAxis.spaceMin = 0.9
         //
         //
         //
         //        lineChartView?.animate(xAxisDuration: 1.0)
         
         //            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
         //            chartInstance.append(lineChartView!)
         }
         else if velocity < -3  //&& Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
         {
         if level > 0
         {
         level = level-1
         
         let chart = chartInstance[level]
         
         scatterChartView = chart as! LineChartView
         
         chart.data = dataBackup[level].copy() as! ChartData
         
         dataBackup.removeLast(dataBackup.count-1 - level)
         
         chartInstance.removeLast(chartInstance.count-1 - level)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 1.0)
         }
         }*/
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


open class ExtraLayer: CALayer {
    
    public static func removeExtraLayer(chart: ChartViewBase) {
        
        
        if let layers = chart.layer.sublayers {
            for layer in layers {
                
                if layer.isKind(of: ExtraLayer.self) {
                    
                    layer.removeFromSuperlayer()
                }
            }
        }
    }
    
}
