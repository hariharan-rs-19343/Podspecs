//
//  ScatterViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 29/03/18.
//  Copyright © 2018 charts. All rights reserved.
//


import UIKit
import zchart

class ScatterViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate {
    
    /*func drawOthers(_ chartView: ChartViewBase) {
     
     let barLineChart = chartView as! BarLineChartViewBase
     if (lineChartView?.datasetSelected)!
     {
     let index = lineChartView?.lastSelectedHigh?.dataSetIndex
     
     if index != nil{
     LineHelperFunctions.magnifyDataSet(chart: lineChartView!, dataSetIndex: index!)
     }
     }
     
     // width for single point
     var currentWidth:CGFloat
     if barLineChart.leftAxis.enabled
     {
     currentWidth = barLineChart.getTransformer(forAxis: .left).valueToPixelMatrix.a
     }
     else{
     currentWidth = barLineChart.getTransformer(forAxis: .right).valueToPixelMatrix.a
     }
     if currentWidth < 0.34
     {
     currentWidth = 0.34
     }
     
     for layer in LineLayer.getAllDataSetLayer(chart: chartView)
     {
     if ((layer.lineDataSet?.lineWidth)!*2) > currentWidth
     {
     layer.lineWidth = currentWidth/2
     }
     }
     
     }
     
     
     func shapePath(point: CGPoint, shapeInstance: ShapeProperties) -> UIBezierPath {
     
     return UIBezierPath()
     }
     
     func limitLineShapePath(shapeFrame: CGRect, shapeInstance: ShapeProperties) -> UIBezierPath {
     
     let path = UIBezierPath()
     
     path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
     
     path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
     
     path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
     
     path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
     
     path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
     
     return path
     }*/
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        let set = scatterChartView?.data?.getDataSetForEntry(entry)
        
        if entry == nil || set == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        guard let plotOptions = scatterChartView?.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
            else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            let allEntriesAtIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: scatterChartView!)
            
            for tooltipEntry in allEntriesAtIndex
            {
                let set = scatterChartView?.data?.getDataSetForEntry(tooltipEntry)
                let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: tooltipEntry.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
            }
        }
        else{
            let set = scatterChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        addChartOrientationSwapButton()
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addScatterChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var scatterChartView:ChartViewBase? = nil
    
    func addScatterChart()
    {
        scatterChartView = containerView?.chart
        scatterChartView?.plotDelegate = self
        
        //        scatterChartView?.rendererDelegate = self
        
        /// Handlers
        scatterChartView?.tapEventListener?.handler = ScatterHighlightHandler()
        
        scatterChartView?.panEventListener?.handler = ScatterPanHandler()
        
        scatterChartView?.longPressEventListener?.handler = ScatterLongPressHandler()
        
        scatterChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        
        scatterChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        scatterChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        scatterChartView?.xAxis.labelPosition = .bottom
        scatterChartView?.xAxis.axisTitle = "Movies"
        
        scatterChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        scatterChartView?.getYAxis(atIndex: 0)!.axisTitle = "Box Office (in Millions)"
        
        scatterChartView?.xAxis.drawGridLinesEnabled = false
        
        scatterChartView?.xAxis.granularity = 1.0
        
        scatterChartView?.setScaleMinima(2.0, scaleY: 1.0)
        
        
        
        scatterChartView?.chartDescription?.enabled = false
        scatterChartView?.scaleXEnabled = true
//        scatterChartView?.scaleYEnabled = true
        
        
//        scatterChartView?.xAxis.scaleType = .Ordinal
        
        scatterChartView?.xAxis.tickLabelMode = .forced
        
        scatterChartView?.xAxis.labelRotationAngle = 60
        
        scatterChartView?.getYAxis(atIndex: 0)!.scaleType = .Linear
        
        scatterChartView?.xAxis.inverted = true
        
        //        scatterChartView?.xAxis.setTimeScaleType(type: .Auto, forcedType: TimeScaleIntervalType.ABSQUARTER)
        
        scatterChartView?.xAxis.labelCount = 14
        
        let valueFormatter = ValueFormatter(chart:self.scatterChartView!)
//        scatterChartView?.xAxis.valueFormatter = valueFormatter
        
        let dollarFomatter = NumberFormatter()
        dollarFomatter.numberStyle = .currency
//        dollarFomatter.
        let ff  = ValueFormatter(chart:self.scatterChartView!)
        ff.formatter = dollarFomatter
//        scatterChartView?.getYAxis(atIndex: 0)!.valueFormatter = ff
        
        
        scatterChartView?.xAxis.spaceMinPixel = 50
        scatterChartView?.xAxis.spaceMaxPixel = 50
        
        for axis in (scatterChartView?.getYAxisArray())!
        {
            axis.spaceMinPixel = 50
            axis.spaceMaxPixel = 50
        }
        
        
        let count = 2
        let range = 100
        
        //        let count = 130
        //        let range = 1200
        
        let movieData = readStringDataFromJson()
    
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        var index = 1.0
        for dict in movieData
        {
            dataEntries1.append(ChartDataEntry(x: index, y: Double(dict["Box office"] as! String)!, data: nil))
            index += 1.0
        }
        
        /*
        let array: [Double] = [940053012.0, 103.0, 3000.0, 2.0, 460.0, 2.0, 100000.0, 7.0, 25000.0, 1.0, 1500.0, 1.0, 2000.0, 1.0, 1.0, 1.0, 13000.0, 2.0, 67899.0, 1.0, 1500000.0, 1.0, 7682627.0, 1.0, 1500.0,  1.0, 0.0, 1.0, 0.0, 1.0, 10.0, 5.0, 376.0, 2.0, 0.0, 50.0, 86686868.0, 2.0, 36925874.0, 1.0, 0.0, 1.0, 0.0, 1.0, 558.0, 1.0, 159753.0, 1.0, 0.0, 3.0, 1000.0, 1.0, 538.6703685738099, 1.0, 0.0, 1.0, 258.0, 1.0, 0.0, 1.0, 2662.0, 1.0, 2089488.0, 3.0, 8228822828.0, 2.0, 4000.0, 2.0, 5000.0, 1.0, 0.0, 1.0, 1056.0, 3.0, 200.0, 1.0, 29.0, 1.0, 0.0, 2.0, 15734.0, 3.0, 0.0, 1.0, 10000000.0, 2.0, 0.0, 1.0, 100000.0, 1.0, 231654.0, 2.0, 9500000.0, 1.0, 28168.0, 503.0, 672795.0, 2.0, 3310851.0, 5.0, 1551.0, 3.0, 73737.0,  1.0, 66.0, 1.0, 1.394333009942421e+16, 3.0, 565.0, 1.0, 100.0, 1.0]
        
        for i in 0..<array.count - 1 {
            
            if (i + 1) % 2 == 0 {
                print(array[i])
                continue
            }
            
            dataEntries1.append(ChartDataEntry(x: array[i], y: array[i+1], data: nil))
        }
        */
        
        
        
//
//        for i in 0..<count {
//
//            // Ordinal Both
//            /*  var lab = "Item " + String(i+1)
//
//             var lab1 = "Map " + String(i+1)
//
//             var val1 = arc4random_uniform(UInt32(range)) + 3
//
//             if i == 0
//             {
//             dataEntries1.append(ChartDataEntry(xString: nil, yString: lab1, data: nil))
//             }
//
//             if i % 7 == 0
//             {
//             //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//
//             dataEntries1.append(ChartDataEntry(xString: lab, yString: lab1, data: nil))
//
//             //            val1 = arc4random_uniform(UInt32(range)) + 3
//
//             lab1 = "Mapvc " + String(i+1)
//
//             //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//             dataEntries1.append(ChartDataEntry(xString: lab, yString: lab1, data: nil))
//
//             lab1 = "Mapdc " + String(i+1)
//
//             //            val1 = arc4random_uniform(UInt32(range)) + 3
//             }
//             //            if i < 100
//             //            {
//             //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
//             //            }
//             if i > 7
//             {
//             lab1 = "Map 5"
//             }
//             if i == 3
//             {
//             dataEntries1.append(ChartDataEntry(xString: nil, yString: lab1, data: nil))
//             }
//             else{
//             dataEntries1.append(ChartDataEntry(xString: lab, yString: lab1, data: nil))
//             }
//
//             if i == 9
//             {
//             //                dataEntries1.append(ChartDataEntry(xString: nil, yString: lab1, data: nil))
//             //                dataEntries1.append(ChartDataEntry(xString: lab, yString: "won", data: nil))
//             //                dataEntries1.append(ChartDataEntry(xString: lab, yString: "don", data: nil))
//             }
//
//             if i > 7
//             {
//             lab1 = "gap 5 " + String(i)
//             //                lab = " product " + String(i)
//             }
//             dataEntries2.append(ChartDataEntry(xString: lab, yString: lab1, data: nil))
//
//             //            let val2 = arc4random_uniform(UInt32(range)) + 103
//             //
//             //            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
//
//             var val3 = arc4random_uniform(UInt32(range)) + 203
//
//             if i % 11 == 0
//             {
//             dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
//
//             val3 = arc4random_uniform(UInt32(range)) + 203
//
//             dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
//
//             val3 = arc4random_uniform(UInt32(range)) + 203
//             }
//             dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: lab as AnyObject))
//             */
//
//            // x - Ordinal , y - number
//            var lab = "Item " + String(i+1)
//
//            var lab1 = "Map " + String(i+1)
//
//            var val1 = arc4random_uniform(UInt32(range)) + 3
//
//            if i % 7 == 0
//            {
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//
//                val1 = arc4random_uniform(UInt32(range)) + 3
//
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
//
//            }
//
//            if i % 3 == 0 || i % 4 == 0 || i % 5 == 0 || i % 6 == 0
//            {
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//                //                dataEntries1.append(ChartDataEntry(xString: lab, y: Double.nan, data: nil))
//
//            }
//            else{
//                val1 = arc4random_uniform(UInt32(range)) + 3
//                dataEntries1.append(ChartDataEntry(xString: lab, y: Double(val1), data: nil))
//            }
//
//            let val2 = arc4random_uniform(UInt32(range)) + 103
//
//            if i == 0
//            {
//                dataEntries2.append(ChartDataEntry(xString: "checking", y: Double(val2), data: nil))
//            }
//            var val3 = arc4random_uniform(UInt32(range)) + 203
//
//            if i % 11 == 0
//            {
//                dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
//
//                val3 = arc4random_uniform(UInt32(range)) + 203
//
//                dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
//
//                val3 = arc4random_uniform(UInt32(range)) + 203
//            }
//            dataEntries3.append(ChartDataEntry(xString: lab, y: Double(val3), data: nil))
//
//
//            // x - number , y - ordinal
//
//            /*let newnum = Double(i + 900)
//             var lab = "Item " + String((i%5)+1)
//
//             dataEntries1.append(ChartDataEntry(x: newnum, yString: lab, data: nil))*/
//
//            // x - number , y - number
//
//            /*let newnum = Double(i + 900)
//             var lab = "Item " + String((i%5)+1)
//
//             var val1 = Double(arc4random_uniform(UInt32(range)) + 3)
//             dataEntries1.append(ChartDataEntry(x: newnum, y: val1, data: nil))*/
//
//        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[6])
        set1.plotType = .Scatter
        
        
        /* let gradient6 = LinearGradient(colors: [ChartColorTemplates.pieColor()[5], ChartColorTemplates.pieColor()[6]], positions: [0.2,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         set1.gradients = [gradient6]*/
        
        let dataOption = set1.dataSetOptions as! AxisChartDataSetOptions
        
        let shape = dataOption.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape.shapeType = .circle
//        shape.size = CGSize(width: 10.0, height: 10.0)
        shape.lineWidth = 2
//        shape.strokeColor = .black
        shape.holeColor = ChartColorTemplates.pieColor()[6]
        
        
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[2])
        set2.plotType = .Scatter
        
        let dataOption2 = set2.dataSetOptions as! AxisChartDataSetOptions
        
        let shape1 = dataOption2.shapeProperties
        //        shape1.holeColor = UIColor.yellow
        shape1.shapeType = .circle
//        shape1.size = CGSize(width: 10.0, height: 10.0)
        shape1.lineWidth = 2
        
        
        /*let gradient2 = LinearGradient(colors: [UIColor.lightGray, ChartColorTemplates.pieColor()[2]], positions: [0,0.5], options: .drawsAfterEndLocation, start: CGPoint(x: 0.5, y: 0), end: CGPoint(x: 0.5, y: 1))
         set2.gradients = [gradient2] */
        
        let set3  = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[4])
        set3.plotType = .Scatter
        
        let dataOption3 = set3.dataSetOptions as! AxisChartDataSetOptions
        
        let shape2 = dataOption3.shapeProperties
        //        shape2.holeColor = nil
        shape2.shapeType = .circle
//        shape2.size = CGSize(width: 10.0, height: 10.0)
        shape2.lineWidth = 2
        
        
        
        
        
        
        let chartData = ChartData(dataSets: [set1])
        chartData.setDrawValues(true)
        
        scatterChartView?.data = chartData
        
        guard let plotOptions = scatterChartView?.getPlotOptions() as? AxisChartPlotOptions
            else { return }
        
        plotOptions.minimumShapeSizeInPixel = 8
        plotOptions.maximumShapeSizeInPixel = 50
        
        plotOptions.maxWidthZoomRestrictionPixel = 50
        
        
//        scatterChartView?.xAxis.spaceMin = 0.5
//        scatterChartView?.xAxis.spaceMax = 0.5
        
        
        
        //lineChartView?.xAxis.spaceMax = 0.5
        
        /*  let upperLimit = ChartLimitLine(limit: 250, label: "UpperLimit")
         upperLimit.lineColor = NSUIColor.black
         upperLimit.shapeProperties = ShapeProperties()
         
         upperLimit.limitValueTextColor = UIColor.white
         upperLimit.limitValueFont = NSUIFont.systemFont(ofSize: 10)
         
         upperLimit.shapeProperties?.holeColor = UIColor.white
         upperLimit.shapeProperties?.shapeType = .custom
         upperLimit.shapeProperties?.shapeSize = 8
         upperLimit.shapeProperties?.lineWidth = 2
         upperLimit.shapeProperties?.customPathDataSource = self
         
         let lowerLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerLimit.lineColor = NSUIColor.red
         
         lowerLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerLimit.lineDashPhase = 2.0
         lowerLimit.lineDashLengths = [1.0, 2.0]
         
         let lowerRightLimit = ChartLimitLine(limit: 120, label: "LowerLimit")
         lowerRightLimit.lineColor = NSUIColor.red
         
         lowerRightLimit.limitValueFont = NSUIFont.systemFont(ofSize: 8)
         
         lowerRightLimit.lineDashPhase = 2.0
         lowerRightLimit.lineDashLengths = [1.0, 2.0]
         
         
         //      upperLimit.lineWidth = 6.0
         
         let xLimit = ChartLimitLine(limit: 0, label: "LowerLimit")
         xLimit.lineColor = NSUIColor.red
         
         xLimit.lineDashPhase = 2.0
         xLimit.lineDashLengths = [1.0, 2.0]
         
         //        lowerLimit.lineWidth = 6.0
         
         scatterChartView?.leftAxis.addLimitLine(upperLimit)
         //            lineChartView?.rightAxis.addLimitLine(lowerLimit)
         //        lineChartView?.xAxis.addLimitLine(xLimit)
         
         
         //        lineChartView?.rightAxis.addLimitLine(lowerRightLimit)*/
        
        
        
        
        //        scatterChartView?.animate(xAxisDuration: 2.0)
        //        ScatterHelperFunctions.customAnimation(chart: scatterChartView!, animationDuration: 3)
        
//        let animateBlock = getAnimationBlock()
//
//        CommonUtilities.customAnimation(chart: scatterChartView!,duration:1,animationBlock: animateBlock)
        
        dataBackup.append(scatterChartView?.data?.copy() as! ChartData)
        chartInstance.append(scatterChartView!)
        
    }
    
    func readDataFromJson() -> [[Int]]
    {
        var finalData:[[Int]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        for rowArray in dataArray
                        {
                            var row:[Int] = []
                            for element in rowArray
                            {
                                let val = element as! Int
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    func readStringDataFromJson() -> [[String: AnyObject]]
    {
        var finalData:[[String: AnyObject]] = [[:]]
        
        if let urlPath = Bundle.main.url(forResource: "MCU", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [[String: AnyObject]] {
                        return jsonDict
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    var uniqueXVal:[Double] = []
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = scatterChartView!
        
        let animateBlock = { [unowned self] in
            
            if chart.data == nil
            {
                return
            }
            
            let contentRect = (self.scatterChartView?.viewPortHandler.contentRect)!
            
            for layer in ScatterLayer.getAllScatterLayer(chart: self.scatterChartView!)
            {
                layer.opacity = 1
            }
            
            guard let plotLayer = CommonHelperFunctions.getPlotViewLayer(chart: self.scatterChartView!)
                else { return }
            
            let transparent = UIColor.clear.cgColor
            let opaque = UIColor.black.cgColor
            
            let maskLayer = CAGradientLayer()
            
            maskLayer.frame =  CGRect(x: contentRect.minX, y: contentRect.minY, width: contentRect.width, height: contentRect.height)
            
            maskLayer.colors = [opaque, opaque, transparent,transparent]
            
            maskLayer.locations = [0,0,0,0]
            
            maskLayer.startPoint = chart.isRotated ? CGPoint(x: 0.5, y: 0) : CGPoint(x: 0, y: 0.5)
            maskLayer.endPoint = chart.isRotated ? CGPoint(x:0.5, y:1) : CGPoint(x:1, y:0.5)
            
            plotLayer.mask = maskLayer
            
            
            let barEntryAnimator = Animator()
            
            barEntryAnimator.updateBlock = { [unowned barEntryAnimator] in
                
                let phaseX = NSNumber(value: barEntryAnimator.phaseX)
                
                let nextValue = barEntryAnimator.phaseX + 0.3 > 1 ? 1 : NSNumber(value: (barEntryAnimator.phaseX + 0.3))
                
                maskLayer.locations = [0,phaseX,nextValue,1]
                
            }
            
            barEntryAnimator.stopBlock = { [unowned barEntryAnimator] in
                barEntryAnimator.updateBlock = nil
            }
            
            barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
        }
        
        return animateBlock
    }
    
    /* func getAnimationBlock() -> (() -> Void)
     {
     
     let totalDuration = TimeInterval(1)
     
     let chart = scatterChartView!
     
     let animateBlock = {
     
     if chart.data == nil
     {
     return
     }
     
     let allLayers = ScatterLayer.getAllScatterLayer(chart: self.scatterChartView!)
     
     var xMaxValue = floor((self.scatterChartView?.getXMinAndMaxValue().max)!)
     
     var entryCount = 0
     
     self.uniqueXVal.removeAll()
     
     for set in (self.scatterChartView?.data?.dataSets)!
     {
     for i in 0..<(set.entryCount)
     {
     let entryX = (set.entryForIndex(i)?.x)!
     
     if entryX.isNaN
     {
     continue
     }
     
     if  !(self.uniqueXVal.contains(entryX)) &&  entryX <= xMaxValue
     {
     self.uniqueXVal.append(entryX)
     entryCount += 1
     }
     else if entryX > xMaxValue{
     break
     }
     }
     }
     
     self.uniqueXVal  = self.uniqueXVal.sorted(by: { (a, b) -> Bool in
     a < b
     })
     
     
     let heightPercent = Double(4)
     
     let duration:Double = ((heightPercent) / (Double(entryCount - 1) + heightPercent)) * totalDuration
     
     
     let barEntryAnimator = Animator()
     
     
     barEntryAnimator.updateBlock = {
     
     for entryIndex in 0..<entryCount
     {
     
     
     let startTime = (( duration / Double(heightPercent)) * Double(entryIndex))
     
     let endTime = startTime + duration
     
     let currentTime = (barEntryAnimator.phaseX) * totalDuration
     
     if currentTime > endTime  {
     
     self.updateLayerPath(phaseValue: 1, index: entryIndex, allLayers: allLayers)
     
     } else if currentTime < startTime {
     
     } else {
     
     let difference = currentTime - startTime
     
     var percent = CGFloat(difference/duration)
     
     if percent > 1
     {
     percent = 1
     }
     
     self.updateLayerPath(phaseValue: percent,index:entryIndex,allLayers: allLayers)
     
     }
     
     }
     
     }
     barEntryAnimator.stopBlock = {
     
     }
     
     barEntryAnimator.animate(xAxisDuration: totalDuration, easingOption: .linear)
     }
     
     return animateBlock
     }
     
     
     func updateLayerPath(phaseValue:CGFloat,index:Int,allLayers:[ChartEntryLayer])
     {
     for layer in ScatterLayer.getAllScatterLayer(chart: scatterChartView!)
     {
     if (layer.chartEntry?.x)! == (self.uniqueXVal[index])
     {
     layer.opacity = 1
     
     let shapeSize = (layer.scatterDataSet?.shapeProperties.shapeSize)!
     let shapeHalf = shapeSize / 2.0
     
     let point = layer.shapePoint!
     
     let circlePath = UIBezierPath(arcCenter: CGPoint(x: point.x,y: point.y), radius: shapeHalf * phaseValue, startAngle: CGFloat(0), endAngle:CGFloat(Double.pi * 2), clockwise: true)
     
     layer.lineWidth = (layer.scatterDataSet?.shapeProperties.lineWidth)!*phaseValue
     
     layer.path = circlePath.cgPath
     
     GradientLayerRenderer.updateGradientLayerPath(targetLayer: layer, newPath: circlePath)
     }
     }
     
     }*/
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var dataBackup:[ChartData] = []
    
    var level:Int = 0
    
    var chartInstance:[ChartViewBase] = []
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        level += 1
        
        scatterChartView = containerView?.chart
        
        scatterChartView?.tapEventListener?.handler = ScatterHighlightHandler()
        
        scatterChartView?.panEventListener?.handler = ScatterPanHandler()
        
        scatterChartView?.longPressEventListener?.handler = ScatterLongPressHandler()
        
        scatterChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        scatterChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        scatterChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        scatterChartView?.xAxis.labelPosition = .bottom
        
        scatterChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        //        scatterChartView?.leftAxis(atIndex: 0).axisMinimum = 0
        
        //        scatterChartView?.xAxis.axisMinimum = 0
        
        scatterChartView?.xAxis.drawGridLinesEnabled = false
        
        scatterChartView?.chartDescription?.enabled = false
        
        scatterChartView?.xAxis.granularity = 1.0
        
        scatterChartView?.scaleXEnabled = true
        scatterChartView?.scaleYEnabled = false
        
        scatterChartView?.customScaleEnabled = true
        scatterChartView?.setScaleMinima(1, scaleY: 1)
        
        scatterChartView?.xAxis.inverted = false
        
        
        //        scatterChartView?.xAxis.scaleType = .Time
        //        scatterChartView?.xAxis.setTimeScaleType(type: .Auto, forcedType: TimeScaleIntervalType.ABSQUARTER)
        
        scatterChartView?.xAxis.spaceMinPixel = 50
        scatterChartView?.xAxis.spaceMaxPixel = 50
        
        scatterChartView?.getYAxis(atIndex: 0)!.spaceMinPixel = 20
        scatterChartView?.getYAxis(atIndex: 0)!.spaceMaxPixel = 20
        
        let count = 300
        let range = 100
        
        
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        //        let newData =  readDataFromJson()
        //        var inc:UInt32 = 3
        //        for row in newData
        //        {
        //            inc += 1
        //            let val = arc4random_uniform(UInt32(range)) + inc
        //            dataEntries1.append(ChartDataEntry(x: Double(row[0]), y: Double(row[1])))
        //            dataEntries2.append(ChartDataEntry(x: Double(row[0]), y: Double(val)))
        //        }
        
        for i in 900..<(900+count)
        {
            let lab = "200" + String(i+1)
            
            let val1 =       arc4random_uniform(UInt32(range)) + 3 //drand48()
            
            if i <= 910  || i == 905 || i == 907 || i == 910 || i == 911 || i == 920 || i == 922 || i >= 998  // || (i > 903 && i < 940)
            {
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data:  nil))
            }
            else{
                if i == 917 || i == 903 || i == 945 || i == 946 || i == 947
                {
                    dataEntries1.append(ChartDataEntry(x: Double(i), y: Double.nan, data:  nil))
                }
                else{
                    dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data:  nil))
                }
            }
            
            let val2 =   arc4random_uniform(UInt32(range)) + 100 // drand48()
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data:  nil))
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 200
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data:  nil))
            
            //            dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
            
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[3])
        set1.plotType = .Scatter
        
        let dataOption = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOption.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Scatter
        
        let dataOption2 = set2.dataSetOptions as! AxisChartDataSetOptions
        
        let shape1 = dataOption2.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape1.shapeType = .circle
        shape1.size = CGSize(width: 8.0, height: 8.0)
        shape1.lineWidth = 2
        
        let set3 = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        set3.plotType = .Scatter
        
        let dataOption3 = set3.dataSetOptions as! AxisChartDataSetOptions
        
        let shape2 = dataOption3.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape2.shapeType = .circle
        shape2.size = CGSize(width: 8.0, height: 8.0)
        shape2.lineWidth = 2
        
        
        
        
        
        let chartData = ChartData(dataSets: [set1, set2, set3])
        chartData.setDrawValues(false)
        
        scatterChartView?.data = chartData
        
        guard let plotOptions = scatterChartView?.getPlotOptions() as? AxisChartPlotOptions
        else { return }
        
        plotOptions.minimumShapeSizeInPixel = 8
        plotOptions.maximumShapeSizeInPixel = 16
        
        plotOptions.maxWidthZoomRestrictionPixel = 50
        
        
        //        scatterChartView?.xAxis.spaceMin = 0.5
        //        scatterChartView?.xAxis.spaceMax = 0.5
        
        
        
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: scatterChartView!,duration:1,animationBlock: animateBlock)
        
        dataBackup.append(scatterChartView?.data?.copy() as! ChartData)
        chartInstance.append(scatterChartView!)
        
    }
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        scatterChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        CommonHelperFunctions.resizeAxisIfNeeded(chart: chart)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        
        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        let animateBlock = getAnimationBlock()
        
        CommonUtilities.customAnimation(chart: scatterChartView!,duration:1,animationBlock: animateBlock)
        
    }
    
    
    func chartScaled(chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat, velocity: CGFloat, start: String, end: String) {
        
        
        /*      if true     //velocity > 1  //&& (Int(end)!-Int(start)!) == 1
         {
         //            level += 1
         //
         //        lineChartView = containerView?.initializeChart(type: .Line) as! LineChartView
         //
         //        lineChartView?.chartActionListener = self
         //
         //        lineChartView?._tapEventListener?.handler = LineHighlightHandler()
         //
         //        lineChartView?._panEventListener?.handler = LinePanHandler()
         //
         //        lineChartView?._longPressEventListener?.handler = LineLongPressHandler()
         //
         //        lineChartView?.rightAxis.enabled = false
         //
         //        lineChartView?.leftAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.xAxis.labelPosition = .bottom
         //
         //        lineChartView?.leftAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.axisMinimum = 0
         //
         //        lineChartView?.xAxis.drawGridLinesEnabled = false
         //
         //        lineChartView?.chartDescription?.enabled = false
         //
         //        lineChartView?.xAxis.granularity = 1.0
         //        //        lineChartView?.xAxis.granularityEnabled = true
         //
         //        //        let count = 2000+50
         let count = 12
         let range = 150
         
         var dataEntries1: [ChartDataEntry] = []
         var dataEntries2: [ChartDataEntry] = []
         var dataEntries3: [ChartDataEntry] = []
         
         var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
         
         //        for i in 2000..<count {
         for i in 0..<count {
         
         let lab = "Item " + String(Double(i+1))
         
         let val1 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: months[i%12] as AnyObject))
         
         
         let val2 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: months[i%12] as AnyObject))
         
         let val3 = arc4random_uniform(UInt32(range)) + 3
         
         dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), data: months[i%12] as AnyObject))
         
         }
         
         let set1:LineChartDataSet = LineChartDataSet(values: dataEntries1, label: "Set1")
         set1.drawIconsEnabled = false
         set1.setColor(UIColor.green)
         
         let shape = set1.markerInstance
         //shape.holeColor = UIColor.white
         shape.shapeType = .circle
         shape.shapeSize = 8
         shape.lineWidth = 2
         
         set1.setShapeColor(UIColor.red)
         
         set1.lineWidth = 2
         set1.drawShapeEnabled = true
         
         set1.drawFilledEnabled = false
         set1.fillAlpha = 0.3
         set1.fillColor = ChartColorTemplates.pieColor()[5]
         set1.mode = .linear
         
         
         let set2:LineChartDataSet = LineChartDataSet(values: dataEntries2, label: "Set2")
         set2.drawIconsEnabled = false
         set2.setColor(UIColor.red)
         
         set2.setCircleColor(UIColor.black)
         set2.lineWidth = 2
         set2.circleRadius = 3.0
         set2.drawCircleHoleEnabled = false
         set2.drawCirclesEnabled = true
         set2.drawShapeEnabled = false
         
         set2.drawFilledEnabled = false
         set2.fillAlpha = 0.3
         set2.fillColor = ChartColorTemplates.pieColor()[1]
         set2.mode = .linear
         
         let set3:LineChartDataSet = LineChartDataSet(values: dataEntries3, label: "Set3")
         set3.drawIconsEnabled = false
         set3.setColor(UIColor.blue)
         
         set3.setCircleColor(UIColor.black)
         set3.lineWidth = 2
         set3.circleRadius = 3.0
         set3.drawCircleHoleEnabled = false
         set3.drawCirclesEnabled = true
         set3.drawShapeEnabled = false
         
         set3.drawFilledEnabled = false
         set3.fillAlpha = 0.3
         set3.fillColor = ChartColorTemplates.pieColor()[2]
         set3.mode = .linear
         
         
         
         //        let chartData = LineChartData(dataSet: set1)
         let chartData = LineChartData(dataSets: [set1])
         chartData.setDrawValues(false)
         
         
         chartView.data = chartData
         
         
         
         
         //        //lineChartView?.xAxis.spaceMax = 0.5
         //        lineChartView?.xAxis.spaceMin = 0.9
         //
         //
         //
         //        lineChartView?.animate(xAxisDuration: 1.0)
         
         //            dataBackup.append(lineChartView?.data?.copy() as! ChartData)
         //            chartInstance.append(lineChartView!)
         }
         else if velocity < -3  //&& Int(start)! == 0 && Int(end)! == (lineChartView?.data?.maxEntryCountSet?.entryCount)!-1
         {
         if level > 0
         {
         level = level-1
         
         let chart = chartInstance[level]
         
         scatterChartView = chart as! LineChartView
         
         chart.data = dataBackup[level].copy() as! ChartData
         
         dataBackup.removeLast(dataBackup.count-1 - level)
         
         chartInstance.removeLast(chartInstance.count-1 - level)
         
         containerView?.initializeChart(chart: chart)
         
         chart.animate(xAxisDuration: 1.0)
         }
         }*/
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    var orientationFlag = true
    
}

extension ScatterViewController: PlotDelegate {
    
    // MARK: - Chart Orientation Change
    func buttonImage() -> UIImage{
        let themeImage: UIImage!

        if orientationFlag{
            themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        
        return themeImage
    }
    
    func addChartOrientationSwapButton(){
        
        let orientationSwapButton = UIButton(type: .custom)
        
        orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)
        
        orientationSwapButton.setImage(buttonImage(), for: .normal)
        
        orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

        let buttonItem = UIBarButtonItem(customView: orientationSwapButton)
        
        let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true
        
        let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true
        
        self.navigationItem.rightBarButtonItem = buttonItem
    }
    
    @objc func chartOrientationSwap(){
        
        if !orientationFlag{
            
            scatterChartView?.isRotated = false
            
            orientationFlag = true
            
            scatterChartView?.xAxis.tickLabelMode = .forced
            
            scatterChartView?.xAxis.labelRotationAngle = 60
            
            scatterChartView?.xAxis.maxLabelWidth = .infinity
            scatterChartView?.scaleXEnabled = true
            scatterChartView?.scaleYEnabled = false
        }
        else{
            
            scatterChartView?.isRotated = true
            
            scatterChartView?.xAxis.labelPosition = .bottom
            
            scatterChartView?.xAxis.maxLabelWidth = 30
            
            scatterChartView?.xAxis.tickLabelMode = .wordwrap
            
            scatterChartView?.xAxis.labelRotationAngle = 0
            
            scatterChartView?.getYAxis(atIndex: 0)?.labelPosition = .outsideChart
            
            orientationFlag = false
            
            scatterChartView?.scaleXEnabled = false
            scatterChartView?.scaleYEnabled = true
        }
        
        scatterChartView?.notifyPlotUpdated()
        addChartOrientationSwapButton()
        
//        let animateBlock = getAnimationBlock()
//
//        CommonUtilities.customAnimation(chart: scatterChartView!,duration:1,animationBlock: animateBlock)
        scatterChartView?.animate(xAxisDuration: 1, yAxisDuration: 1)
    }
    
    func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
        
        if let plotOptions = (plotOption as? AxisChartPlotOptions) {
            plotOptions.minimumShapeSizeInPixel = 8
            plotOptions.maximumShapeSizeInPixel = 16
            
            plotOptions.maxWidthZoomRestrictionPixel = 50
        }
    }
}
