//
//  NegativeValueStackViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 05/07/18.
//  Copyright © 2018 charts. All rights reserved.
//

import UIKit
import zchart

class NegativeValueStackViewController: UIViewController,IToolTipEntryGenerator, ChartViewDelegate  {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil || (entry?.x.isNaN)! //|| (entry?.y.isNaN)!
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(Double(totalSales)) )
            toolTipEntry1.valueTextColor = UIColor.black
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            toolTipEntry1.labelTextAlignment = .left
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let barEntry = entry!
        
        guard let dataSet = barChartView?.data?.getDataSetForEntry(barEntry)
            else { return entries }
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            
            for set in (barChartView?.data?.dataSets)!
            {
                if !(set.isVisible)
                {
                    continue
                }
                
                guard let entry = set.entryForXValue(barEntry.x, closestToY: Double.nan)
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: set.label!, value: String((entry.y)))
                toolTipEntry.valueTextColor = (set.colors[0])
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
                
            }
            /*for i in 0 ..< (barEntry.yValues?.count)!
             {
             let toolTipEntry = ToolTipEntry(label: barDataSet.stackLabels[i], value: String((barEntry.yValues?[i])!))
             toolTipEntry.valueTextColor = (set?.colors[i])! //UIColor.blue //curEntry.entryColor
             toolTipEntry.labelTextAlignment = .left
             toolTipEntry.valueTextAlignment = .right
             
             entries.append(toolTipEntry)
             }*/
        }
        else
        {
            for i in 0..<(dataSet.entryCount)
            {
                let curEntry = dataSet.entryForIndex(i)!
                
                guard let label = curEntry.xString
                    else { continue }
                
                let toolTipEntry = ToolTipEntry(label: label, value: String((curEntry.y)))
                toolTipEntry.valueTextColor = (dataSet.color(atIndex: 0))
                toolTipEntry.labelTextAlignment = .left
                toolTipEntry.valueTextAlignment = .right
                
                entries.append(toolTipEntry)
            }
            
        }
        
        
        return entries
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self //DefaultToolTipEntryGenerator()
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        // containerView?.legend.legendEnabled = false
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.legendToolTipToggleEnabled = false
        
        //   containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
         containerView?.menuControl?.dataSource = self
         containerView?.menuControl?.menudelegate = self
         
         containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = 0
    
    func addBarChart()
    {
        //   let groupSpace = 0.3
        
        //  let barSpace = 0.03
        
        barChartView = containerView?.chart
//        barChartView = containerView?.initializeChart(type: .HorizontalBar) as! BarChartView
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // HorizontalStackedBarPanHandler() //  StackedBarPanHandler() // BarPanHandler()
        
        barChartView?.longPressEventListener?.handler = StackedBarLongPressListener()
        
        //        barChartView?.xAxis.labelRotationAngle = 0
        //
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        barChartView?.getYAxis(atIndex: 0)!.enabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        //
        barChartView?.xAxis.axisTitle = "Items"
        //
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        //
        //        barChartView?.rightAxis.axisTitle = "Quantities"
        //
//        barChartView?.xAxis.wordWrapEnabled = false
        
        //        barChartView?.leftAxis.xOffset = 10
        
        //        barChartView?.xAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //        barChartView?.leftAxis.axisTitleFont = NSUIFont.boldSystemFont(ofSize: 30)
        
        //      barChartView?.xAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleEnabled = false
        //
        //      barChartView?.leftAxis.axisTitleColor = NSUIColor.red
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        //
        
        
        //        let count = 2000+50
        
        totalSales = 0
        let count = 10
        let range = 540
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        
        
        
        //        for i in 2000..<count {
      /*  for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            let val1 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            
            var stackEntry = ChartDataEntry(xString: lab, yValues: [Double(val1), Double(val2), -Double(val3), Double(val4) , Double(val5)], data: lab as AnyObject)
            
            if i % 5 == 0 {
                stackEntry = ChartDataEntry(xString: lab, yValues: [Double(val1), -Double(val2),-Double(val3), -Double(val4) , -Double(val5)], data: lab as AnyObject)
            }
            
            if i == 3 {
                stackEntry = ChartDataEntry(xString: lab, yValues: [Double.nan, Double(val2), Double.nan, Double(val4) , Double.nan], data: lab as AnyObject)
            }
            
            dataEntries1.append(stackEntry)
            
            totalSales += CGFloat(val1+val2+val3+val4+val5)
            
        } */
        
        var xStrings = ["A","B","C","D","E"]
        
        var val1 = [[Double(12), Double(23), Double.nan, -Double(3) ],
        
         [Double(34), Double(31), -Double(13), -Double(7) ],
        
         [Double(23), Double(9), Double(2), Double.nan ],
        
         [Double.nan, Double(34), Double(3), Double(10) ],
        
        [Double(43), -Double(41), -Double(2), -Double(18) ]]
    
        
        
        for i in 0..<xStrings.count
        {
            dataEntries1.append(ChartDataEntry(xString: xStrings[i], y: val1[i][0], data: nil))
//            if i == 1
//            {
//                dataEntries1.append(ChartDataEntry(xString: xStrings[i], y: 7, data: nil))
//            }
        
            if i != 1
            {
            dataEntries2.append(ChartDataEntry(xString: xStrings[i], y: val1[i][1], data: nil))
            }
            
            if i != 3
            {
            dataEntries3.append(ChartDataEntry(xString: xStrings[i], y: val1[i][2], data: nil))
            }
            
            dataEntries4.append(ChartDataEntry(xString: xStrings[i], y: val1[i][3], data: nil))
//            dataEntries4.append(ChartDataEntry(xString: xStrings[i], y: -7, data: nil))
           
        }

        
       /* var stackEntry1 = ChartDataEntry(xString: "A", yValues: [Double(12), Double(23), -Double(23), -Double(3) ], data: "A" as AnyObject)
        var stackEntry2 = ChartDataEntry(xString: "B", yValues: [Double(34), Double(31), -Double(13), -Double(7) ], data: "B" as AnyObject)
        var stackEntry3 = ChartDataEntry(xString: "C", yValues: [Double(23), Double(9), Double(2), -Double(10) ], data: "C" as AnyObject)
        var stackEntry4 = ChartDataEntry(xString: "D", yValues: [Double(32), Double(34), Double(3), Double(10) ], data: "D" as AnyObject)
        var stackEntry5 = ChartDataEntry(xString: "E", yValues: [Double(43), Double(41), Double(2), Double(18) ], data: "E" as AnyObject)
        dataEntries1.append(stackEntry1)
        dataEntries1.append(stackEntry2)
        dataEntries1.append(stackEntry3)
        dataEntries1.append(stackEntry4)
        dataEntries1.append(stackEntry5)*/
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.colorful()[0]]
        set1.plotType = .Bar
        //        set1.values = dataEntries1
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.colorful()[1]]
        set2.plotType = .Bar
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.colorful()[2]]
        set3.plotType = .Bar
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.colorful()[3]]
        set4.plotType = .Bar
        
        
        let chartData = ChartData(dataSets: [set1, set2, set3, set4])
        
        barChartView?.data = chartData
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.isStacked = true
        
        //    let chartData = ChartData(dataSet: set1)
        plotOptions.barWidth = 0.6
        
        
        plotOptions.barWidthPixel = 18
        
        plotOptions.barSpacePixel = 5
        
        plotOptions.maximumBarPixel = 100
        
        plotOptions.fitBars = true
        
        plotOptions.stackSumValueTextColor = UIColor.red
        
//        plotOptions.stackSumValueFont = NSUIFont.systemFont(ofSize: 17.0)
        
        
//        chartData.stackSpacing = 20
        
        //        let groupSpace = 0.1;
        //        let barSpace = 0.03;
        //        chartData.groupBars(fromX: Double(0.0), groupSpace: groupSpace, barSpace: barSpace)
        //        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        //        barChartView?.data = chartData
        
        //   barChartView?.xAxis.valueFormatter = XAxisFormatter(months: dataPoints)
        //        barChartView?.xAxis.labelPosition = .bottom
        //        barChartView?.xAxis.granularityEnabled = true
        //        barChartView?.xAxis.granularity = 1.0
        //        barChartView?.xAxis.labelCount = 6
        //        barChartView?.xAxis.axisMaximum = 10
        
        //        barChartView?.xAxis.axisMinimum = 0
        
        //        barChartView?.xAxis.axisMaximum = 0+chartData.groupWidth(groupSpace: 0.08, barSpace: 0.03)
        
        //        chartData.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 25
        barChartView?.xAxis.spaceMax = 1.0
        barChartView?.xAxis.spaceMin = 1.0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = false
        
        //        barChartView?.xAxis.axisMinimum = 0
        //        barChartView?.xAxis.axisMaximum = chartData.groupWidth(groupSpace: groupSpace, barSpace: barSpace) * 10 + 0
        //  barChartView?.xAxis.centerAxisLabelsEnabled = true
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        barChartView?.getYAxis(atIndex: 1)!.baseLineEnabled = true
//        barChartView?.leftAxis.baseLine?.lineWidth = 2
        
        //        barChartView?.leftAxis.drawAxisLineEnabled = false
        //        barChartView?.rightAxis.drawAxisLineEnabled = false
        
        //        barChartView?.fitBars = true
        
        //        barChartView?.xAxis.granularity = 0.1
        //        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        plotOptions.drawValueAboveBarEnabled = true
//        barChartView?.xAxis.inverted = true
        //        chartData.highlightColor = UIColor.brown
        
        plotOptions.nonHighlightColor = UIColor.gray.withAlphaComponent(0.5)
        
        
        
        
        //        highlightFullBarEnabled
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        //  XYMarkerView *marker = [[XYMarkerView alloc]
        //        let font = UIFont.systemFont(ofSize: 12.0 )
        
        //        let marker = XYMarkerView(color: UIColor.init(white: 180/255, alpha: 1.0), font: font, textColor: UIColor.white, insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0), xAxisValueFormatter: (barChartView?.xAxis.valueFormatter!)!)
        /*   initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
         font: [UIFont systemFontOfSize:12.0]
         textColor: UIColor.whiteColor
         insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)
         xAxisValueFormatter: _chartView.xAxis.valueFormatter];*/
        
        //        marker.chartView = barChartView;
        //        marker.minimumSize = CGSize(width: 80, height: 40)
        //        barChartView?.marker = marker;
        
        //        let scaleLevel = dataEntries1.count / (barChartView?.xAxis.labelCount)!
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
        
        //        let upperLimit = ChartLimitLine(limit: 45, label: "UpperLimit")
        //        upperLimit.lineColor = NSUIColor.green
        //        //        upperLimit.lineWidth = 6.0
        //
        //        let lowerLimit = ChartLimitLine(limit: 4, label: "LowerLimit")
        //        lowerLimit.lineColor = NSUIColor.red
        //
        //        lowerLimit.lineDashPhase = 2.0
        //        lowerLimit.lineDashLengths = [1.0, 2.0]
        
        //        lowerLimit.lineWidth = 6.0
        
        //        barChartView?.leftAxis.addLimitLine(upperLimit)
        //        barChartView?.xAxis.addLimitLine(lowerLimit)
        
        
    }
    
    var dataBackup:[ChartData] = []
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var chartInstance:[ChartViewBase] = []
    
    var level:Int = 0
    
    func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
        drillPerformed(chartView: chartView, selectedEntry: entry, index: level)
    }
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {
        
        level += 1
        
        barChartView = containerView?.chart
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // BarPanHandler()
        
        barChartView?.longPressEventListener?.handler = StackedBarLongPressListener()
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.axisTitle = "Items"+String(level)
        barChartView?.xAxis.scaleType = .Ordinal
        
        
        
//        barChartView?.xAxis.wordWrapEnabled = true
        
        let count = 30
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = "Product " + String(Double(i+1))
            
            let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val2 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val3 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val4 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            let val5 = Double(arc4random_uniform(UInt32(range)) + 3)
            
            dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
            
            dataEntries2.append(ChartDataEntry(xString: lab, y: val2, data: nil))
            
            dataEntries3.append(ChartDataEntry(xString: lab, y: val3, data: nil))
            
            dataEntries4.append(ChartDataEntry(xString: lab, y: val4, data: nil))
            
            dataEntries5.append(ChartDataEntry(xString: lab, y: val5, data: nil))
        }
        
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Company A")
        set1.colors = [ChartColorTemplates.pieColor()[0]]
        set1.plotType = .Bar
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Company B")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .Bar
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Company C")
        set3.colors = [ChartColorTemplates.pieColor()[2]]
        set3.plotType = .Bar
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Company D")
        set4.colors = [ChartColorTemplates.pieColor()[3]]
        set4.plotType = .Bar
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Company E")
        set5.colors = [ChartColorTemplates.pieColor()[4]]
        set5.plotType = .Bar
        
        let chartData = ChartData(dataSets: [set1,set2,set3,set4,set5])
        
        barChartView?.data = chartData
        
        guard let plotOptions = (barChartView?.getPlotOptions(type: .Bar) as? BarPlotOptions)
        else { return }
        
        plotOptions.isStacked = true
        
        plotOptions.barWidth = 0.6
        
        plotOptions.fitBars = true
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        barChartView?.xAxis.granularity = 1.0
        barChartView?.xAxis.labelCount = 10
        barChartView?.xAxis.spaceMax = 0.5
        barChartView?.xAxis.spaceMin = 0.5
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        
        plotOptions.drawValueAboveBarEnabled = false
        
        
        
        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
        barChartView?.chartDescription?.enabled = false
        
        dataBackup.append(barChartView?.data?.copy() as! ChartData)
        plotBackup.append(barChartView!.plotOptions)

        chartInstance.append(barChartView!)
        
        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
        
        let chart = chartInstance[index]
        
        level = index
        
        barChartView = chart
        
        chart.data = dataBackup[index].copy() as! ChartData
        chart.plotOptions = plotBackup[index]
        
        chart.notifyDataSetChanged(redrawRequired: true)
        
        dataBackup.removeLast(dataBackup.count-1 - index)
        plotBackup.removeLast(plotBackup.count-1 - index)

        chartInstance.removeLast(chartInstance.count-1 - index)
        
        containerView?.initializeChart(chart: chart)
        
        chart.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
    }
    
    
    
    
    
    
}

