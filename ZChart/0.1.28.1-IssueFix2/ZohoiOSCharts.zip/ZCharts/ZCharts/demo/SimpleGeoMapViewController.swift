//
//  SimpleGeoMapViewController.swift
//  ZCharts
//
//  Created by Aravinth T on 26/11/21.
//  Copyright © 2021 charts. All rights reserved.
//

import UIKit
import zchart

class SimpleGeoMapViewController: UIViewController,IToolTipEntryGenerator,RendererDelegate {

    var containerView:ChartContainer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        containerView?.tooltip.tooltipEnabled = true
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        containerView?.title.mainTitleSettings.color = UIColor.red
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .right
        containerView?.legend.type = .continous
        
        addGeoMapChart()
    }
    
    func drawOthers(_ chartView: ChartViewBase) {
        
        if !((mapChartView?.customAnimationInProgress)!)
        {
            HeatMapHelperFunctions.highLightMapEntry(chart: chartView, entry: (chartView.lastSelected != nil && chartView.lastSelected!.count > 0 ) ? chartView.lastSelected![0] : nil)
        }
    }
    
    func readDataFromJson() -> [[AnyObject]]
    {
        if let urlPath = Bundle.main.url(forResource: "simpleGeoData", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[[AnyObject]]] {
                        
                        return (dataArray[0] as [[AnyObject]])
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return [[AnyObject]]()
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let count = mapChartView!.data!.entryCount
            
            let toolTipEntry1 = ToolTipEntry(label: "Total Country", value: String(count))
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            toolTipEntry1.labelTextAlignment = .left
            
            toolTipEntry1.valueTextAlignment = .right
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let mapEntry = entry!
        let set = mapChartView?.data?.getDataSetForEntry(mapEntry)
        let index = set?.entryIndex(entry: mapEntry)

        let labels:[String] = ["Country","Data","Color String"]
        let values:[String] = [(mapEntry.xString!),String((mapEntry.colorValue)!),(mapEntry.colorString ?? "nil")]
   
        
        var valueColor = set?.color(atIndex: index!)
        
        if (mapChartView?.colorAxis.isEnabled)!
        {
            valueColor = mapChartView!.colorAxis.getColor(entry: mapEntry)
        }
        
        for i in 0...2
        {
            let dummy = ToolTipEntry(label: labels[i], value: values[i])
            dummy.valueTextColor = valueColor!
            
            dummy.labelTextAlignment = .left
            
            dummy.valueTextAlignment = .right
            entries.append(dummy)
        }
        
        return entries
    }
    
    var mapChartView:ChartViewBase? = nil
    
    func addGeoMapChart()
    {
        
        //*****************************  initialize chart  *******************************//
        
        //Chart Input Data
        mapChartView = containerView?.chart
        
        //*****************************  Handlers  *******************************//
        
        mapChartView?.tapEventListener?.handler = GeoMapHighlightHandler()

        mapChartView?.panEventListener?.handler = DefaultPanHandler()
//
//        mapChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
//
        mapChartView?.pinchEventListener?.handler =  DefaultPinchHandler() // HeatMapPinchHandler()        //DefaultPinchHandler()
        
        mapChartView?.pinchZoomEnabled = true
        
        mapChartView?.rendererDelegate = self
        
        
        //*****************************  Axis Title  *******************************//
        
        mapChartView?.xAxis.axisTitleEnabled = false
        
        mapChartView?.getYAxis(atIndex: 0)!.axisTitleEnabled = false
        
        //***********************  other Axis Properties  *******************************//
        
        mapChartView?.getYAxis(atIndex: 1)!.enabled = false
        
//        mapChartView?.xAxis.wordWrapEnabled = false

        //  mapChartView?.xAxis.autoRotateAngle = 90
        
        //  mapChartView?.xAxis.autoRotateEnabled = false
        
        mapChartView?.xAxis.labelPosition = .bottom
        
        mapChartView?.xAxis.granularityEnabled = true
        
        mapChartView?.xAxis.granularity = 1.0
        
        mapChartView?.scaleXEnabled = true
        mapChartView?.scaleYEnabled = true
//        mapChartView?.pinchZoomEnabled = true
        
        mapChartView?.xAxis.scaleType = .Ordinal
        mapChartView?.getYAxis(atIndex: 0)!.scaleType = .Ordinal
        
        
        mapChartView?.xAxis.drawAxisLineEnabled = false
        mapChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        mapChartView?.xAxis.drawGridLinesEnabled = false
        mapChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
        
        
       
        
        /*let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: mapChartView!)
        mapChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter*/
        
        //*****************************  Data  *******************************//
        
        var dataEntries1: [ChartDataEntry] = []
        
        let newData =  readDataFromJson()
        var inc:UInt32 = 0
        for row in newData
        {
            inc += 1
            var xString = row[0] as? String
            var yString = row[0] as? String
            var colorValue = row[1] as? Double
                        
            let mapEntry = ChartDataEntry(xString: xString, yString: yString, data:nil )
            mapEntry.colorValue = colorValue
            dataEntries1.append(mapEntry)
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set 1")
        
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        
        set1.plotType = .GeoHeatMap
        
        let chartData = ChartData(dataSets: [set1])
        
        chartData.setDrawValues(true)
        
        chartData.paddingInPixels = 5
    
        mapChartView?.data = chartData
        
        let geoMapPlotOptions = mapChartView?.getPlotOptions() as! GeoMapPlotOptions
        
        geoMapPlotOptions.scope = "world-india"
        
        geoMapPlotOptions.projection = "geoMercator"
                
        var excludeKeys:[AnyObject] = []
        
        excludeKeys.append("ata" as AnyObject)
        excludeKeys.append("sgs" as AnyObject)
        excludeKeys.append("atf" as AnyObject)
        excludeKeys.append("flk" as AnyObject)
        
        geoMapPlotOptions.excludeAreas = excludeKeys
        
        geoMapPlotOptions.allAreas = false
        
//        let animateBlock = getAnimationBlock()
//
//        CommonUtilities.customAnimation(chart: mapChartView!,duration:1,animationBlock: animateBlock)
        
       
//        chartData.highlightColor = UIColor.blue
        
//        chartData.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
      
        //*****************************  Other chart properties  *******************************//
        
        mapChartView?.chartDescription?.enabled = false
    
        let colorAxis = (mapChartView?.colorAxis)!
        colorAxis.enabled = true
        
        //Linear Type
        colorAxis.type = .linear
//        colorAxis.stops = [0,3000]
        colorAxis.colors = [hexStringToUIColor(hex:"#004f9b"),hexStringToUIColor(hex: "#bfd8f2")]
//        colorAxis.colors = [hexStringToUIColor(hex: "#A5D6FE"),hexStringToUIColor(hex: "#336A93")] //[UIColor.blue,UIColor.yellow,UIColor.red,UIColor.green,UIColor.purple,UIColor.orange,UIColor.magenta]
//
        
//        colorAxis.type = .range
//        let range1 = Range(from: 0, to: 3000)
//        colorAxis.rangeArray = [range1]
//        colorAxis.colors = [hexStringToUIColor(hex: "#A5D6FE"),hexStringToUIColor(hex: "#336A93")]
        //Range Type
        /*  colorAxis.type = .range
         let range1 = Range(from: 0, to: 250)
         let range2 = Range(from: 250, to: 500)
         let range3 = Range(from: 500, to: 750)
         let range4 = Range(from: 750, to: 1000)
         colorAxis.rangeArray = [range1,range2,range3,range4]
         colorAxis.colors = [UIColor.blue,UIColor.yellow,UIColor.red,UIColor.green] */
        
        //*****************************  Backup  *******************************//
//        if mapChartView?.data != nil
//        {
//            dataBackup.append(mapChartView?.data?.copy() as! ChartData)
//            chartInstance.append(mapChartView!)
//        }
      
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
