//
//  BoxPlotOverviewChartViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 24/04/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import zchart

class BoxPlotOverviewChartViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry!
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.overview.overviewEnabled = true
        containerView?.overviewView.offsets.leftOffset = 50.0
        containerView?.overviewView.offsets.rightOffset = 50.0
        containerView?.overviewView.offsets.bottomOffset = 10
        rangeSliderConfigation()
        
        addBarChart()
        
        
    }
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart//containerView?.initializeChart()
        
//        barChartView?.isOverviewChart = true
        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        barChartView?.xAxis.drawGridLinesEnabled = false
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.xAxis.labelRotationAngle = 60
        
        barChartView?.xAxis.tickLabelMode = .auto
        
        barChartView?.xAxis.customTickEnabled = true
        
        barChartView?.xAxis.axisLabelOffsets.marginTop = 0
        barChartView?.xAxis.axisLabelOffsets.marginBotom = 0
        barChartView?.xAxis.axisLabelOffsets.marginLeft = 10
        barChartView?.xAxis.axisLabelOffsets.marginRight = 10
        
        barChartView?.xAxis.axisTitleOffsets.marginTop = 0
        barChartView?.xAxis.axisTitleOffsets.marginBotom = 0
        barChartView?.xAxis.axisTitleOffsets.marginLeft = 10
        barChartView?.xAxis.axisTitleOffsets.marginRight = 10
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = true
        barChartView?.scaleYEnabled = false
        
        barChartView?.xAxis.scaleType = .Ordinal
        
        barChartView?.xAxis.inverted = false
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = true
        
        barChartView?.getYAxis(atIndex: 0)!.baseLineEnabled = false
        barChartView?.getYAxis(atIndex: 0)!.baseLine?.baseValue = 400
        barChartView?.getYAxis(atIndex: 0)!.resizeEnabled = false
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 20
        let range = 10
        
        var dataEntries1: [ChartDataEntry] = []
        
        var dataEntries2: [ChartDataEntry] = []
        
 
          for i in 0..<count {
            
              let lab = "W"+String(Double(i+1))
              
              let val1 = Double(arc4random_uniform(UInt32(range)) + 15)
              
              let val2 = Double(arc4random_uniform(UInt32(range)) + 1)
              
              let val3 = Double(arc4random_uniform(UInt32(range)) + 35)
              
              let val4 = Double(arc4random_uniform(UInt32(range)) + 15)
              
              var medianVal: Double
              
              var maxWhiskersVal: Double
                                                 
              var minWhiskersVal: Double
              
              var valArr: [Double]
              
              if i > 3 && i < 6 {
                  
                  medianVal = Double.random(in: -val2..<val1 - 2)
                  
                  maxWhiskersVal = max(val1,-val2) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(val1,-val2) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: val1, y0: -val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: -val4..<val3 - 2)
                  
                  maxWhiskersVal = max(val3,-val4) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(val3,-val4) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: val3, y0: -val4, plotData: valArr as AnyObject, data: nil))
                  
              }
              else if i > 7 && i < 10 {
                  
                  medianVal = Double.random(in: -val1..<(-val2 - 2))
                  
                  maxWhiskersVal = max(-val1,-val2) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(-val1,-val2) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: -val1, y0: -val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: -val3..<(-val4 - 2))
                  
                  maxWhiskersVal = max(-val3,-val4) + Double(arc4random_uniform(UInt32(10)))
                                                     
                  minWhiskersVal = min(-val3,-val4) - Double(arc4random_uniform(UInt32(10)))
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: -val3, y0: -val4, plotData: valArr as AnyObject, data: nil))
                  
//                  print(valArr[0],val1,val2)
              }
              else if i > 12 && i < 16 {
                  
                  medianVal = Double.random(in: -val1..<val2 - 2)
                  
                  maxWhiskersVal = max(-val1,val2) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(-val1,val2) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: -val1, y0: val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: -val3..<val4 - 2)
                  
                  maxWhiskersVal = max(-val3,val4) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(-val3,val4) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: -val3, y0: val4, plotData: valArr as AnyObject, data: nil))
                  
//                  print(valArr[0],val1,val2)
              }
              else {
                  
                  medianVal = Double.random(in: val2..<val1 - 2)
                  
                  maxWhiskersVal = max(val1,val2) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(val1,val2) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries1.append(ChartDataEntry(xString: lab, y: val1, y0: val2, plotData: valArr as AnyObject, data: nil))
                  
                  medianVal = Double.random(in: val4..<val3 - 2)
                  
                  maxWhiskersVal = max(val3,val4) + Double(arc4random_uniform(UInt32(10)) + 3)
                                                     
                  minWhiskersVal = min(val3,val4) - Double(arc4random_uniform(UInt32(10)) + 3)
                  
                  valArr = [round(medianVal),minWhiskersVal,maxWhiskersVal]
                  
                  dataEntries2.append(ChartDataEntry(xString: lab, y: val3, y0: val4, plotData: valArr as AnyObject, data: nil))
                  
//                  print(valArr[0],val1,val2)
              }
              
              totalSales += CGFloat(val1)
          }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[2]]
        set1.plotType = .BoxPlot
        set1.dataSetOptions = BarDataSetOptions()
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.colors = [ChartColorTemplates.pieColor()[1]]
        set2.plotType = .BoxPlot
        set2.dataSetOptions = set1.dataSetOptions
        
        let chartData = ChartData(dataSets: [set1,set2])
        
        barChartView?.data = chartData
        
        
        let BoxPlotPlotOptions = barChartView?.getPlotOptions() as! BoxPlotPlotOptions
        
        BoxPlotPlotOptions.fitBars = true
        
        chartData.setDrawValues(false)
        
        BoxPlotPlotOptions.groupSpacePixel = 0.1
        
        BoxPlotPlotOptions.barWidth = 0.7
        
        BoxPlotPlotOptions.barWidthPixel = 20
        
        BoxPlotPlotOptions.barSpacePixel = 20
        
        BoxPlotPlotOptions.barCount = 12
        
        BoxPlotPlotOptions.medianIndex = 0
        
        BoxPlotPlotOptions.minWhiskersIndex = 1
        
        BoxPlotPlotOptions.maxWhiskersIndex = 2
        
        BoxPlotPlotOptions.drawMedianValueEnabled = true
        
        BoxPlotPlotOptions.drawWhiskersValueEnabled = true
        
        BoxPlotPlotOptions.medianColor = UIColor.white
        
        if #available(iOS 13.0, *) {
            BoxPlotPlotOptions.whiskersColor = UIColor.systemGray2
        } else {
            // Fallback on earlier versions
        }
        
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        
        
        //*****************************  MinMax and Colors  *******************************//
        
        BoxPlotPlotOptions.minimumBarPixel = 18
        
        BoxPlotPlotOptions.maximumBarPixel = 30
        
        BoxPlotPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        if let chartView = containerView?.overview.chartView {
            chartView.extraBottomOffset = 10
            setAxisForOverView(chartView: chartView)
            chartView.data = getChartDataForOverviewChart(chartData: chartData)
            chartData.setDrawValues(false)
            setPlotOptionForOverView(chartView: chartView)
        }
  
    }
    
    func getChartDataForOverviewChart(chartData: ChartData) -> ChartData {
        
        
        var datasets = [ChartDataSet]()
        
        for dataset in chartData.dataSets {
            
            var dataEntries = [ChartDataEntry]()
            
            for entryIndex in 0..<dataset.entryCount {
                
                guard let entry = dataset.entryForIndex(entryIndex) else {
                    continue
                }
                
                let y = max(entry.y, entry.y0)
                
                dataEntries.append(ChartDataEntry(xString: entry.xString, y: y, data: nil))
            }
            
            let set = ChartDataSet(values: dataEntries, label: dataset.label)
            set.colors = dataset.colors
            set.plotType = .Bar
            set.drawValuesEnabled = false
            
            datasets.append(set)
            
        }
        
        return ChartData(dataSets: datasets)
    }
    
    func setPlotOptionForOverView(chartView: ChartViewBase) {
    
        let barPlotOption = chartView.getPlotOptions(type: .Bar) as? BarPlotOptions
        
        barPlotOption?.barWidth = 0.7
        barPlotOption?.barSpace = 0.3
        barPlotOption?.minOffset = 0.0
        barPlotOption?.groupSpace = 0.5
    }
    
    func setAxisForOverView(chartView: ChartViewBase) {
        
        chartView.xAxis.scaleType = .Ordinal
        
//        chartView.xAxis.inverted = true
        
        chartView.xAxis.enabled = false
        chartView.getYAxis(atIndex: 0)!.visible = false
        
        chartView.customScaleEnabled = true
        chartView.setScaleMinima(1, scaleY: 1)
    }
    
    func rangeSliderConfigation() {
        
        guard let rangeSlider = containerView?.overviewView.rangeSlider else {
            return
        }
        rangeSlider.highlightShape.holeColor = .clear//.black.withAlphaComponent(0.3)
        rangeSlider.highlightShape.shapeType = .Rect
        
//        rangeSlider.unHighlightShape.shapeType = .Rect
        rangeSlider.unHighlightShape.strokeColor = nil
        rangeSlider.unHighlightShape.holeColor = .gray
//        rangeSlider.unHighlightShape.holeColor = .black.withAlphaComponent(0.3)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        if UIDevice.current.orientation.isLandscape {
            containerView?.overviewHeightFactor = 0.16
        }
        else {
            containerView?.overviewHeightFactor = 0.08
        }
        
    }
}

extension BoxPlotOverviewChartViewController {
    
    func chartValueRemoved(_ chartView: ChartViewBase, entries: [ChartDataEntry]?, dataSets: [ChartDataSet]?, dataSetRemoved: Bool, showTrackerView: Bool) {
        
        if let dataSets = dataSets {
            updateDataset(datasets: dataSets)
        }
    }
    
    func chartValueAdded(chartView: ChartViewBase, entries: [ChartDataEntry]?, dataSets: [ChartDataSet]?, dataSetAdded: Bool) {
        
        if let dataSets = dataSets {
            updateDataset(datasets: dataSets)
        }
    }
    
    func updateDataset(datasets: [ChartDataSet]) {
        
        guard let overviewChart = containerView?.overview.chartView, let data = overviewChart.data else {
            return
        }
        
        for dataset in data.dataSets {
            
            for set in datasets {
                
                if dataset.label == set.label {
                    dataset.visible = set.isVisible
                    break
                }
            }
        }
    }
}

