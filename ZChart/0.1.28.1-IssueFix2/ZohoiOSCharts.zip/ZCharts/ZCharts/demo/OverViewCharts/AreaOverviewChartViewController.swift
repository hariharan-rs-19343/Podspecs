//
//  AreaOverviewChartViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 20/03/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import zchart

class AreaOverviewChartViewController: UIViewController,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        let allEntries = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: lineChartView!)
        
        for i in 0..<(allEntries.count)
        {
            let entry = allEntries[i]
            let set = lineChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: entry.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!  //UIColor.blue //curEntry.entryColor
            
            entries.append(toolTipEntry)
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    @objc fileprivate func tapGestureRecognized(_ recognizer: NSUITapGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        addLine(view: childView, point: location)
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    @objc fileprivate func panGestureRecognized(_ recognizer: NSUIPanGestureRecognizer)
    {
        
        let location = recognizer.location(in: childView)
        
        if  recognizer.state == .began
        {
            childView.layer.addSublayer(shapeLayer)
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .changed
        {
            addLine(view: childView, point: location)
        }
        else if recognizer.state == .ended || recognizer.state == .cancelled
        {
            addLine(view: childView, point: location)
            shapeLayer.removeFromSuperlayer()
        }
        
        
        
        
        if let layers = childView.layer.sublayers
        {
            for layer in layers
            {
                let caLayer:CALayer = layer
                if caLayer.isKind(of: CAShapeLayer.self)
                {
                    let shapeLayer = caLayer as! CAShapeLayer
                    if (shapeLayer.path?.contains(location))!
                    {
                        
                    }
                }
            }
        }
        
        
    }
    
    
    func addMultipleLine(view:UIView)
    {
        
        
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 50, y: 50))
        path.addLine(to: CGPoint(x: 50, y: 95))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:50, y: 105))
        path.addLine(to: CGPoint(x: 50, y: 150))
        path.close()
        
        
        
        //        layer.lineCap = "round"
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        //        layer.fillColor = UIColor.green.cgColor
        shapeLayer.lineWidth = 2
        
        view.layer.addSublayer(shapeLayer)
        
        let circleLayer = CAShapeLayer()
        //        let circlePath = UIBezierPath(rect: CGRect(x: 45, y: 95, width: 10, height: 10))
        let circlePath = UIBezierPath(ovalIn: CGRect(x: 45, y: 95, width: 10, height: 10))
        //        UIBezierPath(ovalIn: <#T##CGRect#>)
        circleLayer.path = circlePath.cgPath
        circleLayer.strokeColor = UIColor.black.cgColor
        circleLayer.fillColor = UIColor.clear.cgColor
        
        shapeLayer.addSublayer(circleLayer)
    }
    
    func addLine(view:UIView, point:CGPoint)
    {
        let path = getNewPath(point: point, yChange: 100)
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 2
        
        var circleLayer:CAShapeLayer? = nil
        
        let sublayers = shapeLayer.sublayers
        if sublayers != nil
        {
            for layer in sublayers!
            {
                if layer.isKind(of: CAShapeLayer.self)
                {
                    circleLayer = layer as! CAShapeLayer
                    break
                }
            }
        }
        
        if circleLayer == nil
        {
            circleLayer = CAShapeLayer()
            circleLayer?.strokeColor = UIColor.black.cgColor
            circleLayer?.fillColor = UIColor.clear.cgColor
            
            shapeLayer.addSublayer(circleLayer!)
        }
        
        circleLayer?.path = getCirclePath(point: point, yChange: 100).cgPath
    }
    
    func getNewPath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        //        let yChange:CGFloat = 50
        let path = UIBezierPath()
        path.move(to: point)
        path.addLine(to: CGPoint(x: point.x, y: point.y + yChange - 5))
        // path.move(to: CGPoint(x:50, y: 100))
        //path.addArc(withCenter: CGPoint(x:50, y: 100), radius: 5, startAngle: 0, endAngle: 360, clockwise: true)
        path.move(to: CGPoint(x:point.x, y: point.y + yChange + 5))
        path.addLine(to: CGPoint(x: point.x, y: point.y + (2.0 * yChange)))
        path.close()
        
        return path
    }
    
    func getCirclePath(point:CGPoint,yChange:CGFloat) -> UIBezierPath
    {
        let radius:CGFloat = 5
        //        let yChange:CGFloat = 50
        let rect = CGRect(x: point.x - radius, y: point.y + yChange - radius, width: 2 * radius, height: 2 * radius)
        let path = UIBezierPath(ovalIn: rect)
        path.close()
        
        return path
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*  if showCustomLineView
         {
         addCustomLineView()
         return
         }*/
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        containerView?.translatesAutoresizingMaskIntoConstraints = false
        
        addChartOrientationSwapButton()
        
        if #available(iOS 11.0, *) {
            view.addConstraints([
                containerView!.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                containerView!.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
                containerView!.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                containerView!.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
            ])
        } else {
            // Fallback on earlier versions
        }
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        containerView?.legend.legendEnabled = false
        
        containerView?.overview.overviewEnabled = true
        containerView?.overviewView.offsets.leftOffset = 50.0
        containerView?.overviewView.offsets.rightOffset = 50.0
        containerView?.overviewView.offsets.bottomOffset = 10
        rangeSliderConfigation()
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.titleEnabled = false
        containerView?.title.mainTitleEnabled = false
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addLineChart()
    }
    
    
    
    var lineChartView:ChartViewBase? = nil
    
    func addLineChart()
    {
        
        lineChartView = containerView?.chart//containerView?.initializeChart()
        lineChartView?.plotDelegate = self
//        lineChartView?.isOverviewChart = true
        
        lineChartView?.tapEventListener?.handler = AreaHighlightHandler()
        
        lineChartView?.panEventListener?.handler = LinePanHandler()
        
        lineChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        lineChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        lineChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = false
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.xAxis.drawGridLinesEnabled = false
        
        lineChartView?.chartDescription?.enabled = false
        
        lineChartView?.xAxis.granularity = 1.0
        
        lineChartView?.xAxis.inverted = false
        
        lineChartView?.scaleXEnabled = true
//        lineChartView?.viewPortHandler.setMinimumScaleX(5)
//        lineChartView?.viewPortHandler.setMaximumScaleX(3)
//        lineChartView?.viewPortHandler.setMinMaxScaleX(minScaleX: 2.0, maxScaleX: 5.0)
        lineChartView?.xAxis.maxRangeToShow = 5
        lineChartView?.xAxis.minRangeToShow = 2
        
        let count = 10
        let range = 54
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        var dataEntries4: [ChartDataEntry] = []
        var dataEntries5: [ChartDataEntry] = []
        var dataEntries6: [ChartDataEntry] = []
        
        for i in 0..<count {
            
            let lab = "Item " + String(Double(i+1))
            
            var val1 = arc4random_uniform(UInt32(range)) + 3
            
            let val2 = arc4random_uniform(UInt32(range)) + 3
            
            let val3 = arc4random_uniform(UInt32(range)) + 3
            
            let val4 = arc4random_uniform(UInt32(range)) + 3
            
            let val5 = arc4random_uniform(UInt32(range)) + 3
            
            let val6 = arc4random_uniform(UInt32(range)) + 3
            
            if i % 2 == 0
            {
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double.nan, data: lab as AnyObject))
            }
            else{
                
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), data: lab as AnyObject))
            }
            
            dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), data: lab as AnyObject))
            
            if i % 2 == 0
            {
                dataEntries3.append(ChartDataEntry(x: Double(i), y: -Double(val3), data: lab as AnyObject))
            }
            else{
                dataEntries3.append(ChartDataEntry(x: Double.nan, y: -Double(val3), data: lab as AnyObject))
            }
            
            
            if i != 5 && i != 6
            {
                dataEntries4.append(ChartDataEntry(x: Double(i), y: -Double(val4), data: lab as AnyObject))
            }
            else{
                dataEntries4.append(ChartDataEntry(x: Double.nan, y: Double.nan, data: lab as AnyObject))
            }

            if i != 5 && i != 6
            {
                if i ==  3
                {
                    dataEntries5.append(ChartDataEntry(x: Double(i), y: Double(val5), data: lab as AnyObject))
                    val1 = arc4random_uniform(UInt32(range)) + 3
                    dataEntries5.append(ChartDataEntry(x: Double(i), y: Double(val1), data: lab as AnyObject))
                }
                else{
                    dataEntries5.append(ChartDataEntry(x: Double(i), y: Double(val5), data: lab as AnyObject))
                }
                
            }
            else{
                dataEntries5.append(ChartDataEntry(x: Double.nan, y: Double.nan, data: lab as AnyObject))
            }
            
            
            
            dataEntries6.append(ChartDataEntry(x: Double(i), y: -Double(val6), data: lab as AnyObject))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[0])
        
        set1.plotType = .Line
        let lineDataSetOptions1 = LineDataSetOptions()
        set1.dataSetOptions = lineDataSetOptions1
        
        let shape = lineDataSetOptions1.markerInstance
        shape.holeColor = UIColor.red
        shape.shapeType = .circle
        shape.size = CGSize(width: 8.0, height: 8.0)
        shape.lineWidth = 2
        
        lineDataSetOptions1.setShapeColor(UIColor.red)
        
        lineDataSetOptions1.drawShapeEnabled = true
        
        lineDataSetOptions1.lineWidth = 1
        
        lineDataSetOptions1.drawFilledEnabled = true
        lineDataSetOptions1.fillAlpha = 0.3
        lineDataSetOptions1.fillColor = ChartColorTemplates.pieColor()[0]
//        set1.mode = .cubicBezier
        
        
        let set2:ChartDataSet = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        
        set2.plotType = .Line
        let lineDataSetOptions2 = LineDataSetOptions()
        set2.dataSetOptions = lineDataSetOptions2
        
        lineDataSetOptions2.drawShapeEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        lineDataSetOptions2.setCircleColor(UIColor.black)
        lineDataSetOptions2.lineWidth = 1
        lineDataSetOptions2.circleRadius = 3.0
        lineDataSetOptions2.drawCircleHoleEnabled = false
        lineDataSetOptions2.drawCirclesEnabled = false
        lineDataSetOptions2.drawFilledEnabled = true
        lineDataSetOptions2.fillAlpha = 0.3
        lineDataSetOptions2.fillColor = ChartColorTemplates.pieColor()[1]
        lineDataSetOptions2.lineDashLengths = [4.0,8.0]
        lineDataSetOptions2.lineDashPhase = 2.0
//        set2.mode = .cubicBezier
        
        let set3:ChartDataSet = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false

        set3.plotType = .Line
        let lineDataSetOptions3 = LineDataSetOptions()
        set3.dataSetOptions = lineDataSetOptions3

        lineDataSetOptions3.drawShapeEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[2])
        lineDataSetOptions3.setCircleColor(UIColor.black)
        lineDataSetOptions3.lineWidth = 1
        lineDataSetOptions3.circleRadius = 3.0
        lineDataSetOptions3.drawCircleHoleEnabled = false
        lineDataSetOptions3.drawCirclesEnabled = false
        lineDataSetOptions3.drawFilledEnabled = true
        lineDataSetOptions3.fillAlpha = 0.3
        lineDataSetOptions3.fillColor = ChartColorTemplates.pieColor()[2]
//        set3.mode = .cubicBezier
        
        let set4:ChartDataSet = ChartDataSet(values: dataEntries4, label: "Set4")
        set4.drawIconsEnabled = false

        set4.plotType = .Line
        let lineDataSetOptions4 = LineDataSetOptions()
        set4.dataSetOptions = lineDataSetOptions4

        lineDataSetOptions4.drawShapeEnabled = false
        set4.setColor(ChartColorTemplates.pieColor()[3])
        lineDataSetOptions4.setCircleColor(UIColor.black)
        lineDataSetOptions4.lineWidth = 1
        lineDataSetOptions4.circleRadius = 3.0
        lineDataSetOptions4.drawCircleHoleEnabled = false
        lineDataSetOptions4.drawCirclesEnabled = false
        lineDataSetOptions4.drawFilledEnabled = true
        lineDataSetOptions4.fillAlpha = 0.3
        lineDataSetOptions4.fillColor = ChartColorTemplates.pieColor()[3]
//        set4.mode = .cubicBezier
        
        let set5:ChartDataSet = ChartDataSet(values: dataEntries5, label: "Set5")
        set5.drawIconsEnabled = false
        
        set5.plotType = .Line
        let lineDataSetOptions5 = LineDataSetOptions()
        set5.dataSetOptions = lineDataSetOptions5

        lineDataSetOptions5.drawShapeEnabled = false
        set5.setColor(ChartColorTemplates.pieColor()[4])
        lineDataSetOptions5.setCircleColor(UIColor.black)
        lineDataSetOptions5.lineWidth = 1
        lineDataSetOptions5.circleRadius = 3.0
        lineDataSetOptions5.drawCircleHoleEnabled = false
        lineDataSetOptions5.drawCirclesEnabled = false
        lineDataSetOptions5.drawFilledEnabled = true
        lineDataSetOptions5.fillAlpha = 0.3
        lineDataSetOptions5.fillColor = ChartColorTemplates.pieColor()[4]
//        set5.mode = .cubicBezier
        
        let set6:ChartDataSet = ChartDataSet(values: dataEntries6, label: "Set6")
        set6.drawIconsEnabled = false

        set6.plotType = .Line
        let lineDataSetOptions6 = LineDataSetOptions()
        set6.dataSetOptions = lineDataSetOptions6

        lineDataSetOptions6.drawShapeEnabled = false
        set6.setColor(ChartColorTemplates.pieColor()[5])
        lineDataSetOptions6.setCircleColor(UIColor.black)
        lineDataSetOptions6.lineWidth = 1
        lineDataSetOptions6.circleRadius = 3.0
        lineDataSetOptions6.drawCircleHoleEnabled = false
        lineDataSetOptions6.drawCirclesEnabled = false
        lineDataSetOptions6.drawFilledEnabled = true
        lineDataSetOptions6.fillAlpha = 0.3
        lineDataSetOptions6.fillColor = ChartColorTemplates.pieColor()[5]
//        set6.mode = .cubicBezier
        
        
//        lineDataSetOptions1.mode = .cubicBezier
//        lineDataSetOptions2.mode = .cubicBezier
//        lineDataSetOptions3.mode = .cubicBezier
//        lineDataSetOptions4.mode = .cubicBezier
//        lineDataSetOptions5.mode = .cubicBezier
//        lineDataSetOptions6.mode = .cubicBezier
        
//        lineDataSetOptions1.mode = .montonic
//        lineDataSetOptions2.mode = .montonic
//        lineDataSetOptions3.mode = .montonic
//        lineDataSetOptions4.mode = .montonic
//        lineDataSetOptions5.mode = .montonic
//        lineDataSetOptions6.mode = .montonic
        
        lineDataSetOptions1.mode = .linear
        lineDataSetOptions2.mode = .linear
        lineDataSetOptions3.mode = .linear
        lineDataSetOptions4.mode = .linear
        lineDataSetOptions5.mode = .linear
        lineDataSetOptions6.mode = .linear
//
//        set1.mode = .stepped
//        set2.mode = .stepped
//        set3.mode = .stepped
//        set4.mode = .stepped
//        set5.mode = .stepped
//        set6.mode = .stepped
        
        let chartData = ChartData(dataSets: [set1, set2])
        chartData.setDrawValues(false)
        
        lineChartView?.data = chartData
        
        guard let linePlotOptions = (lineChartView?.getPlotOptions(type: .Line) as? LinePlotOptions)
            else { return }
        
        linePlotOptions.isStacked = true
        
        linePlotOptions.maxWidthZoomRestrictionPixel = 500
        
        if let chartView = containerView?.overview.chartView {
            chartView.extraBottomOffset = 10
            setAxisForOverView(chartView: chartView)
            chartView.data = chartData
            setPlotOptions(chartView: chartView)
            chartData.setDrawValues(false)
        }
    }
    
    func setPlotOptions(chartView: ChartViewBase) {
        
        guard let linePlotOptions = (chartView.getPlotOptions(type: .Line) as? LinePlotOptions)
            else { return }
        
        linePlotOptions.isStacked = true
        linePlotOptions.minOffset = 0
    }
    
    func setAxisForOverView(chartView: ChartViewBase) {
        
//        chartView.xAxis.scaleType = .Ordinal
        chartView.xAxis.inverted = false
        
        chartView.xAxis.enabled = false
        chartView.getYAxis(atIndex: 0)!.visible = false
    }
    
    func rangeSliderConfigation() {
        
        guard let rangeSlider = containerView?.overviewView.rangeSlider else {
            return
        }
        
//        rangeSlider.delegate = self
        
        rangeSlider.highlightShape.holeColor = .black.withAlphaComponent(0.3)
//        rangeSlider.highlightShape.shapeType = .Rect
        
//        rangeSlider.unHighlightShape.shapeType = .Rect
//        rangeSlider.unHighlightShape.strokeColor = nil
        rangeSlider.unHighlightShape.holeColor = .lightGray
//        rangeSlider.unHighlightShape.holeColor = .black.withAlphaComponent(0.3)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        if UIDevice.current.orientation.isLandscape {
            containerView?.overviewHeightFactor = 0.15
        }
        else {
            containerView?.overviewHeightFactor = 0.08
        }
    }
    var orientationFlag = true

}
/*
extension AreaOverviewChartViewController: RangeSliderDelegate {
    
    func rangeSelected(minimum: Double, maximum: Double) {
        
        if ChartUtils.roundNumber(number: minimum) == ChartUtils.roundNumber(number: maximum) {
//            return
        }
            
        lineChartView?.showViewRange(from: minimum, to: maximum)
    }
}
*/

extension AreaOverviewChartViewController: PlotDelegate {

// MARK: - Chart Orientation Change
func buttonImage() -> UIImage{
    let themeImage: UIImage!

    if orientationFlag{
        themeImage = UIImage(named: "Horizontal Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
    }
    else{
        themeImage = UIImage(named: "Stacked Bar")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
    }
    
    return themeImage
}

func addChartOrientationSwapButton(){
    
    let orientationSwapButton = UIButton(type: .custom)
    
    orientationSwapButton.frame = CGRect(x: 0.0, y: 0.0, width: 16, height: 16)
    
    orientationSwapButton.setImage(buttonImage(), for: .normal)
    
    orientationSwapButton.addTarget(self, action: #selector(chartOrientationSwap), for: UIControl.Event.touchUpInside)

    let buttonItem = UIBarButtonItem(customView: orientationSwapButton)
    
    let currWidth = buttonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
    currWidth?.isActive = true
    
    let currHeight = buttonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
    currHeight?.isActive = true
    
    self.navigationItem.rightBarButtonItem = buttonItem
}

@objc func chartOrientationSwap(){
    
    lineChartView?.xAxis.tickLabelMode = .forced
    
    if !orientationFlag{
        
        lineChartView?.isRotated = false
        
        orientationFlag = true
        
        lineChartView?.xAxis.labelRotationAngle = 60
    }
    else{
        
        lineChartView?.isRotated = true
        
        lineChartView?.xAxis.labelPosition = .bottom
        
        lineChartView?.xAxis.labelRotationAngle = 0
        
        lineChartView?.getYAxis(atIndex: 0)?.labelPosition = .outsideChart
        
        orientationFlag = false
    }
    
    lineChartView?.notifyPlotUpdated()
    addChartOrientationSwapButton()
    lineChartView?.animate(xAxisDuration: 1.0)
}

func updatePlotOptions(plotOption: PlotOptionsBase, type: ChartType) {
    
    if let plotOptions = (plotOption as? LinePlotOptions) {
        plotOptions.isStacked = true
    }
}
}




