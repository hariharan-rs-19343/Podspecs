//
//  HorizontalBarOverviewChartViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 10/04/23.
//  Copyright © 2023 charts. All rights reserved.
//
import zchart
import UIKit

class HorizontalBarOverviewChartViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
        let barEntry = entry!
            
        var label:String
        var value:String
            
        if barEntry.xString != nil
        {
            label = barEntry.xString!
        }
        else{
            label = String(barEntry.x)
        }
            
        if barEntry.yString != nil
        {
            value = barEntry.yString!
        }
        else{
            value = String(barEntry.y)
        }
        
        let toolTipEntry = ToolTipEntry(label:label, value: value)
        
        toolTipEntry.valueTextColor = (barChartView?.data?.dataSets[0].color(atIndex: 0))!
        
        toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry)
        
        
        
        let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
        
        toolTipEntry1.valueTextColor = UIColor.black
        
        toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
        
        entries.append(toolTipEntry1)
        
        return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        containerView?.translatesAutoresizingMaskIntoConstraints = false
        
        if #available(iOS 11.0, *) {
            view.addConstraints([
                containerView!.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                containerView!.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
                containerView!.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
                containerView!.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
            ])
        } else {
            // Fallback on earlier versions
        }
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        containerView?.legend.legendEnabled = true
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
        
        containerView?.overview.overviewEnabled = true
        containerView?.overviewView.offsets.leftOffset = 20.0
        containerView?.overviewView.position = .left
        rangeSliderConfigation()
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        //addChartTypeAndData
        addBarChart()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    var barChartView:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        barChartView = containerView?.chart//containerView?.initializeChart()
        
//        barChartView?.isOverviewChart = true
        
        barChartView?.isRotated = true
        
//        barChartView?.customScaleEnabled = true

        
        //*****************************  Handlers  *******************************//
        
        barChartView?.tapEventListener?.handler = BarHighlightHandler()
        
        barChartView?.panEventListener?.handler = DefaultPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        barChartView?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        barChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        //*****************************  Axis Title  *******************************//
        
        barChartView?.xAxis.axisTitle = "Years"
        
        barChartView?.getYAxis(atIndex: 0)!.axisTitle = "Quantities"
        
        barChartView?.getYAxis(atIndex: 1)!.axisTitle = "Quantities"
        
        
        //*****************************  other Axis Properties  *******************************//
        
        
        barChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        barChartView?.customScaleEnabled = true
        barChartView?.setScaleMinima(1, scaleY: 1)
        
        barChartView?.xAxis.labelPosition = .bottom
        
        barChartView?.xAxis.granularityEnabled = true
        
        barChartView?.xAxis.granularity = 1.0
        
        barChartView?.scaleXEnabled = false
        barChartView?.scaleYEnabled = true
        
        barChartView?.xAxis.scaleType = .Ordinal
        barChartView?.xAxis.inverted = true
        
        barChartView?.getYAxis(atIndex: 0)!.drawAxisLineEnabled = false
        
        let siFormater = SIUnitFormatter()
        siFormater.maximumFractionDigits = 1
        let axisValueFormatter = ValueFormatter(formatter: siFormater, chart: self.barChartView!)
        barChartView?.getYAxis(atIndex: 0)!.valueFormatter = axisValueFormatter
        
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 100
        let range = 1200
        
        var dataEntries1: [ChartDataEntry] = []
        
 
    for i in 0..<count {
          
          var lab = "W"+String(Double(i+1))
            
          
        let val1 = Double(arc4random_uniform(UInt32(range)) + 3)
        dataEntries1.append(ChartDataEntry(xString: lab, y: val1, data: nil))
        totalSales += CGFloat(val1)
    }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .Bar
        set1.dataSetOptions = BarDataSetOptions()
        
        let chartData = ChartData(dataSet: set1)
        
        barChartView?.data = chartData
        
        let barPlotOptions = barChartView?.getPlotOptions() as! BarPlotOptions
        
        chartData.setDrawValues(true)
        
//        barPlotOptions.barWidth = 0.7
//
//        barPlotOptions.barSpace = 0.3
        
        barPlotOptions.barWidthPixel = 18

        barPlotOptions.barSpacePixel = 5
        
        barPlotOptions.barCount = 12
        
//        barPlotOptions.isStacked = true
        // should be given after data input
        barChartView?.xAxis.labelCount = 30
        
        //*****************************  MinMax and Colors  *******************************//
        
//        barPlotOptions.minimumBarPixel = 18
        
//        barPlotOptions.maximumBarPixel = 30
        
        barPlotOptions.nonHighlightColor = UIColor.black.withAlphaComponent(0.2)
        
        if let chartView = containerView?.overview.chartView {
            chartView.isRotated = true
            chartView.extraLeftOffset = 10
            setAxisForOverView(chartView: chartView)
            chartView.data = chartData
            chartData.setDrawValues(false)
            setPlotOptionForOverView(chartView: chartView)
        }
        
        //*****************************  Animation  *******************************//
        
//        barChartView?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
//        let animateBlock = SingleBarViewController.getAnimationBlock(chartView: self.barChartView!)
        
//        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.barChartView!, duration: 0.5)
//
//        CommonUtilities.customAnimation(chart: barChartView!, duration: 1.0, animationBlock: animateBlock)
        
        
        //*****************************  Other chart properties  *******************************//
        
        barChartView?.chartDescription?.enabled = false
        
        //        barChartView?.setScaleMinima(CGFloat(scaleLevel), scaleY: 1)
  
    }
    
    func setPlotOptionForOverView(chartView: ChartViewBase) {
    
        let barPlotOption = chartView.getPlotOptions(type: .Bar) as? BarPlotOptions
        
        barPlotOption?.barWidth = 0.7
        barPlotOption?.barSpace = 0.3
        barPlotOption?.minOffset = 0.0
    }
    
    func setAxisForOverView(chartView: ChartViewBase) {
        
        chartView.xAxis.scaleType = .Ordinal
        
        chartView.xAxis.inverted = true
        
        chartView.xAxis.enabled = false
        chartView.getYAxis(atIndex: 0)!.visible = false
        
        chartView.customScaleEnabled = true
        chartView.setScaleMinima(1, scaleY: 1)
    }
    
    func rangeSliderConfigation() {
        
        guard let rangeSlider = containerView?.overviewView.rangeSlider else {
            return
        }
        
        rangeSlider.delegate = self
        
        rangeSlider.thumbShape.shapeType = .thumbNailVertical
        
        rangeSlider.highlightShape.holeColor = .black.withAlphaComponent(0.3)
        rangeSlider.highlightShape.shapeType = .Rect
        
//        rangeSlider.unHighlightShape.shapeType = .Rect
        rangeSlider.unHighlightShape.strokeColor = nil
        rangeSlider.unHighlightShape.holeColor = .gray
//        rangeSlider.unHighlightShape.holeColor = .black.withAlphaComponent(0.3)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        if UIDevice.current.orientation.isLandscape {
            containerView?.overviewWidthFactor = 0.08
        }
        else {
            containerView?.overviewWidthFactor = 0.2
        }
        
    }
}

extension HorizontalBarOverviewChartViewController: RangeSliderDelegate {
    
    func rangeSelected(minimum: Double, maximum: Double) {
        
        barChartView?.showViewRange(from: minimum, to: maximum)
    }
}

