//
//  BubbleOverviewChartViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 17/04/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import zchart

class BubbleOverviewChartViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate, CustomTicksDelegate, NoteDelegate {
    
    func updateNoteLayer(noteLayer: NoteLayer, noteShape: ShapeProperties) {
        let tempPoint = noteLayer.noteEntry!.point!
        
        let tempPxelPoint  = bubbleChartView!.pixelForValues(x: tempPoint.x as! Double, y: tempPoint.y as! Double, axisIndex: noteLayer.noteEntry!.axisIndex)
        
        let newShape = CAShapeLayer()
        newShape.path = UIBezierPath(ovalIn: CGRect(x: tempPxelPoint.x-10, y: tempPxelPoint.y-10, width: 20, height: 20)).cgPath
        newShape.fillColor = UIColor.red.cgColor
        noteLayer.addSublayer(newShape)
    }
    
    func getTickSizeforEntry(axis: AxisBase, value: Double, chart: ChartViewBase) -> CGSize {
        
        let position = CGPoint(x: 0, y: 0)
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        
        var size = textLayer.frame.size
        
        let imageSize = CGSize(width:min(size.width,30), height: 30)
        
        size.height += imageSize.height
        size.width = imageSize.width
        
        return size
    }
    
    func getTickLayer(axis:AxisBase, value: Double, position:CGPoint, size:CGSize, anchor:CGPoint, text: String, chart: ChartViewBase) -> TickLayer {
        
        var position = position
        var size = size
        
        
        let tickLayer = TickLayer()
        
        let labelAttrs = [NSAttributedString.Key.font: axis.labelFont,
                          NSAttributedString.Key.foregroundColor: axis.labelTextColor ]
        
        let text = (axis as! XAxis).getFormattedValue(value: value)
        
        let textLayer = ChartUtils.drawTextLayer(text: text, point: position, align: .center, attributes: labelAttrs)
        tickLayer.addSublayer(textLayer)
        
        position.y += textLayer.frame.height
        size.height -= textLayer.frame.height
        
        let imageSize = CGSize(width: min(size.width,30), height: size.height)
        let imageLayer = CALayer()
        imageLayer.backgroundColor = UIColor.clear.cgColor
        imageLayer.bounds = CGRect(x: position.x-imageSize.width/2, y: position.y-imageSize.height/2 , width: imageSize.width, height: imageSize.height)
        imageLayer.position = CGPoint(x: position.x, y: position.y+imageSize.height/2)
        imageLayer.contents = UIImage(named: "usericon")?.cgImage  //UIImage(named:segment.imageName)?.cgImage
        tickLayer.addSublayer(imageLayer)
        
        return tickLayer
    }
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        let set = bubbleChartView?.data?.getDataSetForEntry(entry)
        
        if entry == nil || set == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        guard let plotOptions = (bubbleChartView?.getPlotOptions(type: .Bubble) as? BubblePlotOptions)
        else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            let allEntriesAtIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: bubbleChartView!)
            
            for tooltipEntry in allEntriesAtIndex
            {
                let set = bubbleChartView?.data?.getDataSetForEntry(tooltipEntry)
                let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: tooltipEntry.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
            }
        }
        else{
            let set = bubbleChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            
        }
        
        
        return entries
    }
    
    
    func drawOthers(_ chartView: ChartViewBase) {
        
//        print(chartView.xAxis.axisMinimum,chartView.xAxis.axisMaximum,"min and max from drawothers")
    }
    
    
    func shapePath(point: CGPoint, shapeInstance: ShapeProperties, shapeLayer:CAShapeLayer) -> CGMutablePath {
        
        let size = shapeInstance.size.width
        
        let shapeFrame = CGRect(x: point.x - (size/2), y: point.y - (size/2), width: size, height: size)
        
        let path = CGMutablePath()
        
        path.move(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX , y: shapeFrame.minY))
        
        path.addLine(to: CGPoint(x: shapeFrame.maxX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.maxY))
        
        path.addLine(to: CGPoint(x: shapeFrame.minX, y: shapeFrame.minY))
        
        return path
    }
    
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.overview.overviewEnabled = true
        containerView?.overviewView.offsets.leftOffset = 50.0
        containerView?.overviewView.offsets.rightOffset = 50.0
        containerView?.overviewView.offsets.bottomOffset = 10
        rangeSliderConfigation()
        
        //addChartTypeAndData
        addScatterChart()
        
        
    }
    
    func readDataFromJson() -> [[Double]]
    {
        var finalData:[[Double]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        for rowArray in dataArray
                        {
                            var row:[Double] = []
                            for element in rowArray
                            {
                                let val = element as! Double
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    var bubbleChartView:ChartViewBase? = nil
    
    func addScatterChart()
    {
        
        bubbleChartView = containerView?.chart//containerView?.initializeChart()
        
//        bubbleChartView?.isOverviewChart = true
        
        bubbleChartView?.rendererDelegate = self
        
        bubbleChartView?.tapEventListener?.handler = BubbleHighlightHandler()
        
        bubbleChartView?.panEventListener?.handler = DefaultPanHandler()
        //
        //        scatterChartView?.panEventListener?.handler = ScatterPanHandler()
        //
        //        scatterChartView?.longPressEventListener?.handler = ScatterLongPressHandler()
        
        bubbleChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        bubbleChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        bubbleChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        bubbleChartView?.xAxis.labelPosition = .bottom
        
        bubbleChartView?.xAxis.customTickEnabled = true
        
        bubbleChartView?.xAxis.tickDelegate = self
        
        
        bubbleChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        
        bubbleChartView?.getYAxis(atIndex: 0)!.axisMinimum = 0
        
//        bubbleChartView?.xAxis.axisMinimum = 0
        
        bubbleChartView?.xAxis.drawGridLinesEnabled = false
        
        bubbleChartView?.chartDescription?.enabled = false
        
        bubbleChartView?.xAxis.granularity = 1.0
        
        //        bubbleChartView?.xAxis.scaleType = .Time
        
        bubbleChartView?.xAxis.tickLabelMode = .auto
        
        bubbleChartView?.xAxis.labelCount = 10
        
        bubbleChartView?.xAxis.labelRotationAngle = 60
        
        bubbleChartView?.xAxis.valueFormatter = ValueFormatter(chart: bubbleChartView!)
        
        bubbleChartView?.xAxis.spaceMinPixel = 50
        bubbleChartView?.xAxis.spaceMaxPixel = 50
        
        bubbleChartView?.xAxis.inverted = false
        
        let count = 20
        let range = 100
        let sizeRange = 3000
        
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        
        /// Time data testing
        /*let newData =  readDataFromJson()
         var inc:UInt32 = 3
         for row in newData
         {
         inc += 1
         let val = arc4random_uniform(UInt32(range)) + inc
         dataEntries1.append(BubbleChartDataEntry(x: row[0], y: Double(val), size: CGFloat(5), data: nil))
         
         }*/
        
        
        for i in 0..<count {
            
            
            let lab = "200" + String(i+1)
            
            let xString = "Item " + String(i+1)
            let yString = "Furniture " + String(i+1)
            let val1 = arc4random_uniform(UInt32(range)) + 3
            let size1 = arc4random_uniform(UInt32(range)) + 3
            
            if i == 3
            {
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), size: CGFloat(size1), data: lab as AnyObject))
            }
            else if i == 7
            {
                dataEntries1.append(ChartDataEntry(x: Double.nan, y: Double(val1), size: CGFloat.nan, data: lab as AnyObject))
            }
            else{
                dataEntries1.append(ChartDataEntry(x: Double(i), y: Double(val1), size: CGFloat(size1), data: lab as AnyObject))
            }
            
            /// Ordinal Testing
            //            dataEntries1.append(BubbleChartDataEntry(xString: xString, yString: yString, size: CGFloat(size1), data: nil))
            
            let val2 = arc4random_uniform(UInt32(range)) + 103
            let size2 = arc4random_uniform(UInt32(range)) + 3
            
            if i == 5
            {
                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double.nan, size: CGFloat(size2), data: lab as AnyObject))
            }
            else{
                dataEntries2.append(ChartDataEntry(x: Double(i), y: Double(val2), size: CGFloat(size2), data: lab as AnyObject))
            }
            
            let val3 = arc4random_uniform(UInt32(range)) + 203
            let size3 = arc4random_uniform(UInt32(range)) + 3
            
            if i == 8
            {
                let val3 = arc4random_uniform(UInt32(range)) + 203
                dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), size: -CGFloat(size3), data: lab as AnyObject))
            }
            else{
                dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), size: CGFloat(size3), data: lab as AnyObject))
            }
            
            dataEntries3.append(ChartDataEntry(x: Double(i), y: Double(val3), size: CGFloat(size3), data: lab as AnyObject))
            
            
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[2])
        set1.plotType = .Bubble
        
        let dataOptions = set1.dataSetOptions as! AxisChartDataSetOptions
        let shape = dataOptions.shapeProperties
        shape.holeColor = ChartColorTemplates.pieColor()[2]
        shape.shapeType = .circle
        shape.lineWidth = 2
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[1])
        set2.plotType = .Bubble
        
        let dataOptions1 = set2.dataSetOptions as! AxisChartDataSetOptions
        let shape1 = dataOptions1.shapeProperties
        shape1.holeColor = ChartColorTemplates.pieColor()[1]
        shape1.shapeType = .triangle
        shape1.lineWidth = 2
        
        
        let set3  = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[3])
        set3.plotType = .Bubble
        
        let dataOptions2 = set3.dataSetOptions as! AxisChartDataSetOptions
        let shape2 = dataOptions2.shapeProperties
        shape2.holeColor = ChartColorTemplates.pieColor()[3]
        shape2.shapeType = .custom
        shape2.customPathDataSource = self
        shape2.lineWidth = 2
        
        
        
        
        let chartData = ChartData(dataSets: [set1, set2 , set3])
        chartData.setDrawValues(true)
        
        bubbleChartView?.data = chartData
        
        let entry1 = NoteEntry()
        entry1.point = (x: 2.0, y: 192.0)
        
        let entry2 = NoteEntry()
        entry2.point = (x: 4.0, y: 12.0)
        
        let entry3 = NoteEntry()
        entry3.point = (x: 7.0, y: 202.0)
        
        let entry4 = NoteEntry()
        entry4.point = (x: 9.0, y: 192.0)
        
        let noteEntries = [entry1, entry2, entry3, entry4]
        
        bubbleChartView?.notes = Notes(entries: noteEntries)
        bubbleChartView?.notes?.cusotmNoteEnabled = true
        bubbleChartView?.notes?.customNoteDelegate = self
        
        let plotOptions = (bubbleChartView?.getPlotOptions(type: .Bubble) as! BubblePlotOptions)
        plotOptions.minimumShapeSizeInPixel = 8
        plotOptions.maximumShapeSizeInPixel = 30
        
//        bubbleChartView?.xAxis.spaceMin = 0.5
//        bubbleChartView?.xAxis.spaceMax = 0.5
        
        if let chartView = containerView?.overview.chartView {
            chartView.extraBottomOffset = 10
            setAxisForOverView(chartView: chartView)
            chartView.data = chartData
            chartData.setDrawValues(false)
            setPlotOptionForOverView(chartView: chartView)
        }
        
        
        bubbleChartView?.animate(xAxisDuration: 1.0)
        
    }
    
    func setPlotOptionForOverView(chartView: ChartViewBase) {
    
        let BubblePlotOption = chartView.getPlotOptions(type: .Bubble) as? BubblePlotOptions
        
        BubblePlotOption?.minimumShapeSizeInPixel = 8
        BubblePlotOption?.maximumShapeSizeInPixel = 10
        
        BubblePlotOption?.minOffset = 0.0
    }
    
    func setAxisForOverView(chartView: ChartViewBase) {
        
//        chartView.xAxis.inverted = true
        
        chartView.xAxis.spaceMinPixel = 30
        chartView.xAxis.spaceMaxPixel = 30
        
        chartView.xAxis.enabled = false
        chartView.getYAxis(atIndex: 0)!.visible = false
        
//        chartView.customScaleEnabled = true
//        chartView.setScaleMinima(1, scaleY: 1)
    }
    
    func rangeSliderConfigation() {
        
        guard let rangeSlider = containerView?.overviewView.rangeSlider else {
            return
        }
        
        rangeSlider.highlightShape.holeColor = .black.withAlphaComponent(0.3)
//        rangeSlider.highlightShape.shapeType = .Rect
        
//        rangeSlider.unHighlightShape.shapeType = .Rect
        rangeSlider.unHighlightShape.strokeColor = nil
        rangeSlider.unHighlightShape.holeColor = .gray
//        rangeSlider.unHighlightShape.holeColor = .black.withAlphaComponent(0.3)
    }

}
