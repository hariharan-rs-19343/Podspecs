//
//  ScatterOverviewChartViewController.swift
//  ZCharts
//
//  Created by keerthi-pt4274 on 18/04/23.
//  Copyright © 2023 charts. All rights reserved.
//

import UIKit
import zchart

class ScatterOverviewChartViewController: UIViewController,RendererDelegate,IToolTipEntryGenerator,ShapeFactoryDataSource, ChartViewDelegate {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        let set = scatterChartView?.data?.getDataSetForEntry(entry)
        
        if entry == nil || set == nil
        {
            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: "0" )
            
            toolTipEntry1.valueTextColor = UIColor.black
            
            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry1)
            
            return entries
        }
        
        guard let plotOptions = scatterChartView?.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
            else { return [] }
        
        if (plotOptions.barGroupSelectionEnabled)
        {
            let allEntriesAtIndex = CommonHelperFunctions.getAllDatasetEntriesAtGivenEntryIndex(entry: entry!, includeNan: false, chart: scatterChartView!)
            
            for tooltipEntry in allEntriesAtIndex
            {
                let set = scatterChartView?.data?.getDataSetForEntry(tooltipEntry)
                let toolTipEntry = ToolTipEntry(label: (set?.label)!, value: String(describing: tooltipEntry.y))
                toolTipEntry.valueTextColor = (set?.colors[0])!
                
                entries.append(toolTipEntry)
            }
        }
        else{
            let set = scatterChartView?.data?.getDataSetForEntry(entry)
            let toolTipEntry = ToolTipEntry(label:String(describing: (entry?.x)!), value: String(describing: entry?.y))
            toolTipEntry.valueTextColor = (set?.colors[0])!
            
            entries.append(toolTipEntry)
            
        }
        
        
        return entries
    }
    
    var containerView:ChartContainer? = nil
    
    var childView = UIView()
    
    var shapeLayer = CAShapeLayer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .Centered
        containerView?.tooltip.toolTipEntryGenerator = self
        
        // Views Hide Options
        containerView?.title.titleEnabled = false
        containerView?.legend.legendEnabled = true
        //       containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
        containerView?.overview.overviewEnabled = true
        containerView?.overviewView.offsets.leftOffset = 50.0
        containerView?.overviewView.offsets.rightOffset = 50.0
        containerView?.overviewView.offsets.bottomOffset = 10
        rangeSliderConfigation()
        
        //addChartTypeAndData
        addScatterChart()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    var scatterChartView:ChartViewBase? = nil
    
    func addScatterChart()
    {
        scatterChartView = containerView?.chart//containerView?.initializeChart()
        
//        scatterChartView?.isOverviewChart = true
        
        //        scatterChartView?.rendererDelegate = self
        
        /// Handlers
        scatterChartView?.tapEventListener?.handler = ScatterHighlightHandler()
        
        scatterChartView?.panEventListener?.handler = ScatterPanHandler()
        
        scatterChartView?.longPressEventListener?.handler = ScatterLongPressHandler()
        
        scatterChartView?.pinchEventListener?.handler = ZoomingPinchHandler()
        
        
        
        scatterChartView?.getYAxis(atIndex: 1)!.enabled = false
        
        scatterChartView?.getYAxis(atIndex: 0)!.drawGridLinesEnabled = true
        
        scatterChartView?.xAxis.labelPosition = .bottom
        scatterChartView?.xAxis.axisTitle = "Movies"
        
        scatterChartView?.getYAxis(atIndex: 0)!.resizeEnabled = true
        scatterChartView?.getYAxis(atIndex: 0)!.axisTitle = "Box Office (in Millions)"
        
        scatterChartView?.xAxis.drawGridLinesEnabled = false
        
        scatterChartView?.xAxis.granularity = 1.0
        
        
        
        scatterChartView?.chartDescription?.enabled = false
        scatterChartView?.scaleXEnabled = true
        scatterChartView?.scaleYEnabled = false
        
        
        scatterChartView?.xAxis.scaleType = .Ordinal
        
        scatterChartView?.xAxis.tickLabelMode = .forced
        
        scatterChartView?.xAxis.labelRotationAngle = 60
        
        scatterChartView?.getYAxis(atIndex: 0)!.scaleType = .Linear
        
        scatterChartView?.xAxis.inverted = false
        
        //        scatterChartView?.xAxis.setTimeScaleType(type: .Auto, forcedType: TimeScaleIntervalType.ABSQUARTER)
        
        scatterChartView?.xAxis.labelCount = 14
        
        let valueFormatter = ValueFormatter(chart:self.scatterChartView!)
        scatterChartView?.xAxis.valueFormatter = valueFormatter
        
        let dollarFomatter = NumberFormatter()
        dollarFomatter.numberStyle = .currency
//        dollarFomatter.
        let ff  = ValueFormatter(chart:self.scatterChartView!)
        ff.formatter = dollarFomatter
        scatterChartView?.getYAxis(atIndex: 0)!.valueFormatter = ff
        
        
//        scatterChartView?.xAxis.spaceMinPixel = 50
//        scatterChartView?.xAxis.spaceMaxPixel = 50
        
        for axis in (scatterChartView?.getYAxisArray())!
        {
            axis.spaceMinPixel = 50
            axis.spaceMaxPixel = 50
        }
        
        
        let count = 2
        let range = 100
        
        let movieData = readStringDataFromJson()
    
        var dataEntries1: [ChartDataEntry] = []
        var dataEntries2: [ChartDataEntry] = []
        var dataEntries3: [ChartDataEntry] = []
        
        for dict in movieData
        {
            dataEntries1.append(ChartDataEntry(xString: dict["Movie"] as! String, y: Double(dict["Box office"] as! String)!, data: nil))
        }
        
        let set1 = ChartDataSet(values: dataEntries1, label: "Set1")
        set1.drawIconsEnabled = false
        set1.setColor(ChartColorTemplates.pieColor()[6])
        set1.plotType = .Scatter
        
        let dataOption = set1.dataSetOptions as! AxisChartDataSetOptions
        
        let shape = dataOption.shapeProperties
        //        shape.holeColor = ChartColorTemplates.pieColor()[3]
        shape.shapeType = .circle
//        shape.size = CGSize(width: 10.0, height: 10.0)
        shape.lineWidth = 2
//        shape.strokeColor = .black
        shape.holeColor = ChartColorTemplates.pieColor()[6]
        
        
        
        let set2 = ChartDataSet(values: dataEntries2, label: "Set2")
        set2.drawIconsEnabled = false
        set2.setColor(ChartColorTemplates.pieColor()[2])
        set2.plotType = .Scatter
        
        let dataOption2 = set2.dataSetOptions as! AxisChartDataSetOptions
        
        let shape1 = dataOption2.shapeProperties
        //        shape1.holeColor = UIColor.yellow
        shape1.shapeType = .circle
//        shape1.size = CGSize(width: 10.0, height: 10.0)
        shape1.lineWidth = 2
        
        let set3  = ChartDataSet(values: dataEntries3, label: "Set3")
        set3.drawIconsEnabled = false
        set3.setColor(ChartColorTemplates.pieColor()[4])
        set3.plotType = .Scatter
        
        let dataOption3 = set3.dataSetOptions as! AxisChartDataSetOptions
        
        let shape2 = dataOption3.shapeProperties
        //        shape2.holeColor = nil
        shape2.shapeType = .circle
//        shape2.size = CGSize(width: 10.0, height: 10.0)
        shape2.lineWidth = 2
        
        let chartData = ChartData(dataSets: [set1])
        chartData.setDrawValues(true)
        
        scatterChartView?.data = chartData
        
        guard let plotOptions = scatterChartView?.getPlotOptions() as? AxisChartPlotOptions
            else { return }
        
        plotOptions.minimumShapeSizeInPixel = 8
        plotOptions.maximumShapeSizeInPixel = 16
        
        plotOptions.maxWidthZoomRestrictionPixel = 50
        
        if let chartView = containerView?.overview.chartView {
            chartView.extraBottomOffset = 10
            setAxisForOverView(chartView: chartView)
            chartView.data = chartData
            chartData.setDrawValues(false)
            setPlotOptionForOverView(chartView: chartView)
        }
        
    }
    
    func readDataFromJson() -> [[Int]]
    {
        var finalData:[[Int]] = []
        
        if let urlPath = Bundle.main.url(forResource: "input", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [String: AnyObject] {
                    
                    if let dataArray = jsonDict["data"] as? [[AnyObject]] {
                        
                        for rowArray in dataArray
                        {
                            var row:[Int] = []
                            for element in rowArray
                            {
                                let val = element as! Int
                                row.append(val)
                            }
                            finalData.append(row)
                        }
                    }
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    func readStringDataFromJson() -> [[String: AnyObject]]
    {
        var finalData:[[String: AnyObject]] = [[:]]
        
        if let urlPath = Bundle.main.url(forResource: "MCU", withExtension: "json") {
            
            do {
                let jsonData = try Data(contentsOf: urlPath, options: .mappedIfSafe)
                
                if let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? [[String: AnyObject]] {
                        return jsonDict
                }
            }
                
            catch let jsonError {
                Log.error(jsonError)
            }
        }
        
        return finalData
    }
    
    
    func setPlotOptionForOverView(chartView: ChartViewBase) {
    
        let plotOption = chartView.getPlotOptions(type: .Scatter) as? AxisChartPlotOptions
        
        plotOption?.minimumShapeSizeInPixel = 8
        plotOption?.maximumShapeSizeInPixel = 10
        
        plotOption?.maxWidthZoomRestrictionPixel = 50
        
        plotOption?.minOffset = 0.0
    }
    
    func setAxisForOverView(chartView: ChartViewBase) {
        
//        chartView.xAxis.inverted = true
        
//        chartView.xAxis.spaceMinPixel = 50
//        chartView.xAxis.spaceMaxPixel = 50
        
        for axis in chartView.getYAxisArray()
        {
            axis.spaceMinPixel = 50
            axis.spaceMaxPixel = 50
        }
        
        chartView.xAxis.enabled = false
        chartView.getYAxis(atIndex: 0)!.visible = false
    }
    
    func rangeSliderConfigation() {
        
        guard let rangeSlider = containerView?.overviewView.rangeSlider else {
            return
        }
        
        rangeSlider.highlightShape.holeColor = .black.withAlphaComponent(0.3)
        rangeSlider.highlightShape.shapeType = .Rect
        
//        rangeSlider.unHighlightShape.shapeType = .Rect
        rangeSlider.unHighlightShape.strokeColor = nil
        rangeSlider.unHighlightShape.holeColor = .gray
//        rangeSlider.unHighlightShape.holeColor = .black.withAlphaComponent(0.3)
    }
    
}
