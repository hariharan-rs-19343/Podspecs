//
//  WordCloudViewController.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 04/08/21.
//  Copyright © 2021 charts. All rights reserved.
//

import UIKit
import  zchart

class WordCloudViewController: UIViewController,ChartViewDelegate,IToolTipEntryGenerator {
    
    func prepareToolTipEntries(entry: ChartDataEntry?) -> [ToolTipEntry] {
        
        var entries:[ToolTipEntry] = []
        
        if entry == nil
        {
//            let toolTipEntry1 = ToolTipEntry(label: "Total Sales", value: String(describing:totalSales) )
//
//            toolTipEntry1.valueTextColor = UIColor.black
//
//            toolTipEntry1.valueFont = UIFont.boldSystemFont(ofSize: 24)
//
//            entries.append(toolTipEntry1)
            
            return entries
        }
        else
        {
            let barEntry = entry!
                
            var label:String
            var value:String
                
            if barEntry.xString != nil
            {
                label = barEntry.xString!
            }
            else{
                label = String(barEntry.x)
            }
                
            if barEntry.yString != nil
            {
                value = barEntry.yString!
            }
            else{
                value = String(barEntry.y)
            }
            
            let toolTipEntry = ToolTipEntry(label:label, value: value)
            
            toolTipEntry.valueTextColor = (chartInstance?.data?.dataSets[0].color(atIndex: 0))!
            
            toolTipEntry.valueFont = UIFont.boldSystemFont(ofSize: 24)
            
            entries.append(toolTipEntry)
            
            return entries
        }
    }
    
    
    
    var containerView:ChartContainer? = nil
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        containerView = ChartContainer()
        self.view.addSubview(containerView!)
        
        let constraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        let constraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|[alignmentView]|", options: .alignAllCenterY, metrics: nil, views: ["alignmentView":containerView!])
        
        self.view.addConstraints(constraint1)
        self.view.addConstraints(constraint2)
        
        containerView?.chartViewDelegate = self
        
        //Legend Vertical or Horizontal
        containerView?.legend.legendOrientation = .Horizontal
        containerView?.legend.legendPosition = .bottom
        
        //Tooltip LeftRight or Centered
        containerView?.tooltip.toolTipType = .leftRight
        containerView?.tooltip.toolTipEntryGenerator = self
        containerView?.tooltip.leftAlignEnabled = true
        
        
        containerView?.tooltip.leftAlignEnabled = true
        
        // Views Hide Options
               containerView?.title.titleEnabled = false
//               containerView?.legend.legendEnabled = false
//               containerView?.tooltip.tooltipEnabled = false
        
        //Title View options
        containerView?.title.mainTitleSettings.text = "IOS Chart"
        containerView?.title.subTitleSettings.text = "Welcome to Zoho IOS Charts"
        
        //Title View Hide optio
        containerView?.title.mainTitleEnabled = true
        containerView?.title.subTitleEnabled = false
        
//        containerView?.legendToolTipToggleEnabled = true
        
       // containerView?.drillDownView.showView = false
        
        //addChartTypeAndData
        addBarChart()
        
        //        containerView?.toolTipView.enableMenu = false
        //        containerView?.toolTipView.menuControl?.dataSource = self
        //        containerView?.toolTipView.menuControl?.menudelegate = self
        
        // containerView?.toolTipView.menuControl?.selectionColor = UIColor.red
        
        /*REFRESH MENU REMOVED
         containerView?.enableMenu = true
        containerView?.menuControl?.dataSource = self
        containerView?.menuControl?.menudelegate = self
        
        containerView?.menuControl?.selectionColor = UIColor.red */
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func chartValueDrillPerformed(_ chartView: ChartViewBase, entry: ChartDataEntry, level: Int) {
      Log.info("Drilled")
    }
    
    
    
    var chartInstance:ChartViewBase? = nil
    
    var totalSales:CGFloat = CGFloat(0)
    
    func addBarChart()
    {
        //*****************************  initialize chart  *******************************//
        
        chartInstance = containerView?.chart
        
        chartInstance?.backgroundColor = UIColor.clear
        
        //*****************************  Handlers  *******************************//
        
        chartInstance?.tapEventListener?.handler = WordCloudHighlightHandler()
        
        chartInstance?.pinchEventListener?.handler = ZoomingPlotPinchHandler() // DefaultPinchHandler()
        
        chartInstance?.panEventListener?.handler = DefaultPanHandler()
        
        chartInstance?.pinchZoomEnabled = true
        
        /*chartInstance?.panEventListener?.handler = StackedBarPanHandler() // DefaultPanHandler() //  //CustomBarPanHandler()
        
        chartInstance?.longPressEventListener?.handler = SingleBarLongPressListener()
        
        chartInstance?.pinchEventListener?.handler = ZoomingPinchHandler()*/
    
        //*****************************  Data  *******************************//

        totalSales = 0
        
        let count = 130
        let range = 1200
        
        let xyvalues = [
            [
                "Andhra Pradesh",
                16679
            ],
            [
                "Assam",
                17944
            ],
            [
                "Bihar",
                14583
            ],
            [
                "Delhi",
                21371
            ],
            [
                "Goa",
                27398
            ],
            [
                "Gujarat",
                13581
            ],
            [
                "Haryana",
                28913
            ],
            [
                "Jharkhand",
                11462
            ],
            [
                "Karnataka",
                13769
            ],
            [
                "Kerala",
                2888
            ],
            [
                "Madhya Pradesh",
                3015
            ],
            [
                "Orissa",
                16536
            ],
            [
                "Pondicherry",
                41460
            ],
            [
                "Punjab",
                15670
            ],
            [
                "Tamil Nadu",
                19994
            ],
            [
                "Uttaranchal",
                20771
            ],
            [
                "Uttar Pradesh",
                25708
            ],
            [
                "West Bengal",
                17325
            ]
        ]
        
        var dataEntries1: [ChartDataEntry] = []
 
        for i in 0..<xyvalues.count {
            
            let xLabel = xyvalues[i][0] as! String
            
            let yVal = Double(xyvalues[i][1] as! Int)
          
            dataEntries1.append(ChartDataEntry(xString: xLabel, y: yVal, data: nil))
            
        }
        
        let set1:ChartDataSet = ChartDataSet(values: dataEntries1, label: "States")
        set1.colors = [ChartColorTemplates.pieColor()[6]]
        set1.plotType = .WordCloud
        set1.valueFont  = UIFont(name: "TimesNewRomanPS-BoldItalicMT", size: 10)!
        
     
        let chartData = ChartData(dataSet: set1)
       
        chartInstance?.data = chartData
        
        
        let plotOptions = chartInstance?.getPlotOptions() as! WordCloudPlotOptions
        
        plotOptions.minFontSize = 2
        
        plotOptions.maxFontToRestrict = 20
        
        plotOptions.rotation = [0,90]
        
//        plotOptions.outerPadding = 30
        
        
        
       /*
        //*****************************  Animation  *******************************//
        
//        chartInstance?.animate(xAxisDuration: 0.6, yAxisDuration: 0.6)
        
//        let animateBlock = SingleBarViewController.getAnimationBlock(chartView: self.chartInstance!)
        
        let animateBlock = BarHelperFunctions.getAnimationBlock(chartView: self.chartInstance!, duration: 0.5)
        
        CommonUtilities.customAnimation(chart: chartInstance!, duration: 1.0, animationBlock: animateBlock)
        
 */
  
    }
    var initialAnimationAllowed = true
    func chartBufferLoadedBeforeDraw(chartView: ChartViewBase) -> Bool {
//        barChartView?.customAnimationInProgress = false
        
        if initialAnimationAllowed
        {
            let animateBlock = getAnimationBlock()
        
            CommonUtilities.customAnimation(chart: chartInstance!,duration:1,animationBlock: animateBlock)
            
            initialAnimationAllowed = false
        }
        return true
    }
    
    func getAnimationBlock() -> (() -> Void)
    {
        
        let totalDuration = TimeInterval(1)
        
        let chart = chartInstance!
        
        let animateBlock = { [unowned chart] in
            
            if chart.data == nil
            {
                return
            }

            let allLayers = WordCloudTextLayer.getAllWordLayer(chart: chart)
            
            if allLayers.count == 0
            {
                return
            }
            
            let opacAnimator = Animator()
            
            let indexInterpolator = Interpolator.interpolate(a: Double(1), b: Double(allLayers.count-1))
            
            opacAnimator.updateBlock = { [unowned opacAnimator] in
                
                let targetIndex = Int(indexInterpolator(opacAnimator.phaseX))
                
                for i in 0..<(targetIndex+1)
                {
                    guard let textLayer = allLayers[i].sublayers?[0] as? CATextLayer else {
                        continue
                    }
                    textLayer.opacity = 1
                }
            }
            
            opacAnimator.stopBlock = { [unowned opacAnimator] in
                opacAnimator.updateBlock = nil
            }
            
            opacAnimator.animate(xAxisDuration: totalDuration)
        }
        
        return animateBlock
    }
    var dataBackup:[ChartData] = []
    
    var plotBackup:[[ChartType:IPlotOptions]] = []

    var level:Int = 0
    
    func drillPerformed(chartView: ChartViewBase, selectedEntry: ChartDataEntry?,index:Int) {

        
    }
    
    
    func drillReverted(chartView: ChartViewBase, selectedEntry: ChartDataEntry?, index: Int) {
       
    }

}

