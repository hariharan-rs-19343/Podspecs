//
//  ColorUtility.swift
//  ZChartsDemo
//
//  Created by keerthi-pt4274 on 23/11/21.
//  Copyright © 2021 zoho. All rights reserved.
//

import UIKit
import zchart

open class ColorUtility: NSUIColor{
    
    open class func color(traitCollection: UITraitCollection) -> NSUIColor{
        
        if #available(iOS 12.0, *) {
            if traitCollection.userInterfaceStyle == .light{
                return NSUIColor.black
            }
            else{
                return NSUIColor.white
            }
        } else {
            return NSUIColor.white
        }
    }
    
    open class func highlightLabelcolor(traitCollection: UITraitCollection) -> NSUIColor{
        
        if #available(iOS 12.0, *) {
            if traitCollection.userInterfaceStyle == .light{
                return NSUIColor.black
            }
            else{
                return NSUIColor.white
            }
        } else {
            return NSUIColor.white
        }
    }
    
    open class func themeFlag(traitCollection: UITraitCollection) -> Bool{
        
        if #available(iOS 12.0, *) {
            if traitCollection.userInterfaceStyle == .light{
                return true
            }
            else{
                return false
            }
        } else {
            return true
        }
    }
}
