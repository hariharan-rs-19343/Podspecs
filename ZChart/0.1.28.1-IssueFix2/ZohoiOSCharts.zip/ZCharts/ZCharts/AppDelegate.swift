//
//  AppDelegate.swift
//  ZCharts
//
//  Created by Aravinth T on 29/06/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    var navController: UINavigationController?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
//        return true
        
        self.window = UIWindow(frame: UIScreen.main.bounds)
        
        self.navController = UINavigationController()
        
        self.navController?.navigationBar.isTranslucent = false
        
        if #available(iOS 13.0, *) {
            let demoViewController = ChartListController()
            
            demoViewController.window = window
            
            self.navController!.pushViewController(demoViewController, animated: false)
            
            self.window!.rootViewController = navController
            
            self.window!.backgroundColor = .systemBackground
            
            self.window!.makeKeyAndVisible()
            
        } else {
            // Fallback on earlier versions
        }
        
        return true

    }
}

