//
//  ChartListController.swift
//  ZCharts
//
//  Created by Aravinth T on 28/08/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

@available(iOS 13.0, *)
class ChartListController: UIViewController {
    
    var ChartNames = ["Pie","Bar","Mekko","Sankey","WaterFall","BoxPlot","Line","Radar","Dial","Bullet Charts","Area","Scatter","Bubble","Funnel","Heat Map ","Hierarchical Chart","Text Chart","Geo Map","Overview Chart","Combined Charts ","Combined Filter","Performance Chart","Others"]
    
    var Categories = [
                        [
                            ["Name":"Pie ", "class":"PieViewController","Assets":"Pie"],
                            ["Name":"Pie - Spin Wheel", "class":"ArrowPieController","Assets":"Spin wheel"],
                            ["Name":"Donut", "class":"DonutViewController","Assets":"Donut"],
                            ["Name":"Pie - Numeric Color", "class":"PieContinuousLegendVC", "Assets":"Pie Num"],
                            ["Name":"Pie Configurable", "class":"PieConfigurableViewController","Assets":"Pie"],
                        ],
                        [
                            ["Name":"SingleBar ", "class":"SingleBarViewController", "Assets":"Bar"],
                            ["Name":"Bar - RoundedCorner", "class":"SingleBarRoundedCornerViewController", "Assets":"Bar"],
                            ["Name":"HorizontalBar ", "class":"HorizontalBarViewController", "Assets":"Horizontal Bar"],
                            ["Name":"MultiBar ", "class":"MultiBarViewController", "Assets":"Grouped Bar"],
                            ["Name":"HorizontalMultiBar ", "class":"HorizontalMultiBarViewController", "Assets":"Horizontal Grouped Bar"],
                            ["Name":"Stacked ", "class":"StackedBarViewController", "Assets":"Stacked Bar"],
                            ["Name":"HorizontalStackedBar ", "class":"HorizontalStackedBarViewController", "Assets":"Horizontal Stacked Bar"],
                            ["Name":"Stacked Grouping", "class":"MultiStackedBarViewController", "Assets":"MultiStackedBar-vertical"],
                            ["Name":"Horizontal Stacked Grouping ", "class":"HorizontalMultiStackedBarViewController", "Assets":"MultiStackedBar-vertical"],
                            ["Name":"MultiYAxis", "class":"MultiYAxisViewController", "Assets":"Multi axis"],
                            ["Name":"BaseLine HorizontalBar ", "class":"BaseLineHorizontalBarViewController", "Assets":"Horizontal Bar multi"],
                            ["Name":"StackedBar - Percentage", "class":"StackedPercentageViewController", "Assets":"Stacked Bar percent"],
                            ["Name":"StackedBar - Negativedata", "class":"NegativeValueStackViewController", "Assets":"Stacked Bar"],
                            ["Name":"Histogram ", "class":"HistogramViewController", "Assets":"Histogram"],
                            ["Name":"Butterfly ", "class":"ButterflyViewController", "Assets":"Butterfly"],
                            ["Name":"Simple Forecast Bar", "class":"SimpleForecastBarViewController", "Assets":"MultiStackedBar-vertical"],
                            ["Name":"Multi Forecast Bar", "class":"MultiForecastBarViewController", "Assets":"MultiStackedBar-vertical"],
                            ["Name":"Multi Stacked Forecast Bar", "class":"MultiStackedForecastBarViewController", "Assets":"MultiStackedBar-vertical"],
                        ],
                        [
                            ["Name":"Simple Mekko","class":"MariMekkoChartViewController", "Assets":"Marimekko-vertical"]
                        ],
                        [
                            ["Name":"Simple Sankey","class":"SankeyViewController", "Assets":"Sankey"]
                        ],
                        [
                            ["Name":"WaterFall","class":"WaterFallViewController", "Assets":"Waterfall-vertical"],
                            ["Name":"HorizontalWaterFall","class":"HorizontalWaterFallViewController", "Assets":"Waterfall-horizontal"],
                            ["Name":"GroupedWaterFall","class":"ClusteredWaterFallViewController", "Assets":"MultiWaterfall-vertical"],
                            ["Name":"Horizontal GroupedWaterFall","class":"HorizontalClusteredWaterFallViewController", "Assets":"MultiWaterfall-horizontal"],
                            ["Name":"StackedWaterFall","class":"StackedWaterFallViewController", "Assets":"StackedWaterfall-vertical"],
                            ["Name":"Horizontal StackedWaterFall","class":"HorizontalStackedWaterFallViewController", "Assets":"StackedWaterfall-horizontal"]
                        ],
                        [
                            ["Name":"BoxPlot","class":"BoxPlotViewController", "Assets":"BoxPlot-vertical"],
                            ["Name":"HorizontalBoxPlot","class":"HorizontalBoxPlotViewController", "Assets":"BoxPlot-horizontal"],
                            ["Name":"MultiBoxPlot", "class": "MultiBoxPlotViewController", "Assets":"MultiBoxPlot-vertical"],
                            ["Name":"HorizontalMultiBoxPlot", "class":"HorizontalMultiBoxPlotViewController", "Assets":"MultiBoxPlot-horizontal"]
                        ],
                        [
                            ["Name":"LineChart ", "class":"LineViewController", "Assets":"Line"],
                            ["Name":"Line - TimeScale", "class":"LineViewTimeScaleController", "Assets":"Multi Line"],
                            ["Name":"LineRangeChart ", "class":"LineRangeViewController", "Assets":"LineRange-vertical"]
                        ],
                        [
                                ["Name":"Simple Radar Chart", "class":"RadarViewController","Assets":"Radar Web"],
                                ["Name":"Multi Series Radar Chart", "class":"RadarMultiDatasetViewController","Assets":"Multi Radar Web"],
                                ["Name":"Stacked Radar Chart", "class":"RadarStackedViewController","Assets":"Multi Radar Web stacked"]
                        ],
                        [
                            ["Name":"Simple Dial", "class":"DialViewController","Assets":"Dial"],
                            ["Name":"Dial With Target", "class":"DialTargetViewController","Assets":"Dial target"],
                            ["Name":"Dial With Axis", "class":"DialAxisViewController","Assets":"Dial axis"]
                        ],
                        [
                            ["Name":"SingleBullet ", "class":"BulletBarViewController", "Assets":"Bullet"],
                            ["Name":"SingleBulletHorizontal ", "class":"HorizontalBulletBarViewController", "Assets":"Horizontal Bullet"],
                            ["Name":"MultiBullet ", "class":"MultiBulletBarViewController", "Assets":"multi Bullet"],
    //                            ["Name":"MultiStackedBullet ", "class":"MultiStackedBulletBarViewController"]
                        ],
                        [
                            ["Name":"AreaChart ", "class":"AreaViewController", "Assets":"Area"],
                            ["Name":"AreaStackedChart ", "class":"AreaStackedViewController", "Assets":"stacked Area"],
                            ["Name":"AreaChart - BaseLine", "class":"BaseLineAreaViewController", "Assets":"multi Area"],
                            ["Name":"AreaRangeChart ", "class":"AreaRangeViewController", "Assets":"Area"],
                            ["Name":"AreaRange-Line ", "class":"AreaRangeLineViewController", "Assets":"LineRange-vertical"],
                            ["Name":"Forecast-Example ", "class":"AreaRangeLineForeCastViewController", "Assets":"Forecast-vertical"]
                        ],
                        [
                            ["Name":"ScatterChart ", "class":"ScatterViewController", "Assets":"Scatter"]
                        ],
                        [
                            ["Name":"BubbleChart ", "class":"BubbleViewController", "Assets":"Bubble"],
                            ["Name":"BubblePie ", "class":"BubblePieViewController", "Assets":"BUbble Pie"]
                        ],
                        [
                            ["Name":"FunnelChart - Height ", "class":"FunnelViewController", "Assets":"Funnel"],
                            ["Name":"FunnelChart - Width ", "class":"FunnelWidthViewController", "Assets":"Funnel 2"]
                        ],
                        [
                            ["Name":"Simple HeatMap ", "class":"HeatMapViewController", "Assets":"Heat Map"]
                        ],
                        [
                            ["Name":"Packed Bubble ", "class":"PackedBubbleViewController", "Assets":"Packed Bubble"],
                            ["Name":"Flat Bubble ", "class":"FlatPackedBubbleViewController", "Assets":"Multi Packed Bubble"]
                        ],
                        [
                            ["Name":"Word Cloud ", "class":"WordCloudViewController", "Assets":"Word Cloud"],
                            ["Name":"Multi Series Word Cloud ", "class":"MultiWordCloudViewController", "Assets":"multi Word Cloud"],
                            ["Name":"Color Axis Word Cloud ", "class":"WordCloudColorAxisViewController", "Assets":"Word Cloud axis"],
                            ["Name":"Word Cloud Filter", "class":"WordCloudFilterViewController", "Assets":"Word Cloud"],
                        ],
                        [
                            ["Name":"Simple Geo Map", "class":"SimpleGeoMapViewController", "Assets":"Worldmap"],
                            ["Name":"US Geo Map", "class":"USGeoMapViewController", "Assets":"USmap"]
                        ],
                        [
                            ["Name":"Bar OverviewChart", "class":"BarOverviewChartViewController","Assets":""],
                            ["Name":"HorizontalBar OverviewChart", "class":"HorizontalBarOverviewChartViewController","Assets":""],
                            ["Name":"Area OverviewChart", "class":"AreaOverviewChartViewController","Assets":""],
                            ["Name":"Bubble OverviewChart", "class":"BubbleOverviewChartViewController","Assets":""],
                            ["Name":"Scatter OverviewChart", "class":"ScatterOverviewChartViewController","Assets":""],
                            ["Name":"BoxPlot OverviewChart", "class":"BoxPlotOverviewChartViewController","Assets":""]
                        ],
                        [
                            ["Name":"Bar-Line ", "class":"CombinedBarLineViewController", "Assets":"bar - line"],
                            ["Name":"Bar-Area ", "class":"CombinedBarAreaViewController", "Assets":"bar - area"],
                            ["Name":"Scatter-Line ", "class":"CombinedLineScatterViewController", "Assets":"scatter - line-1"],
                            ["Name":"Bubble-Line ", "class":"CombinedLineBubbleViewController", "Assets":"bubble - line"],
                            ["Name": "PerCell Bar-Scatter" , "class": "PerCellBarScatterViewController", "Assets":""],
                            ["Name": "TrendLine" , "class": "TrendLineViewController", "Assets":""]
                        ],
                        [
                            ["Name":"Bar-Line Filter ", "class":"CombinedFilterBarLineViewController", "Assets":"bar - line"],
                            ["Name":"Scatter-Area Filter ", "class":"CombinedFilterScatterLineViewController", "Assets":"scatter - area"],
                            ["Name":"Bar-Scatter-Line-Bubble Filter ", "class":"CombinedChartsFilterViewController", "Assets":"bar-scatter-line-bubble"]
                        ],
                        [
                            ["Name":"Bar ", "class":"SegmentedStackedBarViewController", "Assets":"Multi axis"],
                            ["Name":"Line ", "class":"LinePerformanceViewController", "Assets":"Multi Line"],
                            ["Name":"Scatter ", "class":"ScatterPerformanceViewController", "Assets":"multi Scatter"],
                            ["Name":"Scroll View Charts ", "class":"PerformanceCollectionViewController", "Assets":""]
                        ],
                        [
                            ["Name":"Change Charts ", "class":"ChartChangeViewController", "Assets":""],
                            ["Name":"MultipleChart ", "class":"MultipleChartViewController", "Assets":"Dashboard view"],
                            ["Name":"Preview Vertical Bar ", "class":"PreviewBarViewController", "Assets":"Scroll"],
                            ["Name":"Annotation","class":"AnnotationDemoViewController","Assets":""],
                            ["Name":"PopUpView","class":"PopUpDemoViewController","Assets":""],
                            ["Name":"customLegend","class":"CustomLegendDemoViewController","Assets":""],
                            ["Name":"WaterFall CustomLegend", "class":"WaterFallCustomLegendViewController","Assets":""],
                            ["Name":"WaterFallCustomLegend", "class":"WaterFallCustomLegendViewController","Assets":""],
                            ["Name":"Pyramid ", "class":"PyramidViewController", "Assets":""],
                            ["Name":"Staircase ", "class":"StairCaseViewController", "Assets":""],
                            ["Name":"ZohoCharts JSON Input", "class":"ParserViewController", "Assets":""]
                        ]
                    ]
    
    // Data model for first page
    var chartList = [ChartListDataModel]()
    
    func importDataModel() {
        
        let sequence = zip(ChartNames,Categories)
        
        for (chart,chartcategory) in sequence{
            
            var categoryList = [CategoryListDataModel]()
            
            for charts in chartcategory{
                categoryList.append(CategoryListDataModel(name: charts["Name"] ?? "", className: charts["class"] ?? "",chartImageName: charts["Assets"] ?? ""))
                
            }
            chartList.append(ChartListDataModel(chartName: chart, categoryOfChart: categoryList))
        }
    }
    
    var window: UIWindow?
    
    var searchBar: UISearchBar!
    
    var chartListCollectionView: UICollectionView!
    
    var flowLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    
    var datasource: UICollectionViewDiffableDataSource<Section,ChartListDataModel>!
    
    var snapshot = NSDiffableDataSourceSnapshot<Section,ChartListDataModel>()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        importDataModel()
        
        self.title = "ZCHARTS"
        
        self.navigationController?.navigationBar.barTintColor = .secondarySystemBackground
        
        setUpCollectionView()
        
        setUpNavigationItem()
        
        configureDataSource()
        
        orientationConstains()
        
        preformSnapshot(searchText: "", flag: false)
    }
    
    func setUpCollectionView(){
        
        chartListCollectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        
        chartListCollectionView.register(ChartListCollectionViewCell.self, forCellWithReuseIdentifier: "ChartListCell")
        
        view.addSubview(chartListCollectionView)
        
        chartListCollectionView.delegate = self
        
        if #available(iOS 13.0, *) {
            chartListCollectionView.backgroundColor = .systemBackground
        } else {
            // Fallback on earlier versions
        }
        
        setUpContaints()
    }
    
    func setUpContaints(){
        chartListCollectionView.translatesAutoresizingMaskIntoConstraints = false
        
        if #available(iOS 11.0, *) {
            view.addConstraints([
                chartListCollectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
                chartListCollectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
                chartListCollectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: 10),
                chartListCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
            ])
        } else {
            // Fallback on earlier versions
        }
    }
    
    func setUpSearchBar(){
        
        searchBar = UISearchBar(frame: .zero)
        
        searchBar.placeholder = "search"
        
        searchBar.delegate = self
        
        searchBar.showsCancelButton = false
        
        self.navigationItem.titleView = searchBar
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancelOperation))
        
        searchBar.setNeedsLayout()
    }
    
    func setUpNavigationItem(){
        
        let title = UILabel()
        
        title.text = "ZCHARTS"
        
        self.navigationItem.titleView = title
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(searchBarOperation))
        
        setUpThemeButton()
    }
    
    func setUpThemeButton(){
        let themeButton = UIButton(type: .custom)
        
        themeButton.frame = CGRect(x: 0.0, y: 0.0, width: 16.0, height: 16.0)
        
        themeButton.setImage(themeImage(), for: .normal)
        
        themeButton.addTarget(self, action: #selector(darkMode), for: UIControl.Event.touchUpInside)

        let themeButtonItem = UIBarButtonItem(customView: themeButton)
        
        let currWidth = themeButtonItem.customView?.widthAnchor.constraint(equalToConstant: 20)
        currWidth?.isActive = true
        
        let currHeight = themeButtonItem.customView?.heightAnchor.constraint(equalToConstant: 20)
        currHeight?.isActive = true
        
        self.navigationItem.leftBarButtonItem = themeButtonItem
    }
    
    func themeImage() -> UIImage{
        let themeImage: UIImage!

        if ColorUtility.themeFlag(traitCollection: traitCollection) {
            themeImage = UIImage(named: "dark-mode")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        else{
            themeImage = UIImage(named: "light-mode")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        }
        
        return themeImage
    }
    
    @objc func searchBarOperation(){
        setUpSearchBar()
    }
    
    @objc func cancelOperation(){
        
        searchBar.removeFromSuperview()
        
        preformSnapshot(searchText: "", flag: false)
        
        setUpNavigationItem()
    }
    
    @objc func darkMode(){

        if traitCollection.userInterfaceStyle == .light{
            window?.overrideUserInterfaceStyle = .dark
        }
        else{
            window?.overrideUserInterfaceStyle = .light
        }
        
        self.navigationItem.leftBarButtonItem = nil
        
        setUpThemeButton()
        
    }
    
    //data source
    
    func configureDataSource(){
        
        //Initials diffable data source with cell provider
        
        datasource = UICollectionViewDiffableDataSource<Section,ChartListDataModel>(collectionView: chartListCollectionView , cellProvider: {
            (chartListCollectionView, indexPath, ChartListDataModel) -> ChartListCollectionViewCell? in
            
            let cell = chartListCollectionView.dequeueReusableCell(withReuseIdentifier: "ChartListCell", for: indexPath) as! ChartListCollectionViewCell
            
//            cell.layer.shouldRasterize = true
//
//            cell.layer.rasterizationScale = UIScreen.main.scale
            
            cell.cellData = ChartListDataModel
            
            cell.chartName.text = ChartListDataModel.chartName
            
            cell.navigation = self.navigationController
            
            cell.collectionView.reloadData()
            
            return cell
        })
    }
    
    func preformSnapshot(searchText: String,flag: Bool){
        
        var snapshot = NSDiffableDataSourceSnapshot<Section,ChartListDataModel>()
        
        snapshot.appendSections([Section.main])
        
        let listOfCharts: [ChartListDataModel] = chartList
        
        //apply intial snapshot
        
        if(flag == false){
            
            snapshot.appendItems(listOfCharts)
            
        }
        //apply snapshot based on filtered text
        else{
            var searchBy = [ChartListDataModel]()
            
            for chart in listOfCharts{
                
                var founded = false
                
                if chart.contains(searchText: searchText) {
                    founded = true
                }
                
                var searchByCategory = [CategoryListDataModel]()
                
                for category in chart.categoryOfChart {
                    
                    if category.contains(searchText: searchText) {
                        searchByCategory.append(category)
                        founded = true
                    }
                }
                
                if founded{
                    
                    if searchByCategory.count != 0{
                        searchBy.append(ChartListDataModel(chartName: chart.chartName, categoryOfChart: searchByCategory))
                    }
                    else{
                        searchBy.append(chart)
                    }
                    
                }
            }
            
            if searchBy.count > 0{
                
                snapshot.appendItems(searchBy)
                
            }
            
        }
        datasource.apply(snapshot,animatingDifferences: true)
            
    }
    
    var numberOfRows: CGFloat = 0.0
    
    var height: CGFloat = 0.0
    
    func DimensionForCollectionView(){
        let cellSize: CGFloat = 150.0
        
        numberOfRows = floor(chartListCollectionView.bounds.height / cellSize )
        
        height = chartListCollectionView.bounds.height / numberOfRows
    }
    
    func orientationConstains(){
        if true == UIDevice.current.orientation.isPortrait{
            DimensionForCollectionView()
        }
        else{
            DimensionForCollectionView()
        }
    }

}

@available(iOS 13.0, *)
extension ChartListController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        DimensionForCollectionView()
        
        return CGSize(width: chartListCollectionView.bounds.width, height: self.height)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        orientationConstains()
        
        chartListCollectionView.reloadData()
        
        flowLayout.invalidateLayout()
    }
}

//search Bar delegate

@available(iOS 13.0, *)
extension ChartListController: UISearchBarDelegate{
    
    //function gets called when text is enter into search bar
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if(searchBar.text == ""){
            preformSnapshot(searchText: "", flag: false)
        }
        else{
            preformSnapshot(searchText: searchText, flag: true)
        }
    }
}
