//
//  SankeyGenerator.js
//  d3 js
//

function targetDepth(d) {
  return d.target.depth;
}

function doPackLayout(values, size, sankeyOptions)
{
    var left = function left(node) {
      return node.depth;
    }

    var right = function right(node, n) {
      return n - 1 - node.height;
    }

    var justify = function justify(node, n) {
      return node.sourceLinks.length ? node.depth : n - 1;
    }

    var center = function center(node) {
      return node.targetLinks.length ? node.depth
          : node.sourceLinks.length ? d3.min(node.sourceLinks, targetDepth) - 1
          : 0;
    }
    
    var sankeyLayout = d3.sankey().nodeWidth(sankeyOptions.nodeWidth).nodePadding(sankeyOptions.nodePadding).extent(size);
    
    if (sankeyOptions.align != null)
    {
        var alignFunction = justify;
        switch(sankeyOptions.align) {
          case "left":
            alignFunction = left;
            break;
          case "right":
            alignFunction = right;
            break;
          case "justify":
            alignFunction = justify;
            break;
          case "center":
            alignFunction = center;
            break;
          default:
            alignFunction = justify;
        }
        sankeyLayout = sankeyLayout.nodeAlign(alignFunction);
    }
    
    var sankeyData = sankeyLayout(values)
    
    var finalValues = []
    finalValues.push(sankeyData)
    return finalValues
}


