//
//  ContainerLayout.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

class ContainerLayout: NSObject {
    
    static func activateConstraintsForTitleView(titleView: TitleView)
    {
        let leadingAnchor = titleView.leadingAnchor
        let trailingAnchor = titleView.trailingAnchor
        let topAnchor = titleView.topAnchor
        let heightAnchor = titleView.heightAnchor
        
        let mainTitle = titleView.mainTitle
        let subTitle = titleView.subTitle
        let lineView = titleView.lineDesign
        
        var mainTitleHeightFactor:CGFloat = 0.48
        var subTitleHeightFactor:CGFloat = 0.48
        var lineHeightFactor:CGFloat = 0.04
        
        if !mainTitle.enable{
            mainTitleHeightFactor = 0.0
            subTitleHeightFactor = subTitleHeightFactor * 2.0
            
        }
        
        if !subTitle.enable {
            subTitleHeightFactor = 0.0
            mainTitleHeightFactor = mainTitleHeightFactor * 2.0
        }
        
        if !titleView.showView {
            lineHeightFactor = 0.0
        }
        
        //Title
        let mainTitleLeadingAnchor = mainTitle.leadingAnchor.constraint(equalTo: leadingAnchor)
        let mainTitleTrailingAnchor = mainTitle.trailingAnchor.constraint(equalTo: trailingAnchor)
        let mainTitleTopAnchor = mainTitle.topAnchor.constraint(equalTo: topAnchor)
        let mainTitleHeightAnchor = mainTitle.heightAnchor.constraint(equalTo: heightAnchor, multiplier: mainTitleHeightFactor)
        
        
        
        //Legend
        let subTitleLeadingAnchor = subTitle.leadingAnchor.constraint(equalTo: leadingAnchor)
        let subTitleTrailingAnchor = subTitle.trailingAnchor.constraint(equalTo: trailingAnchor)
        let subTitleTopAnchor = subTitle.topAnchor.constraint(equalTo: mainTitle.bottomAnchor)
        let subTitleHeightAnchor = subTitle.heightAnchor.constraint(equalTo: heightAnchor, multiplier: subTitleHeightFactor)
        
        // Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let lineTopAnchor = lineView.topAnchor.constraint(equalTo: subTitle.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineHeightFactor)
        
        
        
        if titleView.oldConstraints.count > 0 {
            NSLayoutConstraint.deactivate(titleView.oldConstraints)
            //titleView.removeConstraints(titleView.oldConstraints)
        }
        
        titleView.oldConstraints = [ mainTitleLeadingAnchor, mainTitleTrailingAnchor, mainTitleTopAnchor, mainTitleHeightAnchor,
                                     subTitleLeadingAnchor, subTitleTrailingAnchor, subTitleTopAnchor, subTitleHeightAnchor,
                                     lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor]
        
        //titleView.addConstraints(titleView.oldConstraints)
        NSLayoutConstraint.activate(titleView.oldConstraints)
        
    }
    
    static func constraintsForHorizontalLegendLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
        
        let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = containerView.widthAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        var legendViewHeightFactor:CGFloat = 0.15
        if !legendView.showView {
            legendViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        
        var lineViewHeightFactor:CGFloat = 0.02
                if !legendView.showView {
                    lineViewHeightFactor = 0.0
                }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor

        
        var tooltipViewHeightFactor:CGFloat = 0.74
        var tooltipViewWidthFactor:CGFloat = 0.5
        if !toolTipView.showView {
            //tooltipViewHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        else
        {
            tooltipViewHeightFactor = totalHeightPercent
        }
        
        totalWidthPercent = totalWidthPercent - tooltipViewWidthFactor
        //totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        
        var chartViewHeightFactor:CGFloat = 0.74
        var chartViewWidthFactor:CGFloat = 0.5
        if !chartView.showView {
            chartViewHeightFactor = 0.0
        }else {
            chartViewHeightFactor = totalHeightPercent
            chartViewWidthFactor = totalWidthPercent
            
        }
        
        totalHeightPercent = totalHeightPercent - chartViewHeightFactor
        totalWidthPercent = totalWidthPercent - chartViewWidthFactor
        
        print("Landscape :: Total Percent", totalHeightPercent, "Title ", titleViewHeightFactor, " Legend ", legendViewHeightFactor, "Tooltip ", tooltipViewHeightFactor, "Chart ", chartViewHeightFactor, "Chart Width ", chartViewWidthFactor)
        
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: chartView.leadingAnchor)
        let tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        let tooltipWidthAnchor = toolTipView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: tooltipViewWidthFactor)
        
        
        //Chart
        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: toolTipView.trailingAnchor)
        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: chartViewWidthFactor)
        
        let centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        let widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        let heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor, multiplier: 3/3 )
        
        
        //TooltipContentView
        let toolTipContentViewCenterX = toolTipView.contentView.centerXAnchor.constraint(equalTo: toolTipView.centerXAnchor)
        let toolTipContentViewCenterY = toolTipView.contentView.centerYAnchor.constraint(equalTo: toolTipView.centerYAnchor)
        let toolTipContentViewHeight  = toolTipView.contentView.heightAnchor.constraint(equalTo: toolTipView.heightAnchor, multiplier: 2/3)
        
        let toolTipContentViewWidth  = toolTipView.contentView.widthAnchor.constraint(equalTo: toolTipView.widthAnchor, multiplier: (98/100))
        
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,tooltipWidthAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor, chartWidthAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
             centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
             toolTipContentViewCenterX,toolTipContentViewCenterY,toolTipContentViewHeight,toolTipContentViewWidth]
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    }
    
    
    static func constraintsForHorizontalLegendPortrait(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        print("In Contianer Layout")
        
        let titleView = containerView.titleView
        let legendView = containerView.legendView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let lineView = containerView.lineView
        
        let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        var legendViewHeightFactor:CGFloat = 0.10
        if !legendView.showView {
            legendViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        
        
        var lineViewHeightFactor:CGFloat = 0.02
                if !legendView.showView {
                   lineViewHeightFactor = 0.0
               }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor
        
        
        var tooltipViewHeightFactor:CGFloat = 0.15

        if !toolTipView.showView {
            tooltipViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        
        var chartViewHeightFactor:CGFloat = 0.63
        if !chartView.showView {
            chartViewHeightFactor = 0.0
        }else {
            chartViewHeightFactor = totalHeightPercent
        }
        
        totalHeightPercent = totalHeightPercent - chartViewHeightFactor
        
        print("Total Percent", totalHeightPercent, "Title ", titleViewHeightFactor, " Legend ", legendViewHeightFactor, "Tooltip ", tooltipViewHeightFactor, "Chart ", chartViewHeightFactor)
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let lineTopAnchor = lineView.topAnchor.constraint(equalTo: legendView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        
        
        //Chart
        
        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        
        let centerXLegColl = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegColl = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        let widthLegColl = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor)
        let heightLegColl = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor )
        
        
        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 10)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -10)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
              centerXLegColl!, centerYLegColl!, widthLegColl!, heightLegColl!,
              toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom ]
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    }
    
    
    static func constraintsForVerticalLegendPortrait(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        print("Contianer Layout : Vertical Legend , Portrait Mode")
        
        let titleView = containerView.titleView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let legendView = containerView.legendView
         let lineView = containerView.lineView
        
        
        
        let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.1
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        
        var tooltipViewHeightFactor:CGFloat = 0.15
        if !toolTipView.showView {
            tooltipViewHeightFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        
        var legendViewHeightFactor:CGFloat = 0.24
        if !legendView.showView {
            legendViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        
        var lineViewHeightFactor:CGFloat = 0.04
               if !legendView.showView {
                    lineViewHeightFactor = 0.0
                }
        totalHeightPercent = totalHeightPercent - lineViewHeightFactor

        
        //var chartViewHeightFactor:CGFloat = 0.5
        let chartViewHeightFactor = totalHeightPercent
        
        
        print("Total Percent", totalHeightPercent, "Title ", titleViewHeightFactor, " Legend ", legendViewHeightFactor, "Tooltip ", tooltipViewHeightFactor, "Chart ", chartViewHeightFactor)
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        
        
        //Chart
        
        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let legendTopAnchor = legendView.topAnchor.constraint(equalTo: lineView.bottomAnchor)
        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        
        //Line
        let lineLeadingAnchor = lineView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let lineTrailingAnchor = lineView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let lineTopAnchor = lineView.topAnchor.constraint(equalTo: chartView.bottomAnchor)
        let lineHeightAnchor = lineView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: lineViewHeightFactor)
        
        let centerXLegendCollection = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegendCollection = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        let widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 2/3)
        let heightLegendCollection = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor)

        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 10)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -10)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 10)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor,
             lineLeadingAnchor, lineTrailingAnchor, lineTopAnchor, lineHeightAnchor,
              centerXLegendCollection!, centerYLegendCollection!, widthLegendCollection!, heightLegendCollection!,
              toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom ]
        
        
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    }
    
    static func constraintsForVerticalLegendLandscape(containerView:ChartContainer) -> [NSLayoutConstraint]
    {
        
        print("Contianer Layout : Vertical Legend , Landscape Mode")
        
        let titleView = containerView.titleView
        let toolTipView = containerView.toolTipView
        let chartView = containerView.chartView
        let legendView = containerView.legendView
        
        
        let leadingAnchor = containerView.leadingAnchor
        let trailingAnchor = containerView.trailingAnchor
        let topAnchor = containerView.topAnchor
        let heightAnchor = containerView.heightAnchor
        let widthAnchor = containerView.widthAnchor
        
        
        var totalHeightPercent:CGFloat = 1.0
        var totalWidthPercent:CGFloat = 1.0
        
        var titleViewHeightFactor:CGFloat = 0.15
        if !titleView.showView {
            titleViewHeightFactor = 0.0
        }
        totalHeightPercent = totalHeightPercent - titleViewHeightFactor
        
        
        //var legendViewHeightFactor:CGFloat = 0.85
        var legendViewHeightFactor:CGFloat = totalHeightPercent
        var legendViewWidthFactor:CGFloat = 0.4
        if !legendView.showView {
            legendViewHeightFactor = 0.0
            legendViewWidthFactor = 0.0
        }
        //totalHeightPercent = totalHeightPercent - legendViewHeightFactor
        totalWidthPercent = totalWidthPercent - legendViewWidthFactor
        
        
        var tooltipViewHeightFactor:CGFloat = 0.15
        var tooltipViewWidthFactor:CGFloat = 0.6
        if !toolTipView.showView {
            tooltipViewHeightFactor = 0.0
            tooltipViewWidthFactor = 0.0
        }
        
        totalHeightPercent = totalHeightPercent - tooltipViewHeightFactor
        
        //var chartViewHeightFactor:CGFloat = 0.75, chartViewWidthFactor = 0.6
        let chartViewHeightFactor = totalHeightPercent
        let chartViewWidthFactor = totalWidthPercent
        
        
        print("Total Percent", totalHeightPercent, "Title ", titleViewHeightFactor, " Legend ", legendViewHeightFactor, "Tooltip ", tooltipViewHeightFactor, "Chart ", chartViewHeightFactor)
        print("Legend Height ", legendViewHeightFactor, " Width ", legendViewWidthFactor)
        print("Tooltip Height ", tooltipViewHeightFactor, "  Width ", tooltipViewWidthFactor)
        print(" Chart Height ", chartViewHeightFactor, " Width ", chartViewWidthFactor )
        
        var constraints:[NSLayoutConstraint] = []
        
        //Title
        let titleLeadingAnchor = titleView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let titleTrailingAnchor = titleView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let titleTopAnchor = titleView.topAnchor.constraint(equalTo: topAnchor)
        let titleHeightAnchor = titleView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: titleViewHeightFactor)
        
        //Legend
        let legendLeadingAnchor = legendView.leadingAnchor.constraint(equalTo: leadingAnchor)
        let legendTrailingAnchor = legendView.trailingAnchor.constraint(equalTo: toolTipView.leadingAnchor)
        let legendTopAnchor = legendView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let legendHeightAnchor = legendView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: legendViewHeightFactor)
        let legendWidthAnchor = legendView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: legendViewWidthFactor)
        
        
        //Tooltip
        let tooltipLeadingAnchor = toolTipView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
        let tooltipTrailingAnchor = toolTipView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let tooltipTopAnchor = toolTipView.topAnchor.constraint(equalTo: titleView.bottomAnchor)
        let tooltipHeightAnchor = toolTipView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: tooltipViewHeightFactor)
        // let tooltipWidthAnchor = toolTipView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: tooltipViewWidthFactor)
        
        
        
        //Chart
        let chartLeadingAnchor = chartView.leadingAnchor.constraint(equalTo: legendView.trailingAnchor)
        let chartTrailingAnchor = chartView.trailingAnchor.constraint(equalTo: trailingAnchor)
        let chartTopAnchor = chartView.topAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        let chartHeightAnchor = chartView.heightAnchor.constraint(equalTo: heightAnchor, multiplier: chartViewHeightFactor)
        // let chartWidthAnchor = chartView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: chartViewWidthFactor)
        
        
        let topLegendCollection = legendView.collectionView?.topAnchor.constraint(equalTo: legendView.topAnchor, constant: 20)
        let centerXLegendCollection = legendView.collectionView?.centerXAnchor.constraint(equalTo: legendView.centerXAnchor)
        let centerYLegendCollection = legendView.collectionView?.centerYAnchor.constraint(equalTo: legendView.centerYAnchor)
        
        //let width = collectionView?.widthAnchor.constraint(equalTo: self.widthAnchor, constant : ())
        let widthLegendCollection = legendView.collectionView?.widthAnchor.constraint(equalTo: legendView.widthAnchor, multiplier: 3/3)
        let heightLegendCollection = legendView.collectionView?.heightAnchor.constraint(equalTo: legendView.heightAnchor)

        
        //TooltipContentView
        let toolTipcontentViewLeading = toolTipView.contentView.leadingAnchor.constraint(equalTo: toolTipView.leadingAnchor, constant: 10)
        let toolTipcontentViewTrailing = toolTipView.contentView.trailingAnchor.constraint(equalTo: toolTipView.trailingAnchor, constant: -10)
        let toolTipcontentViewTop = toolTipView.contentView.topAnchor.constraint(equalTo: toolTipView.topAnchor,constant: 5)
        let toolTipcontentViewBottom = toolTipView.contentView.bottomAnchor.constraint(equalTo: toolTipView.bottomAnchor)
        
        let allConstraints =
            [titleLeadingAnchor, titleTrailingAnchor, titleTopAnchor, titleHeightAnchor,
             legendLeadingAnchor, legendTrailingAnchor, legendTopAnchor, legendHeightAnchor, legendWidthAnchor,
             tooltipLeadingAnchor, tooltipTrailingAnchor, tooltipTopAnchor, tooltipHeightAnchor,
             chartLeadingAnchor, chartTrailingAnchor, chartTopAnchor, chartHeightAnchor,
             centerXLegendCollection!, centerYLegendCollection!, widthLegendCollection!, heightLegendCollection!,topLegendCollection!,
               toolTipcontentViewLeading,toolTipcontentViewTrailing,toolTipcontentViewTop,toolTipcontentViewBottom ]
        
        constraints.append(contentsOf:  allConstraints)
        
        
        return constraints
    }

    
}
