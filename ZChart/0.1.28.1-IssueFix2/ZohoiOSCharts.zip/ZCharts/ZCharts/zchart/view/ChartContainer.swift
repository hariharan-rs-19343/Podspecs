//
//  ChartContainer.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  Charts

class ChartContainer: UIView, ChartViewDelegateToContainer,UICollectionViewDataSource, LegendViewDelegate {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    //var _spinAnimator: Animator!

    var firstTime:Bool = true

    var currentOrientation:Orientation = .Undefined
    
    var installedConstraints:[NSLayoutConstraint] = []
    
    let titleView = TitleView()
    
    let toolTipView = ToolTipView()
    
    let legendView = LegendView()
    
    let chartView = ChartView()
    
    let lineView = LineView()
    
    var legendEntries:[LegendEntry]? = []
    
    var enableMainTitle:Bool {
        set {
            self.titleView.mainTitle.enable = newValue
            self.titleView.reloadTitles()
        }
        get{
            return self.titleView.mainTitle.enable
        }
        
    }
    
    var enableSubTitle:Bool {
        set {
            self.titleView.subTitle.enable = newValue
            self.titleView.reloadTitles()
        }
        get{
            return self.titleView.subTitle.enable
        }
        
    }
    
    weak var delegateToChartView:LegendViewDelegate? = nil
    
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        lineView.chartContainer = self
        print("Initial Bound ", self.bounds, self.frame)
        self.translatesAutoresizingMaskIntoConstraints = false
        addContentViews()
        
//        _spinAnimator = Animator()
//        _spinAnimator.delegate = self
        
        self.addObserver(self, forKeyPath: "bounds", options: .new, context: nil)
        self.addObserver(self, forKeyPath: "frame", options: .new, context: nil)
        
    }
    
    deinit
    {
        self.removeObserver(self, forKeyPath: "bounds")
        self.removeObserver(self, forKeyPath: "frame")
    }
    
    open override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?)
    {
        if keyPath == "bounds" || keyPath == "frame"
        {
            print("Observer for Key ", keyPath! , " called ", self.bounds, self.frame)
            self.setNeedsUpdateConstraints()
        }
    }
    
    convenience init() {
        self.init(frame: CGRect.zero)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initializeChart(type: ChartType) -> ChartViewBase
    {
        let chartObj = chartView.initializeChart(type: type)
        chartObj.delegateToContainer = self
        
        self.delegateToChartView = self.chartView.chart
        
        return chartObj
    }
    
    func addContentViews()
    {
        
        titleView.backgroundColor = UIColor.clear
        
        toolTipView.backgroundColor = UIColor.clear
        
        legendView.backgroundColor = UIColor.clear
        
        chartView.backgroundColor = UIColor.clear
        
        titleView.translatesAutoresizingMaskIntoConstraints = false
        toolTipView.translatesAutoresizingMaskIntoConstraints = false
        legendView.translatesAutoresizingMaskIntoConstraints = false
        chartView.translatesAutoresizingMaskIntoConstraints = false
        lineView.translatesAutoresizingMaskIntoConstraints = false
        
        self.addSubview(titleView)
        
        self.addSubview(legendView)
        
        self.addSubview(toolTipView)
        
        self.addSubview(chartView)
        
        self.addSubview(lineView)
    
        legendView.collectionView?.dataSource = self
        legendView.delegate = self
        
    }
    
    override func updateConstraints() {
        
        print("Bound ", self.bounds, self.frame)
        print("In Update Constraints: Device Orient", currentOrientation , " Leg Orient ", legendView.orientation)
        
        if self.installedConstraints.count > 0
        {
            NSLayoutConstraint.deactivate(self.installedConstraints)
        }
        
        
        if self.isPortraitOrientation() && (self.currentOrientation != .Portrait || self.currentOrientation == .Undefined){
          
            self.currentOrientation = .Portrait
            self.installedConstraints = getConstraints()
            
        }
        else if !self.isPortraitOrientation() && (self.currentOrientation == .Portrait || self.currentOrientation == .Undefined) {
            
            self.currentOrientation = .Landscape
            self.installedConstraints = getConstraints()
        }
        
        NSLayoutConstraint.activate(self.installedConstraints)
        
        super.updateConstraints()
    }
    
    
    func isPortraitOrientation() -> Bool
    {
        return UIDevice.current.orientation.isPortrait
    }
    
    func getConstraints() -> [NSLayoutConstraint] {
        
        print("Device Orient", currentOrientation , " Leg Orient ", legendView.orientation)
        
        
        var constraints:[NSLayoutConstraint] = ContainerLayout.constraintsForHorizontalLegendPortrait(containerView: self)
      
        // To set Portrait Orientation
        self.chartView.chart.isVertical = true
        
        
        if currentOrientation == .Portrait
        {
            if legendView.orientation == .Vertical
            {
                constraints = ContainerLayout.constraintsForVerticalLegendPortrait(containerView: self)
            }
        } else if currentOrientation == .Landscape
        {
            if legendView.orientation == .Vertical
            {
                constraints = ContainerLayout.constraintsForVerticalLegendLandscape(containerView: self)
            } else if legendView.orientation == .Horizontal
            {
                constraints = ContainerLayout.constraintsForHorizontalLegendLandscape(containerView: self)
                //To set Landscape Orientation
                self.chartView.chart.isVertical = false
            }
        }
        
        return constraints
    }
    
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        toolTipView.reloadData(entry: entry)
    }
    
    func legendReloaded(_ chartView: ChartViewBase, _ legendEntries: [LegendEntry]?) {
        if legendEntries != nil && (legendEntries?.count)! > 0
        {
            print("Legend Notification received")
            legendView.calculateMaxCellSize(entries: legendEntries!)
            legendView.collectionView?.reloadData()
        }
    }
    
    
    //------ DataSource for Legend ------------//
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("Section Count ", section, " ArrayCount ", self.chartView.chart.legend.entries.count )
        //return legendEntries!.count
        return self.chartView.chart.legend.entries.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let entries = self.chartView.chart.legend.entries
        
        let entry = entries[indexPath.item]

        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LegendCell", for: indexPath) as! LegendCell
       
        cell.legendOrientation = legendView.orientation
        cell.entry = entry
        cell.delegate = self.legendView
        
            if self.legendView.legendForm == .Square
            {
                cell.shapeLayer.path = UIBezierPath(rect: cell.shapeLayer.bounds).cgPath
            }
            else
            {
                cell.shapeLayer.path = UIBezierPath(ovalIn: cell.shapeLayer.bounds).cgPath
                
            }
        
            let text = entry.label
            cell.labelView.text = text
            cell.labelView.font = UIFont.systemFont(ofSize: 20)
            cell.labelView.alpha = 1.0
            cell.formView.alpha = 1.0
        
       
        
            cell.shapeLayer.fillColor = entry.formColor?.cgColor
            cell.labelView.textColor = UIColor.black

        
            if entry.enabled
            {
                cell.shapeLayer.fillColor = entry.formColor?.cgColor
                cell.labelView.textColor = UIColor.black
                //cell.alpha = 1.0
            }
            else
            {
                  cell.labelView.alpha = 0.1
                  cell.formView.alpha = 0.1
            }
        
            //To Add a Mask on Legend View//TMP// Have to call on when the collection view loaded the content size and init frame
            legendView.addMask()
        
        return cell
    }
    
    //------------------LegendViewDelegate---------------//
    
    func legendSelected(indexPath: IndexPath) {
        self.delegateToChartView?.legendSelected!(indexPath: indexPath)
    }
    
    func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
         self.delegateToChartView?.legendEnabled!(indexPath: indexPath, entry: entry)
    }
    
    func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
         self.delegateToChartView?.legendDisabled!(indexPath: indexPath, entry: entry)
    }
    
    //------------------LegendViewDelegate---------------//
    
    //------------------LegendViewDelegate---------------//
    
    
    func removeLine()
    {
        if !legendView.showView
        {
            if let sublayers = lineView.layer.sublayers {
                
                for child in sublayers
                {
                    child.removeFromSuperlayer()
                }
                
            }
        }
    }
    
    
    
   /* func legendSelected(indexPath: IndexPath)
    {

        let entries = self.chartView.chart.legend.entries
        let entry = entries[indexPath.item]
        
        if entry.enabled
        {
        
        
        let pieChart = self.chartView.chart as! PieChartView
        let rotAngle = pieChart.rotationAngle
        let drawAngle = pieChart.drawAngles[indexPath.item]
        let absAngle = pieChart.absoluteAngles[indexPath.item]
        
        
        
        let endAngle = rotAngle + absAngle
        
        
        let startAngle = (endAngle - drawAngle)
        
         var midAngle:CGFloat =  ((startAngle + endAngle) / 2.0)
        
    
        
        if midAngle > 360
        {
            midAngle = midAngle - 360
        }
        
        let pt = pieChart.getPosition(center: pieChart.centerCircleBox, dist: pieChart.radius/2, angle: midAngle)
        
        let high = pieChart.getHighlightByTouchPoint(pt)
      
        if high != nil {
           pieChart.pieType.taprotate(high: high!,location: pt,rotation: false,addangle:0)
        }

       
        
       
            
        }
        
    }
    
    open func animatorUpdated(_ chartAnimator: Animator)
    {
        let pieChart = self.chartView.chart as! PieChartView
        pieChart.updateDrawAngles()
        
    }
    
    open func animatorStopped(_ chartAnimator: Animator)
    {
        
    }
    
    
    func legendEnabled(indexPath: IndexPath, entry: LegendEntry) {
     print("Container::LegendEnabled ", indexPath.item, entry.label)
        
        let pieChart = self.chartView.chart as! PieChartView
        
        let dataSet = self.chartView.chart.data?.dataSets[0]
        let chartEntry = dataSet?.entryForIndex(indexPath.item)
        
        
        chartEntry?.enabled = true
        
        
        if _spinAnimator != nil
        {
            _spinAnimator.stop()
        }
        
        let originalVal:CGFloat = CGFloat((chartEntry?.oldValue)!)
        
        _spinAnimator = Animator()
        _spinAnimator.delegate = self
        
        _spinAnimator.updateBlock = {
            chartEntry?.y = Double((originalVal * CGFloat(self._spinAnimator.phaseX)) + CGFloat(0))
            pieChart.data?.setDrawValues(false)
            pieChart.highlightValue(nil, callDelegate: true)
            
        }
        _spinAnimator.stopBlock = {
            self._spinAnimator = nil
            pieChart.pieType.rotationStops()
        }
        
        _spinAnimator.animate(xAxisDuration: 1, easingOption: .linear)
  
        
    }
    
    func legendDisabled(indexPath: IndexPath, entry: LegendEntry) {
        
        print("Container::LegendDisabled ", indexPath.item, entry.label)
    
        let pieChart = self.chartView.chart as! PieChartView
        
        let dataSet = self.chartView.chart.data?.dataSets[0]
        let chartEntry = dataSet?.entryForIndex(indexPath.item)
        
        chartEntry?.enabled = false
        
        if _spinAnimator != nil
        {
            _spinAnimator.stop()
        }
        
        let originalVal:CGFloat = CGFloat((chartEntry?.y)!)
        
        
        _spinAnimator = Animator()
        _spinAnimator.delegate = self
        
        
        _spinAnimator.updateBlock = {
            chartEntry?.y = Double(originalVal - (originalVal * CGFloat(self._spinAnimator.phaseX)))
            pieChart.highlightValue(nil, callDelegate: true)
            pieChart.data?.setDrawValues(false)
            
        }
        
        _spinAnimator.stopBlock = {
            self._spinAnimator = nil
            pieChart.updateDrawAngles()
            pieChart.pieType.rotationStops()
          
        }
        
        _spinAnimator.animate(xAxisDuration: 1, easingOption: .linear)
        
        
    } */
    
    //------------------LegendViewDelegate---------------//
    
}


enum Orientation
{
    case Undefined
    case Portrait
    case Landscape
}

enum LegendOrientation
{
    case Horizontal
    case Vertical
}

