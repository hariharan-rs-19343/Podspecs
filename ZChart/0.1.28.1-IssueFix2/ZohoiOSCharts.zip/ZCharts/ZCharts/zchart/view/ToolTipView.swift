//
//  ToolTipView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  Charts

class ToolTipView: UIView, UIScrollViewDelegate {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    
    
    var showView:Bool = true
    
    var toolTipEntryGenerator:IToolTipEntryGenerator = DefaultToolTipEntryGenerator()
    
    private var type:ToolTipType = .leftRight //SET AS PRIVATE
    
    var toolTipType:ToolTipType
    {
        set
        {
            self.type = newValue
            resetAxis()
        }
        get
        {
            return self.type
        }
    }
    
    let scrollView = UIScrollView()
    
    var parentStackView = UIStackView()
    
    let maskLayer = CAGradientLayer()
    
    let contentView = UIView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.initialize()
    }
    
    func initialize()
    {
        scrollView.delegate = self
        
        self.addSubview(contentView)
        
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
      //  self.addSubview(scrollView)
        
        contentView.addSubview(scrollView)
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        
        scrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        
        //        scrollView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10).isActive = true
        //        scrollView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
        //        scrollView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        //        scrollView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        
        print("Scroll view bound ", scrollView.bounds)
        
        scrollView.addSubview(parentStackView)
        
        parentStackView.translatesAutoresizingMaskIntoConstraints = false
        
        parentStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        parentStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        parentStackView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        parentStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        
        parentStackView.spacing = 10.0
        
        resetAxis()
        
        
    }
    
//    func initialize()
//    {
//        scrollView.delegate = self
//        
//        self.addSubview(scrollView)
//        
//        scrollView.translatesAutoresizingMaskIntoConstraints = false
////        scrollView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
////        scrollView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
////        scrollView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
////        scrollView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
//        
////        scrollView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10).isActive = true
////        scrollView.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
////        scrollView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
////        scrollView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
//        
//        scrollView.addSubview(parentStackView)
//        
//        parentStackView.translatesAutoresizingMaskIntoConstraints = false
//        
//        parentStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
//        parentStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
//        parentStackView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
//        parentStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
//        
//        parentStackView.spacing = 10.0
//        
//        resetAxis()
//        
//    }
    
    func resetAxis()
    {
        if self.toolTipType == .Centered
        {
            print("Center Type ", self.toolTipType)
            
            parentStackView.axis = .horizontal
            parentStackView.distribution = .fillEqually
            parentStackView.alignment = .center
            
            // parentStackView.heightAnchor.constraint(equalTo: scrollView.heightAnchor).isActive = true
        }
        else if self.toolTipType == .leftRight
        {
            parentStackView.axis = .vertical
            parentStackView.distribution = .fillProportionally
            parentStackView.alignment = .fill
            
            // parentStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        }
        
    }
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func reloadData(entry: ChartDataEntry)
    {
        
        if parentStackView.arrangedSubviews.count > 0 {
            for view in parentStackView.arrangedSubviews {//NEED TO CHECK
                //parentStackView.removeArrangedSubview(view)
                view.removeFromSuperview()
            }
        }
        
        var contentWidth:CGFloat = 0.0
        var contentHeight:CGFloat = 0.0
        
        let entries = toolTipEntryGenerator.prepareToolTipEntries(entry: entry)
        
        let count = entries.count
        
        for entry in entries {
            
            let tooltipCell = ToolTipCell(toolTipEntry: entry, toolTipType: toolTipType)
            
            let size = tooltipCell.getLabelSize()
            
            if size.height > contentHeight {
                contentHeight = size.height
            }
            
            if size.width > contentWidth {
                contentWidth = size.width
            }
            
            parentStackView.addArrangedSubview(tooltipCell)
        }
        
        if self.toolTipType == .Centered
        {
            contentWidth = contentWidth * CGFloat(count)
            contentWidth  = contentWidth + ( parentStackView.spacing * CGFloat(count))
            
            parentStackView.heightAnchor.constraint(equalTo: scrollView.heightAnchor).isActive = true
            
            maskLayer.startPoint = CGPoint(x: 0, y: 0.5)
            maskLayer.endPoint = CGPoint(x:1.0, y:0.5)
            
        }
        else if self.toolTipType == .leftRight
        {
            contentHeight = contentHeight * CGFloat(count)
            contentHeight  = contentHeight + ( parentStackView.spacing * CGFloat(count))
            
            parentStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
            
            maskLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
            maskLayer.endPoint = CGPoint(x:0.5, y:1.0)
        }
        
        scrollView.contentSize = CGSize(width: contentWidth, height: contentHeight)
        
        centerTooltip()
        

    }
    
    func centerTooltip()
    {
        if ((floor(scrollView.contentSize.height) <=  floor(scrollView.bounds.height)) && (self.toolTipType == .leftRight) || (floor(scrollView.contentSize.width) <= floor(scrollView.bounds.width)) && (self.toolTipType == .Centered))
        {
            if self.toolTipType == .Centered
            {
                parentStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
            }
            else if self.toolTipType == .leftRight
            {
                parentStackView.heightAnchor.constraint(equalTo: scrollView.heightAnchor).isActive = true
            }
        }

    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.stoppedScrolling(scrollView: scrollView)
    }
    
    
    func stoppedScrolling(scrollView: UIScrollView)
    {
       
        let transparent = UIColor.clear.cgColor
        let opaque = UIColor.black.cgColor
        var startPoint:CGFloat = scrollView.contentOffset.x
        var currentOffsetValue:CGFloat = scrollView.bounds.size.width
        var totalValue:CGFloat = scrollView.contentSize.width
        
        if self.toolTipType == .leftRight
        {
            startPoint = scrollView.contentOffset.y
            currentOffsetValue = scrollView.bounds.size.height
            totalValue = scrollView.contentSize.height
        }
        
         print("Stopped Scrolling ", scrollView.contentSize, " offset ", scrollView.contentOffset, " Bound ", scrollView.bounds, " frame ",scrollView.frame  )
        
        print("Start Point ", startPoint, " Content Width ", currentOffsetValue , " Total Width ", totalValue, " Addition ", startPoint + currentOffsetValue )
    
        
        if startPoint + currentOffsetValue == currentOffsetValue
        {
            print("Start Slize")
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
            
        }
        else if startPoint + currentOffsetValue == totalValue
        {
            print("End Slize")
            maskLayer.colors = [transparent, opaque, opaque]
            maskLayer.locations = [0,0.2,1]
        
        }
        else
        {
            print(" Mid Slize ")
            maskLayer.colors = [transparent, opaque, opaque,transparent]
            maskLayer.locations = [0,0.2,0.8,1]
           
        }
    }
    
    func addMask()
    {
        
        print("Tooltip View :: Content View ", contentView.bounds, contentView.frame, "Scroll View Bound " , scrollView.bounds, scrollView.frame , " Self Bound ", self.bounds, "Scroll Content ", scrollView.contentSize, "Scroll Offset ", scrollView.contentOffset)
        
        if floor(scrollView.contentSize.width) > floor(scrollView.bounds.size.width) && self.toolTipType == .Centered || floor(scrollView.contentSize.height) > floor(scrollView.bounds.size.height) && self.toolTipType == .leftRight
        {
            
            let transparent = UIColor.clear.cgColor
            let opaque = UIColor.black.cgColor
            
            let parentLayer = CALayer()
            parentLayer.frame = self.bounds
            
            
            maskLayer.bounds = CGRect(x: scrollView.bounds.origin.x, y: 0, width: scrollView.bounds.size.width, height: scrollView.bounds.size.height)
            maskLayer.position = scrollView.layer.position
            
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.8,1]
            parentLayer.addSublayer(maskLayer)
            contentView.layer.mask = parentLayer
        }
        else{
           contentView.layer.mask = nil
        }

    }
    
    
    override func layoutSubviews() {
        centerTooltip()
        addMask()
        
        
    }
    

}

enum ToolTipType
{
    case Centered
    case leftRight
}
