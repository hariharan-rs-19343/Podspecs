//
//  LegendView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import Charts

/*@objc
 protocol LegendViewDelegate
 {
 @objc optional func legendSelected(indexPath: IndexPath)
 
 @objc optional func legendDisabled(indexPath: IndexPath, entry: LegendEntry)
 
 @objc optional func legendEnabled(indexPath: IndexPath, entry: LegendEntry)
 
 } */

class LegendView: UIView,UICollectionViewDelegateFlowLayout, LegendCellDelegate, UIGestureRecognizerDelegate {
    
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
    
    open weak var delegate: LegendViewDelegate?
    
    let maskLayer = CAGradientLayer()
    
    var legendEntries:[LegendEntry]? = nil
    
    var orientation:LegendOrientation
    {
        set
        {
            self._orientation = newValue
            resetOrientation()
        }
        get
        {
            return _orientation
        }
    }
    
    
    var showView:Bool = true
    
    fileprivate var sectionInsets = UIEdgeInsets(top: 10.0, left: 20.0, bottom: 10.0, right: 20.0)
    
    var collectionView:UICollectionView? = nil
    
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    
    var _orientation:LegendOrientation = .Horizontal
    
    var legendForm:LegendForm = .Circle
    
    var maxCellSize:CGSize = CGSize.zero
    
    var panUpGestureRecognizer: UIPanGestureRecognizer!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.initialize()
    }
    
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func resetOrientation()
    {
        
        if self.orientation == .Horizontal
        {
            
            maskLayer.startPoint = CGPoint(x: 0, y: 0.5)
            maskLayer.endPoint = CGPoint(x:1, y:0.5)
            
            let layout =  self.collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
            layout.scrollDirection = .horizontal
            
            
            sectionInsets = UIEdgeInsets(top: 5.0, left: 20.0, bottom: 5.0, right: 20.0)
            
            print("Horizontal Orientation ")
            
        }
        else
        {
            
            maskLayer.startPoint = CGPoint(x: 0.5, y: 0)
            maskLayer.endPoint = CGPoint(x:0.5, y:1)
            
            let layout =  self.collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
            layout.scrollDirection = .vertical
            
            sectionInsets = UIEdgeInsets(top: 20.0, left: 20.0, bottom: 20.0, right: 20.0)
            
            print("Vertical Orientation ")
            
        }
        
    }
    
    func isPortraitOrientation() -> Bool
    {
        return UIDevice.current.orientation.isPortrait
    }
    
    func initialize()
    {
        
        
        collectionView  = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        
        self.addSubview(collectionView!)
        
        collectionView?.translatesAutoresizingMaskIntoConstraints = false
        
        resetOrientation()
        
        collectionView?.backgroundColor = UIColor.clear
        
        collectionView?.delegate = self
        
        collectionView?.register(LegendCell.self, forCellWithReuseIdentifier: "LegendCell")
        
        panUpGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
        panUpGestureRecognizer?.delegate = self
        collectionView?.addGestureRecognizer(panUpGestureRecognizer)
        
    }
    
    
    // --------------UICollectionViewDelegateFlowLayout------------------------- //
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let height = collectionView.frame.size.height - sectionInsets.top - sectionInsets.bottom
        
        let newSize = CGSize(width: maxCellSize.width, height: height)
        
        let entry = legendEntries?[indexPath.item]
        let text = entry?.label
        let size: CGSize = (text)!.size(attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 20)])
        
        let newWidth = size.width + height
    
        
        //print("Item size for index ", indexPath.item, " Max Cell size ", maxCellSize, " New Size ", newSize , "New Width ", newWidth, " Height ", height)
        
        if self.orientation == .Horizontal
        {
            //return newSize
            return CGSize(width: newWidth, height: height)
        }
        else{
            return maxCellSize
            //return CGSize(width: newWidth, height: size.height)
        }
    }
    
    //3
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    
    // 4
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = indexPath.item
        let animated = true
        self.collectionView?.selectItem(
            at: IndexPath(item: item, section: 0),
            animated: animated,
            scrollPosition: UICollectionViewScrollPosition())
        self.scrollToItem(item, animated: animated)
        
        if delegate != nil
        {
            delegate?.legendSelected!(indexPath: indexPath)
        }
        
        
        /*self.selectedItem = item
         if notifySelection {
         self.delegate?.pickerView?(self, didSelectItem: item)
         } */
    }
    
    public func scrollToItem(_ item: Int, animated: Bool = false) {
        
        var position:UICollectionViewScrollPosition = .centeredHorizontally
        
        if self.orientation == .Vertical {
            position = .centeredVertically
        }
        
        self.collectionView?.scrollToItem(
            at: IndexPath(
                item: item,
                section: 0),
            at: position,
            animated: animated)
        
    }
    // --------------UICollectionViewDelegateFlowLayout------------------------- //
    
    
    // ---------------------LegendCellDelegate------------------------- //
    
    func legendEnabled(entry: LegendEntry, indexPath: IndexPath)
    {
        if delegate != nil
        {
            delegate?.legendEnabled!(indexPath: indexPath, entry: entry)
        }
        
    }
    
    func legendDisabled(entry: LegendEntry, indexPath: IndexPath)
    {
        if delegate != nil
        {
            delegate?.legendDisabled!(indexPath: indexPath, entry: entry)
        }
        
    }
    
    
    func indexPathForCell(cell: UICollectionViewCell) -> IndexPath {
        return (self.collectionView?.indexPath(for: cell))!
    }
    // ---------------------LegendCellDelegate------------------------- //
    
    
    func calculateMaxCellSize(entries: [LegendEntry])
    {
        var maxWidth:CGFloat = 0.0
        var maxHeight:CGFloat = 0.0
        
        self.legendEntries = entries
        
        for entry in entries
        {
            let text = entry.label
            
            let size: CGSize = (text)!.size(attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 20)])
            
          //   print(" Text ", text , "size ", size  )
            
            if size.width > maxWidth
            {
                maxWidth = size.width
            }
            
            if size.height > maxHeight
            {
                maxHeight = size.height
            }
            
        }
        
       // print(" Max Width  ", maxWidth , " Height  ", maxHeight  )
        
        maxWidth = maxWidth + maxHeight + maxHeight // To include legend form
        
        maxCellSize = CGSize(width: maxWidth, height: maxHeight)
        
         print("Max Cell Size Calculated ", maxCellSize)
        
    }
    
    
    
    //----------------------- Pan Recognizer ----------------------------//
    
    var _last_cell:LegendCell? = nil
    var _last_cell_frame:CGRect? = nil
    
    
    internal func handlePan(_ gesture: UIGestureRecognizer)
    {
        
        if (!gesture.isKind(of: UIPanGestureRecognizer.self)) {
            return
        }
        
        let panRecognizer = gesture as! UIPanGestureRecognizer
        
        
        let location = panRecognizer.location(in: self.collectionView)
        //let swipeLocation = gesture.location(in: self.collectionView)
        let indexPath = self.collectionView?.indexPathForItem(at: location)
        
        let velocity = panRecognizer.velocity(in: self)
        
        //let location = panRecognizer.location(in: self.collectionView)
        
        if (gesture.state == .began)
        {
            // Start of the gesture.
            // You could remove any layout constraints that interfere
            // with changing of the position of the content view.
        }
            
        else if (gesture.state == .changed)
        {
            
            if !(indexPath != nil)
            {
                return
            }
            
            let swipedCell = self.collectionView?.cellForItem(at: indexPath!) as! LegendCell
            
            
            
            if _last_cell_frame == nil
            {
                _last_cell=swipedCell
                _last_cell_frame = swipedCell.frame
            }
           
            if _last_cell != nil && _last_cell != swipedCell
            {
                 print("MISMATCH :: Last Cell  ", _last_cell?.labelView.text , " Swiped Cell ", swipedCell.labelView.text, " ")
                return
            }
            
            swipedCell.contentView.clipsToBounds = false
            
            var frame = swipedCell.frame;
            
          //  print("Content view frame ", frame, "Location ", location , " Velocity ", velocity, swipedCell)
            
            if velocity.y < 0 && self.orientation == .Horizontal
            {
                frame.origin.y = location.y - (_last_cell_frame?.size.height)!;
            }
            else if velocity.y > 0 && self.orientation == .Horizontal
            {
                frame.origin.y = location.y + (_last_cell_frame?.size.height)! / 2 ;
            }
            else if velocity.x < 0 && self.orientation == .Vertical
            {
                frame.origin.x = location.x - (_last_cell_frame?.size.width)!;
            }
            else if velocity.x > 0 && self.orientation == .Vertical
            {
                frame.origin.x = location.x + (_last_cell_frame?.size.width)! / 2 ;
            }
            
            swipedCell.frame = frame;
//            let denom = swipedCell.contentView.bounds.size.height + fabs(location.y);
//            let percent = swipedCell.contentView.bounds.size.height / denom;
//            swipedCell.alpha = percent;
            
        }
            
        else if (gesture.state == .ended)
        {
            
            if _last_cell == nil
            {
                return
            }
            
            if self._last_cell_frame == nil{
                return
            }
            
            /*
             Naïve solution: If the bottom edge of the swipeableRect needs to cross
             the top of the bounding contentView and also needs to be
             fast enough for the swipe to work.
             */
            UIView.animate(withDuration: 0.5,
                           delay: 0,
                           usingSpringWithDamping: 0.33,
                           initialSpringVelocity: 0.0,
                           //options: UIViewAnimationOptions(),
                options: .curveLinear,
                animations: { [weak self]() -> Void in
                    
                    self?._last_cell?.frame = (self?._last_cell_frame!)!
                    
                    if self?.orientation == .Horizontal
                    {
                        if location.y > (self?._last_cell_frame?.origin.y)!
                        {
                            self?.enableCell(cell: (self?._last_cell)!)
                        }
                        else {
                            self?.disableCell(cell: (self?._last_cell)!)
                        }
                    }
                    else
                    {
                      
                        if location.x > (self?._last_cell_frame?.origin.x)!
                        {
                            self?.disableCell(cell: (self?._last_cell)!)
                        }
                        else {
                            self?.enableCell(cell: (self?._last_cell)!)
                        }
                        
                    }
                    
                    
                    
                }, completion: nil)
            
            _last_cell = nil
            _last_cell_frame = nil
            
        }
        
    }
    
    func enableCell(cell : LegendCell)
    {
        cell.enableCell()
    }
    
    func disableCell(cell : LegendCell)
    {
        cell.disableCell()
    }
    
    
    override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        
        if (!gestureRecognizer.isKind(of: UIPanGestureRecognizer.self)) {
            return false
        }
        let panRecognizer = gestureRecognizer as! UIPanGestureRecognizer
        
        let translation = panRecognizer.translation(in: self.collectionView)
        
        
        
        if self.orientation == .Horizontal
        {
            if abs(translation.x) > 0
            {
                return false
            }
            
            return abs(translation.x) < abs(translation.y)
        }
        else
        {
           
         //   print("Translation in vertical Y Value ", abs(translation.y), " X Value ", abs(translation.x))
            
            if abs(translation.y) > 0
            {
                return false
            }
            
            return abs(translation.y) < abs(translation.x)
        }
        
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.stoppedScrolling(scrollView: scrollView)
    }
    
    
    func stoppedScrolling(scrollView: UIScrollView)
    {
        
        let transparent = UIColor.clear.cgColor
        let opaque = UIColor.black.cgColor
        var startPoint:CGFloat = scrollView.contentOffset.x
        var currentOffsetValue:CGFloat = scrollView.bounds.size.width
        var totalValue:CGFloat = scrollView.contentSize.width
        
        if self.orientation == .Vertical
        {
            startPoint = scrollView.contentOffset.y
            currentOffsetValue = scrollView.bounds.size.height
            totalValue = scrollView.contentSize.height
        }
        
        print("Stopped Scrolling ", scrollView.contentSize, " offset ", scrollView.contentOffset, " Bound ", scrollView.bounds, " frame ",scrollView.frame  )
        
        print("Start Point ", startPoint, " Content Width ", currentOffsetValue , " Total Width ", totalValue, " Addition ", startPoint + currentOffsetValue )
        
        
        if startPoint + currentOffsetValue == currentOffsetValue
        {
            print("Start Slize")
            maskLayer.colors = [opaque, opaque, transparent]
            maskLayer.locations = [0,0.7,1]
            
        }
        else if startPoint + currentOffsetValue == totalValue
        {
            print("End Slize")
            maskLayer.colors = [transparent, opaque, opaque]
            maskLayer.locations = [0,0.2,1]
            
        }
        else
        {
            print(" Mid Slize ")
            maskLayer.colors = [transparent, opaque, opaque,transparent]
            maskLayer.locations = [0,0.2,0.8,1]
            
        }
    }
    
    func addMask()
    {
        if ((collectionView?.contentSize.width)! > self.bounds.size.width && self.orientation == .Horizontal) || ((collectionView?.contentSize.height)! > self.bounds.size.height && self.orientation == .Vertical)
        {
        let transparent = UIColor.clear.cgColor
        let opaque = UIColor.black.cgColor
        
        let parentLayer = CALayer()
        parentLayer.frame = self.bounds
        
        maskLayer.frame = CGRect(x: self.bounds.origin.x, y: 0, width: self.bounds.size.width, height: self.bounds.size.height)

        maskLayer.colors = [opaque, opaque, transparent]
        maskLayer.locations = [0,0.8,1]
        parentLayer.addSublayer(maskLayer)
        self.layer.mask = parentLayer
        }
        else
        {
            self.layer.mask = nil
        }
    }
    
    
    override func layoutSubviews() {
     
            addMask()
        
    
    }
    
    //----------------------- Pan Recognizer ----------------------------//
}

enum LegendForm
{
    case Circle
    case Square
}
