//
//  LabelView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

class LabelView: UILabel {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.enable = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        super.init(frame: CGRect.zero)
        self.enable = true
    }
    
    var hideEnabled:Bool = false
    
    var enable:Bool {
        set {
            self.hideEnabled = !newValue
        }
        get {
            return  !self.hideEnabled
        }
    }
    
    

}
