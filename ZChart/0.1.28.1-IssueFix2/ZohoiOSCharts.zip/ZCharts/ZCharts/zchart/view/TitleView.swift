//
//  TitleView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

class TitleView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    var lineDesign:LineView = LineView()
    
    var showView:Bool = true
    
    var mainTitle:LabelView = LabelView()
    
    var subTitle:LabelView = LabelView()
    
  
    
    var oldConstraints:[NSLayoutConstraint] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        lineDesign.titleView = self
        self.addTitles()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func addTitles()
    {
        
        mainTitle.font = UIFont.systemFont(ofSize: 20)
        mainTitle.text = "Zoho Native Chart"
        mainTitle.textAlignment = .center
        
        subTitle.font = UIFont.systemFont(ofSize: 10)
        subTitle.text = "Welcome to Zoho Native Chart"
        subTitle.textAlignment = .center
        
        
        
        mainTitle.translatesAutoresizingMaskIntoConstraints = false
        subTitle.translatesAutoresizingMaskIntoConstraints = false
        lineDesign.translatesAutoresizingMaskIntoConstraints = false
        
        
        self.addSubview(mainTitle)
        self.addSubview(subTitle)
        self.addSubview(lineDesign)
        
        reloadTitles()
    }
    
    func removeLine()
    {
        if !showView
        {
        if let sublayers = lineDesign.layer.sublayers {
            
            for child in sublayers
            {
                child.removeFromSuperlayer()
            }
            
        }
        }
    }
    
    func reloadTitles()
    {
        ContainerLayout.activateConstraintsForTitleView(titleView: self)
    }
    
}
