//
//  ChartView.swift
//  ZCharts
//
//  Created by Aravinth T on 03/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  Charts

class ChartView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    var showView:Bool
    {
        get
        {
            return true
        }
    }

    fileprivate var _chart:ChartViewBase? = nil
    
    var chart:ChartViewBase
    {
        get
        {
            return _chart!
        }
    }
    
   func initializeChart(type: ChartType) -> ChartViewBase
    {
        _chart = getChartFromType(type)
        self.addSubview(_chart!)
        
        _chart?.translatesAutoresizingMaskIntoConstraints = false
        
        let centerX = _chart?.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        let centerY = _chart?.centerYAnchor.constraint(equalTo: self.centerYAnchor)
        let width = _chart?.widthAnchor.constraint(equalTo: self.widthAnchor)
        let height = _chart?.heightAnchor.constraint(equalTo: self.heightAnchor)
        
        let oldConstraints:[NSLayoutConstraint] = [centerX!, centerY!, width!, height!]
        NSLayoutConstraint.activate(oldConstraints)
        
        return _chart!
    }
    
    internal func getChartFromType(_ type: ChartType) -> ChartViewBase
    {
        switch type
        {
        case .Pie:
            return PieChartView()
        case .Bar:
            return BarChartView()
        }
    }
    
}

enum ChartType
{
    case Pie
    case Bar
}

