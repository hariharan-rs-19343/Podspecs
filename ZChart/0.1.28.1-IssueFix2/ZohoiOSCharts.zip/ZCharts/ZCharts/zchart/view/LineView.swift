//
//  LineView.swift
//  ZCharts
//
//  Created by Mohammed Musthafa A K on 17/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  Charts


class LineView: UIView
{
    weak var titleView:TitleView?
    weak var chartContainer:ChartContainer?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(frame: CGRect.zero)
        // self.addLine(frame: CGRect.zero)
    }
    
    
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
  
    func addLine(frame:CGRect)
    {
   
        if let sublayers = self.layer.sublayers {
            
            for child in sublayers
            {
                child.removeFromSuperlayer()
            }
            
        }
        
        
        self.frame = frame
        //print("frame",self.frame,"bounds",self.bounds.width,self.bounds.height)
        
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: (5/100)*self.bounds.width, y: self.bounds.height/2))
        path.addLine(to: CGPoint(x: self.bounds.width - ((5/100)*self.bounds.width), y: self.bounds.height/2))
        
        //design path
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.gray.withAlphaComponent(0.3).cgColor
        shapeLayer.lineWidth = 1.0
        
        self.layer.addSublayer(shapeLayer)
        
    }
    
    
    override func layoutSubviews() {
       // print("frame",self.frame,"bounds",self.bounds.width,self.bounds.height)
        addLine(frame: self.frame)
        
        titleView?.removeLine()
        chartContainer?.removeLine()
    
        
    }
    
    
    
}
