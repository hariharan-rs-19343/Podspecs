//
//  ToolTipEntry.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

class ToolTipEntry: NSObject {

    internal var _label:String!
    
    internal var _value:String!
    
    
    var label:String {
        set
        {
            _label = newValue
        }
        get
        {
            return _label
        }
    }
    
    var value:String {
        set
        {
            _value = newValue
        }
        get
        {
            return toolTipValueFormatter.stringForValue(value: self._value)
        }
        
    }
    
    init(label: String, value: String) {
        super.init()
        self.label = label
        self.value = value
    }
    
    var valueTextColor:UIColor = UIColor.blue
    
    var valueFont:UIFont = UIFont.systemFont(ofSize: 20)
    
    var labelTextColor:UIColor = UIColor.black
    
    var labelFont:UIFont = UIFont.boldSystemFont(ofSize: 20)
    
    var toolTipValueFormatter:IToolTipValueFormatter = DefaultToolTipValueFormatter()
    
    
}
