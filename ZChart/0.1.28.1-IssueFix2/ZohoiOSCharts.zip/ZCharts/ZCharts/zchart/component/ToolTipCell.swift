//
//  ToolTipCell.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

class ToolTipCell: UIStackView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    let label = UILabel()
    
    let value = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    /*init() {
     super.init(frame: CGRect.zero)
     self.axis = .vertical
     self.distribution = .fillEqually
     self.alignment = .fill
     self.addViews()
     } */
    
    
    init(toolTipEntry: ToolTipEntry,  toolTipType: ToolTipType) {
        super.init(frame: CGRect.zero)
        
        if toolTipType == .Centered
        {
            self.axis = .vertical
            self.distribution = .fillEqually
            self.alignment = .fill
            
            label.textAlignment = .center
            value.textAlignment = .center
        }
        else if toolTipType == .leftRight {
            
            self.axis = .horizontal
            self.distribution = .fillEqually
            self.alignment = .fill
            
            label.textAlignment = .left
            value.textAlignment = .right
        }
        
        self.addViews(toolTipEntry : toolTipEntry)
    }
    
    /*init() {
     super.init(frame: CGRect.zero)
     self.axis = .horizontal
     self.distribution = .fillEqually
     self.alignment = .fill
     self.addViews()
     }*/
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addViews(toolTipEntry: ToolTipEntry) {
        
        label.text = toolTipEntry.label
        label.textColor = toolTipEntry.labelTextColor
        label.font = toolTipEntry.labelFont
        
        value.text = toolTipEntry.value
        value.textColor = toolTipEntry.valueTextColor
        value.font = toolTipEntry.valueFont
        
        
        self.addArrangedSubview(label)
        self.addArrangedSubview(value)
    }
    
    func getLabelSize() -> CGSize {
        
        let size1 = (label.text! as NSString).size(attributes: [NSFontAttributeName: label.font])
        let size2 = (value.text! as NSString).size(attributes: [NSFontAttributeName: value.font])
        
        var width:CGFloat = size1.width
        if size2.width > width {
            width = size2.width
        }
        
        var height:CGFloat = size1.height * 2
        if size2.height > size1.height {
            height = size2.height * 2
        }
        return CGSize(width: width, height: height)
        
    }

}
