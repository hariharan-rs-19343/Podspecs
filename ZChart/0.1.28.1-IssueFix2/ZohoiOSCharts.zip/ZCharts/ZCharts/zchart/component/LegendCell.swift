//
//  LegendCell.swift
//  ZCharts
//
//  Created by Aravinth T on 11/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import Charts

@objc
protocol LegendCellDelegate
{
    @objc optional func legendEnabled(entry: LegendEntry, indexPath: IndexPath)
    
    @objc optional func legendDisabled(entry: LegendEntry, indexPath: IndexPath)
    
    @objc optional func indexPathForCell(cell: UICollectionViewCell) -> IndexPath
    
}

class LegendCell: UICollectionViewCell {
    
    var formView:UIView!
    
    var labelView:UILabel!
    
    var shapeLayer:CAShapeLayer!
    
    var oldListeners:[UIGestureRecognizer] = []
    
    var legendOrientation:LegendOrientation = .Horizontal
    /* {
     didSet
     {
     addGestureListener()
     }
     } */
    
    weak var entry:LegendEntry? = nil
    
    weak var delegate:LegendCellDelegate? = nil
    
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        
        //formView = UIView(frame: CGRect(x: 0, y: 0, width: frame.width * 0.2, height: frame.height))
        formView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.height/2 , height: self.frame.height))
        
        let radius = min(formView.bounds.width, formView.bounds.height) * (1/2)
        
        shapeLayer = CAShapeLayer()
        shapeLayer.bounds = CGRect(x: 0, y: 0, width: radius, height: radius)
        
        shapeLayer.position = formView.layer.position
        
        formView.layer.addSublayer(shapeLayer)
        
        //labelView = UILabel(frame: CGRect(x: frame.width * 0.3, y: 0, width: frame.width * 0.7 , height: frame.height))
        labelView = UILabel(frame: CGRect(x: self.frame.height * (2/3) , y: 0, width: self.frame.width - self.frame.height * (2/3)  , height: self.frame.height))
        
        labelView.font = UIFont.systemFont(ofSize: 20)
        labelView.textAlignment = .left
        
      //  print("Init Legend Cell Frame ", frame , " Form view ", formView.frame, " Label ", labelView.frame)
        
        self.contentView.addSubview(formView)
        self.contentView.addSubview(labelView)
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func legendInit()
    {
        
        //formView.frame = CGRect(x: 0, y: 0, width: self.frame.width * 0.2, height: self.frame.height)
        formView.frame = CGRect(x: 0, y: 0, width: self.frame.height/2 , height: self.frame.height)
        
        let radius = min(formView.bounds.width, formView.bounds.height) * (1/2)
        
        shapeLayer.bounds = CGRect(x: 0, y: 0, width: radius, height: radius)
        
        shapeLayer.position = formView.layer.position
        
        //labelView.frame = CGRect(x: self.frame.width * 0.3, y: 0, width: self.frame.width * 0.7 , height: self.frame.height)
        labelView.frame = CGRect(x: self.frame.height * (2/3) , y: 0, width: self.frame.width - self.frame.height * (2/3)  , height: self.frame.height)
    }
    
    /*  func addGestureListener()
     {
     /*for listener in self.oldListeners
     {
     self.removeGestureRecognizer(listener)
     }*/
     
     if self.oldListeners.count > 0
     {
     return
     }
     
     if self.legendOrientation == .Horizontal
     {
     let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeUp.direction = .up
     self.addGestureRecognizer(swipeUp)
     
     let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeDown.direction = .down
     self.addGestureRecognizer(swipeDown)
     
     oldListeners = [swipeUp, swipeDown]
     }
     else
     {
     let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeLeft.direction = .left
     self.addGestureRecognizer(swipeLeft)
     
     let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
     swipeRight.direction = .right
     self.addGestureRecognizer(swipeRight)
     
     oldListeners = [swipeLeft, swipeRight]
     
     }
     
     }
     
     func handleGesture(gesture: UISwipeGestureRecognizer)
     {
     if gesture.direction == UISwipeGestureRecognizerDirection.right {
     print("Swipe Right")
     disableCell()
     }
     else if gesture.direction == UISwipeGestureRecognizerDirection.left {
     print("Swipe Left")
     enableCell()
     }
     else if gesture.direction == UISwipeGestureRecognizerDirection.up {
     print("Swipe Up")
     disableCell()
     }
     else if gesture.direction == UISwipeGestureRecognizerDirection.down {
     print("Swipe Down")
     enableCell()
     }
     }
     */
    
    func disableCell()
    {
        
        if self.entry == nil {
            // print(" Entry nil for ", labelView.text)
            return
        }
        
        if !(self.entry?.enabled)!
        {
            return
        }
        
       // self.alpha = 0.1
        
        self.labelView.alpha = 0.1
        self.formView.alpha = 0.1
        
        self.entry?.enabled = false
        
        self.delegate?.legendDisabled!(entry: entry!, indexPath: (self.delegate?.indexPathForCell!(cell: self))!)
        
        /* UIView.animate(withDuration: 1, delay: 0.5, options: UIViewAnimationOptions.transitionCurlUp, animations: {
         self.alpha = 0.5
         self.shapeLayer.fillColor = UIColor.lightGray.cgColor
         self.labelView.textColor = UIColor.lightGray
         }, completion: nil) */
        
    }
    
    func enableCell()
    {
        if (self.entry?.enabled)!
        {
            return
        }
        
       // self.alpha = 1.0
        
        self.entry?.enabled = true
        
        self.labelView.alpha = 1.0
        self.formView.alpha = 1.0
        
        self.shapeLayer.fillColor = self.entry?.formColor?.cgColor
        self.labelView.textColor = UIColor.black
        
        /* print(entry?.label)
         UIView.animate(withDuration: 2, delay: 0.5, options: UIViewAnimationOptions.curveEaseOut, animations: {
         self.alpha = 1.0
         self.shapeLayer.fillColor = (self.entry?.formColor?.cgColor)!
         self.labelView.textColor = UIColor.black
         }, completion: nil) */
        
        self.delegate?.legendEnabled!(entry: entry!, indexPath: (self.delegate?.indexPathForCell!(cell: self))!)
        
    }
    
    override func layoutSubviews() {
        print(self.frame)
        legendInit()

    }
    
    
}
