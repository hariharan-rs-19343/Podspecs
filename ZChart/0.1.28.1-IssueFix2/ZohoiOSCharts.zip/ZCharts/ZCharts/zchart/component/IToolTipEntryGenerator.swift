//
//  IToolTipEntryGenerator.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import Charts

protocol  IToolTipEntryGenerator : NSObjectProtocol {
    
    func prepareToolTipEntries(entry: ChartDataEntry) -> [ToolTipEntry]
    
}

