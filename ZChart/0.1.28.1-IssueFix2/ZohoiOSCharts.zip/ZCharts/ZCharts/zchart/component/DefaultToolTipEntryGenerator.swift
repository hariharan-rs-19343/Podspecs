//
//  DefaultToolTipEntryGenerator.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit
import  Charts

class DefaultToolTipEntryGenerator : NSObject, IToolTipEntryGenerator
{
    func prepareToolTipEntries(entry: ChartDataEntry) -> [ToolTipEntry] {
        
        
        let pieEntry = entry as! PieChartDataEntry
        
        var entries:[ToolTipEntry] = []
        
        let toolTipEntry = ToolTipEntry(label: pieEntry.label!, value: String(pieEntry.y))
        toolTipEntry.valueTextColor = entry.entryColor
        
        
        entries.append(toolTipEntry)
        entries.append(toolTipEntry)
        entries.append(toolTipEntry)
        entries.append(toolTipEntry)
        entries.append(toolTipEntry)
        entries.append(toolTipEntry)
        
        
        return entries
    }
}

