//
//  DefaultToolTipValueFormatter.swift
//  ZCharts
//
//  Created by Aravinth T on 04/07/17.
//  Copyright © 2017 charts. All rights reserved.
//

import UIKit

class DefaultToolTipValueFormatter : NSObject, IToolTipValueFormatter
{
    func stringForValue(value: String) -> String {
        return value
    }
}
