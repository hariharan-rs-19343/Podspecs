#
#  Be sure to run `pod spec lint ZCharts.podspec' to ensure this is a
#  valid spec and to remove all comments including this before submitting the spec.
#
#  To learn more about Podspec attributes see http://docs.cocoapods.org/specification.html
#  To see working Podspecs in the CocoaPods repo see https://github.com/CocoaPods/Specs/
#

Pod::Spec.new do |s|

  # ―――  Spec Metadata  ―――――――――――――――――――――――――――――――――――――――――――――――――――――――――― #
  #
  #  These will help people to find your library, and whilst it
  #  can feel like a chore to fill in it's definitely to your advantage. The
  #  summary should be tweet-length, and the description more in depth.
  #

  s.name         = "ZCharts"
  s.version      = "0.0.1"
  s.summary          = "Zoho Charts SDK"
  s.license          = { :type => "MIT", :text=> <<-LICENSE
  MIT License

  Copyright (c) 2018 Zoho Corporation

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all 
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE 
  SOFTWARE
  LICENSE
}



  s.homepage     = "https://git.csez.zohocorpin.com/opensource/zohoioscharts"
  s.author       = { "Aravinth T" => "aravinth.t@zohocorp.com" }
  

   s.source = { :git => '' }
   #s.source = { :http => 'http://build/zoho_ios/zohoioscharts/milestones/master/ZOHOIOSCHARTS_V0.0.1.7_FIX2/ZohoiOSCharts.zip' }
  #s.source = { :http => 'http://build/zoho_ios/zohoioscharts/milestones/master/ZOHOIOSCHARTS_V0.0.1.6_FIX_3/ZohoiOSCharts.zip' }
  #s.source = { :http => 'http://build/zoho_ios/zohoioscharts/milestones/master/ZOHOIOSCHARTS_V0.0.1.5_FIX_11/ZohoiOSCharts.zip' }
  
  #s.source           = { :git => "https://git.csez.zohocorpin.com/opensource/zohoioscharts.git", :commit => "2e4af8e185540903330cc05ac88c9a602579b2d2" }
  #s.source           = { :git => "https://git.csez.zohocorpin.com/opensource/zohoioscharts.git", :tag => "0.1.0" }
  
  s.social_media_url = "http://zoho.com"
#  s.platform     = :ios, '10.0'
#  s.platform     = :ios, '9.1'
  s.ios.deployment_target = "9.1"
  s.tvos.deployment_target = "9.1"
  s.osx.deployment_target = "10.13"

  #s.requires_arc = true
  #s.source_files = 'ZCharts/zchart/**/*.{h,m,swift}'
  #s.resources =  ["ZCharts/zchart/**/*.lproj","ZCharts/zchart/**/*.plist"]
  #s.resources =  ["ZCharts/zchart/JS/*.js"]
  # s.resources =  ["ZCharts/zchart/**/*.js","ZCharts/zchart/**/*.html"]
  s.resources =  ["zchart/**/*.js","zchart/**/*.html",
   "PrivacyInfo.xcprivacy"]
  
  #spec.resources =  ["ZCharts/zchart/**/*.xcdatamodeld", "SearchKit_Library/ZohoSearchKit/**/*.lproj","SearchKit_Library/ZohoSearchKit/**/*.plist","SearchKit_Library/ZohoSearchKit/**/*.storyboard","SearchKit_Library/ZohoSearchKit/**/*.xib","SearchKit_Library/ZohoSearchKit/ZohoSearchKit_Assets.xcassets"]
  #s.frameworks = 'Foundation'
  #s.framework = 'XCTest'
  #s.module_name = 'zchart'

  s.default_subspec = "Core"

  s.subspec "Core" do |ss|
    # ss.source_files  = ["ZCharts/zchart/**/*.swift"]
    ss.source_files  = ["zchart/**/*.swift"]
  end

  s.static_framework = true
	
end
